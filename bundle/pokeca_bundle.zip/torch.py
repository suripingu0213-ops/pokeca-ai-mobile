"""スマホ版(Pyodide)用の torch 互換スタブ。web/app.py が使っている分(no_grad/tanh/load/Tensor)だけを持つ。

本物のtorchはスマホに載せない(重い)。モデルの重みは build_pwa.py が .npz 形式で書き出し、
ここの load() が numpy 配列の辞書として返す。
"""

from __future__ import annotations

import contextlib

import numpy as np


class Tensor:  # 型注釈用(web/app.pyは `from __future__ import annotations` なので評価されない)
    pass


def no_grad():
    return contextlib.nullcontext()


def tanh(x):
    return np.tanh(x)


def load(path, map_location=None, weights_only=False):
    """build_pwa.py が書いた .npz(拡張子は.ptのまま)を {"model_state": {...}, "vocab_card_ids": [...]} として返す。"""
    with np.load(path, allow_pickle=False) as z:
        vocab_card_ids = [str(s) for s in z["vocab_card_ids"]]
        state = {k: z[k] for k in z.files if k != "vocab_card_ids"}
    return {"model_state": state, "vocab_card_ids": vocab_card_ids}
