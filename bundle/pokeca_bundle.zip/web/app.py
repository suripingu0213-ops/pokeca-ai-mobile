"""盤面表示・クリック操作のローカルWebアプリ(Flask)。

使い方:
    python web/app.py
    ブラウザで http://127.0.0.1:5050 を開く
"""

from __future__ import annotations

import contextlib
import copy
import pickle
import random
import re
import sys
import time
import uuid
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parent.parent))

import torch
from flask import Flask, jsonify, render_template, request

from agents.network import PolicyValueNetwork
from agents.policy_agent import PolicyAgent
from cards.card_db import CardDatabase
from config.settings import BUG_REPORTS_DIR, CHECKPOINT_DIR, DATA_DIR, HUMAN_GAMES_DIR, REPLAY_DIR
from deck.deck_loader import load_deck
from deck.regulations import get_regulation, regulations_by_category
from engine.actions import Action, ResolveDamageDistribution, ResolveSearchChoice
from engine.display import card_name, describe_action, serialize_actions, serialize_card_detail, serialize_state
from engine.legal_actions import legal_actions, next_actor, user_prohibitions_disabled
from engine.rules_engine import IllegalActionError, apply_action
from engine.turn_manager import setup_new_game
from rl_env.encoding import CardVocab, encode_action, encode_state
from agents.deck_ai import DECK_AIS, ai_key_for_deck, store_path
from agents.empirical_agent import EmpiricalWinRateAgent
from rl_env.state_key import state_action_key
from training.visit_counts import VisitCountStore

app = Flask(__name__)
app.config["SEND_FILE_MAX_AGE_DEFAULT"] = 0  # static(js/css)をブラウザにキャッシュさせない(更新が反映されない事故を防ぐ)

CARD_DB = CardDatabase.from_cache()
SAMPLE_DECKS_DIR = Path(__file__).resolve().parent.parent / "deck" / "sample_decks"
DEFAULT_DECK_A = "deck/sample_decks/pjcs2026_bakegakure_kabu.yaml"
DEFAULT_DECK_B = "deck/sample_decks/pjcs2026_bakegakure_r.yaml"
DEFAULT_REGULATION = "pjcs2026"

# 複数タブ(同じブラウザで対戦画面を2つ開く等)を開くと、以前はグローバルな単一のGAME辞書を
# 全タブが共有していたため、片方のタブで「対局を始める」を押すともう片方の対局を無言で
# 上書きしてしまうバグがあった(「デッキが勝手に変わる」として報告された不具合の根本原因)。
# ここではタブごとに独立したgame_id(sessionStorageで管理、Cookieと違いタブ間で共有されない)を
# 発行し、GAMESにgame_id単位で状態を持たせることでタブ間の干渉を構造的になくす。
GAMES: dict[str, dict] = {}


def _new_game_dict() -> dict:
    return {
        "state": None,
        "player0_agent": "human",
        "player1_agent": "human",
        "policy_variant_0": "general",
        "policy_variant_1": "general",
        "human_records": [],
        "step_ai": False,
        "records_decided": False,
        "records_auto_discarded": False,
        # リプレイ再生モード(2026-09-18、事前生成した自己対戦の記録をコマ送りで見返す機能)。
        # "live"(通常の対局/観戦)か"replay"かを区別し、"replay"のときはreplay_stepsに保持した
        # 実際の行動列をそのままコマ送りで再生する(_advance_replay_one_step参照)。
        "mode": "live",
        "replay_steps": [],
        "replay_cursor": 0,
        "replay_meta": None,
        # 一手巻き戻し用のスナップショット履歴(2026-09-02、ユーザー報告「普通のポケカと違うので
        # ミスが起きやすい。学習データに問題が出ないように一手戻せるようにしてほしい」)。
        "undo_stack": [],
        # 記憶機構(agents.network.PolicyValueNetworkのGRU隠れ状態、2026-09-02)。
        # _make_inference_agentは(最新のAIに更新した際に即座に反映されるよう)毎回新しい
        # エージェントインスタンスを作るため、隠れ状態はエージェント側ではなくgame辞書側で
        # 対局をまたいで持ち回る(_agent_hidden_state_for_seat/_save_agent_hidden_state_for_seat参照)。
        "agent_hidden_states": {},
    }


def _agent_hidden_state_for_seat(game: dict, actor: int):
    return game.setdefault("agent_hidden_states", {}).get(actor)


def _save_agent_hidden_state_for_seat(game: dict, actor: int, agent) -> None:
    game.setdefault("agent_hidden_states", {})[actor] = getattr(agent, "hidden_state", None)


def _observe_for_ai_seats(game: dict, state) -> None:
    """AI操作の座席(いる場合)の記憶を、今の盤面(=直前の行動の結果)で更新する。人間の手番の後にも
    呼ぶことで、相手(人間)が何をしたかもAIの記憶に反映される(2026-09-02、ユーザー提案)。"""
    if state is None:
        return
    for actor in (0, 1):
        if not _seat_is_policy(game, actor):
            continue
        agent = _make_seat_agent(game, actor)
        agent.hidden_state = _agent_hidden_state_for_seat(game, actor)
        agent.observe(state, CARD_DB)
        _save_agent_hidden_state_for_seat(game, actor, agent)


def _get_game(game_id: str | None) -> dict | None:
    if not game_id:
        return None
    return GAMES.get(game_id)


def _load_policy_network(checkpoint_dir: Path) -> tuple[PolicyValueNetwork, CardVocab, str | None]:
    """checkpoint_dir配下に保存済みのモデル(policy_*.pt)があれば最新のものを読み込み、無ければ
    未学習のネットワークを使う(評価値・AI操作はいずれも意味のある精度にはならないが、機能自体は動く)。
    ネットワーク構造(入力次元等)が変わった後の旧チェックポイントは読み込めないため、その場合は
    エラーにせず未学習のネットワークにフォールバックする(起動時に例外で落ちないようにするため)。
    "policy_*.pt"限定でglobする(同じディレクトリに同居しうるopponent_pool_latest.ptを誤って
    読み込まないため)。戻り値の3つ目は実際に読み込めたチェックポイント名(フォールバック時はNone)。"""
    checkpoints = sorted(checkpoint_dir.glob("policy_*.pt"), key=lambda p: p.stat().st_mtime) if checkpoint_dir.exists() else []
    if checkpoints:
        latest = checkpoints[-1]
        checkpoint = torch.load(latest, map_location="cpu", weights_only=False)
        vocab = CardVocab.from_card_ids(checkpoint["vocab_card_ids"])
        network = PolicyValueNetwork(vocab_size=len(vocab))
        try:
            # strict=False: 記憶機構(memory_cell/memory_gate)等の新規モジュール追加直後でも、
            # 既存キーの形状さえ一致していれば旧チェックポイントを読み込める(新モジュールは
            # __init__時点の初期値のまま)。既存キーの形状不一致(本当に非互換)は引き続き
            # RuntimeErrorとしてこのexceptで捕まる。
            network.load_state_dict(checkpoint["model_state"], strict=False)
        except RuntimeError:
            vocab = CardVocab(CARD_DB)
            network = PolicyValueNetwork(vocab_size=len(vocab))
            loaded_name = None
        else:
            loaded_name = latest.name
    else:
        vocab = CardVocab(CARD_DB)
        network = PolicyValueNetwork(vocab_size=len(vocab))
        loaded_name = None
    network.eval()
    return network, vocab, loaded_name


# 対戦相手のAIとして選べるモデル(training_dashboardの学習プロファイルに対応)。
# 「通常AI」は全レギュレーション混在で学習した既存モデル、「HIJ専用AI」はHIJレギュレーション
# (現行スタンダード)のデッキだけで学習した専用モデル。それぞれ独立したチェックポイント
# ディレクトリを持つため、別々に読み込んで対局セットアップ画面で選べるようにする。
def _load_policy_models() -> dict[str, dict]:
    models = {}
    for key, label, directory in (
        ("general", "通常AI(全レギュレーション)", CHECKPOINT_DIR),
        ("hij", "HIJ専用AI", DATA_DIR / "checkpoints_hij"),
        # 2026-09-22追加: リプレイ添削で使う「今の専用AIから見た各選択肢の推定勝率」表示
        # (_replay_action_win_rates)専用。対局操作の対戦相手としては選べない(対局セットアップ
        # 画面のPOLICY_MODELS一覧には出すが、このモデル自体で実際に打たせる用途は今のところ無い)。
        ("osaka_aichi_mirror", "大阪優勝フーディン vs 愛知優勝ドラパルト(専用AI)", DATA_DIR / "checkpoints_osaka_aichi_mirror"),
        # 2026-09-25追加: ドラパルト(愛知優勝)デッキ同士のミラー戦だけに学習を集中させる専用AI
        # (training_dashboard.app PROFILES["aichi_dragapult_mirror"]が育てる)。対局セットアップ画面の
        # 「ドラパルト(愛知優勝)ミラー」専用枠(_DEDICATED_SLOTS)でだけ、対戦相手として固定で使う
        # (_new_game参照)。通常の対局セットアップのAI選択肢には出さない(/api/policy_models)。
        # 2026-09-25のラベルは「ドラパルト(愛知優勝)ミラー専用AI」だったが、既存のドラパAI
        # (DECK_AIS、実績の勝率だけで動く別物)と対局セットアップ画面で見分けづらいというユーザー
        # 指摘(2026-10-02)を受けて「ドラパミラーAI」に短縮・明確化した。
        ("aichi_dragapult_mirror", "ドラパミラーAI", DATA_DIR / "checkpoints_aichi_dragapult_mirror"),
    ):
        network, vocab, checkpoint_name = _load_policy_network(directory)
        models[key] = {"label": label, "network": network, "vocab": vocab, "checkpoint_name": checkpoint_name}
    return models


POLICY_MODELS = _load_policy_models()


def _policy_model(variant: str | None) -> dict:
    return POLICY_MODELS.get(variant or "general", POLICY_MODELS["general"])


_DECK_PLACEMENT_PATTERN = re.compile(r"(準優勝|優勝|ベスト(\d+)|(\d+)位)")

# 同じレギュレーション内に複数の大会のデッキが混在する場合(例: cl2026_ninjaspinner_eraは
# チャンピオンズリーグ2026大阪(2026年3月28-29日)と愛知5月(同年5月)の2大会を1レギュレーションに
# まとめている)、開催が古い方から先に並べるための大会名→順序のマップ。deck/regulations.pyの
# 説明文に書かれている実際の開催日を根拠にしている。ここに無い大会名は既定値0のまま(=同じ
# レギュレーション内が単一大会しか無い場合はこの段の判定が効かず、順位のみで並ぶ従来通りの
# 挙動になる)。新しい複数大会レギュレーションを追加したときはここにも追記すること。
_TOURNAMENT_CHRONOLOGICAL_ORDER: dict[str, int] = {
    "CL2026大阪": 0,  # 2026年3月28-29日
    "CL2026愛知5月": 1,  # 2026年5月
}


def _deck_placement_rank(deck_name: str) -> int:
    """デッキ名の「(CL2026大阪優勝 ...)」「(2025年世界大会3位 ...)」等の表記から、大会内の
    順位を表す整数を取り出す(優勝=1、準優勝=2、ベストN=N-1、N位=N)。準優勝は「優勝」を
    部分文字列として含むため、優勝を優先して誤判定しないよう別々にチェックする。表記が無い
    デッキ(ミラー用/現行スタンダード等)は末尾にまとめる。"""
    match = _DECK_PLACEMENT_PATTERN.search(deck_name)
    if match is None:
        return 999
    if match.group(1) == "準優勝":
        return 2
    if match.group(1) == "優勝":
        return 1
    if match.group(2) is not None:  # ベストN
        return max(1, int(match.group(2)) - 1)
    return int(match.group(3))  # N位


def _deck_tournament_rank(deck_name: str) -> int:
    """デッキ名の大会表記部分(順位表記の手前)を取り出し、_TOURNAMENT_CHRONOLOGICAL_ORDERで
    開催の古い順を調べる。マップに無い大会名(=そのレギュレーション内は単一大会のみ)は0として
    扱い、この段の判定を実質無効化する(全デッキが同じキーになるので、後続の順位キーだけで
    並ぶ)。"""
    match = _DECK_PLACEMENT_PATTERN.search(deck_name)
    if match is None:
        return 0
    paren_start = deck_name.rfind("(", 0, match.start())
    if paren_start == -1:
        return 0
    tournament_label = deck_name[paren_start + 1 : match.start()]
    return _TOURNAMENT_CHRONOLOGICAL_ORDER.get(tournament_label, 0)


def _deck_sort_key(deck_name: str) -> tuple[int, int, str]:
    """大会の開催が古い順→大会内の成績順(優勝が先)→デッキ名の五十音/アルファベット順、の
    3段階でデッキを並べるためのキーを返す(2026-09-01、ユーザー要望「デッキの順番を優勝順番、
    複数の大会がある場合には古いものから新しいものに」対応)。"""
    return (_deck_tournament_rank(deck_name), _deck_placement_rank(deck_name), deck_name)


def _list_decks(regulation_id: str | None = None) -> list[dict]:
    decks = []
    for path in sorted(SAMPLE_DECKS_DIR.glob("*.yaml")):
        relative_path = f"deck/sample_decks/{path.name}"
        try:
            deck = load_deck(relative_path, CARD_DB, validate=False)
        except Exception:
            continue
        if regulation_id is not None and deck.regulation != regulation_id:
            continue
        decks.append(
            {
                "id": path.stem,
                "name": deck.name,
                "path": relative_path,
                "card_count": sum(deck.cards.values()),
                "regulation": deck.regulation,
            }
        )
    decks.sort(key=lambda d: _deck_sort_key(d["name"]))
    return decks


def _new_game(
    deck_a_path: str, deck_b_path: str, seed: int | None, regulation_id: str,
    player0_agent: str, player1_agent: str,
    policy_variant_0: str = "general", policy_variant_1: str = "general",
    eval_variant_0: str | None = None, eval_variant_1: str | None = None,
) -> str:
    dedicated_slot = _DEDICATED_SLOTS.get(regulation_id)
    regulation_id = dedicated_slot.get("real_regulation", regulation_id) if dedicated_slot else regulation_id
    deck_a = load_deck(deck_a_path, CARD_DB)
    deck_b = load_deck(deck_b_path, CARD_DB)
    # デッキ自体のregulationと、セットアップ画面で選ばれたregulation_idが食い違っていないか確認する。
    # フロントエンドは選んだレギュレーションのデッキ一覧しか出さない設計だが、通信の遅延順序が
    # 入れ替わる等でズレたまま送信されると、選んだのと違うルールセットで対局が始まってしまう
    # (「別のレギュレーションを読み込んでいる」ように見える不具合の実例)ため、ここでも検証する。
    if deck_a.regulation != regulation_id or deck_b.regulation != regulation_id:
        raise ValueError(
            f"選択中のレギュレーション({regulation_id})と、デッキ自体のレギュレーション"
            f"(player0: {deck_a.regulation} / player1: {deck_b.regulation})が一致しません。"
            "画面を再読み込みしてから、レギュレーションとデッキを選び直してください。"
        )
    rng = random.Random(seed)
    ruleset = get_regulation(regulation_id).ruleset
    game = _new_game_dict()
    game["state"] = setup_new_game(deck_a.to_card_list(), deck_b.to_card_list(), CARD_DB, rng, ruleset=ruleset)
    # 対局終了時、専用AIの対決(_DEDICATED_PROFILE_DECK_NAMES)ならその専用の人間対局データ
    # フォルダにも書き出すため保持しておく(2026-09-24、api_save_human_records参照)。
    game["deck_a_path"] = deck_a_path
    game["deck_b_path"] = deck_b_path
    game["player0_agent"] = player0_agent if player0_agent in ("human", "policy") else "human"
    game["player1_agent"] = player1_agent if player1_agent in ("human", "policy") else "human"
    game["policy_variant_0"] = policy_variant_0 if (policy_variant_0 in POLICY_MODELS or policy_variant_0 in DECK_AIS) else "general"
    game["policy_variant_1"] = policy_variant_1 if (policy_variant_1 in POLICY_MODELS or policy_variant_1 in DECK_AIS) else "general"
    # 専用枠にfixed_aiが指定されていれば、AI操作の座席は必ずそのAIを使う(2026-09-25、ユーザー指示
    # 「AIはドラパルトの新しく作るAIの固定でいい」)。フロントエンドが送ってきた値に関わらず
    # サーバー側で強制する(選択肢を出さない設計だが、念のための二重の防御)。
    fixed_ai = dedicated_slot.get("fixed_ai") if dedicated_slot else None
    if fixed_ai is not None:
        if game["player0_agent"] == "policy":
            game["policy_variant_0"] = fixed_ai
        if game["player1_agent"] == "policy":
            game["policy_variant_1"] = fixed_ai
    # 人間操作の座席の番に、どのAIの評価値を表示するか(2026-09-25、ユーザー要望)。指定が無い/不明なら
    # 従来通り、相手側(AI操作の座席)のAIを評価役にする(_eval_variant_for_actor)。
    for seat, chosen in ((0, eval_variant_0), (1, eval_variant_1)):
        if chosen in POLICY_MODELS or chosen in DECK_AIS:
            game[_eval_variant_key_for_seat(seat)] = chosen
    if game["player0_agent"] == "policy" and game["player1_agent"] == "policy":
        # AI同士の対局(観戦モード)。ここでstep_aiを強制しておかないと、_auto_advance_aiが
        # 対局を最後まで一気に進めてしまい(1手ごとの探索を挟むと数十秒かかることもある)、
        # 「見れるように」というユーザー要望に反して1手も見せずに終わってしまう。
        game["step_ai"] = True
    game_id = uuid.uuid4().hex
    GAMES[game_id] = game
    return game_id


def _list_replay_files() -> list[Path]:
    if not REPLAY_DIR.exists():
        return []
    return sorted(REPLAY_DIR.glob("*.pkl"), key=lambda p: p.stat().st_mtime, reverse=True)


def _load_replay_record(path: Path) -> dict:
    with open(path, "rb") as f:
        return pickle.load(f)


def _record_claude_seats(record: dict) -> tuple[int, ...]:
    """scripts/claude_play_session.pyが書き出したリプレイのレコードから、Claude自身が判断した
    座席の一覧を取り出す(2026-09-22、--dual-claude対応でclaude_seat(単数)からclaude_seats
    (複数対応)に一般化)。新しい"claude_seats"フィールドを優先し、無ければ旧"claude_seat"
    (単数、2026-09-19以前〜9/22の単一シート版リプレイ)から復元する。どちらも無ければ
    scripts/generate_self_play_replay.pyが書き出した通常の自己対戦リプレイ(HIJ AI同士)で、
    空タプルを返す。"""
    seats = record.get("claude_seats")
    if seats is not None:
        return tuple(seats)
    claude_seat = record.get("claude_seat")
    if claude_seat is None:
        return ()
    return (claude_seat,)


def _replay_matchup_label(record: dict) -> str:
    """「誰対誰か」をリプレイ一覧・再生画面の一番目立つ位置に出すための短いラベル
    (2026-09-19、ユーザー要望)。deck_a/deck_bの並び順と揃える(座席0がClaudeならClaudeが先、
    座席1なら後)。"""
    claude_seats = _record_claude_seats(record)
    if len(claude_seats) >= 2:
        return "Claude vs Claude"
    if not claude_seats:
        return "HIJ AI vs HIJ AI"
    return "Claude vs HIJ AI" if claude_seats[0] == 0 else "HIJ AI vs Claude"


# 2026-09-22追加: リプレイ添削中の選択肢ごとの推定勝率表示(ユーザー要望「フーディンAI対
# どらパAI・クロード対AI・クロード対クロードの時だけ選択肢の時に出るように」)。表示対象は
# 「専用AI(POLICY_MODELS)が存在するデッキ対決のリプレイかどうか」で判定する(現状
# osaka_aichi_mirrorだけ)。誰が実際に対局を打ったか(AI同士/Claude/Claude対Claude)は問わない
# ――記録時点の評価値ではなく「今の専用AIならどう評価するか」を事後的に見るための機能なので、
# 対局を実際に打った側がAIかClaudeかに関わらず、対応する専用AIさえあれば表示してよい
# (2026-09-22、ユーザー確認済み)。
_DEDICATED_PROFILE_DECK_NAMES: dict[str, frozenset[str]] = {
    "osaka_aichi_mirror": frozenset(
        {"cl2026osaka_alakazam_dudunsparce_akagi.yaml", "cl2026aichimay_dragapult_dusknoir_shiokawa.yaml"}
    ),
    # 2026-10-02追加: ドラパルト(愛知優勝)ミラー専用AI(NN)。両陣営とも同じデッキなので
    # ファイル名の集合は1つだけになる(_replay_dedicated_profile参照)。
    "aichi_dragapult_mirror": frozenset({"cl2026aichimay_dragapult_dusknoir_shiokawa.yaml"}),
}

# 専用AIの対決を人間が対局した場合、通常のdata/human_games/(全レギュレーション共通プール)に
# 加えて、専用AI自身の学習(training.train --human-data-dir)がこのマッチアップの対局だけを
# 読み込めるよう、専用のフォルダにも複製して書き出す(2026-09-24、ユーザー要望「私の対戦は
# 人間の対戦に反映されるようにしてください」)。ディレクトリ名はtraining_dashboard/app.pyの
# checkpoint_dir命名規則(checkpoints_<profile>)と揃えている。
_DEDICATED_PROFILE_HUMAN_GAMES_DIRS: dict[str, Path] = {
    "osaka_aichi_mirror": DATA_DIR / "human_games_osaka_aichi_mirror",
    # 2026-10-02、ユーザー要望「どらパミラーで戦った対局のみを、どらパミラーの人間学習データとして
    # 追加してほしい」。training_dashboard.app PROFILES["aichi_dragapult_mirror"]の
    # --human-data-dirがこのフォルダを指す。
    "aichi_dragapult_mirror": DATA_DIR / "human_games_aichi_dragapult_mirror",
}


def _replay_dedicated_profile(deck_a_path: str, deck_b_path: str) -> str | None:
    """このリプレイのデッキ対決に対応する専用AI(POLICY_MODELSのキー)があればそれを返す。
    無ければNone(=推定勝率は表示しない)。パスの表記ゆれ(相対/絶対、区切り文字)を避けるため
    ファイル名だけで比較する。"""
    names = {Path(deck_a_path).name, Path(deck_b_path).name}
    for profile_key, deck_names in _DEDICATED_PROFILE_DECK_NAMES.items():
        if names == deck_names:
            return profile_key
    return None


def _new_replay_game(replay_path: Path) -> str:
    """scripts/generate_self_play_replay.pyが書き出したdata/replays/*.pklを読み込み、
    1手ずつコマ送りで再生できる新しいgameを作る。

    初期盤面は記録時と同じ(deck_a_path, deck_b_path, seed)から再構築する
    (rl_env.environment.GameEnvironment.resetと同じくengine.turn_manager.setup_new_gameを
    直接呼ぶだけなので、記録時と完全に同じ初期手札・初期山札順になる)。記録済みのsteps
    (実際に選ばれたAction列)をそのまま順に適用していく。"""
    record = _load_replay_record(replay_path)
    deck_a = load_deck(record["deck_a_path"], CARD_DB)
    deck_b = load_deck(record["deck_b_path"], CARD_DB)
    ruleset = get_regulation(record["regulation"]).ruleset
    rng = random.Random(record["seed"])
    game = _new_game_dict()
    game["state"] = setup_new_game(deck_a.to_card_list(), deck_b.to_card_list(), CARD_DB, rng, ruleset=ruleset)
    game["player0_agent"] = "policy"
    game["player1_agent"] = "policy"
    game["step_ai"] = True
    game["mode"] = "replay"
    game["replay_steps"] = record["steps"]
    game["replay_cursor"] = 0
    game["replay_source"] = record.get("source")
    game["claude_seats"] = _record_claude_seats(record)
    game["deck_a_path"] = record["deck_a_path"]
    game["deck_b_path"] = record["deck_b_path"]
    game["replay_win_rate_profile"] = _replay_dedicated_profile(record["deck_a_path"], record["deck_b_path"])
    game["replay_meta"] = {
        "path": str(replay_path),
        "matchup_label": _replay_matchup_label(record),
        "deck_a_label": record.get("deck_a_label", record["deck_a_path"]),
        "deck_b_label": record.get("deck_b_label", record["deck_b_path"]),
        "winner": record.get("winner"),
        "win_reason": record.get("win_reason"),
        "turn_count": record.get("turn_count"),
        "step_count": len(record["steps"]),
        "checkpoint": record.get("checkpoint"),
        "checkpoint_iter": _checkpoint_iteration(record.get("checkpoint")),
        "total_games_trained": record.get("total_games_trained"),
    }
    game_id = uuid.uuid4().hex
    GAMES[game_id] = game
    return game_id


def _replay_step_actor_action(step: tuple) -> tuple[int, Action]:
    """replay_stepsの1要素から(actor, action)を取り出す。2026-09-19以前に生成した2要素タプル
    (actor, action)と、それ以降の4要素タプル(actor, action, eval_value, action_scores)の
    どちらでも読めるようにする(既存のリプレイファイルとの後方互換)。"""
    return step[0], step[1]


def _replay_step_eval(step: tuple) -> tuple[float | None, list[float] | None]:
    """replay_stepsの1要素から、その時点でAIが実際の判断に使った評価値(eval_value, action_scores)を
    取り出す。2026-09-19より前に生成した2要素タプルには記録が無いため(None, None)を返す。"""
    if len(step) >= 4:
        return step[2], step[3]
    return None, None


def _advance_replay_one_step(game: dict) -> bool:
    """リプレイ再生モード中、記録済みの行動を1つだけ適用する(コマ送り用)。
    _advance_ai_one_stepのリプレイ版。実行したらTrue、再生し終わっている/対局が終わっている
    ならFalseを返す(_advance_ai_one_stepと同じ戻り値の意味)。"""
    state = game["state"]
    if state is None or state.is_game_over():
        return False
    steps = game.get("replay_steps") or []
    cursor = game.get("replay_cursor", 0)
    if cursor >= len(steps):
        return False
    actor, action = _replay_step_actor_action(steps[cursor])
    _push_undo_snapshot(game)
    description = describe_action(action, state.players[actor], CARD_DB, state)
    game["last_ai_action_descriptions"] = [{"seat": actor, "description": description, "was_lethal": False}]
    game["last_ai_action_description"] = description
    game["last_ai_action_was_lethal"] = False
    apply_action(state, CARD_DB, action)
    game["replay_cursor"] = cursor + 1
    return True


def _make_inference_agent(model: dict, actor_index: int) -> PolicyAgent:
    """対人戦用のAIエージェントを組み立てる。

    2026-09-05、ユーザー判断によりlethal_solver(必勝手ソルバー)とSearchPolicyAgent(浅い先読み)は
    どちらも対人戦の実際の手選択には使わないことにした。理由: (1) lethal_solverはランダム性を含む
    行動を一律除外する保守的な実装のため、実際にはリーサルを見逃すことが多く信頼性が低い、
    (2) 先読みが方策ネットワーク自身の判断(生スコア最大の手)とは異なる手を選ぶことがあり、
    フロントエンドに表示される「AI評価値」(_evaluate_position、先読みなしの生スコア)とAIの
    実際の行動がズレる原因になっていた ―― ユーザーからの「評価値通りに動いているものを見たい」
    という要望に対し、表示側を先読み込みにして合わせるより、先読み・必勝手判定自体を無くして
    ネットワーク自身のgreedy選択(scores最大)だけにする方が単純で確実と判断した。
    これで実際の行動は_evaluate_position()が表示する評価値の最大値と(隠れ状態の扱いを除けば)
    一致するはず。

    lethal_solver/SearchPolicyAgent自体は削除していないので、将来また使いたくなったら
    `agents.lethal_agent.LethalThenPolicyAgent`で`agents.search_policy_agent.SearchPolicyAgent`
    (search_width=6, search_depth=2, max_simulations=40が以前使っていた値)をラップして
    ここで返すように戻せばよい(git履歴、またはこの関数の直前のバージョンを参照)。"""
    return PolicyAgent(model["network"], model["vocab"], actor_index=actor_index, greedy=True, epsilon=0.0)


class _DeckAIAgent(EmpiricalWinRateAgent):
    """対局用のデッキ別AI(フーディンAI/ドラパAI): 実績の勝率だけで手を選ぶ(agents.empirical_agent)。
    記憶(隠れ状態)は持たないが、既存の対局ロジックが期待するhidden_state/observeだけ備える。"""

    hidden_state = None

    def observe(self, state, card_db) -> None:
        return None


def _make_seat_agent(game: dict, actor: int):
    variant = game.get(_policy_variant_key_for_seat(actor))
    if variant in DECK_AIS:
        vocab = _policy_model("osaka_aichi_mirror")["vocab"]  # 盤面キーの語彙(agents.deck_ai.VOCAB_CHECKPOINT_DIR)
        return _DeckAIAgent(_visit_count_store(variant, create=True), vocab, actor_index=actor, epsilon=0.0)
    return _make_inference_agent(_policy_model(variant), actor_index=actor)


def _agent_key_for_seat(actor: int) -> str:
    return "player0_agent" if actor == 0 else "player1_agent"


def _policy_variant_key_for_seat(actor: int) -> str:
    return "policy_variant_0" if actor == 0 else "policy_variant_1"


def _eval_variant_key_for_seat(actor: int) -> str:
    return "eval_variant_0" if actor == 0 else "eval_variant_1"


def _seat_is_policy(game: dict, actor: int) -> bool:
    return game.get(_agent_key_for_seat(actor), "human") == "policy"


def _eval_variant_for_actor(game: dict, actor: int) -> str:
    """今の手番側の評価に使うAIモデルを選ぶ。手番側がAI操作ならその自身のモデルを使う(AI同士の
    対局を観戦するとき、今動いている側の判断をそのまま見せるため)。手番側が人間操作なら、
    相手側(AI操作の方)のモデルを判定役として使う(player1のみAI操作をサポートしていた頃と
    同じ挙動を維持する、2026-09-01のplayer0/player1両対応化で一般化)。"""
    if _seat_is_policy(game, actor):
        return game.get(_policy_variant_key_for_seat(actor), "general")
    chosen = game.get(_eval_variant_key_for_seat(actor))
    if chosen:
        return chosen  # 人間操作の座席でユーザーが選んだ、評価値を表示するAI
    other = 1 - actor
    return game.get(_policy_variant_key_for_seat(other), "general")


def _eval_hidden_state_for_actor(game: dict, actor: int):
    """_eval_variant_for_actorと同じ判定基準(判定役に選ばれた側の視点)で、その判定役が実際に
    持ち回っている隠れ状態を返す(2026-09-05追加)。_evaluate_position表示用の評価値を、実際に
    このgameを操作しているAIエージェントの記憶と揃えるため。"""
    if _seat_is_policy(game, actor):
        return _agent_hidden_state_for_seat(game, actor)
    other = 1 - actor
    chosen = game.get(_eval_variant_key_for_seat(actor))
    if chosen and not (_seat_is_policy(game, other) and game.get(_policy_variant_key_for_seat(other)) == chosen):
        return None  # 相手AIとは別のモデルを評価役に選んだ場合、相手AIの記憶は流用できない
    return _agent_hidden_state_for_seat(game, other)


def _auto_advance_ai(game: dict) -> None:
    """AI操作の座席(player0/player1のどちらか、または両方)の手番である間、自動で行動を選び
    続ける。500手を超えたら異常事態として打ち切る(通常の対局は数百手以内に終わるため、
    無限ループ化した場合の安全弁)。

    game["step_ai"]がTrueの場合(「AIの手をコマ送りで見る」設定)は、まとめて最後まで進めず
    1手だけ実行して戻る。相手が何をしているか分かりにくいという声を受け、フロントエンド側から
    /api/ai_stepを1手ずつ呼んで進められるようにするため。AI同士の対局(観戦モード)は
    _new_game側で常にこのモードを強制している。

    1回の呼び出しでAIが複数手(どうぐ添付→ワザ等)を連続して行うことがあるため、
    game["last_ai_action_descriptions"]にこの呼び出し中に実行した手を全て順番に記録する
    (以前は単一のlast_ai_action_descriptionを毎回上書きしていたため、最後の1手しか
    フロントエンドに表示されず、それより前の手が消えてしまっていた不具合、2026-09-01発覚)。
    各エントリの"seat"は、その手を指したのがplayer0/player1のどちらかを表す(観戦モードで
    フロントエンドがどちらの手か表示できるようにするため)。
    """
    state = game["state"]
    if state is None:
        return
    if game.get("step_ai"):
        _advance_ai_one_step(game)
        return
    agents_by_seat: dict[int, PolicyAgent] = {}
    descriptions: list[dict] = []
    steps = 0
    while not state.is_game_over() and steps < 500:
        actor = next_actor(state)
        if not _seat_is_policy(game, actor):
            break
        actions = legal_actions(state, CARD_DB)
        if not actions:
            break
        if actor not in agents_by_seat:
            agents_by_seat[actor] = _make_seat_agent(game, actor)
            agents_by_seat[actor].hidden_state = _agent_hidden_state_for_seat(game, actor)
        agent = agents_by_seat[actor]
        chosen = agent.choose_action(state, CARD_DB, actions)
        descriptions.append(
            {
                "seat": actor,
                "description": describe_action(chosen, state.players[actor], CARD_DB, state),
                # 2026-09-05にlethal_solverを対人戦の実際の手選択から外したため、常にFalse
                # (agent.last_used_lethalに相当する概念自体が今は存在しない)。
                "was_lethal": False,
            }
        )
        apply_action(state, CARD_DB, chosen)
        _save_agent_hidden_state_for_seat(game, actor, agent)
        _observe_for_ai_seats(game, state)  # 今行動していない側のAI(いれば)の記憶も更新する
        steps += 1
    if descriptions:
        game["last_ai_action_descriptions"] = descriptions
        game["last_ai_action_description"] = descriptions[-1]["description"]
        game["last_ai_action_was_lethal"] = descriptions[-1]["was_lethal"]


def _advance_ai_one_step(game: dict) -> bool:
    """AIの手を1つだけ実行する(コマ送りモード用)。実行したらTrue、AI操作の座席の番でない/
    合法手が無い/対局が終わっている等で何もしなかったらFalseを返す。

    2026-09-05にlethal_solver/SearchPolicyAgentを対人戦の実際の手選択から外したため
    (_make_inference_agent参照)、was_lethalは常にFalse。それでもなお「評価値
    (_evaluate_position、常にゼロ隠れ状態で計算)の上位と違う手をAIが選ぶ」ケースが残るとしたら、
    実際のエージェントが対局を通して持ち越している記憶(隠れ状態)を評価値側が反映していないため
    (_evaluate_position付近のコメント参照)。

    リプレイ再生モード(2026-09-18、game["mode"] == "replay")では、ライブ推論する代わりに
    _advance_replay_one_stepへ委譲し、事前に記録済みの行動をそのまま1つ再生する。"""
    if game.get("mode") == "replay":
        return _advance_replay_one_step(game)
    state = game["state"]
    if state is None or state.is_game_over():
        return False
    actor = next_actor(state)
    if not _seat_is_policy(game, actor):
        return False
    actions = legal_actions(state, CARD_DB)
    if not actions:
        return False
    agent = _make_seat_agent(game, actor)
    agent.hidden_state = _agent_hidden_state_for_seat(game, actor)
    chosen = agent.choose_action(state, CARD_DB, actions)
    description = describe_action(chosen, state.players[actor], CARD_DB, state)
    game["last_ai_action_descriptions"] = [
        {"seat": actor, "description": description, "was_lethal": False}
    ]
    game["last_ai_action_description"] = description
    game["last_ai_action_was_lethal"] = False
    apply_action(state, CARD_DB, chosen)
    _save_agent_hidden_state_for_seat(game, actor, agent)
    _observe_for_ai_seats(game, state)  # 今行動していない側のAI(いれば)の記憶も更新する
    return True


def _human_seat_prohibitions_off(game: dict):
    """人間操作の座席の番のあいだ、禁止行動(data/prohibited_actions.md)を無効にするコンテキスト
    (2026-09-25、ユーザー指摘「AIの禁止行動が私にも適用されている。なかよしポフィンしか使えない場面が
    あった」)。禁止行動は学習効率化のためにAIの選択肢だけを絞るもので、人間には適用しない。本物の
    カードルールはそのまま適用される。リプレイ再生・AI操作の座席の番・対局終了後は何もしない
    (AIの手選択・観戦では従来どおり禁止行動が効く)。"""
    state = game.get("state")
    if game.get("mode") == "replay" or state is None or state.is_game_over():
        return contextlib.nullcontext()
    if _seat_is_policy(game, next_actor(state)):
        return contextlib.nullcontext()
    return user_prohibitions_disabled()


def _is_human_turn(state, game: dict) -> bool:
    """今の手番側がAI操作(policy)でなければ人間操作とみなす(以前はplayer0が常に人間操作という
    前提だったが、player0もAI操作を選べるようになった2026-09-01のAI観戦モード追加で一般化した)。"""
    return not _seat_is_policy(game, next_actor(state))


def _record_human_decision(game: dict, state, action: Action) -> None:
    """人間が選んだ手を模倣学習の教師データとして記録する(勝敗は問わない)。
    実行前の盤面・その時点の合法手一覧・選んだ手のインデックスを保持しておき、対局が終わった時点で
    ユーザーが「この対局を学習に使うか」を選んでから、初めてdata/human_games/へ書き出す
    (_maybe_prompt_for_record_decision/api_save_human_records)。検証で適当にプレイした対局まで
    無条件に学習データへ混ぜてしまうと困る、という要望のため、対局終了時点では即座に書き出さない。"""
    if not _is_human_turn(state, game):
        return
    actor = next_actor(state)
    actions_before = legal_actions(state, CARD_DB)
    try:
        chosen_index = actions_before.index(action)
    except ValueError:
        return  # 想定外(手動構築したActionが列挙結果と一致しない等)なら記録しない
    if len(actions_before) <= 1:
        return  # 選択肢が1つしかない場面は模倣対象として無意味
    game["human_records"].append(
        {
            "state": copy.deepcopy(state),
            "actor": actor,
            "legal_actions": actions_before,
            "chosen_index": chosen_index,
        }
    )


def _human_won_by_deck_out(game: dict, state) -> bool:
    """人間操作の側が、相手の山札切れ(LO)によって勝ったか。2026-09-16ユーザー指摘: LO勝ちした
    対局の人間の手をそのまま模倣学習データにしてしまうと、その対局中の(相手を山札切れさせる
    ために回りくどい/非効率な手を選んでいたかもしれない)手を「良い手」として真似させてしまい、
    自己対戦側で意図的に設けている「自分の山札切れを避けさせる」学習(training/reinforce.pyの
    EMPTY_DECK_TURN_END_PENALTY/DECK_OUT_LOSS_REWARD、山札切れ決着の勝者は自己対戦の学習対象
    からも除外している)と矛盾する信号になりうる。相手を山札切れさせること自体は正当な戦略
    ([[project_pokeca_deckout_penalty_provisional]]参照)だが、その対局の人間の手を模倣学習の
    教師データにするのは別問題のため、ここで検出して保存対象から自動的に除外する。"""
    if state is None or state.winner is None or state.winner == -1:
        return False
    if state.win_reason != "deck_out":
        return False
    return not _seat_is_policy(game, state.winner)


def _pending_record_decision(game: dict, state) -> bool:
    """対局が終わっていて、学習データとして保存するか未確定の人間の記録が残っているか。

    相手の山札切れ(LO)で人間側が勝った対局は、_human_won_by_deck_out参照の理由により
    保存するかどうかの確認自体を出さず、記録を自動的に破棄する(records_auto_discardedを
    立てて、フロントエンドがその旨を一度だけ表示できるようにする)。"""
    if not (
        bool(game.get("human_records")) and state is not None and state.is_game_over()
        and not game.get("records_decided")
    ):
        return False
    if _human_won_by_deck_out(game, state):
        game["human_records"] = []
        game["records_decided"] = True
        game["records_auto_discarded"] = True
        return False
    return True


_UNDO_STACK_MAX = 20  # 際限なく積み上がらないよう上限を設ける(長い対局でもメモリを圧迫しないため)


def _push_undo_snapshot(game: dict) -> None:
    """人間の操作(api_action/api_resolve_search_choice/api_resolve_damage_distribution)を適用する
    直前に呼び、盤面・模倣学習用記録・AIの記憶(hidden_state)をまとめてスナップショットする。
    _pop_undo_snapshotで、この一連の操作(その後のAIの自動応答も含む)を丸ごと取り消せる。"""
    state = game.get("state")
    if state is None:
        return
    game.setdefault("undo_stack", []).append(
        {
            "state": copy.deepcopy(state),
            "human_records_len": len(game.get("human_records") or []),
            "agent_hidden_states": copy.deepcopy(game.get("agent_hidden_states") or {}),
            # リプレイ再生モードのコマ送り位置(2026-09-18)。ライブ対局では常にNoneのまま無視される。
            "replay_cursor": game.get("replay_cursor") if game.get("mode") == "replay" else None,
        }
    )
    if len(game["undo_stack"]) > _UNDO_STACK_MAX:
        game["undo_stack"].pop(0)


def _pop_undo_snapshot(game: dict) -> bool:
    """直前のスナップショットへ盤面を戻す。戻せるものが無ければFalseを返す。
    human_recordsは元の長さに切り詰める(=ミスった手を模倣学習の教師データに混ぜない、という
    今回のユーザー要望の核心部分。human_recordsは対局終了時にユーザーが明示的に保存を確定する
    まではメモリ上にあるだけなので、ここで切り詰めれば保存されるデータには一切残らない)。
    リプレイ再生モード(2026-09-18)ではreplay_cursorも合わせて巻き戻す。"""
    stack = game.get("undo_stack") or []
    if not stack:
        return False
    snapshot = stack.pop()
    game["state"] = snapshot["state"]
    game["human_records"] = (game.get("human_records") or [])[: snapshot["human_records_len"]]
    game["agent_hidden_states"] = snapshot["agent_hidden_states"]
    game["records_decided"] = False
    if game.get("mode") == "replay" and snapshot.get("replay_cursor") is not None:
        game["replay_cursor"] = snapshot["replay_cursor"]
    return True


def _evaluate_position(
    state, policy_variant: str | None = None, hidden_state: torch.Tensor | None = None,
) -> tuple[float | None, list[float] | None]:
    """現在の手番側から見た局面評価値(-1〜1)と、各合法手に対するAIの推奨度
    (legal_actions()と同じ並び順の生スコア)を1回のforwardでまとめて計算する。

    2026-09-09、ユーザー指摘を受け、推奨度は「AIが実際に行動を選ぶときに使っている値」に統一した。
    以前はsoftmax確率(合計1.0、0〜100%表示)を返していたが、agents/policy_agent.PolicyAgent の
    greedy選択は`torch.argmax(scores)`で生スコアそのものを比較しており、softmaxは表示用の変換に
    過ぎなかった。この変換により、複数の選択肢の中で1つが明確に優れている(にすぎない)場面でも
    「AI:100%」という、あたかも「勝率100%」であるかのような誤解を招く表示になってしまっていた
    (カードゲームには運の要素があるのに100%はおかしい、というユーザー指摘)。生スコアは上限が
    無く合計も1にならないため、この誤解を避けられる。順序(どれが1位か)はsoftmax確率と完全に
    同じ(単調変換のため)なので、実際の行動選択との整合性は変わらない。

    盤面は手番が変わるたびに「自分」側が入れ替わって表示される(serialize_stateのis_viewer)ため、
    どちらも同じ視点(次に行動するプレイヤー)で揃える。未学習モデルでは参考値程度にしかならない。
    対戦準備中(最初に出すポケモンを選ぶ場面等)も含めて評価する。終局後・合法手が無い場合のみ (None, None)。
    policy_variant: このgameで対戦相手として選ばれているAI(POLICY_MODELSのキー)。評価表示も
    実際に対戦しているモデルの視点に揃える。
    hidden_state: 2026-09-05、実際にこのgameを操作しているAIエージェントインスタンスが持ち回っている
    隠れ状態(_agent_hidden_state_for_seat)をそのまま渡せるようにした。以前はここが常にNone
    (ゼロ隠れ状態)固定で、実際の手選択(記憶を踏まえたgreedy選択)と評価値表示の前提がズレ、
    「評価値の1位と違う手をAIが選ぶ」原因の1つになっていた(lethal_solver/検索を無くした後も
    まだズレが残っていたのはこれが理由)。呼び出し側が手番の座席の隠れ状態を渡せば一致する。
    """
    if state is None or state.is_game_over():
        return None, None
    actor = next_actor(state)
    actions = legal_actions(state, CARD_DB)
    if not actions:
        return None, None
    if policy_variant in DECK_AIS:
        return None, None  # 実績の勝率で打つデッキ別AIにはニューラルネットの評価値が無い
    player = state.player(actor)
    model = _policy_model(policy_variant)
    network, vocab = model["network"], model["vocab"]
    with torch.no_grad():
        state_features = encode_state(state, CARD_DB, vocab, actor)
        action_features = [encode_action(a, player, CARD_DB, vocab, state) for a in actions]
        scores, value, _ = network(state_features, action_features, hidden_state)
    eval_value = round(float(torch.tanh(value).item()), 4)
    action_scores = [round(float(s), 4) for s in scores]
    return eval_value, action_scores


def _replay_action_win_rates(
    state: GameState, actions: list[Action], profile_key: str, actor: int
) -> list[float | None] | None:
    """リプレイ添削用: 今の局面で選べる各選択肢について、`profile_key`に対応する専用AI
    (POLICY_MODELS)の"今の"チェックポイントで実際に1手先まで仮進行させ、その結果状態を
    同じネットワークで評価した値(actor視点の推定勝率%)を返す(2026-09-22、ユーザー要望)。
    記録時点の評価値(ai_eval/action_scores)とは別物で、常に現在のチェックポイントを使う
    (「今の専用AIならこの対局をどう評価するか」を見るための事後評価)。

    value_head は combined_emb(状態埋め込み)だけから計算され action_features には依存しない
    (agents/network.PolicyValueNetwork.forward参照)ため、行動後の局面のvalueだけを見ればよい。
    value_headはtanhで[-1,1]に丸められ、その状態で「次に行動する側」から見た値を返すため、
    行動後も手番がactorのまま(エネルギー添付等)ならそのまま、相手に手番が移ればactor視点に
    揃えるため符号を反転する。記憶機構(hidden_state)は、このネットワークが実際にこの対局を
    打ったわけではない(事後評価専用)ため、常にNone(ゼロ隠れ状態)で評価する簡易版。"""
    model = _policy_model(profile_key)
    if model.get("checkpoint_name") is None:
        return None  # まだ学習(チェックポイント保存)が一度も行われていない専用AIでは表示しない
    network, vocab = model["network"], model["vocab"]
    results: list[float | None] = []
    with torch.no_grad():
        for action in actions:
            sim_state = copy.deepcopy(state)
            try:
                apply_action(sim_state, CARD_DB, action)
            except IllegalActionError:
                results.append(None)
                continue
            if sim_state.is_game_over():
                if sim_state.winner is None or sim_state.winner == -1:
                    results.append(50.0)
                else:
                    results.append(100.0 if sim_state.winner == actor else 0.0)
                continue
            next_actor_here = next_actor(sim_state)
            next_actions = legal_actions(sim_state, CARD_DB)
            if not next_actions:
                results.append(None)
                continue
            next_player = sim_state.player(next_actor_here)
            state_features = encode_state(sim_state, CARD_DB, vocab, next_actor_here)
            action_features = [encode_action(a, next_player, CARD_DB, vocab, sim_state) for a in next_actions]
            _, value, _ = network(state_features, action_features, None)
            v = float(torch.tanh(value).item())
            if next_actor_here != actor:
                v = -v
            results.append(round((v + 1) / 2 * 100, 1))
    return results


_VISIT_COUNT_STORES: dict[str, VisitCountStore | None] = {}


def _visit_count_store(ai_key: str, create: bool = False) -> VisitCountStore | None:
    """デッキ別AI(agents.deck_ai.DECK_AIS)の実績ストアを遅延生成して使い回す。学習がまだ一度も
    走っていなくてファイルが無い場合、createなし(表示用)ならNone(SQLiteが空ファイルを勝手に
    作らないようにする)、createあり(AIの対局用)なら空のストアを作る。"""
    if ai_key not in _VISIT_COUNT_STORES or (create and _VISIT_COUNT_STORES[ai_key] is None):
        path = store_path(ai_key)
        _VISIT_COUNT_STORES[ai_key] = VisitCountStore(path) if (create or path.exists()) else None
    return _VISIT_COUNT_STORES[ai_key]


def _action_visit_counts_for_ai(
    state: GameState, actions: list[Action], ai_key: str, actor: int, with_human: bool = False
) -> list[tuple[int, ...]] | None:
    """デッキ別AI(ai_key)の学習履歴の中で、「actorから見える情報だけで同じ盤面+同じ選択」が
    何回選ばれ、そのうち何回その手を打った側が勝ったかを、actionsの各選択肢について返す
    (2026-09-24)。「同じ盤面」の定義は_replay_action_win_ratesが使っているのと同じ
    encode_state()の出力に基づく(rl_env.state_key参照)。学習がまだ一度も走っていない場合はNone。"""
    store = _visit_count_store(ai_key)
    if store is None:
        return None
    vocab = _policy_model("osaka_aichi_mirror")["vocab"]
    keys = [state_action_key(state, CARD_DB, vocab, actor, action) for action in actions]
    counts = store.get_many(keys)
    if not with_human:
        return [counts.get(k, (0, 0)) for k in keys]
    # 人間が打った手の数(重みを掛ける前の生の数)も添える。表示用。
    human = store.get_many_human(keys)
    return [(*counts.get(k, (0, 0)), human.get(k, (0, 0))[0]) for k in keys]


def _replay_action_visit_counts(
    state: GameState, actions: list[Action], deck_path: str | None, actor: int, with_human: bool = False
) -> list[tuple[int, ...]] | None:
    """リプレイ添削用: actorが使っているデッキ(deck_path)に対応するAI(フーディンAI/ドラパAI)の
    実績を、_action_visit_counts_for_aiで引く。AIはデッキごとに別なので、対応するAIが無いデッキはNone。"""
    ai_key = ai_key_for_deck(deck_path)
    if ai_key is None:
        return None
    return _action_visit_counts_for_ai(state, actions, ai_key, actor, with_human)


def _attach_visit_counts(entries: list[dict], counts: list[tuple[int, ...]] | None) -> None:
    if counts is None or len(counts) != len(entries):
        return
    for entry, (count, wins, *rest) in zip(entries, counts):
        entry["visit_count"] = count
        entry["past_wins"] = wins
        entry["past_human_moves"] = rest[0] if rest else 0  # うち人間が打った手の数(重み掛け前)
        # 実際にその盤面+選択が出た対局で、その手を打った側が最終的に勝った割合(%)。
        # ニューラルネットの推定(win_rate)とは別物の、実績そのもの。未出現ならNone。
        entry["past_win_rate"] = round(wins / count * 100, 1) if count else None


@app.route("/")
def index():
    return render_template("index.html")


# 対局セットアップの「レギュレーション」欄に並べる、専用AI対局の枠(2026-09-25、ユーザー要望)。
# 実体は既存のレギュレーション(real_regulation)+対象2デッキの絞り込みで、対局時はreal_regulationに読み替える。
# この枠から始めた対局は、対局後に保存を選べば専用の人間対局データフォルダにも記録される
# (_DEDICATED_PROFILE_HUMAN_GAMES_DIRS、api_save_human_records)。
_DEDICATED_SLOT_ID = "dedicated_alakazam_dragapult"
_AICHI_DRAGAPULT_MIRROR_SLOT_ID = "dedicated_aichi_dragapult_mirror"
_DEDICATED_SLOTS: dict[str, dict] = {
    _DEDICATED_SLOT_ID: {
        "category": "past",
        "real_regulation": "cl2026_ninjaspinner_era",
        "name": "フーディン vs ドラパルト(専用AI)",
        "deck_paths": [f"deck/sample_decks/{DECK_AIS[k]['deck_file']}" for k in ("osaka_alakazam", "aichi_dragapult")],
    },
    # 2026-09-25追加: ドラパルト(愛知優勝)同士のミラー戦専用枠。デッキは1つだけなので両陣営とも
    # 自動的に同じデッキになる(mirror=True、既存のmirrorレギュレーションと同じ仕組み)。
    # AI操作の座席は常にaichi_dragapult_mirror専用AI固定(fixed_ai、_new_game参照、選択肢を出さない)。
    _AICHI_DRAGAPULT_MIRROR_SLOT_ID: {
        "category": "past",
        "real_regulation": "cl2026_ninjaspinner_era",
        "name": "ドラパルト(愛知優勝)ミラー",
        "deck_paths": [f"deck/sample_decks/{DECK_AIS['aichi_dragapult']['deck_file']}"],
        "mirror": True,
        "fixed_ai": "aichi_dragapult_mirror",
    },
}


@app.route("/api/regulations")
def api_regulations():
    grouped = regulations_by_category()
    deck_counts: dict[str, int] = {}
    for deck in _list_decks():
        deck_counts[deck["regulation"]] = deck_counts.get(deck["regulation"], 0) + 1
    result = {
        category: [
            {
                "id": r.id,
                "name": r.name,
                "sets": list(r.sets),
                "description": r.description,
                "mirror": r.mirror,
                "deck_count": deck_counts.get(r.id, 0),
            }
            for r in regs
        ]
        for category, regs in grouped.items()
    }
    for slot_id, slot in _DEDICATED_SLOTS.items():
        real = get_regulation(slot["real_regulation"])
        result.setdefault(slot["category"], []).append(
            {
                "id": slot_id,
                "name": slot["name"],
                "sets": list(real.sets),
                "description": (
                    "フーディン(大阪優勝)とドラパルト(愛知優勝)だけで対局する枠です。ルールは"
                    f"「{real.name}」と同じ。対局後に保存を選ぶと、専用の人間対局データフォルダにも記録されます。"
                ),
                "mirror": slot.get("mirror", False),
                "deck_count": len(slot["deck_paths"]),
                "default_decks": slot["deck_paths"],
                # AI操作の座席で使うAIが固定されている場合、そのAIのid・表示名をフロントエンドへ渡す
                # (2026-10-02、ユーザー指摘「対局セットアップのどらぱAIがどっちのAIを指しているか
                # 分からない」: この専用枠は実際には常にfixed_aiを使うのに、フロントエンドの選択肢には
                # 無関係なAI(通常AI・ドラパAI等)しか出ず、実際に使われているAIが分からなかった)。
                "fixed_ai": slot.get("fixed_ai"),
                "fixed_ai_label": POLICY_MODELS[slot["fixed_ai"]]["label"] if slot.get("fixed_ai") else None,
            }
        )
    return jsonify(result)


@app.route("/api/decks")
def api_decks():
    regulation_id = request.args.get("regulation")
    slot = _DEDICATED_SLOTS.get(regulation_id or "")
    if slot is not None:
        by_path = {d["path"]: d for d in _list_decks(slot["real_regulation"])}
        return jsonify({"decks": [by_path[p] for p in slot["deck_paths"] if p in by_path]})
    return jsonify({"decks": _list_decks(regulation_id)})


_POLICY_MODEL_CHECKPOINT_DIRS = {
    "general": CHECKPOINT_DIR,
    "hij": DATA_DIR / "checkpoints_hij",
    "osaka_aichi_mirror": DATA_DIR / "checkpoints_osaka_aichi_mirror",
}


@app.route("/api/policy_models")
def api_policy_models():
    """対局セットアップ画面の「対戦相手のAI」選択肢一覧(通常AI/HIJ専用AI)。"""
    return jsonify(
        {
            "models": [
                {"id": key, "label": model["label"], "loaded_checkpoint": model["checkpoint_name"], "deck_file": None}
                for key, model in POLICY_MODELS.items()
                if key not in ("osaka_aichi_mirror", "aichi_dragapult_mirror")  # 旧・2デッキ共用の専用AI/
                # ミラー専用AI(専用枠で固定使用、ここでは選べない)。デッキ別AIに分けたので選択肢から外す
            ] + [
                {"id": key, "label": info["label"], "loaded_checkpoint": None, "deck_file": info["deck_file"]}
                for key, info in DECK_AIS.items()
            ]
        }
    )


@app.route("/api/model_status")
def api_model_status():
    variant = request.args.get("variant", "general")
    if variant in DECK_AIS:
        return jsonify({"loaded_checkpoint": "実績の勝率(学習で自動更新)", "latest_checkpoint": "実績の勝率(学習で自動更新)"})
    directory = _POLICY_MODEL_CHECKPOINT_DIRS.get(variant, CHECKPOINT_DIR)
    # key=mtime: ファイル名の文字列順ではなく更新日時順で「最新」を判定する。以前は文字列順の
    # ままだったため、手動移行で作った"policy_MIGRATED_..."(先頭が英字)が、本来もっと新しい
    # "policy_<unixtime>_iter<N>.pt"(先頭が数字、英字より文字コードが小さい)より常に「後ろ」に
    # 来てしまい、実際に学習が進んで新しいチェックポイントが増えても「既に最新版です」と
    # 誤判定し続けていた(2026-09-02発覚、_load_policy_networkの初回読み込みは元々mtime順で
    # 正しかったのに、reload_model/model_status側だけこの不具合が残っていた)。
    checkpoints = sorted(directory.glob("policy_*.pt"), key=lambda p: p.stat().st_mtime) if directory.exists() else []
    latest_name = checkpoints[-1].name if checkpoints else None
    model = _policy_model(variant)
    return jsonify({"loaded_checkpoint": model["checkpoint_name"], "latest_checkpoint": latest_name})


@app.route("/api/reload_model", methods=["POST"])
def api_reload_model():
    """学習中に保存された最新のチェックポイントを、対局アプリを再起動せずに読み込み直す。
    進行中の対局のGAME状態には影響しない(次にAIが手を選ぶときから新しいモデルが使われる)。
    variant("general"/"hij")を指定して、どちらのAIを更新するか選べる。"""
    body = request.get_json(silent=True) or {}
    variant = body.get("variant", "general")
    if variant in DECK_AIS:
        return jsonify({"reloaded": False, "loaded_checkpoint": "実績の勝率(学習で自動更新)"})
    if variant not in POLICY_MODELS:
        return jsonify({"error": f"不明なAIです: {variant}"}), 400
    directory = _POLICY_MODEL_CHECKPOINT_DIRS.get(variant, CHECKPOINT_DIR)
    # key=mtime: ファイル名の文字列順ではなく更新日時順で「最新」を判定する。以前は文字列順の
    # ままだったため、手動移行で作った"policy_MIGRATED_..."(先頭が英字)が、本来もっと新しい
    # "policy_<unixtime>_iter<N>.pt"(先頭が数字、英字より文字コードが小さい)より常に「後ろ」に
    # 来てしまい、実際に学習が進んで新しいチェックポイントが増えても「既に最新版です」と
    # 誤判定し続けていた(2026-09-02発覚、_load_policy_networkの初回読み込みは元々mtime順で
    # 正しかったのに、reload_model/model_status側だけこの不具合が残っていた)。
    checkpoints = sorted(directory.glob("policy_*.pt"), key=lambda p: p.stat().st_mtime) if directory.exists() else []
    if not checkpoints:
        return jsonify({"error": "チェックポイントがまだありません"}), 400
    latest = checkpoints[-1]
    current = POLICY_MODELS[variant]
    if latest.name == current["checkpoint_name"]:
        return jsonify({"reloaded": False, "loaded_checkpoint": current["checkpoint_name"]})
    checkpoint = torch.load(latest, map_location="cpu", weights_only=False)
    vocab = CardVocab.from_card_ids(checkpoint["vocab_card_ids"])
    network = PolicyValueNetwork(vocab_size=len(vocab))
    try:
        network.load_state_dict(checkpoint["model_state"], strict=False)  # strict=False: 上のロード処理と同じ理由
    except RuntimeError:
        return jsonify({"error": f"{latest.name} は現在のネットワーク構造と互換性がありません(学習し直す必要があります)"}), 400
    network.eval()
    POLICY_MODELS[variant] = {"label": current["label"], "network": network, "vocab": vocab, "checkpoint_name": latest.name}
    return jsonify({"reloaded": True, "loaded_checkpoint": latest.name})


@app.route("/api/deck_recipe")
def api_deck_recipe():
    path = request.args.get("path")
    if not path:
        return jsonify({"error": "pathが必要です"}), 400
    try:
        deck = load_deck(path, CARD_DB, validate=False)
    except Exception:
        return jsonify({"error": "デッキが見つかりません"}), 404

    def category_rank(card_id: str) -> int:
        card = CARD_DB.get(card_id)
        return card.display_category_rank if card else 99

    entries = [
        {
            "card_id": card_id,
            "name": card_name(CARD_DB, card_id),
            "image": (CARD_DB.get(card_id).image_small if CARD_DB.get(card_id) else ""),
            "count": count,
        }
        for card_id, count in deck.cards.items()
    ]
    entries.sort(key=lambda e: (category_rank(e["card_id"]), e["name"]))
    return jsonify({"name": deck.name, "card_count": sum(deck.cards.values()), "cards": entries})


@app.route("/api/new_game", methods=["POST"])
def api_new_game():
    body = request.get_json(silent=True) or {}
    deck_a_path = body.get("deck_a", DEFAULT_DECK_A)
    deck_b_path = body.get("deck_b", DEFAULT_DECK_B)
    seed = body.get("seed")
    regulation_id = body.get("regulation", DEFAULT_REGULATION)
    player0_agent = body.get("player0_agent", "human")
    player1_agent = body.get("player1_agent", "human")
    policy_variant_0 = body.get("policy_variant_0", "general")
    policy_variant_1 = body.get("policy_variant_1", "general")
    try:
        game_id = _new_game(
            deck_a_path, deck_b_path, seed, regulation_id,
            player0_agent, player1_agent, policy_variant_0, policy_variant_1,
            body.get("eval_variant_0"), body.get("eval_variant_1"),
        )
    except (ValueError, FileNotFoundError) as exc:
        return jsonify({"error": str(exc)}), 400
    game = GAMES[game_id]
    _auto_advance_ai(game)
    return _state_response(game, game_id)


_CHECKPOINT_ITER_RE = re.compile(r"iter(\d+)")


def _checkpoint_iteration(checkpoint_name: str | None) -> int | None:
    """チェックポイントのファイル名(例: "policy_1789726616_iter440.pt")から学習イテレーション回数
    (例: 440)を取り出す。命名規則に合わないもの(MIGRATED_pre_reset_...等)はNoneを返す。"""
    if not checkpoint_name:
        return None
    m = _CHECKPOINT_ITER_RE.search(checkpoint_name)
    return int(m.group(1)) if m else None


def _resolve_replay_path(replay_id: str | None) -> Path | None:
    """replay_idからdata/replays配下のファイルパスを安全に解決する(".."等でのパストラバーサル対策)。
    存在しない、またはREPLAY_DIRの外を指す場合はNoneを返す。"""
    if not replay_id:
        return None
    path = REPLAY_DIR / f"{replay_id}.pkl"
    if not path.exists() or path.parent.resolve() != REPLAY_DIR.resolve():
        return None
    return path


@app.route("/api/replays")
def api_replays():
    """data/replays/*.pkl(scripts/generate_self_play_replay.pyが生成)の一覧を、新しい順に返す。
    一覧表示用に軽量なメタ情報だけを返す(全手順のsteps自体は/api/load_replayで個別に読み込む)。"""
    entries = []
    for path in _list_replay_files():
        try:
            record = _load_replay_record(path)
        except Exception:
            continue  # 壊れた/世代の違うファイルはスキップする
        checkpoint = record.get("checkpoint")
        entries.append(
            {
                "id": path.stem,
                "matchup_label": _replay_matchup_label(record),
                "deck_a_label": record.get("deck_a_label", record.get("deck_a_path", "?")),
                "deck_b_label": record.get("deck_b_label", record.get("deck_b_path", "?")),
                "winner": record.get("winner"),
                "win_reason": record.get("win_reason"),
                "turn_count": record.get("turn_count"),
                "step_count": len(record.get("steps") or []),
                "checkpoint": checkpoint,
                "checkpoint_iter": _checkpoint_iteration(checkpoint),
                "total_games_trained": record.get("total_games_trained"),
                "generated_at": record.get("generated_at"),
            }
        )
    return jsonify({"replays": entries})


@app.route("/api/load_replay", methods=["POST"])
def api_load_replay():
    body = request.get_json(silent=True) or {}
    path = _resolve_replay_path(body.get("replay_id"))
    if path is None:
        return jsonify({"error": "リプレイが見つかりません"}), 404
    try:
        game_id = _new_replay_game(path)
    except Exception as exc:
        return jsonify({"error": f"リプレイの読み込みに失敗しました: {exc}"}), 400
    game = GAMES[game_id]
    return _state_response(game, game_id)


@app.route("/api/delete_replay", methods=["POST"])
def api_delete_replay():
    """保存済みのリプレイファイルをユーザーの操作で削除する(2026-09-19、ユーザー要望)。
    元データ(自己対戦のシミュレーション結果)であり待った(取り消し)の効かない削除だが、
    フロントエンド側で削除前に確認ダイアログを挟む前提。"""
    body = request.get_json(silent=True) or {}
    path = _resolve_replay_path(body.get("replay_id"))
    if path is None:
        return jsonify({"error": "リプレイが見つかりません"}), 404
    path.unlink()
    return jsonify({"ok": True})


@app.route("/api/set_step_mode", methods=["POST"])
def api_set_step_mode():
    """「AIの手をコマ送りで見る」設定のオン/オフ切り替え。ONにすると、以後このgame_idでは
    人間の行動後にAIの手をまとめて最後まで進めず、/api/ai_stepを都度呼ぶまで1手も進めなくなる
    (現在AIの番の途中であれば、そこで一旦停止する)。"""
    body = request.get_json(silent=True) or {}
    game = _get_game(body.get("game_id"))
    if game is None or game["state"] is None:
        return jsonify({"error": "対局が開始されていません"}), 400
    if game.get("mode") == "replay":
        # リプレイ再生モードは常に1手ずつの再生を強制する(OFFにすると_auto_advance_aiが記録済みの
        # 行動列を無視してライブ推論で最後まで進めてしまい、リプレイの意味が無くなるため)。
        return _state_response(game, body.get("game_id"))
    game["step_ai"] = bool(body.get("enabled"))
    return _state_response(game, body.get("game_id"))


@app.route("/api/ai_step", methods=["POST"])
def api_ai_step():
    """「コマ送り」モード中、AIの手を1つだけ進める。"""
    body = request.get_json(silent=True) or {}
    game = _get_game(body.get("game_id"))
    if game is None or game["state"] is None:
        return jsonify({"error": "対局が開始されていません"}), 400
    _advance_ai_one_step(game)
    return _state_response(game, body.get("game_id"))


def _record_human_moves_into_ai_stores(game: dict, records: list[dict]) -> None:
    """専用AIの対決を人間が対局して保存を選んだとき、人間が打った手(盤面+選択)と、その対局の勝敗を、
    打った席のデッキのAI(フーディンAI/ドラパAI)の勝率DBに書き足す(2026-09-25、ユーザー指示「人間の手を
    入れる。1手の価値はAIの5万回分」)。自己対戦の集計とは別の表に「人間が打った回数・勝った回数」として
    入れ、重み(training.visit_counts.load_human_weight)は読み出すときに掛ける。勝敗が付かなかった
    対局(引き分け・未決着)は自己対戦と同じく数えない。"""
    state = game["state"]
    winner = state.winner if state is not None and state.is_game_over() else None
    if winner not in (0, 1):
        return
    vocab = _policy_model("osaka_aichi_mirror")["vocab"]
    per_ai: dict[str, list[tuple[str, int]]] = {}
    for record in records:
        actor = record["actor"]
        ai_key = ai_key_for_deck(game.get("deck_a_path") if actor == 0 else game.get("deck_b_path"))
        if ai_key is None:
            continue
        action = record["legal_actions"][record["chosen_index"]]
        key = state_action_key(record["state"], CARD_DB, vocab, actor, action)
        per_ai.setdefault(ai_key, []).append((key, 1 if actor == winner else 0))
    for ai_key, outcomes in per_ai.items():
        _visit_count_store(ai_key, create=True).record_human_outcomes(outcomes)


@app.route("/api/save_human_records", methods=["POST"])
def api_save_human_records():
    """対局終了後、この対局の人間側の手をAIの模倣学習データとして保存するかどうかの選択。
    save=trueならdata/human_games/へ書き出し、falseなら破棄する。どちらの場合も
    game["records_decided"]を立て、以後同じ対局で再度promptを出さないようにする
    (「検証で適当に回した対局まで学習されると困る」という要望への対応)。"""
    body = request.get_json(silent=True) or {}
    game = _get_game(body.get("game_id"))
    if game is None or game["state"] is None:
        return jsonify({"error": "対局が開始されていません"}), 400
    save = bool(body.get("save"))
    records = game.get("human_records") or []
    if save and records:
        filename = f"{int(time.time())}_{uuid.uuid4().hex[:8]}.pkl"
        with open(HUMAN_GAMES_DIR / filename, "wb") as f:
            pickle.dump(records, f)
        # 専用AIの対決(フーディンAI対ドラパAイ等)なら、専用の人間対局データフォルダにも
        # 同じ記録を複製して書き出す(2026-09-24)。通常プールへの保存は変えず、追加で行う。
        dedicated_profile = _replay_dedicated_profile(
            game.get("deck_a_path", ""), game.get("deck_b_path", "")
        )
        dedicated_dir = _DEDICATED_PROFILE_HUMAN_GAMES_DIRS.get(dedicated_profile) if dedicated_profile else None
        if dedicated_dir is not None:
            dedicated_dir.mkdir(parents=True, exist_ok=True)
            with open(dedicated_dir / filename, "wb") as f:
                pickle.dump(records, f)
        # DECK_AIS(実績の勝率だけで動く表形式のAI)の勝率DBへの書き足しは、その仕組みを使う
        # osaka_aichi_mirror(フーディンAI対ドラパAI)だけに限る。aichi_dragapult_mirror等の
        # NNベースのAIは、上の専用フォルダへの複製(--human-data-dirで読む模倣学習)だけで十分で、
        # ここを通すとai_key_for_deck()が同じデッキ名から誤って古い表形式のドラパAI側へも
        # 書き込んでしまう(2026-10-02発覚、デッキファイルが同じであるため)。
        if dedicated_profile == "osaka_aichi_mirror":
            _record_human_moves_into_ai_stores(game, records)
    game["human_records"] = []
    game["records_decided"] = True
    return _state_response(game, body.get("game_id"))


@app.route("/api/report_bug", methods=["POST"])
def api_report_bug():
    """対局終了後、「バグ報告」ボタン: この対局の盤面ログ全文(state.log、対局開始から終了までの
    全イベント)と最終盤面(GameStateそのもの)、ユーザーが入力した「何がおかしかったか」の説明文を
    まとめて1件のフォルダとして保存する。模倣学習用のhuman_records(人間が選んだ手のみを記録)とは
    別物で、AIの手も含めた対局全体の記録なので、再現しにくいバグの調査に使う想定。api_save_human_records
    と同じくrecords_decidedを立て、以後同じ対局で再度promptを出さないようにする。"""
    body = request.get_json(silent=True) or {}
    game = _get_game(body.get("game_id"))
    if game is None or game["state"] is None:
        return jsonify({"error": "対局が開始されていません"}), 400
    description = (body.get("description") or "").strip()
    state = game["state"]

    folder_name = f"{int(time.time())}_{uuid.uuid4().hex[:8]}"
    report_dir = BUG_REPORTS_DIR / folder_name
    report_dir.mkdir(parents=True, exist_ok=True)
    (report_dir / "description.txt").write_text(description or "(説明なし)", encoding="utf-8")
    (report_dir / "log.txt").write_text("\n".join(state.log), encoding="utf-8")
    with open(report_dir / "state.pkl", "wb") as f:
        pickle.dump(state, f)

    game["human_records"] = []
    game["records_decided"] = True
    return _state_response(game, body.get("game_id"))


@app.route("/api/quit", methods=["POST"])
def api_quit():
    """「対局を終了する」ボタン: このタブの対局だけを終了する(他のタブ/他のgame_idの対局には
    影響しない。以前はサーバープロセス自体を落としていたが、game_id単位で状態を分離した今は
    そこまでする必要が無く、むしろ他のタブの対局まで巻き込んで終了させてしまうデメリットが大きい)。"""
    body = request.get_json(silent=True) or {}
    game_id = body.get("game_id")
    if game_id:
        GAMES.pop(game_id, None)
    return jsonify({"ok": True})


@app.route("/api/state")
def api_state():
    game_id = request.args.get("game_id")
    game = _get_game(game_id)
    if game is None or game["state"] is None:
        return jsonify(
            {"state": None, "actions": [], "player0_agent": "human", "player1_agent": "human", "ai_eval": None, "can_undo": False}
        )
    return _state_response(game, game_id)


@app.route("/api/card/<card_id>")
def api_card(card_id: str):
    detail = serialize_card_detail(CARD_DB, card_id)
    if detail is None:
        return jsonify({"error": "カードが見つかりません"}), 404
    return jsonify(detail)


@app.route("/api/action", methods=["POST"])
def api_action():
    body = request.get_json(silent=True) or {}
    game = _get_game(body.get("game_id"))
    if game is None or game["state"] is None:
        return jsonify({"error": "対局が開始されていません"}), 400
    if game.get("mode") == "replay":
        return jsonify({"error": "リプレイ再生中は操作できません"}), 400
    state = game["state"]

    index = body.get("index")
    with _human_seat_prohibitions_off(game):
        actions = legal_actions(state, CARD_DB)
        if index is None or not (0 <= index < len(actions)):
            return jsonify({"error": "不正な行動インデックスです"}), 400

        action = actions[index]
        _push_undo_snapshot(game)
        _record_human_decision(game, state, action)
        try:
            apply_action(state, CARD_DB, action)
        except IllegalActionError as exc:
            return jsonify({"error": str(exc)}), 400

    _observe_for_ai_seats(game, state)  # 人間側の手も(AI操作の座席があれば)その記憶に反映する
    _auto_advance_ai(game)
    return _state_response(game, body.get("game_id"))


@app.route("/api/resolve_search_choice", methods=["POST"])
def api_resolve_search_choice():
    body = request.get_json(silent=True) or {}
    game = _get_game(body.get("game_id"))
    if game is None or game["state"] is None:
        return jsonify({"error": "対局が開始されていません"}), 400
    if game.get("mode") == "replay":
        return jsonify({"error": "リプレイ再生中は操作できません"}), 400
    state = game["state"]

    selected = body.get("selected_indices", [])
    if not isinstance(selected, list) or not all(isinstance(i, int) for i in selected):
        return jsonify({"error": "不正な選択です"}), 400

    action = ResolveSearchChoice(tuple(sorted(set(selected))))
    with _human_seat_prohibitions_off(game):
        _push_undo_snapshot(game)
        _record_human_decision(game, state, action)
        try:
            apply_action(state, CARD_DB, action)
        except IllegalActionError as exc:
            return jsonify({"error": str(exc)}), 400

    _observe_for_ai_seats(game, state)  # 人間側の手も(AI操作の座席があれば)その記憶に反映する
    _auto_advance_ai(game)
    return _state_response(game, body.get("game_id"))


@app.route("/api/resolve_damage_distribution", methods=["POST"])
def api_resolve_damage_distribution():
    body = request.get_json(silent=True) or {}
    game = _get_game(body.get("game_id"))
    if game is None or game["state"] is None:
        return jsonify({"error": "対局が開始されていません"}), 400
    if game.get("mode") == "replay":
        return jsonify({"error": "リプレイ再生中は操作できません"}), 400
    state = game["state"]

    counts = body.get("counts", [])
    if not isinstance(counts, list) or not all(isinstance(c, int) for c in counts):
        return jsonify({"error": "不正な配分です"}), 400

    action = ResolveDamageDistribution(tuple(counts))
    with _human_seat_prohibitions_off(game):
        _push_undo_snapshot(game)
        _record_human_decision(game, state, action)
        try:
            apply_action(state, CARD_DB, action)
        except IllegalActionError as exc:
            return jsonify({"error": str(exc)}), 400

    _observe_for_ai_seats(game, state)  # 人間側の手も(AI操作の座席があれば)その記憶に反映する
    _auto_advance_ai(game)
    return _state_response(game, body.get("game_id"))


@app.route("/api/undo", methods=["POST"])
def api_undo():
    """直前の人間の操作(その後のAIの自動応答も含む)を丸ごと取り消す(2026-09-02、ユーザー要望
    「普通のポケカと違うのでミスが起きやすい。学習データに問題が出ないように一手戻せるように
    してほしい」)。取り消した分の模倣学習用記録(human_records)もあわせて切り詰められる。"""
    body = request.get_json(silent=True) or {}
    game = _get_game(body.get("game_id"))
    if game is None or game["state"] is None:
        return jsonify({"error": "対局が開始されていません"}), 400
    if not _pop_undo_snapshot(game):
        return jsonify({"error": "これ以上は戻せません"}), 400
    return _state_response(game, body.get("game_id"))


def _sort_hand_and_discard(state) -> None:
    """手札・トラッシュの表示順を揃える(ポケモン→サポート→グッズ→どうぐ→スタジアム→エネルギー)。

    表示とアクションのhand_indexは同じ並びを参照するため、シリアライズ直前に実体を並べ替える。

    ただし、pending_search_choiceのzoneが"hand"/"discard"の間は、その対象プレイヤーのその
    zoneだけは並べ替えない。PendingSearchChoice.source_indicesは生成された時点でのリスト内の
    位置(popで取り出すための素のインデックス)を保持しており、確定処理(ResolveSearchChoice)まで
    その並びが変わらない前提になっている。ここで並べ替えてしまうと、次のレスポンス生成時点で
    source_indicesが指す位置と実際のカードがずれてしまい、無関係なカード(使用したトレーナーズ
    自身が紛れ込む等)が選ばれてしまう(エネルギー回収でトラッシュのエネルギーの代わりに
    使用したカード自身が手札に戻ってしまうバグ等の原因だった)。
    """
    choice = state.pending_search_choice
    locked_player = choice.player_index if choice is not None and choice.zone in ("hand", "discard") else None
    locked_zone = choice.zone if locked_player is not None else None
    for i, player in enumerate(state.players):
        if not (i == locked_player and locked_zone == "hand"):
            player.hand.sort(key=lambda cid: (CARD_DB.get(cid).display_category_rank if CARD_DB.get(cid) else 99))
        if not (i == locked_player and locked_zone == "discard"):
            player.discard.sort(key=lambda cid: (CARD_DB.get(cid).display_category_rank if CARD_DB.get(cid) else 99))


def _state_response(game: dict, game_id: str | None):
    with _human_seat_prohibitions_off(game):
        return _state_response_impl(game, game_id)


def _state_response_impl(game: dict, game_id: str | None):
    state = game["state"]
    if game.get("mode") != "replay":
        # リプレイ再生モード(2026-09-18)では並べ替えない: _sort_hand_and_discardは表示上見やすくする
        # ためにhand/discardを実体ごと並べ替えるが(_advance_replay_one_stepが適用する記録済みの
        # hand_index等は、並べ替えが一切無かった生成時(scripts/generate_self_play_replay.py)の
        # 挿入順のままを前提にしている。ここで並べ替えてしまうと以降の記録済みインデックスが
        # 別のカードを指すようになり、「選択できる枚数の範囲外です」等で再生が止まってしまう
        # (実際に発生したバグ、2026-09-18)。ライブ対局(人間操作/観戦)は並べ替えが無いと
        # 画面に表示されているカードの見た目の位置とhand_indexがズレるため、従来通り並べ替える。
        _sort_hand_and_discard(state)
    game_over = state is None or state.is_game_over()
    current_actor = None if game_over else next_actor(state)
    is_replay = game.get("mode") == "replay"
    # claude_play_session.py が書き出したリプレイは、Claude自身の手番だけ
    # user_prohibitions_disabled()下で合法手を記録している(禁止行動を無視してよい指示のため)。
    # ここで素のlegal_actions()を呼ぶと記録時より選択肢が減り、_replay_step_evalのaction_scores
    # と長さが合わずAI評価値が表示されなくなる(2026-09-22、ユーザー報告により発覚)。
    # 記録時と同じ条件を再現するため、該当手番だけ同じコンテキストで合法手を計算し直す。
    claude_turn_in_replay = (
        is_replay
        and current_actor is not None
        and game.get("replay_source") == "claude_play_session"
        and current_actor in game.get("claude_seats", ())
    )
    if claude_turn_in_replay:
        with user_prohibitions_disabled():
            actions = serialize_actions(state, CARD_DB)
            raw_actions = legal_actions(state, CARD_DB)
    else:
        actions = serialize_actions(state, CARD_DB)
        raw_actions = legal_actions(state, CARD_DB)
    replay_finished = is_replay and game.get("replay_cursor", 0) >= len(game.get("replay_steps") or [])
    if is_replay:
        # リプレイ再生モードでは、今のチェックポイントで評価値を計算し直すと(学習が進んで
        # 変わっている可能性があるため)誤解を招くので、記録時点でそのAIが実際の判断に使った
        # 評価値をそのまま見せる(2026-09-19、ユーザー要望「その当時のAI評価値も見たい」)。
        # replay_steps[cursor]は「まだ適用していない、次にコマ送りする行動」で、これから
        # 表示するactions(=今の局面の合法手)はその行動を選んだ時点の合法手と一致するはず
        # (_sort_hand_and_discardをスキップしているため、並び順もズレない)。
        steps = game.get("replay_steps") or []
        cursor = game.get("replay_cursor", 0)
        if cursor < len(steps):
            ai_eval, action_scores = _replay_step_eval(steps[cursor])
        else:
            ai_eval, action_scores = None, None
    else:
        eval_variant = (
            _eval_variant_for_actor(game, current_actor) if current_actor is not None else game.get("policy_variant_1", "general")
        )
        eval_hidden_state = _eval_hidden_state_for_actor(game, current_actor) if current_actor is not None else None
        ai_eval, action_scores = _evaluate_position(state, eval_variant, eval_hidden_state)
    if action_scores is not None and len(action_scores) == len(actions):
        for entry, score in zip(actions, action_scores):
            entry["ai_score"] = score
    # 選択肢ごとの推定勝率(2026-09-22、ユーザー要望): リプレイ添削中、専用AI(POLICY_MODELS)が
    # 存在するデッキ対決かつ、選択肢が2つ以上ある本当の決断点でだけ表示する(強制手・1択の局面
    # では出さない)。
    # ニューラルネットの「推定勝率」(win_rate)は、実績が0回の局面でも値が出てしまい根拠が無いため、
    # 対局・リプレイのどちらでも表示しない(2026-09-25、ユーザー指摘「過去の実績が0なのに推定勝率が
    # 出ているのは何なのか」)。表示する勝率は下の「過去の勝率」(実際にその盤面+選択が出た対局の結果)だけ。
    decision_point = current_actor is not None and len(actions) > 1 and len(raw_actions) == len(actions)
    # 選択肢ごとの出現回数・過去の勝率(2026-09-24、ユーザー要望): 選択肢が2つ以上ある本当の決断点でだけ
    # 表示する。リプレイは、actorのデッキに対応するAIの実績を見る。ライブ対局は、その手番の評価役に
    # 選ばれているAI(_eval_variant_for_actor)がデッキ別AIならその実績を見る(人間操作の座席では、
    # セットアップ画面で「評価値を表示するAI」として選んだAI)。
    if decision_point:
        if is_replay:
            if game.get("replay_win_rate_profile"):
                actor_deck_path = game.get("deck_a_path") if current_actor == 0 else game.get("deck_b_path")
                _attach_visit_counts(actions, _replay_action_visit_counts(state, raw_actions, actor_deck_path, current_actor, True))
        else:
            live_variant = _eval_variant_for_actor(game, current_actor)
            if live_variant in DECK_AIS:
                _attach_visit_counts(actions, _action_visit_counts_for_ai(state, raw_actions, live_variant, current_actor, True))
    # コマ送りモード中、まだAI操作の座席の番の途中(=フロントエンドが/api/ai_stepを呼べば1手進む)かどうか。
    # リプレイ再生モードでは、記録済みの行動を全て再生し終えていたら(replay_finished)もう進められない。
    awaiting_ai_step = bool(
        game.get("step_ai") and not game_over and current_actor is not None and _seat_is_policy(game, current_actor)
        and not replay_finished
    )
    return jsonify(
        {
            "game_id": game_id,
            "state": serialize_state(state, CARD_DB),
            "actions": actions,
            "player0_agent": game.get("player0_agent", "human"),
            "player1_agent": game.get("player1_agent", "human"),
            "ai_eval": ai_eval,
            "step_ai": bool(game.get("step_ai")),
            "awaiting_ai_step": awaiting_ai_step,
            "pending_record_decision": _pending_record_decision(game, state),
            "records_auto_discarded": bool(game.get("records_auto_discarded")),
            "policy_variant_0": game.get("policy_variant_0", "general"),
            "policy_variant_1": game.get("policy_variant_1", "general"),
            "last_ai_action_description": game.get("last_ai_action_description"),
            "last_ai_action_was_lethal": bool(game.get("last_ai_action_was_lethal")),
            "last_ai_action_descriptions": game.get("last_ai_action_descriptions", []),
            "can_undo": bool(game.get("undo_stack")),
            "mode": game.get("mode", "live"),
            "replay_meta": game.get("replay_meta"),
            "replay_progress": (
                {"cursor": game.get("replay_cursor", 0), "total": len(game.get("replay_steps") or [])}
                if is_replay
                else None
            ),
        }
    )


if __name__ == "__main__":
    app.run(debug=True, port=5050)
