"""スマホ版(Pyodide)用の Flask 互換スタブ。web/app.py をそのまま読み込めるようにするための最小限の実装。

ネットワークは使わない。pwa_server.handle() が、ブラウザの fetch("/api/...") を受け取って、ここに登録された
ルート関数を直接呼ぶ。
"""

from __future__ import annotations

import re


class _Request:
    """いま処理中のリクエスト(1つずつ順に処理するので、グローバルに1つだけ持てばよい)。"""

    def __init__(self) -> None:
        self.args: dict[str, str] = {}
        self._json = None
        self.method = "GET"

    def get_json(self, silent: bool = False):
        return self._json


request = _Request()


class _Response:
    def __init__(self, payload, status: int = 200) -> None:
        self.payload = payload
        self.status_code = status


def jsonify(*args, **kwargs):
    return _Response(args[0] if args else kwargs)


def render_template(name: str, **context) -> str:
    raise RuntimeError("スマホ版ではテンプレートを使いません(index.htmlは静的ファイルとして配布)")


def _rule_to_regex(rule: str) -> re.Pattern:
    parts = re.split(r"<(?:[a-z]+:)?\w+>", rule)
    return re.compile("^" + "([^/]+)".join(re.escape(p) for p in parts) + "$")


class Flask:
    def __init__(self, name: str, *args, **kwargs) -> None:
        self.config: dict = {}
        self.routes: list[tuple[re.Pattern, set[str], object]] = []

    def route(self, rule: str, methods=None):
        allowed = set(methods or ["GET"])

        def decorator(func):
            self.routes.append((_rule_to_regex(rule), allowed, func))
            return func

        return decorator

    def run(self, *args, **kwargs) -> None:
        raise RuntimeError("スマホ版ではサーバーを起動しません")
