"""スマホ版用のスタブ(盤面ごとの出現回数ストアはPCの学習専用)。"""


class VisitCountStore:
    def __init__(self, *args, **kwargs) -> None:
        raise RuntimeError("出現回数ストアはスマホ版では使えません")
