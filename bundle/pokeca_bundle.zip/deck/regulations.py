"""レギュレーション(対局のルールセット + 使用可能パック範囲)のカタログ。

- 「ノーマル」= 現行のスタンダード相当(時代・パックで使えるカードが変わる)。
- 「過去」= 過去の実在した公式スタンダードレギュレーション。
- 「エクストラ」= 実在するエクストラレギュレーション(公式の特別フォーマット)。
- 「特殊」= がブレンミラーのような、公式レギュレーションではない自作の特殊ルール。

新しい時代のノーマル/過去レギュレーションを増やすときは、ここに1エントリ追加し、
対応するデッキYAMLの `regulation:` フィールドをそのidに合わせるだけでよい。
"""

from __future__ import annotations

from dataclasses import dataclass, field

from engine.ruleset import (
    ADV_JP_EARLY_RULESET, ADV_JP_RULESET, BW_RULESET, DEFAULT_RULESET, DP_JP_RULESET, PRE_SWSH_RULESET, Ruleset,
    WCS2010_RULESET,
)


@dataclass(frozen=True)
class Regulation:
    id: str
    name: str
    category: str  # "normal" | "past" | "extra" | "special"
    ruleset: Ruleset
    sets: tuple[str, ...] = field(default_factory=tuple)  # 表示用: 使用可能パック範囲
    description: str = ""
    mirror: bool = False  # True なら両プレイヤーが同じデッキを使う(ミラー戦専用)
    set_start_date: str | None = None  # ISO形式(YYYY-MM-DD)。このレギュレーションで使える最古のパックの発売日
    # (時代別レギュレーションなど、発売日の範囲[set_start_date, set_cutoff_date]でカードプールを決めるもの用。
    # Noneなら下限なし)。日本版の発売日(data/jp_card_index.json、scripts/build_jp_card_index.py)で判定する。
    set_cutoff_date: str | None = None  # ISO形式(YYYY-MM-DD)。このレギュレーションで使える最新パックの
    # 発売日(=上のsetsで説明している「時点」の実際の日付)。standard_current等、現行の実カードデータ
    # (legalities.standard)で判定すべきものはNoneのままにする。デッキ構築サイトが、組んだデッキの
    # 最新カードの発売日とここを比較して「使えるレギュレーション」を機械的に判定するために使う。


REGULATIONS: tuple[Regulation, ...] = (
    Regulation(
        id="standard_current",
        name="現行スタンダード",
        category="normal",
        ruleset=DEFAULT_RULESET,
        sets=(
            "Scarlet & Violet 〜 Mega Evolution(レギュレーションマークH/I/J)",
            "日本国内では2024年1月26日(「ワイルドフォース/サイバージャッジ」でHマーク開始)〜現在(2026年8月)に発売されたカードに相当",
        ),
        description="2026年8月時点のスタンダードレギュレーション(レギュレーションマークH以降)で組んだデッキ。",
    ),
    Regulation(
        id="pjcs2026",
        name="PJCS2026デッキ環境",
        category="past",
        ruleset=DEFAULT_RULESET,
        set_cutoff_date="2026-06-07",
        sets=(
            "Scarlet & Violet 〜 MEGA「アビスアイ」(2026年6月6-7日時点で発売済みのパックのみ)",
            "日本国内では2024年1月26日(「ワイルドフォース/サイバージャッジ」でHマーク開始、"
            "2026年1月23日にGマーク使用不可・H/I/Jのみに変更)〜2026年5月22日(拡張パック「アビスアイ」)"
            "に発売されたカードに相当",
        ),
        description=(
            "2026年6月6-7日に開催されたポケモンジャパンチャンピオンシップス2026(PJCS2026)"
            "カードゲーム部門・マスターリーグの上位デッキを再現。優勝オオタケトシユキ選手(メガガルーラボックス)、"
            "準優勝フカセカブ選手(ばけがくれ)、ベスト4バ!選手(メガフシギバナ)・こび選手(ドラパルト)、"
            "ベスト8けー選手(ドラパルト/バシャーモ)・R選手(ばけがくれ)・JoeH選手(ヤドキング)を収録。"
            "ベスト8の残り1名は公式結果ページで非公開設定のため、デッキ内容は不明(捏造せず7デッキのみ収録)。"
        ),
    ),
    Regulation(
        id="cl2026_ninjaspinner_era",
        name="CL2026デッキ環境(ニンジャスピナー期・大阪/愛知5月)",
        category="past",
        ruleset=DEFAULT_RULESET,
        set_cutoff_date="2026-03-13",
        sets=(
            "Scarlet & Violet 〜 MEGA「ニンジャスピナー」(2026年3月13日時点で発売済みのパックのみ)",
            "日本国内では2024年1月26日(「ワイルドフォース/サイバージャッジ」でHマーク開始、"
            "2026年1月23日にGマーク使用不可・H/I/Jのみに変更)〜2026年3月13日(拡張パック「ニンジャスピナー」)"
            "に発売されたカードに相当。次弾「アビスアイ」は2026年5月22日発売のため、"
            "この間に開催された大会(大阪3/28-29・愛知5月9-10)はいずれも同一のカードプールで争われた",
        ),
        description=(
            "同一カードプール(〜ニンジャスピナー)で開催された2大会、チャンピオンズリーグ2026大阪"
            "(2026年3月28-29日)とチャンピオンズリーグ2026愛知5月(2026年5月9-10日)の上位デッキをまとめて収録。"
            "【大阪】優勝アカギタツキ選手(フーディン/ノココッチ)、準優勝アマノトシキ選手(マリィのオーロンゲex)、"
            "ベスト4タケウチヤスマサ選手(イワパレス)・トモキ選手(ロケット団のミュウツーex)、"
            "ベスト8はmako_rog選手(ボムゲッコウガ)・ざわ選手(フーディン/ノココッチ)・"
            "サトウ選手(イイネイヌ/ガメノデス)・ヒロ選手(ドラパルトex/バシャーモex)。"
            "【愛知5月】優勝シオカワセイノスケ選手(ドラパルトex&ヨノワール)、準優勝ヒカル選手(Nのゾロアークex)、"
            "ベスト4まそ選手(カミツオロチex)・Sh0-1選手(ドラパルト/バシャーモ)、"
            "ベスト8はライ選手(ドラパルト/ノココッチ)・ねりす選手(Nのゾロアーク)・n選手(ドラパルトex&ヨノワール)・"
            "C4nC3r選手(ガルーラボックス)。計16デッキを収録。"
        ),
    ),
    Regulation(
        id="cl2026_fukuoka",
        name="CL2026福岡デッキ環境",
        category="past",
        ruleset=DEFAULT_RULESET,
        set_cutoff_date="2026-01-23",
        sets=(
            "Scarlet & Violet 〜 MEGA「ムニキスゼロ」(2026年2月21-22日時点で発売済みのパックのみ)",
            "日本国内では2024年1月26日(「ワイルドフォース/サイバージャッジ」でHマーク開始、"
            "2026年1月23日にGマーク使用不可・H/I/Jのみに変更)〜2026年1月23日(拡張パック「ムニキスゼロ」)"
            "に発売されたカードに相当",
        ),
        description=(
            "2026年2月21-22日に開催されたチャンピオンズリーグ2026福岡の上位デッキを再現。"
            "優勝ノガミダタカト選手(メガガルーラボックス)、準優勝わたよ選手(オリーヴァ)、"
            "ベスト4藤本海右選手(ガルーラドラパルト)・ウラタアキヒロ選手(タケルライコ)、"
            "ベスト8はn選手(イワパレス)・あさき選手(ボムドラパルト)・あんぱん選手(ドラパルト)・"
            "ジャンタルマンタル選手(ドンカラス)の計8デッキを収録。"
        ),
    ),
    Regulation(
        id="standard_2025_worlds",
        name="2025年 世界大会環境",
        category="past",
        ruleset=DEFAULT_RULESET,
        set_cutoff_date="2025-08-17",
        sets=(
            "Scarlet & Violet 〜 Shrouded Fable(2025年8月15-17日時点で発売済みのパックのみ)",
            "日本国内では2023年1月20日(「スカーレット&バイオレット」でGマーク開始)〜2025年8月時点発売済みパック"
            "(2025年1月24日にIマーク開始済み、Jマークはまだ無い)に相当",
        ),
        description=(
            "2025年8月15-17日、アナハイムで開催された世界大会マスターズ部門優勝、Riley McKay選手のガーデヴォールデッキ、"
            "2位Justin Newdorf選手のドラパルト/デスバーンデッキ、3位Shizuki Nakagawa選手のらいげきしぶ/オーガポンデッキ、"
            "4位Junya Tanaka選手のリザードンex/ポッポサンダーexデッキを再現。"
            "※北米(英語版)の大会・カードデータをもとに構築しており、日本語版のパック発売日とは厳密には一致しない場合がある。"
        ),
    ),
    Regulation(
        id="standard_2024_worlds",
        name="2024年 世界大会環境",
        category="past",
        ruleset=DEFAULT_RULESET,
        set_cutoff_date="2024-08-18",
        sets=(
            "Scarlet & Violet 〜 Twilight Masquerade(2024年8月15-18日時点で発売済みのパックのみ)",
            "日本国内では2023年1月20日(「スカーレット&バイオレット」でGマーク開始)〜2024年8月時点発売済みパック"
            "(2024年1月26日にHマーク開始済み)に相当",
        ),
        description=(
            "2024年8月15-18日、ハワイ・ホノルルで開催された世界大会マスターズ部門優勝、"
            "Fernando Cifuentes選手のアイアンバルジェットexデッキを再現。"
            "ロストゾーン(ロストシティ/ロストバキューム)を新たにエンジンへ実装。"
            "※北米(英語版)の大会・カードデータをもとに構築しており、日本語版のパック発売日とは厳密には一致しない場合がある。"
        ),
    ),
    Regulation(
        id="standard_2023_worlds",
        name="2023年 世界大会環境",
        category="past",
        ruleset=DEFAULT_RULESET,
        set_cutoff_date="2023-08-13",
        sets=(
            "Sword & Shield 〜 Scarlet & Violet(2023年8月11-13日時点で発売済みのパックのみ)",
            "日本国内では2022年1月14日(Fマーク開始)〜2023年8月時点発売済みパック"
            "(2023年1月20日にGマーク開始済み)に相当",
        ),
        description=(
            "2023年8月11-13日、神奈川・横浜で開催された世界大会マスターズ部門優勝、Vance Kelley選手の"
            "フュージョンミュウ(ミュウVMAX/ゲノセクトV)デッキ、2位Tord Reklev選手のガーデヴォールデッキ、"
            "3位Michael Pramawat選手のギラティナLZボックス、4位Azul Garcia Griego選手のフュージョンミュウを再現。"
            "※北米(英語版)の大会・カードデータをもとに構築しており、日本語版のパック発売日とは厳密には一致しない場合がある。"
        ),
    ),
    Regulation(
        id="standard_2022_worlds",
        name="2022年 世界大会環境",
        category="past",
        ruleset=DEFAULT_RULESET,
        set_cutoff_date="2022-08-21",
        sets=(
            "Sword & Shield 〜 Brilliant Stars/Celebrations(2022年8月18-21日時点で発売済みのパックのみ)",
            "日本国内では2021年1月22日(Eマーク開始)〜2022年8月時点発売済みパック"
            "(2022年1月14日にFマーク開始済み)に相当",
        ),
        description=(
            "2022年8月18-21日、イギリス・ロンドンで開催された世界大会マスターズ部門優勝、"
            "Ondřej Škubal選手のアルセウス/そらとぶピカチュウデッキを再現(2位Daichi Shimada選手・"
            "3位Ryota Ishiyama選手も同アーキタイプ)。"
            "※北米(英語版)の大会・カードデータをもとに構築しており、日本語版のパック発売日とは厳密には一致しない場合がある。"
        ),
    ),
    Regulation(
        id="standard_2021_players_cup",
        name="2021年 Players Cup III環境",
        category="past",
        ruleset=DEFAULT_RULESET,
        set_cutoff_date="2021-04-23",
        sets=(
            "Sun & Moon 〜 Battle Styles(2021年4月23日時点で発売済みのパックのみ)",
            "レギュレーションマークE(「一撃マスター/連撃マスター」2021年1月22日〜)適用開始直後の環境に相当",
        ),
        description=(
            "2021年4月23日、オンライン開催されたPokémon Players Cup III Global Finals TCG部門優勝、"
            "Azul Garcia Griego選手のれんげきウーラオスVMAXデッキを再現。"
            "WCS(世界大会)ではなくPlay! Pokémonのオンライン大会だが、当時COVID-19影響で2020・2021年の"
            "世界大会が中止されたため、代替として優勝デッキを採用した。"
            "※北米(英語版)の大会・カードデータをもとに構築しており、日本語版のパック発売日とは厳密には一致しない場合がある。"
        ),
    ),
    Regulation(
        id="standard_2020_players_cup",
        name="2020年 Players Cup環境",
        category="past",
        ruleset=DEFAULT_RULESET,
        set_cutoff_date="2020-08-30",
        sets=(
            "Sun & Moon 〜 Rebel Clash(2020年8月29-30日時点で発売済みのパックのみ)",
            "レギュレーションマークD(「ソード&シールド」2019年11月29日〜)適用開始直後の環境に相当",
        ),
        description=(
            "2020年8月29-30日、オンライン開催されたPokémon Players Cup Finals TCG部門優勝、"
            "Natalie Millar選手のザシアンV/ルカリオ&メルメタルGXデッキ「The Safe」を再現"
            "(決勝の相手Matthew Burris選手も同一レシピのミラー戦だった)。"
            "WCS(世界大会)ではなくPlay! Pokémonのオンライン大会だが、当時COVID-19影響で2020・2021年の"
            "世界大会が中止されたため、代替として優勝デッキを採用した。"
            "※北米(英語版)の大会・カードデータをもとに構築しており、日本語版のパック発売日とは厳密には一致しない場合がある。"
        ),
    ),
    Regulation(
        id="standard_2019_worlds",
        name="2019年 世界大会環境",
        category="past",
        ruleset=PRE_SWSH_RULESET,
        set_cutoff_date="2019-08-18",
        sets=(
            "Sun & Moon 〜 Unified Minds(2019年8月15-18日時点で発売済みのパックのみ)",
            "レギュレーションマーク制度はまだ導入前(2019年11月のソード&シールドから開始)のため、"
            "当時の実際のスタンダードは「サン&ムーン」ブロック全体(2017年2月〜)が使用可能だった",
        ),
        description=(
            "2019年8月15-18日、アメリカ・ワシントンD.C.で開催された世界大会マスターズ部門優勝、"
            "Henry Brand選手のミュウツー&ミュウGXデッキ、2位Shintaro Ito選手のズガドーンGX/アーゴヨンデッキ、"
            "3位Blaine Hill選手のボルケニオン/レシラム&リザードンGXデッキ、4位Tord Reklev選手の"
            "レシラム&リザードンGXファイアーボックスデッキを再現。GXワザ(1ゲームに1回限りの特殊ワザ)は"
            "VSTARパワーと同様の理由で未対応。"
            "※北米(英語版)の大会・カードデータをもとに構築しており、日本語版のパック発売日とは厳密には一致しない場合がある。"
        ),
    ),
    Regulation(
        id="standard_2018_worlds",
        name="2018年 世界大会環境",
        category="past",
        ruleset=PRE_SWSH_RULESET,
        set_cutoff_date="2018-08-19",
        sets=(
            "XY—BREAKthrough 〜 Sun & Moon—Celestial Storm(2018年8月17-19日時点で発売済みのパックのみ)",
            "レギュレーションマーク制度導入前のため、当時の実際のスタンダードは「XY—BREAKthrough」"
            "(2015年11月発売)以降のブロックが使用可能だった",
        ),
        description=(
            "2018年8月17-19日、アメリカ・テネシー州ナッシュビルで開催された世界大会マスターズ部門のTop4を再現: "
            "優勝Robin Schulz選手(ゾロアーク/ダストダス)、2位Jeff Kolenc選手(カラマネロ/マーシャドーGX)、"
            "3位Klive Aw Jun Jie選手(ジガルデGX/ルガルガンGX)、4位Pedro Eugenio Torres選手(レックウザGX)。"
            "GXワザ(1ゲームに1回限りの特殊ワザ)はVSTARパワーと同様の理由で未対応。"
            "※北米(英語版)の大会・カードデータをもとに構築しており、日本語版のパック発売日とは厳密には一致しない場合がある。"
        ),
    ),
    Regulation(
        id="standard_2017_worlds",
        name="2017年 世界大会環境",
        category="past",
        ruleset=PRE_SWSH_RULESET,
        set_cutoff_date="2017-08-20",
        sets=(
            "XY—Ancient Origins 〜 Sun & Moon—Burning Shadows(2017年8月18-20日時点で発売済みのパックのみ)",
            "レギュレーションマーク制度導入前のため、当時の実際のスタンダードは「XY—Roaring Skies」"
            "(2015年5月発売)以降のブロックが使用可能だった",
        ),
        description=(
            "2017年8月18-20日、アメリカ・カリフォルニア州アナハイムで開催された世界大会マスターズ部門のTop4を再現: "
            "優勝Diego Cassiraga選手(サーナイトGX)、2位Naoto Suzuki選手(グソクムシャGX/ダストダス)、"
            "3位Xander Pero選手(エーフィGX/ダストダス)、4位Sho Sasaki選手(グソクムシャGX/ダストダス、"
            "ジジーロンGX/マギアナEXタッチ)。GXワザ(1ゲームに1回限りの特殊ワザ)はVSTARパワーと同様の理由で未対応。"
            "※北米(英語版)の大会・カードデータをもとに構築しており、日本語版のパック発売日とは厳密には一致しない場合がある。"
        ),
    ),
    Regulation(
        id="standard_2016_worlds",
        name="2016年 世界大会環境",
        category="past",
        ruleset=PRE_SWSH_RULESET,
        set_cutoff_date="2016-08-21",
        sets=(
            "XY 〜 XY—Fates Collide(2016年8月19-21日時点で発売済みのパックのみ)",
            "レギュレーションマーク制度導入前のため、当時の実際のスタンダードは「XY」基本パック"
            "(2014年2月発売)以降のブロックが使用可能だった",
        ),
        description=(
            "2016年8月19-21日、アメリカ・カリフォルニア州サンフランシスコで開催された世界大会マスターズ部門のTop4を再現: "
            "優勝Shintaro Ito選手(メガタブンネEX)、2位Cody Walinski選手(ゲッコウガBREAK/ファイアロー)、"
            "3位Samuel Hough選手(ラフレシアトゥールボックス)、4位Ross Cawthon選手(ビークイン/イベルタル)。"
            "メガシンカのルール(進化した番はそこで終了する)はv1簡略版として未対応。"
            "※北米(英語版)の大会・カードデータをもとに構築しており、日本語版のパック発売日とは厳密には一致しない場合がある。"
        ),
    ),
    Regulation(
        id="standard_2015_worlds",
        name="2015年 世界大会環境",
        category="past",
        ruleset=PRE_SWSH_RULESET,
        set_cutoff_date="2015-08-16",
        sets=(
            "Black & White—Plasma Blast 〜 XY—Roaring Skies(2015年8月14-16日時点で発売済みのパックのみ)",
            "レギュレーションマーク制度導入前のため、当時の実際のスタンダードは「Black & White—Plasma Storm」"
            "(2013年11月発売)以降のブロックが使用可能だった",
        ),
        description=(
            "2015年8月14-16日、アメリカ・マサチューセッツ州ボストンで開催された世界大会マスターズ部門のTop4を再現: "
            "優勝Jacob Van Wagner選手(カメックス/ケルディオEX「HonorStoise」)、"
            "2位Mees Brenninkmeijer選手(ガマゲロゲEX/クロバット)、"
            "3位Igor Costa選手(ガマゲロゲEX/クロバット)、"
            "4位Merlin Quittek選手(ナイトマーチ)。"
            "実際の大会デッキリスト(Limitless TCG等)に基づいて構築しているため、"
            "一部カードは上記の理論上のローテーション期間より古い印刷(例: N(bw5-96、Dark Explorers収録)"
            "のような当時のプレイヤーが実際に使用した印)を含む場合がある。"
            "ミュウEXの特性「Versatile」(場のポケモンのワザを使える)は、GXワザ/VSTARパワー自体は"
            "借りられないv1簡略版。「Replace」(エネルギー移動)は複数体への自由分配ではなく1体への"
            "全移動に簡略化。"
            "※北米(英語版)の大会・カードデータをもとに構築しており、日本語版のパック発売日とは厳密には一致しない場合がある。"
        ),
    ),
    Regulation(
        id="standard_2014_worlds",
        name="2014年 世界大会環境",
        category="past",
        ruleset=PRE_SWSH_RULESET,
        set_cutoff_date="2014-08-17",
        sets=(
            "Black & White 〜 XY(2014年8月15-17日時点で発売済みのパックのみ)",
            "レギュレーションマーク制度導入前のため、当時の実際のスタンダードは「Black & White」"
            "基本パック(2011年4月発売)以降のブロックが使用可能だった",
        ),
        description=(
            "2014年8月15-17日、アメリカ・ワシントン州シアトルで開催された世界大会マスターズ部門の"
            "Top4を再現: 優勝Andrew Estrada選手(ビリジオンEX/ゲノセクトEX)、"
            "2位Igor Costa選手(ビリジオンEX/ゲノセクトEX)、"
            "3位Michikazu Tsuda選手(フレフワン/ガルーラEX)。4位は順次追加予定。"
            "実際の大会デッキリスト(Limitless TCG等)に基づいて構築している。"
            "Gブースター(どうぐ由来のワザ追加)はゲノセクトEXにつけたときのワザ「G Booster」の使用に対応済み。"
            "カードDBに無い当時の印刷は、同一テキストの後年の印刷(例: フラダリxy7-78、シェイミEXxy6-77、基本エネルギーのbase1版など)で代用している。"
            "※北米(英語版)の大会・カードデータをもとに構築しており、日本語版のパック発売日とは厳密には一致しない場合がある。"
        ),
    ),
    Regulation(
        id="wcs2010_gabu_ren",
        name="WCS2010 ガブレンミラー",
        category="special",
        ruleset=WCS2010_RULESET,
        set_cutoff_date="2010-04-16",
        sets=(
            "Diamond & Pearl", "Platinum", "HeartGold & SoulSilver",
            "日本国内では2006年11月30日(「時空の創造 ダイヤモンド/パールコレクション」)〜"
            "2010年4月16日(「ハートゴールドコレクション/ソウルシルバーコレクション」)に発売されたカードに相当",
        ),
        description="2010年世界選手権当時のルール(先攻1ターン目はトレーナーズ使用不可)を再現した、非公式の同型ミラー戦。",
        mirror=True,
    ),
)

# ---- 時代別レギュレーション(2026-10-06、ユーザー指示「HIJなどのマーク以外にも発売日などでも差別化していく」) ----
# 日本版のパックの発売日の範囲([set_start_date, set_cutoff_date])でカードプールを決める。範囲は各時代のメインセットの
# 最初の発売日から、次の時代の最初のメインセットの前日まで(時代どうしは重ならない)。大会ごとのレギュレーションと違い、
# その期間に発売された全カードが使える(前の時代のカードは含まない)。
# ルールセットは data/first_turn_rules_history.md の日本版の表に従う。カードDBへの取り込み状況は
# scripts/regulation_pool_report.py で確認する(未取り込みのカードは実装前なので、デッキには使えない)。
def _era(id: str, name: str, start: str, end: str, ruleset: Ruleset, blocks: str) -> Regulation:
    return Regulation(
        id=id,
        name=name,
        category="era",
        ruleset=ruleset,
        set_start_date=start,
        set_cutoff_date=end,
        sets=(blocks, f"日本版の発売日 {start} 〜 {end} のパックに収録されたカード"),
        description=f"{name}(日本版 {start}〜{end} 発売のパックのカードが使える、時代別レギュレーション)。",
    )


_ERA_REGULATIONS: tuple[Regulation, ...] = (
    _era("era_adv", "ADV期", "2003-01-31", "2004-04-08", ADV_JP_EARLY_RULESET, "ADV1〜ADV5"),
    _era("era_pcg", "PCG期", "2004-04-09", "2006-11-29", ADV_JP_RULESET, "PCG1〜PCG6ほか"),
    _era("era_dp", "ダイヤモンド&パール期", "2006-11-30", "2008-10-09", DP_JP_RULESET, "DP1〜DPS"),
    _era("era_pt", "プラチナ期", "2008-10-10", "2009-10-08", DP_JP_RULESET, "DPt1〜DPt4"),
    _era("era_legend", "LEGEND期", "2009-10-09", "2010-12-16", DP_JP_RULESET, "L1〜L3"),
    _era("era_bw", "ブラック&ホワイト期", "2010-12-17", "2013-12-12", BW_RULESET, "BW1〜BW8ほか"),
    _era("era_xy", "XY期", "2013-12-13", "2016-12-08", PRE_SWSH_RULESET, "XY1〜XY11ほか"),
    _era("era_sm", "サン&ムーン期", "2016-12-09", "2019-12-05", PRE_SWSH_RULESET, "SM1〜SM12a"),
    _era("era_swsh", "ソード&シールド期", "2019-12-06", "2023-01-19", DEFAULT_RULESET, "S1〜S12a"),
    _era("era_sv", "スカーレット&バイオレット期", "2023-01-20", "2025-07-31", DEFAULT_RULESET, "SV1〜SV11"),
    _era("era_mega", "メガシリーズ期", "2025-08-01", "2026-12-31", DEFAULT_RULESET, "M1〜M6ほか"),
)

REGULATIONS = REGULATIONS + _ERA_REGULATIONS

_BY_ID = {r.id: r for r in REGULATIONS}

# HIJレギュレーション(レギュレーションマークH/I/Jのカードのみ使用可能な、日本国内2024年1月26日〜
# 現在のスタンダードフォーマット)に属するレギュレーションidの集合。現行スタンダード本体("standard_current")
# に加えて、同じH/I/J期間内の異なるカードプールカットオフで開催された過去大会のデッキスナップショット
# (pjcs2026/cl2026_fukuoka/cl2026_ninjaspinner_era)も、ルールセット自体は同一(DEFAULT_RULESET)なので
# ここに含める。AI学習環境(training.train)がこの集合を使って、大会の枠を横断した1つの学習対象として扱う。
HIJ_REGULATION_IDS: frozenset[str] = frozenset(
    {"standard_current", "pjcs2026", "cl2026_fukuoka", "cl2026_ninjaspinner_era"}
)

_CATEGORY_ORDER = ("normal", "past", "era", "extra", "special")


def get_regulation(regulation_id: str) -> Regulation:
    return _BY_ID.get(regulation_id, REGULATIONS[0])


def regulations_by_category() -> dict[str, list[Regulation]]:
    grouped: dict[str, list[Regulation]] = {c: [] for c in _CATEGORY_ORDER}
    for r in REGULATIONS:
        grouped.setdefault(r.category, []).append(r)
    return {c: regs for c, regs in grouped.items() if regs}
