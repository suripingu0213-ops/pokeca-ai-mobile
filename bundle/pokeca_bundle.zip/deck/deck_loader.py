"""YAMLファイルからデッキを読み込む。"""

from __future__ import annotations

import yaml

from cards.card_db import CardDatabase
from deck.deck_format import Deck


def load_deck(path: str, card_db: CardDatabase, validate: bool = True) -> Deck:
    with open(path, encoding="utf-8") as f:
        data = yaml.safe_load(f)
    deck = Deck(
        name=data.get("name", path),
        cards=dict(data["cards"]),
        regulation=data.get("regulation", "standard_current"),
    )
    if validate:
        deck.validate(card_db)
    return deck
