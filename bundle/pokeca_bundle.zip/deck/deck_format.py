"""デッキ定義スキーマと検証(60枚、基本エネルギー以外は同名4枚まで、たね1枚以上)。"""

from __future__ import annotations

from dataclasses import dataclass

from cards.card_db import CardDatabase

DECK_SIZE = 60
MAX_COPIES_NON_BASIC_ENERGY = 4


class DeckValidationError(ValueError):
    pass


@dataclass
class Deck:
    name: str
    cards: dict[str, int]  # card_id -> 枚数
    regulation: str = "standard_current"

    def to_card_list(self) -> list[str]:
        result: list[str] = []
        for card_id, count in self.cards.items():
            result.extend([card_id] * count)
        return result

    def validate(self, card_db: CardDatabase) -> None:
        total = sum(self.cards.values())
        if total != DECK_SIZE:
            raise DeckValidationError(f"デッキ枚数は{DECK_SIZE}枚である必要があります(現在{total}枚)")

        has_basic_pokemon = False
        ace_spec_count = 0
        for card_id, count in self.cards.items():
            card = card_db.get(card_id)
            if card is None:
                raise DeckValidationError(f"カードDBに存在しないカードID: {card_id}")
            is_basic_energy = card.is_energy and not card.is_special_energy
            if not is_basic_energy and count > MAX_COPIES_NON_BASIC_ENERGY:
                raise DeckValidationError(f"{card_id} は同名{MAX_COPIES_NON_BASIC_ENERGY}枚までです(現在{count}枚)")
            if card.is_basic:
                has_basic_pokemon = True
            if "ACE SPEC" in card.subtypes:
                ace_spec_count += count

        if not has_basic_pokemon:
            raise DeckValidationError("たねポケモンが1枚も入っていません")
        if ace_spec_count > 1:
            raise DeckValidationError(f"ACE SPECは1デッキに1枚までです(現在{ace_spec_count}枚)")
