"""スマホ版(Pyodide)のサーバー代わり。web/app.py(PC版Flaskアプリ)を無改造のまま読み込み、
ブラウザの fetch("/api/...") をその場でルート関数の呼び出しに変える。

PC版とスマホ版でゲームのロジックを二重管理しないため、ここには「Flaskの代わりに呼ぶ」処理しか書かない。
"""

from __future__ import annotations

import json
import os
import pickle
import sys
from urllib.parse import parse_qsl, urlsplit

ROOT = os.path.dirname(os.path.abspath(__file__))
os.chdir(ROOT)  # デッキの相対パス("deck/sample_decks/...")・data/ をPC版と同じ位置で解決する
if ROOT not in sys.path:
    sys.path.insert(0, ROOT)

import flask  # noqa: E402  (overrides/flask.py のスタブ)

from agents import deck_ai  # noqa: E402

_app_module = None


def _load():
    global _app_module
    if _app_module is None:
        import importlib

        _app_module = importlib.import_module("web.app")
        # 実績の勝率AI(フーディンAI/ドラパAI)はスマホでは使えない。web/appは読み込み時に専用枠の定義で
        # DECK_AISのキーを引くため、読み込みが終わってから空にして「選べるAIが無い」状態にする。
        deck_ai.DECK_AIS.clear()
        # 「フーディン vs ドラパルト(専用AI)」枠のAIは、PC版ではデッキ別の実績AIを選べるが、スマホでは使えない。
        # 代わりに、この2デッキの対決で学習した専用ネットワークに固定する(画面にもそのAI名が出る)。
        slot = _app_module._DEDICATED_SLOTS.get(_app_module._DEDICATED_SLOT_ID)
        if slot is not None and "osaka_aichi_mirror" in _app_module.POLICY_MODELS:
            slot["fixed_ai"] = "osaka_aichi_mirror"
    return _app_module


def init() -> str:
    """起動時に1回呼ぶ。カードDB・モデル・ルート登録を済ませておく(最初の対局までの待ちを1か所に集める)。"""
    import time

    t0 = time.time()
    module = _load()
    return json.dumps(
        {
            "routes": len(module.app.routes),
            "cards": len(module.CARD_DB),
            "models": sorted(module.POLICY_MODELS),
            "load_seconds": round(time.time() - t0, 2),
        }
    )


def handle(method: str, url: str, body_json: str | None) -> str:
    """fetch相当。戻り値は {"status": int, "body": ...} のJSON文字列。"""
    module = _load()
    parts = urlsplit(url)
    flask.request.method = method.upper()
    flask.request.args = dict(parse_qsl(parts.query))
    flask.request._json = json.loads(body_json) if body_json else None
    for pattern, methods, func in module.app.routes:
        match = pattern.match(parts.path)
        if match is None:
            continue
        if flask.request.method not in methods:
            return json.dumps({"status": 405, "body": {"error": "method not allowed"}})
        result = func(*match.groups())
        status = 200
        if isinstance(result, tuple):
            result, status = result
        if isinstance(result, flask._Response):
            status = result.status_code if status == 200 else status
            payload = result.payload
        else:
            payload = result
        return json.dumps({"status": status, "body": payload}, ensure_ascii=False, default=str)
    return json.dumps({"status": 404, "body": {"error": "not found: " + parts.path}})


# ---- 対局の自動保存(スマホはバックグラウンドに回るとアプリごと終了されることがあるため、再開できるようにする) ----
SESSION_FILE = os.path.join(ROOT, "data", "phone_session", "games.pkl")
UNDO_KEEP = 6  # 保存時に残す「一手戻す」の履歴数(全部残すと大きすぎる)
GAMES_KEEP = 2  # 保存する対局数(新しい方から。終わった対局が溜まり続けないようにする)


def save_session() -> int:
    """進行中の対局をファイルに書く(pwa_worker.jsがこの後IndexedDBへ同期する)。戻り値は保存した対局数。"""
    module = _load()
    saved = {}
    for game_id, game in list(module.GAMES.items())[-GAMES_KEEP:]:
        try:
            copy_ = dict(game)
            copy_["undo_stack"] = list(game.get("undo_stack") or [])[-UNDO_KEEP:]
            pickle.dumps(copy_)  # 保存できない中身があれば、この対局だけ飛ばす
            saved[game_id] = copy_
        except Exception:
            continue
    os.makedirs(os.path.dirname(SESSION_FILE), exist_ok=True)
    tmp = SESSION_FILE + ".tmp"
    with open(tmp, "wb") as f:
        pickle.dump(saved, f)
    os.replace(tmp, SESSION_FILE)
    return len(saved)


def restore_session() -> int:
    """前回保存した対局を読み戻す(無い・壊れているときは0)。"""
    module = _load()
    try:
        with open(SESSION_FILE, "rb") as f:
            saved = pickle.load(f)
    except Exception:
        return 0
    module.GAMES.update(saved)
    return len(saved)
