"""ローカルキャッシュからロードするカードデータベース。"""

from __future__ import annotations

from cards.cache import load_cards
from cards.models import Card

# みがわりロボ(Robo Substitute、xy4-102)は「グッズだが30HPの無色たねポケモンとして場に出す」という
# 特殊カード。実際のxy4-102(グッズカード)とは別に、場に出ているときだけ使う合成カードIDを用意する
# (手札/トラッシュでは引き続き本来のxy4-102のまま扱う)。ROBO_SUBSTITUTE_ITEM_ID/POKEMON_IDは
# engine側(legal_actions.py/rules_engine.py)からも参照する。
ROBO_SUBSTITUTE_ITEM_ID = "xy4-102"
ROBO_SUBSTITUTE_POKEMON_ID = "xy4-102-mon"
_ROBO_SUBSTITUTE_POKEMON_CARD = Card(
    id=ROBO_SUBSTITUTE_POKEMON_ID,
    name="Robo Substitute",
    supertype="Pokémon",
    subtypes=("Basic",),
    hp=30,
    types=("Colorless",),
)


# 「グッズだが60HPの無色たねポケモンとして場に出せる」化石グッズ(Antique〜Fossil)。みがわりロボと同じく、場にいる間だけ合成カードID(<ID>-mon)の
# ポケモンとして扱う(手札/トラッシュでは本来のグッズのID)。ロボは30HP・きぜつしてもサイドを取られないが、化石は60HP・サイドは通常どおり取られる。
ANTIQUE_FOSSIL_ITEM_IDS = ("me3-68", "me3-69", "me5-72", "me5-73", "rsv10pt5-79", "sm5-134", "sm6-116", "sm9-155", "sm11-210", "sm12-207")  # Antique〜Fossil / Unidentified Fossil(60HP無色たね)
# リーリエのポケ人形(Lillie's Poké Doll): 30HPの無色たね。きぜつしても相手はサイドを取れない。バトル場にいるときだけ、ついているカードをトラッシュして山札の下に置ける。
POKE_DOLL_ITEM_IDS = ("sm12-197", "sm12-267")
ITEM_AS_POKEMON: dict[str, str] = {ROBO_SUBSTITUTE_ITEM_ID: ROBO_SUBSTITUTE_POKEMON_ID}
ITEM_AS_POKEMON.update({item_id: item_id + "-mon" for item_id in ANTIQUE_FOSSIL_ITEM_IDS})
ITEM_AS_POKEMON.update({item_id: item_id + "-mon" for item_id in POKE_DOLL_ITEM_IDS})
POKEMON_AS_ITEM: dict[str, str] = {pokemon_id: item_id for item_id, pokemon_id in ITEM_AS_POKEMON.items()}


class CardDatabase:
    def __init__(self, cards: dict[str, Card] | None = None) -> None:
        self._cards: dict[str, Card] = cards or {}

    @classmethod
    def from_cache(cls) -> "CardDatabase":
        raw_cards = load_cards()
        cards = {}
        for raw in raw_cards:
            try:
                card = Card.from_api_json(raw)
            except (KeyError, ValueError, TypeError):
                continue
            cards[card.id] = card
        if ROBO_SUBSTITUTE_ITEM_ID in cards:
            cards[ROBO_SUBSTITUTE_POKEMON_ID] = _ROBO_SUBSTITUTE_POKEMON_CARD
        from dataclasses import replace

        for item_id in ANTIQUE_FOSSIL_ITEM_IDS:
            item = cards.get(item_id)
            if item is not None:
                cards[ITEM_AS_POKEMON[item_id]] = replace(
                    item, id=ITEM_AS_POKEMON[item_id], supertype="Pokémon", subtypes=("Basic",), hp=60, types=("Colorless",),
                    rules=(), trainer_text="",
                )  # 特性は元のカードのものをそのまま引き継ぐ
        for item_id in POKE_DOLL_ITEM_IDS:
            item = cards.get(item_id)
            if item is not None:
                cards[ITEM_AS_POKEMON[item_id]] = replace(
                    item, id=ITEM_AS_POKEMON[item_id], supertype="Pokémon", subtypes=("Basic",), hp=30, types=("Colorless",),
                    rules=(), trainer_text="",
                )
        return cls(cards)

    def __len__(self) -> int:
        return len(self._cards)

    def __contains__(self, card_id: str) -> bool:
        return card_id in self._cards

    def get(self, card_id: str) -> Card | None:
        return self._cards.get(card_id)

    def get_or_raise(self, card_id: str) -> Card:
        card = self._cards.get(card_id)
        if card is None:
            raise KeyError(f"card id not found in database: {card_id}")
        return card

    def find_by_name(self, name: str) -> list[Card]:
        lowered = name.lower()
        return [c for c in self._cards.values() if lowered in c.name.lower()]

    def all(self) -> list[Card]:
        return list(self._cards.values())


TEAM_ROCKETS_NAME_PREFIX = "Team Rocket's"
# ロケット団のワナイダー(sv10a-9)は英語版が未確認のためcard.nameが日本語のまま登録されており、
# `card.name.startswith(TEAM_ROCKETS_NAME_PREFIX)`だけでは「ロケット団のポケモン」の判定から
# 漏れてしまう(2026-08-22、ユーザーからロケット団のミュウツーexの特性「Power Saver」の
# ポケモン数カウントに漏れがあるとの報告を受けて発覚。同じ判定パターンがeffects/primitives.py・
# engine/legal_actions.py・engine/win_conditions.pyの複数箇所に散在していたため、まとめてここに
# 一本化した)。
_TEAM_ROCKETS_UNTRANSLATED_NAME_CARD_IDS = frozenset({"sv10a-9"})


def is_team_rockets_pokemon(card: Card | None) -> bool:
    """「ロケット団の」を冠するポケモンかどうかを判定する(特性「Power Saver」のポケモン数
    カウント、ロケット団専用トレーナーズの対象判定等で共通して使う)。"""
    if card is None:
        return False
    return card.name.startswith(TEAM_ROCKETS_NAME_PREFIX) or card.id in _TEAM_ROCKETS_UNTRANSLATED_NAME_CARD_IDS


def card_has_subtype(card: Card | None, subtype: str) -> bool:
    """サブタイプ判定。「Team Aqua」「Team Magma」はカードDB上のサブタイプではなく
    「Team Aqua's 〜」という名前で表現されるため、名前接頭辞でも判定する。"""
    if card is None:
        return False
    if subtype in card.subtypes:
        return True
    if subtype in ("Team Aqua", "Team Magma"):
        return card.name.startswith(subtype + "'s ")
    return False
