"""pokemontcg.io のカードデータを表す静的モデル。

このモジュールはカードの「見た目のデータ」だけを保持する。攻撃/特性が
実際に何をするかは effects/registry.py 側でカードIDに紐付けて定義する。
"""

from __future__ import annotations

from dataclasses import dataclass, field


@dataclass(frozen=True)
class WeaknessResistance:
    type: str
    value: str  # 例: "×2", "-30"


@dataclass(frozen=True)
class Attack:
    name: str
    cost: tuple[str, ...]  # 例: ("Grass", "Colorless")
    damage: str  # 例: "30", "60+", "" (ダメージなし)
    text: str

    @property
    def converted_energy_cost(self) -> int:
        return len(self.cost)

    @property
    def base_damage(self) -> int:
        digits = "".join(ch for ch in self.damage if ch.isdigit())
        return int(digits) if digits else 0


@dataclass(frozen=True)
class Ability:
    name: str
    text: str
    ability_type: str = ""  # "Ability", "Poké-Power", "Poké-Body" 等


_DISPLAY_CATEGORY_ORDER = ("pokemon", "supporter", "item", "tool", "stadium", "energy")


@dataclass(frozen=True)
class Card:
    id: str
    name: str
    supertype: str  # "Pokémon" / "Trainer" / "Energy"
    subtypes: tuple[str, ...]  # 例: ("Basic",), ("Stage 1",), ("Item",), ("Supporter",)
    hp: int | None = None
    types: tuple[str, ...] = field(default_factory=tuple)
    evolves_from: str | None = None
    attacks: tuple[Attack, ...] = field(default_factory=tuple)
    abilities: tuple[Ability, ...] = field(default_factory=tuple)
    weaknesses: tuple[WeaknessResistance, ...] = field(default_factory=tuple)
    resistances: tuple[WeaknessResistance, ...] = field(default_factory=tuple)
    retreat_cost: tuple[str, ...] = field(default_factory=tuple)
    rules: tuple[str, ...] = field(default_factory=tuple)  # ex/GX等のルール文
    trainer_text: str = ""  # Trainer/Energyカードの効果テキスト
    image_small: str = ""
    image_large: str = ""

    @property
    def is_pokemon(self) -> bool:
        return self.supertype == "Pokémon"

    @property
    def is_basic(self) -> bool:
        return self.is_pokemon and "Basic" in self.subtypes

    @property
    def is_level_up(self) -> bool:
        """Lv.Xポケモンかどうか(pokemontcg.ioでは subtypes に "Level-Up" が入る)。"""
        return self.is_pokemon and "Level-Up" in self.subtypes

    @property
    def is_sp_pokemon(self) -> bool:
        """SPポケモン(2009年前後のギンガ団SPシリーズ)かどうか。"""
        return self.is_pokemon and "SP" in self.subtypes

    @property
    def level_up_base_name(self) -> str | None:
        """Lv.Xカードが対応する、レベルアップ元のポケモン名("Luxray GL LV.X" -> "Luxray GL")。"""
        if not self.is_level_up:
            return None
        for suffix in (" LV.X", " Lv.X", " LV. X"):
            if self.name.endswith(suffix):
                return self.name[: -len(suffix)]
        return None

    @property
    def is_trainer(self) -> bool:
        return self.supertype == "Trainer"

    @property
    def is_supporter(self) -> bool:
        return self.is_trainer and "Supporter" in self.subtypes

    @property
    def is_item(self) -> bool:
        return self.is_trainer and "Item" in self.subtypes

    @property
    def is_stadium(self) -> bool:
        return self.is_trainer and "Stadium" in self.subtypes

    @property
    def is_pokemon_tool(self) -> bool:
        return self.is_trainer and "Pokémon Tool" in self.subtypes

    @property
    def is_energy(self) -> bool:
        return self.supertype == "Energy"

    @property
    def is_special_energy(self) -> bool:
        return self.is_energy and "Special" in self.subtypes

    @property
    def display_category_rank(self) -> int:
        """画面表示用の並び順(ポケモン→サポート→グッズ→ポケモンのどうぐ→スタジアム→エネルギー)。"""
        if self.is_pokemon:
            cat = "pokemon"
        elif self.is_supporter:
            cat = "supporter"
        elif self.is_pokemon_tool:  # どうぐはsubtypesに"Item"も含むため、Itemより先に判定する
            cat = "tool"
        elif self.is_item:
            cat = "item"
        elif self.is_stadium:
            cat = "stadium"
        elif self.is_energy:
            cat = "energy"
        else:
            cat = None
        return _DISPLAY_CATEGORY_ORDER.index(cat) if cat in _DISPLAY_CATEGORY_ORDER else len(_DISPLAY_CATEGORY_ORDER)

    @property
    def basic_energy_type(self) -> str | None:
        """基本エネルギーのタイプ名。pokemontcg.ioはエネルギーカードに `types` を入れないため、
        カード名("Fire Energy"など)から推測する。特殊エネルギー(Double Colorless等)はNone。"""
        if self.is_energy and not self.is_special_energy and self.name.endswith(" Energy"):
            return self.name[: -len(" Energy")]
        return None

    @property
    def retreat_cost_count(self) -> int:
        return len(self.retreat_cost)

    @property
    def extra_prize_count(self) -> int:
        """ex/GX等、きぜつ時に追加でサイドを取られるカードなら1以上を返す。
        メガシンカポケモンex(2025年〜の新メガシンカ)はさらに1多く(合計3枚)取られる。"""
        if "MEGA" in self.subtypes or "Mega" in self.subtypes:
            return 2
        for rule_text in self.rules:
            if "3 Prize" in rule_text or "3枚" in rule_text:
                return 2
            if "2 Prize" in rule_text or "2枚" in rule_text:
                return 1
        for subtype in self.subtypes:
            if subtype in ("ex", "EX", "GX", "V", "VMAX", "VSTAR"):
                return 1
        return 0

    @classmethod
    def from_api_json(cls, data: dict) -> "Card":
        hp_raw = data.get("hp")
        attacks = tuple(
            Attack(
                name=a.get("name", ""),
                # pokemontcg.ioは0コストワザのcostを["Free"]と表現する(コスト無し=何もエネルギーが
                # 要らない、という意味であって、"Free"という名のエネルギータイプが要る訳ではない)。
                cost=tuple(t for t in a.get("cost", ()) if t != "Free"),
                damage=a.get("damage", "") or "",
                text=a.get("text", "") or "",
            )
            for a in data.get("attacks", []) or []
        )
        abilities = tuple(
            Ability(
                name=ab.get("name", ""),
                text=ab.get("text", "") or "",
                ability_type=ab.get("type", "") or "",
            )
            for ab in data.get("abilities", []) or []
        )
        weaknesses = tuple(
            WeaknessResistance(type=w.get("type", ""), value=w.get("value", ""))
            for w in data.get("weaknesses", []) or []
        )
        resistances = tuple(
            WeaknessResistance(type=r.get("type", ""), value=r.get("value", ""))
            for r in data.get("resistances", []) or []
        )
        return cls(
            id=data["id"],
            name=data.get("name", ""),
            supertype=data.get("supertype", ""),
            subtypes=tuple(data.get("subtypes", []) or []),
            hp=int(hp_raw) if hp_raw else None,
            types=tuple(data.get("types", []) or []),
            evolves_from=data.get("evolvesFrom"),
            attacks=attacks,
            abilities=abilities,
            weaknesses=weaknesses,
            resistances=resistances,
            retreat_cost=tuple(data.get("retreatCost", []) or []),
            rules=tuple(data.get("rules", []) or []),
            trainer_text=" ".join(data.get("rules", []) or []) if data.get("supertype") != "Pokémon" else "",
            image_small=(data.get("images") or {}).get("small", ""),
            image_large=(data.get("images") or {}).get("large", ""),
        )
