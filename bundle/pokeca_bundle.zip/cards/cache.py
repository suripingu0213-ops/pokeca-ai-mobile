"""カードJSONのローカルキャッシュ読み書き。"""

from __future__ import annotations

import json

from config.settings import CARDS_CACHE_FILE


def save_cards(cards: list[dict]) -> None:
    CARDS_CACHE_FILE.parent.mkdir(parents=True, exist_ok=True)
    with open(CARDS_CACHE_FILE, "w", encoding="utf-8") as f:
        json.dump(cards, f, ensure_ascii=False)


def load_cards() -> list[dict]:
    if not CARDS_CACHE_FILE.exists():
        return []
    with open(CARDS_CACHE_FILE, encoding="utf-8") as f:
        return json.load(f)


def cache_exists() -> bool:
    return CARDS_CACHE_FILE.exists()
