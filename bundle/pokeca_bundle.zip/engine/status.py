"""特殊状態(どく・やけど・ねむり・マヒ・こんらん)の定義と解決。

公式ルール(上級プレイヤー用ルールガイド Ver.3.4)に基づく:
- どく/やけど は毒・火傷それぞれ独立したフラグで、ほかの特殊状態と共存できる。
- ねむり・マヒ・こんらん は同時に1つしか付与できない(新しく付与されたら上書き)。
- 特殊状態はバトルポケモンだけが受け、にげる/入れ替え/進化ですべて消える。
"""

from __future__ import annotations

import random
from dataclasses import dataclass, field
from enum import Enum, auto


class ExclusiveCondition(Enum):
    NONE = auto()
    ASLEEP = auto()
    PARALYZED = auto()
    CONFUSED = auto()


POISON_DAMAGE = 10
BURN_DAMAGE = 20


@dataclass
class StatusState:
    poisoned: bool = False
    poison_severity: int = 1  # 通常のどくは1(10ダメージ)。一部カードは2(20ダメージ)などに強化する
    burned: bool = False
    exclusive: ExclusiveCondition = ExclusiveCondition.NONE
    paralysis_survives_next_checkup: bool = False  # マヒを与えた側の番の終わりのチェックでは治さないためのフラグ
    sleep_flip_count: int = 1  # ねむりから目覚める判定で振るコイン枚数(通常1枚、カビゴンの「爆音イビキ」は2枚)
    confusion_counters: int = 3  # こんらんでワザに失敗したときの自傷ダメカンの数(通常3個、Heavy Perfumeは6個)

    def clear_all(self) -> None:
        """にげる/入れ替え/進化ですべての特殊状態が消える。"""
        self.poisoned = False
        self.poison_severity = 1
        self.burned = False
        self.exclusive = ExclusiveCondition.NONE
        self.paralysis_survives_next_checkup = False
        self.sleep_flip_count = 1
        self.confusion_counters = 3

    def apply_exclusive(self, condition: ExclusiveCondition) -> None:
        """ねむり/マヒ/こんらんは新しいものが古いものを上書きする。"""
        self.exclusive = condition
        if condition == ExclusiveCondition.CONFUSED:
            self.confusion_counters = 3
        if condition == ExclusiveCondition.ASLEEP:
            self.sleep_flip_count = 1  # 通常のねむり付与は常に1枚判定にリセットする
        if condition == ExclusiveCondition.PARALYZED:
            # マヒを与えたのは相手の番の途中(攻撃側の番)なので、その番の終わりに来る
            # ポケモンチェックでは治さない。相手(にげる/ワザを封じたい相手)自身の番の
            # 終わりのチェックで初めて治す。
            self.paralysis_survives_next_checkup = True

    @property
    def can_attack(self) -> bool:
        return self.exclusive not in (ExclusiveCondition.ASLEEP, ExclusiveCondition.PARALYZED)

    @property
    def can_retreat(self) -> bool:
        return self.exclusive not in (ExclusiveCondition.ASLEEP, ExclusiveCondition.PARALYZED)

    @property
    def is_confused(self) -> bool:
        return self.exclusive == ExclusiveCondition.CONFUSED

    @property
    def is_any(self) -> bool:
        return self.poisoned or self.burned or self.exclusive != ExclusiveCondition.NONE


@dataclass
class CheckupResult:
    """ポケモンチェック1体分の結果ログ(リプレイ表示・デバッグ用)。"""

    damage_dealt: int = 0
    woke_up: bool = False
    burn_cured: bool = False
    paralysis_cleared: bool = False
    confusion_self_damage: int = 0
    events: list[str] = field(default_factory=list)


def resolve_confusion_attack_check(status: StatusState, rng: random.Random) -> tuple[bool, int]:
    """こんらん状態でワザを使うときの成功判定。

    戻り値: (成功したか, 自傷ダメージ(失敗時30))
    """
    if not status.is_confused:
        return True, 0
    if rng.random() < 0.5:
        return True, 0
    return False, 10 * status.confusion_counters


def resolve_pokemon_checkup(
    status: StatusState, rng: random.Random, sleep_flips: int | None = None, burn_stays: bool = False
) -> CheckupResult:
    """ポケモンチェック手順: どく→やけど→ねむり→マヒ の順に処理する。

    マヒは1回のチェックで自動的に治る(次の相手の番の終わりまでの効果として簡略化)。
    こんらんはチェックでは治らない(にげる/入れ替え/進化でのみ解除)。
    """
    result = CheckupResult()

    if status.poisoned:
        poison_amount = POISON_DAMAGE * status.poison_severity
        result.damage_dealt += poison_amount
        result.events.append(f"どくダメージ {poison_amount}")

    if status.burned:
        result.damage_dealt += BURN_DAMAGE
        result.events.append(f"やけどダメージ {BURN_DAMAGE}")
        if rng.random() < 0.5 and not burn_stays:  # burn_stays: ウェラ火山公園(コインがオモテでもやけどは治らない)
            status.burned = False
            result.burn_cured = True
            result.events.append("やけど治癒")

    if status.exclusive == ExclusiveCondition.ASLEEP:
        all_heads = all(rng.random() < 0.5 for _ in range(max(status.sleep_flip_count, sleep_flips or 1)))  # sleep_flips: おやすみの森(2枚投げて両方オモテ)
        if all_heads:
            status.exclusive = ExclusiveCondition.NONE
            status.sleep_flip_count = 1
            result.woke_up = True
            result.events.append("目を覚ました")

    if status.exclusive == ExclusiveCondition.PARALYZED:
        if status.paralysis_survives_next_checkup:
            # 与えた側の番の終わりのチェック: このチェックでは治さず、次のチェックで治す
            status.paralysis_survives_next_checkup = False
        else:
            status.exclusive = ExclusiveCondition.NONE
            result.paralysis_cleared = True
            result.events.append("マヒ治癒")

    return result
