"""バトル状態のデータモデル。

`GameState.apply_action` からのみ変更されることを前提とする(engine/rules_engine.py 参照)。
"""

from __future__ import annotations

import contextvars

import dataclasses
import random
from dataclasses import dataclass, field

from engine.ruleset import DEFAULT_RULESET, Ruleset
from engine.status import StatusState

MAX_BENCH_SIZE = 5
STARTING_HAND_SIZE = 7
PRIZE_COUNT = 6


def _fill_missing_fields_with_defaults(obj: object, state: dict) -> None:
    """pickle復元(__setstate__)用の共通処理。data/human_games/*.pklは対局のたびにGameStateを
    まるごとpickle保存しており、以後のセッションでこれらのdataclassにフィールドを追加すると、
    古いpklファイルを読み込んだ際にpickleのデフォルト復元(__dict__をそのまま流し込むだけで
    __init__を経由しない)では新フィールドが存在せずAttributeErrorになる(2026-08-20、
    known_opponent_hand追加直後、模倣学習が人間の対局記録を読み込む際に実際に発生して発覚)。
    保存時点に存在しなかったフィールドは、この関数でdataclass定義の既定値/default_factoryを
    補って埋める(今後さらにフィールドを追加しても、この仕組み自体を追加で書き換える必要はない)。
    """
    for f in dataclasses.fields(obj):
        if f.name in state:
            continue
        if f.default_factory is not dataclasses.MISSING:  # type: ignore[misc]
            state[f.name] = f.default_factory()
        elif f.default is not dataclasses.MISSING:
            state[f.name] = f.default


def discard_attached_tool(state: "GameState", holder: "PlayerState", mon: "PokemonInPlay") -> str | None:
    """ポケモンについているどうぐを外してトラッシュに置く。どうぐのカードの持ち主(attached_tool_owner)がいれば、
    そのプレイヤーのトラッシュに、いなければ場のポケモンの持ち主(holder)のトラッシュに置く。外したカードIDを返す。"""
    tool = mon.attached_tool
    if tool is None:
        return None
    owner = state.players[mon.attached_tool_owner] if mon.attached_tool_owner is not None else holder
    from effects.era_sm_hooks import U_TURN_BOARD_IDS

    (owner.hand if tool in U_TURN_BOARD_IDS else owner.discard).append(tool)  # Uターンボード: 場から離れたら、トラッシュではなく手札に加える
    mon.attached_tool = None
    mon.attached_tool_owner = None
    return tool


# ドータクンの「Heal Block」: 場に特性が有効なドータクンがいる間、ダメージの回復(ダメージを減らす代入)を無視する。
# engine.rules_engine.apply_actionが、行動ごとに(場の状態から)設定する。ダメカンの「移動」は回復ではないので、
# PokemonInPlay.remove_countersで引く(ガードされない)。
HEAL_BLOCK: contextvars.ContextVar = contextvars.ContextVar("heal_block", default=False)
# 「このポケモンは、相手の次の番、ダメージを回復できない」(ムーンゲイストビーム等)を受けているポケモンのid()の集合。
# apply_actionが、行動ごとに場の状態から設定する(HEAL_BLOCKと同じ仕組み。個々のポケモンだけが対象)。
HEAL_BLOCKED_MON_IDS: contextvars.ContextVar = contextvars.ContextVar("heal_blocked_mon_ids", default=frozenset())


class _GuardedDamage:
    """PokemonInPlay.damageのデスクリプタ。値はインスタンスの__dict__["damage"]に持つ(保存済みの対局記録(pickle)・
    deepcopyと互換)。Heal Blockが有効なとき、現在より小さい値の代入(=回復)は無視する。"""

    def __get__(self, obj, objtype=None):
        return 0 if obj is None else obj.__dict__.get("damage", 0)

    def __set__(self, obj, value) -> None:
        old = obj.__dict__.get("damage", 0)
        if value < old:
            if HEAL_BLOCK.get() or id(obj) in HEAL_BLOCKED_MON_IDS.get():
                return
            obj.__dict__["healed_this_turn"] = True  # 「このターンに回復した」(Power Creation等の判定用)
        obj.__dict__["damage"] = value


@dataclass
class PokemonInPlay:
    card_id: str
    attached_energy: list[str] = field(default_factory=list)  # 各エネルギーカードのcard_id
    damage: int = _GuardedDamage()  # 現在受けているダメージ(HP減少量)
    status: StatusState = field(default_factory=StatusState)
    turn_played: int = -1  # このポケモンが場に出た(たね)/進化したターン番号
    attached_tool: str | None = None
    attached_tool_owner: int | None = None  # どうぐのカードの持ち主(プレイヤー番号)。通常は場のポケモンの持ち主と同じなのでNone。
    # 相手のポケモンにつけるどうぐ(ヘッドノイザー)だけ、つけたプレイヤーを入れる("put this card in its owner's discard pile")
    leveled_up: bool = False  # Lv.Xに進化済みかどうか(通常進化とは別枠)
    locked_attack_name: str | None = None  # 「次の自分の番、このワザは使えない」の対象ワザ名
    locked_attack_until_turn: int = 0  # このターン番号までロックされる(player.turns_taken基準)
    used_ability_this_turn: bool = False  # 「1回の自分の番に1回」制限のある特性/ポケパワーを既に使ったか
    unlimited_ability_uses_this_turn: int = 0  # 「自分の番に何度でも使える」特性(メガフシギバナexの「Solar Transfer」等、
    # rules_engine._UNLIMITED_PER_TURN_ABILITY_CARD_IDS)の、この番で使った回数。実際の戦略上意味のある
    # 使用回数を大きく超えて上限に達したら合法手から除外し、自分のポケモン間でエネルギーを行ったり来たり
    # させ続けて対局が終わらなくなる退化ループを防ぐ(legal_actions._UNLIMITED_ABILITY_USE_CAP)
    shielded_until_turn: int = 0  # 「相手の次の番、ワザの効果を受けない」対象。相手(攻撃側)のturns_taken基準で判定(0なら無効)
    damage_reduction_amount: int = 0  # 「相手の次の番、受けるダメージ-N」の軽減量(ヒスイヌメルゴンVSTARの「ローリングアイアン」等)
    damage_reduction_until_turn: int = 0  # 上記の有効期限。相手(攻撃側)のturns_taken基準で判定(0なら無効)
    no_energy_attach_until_turn: int = 0  # 「相手は次の番、手札からこのポケモンにエネルギーをつけられない」(Cross Slicer)。持ち主のturns_taken基準
    no_evolve_until_turn: int = 0  # 「相手は次の番、このポケモンを進化させられない」(Time Freeze)。持ち主のturns_taken基準
    heal_blocked_turn: int = 0  # 「相手の次の番、このポケモンはダメージを回復できない」: 持ち主のturns_takenがこの値の番の間だけ有効
    incoming_damage_bonus_until_turn: int = 0  # 「相手の次の番、このポケモンが受けるワザのダメージ+N(弱点・抵抗力のあと)」(Pivot Throw等)。攻撃側のturns_taken基準
    incoming_damage_bonus_amount: int = 0
    abilities_off_until_turn: int = 0  # 「相手のこのポケモンは、あなたの次の番の終わりまで特性を持たない」(Gastro Acid)。攻撃側(相手)のturns_taken基準
    attack_bonus_until_turn: int = 0  # 「自分の次の番、このポケモンのワザ(またはattack_bonus_attack_nameのワザ)のダメージ+N」(Echoed Voice等)。
    # 自分の番のturns_takenがこの値と一致する番だけ有効
    attack_bonus_amount: int = 0
    attack_bonus_attack_name: str = ""
    no_weakness_until_turn: int = 0  # 「相手の次の番、このポケモンは弱点を持たない」。相手(攻撃側)のturns_taken基準
    damage_prevent_threshold_until_turn: int = 0  # 「相手の次の番、ワザのダメージがN以下なら防ぐ」(Harden)。相手のturns_taken基準
    damage_prevent_threshold: int = 0
    current_attack_name: str = ""  # いま使っているワザの名前(ワザ名つきの効果の判定用。ワザを使うたびに更新する)
    attack_coinflip_until_turn: int = 0  # 「相手の次の番、このポケモンがワザを使おうとしたら、相手がコインを投げる。ウラならそのワザは失敗」
    # (ヤナップ等の「Attract」)の有効期限。attack_disabled_until_turnと同じく持ち主自身のturns_taken基準
    attack_disabled_until_turn: int = 0  # 「相手の次の番、このポケモンは攻撃できない」(アイアンバンドルの「冷凍ストリーム」等)。プレイヤー単位のattack_locked_until_turnと異なりポケモン単位
    retreat_disabled_until_turn: int = 0  # 「相手の次の番、このポケモンはにげられない」(デスバーンの「Shadow Bind」等)
    evolution_history: list[str] = field(default_factory=list)  # 進化前のcard_idを古い順に積んだスタック(退化ワザ用)
    destiny_bond_until_turn: int = 0  # 「相手の次の番、このポケモンをきぜつさせたポケモンも道連れできぜつ」(Gastlyの「Destiny Bond」)。相手(攻撃側)のturns_taken基準で判定(0なら無効)
    retaliate_on_damaged_until_turn: int = 0  # 「相手の次の番、このポケモンがワザのダメージを受けたら攻撃したポケモンにダメカン」(テツノイサハexの「Repulsor Axe」)。相手(攻撃側)のturns_taken基準で判定(0なら無効)
    retaliate_on_damaged_counters: int = 0  # 上記で乗せるダメカンの個数
    retaliate_equal_damage: bool = False  # True: 上記のダメカンの個数ではなく、受けたダメージと同じ数のダメカンをのせる(Right Back at You)
    ko_attacker_card_id: str = ""  # このポケモンを相手のワザのダメージできぜつさせたポケモンのcard_id(サイド枚数を変える特性の判定用)
    forced_attack_name: str | None = None  # 「相手の次の番、このポケモンはこのワザしか使えない」(Encore)。持ち主自身のturns_taken基準
    forced_attack_until_turn: int = 0
    type_override: str = ""  # 「次の自分の番の終わりまで、このポケモンは指定のタイプになる」(Type Switch)。持ち主自身のturns_taken基準
    type_override_until_turn: int = 0
    coin_count_override_attack: str = ""  # 「次の自分の番、このポケモンの〇〇のワザで投げるコインの数がN枚になる」(Exciting Shake)
    coin_count_override_amount: int = 0
    coin_count_override_until_turn: int = 0
    damage_coin_shield_until_turn: int = 0  # 「相手の次の番、このポケモンがワザのダメージを受けるたびコインを投げ、オモテならそのダメージを防ぐ」(Afterimage Strike)。相手(攻撃側)のturns_taken基準
    effect_shield_until_turn: int = 0  # 「相手の次の番、ワザの効果(ダメージを除く)を受けない」(Light Pulse)。相手(攻撃側)のturns_taken基準
    last_attack_damage_taken: int = 0  # 直近に相手のワザで受けたダメージ(last_attack_damage_turnと同じ番のぶんの合計)。Vengeful Wish用
    last_attack_damage_turn: int = 0  # 上記を受けたときのstate.turn_number
    attach_counters_until_turn: int = 0  # 同様の間、手札からエネルギーをつけるたびにダメカンをのせる(Electrified Incisors)
    attach_counters_amount: int = 0
    shield_vs_ability_until: int = 0  # この値以下の相手のturns_takenの間、特性を持つポケモンのワザのダメージを受けない(Psy Protection)
    evolution_damage_reduction_until: int = 0  # 同様の間、進化ポケモンのワザのダメージを軽減する(Metal Block)
    evolution_damage_reduction_amount: int = 0
    next_turn_attack_bonus: int = 0  # 「自分の次の番、このポケモンのワザは+N」(No Reprieve/Slumbering Smack)
    next_turn_attack_bonus_until: int = 0  # 上の効果が有効な、このポケモンの持ち主のturns_taken
    ex_attack_shield_until: int = 0  # この値以下の、相手(攻撃側)のturns_takenの間、相手のポケモンexのワザのダメージも効果も受けない(Acerola's Mischief)
    energy_to_hand_only_type: str | None = None  # energy_to_hand_pendingが指定タイプの基本エネルギーだけを手札に加えるとき(Diver's Catch)
    energy_to_hand_pending: bool = False  # エナジーポーチ: きぜつしたとき、ついていた基本エネルギーを手札に加える(win_conditions参照)
    rescued_to_deck_pending: bool = False  # セレビィの「Leap Through Time」: きぜつしたとき、トラッシュではなく山札に戻す(win_conditions参照)
    rescued_to_hand_pending: bool = False  # このポケモンが相手のワザのダメージできぜつする瞬間の一時フラグ。win_conditions.apply_knockoutsがこれを見て、トラッシュではなく手札に戻す(スプラッシュエネルギー用)
    damage_immunity_until_turn: int = 0  # 「相手の次の番、特定の種類のポケモンのワザによるダメージを受けない」の有効期限。相手(攻撃側)のturns_taken基準で判定(0なら無効)
    delayed_removal_turn: int = 0  # 「相手の次の番の終わりに、きぜつする/トラッシュされる」(Doom Desire/Cacophony): そのプレイヤーのturns_taken
    delayed_removal_mode: str = ""
    attack_cost_extra: int = 0  # 「相手の次の番、このポケモンのワザのコストが無色N個ふえる」(Sticky Shot): state.turn_numberがこの値以下の間有効
    attack_cost_extra_until_turn_number: int = 0
    retreat_cost_extra: int = 0
    retreat_cost_extra_until_turn_number: int = 0
    bide_until_turn: int = 0  # Bide: このターン番号(相手のturns_taken基準)まで、ワザのダメージできぜつしても残りHP10で耐える
    ko_if_damaged_until_turn: int = 0  # Allergic Shock: 攻撃側のturns_takenがこの値以下の間、ワザのダメージを受けたらきぜつ
    ko_retaliate_discard_until_turn: int = 0  # Little Grudge: ワザできぜつしたとき、攻撃したポケモンのエネルギーを1枚トラッシュ
    status_immune_until_turn: int = 0  # Shining Breath: 相手のturns_takenがこの値以下の間、特殊状態にならない
    weakness_override_type: str = ""  # Conversion 3/Trick Sticker: 弱点のタイプの書き換え
    weakness_override_until_turn_number: int = 0
    sleep_on_attach_until_turn: int = 0  # Boo-Hoo: 持ち主のturns_takenがこの値以下の間、手札からエネルギーをつけられたらねむりになる
    persistent_attack_bonus: int = 0  # Dragon Dance: バトル場にいる間、ワザのダメージ+N(persistent_bonus_became_active_turnがbecame_active_turnと同じ間)
    persistent_bonus_became_active_turn: int = -2
    shield_scope: str = ""  # 「相手の次の番、◯◯ポケモンによるワザの効果(ダメージを含む)を受けない」の対象種別(era_primitives_f.ApplyScopedShieldToSelf)
    shield_scope_until_turn: int = 0
    damage_immunity_scope: str = ""  # 上記の対象種別: "basic"(たねポケモン)/"evolution"(進化ポケモン)/"gx_ex"(GX・EXポケモン)
    damage_debuff_until_turn: int = 0  # 「次の自分の番、このワザの基本ダメージがNになる」の有効期限(マギアナEXの「Soul Blaster」)。自分自身のturns_taken基準で判定(0なら無効)
    became_active_turn: int = -1  # ベンチからバトル場に出た(にげる/入れ替え等で)自分の番の番号。ガチガチンGXの「First Impression」/れんげきウーラオスVMAXの「Gale Thrust」用(にげる/SwitchActiveWithBench経由のみ対応、きぜつ後の新アクティブ選択等は未対応)
    no_prize_on_ko_until_turn: int = 0  # 「相手の次の番の間にきぜつしても、相手はサイドを取れない」の有効期限。相手(攻撃側)のturns_taken基準で判定(0なら無効)。ポイポル(FLI版)の「Knockout Reviver」用
    outgoing_damage_debuff_until_turn: int = 0  # 「相手の次の番の間、このポケモンが使うワザのダメージが少なくなる」の有効期限(チコリータの「Growl」等)。このポケモンの持ち主のturns_taken基準で判定(0なら無効)
    outgoing_damage_debuff_amount: int = 0  # 上記の軽減量
    attack_lock_name: str = ""  # 「バトル場を離れるまで、このワザをもう使えない」の対象のワザ名
    attack_lock_marker: int = -99  # 上を使ったときのbecame_active_turn(同じ値のあいだはロック)
    extra_damage_taken: int = 0  # 「自分の次の番、このポケモンはワザのダメージをN多く受ける」の量
    extra_damage_taken_turn: int = 0  # 上の効果が有効な、攻撃側のturns_taken(その番だけ)
    delayed_counters: int = 0  # 「相手の次の番の終わりに、このポケモンにダメカンをN個のせる」の個数
    delayed_counters_turn: int = 0  # 上の効果が発動する、このポケモンの持ち主のturns_taken(その番の終わり)
    hit_by_calculated_attack_damage: bool = False  # 直近のワザで(ダメージ計算を経由した)実際のダメージを受けたか一時フラグ。
    # ダメカンを直接のせる効果(ドラパルトexの「Phantom Dive」の追加ダメカン部分等)では立たない。
    # レガシーエネルギーの「相手のワザによるダメージできぜつしたら」/毒リベンジ系「相手のワザできぜつしていたら」
    # 判定はこちらの「ダメージ」限定の意味で、effects.primitives.resolve_attack_damageの末尾で立てられ、
    # engine.rules_engine._mark_ko_by_attackが読んで都度リセットする(2026-08-25の公式FAQ監査で発覚)。

    def __setstate__(self, state: dict) -> None:
        _fill_missing_fields_with_defaults(self, state)
        self.__dict__.update(state)

    def remaining_hp(self, max_hp: int) -> int:
        return max(0, max_hp - self.damage)

    def is_knocked_out(self, max_hp: int) -> bool:
        return self.remaining_hp(max_hp) <= 0

    def heal(self, amount: int) -> None:
        self.damage = max(0, self.damage - amount)

    def remove_counters(self, amount: int) -> None:
        """ダメカンを取り除く(「移す」効果の移動元用。回復ではないのでHeal Blockの影響を受けない)。"""
        self.__dict__["damage"] = max(0, self.damage - amount)  # 移動は回復ではないので、healed_this_turnは立てない


@dataclass
class PlayerState:
    deck: list[str] = field(default_factory=list)
    hand: list[str] = field(default_factory=list)
    discard: list[str] = field(default_factory=list)
    lost_zone: list[str] = field(default_factory=list)  # ロストゾーン(トラッシュと違いゲーム外に除外されたカード)
    prizes: list[str] = field(default_factory=list)  # 裏向きのサイド(カードID保持、内容は非公開情報として扱う)
    prize_marks: list[int] = field(default_factory=list)  # サイドの各スロットの公開状態(prizesと同じ並び)。
    # 0=裏向き(本人も中身を知らない) / 1=本人だけが中身を見た(ベベノムの「Eye Opener」) / 2=表向き(両者に公開、
    # タウンマップ)。空リスト、または長さがprizesと食い違う間は全て0(裏向き)として扱う。サイドへの出し入れは
    # take_prize/add_prizes/reset_prize_marksを経由して、この並びを保つこと。
    active: PokemonInPlay | None = None
    bench: list[PokemonInPlay] = field(default_factory=list)

    known_opponent_hand: list[str] = field(default_factory=list)  # 「デンジュモクGXのLighting-GX」等、
    # 相手の手札を公開させる効果でこのプレイヤーが過去に見た相手の手札の中身のスナップショット
    # (公開時点でこのプレイヤーのknown_opponent_handを上書きする)。人間のプレイヤーは画面で見た
    # 内容を対局中ずっと覚えていられるが、状態だけを見て毎回判断するAIの設計では「今の状態」以外を
    # 記憶できないため、以前はこの種の情報がAIにとって公開直後の1手にしか使えなかった
    # (2026-08-20、ユーザー指摘を受けて追加)。実際に今もなお相手の手札に残っているかどうかは
    # rl_env.encoding側で実際のhand内容と突き合わせてクランプする(このフィールド自体は
    # 「見た時点のスナップショット」を保持するだけで、以後の増減は自動追跡しない)。

    energy_attached_this_turn: bool = False
    supporter_played_this_turn: bool = False
    stadium_played_this_turn: bool = False
    retreated_this_turn: bool = False
    turns_taken: int = 0
    coin_first_forced: int = -1  # この番、最初に投げるコインの結果を決めてある(-1=無し/0=オモテ/1=ウラ)(ウィル)。使うと-1に戻る
    end_turn_draw_to: int = 0  # 「この番の終わりに、手札がN枚になるまで引く」(ブルーのたくらみ)。番の終わりの処理が読んで0に戻す
    star_order_turn: int = -1  # スカイシールストーンの「スターオーダー」を使った番(turns_taken)
    eot_tool_done_turn: int = -1  # 番の終わりに選ぶどうぐ(パワフルグラス)を、その番にもう処理したか(turns_taken)
    end_turn_hand_limit: tuple | None = None  # 「この番の終わりに、手札がA枚以上なら、B枚になるまで手札を山札に戻す」(リーリエの全力)。(A, B)
    gx_override_this_turn: list = field(default_factory=list)  # この番、GXワザを使ったあとでも使えるポケモン("name:ジガルデGX"/"type:Water")
    ignore_defender_effects_subtype_this_turn: str | None = None  # この番、このサブタイプのポケモンのワザのダメージは、相手のバトルポケモンにかかっている効果を受けない(ウルトラフォレスト カートボーイ)
    used_gx_attack_this_game: bool = False  # GXワザは1ゲームに1回まで(カード問わずプレイヤー単位)
    used_vstar_power_this_game: bool = False  # VSTARパワーも同様に1ゲームに1回まで
    gx_attacks_locked: bool = False  # ラティオスGXの「Clear Vision-GX」: 相手はこのゲーム中GXワザを一切使えない
    attack_locked_until_turn: int = 0  # 「相手の次の番、ワザを使えない」(アイアンルールGX等)。自分自身のturns_taken基準
    used_stadium_ability_this_turn: bool = False  # 「各プレイヤーの番に1回」使えるスタジアム効果(ウルトラスペース等)
    metal_damage_reduction_active: bool = False  # 「今後ずっと、自分の鋼ポケモンが受けるダメージ-30」(フルメタルウォールGX)。ターン限定のダメージ軽減と違いゲーム終了まで継続する
    ex_damage_immunity_until_turn: int = 0  # 「相手の次の番、自分のポケモン全員がポケモンEXから受けるダメージを防ぐ。このポケモンがバトル場を離れたら終わり」(Diamond Force)。相手(攻撃側)のturns_taken基準
    ex_damage_immunity_source: object = None  # 上記の効果の持ち主(PokemonInPlay)。バトル場にいる間だけ有効
    coins_tails_until_turn: int = 0  # 「相手の次の番、コインを投げるたびウラとして扱う」(Slap of Misfortune等)。自分自身のturns_taken基準
    no_turn_draw_on_turn: int = 0  # 「次の自分の番のはじめに山札を引けない」(Heart Wink)。このturns_takenの番のドローをなくす
    ko_by_attack_names_pending: list = field(default_factory=list)  # 現在進行中の相手の番の間に、相手のワザのダメージできぜつした自分のポケモンの名前
    ko_by_attack_names_last_turn: list = field(default_factory=list)  # 直前の相手の番の上記(Retributionの判定用)
    attack_bonus_rules_this_turn: list = field(default_factory=list)  # この番の間の「〜のポケモンのワザは+N」: [{"amount","spec","per_prize","ignore_defender_effects"}, ...](グラント/カレンの信念/フィービ等)
    attack_bonuses_this_turn: list = field(default_factory=list)  # この番の間の「(基本)〇タイプのポケモンのワザは+N」: [(タイプ, ダメージ, たねのみか), ...](Steam Up等)
    used_ability_names_this_turn: list = field(default_factory=list)  # この番に使った特性の名前(「同名の特性は1つしか使えない」特性用)
    supporters_played_count_this_turn: int = 0  # この番に使ったサポートの枚数(Dual Brains: サポートを2枚使える特性用)
    supporters_locked_until_turn: int = 0  # 「相手の次の番、サポートを使えない」(Blockade等)。自分自身のturns_taken基準
    items_locked_until_turn: int = 0  # 「相手の次の番、グッズを使えない」(オーシャンカース/かゆいかふん等)。自分自身のturns_taken基準
    poisoned_cant_retreat_until_turn: int = 0  # ロクシーの気迫(Roxie's Performance)実カードテキスト:
    # 「相手の次の番の間、どくのポケモンはにげられない(新しくどくになったポケモンも含む)」。
    # 特定のポケモンではなくプレイヤー単位のウィンドウとして持ち、にげる判定時に現在どくかどうかを
    # 都度チェックする(新しくどくになったポケモンにも遡って効くため、個別ポケモンのフラグでは表現できない)。
    pokemon_ko_by_attack_pending: bool = False  # 現在進行中の相手の番の間に、自分のポケモンが相手のワザできぜつしたか
    pokemon_ko_by_attack_last_turn: bool = False  # 直前の相手の番の間に、自分のポケモンが相手のワザできぜつしていたか(毒リベンジ等の判定用)
    pokemon_ko_pending: bool = False  # 現在進行中の相手の番の間に、自分のポケモンが(原因を問わず)きぜつしたか
    pokemon_ko_last_turn: bool = False  # 直前の相手の番の間に、自分のポケモンが(原因を問わず)きぜつしていたか(Fezandipiti exの「Flip the Script」判定用)
    ko_types_pending: list = field(default_factory=list)  # 現在進行中の相手の番の間にきぜつした自分のポケモンのタイプ(「Fairyポケモンがきぜつしていたら」等の判定用)
    ko_types_last_turn: list = field(default_factory=list)  # 直前の相手の番の上記
    team_rocket_pokemon_ko_pending: bool = False  # 現在進行中の相手の番の間に、自分の「Team Rocket's」ポケモンがきぜつしたか
    team_rocket_pokemon_ko_last_turn: bool = False  # 直前の相手の番の間に、自分の「Team Rocket's」ポケモンがきぜつしていたか(ロケット団のアポロ判定用)
    bonus_prize_next_knockout: int = 0  # 「このワザできぜつさせた場合、追加でサイドを1枚多く取れる」(アイアンハンドexの「ばんばんハンド」等)。apply_knockoutsで消費後リセットする
    bonus_prize_if_tera_ko_this_turn: bool = False  # 「この番の間、自分のテラスタルポケモンのワザできぜつさせたら追加でサイド+1」(ブライアー等)。ターン終了時にリセットする
    legacy_energy_prize_denial_used: bool = False  # レガシーエネルギー実カードテキスト: 「ついているポケモンが相手のワザによるダメージできぜつしたら、
    # 相手が取るサイドが1枚減る。この効果は1ゲームに1回まで」。1ゲーム通して1回きりなのでリセットしない
    last_turn_attack_used: tuple[str, str] | None = None  # 自分の前の番に使ったワザ(番の開始時にlast_attack_usedから移す)
    last_attack_used: tuple[str, str] | None = None  # 直前の自分の番で使ったワザ(card_id, attack_name)。ミミッキュの「コピーキャット」判定用。自分の番の開始時にリセットする
    used_discard_ability_this_turn: bool = False  # トラッシュにいる状態で発動する特性(ギラティナの「Distortion Door」等)を既に使ったか。「1回の自分の番に1回」制限用
    fusion_strike_damage_bonus_until_turn: int = 0  # パワータブレット: この番の間、自分のFusion Strikeポケモンのワザは相手のバトルポケモンに+30(turns_takenがこの値以下の間有効)
    ex_v_bonus_damage_until_turn: int = 0  # スグリ(Kieran): この番の間、自分のワザは相手のバトル場のex/Vポケモンに+30(turns_takenがこの値以下の間有効)
    tools_locked_until_turn: int = 0  # Chaos Wheel: 手札からポケモンのどうぐを使えない(turns_takenがこの値以下の間)
    special_energy_locked_until_turn: int = 0  # 手札から特殊エネルギーをつけられない
    stadiums_locked_until_turn: int = 0  # 手札からスタジアムを使えない
    evolve_locked_until_turn: int = 0  # Evolution Jammer: 手札のポケモンで進化できない
    trainer_coin_until_turn: int = 0  # Dizzying Wind: トレーナーズを使うたびコイン。ウラなら効果なし
    damage_bonus_flat_this_turn: int = 0  # プラスパワー等: この番の間、自分のワザは相手のバトルポケモンに+N(弱点・抵抗力適用前)
    damage_bonus_per_prize_this_turn: int = 0  # アイリス: この番の間、相手がとったサイド1枚につき+N
    ex_bonus_damage_40_until_turn: int = 0  # からておうの稽古(Black Belt's Training): この番の間、自分のワザは相手のバトル場のexポケモンに+40(turns_takenがこの値以下の間有効)
    hand_cards_locked_until_turn: int = 0  # この値以下のturns_takenの間、手札からカードを一切使えない(「相手は次の番、手札からカードを使えない」)
    prizes_taken_this_turn: int = 0  # この番(次の自分の番の開始まで保持)にとったサイドの枚数(Settle the Score: 相手が直前の番にとった枚数)
    special_energy_attach_locked_until_turn: int = 0  # この値以下のturns_takenの間、手札から特殊エネルギーをつけられない(Bind Pulse)
    end_of_turn_discard_energy: list = field(default_factory=list)  # つけた番の終わりにトラッシュするエネルギー(ダブルアクア/ダブルマグマ): (ポケモン, エネルギーID)
    supporters_allowed_this_turn: int = 1  # この番に使えるサポートの枚数(Lt. Surge's Strategy: 3枚)
    damage_reductions: list = field(default_factory=list)  # 「相手の次の番、自分の〜ポケモンが受けるダメージを軽減/無効」の効果(Iron Defender/Lusamine等)。
    # 要素: {"type": タイプ|None, "subtype": サブタイプ|None, "amount": 軽減量(Noneなら全て無効), "until": 相手(攻撃側)のturns_takenがこの値以下の間有効}
    bonus_prize_name_prefix_this_turn: tuple | None = None  # (カード名の接頭辞, 追加サイド枚数): この番、その名前のポケモンのワザできぜつさせたら追加でサイドを取る(Anthea & Concordia)
    supporter_names_this_turn: list = field(default_factory=list)  # この番に使ったサポートの名前(「この番、〇〇を手札から使っていたら」特性用)
    team_rocket_supporter_played_this_turn: bool = False  # この番中に名前に「Team Rocket's」を含むサポートを使ったか(ロケット団のファクトリー判定用)
    active_abilities_blocked_on_turn: int = -1  # このプレイヤーのバトルポケモンの特性が封じられている番(state.turn_number、
    # -1なら無効)。キャンセリングコロン: 「自分の番の終わりまで、相手のバトルポケモンは特性を持たない(その番に出たポケモンも含む)」
    pending_second_attack: bool = False  # ホルビーの「Ω Barrage」/カミッチュの「おまつりおんど」: 1回目のワザ後、2回目を使うか選べる状態
    used_attack_twice_bonus_this_turn: bool = False  # 上記の「2回目のワザ」を、この番で既に使った(または放棄した)か。1番につき1回まで

    def __setstate__(self, state: dict) -> None:
        _fill_missing_fields_with_defaults(self, state)
        self.__dict__.update(state)

    def prize_mark(self, index: int) -> int:
        if len(self.prize_marks) != len(self.prizes) or not (0 <= index < len(self.prize_marks)):
            return 0
        return self.prize_marks[index]

    def take_prize(self, index: int = -1) -> str:
        """サイドのindex番目を取り除いて返す(公開状態の並びも一緒に取り除く)。"""
        in_sync = len(self.prize_marks) == len(self.prizes)
        self.prizes_taken_this_turn += 1
        card = self.prizes.pop(index)
        if in_sync:
            self.prize_marks.pop(index)
        else:
            self.prize_marks = []
        return card

    def add_prizes(self, card_ids: list[str]) -> None:
        """カードを裏向きのサイドに加える。"""
        if len(self.prize_marks) != len(self.prizes):
            self.prize_marks = [0] * len(self.prizes)
        self.prizes.extend(card_ids)
        self.prize_marks.extend([0] * len(card_ids))

    def reset_prize_marks(self) -> None:
        self.prize_marks = []

    def mark_all_prizes(self, mark: int) -> None:
        """今あるサイド全てを、指定の公開状態にする(既により公開された状態のものは下げない)。"""
        current = [self.prize_mark(i) for i in range(len(self.prizes))]
        self.prize_marks = [max(m, mark) for m in current]

    def all_pokemon_in_play(self) -> list[PokemonInPlay]:
        result = []
        if self.active is not None:
            result.append(self.active)
        result.extend(self.bench)
        return result

    def reset_turn_flags(self) -> None:
        self.energy_attached_this_turn = False
        self.coin_first_forced = -1
        self.end_turn_draw_to = 0
        self.end_turn_hand_limit = None
        self.gx_override_this_turn = []
        self.ignore_defender_effects_subtype_this_turn = None
        self.supporter_played_this_turn = False
        self.supporters_played_count_this_turn = 0
        self.used_ability_names_this_turn = []
        self.supporter_names_this_turn = []
        self.prizes_taken_this_turn = 0
        self.supporters_allowed_this_turn = 1
        self.bonus_prize_name_prefix_this_turn = None
        self.attack_bonuses_this_turn = []
        self.attack_bonus_rules_this_turn = []
        self.damage_bonus_flat_this_turn = 0
        self.damage_bonus_per_prize_this_turn = 0
        self.team_rocket_supporter_played_this_turn = False
        self.stadium_played_this_turn = False
        self.retreated_this_turn = False
        self.used_stadium_ability_this_turn = False
        self.ko_by_attack_names_last_turn = self.ko_by_attack_names_pending
        self.ko_by_attack_names_pending = []
        self.pokemon_ko_by_attack_last_turn = self.pokemon_ko_by_attack_pending
        self.pokemon_ko_by_attack_pending = False
        self.pokemon_ko_last_turn = self.pokemon_ko_pending
        self.pokemon_ko_pending = False
        self.ko_types_last_turn = self.ko_types_pending
        self.ko_types_pending = []
        self.team_rocket_pokemon_ko_last_turn = self.team_rocket_pokemon_ko_pending
        self.team_rocket_pokemon_ko_pending = False
        self.bonus_prize_if_tera_ko_this_turn = False
        self.last_turn_attack_used = self.last_attack_used  # 「自分の前の番に使ったワザ」(メワツーの「Barrier」の連続使用禁止用)
        self.last_attack_used = None
        self.used_discard_ability_this_turn = False
        self.pending_second_attack = False
        self.used_attack_twice_bonus_this_turn = False
        for mon in self.all_pokemon_in_play():
            mon.used_ability_this_turn = False
            mon.unlimited_ability_uses_this_turn = 0


@dataclass
class PendingSearchChoice:
    """山札/トラッシュから選んで手札に加える効果の途中経過(ハイパーボール等)。

    候補はトリガー時点でのzone内位置(source_indices)をcard_idsと対で保持する。
    保留中は他の行動を挟めないため、確定処理までzoneの中身は変化しない前提でよい。
    """

    player_index: int
    zone: str  # "deck" | "discard" | "hand" (通常の検索) | "field_attachment" | "own_pokemon_target" | "own_pokemon_energy_target" (場のポケモン自体/装着カードを選ぶ新種別、_handle_resolve_search_choiceで早期分岐して専用解決する)
    source_indices: list  # 通常zoneではint(pop用インデックス)、新zoneではタプル(例: ("tool", side, slot))等、zone依存の任意の値
    card_ids: list[str]
    min_count: int
    max_count: int
    prompt: str
    shuffle_after: bool = True
    allowed_counts: tuple | None = None  # 指定時は、選べる枚数をこの中のものだけに限る(「2枚トラッシュしてもよい」=0枚か2枚のみ、
    # 1枚だけ選ぶことはできない)。min_count/max_countの範囲内で、さらに絞り込む
    exclusive_subtype: str | None = None  # 指定時は、選択が「そのサブタイプのカードをちょうど1枚だけ」か「そのサブタイプを含まない
    # カードだけ(複数可)」のどちらかでなければならない(プラターヌ博士の贈り物: "1 Basic Pokémon-EX or 3 Basic Pokémon
    # (except for Pokémon-EX)")
    all_card_ids: list[str] = field(default_factory=list)  # ALLフィルタ用: zone全体のスナップショット(参照のみ、選択不可のものも含む)
    remaining_to_bottom: bool = False  # True: 選ばなかったカードをzoneの一番下に送る(トレードオフ等、「見て1枚選ぶ」系の効果用)
    remaining_to_discard: bool = False  # True: 選ばなかったカードをトラッシュに送る(アクロバイク/ハプウ等、実カードテキストが"Discard the other card(s)"と明記している場合用)
    destination: str = "hand"  # "hand" | "bench" | "discard"(ハイパーボール等) | "deck"(ポケモン通信、手札のポケモンを山札に戻す) | "attach_energy"(選んだエネルギーを直接つける)
    attach_target_pokemon: "PokemonInPlay | None" = None  # destination="attach_energy"のときの添付先(直接参照)
    remaining_script: tuple = field(default_factory=tuple)  # この選択が確定した後に続けて実行する効果(1つのカード効果中に選択が複数回挟まる場合用)
    cont_source_pokemon: "PokemonInPlay | None" = None  # remaining_script再開用(EffectContext再構築に必要)
    cont_source_card_id: str = ""
    cont_acting_player: int | None = None  # remaining_script再開用: 選ぶのが相手(player_index)でも、続きの効果は元の効果を使った側(ここ)として実行する(ジェシー&ジェームズ等)
    cont_target_bench_index: int | None = None  # remaining_script再開用: 選択が挟まる前のEffectContext.target_bench_index
    # を引き継ぐ(例: ワザの「相手ベンチ1匹を選ぶ」対象指定が、選択の途中で組み立て直されるEffectContextから
    # 消えてしまい、選択解決後に続くDealBonusDamageToChosenOpponentBench等が対象を見失う不具合、2026-09-01発覚)。
    source_card_id: str = ""  # この検索選択を発生させたカードのcard_id(_trigger_search_choice経由のみ設定、
    # 2026-09-10追加)。禁止行動(data/prohibited_actions.md参照)で特定カード限定の制限をかける際、
    # 「今この検索選択がどのカードから来たか」を判定するために使う。cont_source_card_idとは別物
    # (そちらはremaining_script再開用のEffectContext再構築専用)。
    custom_data: object = None  # zone固有の追加情報(例: own_pokemon_energy_targetでの移動元スロット番号)。deck/hand/discard以外の新しいzone種別が使う汎用の受け皿
    reveal_to_opponent: bool = True  # False: 山札の中身を見て選ぶ系の効果で、実カードのテキストに
    # "reveal"の指定が無いもの(ドロンチの「ていさつしれい」等)。共有ログに具体的なカード名を出さない
    # (山札からの通常サーチ(Ultra Ball等、実カードが"reveal"を明記)はTrueのまま公開情報として扱う)。
    then_end_turn: bool = False  # ワザの効果として発生した保留か(True時、解決後にターンを終了する。
    # トレーナーズ/特性由来の保留は使用後もターンが続くためFalseのまま)。_handle_attackが設定する。
    effect_source: str = "attack"  # "attack" | "ability": この選択を発生させた効果がワザ由来か特性由来か
    # (remaining_scriptの続きをEffectContextに再構築する際、ミストエネルギー等の「ワザ限定」免疫を
    # 特性由来の効果に誤って適用しないため。ゲッコウガの「Water Shuriken」(手札のみずエネルギーを
    # 捨てて発動→ダメカンをのせる)等、特性の効果が選択を挟んで連鎖する場合に必要、2026-09-04)。


    def actor(self) -> int:
        """この選択の続き(remaining_script等)を実行するときの「効果を使ったプレイヤー」。"""
        return self.cont_acting_player if self.cont_acting_player is not None else self.player_index


@dataclass
class PendingDamageDistribution:
    """「ダメカンをN個、相手のポケモンに好きなように分配してよい」効果の途中経過
    (ミュウの「サイコパワー」等)。

    対象は相手のバトル/ベンチ(bench_only=Trueならベンチのみ)。ResolveDamageDistributionで
    各対象への配分数を確定する。
    """

    player_index: int
    total_counters: int
    bench_only: bool = False
    max_per_target: int | None = None
    source_card_id: str = ""
    target_own_side: bool = False  # True: 自分の場が対象(自滅ダメージ。ドサイドンEXの「Grenade Hammer」等)
    fixed_per_target: bool = False  # True: "好きなように"ではなく、選んだ対象全員にmax_per_target個ずつの固定配分
    then_end_turn: bool = False  # ワザの効果として発生した保留か(True時、解決後にターンを終了する)。_handle_attackが設定する。
    damage_per_counter: int = 10  # 1個あたりのダメージ量(通常のダメカンは10。オリーヴァexの
    # 「オイルマシンガン」実カードテキスト: "Choose 1 of your opponent's Pokémon 6 times.
    # (You can choose the same Pokémon more than once.) For each time you chose a Pokémon,
    # do 20 damage to it."のように、1回の「選択」が20ダメージぶんの効果もあるため可変にした
    # (以前は対象選択を1回だけに単純化し、複数体に振り分けられなかった)。
    effect_source: str = "attack"  # "attack" | "ability": DistributeDamageCountersFreely等を発動した
    # 効果がワザ由来か特性由来か(ResolveDamageDistributionでの免疫判定に必要。ルチャブルの
    # 「Flying Entry」/ギラティナ(smp-SM151)の「Distortion Door」等、特性由来でこのプリミティブを
    # 使うカードに、ミストエネルギー等の「ワザ限定」免疫を誤って適用しないため、2026-09-04)。


@dataclass
class PendingTrigger:
    """「〜出したとき、使ってもよい」系のポケパワー(ベンチに出た/レベルアップした瞬間の任意発動)の途中経過。

    上級ルールでは、この種のポケパワーは発動タイミングが来ても使うかどうかをプレイヤーが選べる(「してもよい」)。
    ここでは効果を確定実行せず、AcceptTrigger/DeclineTriggerで使う/使わないをプレイヤーに選ばせる。
    """

    player_index: int
    source_card_id: str
    mon: "PokemonInPlay"  # 発動元のポケモン(直接参照。GameStateはJSONへ直列化しないため参照保持で問題ない)
    script: tuple
    needs_target: bool = False
    target_kind: str = ""  # "opponent_bench" | "opponent_any" | "own_bench"
    then_end_turn: bool = False  # ワザの後に発動する「してもよい」系(ウーラオスVの「Strafe」等)。解決後にターンを進める
    override_kind: str = ""  # 特性以外(ワザ発動後の「してもよい」等)のときの表示用の種別ラベル
    override_label: str = ""  # 同上、名称ラベル(空なら特性名から自動生成する)
    attached_energy_id: str = ""  # エネルギー添付トリガーの場合、実際についたカードID(イーブイの「Energy Evolution」等、添付したエネルギーのタイプ判定に使う)
    mandatory: bool = False  # True: 「〜してもよい」ではなく必ず行う効果(ワープエネルギーの「入れ替える」等)。使わない(DeclineTrigger)を選べない


@dataclass
class PendingPowerSprayWindow:
    """パワースプレー(相手のポケパワー使用に割り込んで打ち消せるグッズ)の割り込みウィンドウ。

    ポケパワーの使用(UseAbility/AcceptTriggerのいずれか)が宣言された直後、実際に効果を解決する前に
    このウィンドウを開く。相手はUsePowerSpray(打ち消す)かPassPowerSprayWindow(何もしない)を選べる。
    使用側の「特性を使った」扱い(used_ability_this_turn等)は既にウィンドウを開く前に確定させておく
    (公式ルール通り、パワースプレーで打ち消されても「使った」ことにはなる)。
    """

    actor: int  # ポケパワーを使ったプレイヤー
    opponent_index: int  # パワースプレーを打てるプレイヤー(=応答する側)
    source_card_id: str
    mon: "PokemonInPlay"  # 発動元のポケモン(効果解決時にsource_pokemonとして使う)
    script: tuple
    target_bench_index: int | None = None


@dataclass
class GameState:
    players: tuple[PlayerState, PlayerState]
    current_player: int = 0
    turn_number: int = 1
    stadium_in_play: str | None = None
    stadium_owner: int | None = None
    stadium_orientation_target: int | None = None  # パラレルシティ等「出すときに向きを選べる」
    # スタジアム用: ↓側(効果を受ける側)のプレイヤー番号。向きの選択が無いスタジアムでは常にNone。
    is_first_turn_of_game: bool = True
    winner: int | None = None  # None=対局続行, 0/1=勝者, -1=引き分け
    win_reason: str | None = None  # "prizes"=サイド6枚, "no_pokemon"=場のポケモン全滅, "deck_out"=山札切れ
    # (勝敗が決まった原因。学習時の報酬整形で「自滅的な負け方(山札切れ)」と「相手に押し切られた
    # 負け方(ポケモン切れ)」を区別するために追加。2026-08-26)
    pending_active_choice: list[int] = field(default_factory=list)
    then_after_choice: str = "checkup"  # "checkup" | "advance" | "continue"
    then_end_turn_after_active_choice: bool = False  # ワザの効果(ダメカン配分等)の途中できぜつ→新
    # アクティブ選択が発生した場合、then_after_choice="continue"でもこの選択解決後にターンを終了させる
    # 必要があるかどうか(ファントムダイブ等。then_end_turn/custom_data stalenessバグ対策)。
    ruleset: Ruleset = field(default_factory=lambda: DEFAULT_RULESET)
    setup_complete: bool = True  # False の間は対戦準備フェーズ(バトルポケモンを自分で選ぶ)
    first_player: int = 0  # コイントスで先攻になったプレイヤー番号(players配列上の物理的な座席は固定のまま、
    # 先攻/後攻だけをここで管理する。deck_a/deck_bをplayers[0]/[1]に入れ替える方式だと、
    # Webアプリ側の「player0=常に人間」という前提が先攻後攻の結果次第で崩れてしまうため)
    setup_player: int = 0  # 対戦準備中: 今どちらのプレイヤーが選んでいるか(先攻→後攻の順)
    setup_active_chosen: list[bool] = field(default_factory=lambda: [False, False])
    pending_mulligan_bonus_draws: tuple[int, int] = (0, 0)  # 各プレイヤーが対戦準備完了後に引けるマリガンボーナスドロー枚数(相手との差分。両者がマリガンした場合は相殺され、回数の少ない側だけが差分ぶん引ける)
    mulligan_bonus_draw_pending_players: tuple[int, ...] = ()  # まだ「何枚引くか」を選んでいない
    # プレイヤーのインデックス一覧(先頭から順に選ぶ)。公式ルール上、マリガンボーナスドローは
    # 相手のマリガン回数まで好きな枚数を選んで引いてよく、必ず全部引く必要はない(以前は選択を
    # 挟まず自動で最大枚数を引いていた不具合、2026-09-01ユーザー報告で発覚)。
    pending_search_choice: PendingSearchChoice | None = None
    pending_trigger: PendingTrigger | None = None
    sibling_evolve_queue: list = field(default_factory=list)  # 「別の同名ポケモンを進化させたとき」系の特性(イーブイの「Resonant Evolution」)を
    # まだ提案していない持ち主(PokemonInPlay)の待ち行列。先頭から順に1匹ずつ「使う/使わない」を聞く
    pending_damage_distribution: PendingDamageDistribution | None = None
    pending_power_spray_window: PendingPowerSprayWindow | None = None
    rng: random.Random = field(default_factory=random.Random)
    log: list[str] = field(default_factory=list)
    last_reveal: dict | None = None  # {"title": str, "card_ids": list[str]}。選択の余地なく機械的に
    # 解決する「山札の中身を見る」系の効果(ポケストップ等)で、テキストログだけでなく実際に
    # 見えたカードの画像も一度Web UIに表示するための非ブロッキングな通知(ゲーム進行には影響しない)。
    last_reveal_seq: int = 0  # last_revealが更新されるたびに+1する通し番号。Web UI側が「これは
    # まだ見せていない新しい通知か」を判定するための識別子として使う(以前はログ全体の行数
    # (常に増え続ける)をこの判定に使っており、last_reveal自体は対局開始後最初の1回のカード効果
    # 以降ずっと同じ内容のまま更新されていなくても、ログの行数は毎ターン増え続けるため、同じ
    # 通知が対局が終わるまでポーリングのたびに再表示され続けるバグになっていた。2026-08-21発覚。
    # ロケット団のドンカラスデッキ(ロトりぼう使用)との対戦で「山札の上から見えたカード」という
    # 通知がずっと出続けるという報告から発覚。
    global_ability_lock_owner: int = -1  # サポート「Hex Maniac」: 両プレイヤーの特性を封じる効果の対象プレイヤー(-1なら無効)
    global_ability_lock_until_turn: int = 0  # global_ability_lock_ownerのturns_takenがこの値以下の間、有効
    opponent_ability_lock_target: int = -1  # ゲッコウガの「Shadow Stitching」等: 特性を封じられる側のプレイヤー(-1なら無効、相手側のみが対象)
    opponent_ability_lock_until_turn: int = 0  # opponent_ability_lock_targetのturns_takenがこの値以下の間、有効
    picked_counter_source: object = None  # ダメカンを別のポケモンに移す特性(2段階の選択)で、1段階目に選んだポケモンと取り除いた個数
    picked_counter_count: int = 0
    ko_followups: list = field(default_factory=list)  # きぜつ時に発動するどうぐの効果(エキスパートシェア等)の待ち行列。effects/era_trainers.py参照
    forced_turn_end_after_ability: bool = False  # ザシアンVの「Intrepid Sword」/「Roar of the Sword」等「この特性を使ったら、自分の番はここで終わる」の一時フラグ
    played_card_destination: str | None = None  # いま使っているグッズ/サポート自身の行き先("hand"=手札に戻す/"prizes"=サイドに混ぜる)。使い終えたあとの処理が読んで消す。Noneなら通常どおりトラッシュ
    extra_turn_pending: bool = False  # 「この番のあと、もう1回自分の番を行う(ポケモンチェックは行わない)」(スプリーム パフGX等)。次のadvance_turnで同じプレイヤーが続ける

    def __setstate__(self, state: dict) -> None:
        _fill_missing_fields_with_defaults(self, state)
        self.__dict__.update(state)

    def opponent_index(self, player_index: int) -> int:
        return 1 - player_index

    def player(self, index: int) -> PlayerState:
        return self.players[index]

    def is_game_over(self) -> bool:
        return self.winner is not None

    def add_log(self, message: str) -> None:
        self.log.append(message)
