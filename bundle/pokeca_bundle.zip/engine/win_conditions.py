"""きぜつ処理・勝敗判定。

公式ルール:
- ワザ・カードの効果・特殊状態で残りHPが0になったポケモンは【きぜつ】する
- きぜつしたポケモンはついているカードごとトラッシュ、相手はきぜつした数ぶんサイドを取る
  (「サイドを取る」= 相手が自分自身のサイドから手札にカードを加えること)
- 負け条件: 自分のサイドをすべて取られた/自分の場にポケモンがいなくなった/山札切れで引けない
"""

from __future__ import annotations

from cards.card_db import CardDatabase, ROBO_SUBSTITUTE_POKEMON_ID, is_team_rockets_pokemon
from engine.continuous import effective_max_hp, wonder_kiss_active
from engine.display import card_name
from engine.energy import LEGACY_ENERGY_ID, energy_effect_present
from engine.state import GameState, PlayerState, PokemonInPlay, discard_attached_tool

LOST_CITY_STADIUM_ID = "swsh11-161"  # ロストシティ: きぜつしたポケモンはトラッシュの代わりにロストゾーンへ


def _apply_legacy_energy_prize_denial(defender: PlayerState, pokemon: PokemonInPlay, prize_count: int) -> int:
    """レガシーエネルギーがついたポケモンが、相手のワザによる実際のダメージ計算を経由したダメージ
    (pokemon.hit_by_calculated_attack_damage、ダメカンを直接のせる効果ではなく)できぜつしたなら、
    そのプレイヤーの「1ゲームに1回」の権利を消費して相手が取るサイドを1枚減らす。プレイヤー単位の
    pokemon_ko_by_attack_pendingではなく、このポケモン自身のフラグを見る必要がある: 同じワザの中で
    別のポケモンが計算ダメージできぜつし、このポケモンはダメカンをのせる効果(ドラパルトexの
    「Phantom Dive」の追加ダメカン等)だけできぜつした場合、この特典は発動しない
    (2026-08-25の公式FAQ監査で発覚・修正)。"""
    if (
        energy_effect_present(pokemon.attached_energy, LEGACY_ENERGY_ID)
        and pokemon.hit_by_calculated_attack_damage
        and not defender.legacy_energy_prize_denial_used
    ):
        defender.legacy_energy_prize_denial_used = True
        return max(0, prize_count - 1)
    return prize_count


_NAME_PREFIX_TOOL_PRIZE_DENIAL: dict[str, str] = {
    "sv9-151": "Lillie's",  # リーリエのしんじゅ(Lillie's Pearl)実カードテキスト: "If the Lillie's
    # Pokémon this card is attached to is Knocked Out by damage from an attack from your opponent's
    # Pokémon, that player takes 1 fewer Prize card."(レガシーエネルギーと違い1ゲーム1回の制限は無い)
}


def _apply_name_prefix_tool_prize_denial(
    card_db: CardDatabase, pokemon: PokemonInPlay, prize_count: int, tool: str | None = None
) -> int:
    """tool: きぜつした時点でついていたどうぐ(トラッシュ処理の後はpokemon.attached_toolが空になるため、呼び出し側が先に控えて渡す)。"""
    required_prefix = _NAME_PREFIX_TOOL_PRIZE_DENIAL.get((tool if tool is not None else pokemon.attached_tool) or "")
    if required_prefix is None or not pokemon.hit_by_calculated_attack_damage:
        return prize_count
    pokemon_card = card_db.get(pokemon.card_id)
    if pokemon_card is None or not pokemon_card.name.startswith(required_prefix):
        return prize_count
    return max(0, prize_count - 1)


def _max_hp(
    card_db: CardDatabase,
    card_id: str,
    attached_tool: str | None = None,
    stadium_in_play: str | None = None,
    attached_energy: list[str] | None = None,
) -> int:
    return effective_max_hp(card_db, card_id, attached_tool, stadium_in_play, attached_energy)


def apply_knockouts(state: GameState, card_db: CardDatabase) -> tuple[list[int], list[tuple[int, int]]]:
    """両プレイヤーのきぜつを処理する。戻り値は(新アクティブ選択が必要なプレイヤーのインデックス一覧,
    どのサイドを取るか選択が必要な(プレイヤーインデックス, 枚数)の一覧)。後者は実カードルール通り
    「残りサイドを見て自分で選んで取る」ため、取る枚数が残りサイド枚数未満(=選ぶ余地がある)ときのみ
    発生する(全部取る場合は選ぶ余地が無いので即座に取る)。呼び出し側(engine.rules_engine)は
    後者が空でなければPendingSearchChoiceを立てて選ばせ、解決後に前者の処理に進む。

    ベンチのきぜつを先に処理してからバトルポケモンのきぜつを見るのが重要: 1回のワザで
    バトルポケモンとベンチが同時にきぜつする場合(例: Tree Slamのような「バトルポケモンに
    ダメージ+ベンチ2体にもダメージ」系のワザ)、先にバトルポケモンだけ見て「ベンチが残っている」
    と判断してしまうと、実際にはそのベンチも同時にきぜつしていて場に何も残っていないのに
    「新しいバトルポケモンを選べる」と誤判定し、選択肢が存在しないまま手詰まりになってしまう。
    """
    needs_new_active: list[int] = []
    needs_prize_choice: list[tuple[int, int]] = []

    for player_index, player in enumerate(state.players):
        opponent_index = state.opponent_index(player_index)
        opponent = state.players[opponent_index]

        knocked_out_bench = [
            b for b in player.bench if b.is_knocked_out(_max_hp(card_db, b.card_id, b.attached_tool, state.stadium_in_play, b.attached_energy))
        ]
        from effects.era_trainers import collect_ko_followups, era_prize_denial

        for pokemon in knocked_out_bench:
            # pokemon_ko_pending/team_rocket_pokemon_ko_pendingは「相手の番の間に自分のポケモンが
            # きぜつしたか」(Unfair Stamp/Flip the Script等の発動条件、原因は問わない)。
            # 自分自身の番の間に、自分の特性等で自滅的にきぜつした場合(ヨノワールの「Cursed Blast」等)
            # は対象外のはずが、以前はここで現在の手番側を見ずに一律で立てていたため、自分の番中の
            # 自滅きぜつでも次の自分の番にこれらのカードが使えてしまっていた(2026-09-10ユーザー報告)。
            if player_index != state.current_player:
                player.pokemon_ko_pending = True
                pokemon_card = card_db.get(pokemon.card_id)
                if pokemon_card is not None:
                    player.ko_types_pending.extend(pokemon_card.types)
                if is_team_rockets_pokemon(pokemon_card):
                    player.team_rocket_pokemon_ko_pending = True
            player.bench.remove(pokemon)
            ko_tool = pokemon.attached_tool  # トラッシュ前に控える(サイド減少のどうぐの判定用)
            collect_ko_followups(state, card_db, player_index, pokemon, False)
            _apply_leap_through_time(state, card_db, player_index, pokemon)
            _discard_pokemon(state, player, pokemon, card_db)
            if pokemon.card_id == ROBO_SUBSTITUTE_POKEMON_ID:
                # みがわりロボ: "If this card is Knocked Out, your opponent can't take any Prize Cards for it."
                state.add_log(f"player{player_index} のベンチの {card_name(card_db, pokemon.card_id)} がきぜつ！ サイドは取れない")
                continue
            if pokemon.no_prize_on_ko_until_turn > 0 and opponent.turns_taken <= pokemon.no_prize_on_ko_until_turn:
                state.add_log(
                    f"player{player_index} のベンチの {card_name(card_db, pokemon.card_id)} がきぜつ！ "
                    f"「Knockout Reviver」によりサイドは取れなかった"
                )
                continue
            prize_count = 1 + (card_db.get(pokemon.card_id).extra_prize_count if card_db.get(pokemon.card_id) else 0)
            prize_count = _apply_legacy_energy_prize_denial(player, pokemon, prize_count)
            prize_count = _apply_name_prefix_tool_prize_denial(card_db, pokemon, prize_count, ko_tool)
            prize_count = max(0, prize_count - era_prize_denial(state, pokemon, ko_tool, card_db, pokemon.hit_by_calculated_attack_damage and player_index != state.current_player, False))  # ライフデュー
            from effects.passives import adjust_ko_prize

            prize_count = adjust_ko_prize(state, card_db, player_index, pokemon, prize_count)
            if prize_count <= 0:
                state.add_log(f"player{player_index} のベンチの {card_name(card_db, pokemon.card_id)} がきぜつ！ サイドは取れない(特性)")
                continue
            state.add_log(
                f"player{player_index} のベンチの {card_name(card_db, pokemon.card_id)} がきぜつ！ "
                f"player{opponent_index} がサイドを{prize_count}枚取る"
            )
            if not _take_prizes(opponent, prize_count, _prizes_discarded(state, ko_tool, pokemon, player_index)):
                needs_prize_choice.append((opponent_index, prize_count))

        knocked_out_active = (
            player.active is not None
            and player.active.is_knocked_out(_max_hp(card_db, player.active.card_id, player.active.attached_tool, state.stadium_in_play, player.active.attached_energy))
        )
        if knocked_out_active:
            pokemon = player.active
            ko_tool = pokemon.attached_tool
            collect_ko_followups(state, card_db, player_index, pokemon, True)
            _apply_leap_through_time(state, card_db, player_index, pokemon)
            if player_index != state.current_player:  # 上のベンチ側と同じ理由(自滅きぜつは対象外)
                player.pokemon_ko_pending = True
                active_card = card_db.get(pokemon.card_id)
                if active_card is not None:
                    player.ko_types_pending.extend(active_card.types)
                if is_team_rockets_pokemon(active_card):
                    player.team_rocket_pokemon_ko_pending = True
            _discard_pokemon(state, player, pokemon, card_db)
            player.active = None
            if pokemon.card_id == ROBO_SUBSTITUTE_POKEMON_ID:
                opponent.bonus_prize_next_knockout = 0
                state.add_log(f"player{player_index} の {card_name(card_db, pokemon.card_id)} がきぜつ！ サイドは取れない")
            elif pokemon.no_prize_on_ko_until_turn > 0 and opponent.turns_taken <= pokemon.no_prize_on_ko_until_turn:
                opponent.bonus_prize_next_knockout = 0
                state.add_log(
                    f"player{player_index} の {card_name(card_db, pokemon.card_id)} がきぜつ！ "
                    f"「Knockout Reviver」によりサイドは取れなかった"
                )
            else:
                prize_count = (
                    1
                    + (card_db.get(pokemon.card_id).extra_prize_count if card_db.get(pokemon.card_id) else 0)
                    + opponent.bonus_prize_next_knockout
                )
                opponent.bonus_prize_next_knockout = 0
                if wonder_kiss_active(state, card_db, opponent) and state.rng.random() < 0.5:
                    # トゲキッス「Wonder Kiss」: 相手(=このプレイヤーから見たopponent)のバトルポケモンが
                    # きぜつしたとき、コインを1回投げオモテなら追加でサイド+1(重複しない)。
                    prize_count += 1
                    state.add_log(f"player{opponent_index} の「Wonder Kiss」: コインを投げオモテが出た、追加でサイドを1枚多く取る")
                prize_count = _apply_legacy_energy_prize_denial(player, pokemon, prize_count)
                prize_count = _apply_name_prefix_tool_prize_denial(card_db, pokemon, prize_count, ko_tool)
                prize_count = max(0, prize_count - era_prize_denial(state, pokemon, ko_tool, card_db, pokemon.hit_by_calculated_attack_damage and player_index != state.current_player, True))  # ライフデュー
                from effects.passives import adjust_ko_prize

                prize_count = adjust_ko_prize(state, card_db, player_index, pokemon, prize_count)
                if prize_count <= 0:
                    state.add_log(f"player{player_index} の {card_name(card_db, pokemon.card_id)} がきぜつ！ サイドは取れない(特性)")
                else:
                    state.add_log(
                        f"player{player_index} の {card_name(card_db, pokemon.card_id)} がきぜつ！ "
                        f"player{opponent_index} がサイドを{prize_count}枚取る"
                    )
                    if not _take_prizes(opponent, prize_count, _prizes_discarded(state, ko_tool, pokemon, player_index)):
                        needs_prize_choice.append((opponent_index, prize_count))
            if player.bench:
                needs_new_active.append(player_index)

    return needs_new_active, needs_prize_choice


def _prizes_discarded(state, ko_tool, pokemon, player_index: int) -> bool:
    from effects.era_trainers import _tools_active
    from effects.era_tools_j import prizes_discarded

    return bool(ko_tool) and _tools_active(state) and prizes_discarded(state, ko_tool, pokemon.hit_by_calculated_attack_damage and player_index != state.current_player)


def _apply_leap_through_time(state: GameState, card_db: CardDatabase, player_index: int, pokemon: PokemonInPlay) -> None:
    """セレビィの「Leap Through Time」: コインがオモテなら、トラッシュではなく山札に戻り、相手はサイドを取れない。"""
    from effects.era_special import leap_through_time_applies

    if leap_through_time_applies(state, card_db, player_index, pokemon):
        pokemon.rescued_to_deck_pending = True
        pokemon.no_prize_on_ko_until_turn = 10**9


def _discard_pokemon(state: GameState, player, pokemon: PokemonInPlay, card_db: CardDatabase | None = None) -> None:
    if pokemon.rescued_to_deck_pending:
        player.deck.extend(pokemon.evolution_history)
        player.deck.append(pokemon.card_id)
        player.deck.extend(pokemon.attached_energy)
        if pokemon.attached_tool:
            player.deck.append(pokemon.attached_tool)
            pokemon.attached_tool = None
        state.rng.shuffle(player.deck)
        return
    from cards.card_db import POKEMON_AS_ITEM

    body_card_id = POKEMON_AS_ITEM.get(pokemon.card_id, pokemon.card_id)  # 場から離れたら本来のグッズのカードに戻る(みがわりロボ/化石グッズ)
    if pokemon.rescued_to_hand_pending:
        # スプラッシュエネルギー: みずポケモンが相手のワザのダメージできぜつしたら、本体はトラッシュではなく
        # 手札に戻る(ついている他のカードは通常通りトラッシュ)。
        player.hand.extend(pokemon.evolution_history)  # 進化前のカードも、ポケモンの一部として手札に戻る
        player.hand.append(body_card_id)
    elif state.stadium_in_play == LOST_CITY_STADIUM_ID:
        # 進化しているポケモンは、進化前のカードもまとめてカードの束としてロストゾーンに送る
        # (evolution_historyに積まれた進化前card_idを古い順に、最後に現在のcard_idを送る。
        # 以前はcard_idしか送っておらず、進化前のカードがゲームから消えてしまっていた)。
        player.lost_zone.extend(pokemon.evolution_history)
        player.lost_zone.append(body_card_id)
    else:
        # 進化しているポケモンをトラッシュするときは、進化前のカードもまとめてカードの束として
        # トラッシュに送る(evolution_historyに積まれた進化前card_idを古い順に、最後に現在のcard_id)。
        player.discard.extend(pokemon.evolution_history)
        player.discard.append(body_card_id)
    if pokemon.energy_to_hand_pending and card_db is not None:
        only_type = pokemon.energy_to_hand_only_type
        for e in pokemon.attached_energy:  # エナジーポーチ: 基本エネルギーは手札に、それ以外はトラッシュに(Diver's Catch: 指定タイプの基本エネルギーだけ)
            c = card_db.get(e)
            to_hand = c is not None and c.is_energy and not c.is_special_energy and (only_type is None or c.basic_energy_type == only_type)
            (player.hand if to_hand else player.discard).append(e)
    else:
        player.discard.extend(pokemon.attached_energy)
    if pokemon.attached_tool:
        discard_attached_tool(state, player, pokemon)


def _take_prizes(player, count: int, discard: bool = False) -> bool:
    """countが残りサイド枚数以上(=全部取る、選ぶ余地が無い)ならその場で取ってTrueを返す。
    残りサイドの方が多く選ぶ余地がある場合は何もせずFalseを返す(呼び出し側がプレイヤーに
    どれを取るか選ばせ、選んだ分だけ後で手札に移す)。実カードルール通り、プレイヤーは自分の
    残りサイドを見て自由に選んで取れる(固定の順番で機械的に取るものではない)。"""
    if count < len(player.prizes) and not discard:
        return False
    take = min(count, len(player.prizes))
    for _ in range(take):
        card = player.take_prize()
        (player.discard if discard else player.hand).append(card)  # discard=True: ビリビリスモッグ(サイドを手札に加えずトラッシュ)
    return True


def check_win_conditions(state: GameState) -> None:
    if state.winner is not None:
        return
    if not state.setup_complete:
        # 対戦準備中はまだ片方(または両方)がバトルポケモンを選んでいない状態が正常なので、
        # 「場にポケモンがいない」を敗北条件として扱わない。
        return

    for player_index, player in enumerate(state.players):
        if len(player.prizes) == 0:
            state.winner = player_index
            state.win_reason = "prizes"
            state.add_log(f"player{player_index} がサイドを全て取り、勝利した！")
            return

    for player_index, player in enumerate(state.players):
        if player.active is None and not player.bench:
            state.winner = state.opponent_index(player_index)
            state.win_reason = "no_pokemon"
            state.add_log(f"player{player_index} は場にポケモンがいないため敗北")
            return
