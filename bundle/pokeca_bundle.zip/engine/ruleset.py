"""レギュレーション(時代・特殊ルール)ごとに異なる細則を表す。

通常ルールと異なる過去のレギュレーションを再現するための差分だけをここに持つ。
ゲームの基本メカニクス(ターン進行・進化・きぜつ等)は常にengine/の他モジュールが担う。
"""

from __future__ import annotations

from dataclasses import dataclass


@dataclass(frozen=True)
class Ruleset:
    id: str
    name: str
    first_player_can_attack_turn1: bool = True
    first_player_can_play_trainers_turn1: bool = True  # Item/サポート/スタジアム全て(WCS2010等の特殊ルール用)
    first_player_draws_turn1: bool = True  # 先攻の最初の番に山札を引くか(2026-10-03追加。日本はADV期
    # (2003/1/31〜)から、DP期のどこか(2006/10〜2008/8の間、正確な日付は未確認)までは引けなかった。
    # 英語版は2004〜2006年は引けず、2007年(DP)から引く。現行は引く)。
    first_player_can_play_supporter_turn1: bool = True  # サポートのみ(現行ルール。日本は2019年11月29日〜、
    # 北米・国際大会(英語版)は2020年2月21日(Sword & Shieldの大会使用解禁日)〜で適用開始日が異なる)

    # 先攻1ターン目のワザ禁止: 2013年11月8日(英語版Kalos Starter Set発売/日本語版でも同日ごろ)〜、
    #   日本・国際で適用開始日の差は確認できていない(単一の日付)。
    # 先攻1ターン目のサポート禁止: 日本は2019年11月29日(金)〜(ソード&シールド発売に先立つ告知、
    #   https://www.pokemon-card.com/info/2019/20190922_002095.html)、北米・国際大会(英語版)は
    #   2020年2月21日〜(英語版Sword & Shieldの大会使用解禁日、英語版パック自体は2020年2月7日発売)。
    # このプロジェクトのWCS/Players Cup優勝デッキ再現は北米(英語版)の大会記録を主に参照しているため、
    # PRE_SWSH_RULESET→DEFAULT_RULESETの切り替え境界は北米の2020年2月21日基準で判断する
    # (ただし現在収録されている全デッキの開催時期はいずれの日付を基準にしても同じ判定結果になる)。


# 現行ルール: 先攻1ターン目はワザが使えない(2013年11月8日以降)、サポートも使えない
# (日本2019年11月29日/北米2020年2月21日以降、詳細は上記フィールドのコメント参照)。
DEFAULT_RULESET = Ruleset(
    id="default",
    name="現行ルール",
    first_player_can_attack_turn1=False,
    first_player_can_play_supporter_turn1=False,
)

# 2013年11月〜2019年(BW—Plasma Storm期〜SM期)ルール: 先攻1ターン目はワザが使えないが、サポートは使えた
# (「先攻1ターン目サポート禁止」は日本2019年11月29日/北米2020年2月21日からのルール変更のため)。
PRE_SWSH_RULESET = Ruleset(
    id="pre_swsh",
    name="2013年11月〜2019年ルール",
    first_player_can_attack_turn1=False,
    first_player_can_play_supporter_turn1=True,
)

# WCS2010(2010年世界選手権)レギュレーション: 先攻はワザは使えるが、1ターン目はトレーナーズ(グッズ/サポート/スタジアム)を使えない
WCS2010_RULESET = Ruleset(
    id="wcs2010",
    name="WCS2010",
    first_player_can_attack_turn1=True,
    first_player_can_play_trainers_turn1=False,
)

# ---- 過去のレギュレーション用(2026-10-03追加、ユーザー指示「レギュレーションごとに切り替えてください」) ----
# 先攻の最初の番のルールの変遷(ワザ・サポート・グッズ/スタジアム・山札を引く)を時代ごとに表す。
# 「最初の番の進化」(両者とも不可)は対象外(ユーザー指示、導入時期が未確認のため現行のまま)。
# 出典・確度は data/first_turn_rules_history.md を参照。日本版と英語版で時期・内容が違う時代は別々に持つ。
# 該当する実在レギュレーション(deck/regulations.py)はまだ無いため、今のところ使われていないが、
# 追加したときにRegulation(ruleset=...)へ指定するだけで切り替わる。

# BW期(日本2010年12月〜2013年11月7日、英語版2011年〜2013年): 先攻でもワザ・サポート・グッズ・スタジアムが使え、山札も引く。
BW_RULESET = Ruleset(id="bw", name="BW期ルール(2010/12〜2013/11)")

# 日本のADV〜DP期: 先攻は山札を引けず(DP期のどこかで復活、復活後はdp_jpを使う)、サポーターは使えない
# (グッズ・スタジアム・ワザは使える)。ADV第3版(2004年1月)〜。ADV第1版(2003年1月〜2004年1月)は
# サポーターも使えた。
ADV_JP_RULESET = Ruleset(
    id="adv_jp", name="日本ADV期ルール(2004/1〜)",
    first_player_draws_turn1=False, first_player_can_play_supporter_turn1=False,
)
ADV_JP_EARLY_RULESET = Ruleset(
    id="adv_jp_early", name="日本ADV第1版ルール(2003/1〜2004/1)", first_player_draws_turn1=False,
)
# 日本のDP期(先攻ドロー復活後〜BW前): 山札を引く、サポーターだけ使えない。
DP_JP_RULESET = Ruleset(id="dp_jp", name="日本DP期ルール", first_player_can_play_supporter_turn1=False)
# 英語版の2004年〜2006年: 山札を引けず、サポーターも使えない。
ADV_EN_RULESET = Ruleset(
    id="adv_en", name="英語版2004〜2006年ルール",
    first_player_draws_turn1=False, first_player_can_play_supporter_turn1=False,
)

_ALL_RULESETS = {
    r.id: r
    for r in (
        DEFAULT_RULESET, PRE_SWSH_RULESET, WCS2010_RULESET, BW_RULESET,
        ADV_JP_RULESET, ADV_JP_EARLY_RULESET, DP_JP_RULESET, ADV_EN_RULESET,
    )
}


def get_ruleset(ruleset_id: str) -> Ruleset:
    return _ALL_RULESETS.get(ruleset_id, DEFAULT_RULESET)
