"""現在の状態から合法な行動を列挙する。"""

from __future__ import annotations

from effects.card_aliases import canonical_id

from dataclasses import replace

import contextlib
import contextvars
import json
from pathlib import Path
from itertools import combinations, islice

from cards.card_db import (
    CardDatabase,
    ITEM_AS_POKEMON,
    POKEMON_AS_ITEM,
    ROBO_SUBSTITUTE_ITEM_ID,
    ROBO_SUBSTITUTE_POKEMON_ID,
    TEAM_ROCKETS_NAME_PREFIX,
    is_team_rockets_pokemon,
)
from effects.primitives import (
    AttachEnergyFromDiscardToEachOwnBenchedOfType,
    AttachEnergyFromDiscardToOwnPokemon,
    AttachEnergyFromDiscardToOwnPokemonWithChoice,
    AttachEnergyFromDiscardToSelf,
    AttachEnergyFromHandToChosenOwnPokemon,
    AttachEnergyFromHandToSelf,
    DamageCounterOnChosenOwnPokemon,
    DamagePerFusionStrikeEnergyAcrossBoard,
    DamageToChosenOwnPokemonIgnoringWeaknessResistance,
    DiscardCardsFromHand,
    DiscardOwnHandBasicEnergyThenDraw,
    DiscardTopNAttachEnergyFound,
    DamageWithSupporterBonusToChosenOpponentBench,
    DamageWithBonusBenchIfExtraEnergy,
    DamageToChosenOpponentPokemonScaledByOwnPokemonNamedCoinFlips,
    DealBonusDamageToChosenOpponentBench,
    DamageBonusIfStadiumDiscarded,
    OPTIONAL_VARIANT_BONUS_EFFECTS,
    has_optional_variant,
    DiscardHandEnergyThenSwitchOpponentBench,
    DiscardStadiumInPlayIfChosen,
    ForceOpponentSwitchChosenBench,
    DamageCounterOnChosenOpponentPokemon,
    DamageCounterOnChosenOpponentBenchIfActiveHasSpecialCondition,
    DamageCounterOnChosenOpponentThenSelfKnockout,
    DamagePerSelfEnergyToChosenOpponent,
    Draw,
    DrawThenShuffleSelfIntoDeckIfDrew,
    DrawUpTo,
    DealDamageToChosenOpponentPokemon,
    HealTarget,
    ReturnOwnBenchedPokemonAndAttachedToHand,
    LockChosenOpponentAttackNextTurn,
    MoveDamageCountersFromAllOwnPokemonToChosenOpponent,
    DamagePerSelfDamageCountersToChosenOpponent,
    MoveDamageCountersFromSelfToOpponentActive,
    MoveEnergyBetweenOwnPokemon,
    NotImplementedEffect,
    LookTopNAttachEnergyRestToHand,
    SearchDeckAndAttachEnergy,
    SearchDeckAnyEnergyAttachToSelf,
    SearchDeckForBasicEnergyAttachToTarget,
    SearchDeckForBasicPokemonToBench,
    SearchDiscardAnyCardToHand,
    SearchDiscardForBasicEnergyToHand,
    SearchDiscardForBasicPokemonToBench,
    SearchDiscardForPokemonOfTypeToBench,
    SearchDiscardForPokemonOfTypeToHand,
    SearchDiscardForPokemonOrEnergy,
    SwitchActiveWithBenchThenPoisonSelf,
    SearchDiscardForPokemonToHand,
    SearchDiscardForSPAndEnergy,
    SearchDiscardForSubtypeToHand,
    SearchDiscardForSupporterOrStadiumToHand,
    SearchDiscardForSupporterToHand,
    SearchDiscardForTrainerToHand,
    ShuffleFromDiscardIntoDeck,
    ChooseOwnAttachedEnergyThenShuffleForBonusBenchDamage,
    ShuffleSpecialEnergyFromDiscardIntoDeck,
    ShuffleSupportersFromDiscardIntoDeck,
    SwitchActiveWithBench,
)
from effects.registry import (
    DISCARD_ABILITY_EFFECTS,
    DISCARD_ABILITY_TO_HAND_CARD_IDS,
    get_ability_script,
    get_attack_script,
    get_stadium_ability_script,
    get_trainer_paired_script,
    get_trainer_script,
)
from engine.continuous import (
    ability_blocked_by_damp,
    MEMORY_CAPSULE_ID,
    ability_suppressed,
    abilities_blocked_by_flutter_mane,
    abilities_blocked_by_garbotoxin,
    abilities_blocked_by_giratina_devour_light,
    abilities_blocked_by_iron_thorns_ex,
    abilities_blocked_by_stadium,
    effective_bench_limit,
    effective_max_hp,
    items_blocked_by_active_trevenant,
    items_blocked_by_vileplume,
    tools_disabled,
    wild_growth_active,
)
from engine.actions import (
    AcceptTrigger,
    Action,
    Attack,
    AttachEnergy,
    ChooseInitialActive,
    ChooseMulliganBonusDrawCount,
    ChooseNewActive,
    ConfirmSetupDone,
    DeclineTrigger,
    DiscardRoboSubstitute,
    EndTurn,
    Evolve,
    PlayBasicPokemon,
    PlayItem,
    PlayLevelUp,
    PlayPokemonTool,
    PlaySupporter,
    PlayStadium,
    PassPowerSprayWindow,
    ResolveDamageDistribution,
    ResolveSearchChoice,
    Retreat,
    UseAbility,
    UseBorrowedAttack,
    UseDiscardAbility,
    UsePowerSpray,
    UseStadiumAbility,
    Zone,
)
from engine.energy import (
    ESCAPE_BOARD_TOOL_ID,
    RAPID_STRIKE_ENERGY_ID,
    SPLASH_ENERGY_ID,
    TEAM_ROCKET_ENERGY_ID,
    TEAM_ROCKET_ENERGY_REPRINT_ID,
    WONDER_ENERGY_ID,
    can_pay_cost,
    can_pay_retreat_cost,
    effective_attack_cost,
    effective_retreat_cost_count,
    energy_matches_type,
    has_dark_cloak_in_play,
    has_thunderclap_zone_in_play,
    has_skyliner_in_play,
    special_energy_suppression_for,
)
from engine.state import GameState, MAX_BENCH_SIZE, PendingSearchChoice, PlayerState, PokemonInPlay


def next_actor(state: GameState) -> int:
    if not state.setup_complete:
        if state.mulligan_bonus_draw_pending_players:
            return state.mulligan_bonus_draw_pending_players[0]
        return state.setup_player
    if state.pending_power_spray_window is not None:
        return state.pending_power_spray_window.opponent_index
    if state.pending_trigger is not None:
        return state.pending_trigger.player_index
    if state.pending_search_choice is not None:
        return state.pending_search_choice.player_index
    if state.pending_damage_distribution is not None:
        return state.pending_damage_distribution.player_index
    if state.pending_active_choice:
        return state.pending_active_choice[0]
    return state.current_player


def _damage_distribution_actions(state: GameState, card_db: CardDatabase) -> list[Action]:
    """ダメカン自由配分の全ての配分パターンを列挙する(合計がtotal_countersになる非負整数の組)。

    免疫(Repelling Veil・ミストエネルギー等の「ワザの効果を防ぐ」もの)やシールド状態、
    ダメカン付与を防ぐどうぐ、バトルコロシアム(スタジアム、相手のベンチにはダメカンがのらない)を
    持つ対象は、engine/rules_engine.py._handle_resolve_damage_distribution側で実際には既に
    ダメカンがのらないよう無視されている(2026-08-23、ドラパルトexの「Phantom Dive」の
    ばらまきダメカンがばけがくれ等をすり抜けていた不具合の修正。バトルコロシアムのチェック漏れは
    2026-09-22に追加で発覚・修正)。しかしこちら(合法手の列挙)はその対象も含めて配分パターンを
    作っていたため、「免疫を持つ相手にダメカンを配分する」という実質何も起きない選択肢が
    合法手に混じっていた(2026-09-19、Claude対局中のユーザー指摘で発覚)。列挙の時点で
    免疫・シールド対象を配分先候補から除外し、無駄になる配分を選択肢に出さないようにする。"""
    from effects.primitives import (
        _BATTLE_COLOSSEUM_STADIUM_ID,
        _blocks_damage_counters,
        _defender_blocks_effect,
        _defender_is_shielded,
    )
    from effects.context import EffectContext
    from engine.continuous import tools_disabled

    dist = state.pending_damage_distribution
    side_player = (
        state.player(dist.player_index)
        if dist.target_own_side
        else state.player(state.opponent_index(dist.player_index))
    )
    targets: list[PokemonInPlay] = []
    if not dist.bench_only and side_player.active is not None:
        targets.append(side_player.active)
    targets.extend(side_player.bench)
    num_targets = len(targets)
    if num_targets <= 0:
        return []

    blocked = [False] * num_targets
    if not dist.target_own_side:
        ctx = EffectContext(
            state=state, card_db=card_db, acting_player=dist.player_index, source_pokemon=None,
            source_card_id=dist.source_card_id, rng=state.rng, effect_source=dist.effect_source,
        )
        stadium_tools_disabled = tools_disabled(state.stadium_in_play)
        battle_colosseum_active = state.stadium_in_play == _BATTLE_COLOSSEUM_STADIUM_ID
        for i, target in enumerate(targets):
            if (
                _defender_is_shielded(ctx, target)
                or _defender_blocks_effect(ctx, target)
                or (not stadium_tools_disabled and _blocks_damage_counters(target))
                or (battle_colosseum_active and target is not side_player.active)
            ):
                blocked[i] = True

    eligible_indices = [i for i in range(num_targets) if not blocked[i]]
    if not eligible_indices:
        # 対象が1体も残らない(全員ブロック対象)場合。engine/rules_engine.py側の解決処理は
        # sum(action.counts) == dist.total_countersを要求するため、ここで単純に[]を返すと
        # 「ダメカン配分待ちなのに合法手が1つも無い」という手詰まり状態になってしまう
        # (2026-09-22発覚: バトルコロシアムが場にある間、ベンチ限定のPhantom Dive等はベンチの
        # 対象全員がブロックされるため、このケースに毎回該当する)。どのみち解決処理側も同じ
        # 判定で実際のダメージ付与をスキップするので、ブロック対象へ(max_per_target内で)
        # 便宜上割り振っただけのダミーの1択を返す(実際には何もダメカンがのらない)。
        dummy = [0] * num_targets
        remaining = dist.total_counters
        cap = dist.max_per_target if dist.max_per_target is not None else dist.total_counters
        for i in range(num_targets):
            if remaining <= 0:
                break
            take = min(cap, remaining)
            dummy[i] = take
            remaining -= take
        if remaining > 0:
            return []  # 上限を使い切ってもtotal_countersに届かない(理論上起き得ないはずの安全弁)
        return [ResolveDamageDistribution(tuple(dummy))]
    num_eligible = len(eligible_indices)

    def spread(counts: tuple[int, ...]) -> tuple[int, ...]:
        full = [0] * num_targets
        for idx, count in zip(eligible_indices, counts):
            full[idx] = count
        return tuple(full)

    max_per_target = dist.max_per_target if dist.max_per_target is not None else dist.total_counters

    if dist.fixed_per_target and dist.max_per_target:
        # "選んだ対象全員にmax_per_target個ずつ"の固定配分(ドサイドンEXの「Grenade Hammer」等)。
        k = min(dist.total_counters // dist.max_per_target, num_eligible)
        return [
            ResolveDamageDistribution(spread(tuple(dist.max_per_target if i in chosen else 0 for i in range(num_eligible))))
            for chosen in combinations(range(num_eligible), k)
        ]

    def compositions(total: int, parts: int):
        if parts == 1:
            if total <= max_per_target:
                yield (total,)
            return
        for first in range(min(total, max_per_target) + 1):
            for rest in compositions(total - first, parts - 1):
                yield (first,) + rest

    return [ResolveDamageDistribution(spread(counts)) for counts in compositions(dist.total_counters, num_eligible)]


_POWER_SPRAY_ID = "pl1-117"  # パワースプレー


def can_play_power_spray(player: PlayerState, card_db: CardDatabase) -> bool:
    """パワースプレーが手札にあり、かつ「自分の場のポケモンSPが2匹以下だと使えない」条件を満たすか。"""
    if _POWER_SPRAY_ID not in player.hand:
        return False
    sp_count = sum(
        1 for mon in player.all_pokemon_in_play() if (c := card_db.get(mon.card_id)) is not None and c.is_sp_pokemon
    )
    return sp_count > 2


def _power_spray_window_actions(state: GameState, card_db: CardDatabase) -> list[Action]:
    window = state.pending_power_spray_window
    opponent = state.player(window.opponent_index)
    actions: list[Action] = [PassPowerSprayWindow()]
    if can_play_power_spray(opponent, card_db):
        actions.append(UsePowerSpray())
    return actions


def _trigger_choice_actions(state: GameState) -> list[Action]:
    trig = state.pending_trigger
    actions: list[Action] = [] if trig.mandatory else [DeclineTrigger()]
    if not trig.needs_target:
        actions.append(AcceptTrigger())
        return actions
    if trig.target_kind == "own_bench":
        player = state.player(trig.player_index)
        actions.extend(AcceptTrigger(bi) for bi in range(len(player.bench)))
        return actions
    opponent = state.player(state.opponent_index(trig.player_index))
    if trig.target_kind == "opponent_any" and opponent.active is not None:
        actions.append(AcceptTrigger(None))
    actions.extend(AcceptTrigger(bi) for bi in range(len(opponent.bench)))
    return actions


def setup_face_down_modes(card_db: CardDatabase, card_id: str, goes_second: bool = False) -> set:
    """たねでないのに、対戦準備で裏向きに出せる特性(Gale Wings/Explosiveness/Electric Start)の出せる場所: {"active"}/{"active","bench"}/空集合。
    「If you go second」の条件がある特性(Electric Start)は、goes_second=Trueのときだけ。"""
    card = card_db.get(card_id)
    if card is None or not card.is_pokemon or card.is_basic:
        return set()
    for ability in card.abilities:
        text = ability.text or ""
        if "when you are setting up to play, you may put it face down" not in text:
            continue
        if "If you go second" in text and not goes_second:
            continue
        modes = {"active"}
        if "or on your Bench" in text:
            modes.add("bench")
        return modes
    return set()


def _can_be_initial_active(card_db: CardDatabase, card_id: str, goes_second: bool = False) -> bool:
    """通常はたねポケモンのみ。特性「Gale Wings」(ファイアローの「疾風の翼」)・「Explosiveness」(ゲキコウ)等を持つポケモンは
    たねでなくても、対戦準備で裏向きのバトルポケモンとして選べる。"""
    card = card_db.get(card_id)
    if card is None:
        return False
    if card.is_basic:
        return True
    return "active" in setup_face_down_modes(card_db, card_id, goes_second)


# 禁止行動(data/prohibited_actions.md)を一時的に無効化するための仕組み(2026-09-19)。
# data/prohibited_actions.mdの全項目は「実カードのルールではなく、学習効率化のためにユーザーが
# 明示的に選択肢から除外することを指定したもの」(このファイル冒頭の説明を参照)であり、
# 本物のカードルール(進化のタイミング制限・特性の発動条件・先攻1ターン目の制限等)とは別物。
# scripts/claude_play_session.pyでClaude自身が判断するときは、この区別に従い「禁止行動」だけを
# 一時的に無効化できるようにする(ユーザー指示: 「あなたがプレイをするときには特に禁止事項を
# 守る必要はありません」)。本物のカードルールはこのコンテキストマネージャの影響を受けない
# (このモジュール内で、この変数を直接参照している箇所以外は一切変わらない)。
_respect_user_prohibitions: contextvars.ContextVar[bool] = contextvars.ContextVar(
    "_respect_user_prohibitions", default=True
)

# 禁止行動一覧(data/prohibited_actions.md)をまるごと無効にするための、ファイル1つで切り替える
# グローバル設定(2026-09-25、ユーザー指示「禁止行動一覧についても一度オフにできるようにして、
# オフにしてください」)。上のuser_prohibitions_disabled()が「この呼び出しだけ一時的に無効化する」
# ためのものなのに対し、こちらは「切り替えるまでずっと無効」の恒久的なオン/オフ。ファイルが
# 無い/壊れている場合は有効(True、従来通りの挙動)。学習プロセス(別プロセス)とこのプロセスの
# 両方から読めるよう、ファイルの更新日時が変わったときだけ読み直すキャッシュにする
# (training.visit_counts.load_human_weight と同じ方式)。
_PROHIBITED_ACTIONS_TOGGLE_FILE = Path(__file__).resolve().parent.parent / "data" / "prohibited_actions_enabled.json"
_prohibited_actions_toggle_cache: tuple[float, bool] | None = None


def prohibited_actions_globally_enabled(path: Path | None = None) -> bool:
    global _prohibited_actions_toggle_cache
    toggle_path = path or _PROHIBITED_ACTIONS_TOGGLE_FILE
    try:
        mtime = toggle_path.stat().st_mtime_ns  # ns精度: 短時間に連続で書き換えてもst_mtime(秒精度)の
        # 分解能不足でキャッシュが古い値のまま取り残されるのを防ぐ(2026-09-25のテストで発覚)。
    except OSError:
        return True
    if _prohibited_actions_toggle_cache is not None and _prohibited_actions_toggle_cache[0] == mtime:
        return _prohibited_actions_toggle_cache[1]
    try:
        enabled = bool(json.loads(toggle_path.read_text(encoding="utf-8"))["enabled"])
    except (OSError, ValueError, KeyError, TypeError):
        return True
    _prohibited_actions_toggle_cache = (mtime, enabled)
    return enabled


def set_prohibited_actions_globally_enabled(enabled: bool, path: Path | None = None) -> None:
    toggle_path = path or _PROHIBITED_ACTIONS_TOGGLE_FILE
    toggle_path.parent.mkdir(parents=True, exist_ok=True)
    toggle_path.write_text(json.dumps({"enabled": enabled}, ensure_ascii=False), encoding="utf-8")


@contextlib.contextmanager
def user_prohibitions_disabled():
    """このwithブロック内でのlegal_actions()呼び出しは、data/prohibited_actions.mdの禁止行動を
    一切適用しない(本物のカードルールは通常通り適用される)。自己対戦・対人戦・既存テストは
    このコンテキストマネージャを使わないため、デフォルト(常に禁止行動を適用する)の挙動は
    一切変わらない。"""
    token = _respect_user_prohibitions.set(False)
    try:
        yield
    finally:
        _respect_user_prohibitions.reset(token)


def _user_prohibitions_active() -> bool:
    return _respect_user_prohibitions.get() and prohibited_actions_globally_enabled()


# 禁止行動(data/prohibited_actions.md参照、AI学習より優先): 対戦準備(セットアップ)でバトル場・
# ベンチどちらにも出すことを一律禁止するカードID(他に選択肢が無い場合を除く)。
# - ニャースex(起死回生のキャッチ、me3-62/me3-107/me3-121): この特性は「手札からベンチに
#   出した時」にのみ発動するため、対戦準備での配置(セットアップ)では発動しない
#   (engine/rules_engine.pyの_handle_play_basicで対戦準備中はトリガーを起こさないよう別途
#   修正済み)。そのため対戦準備でニャースexを出しても特性の価値を得られず、ただ2枚サイドを
#   献上するリスクだけが残る。試合開始後に手札から出せばこの特性が使えるので、対戦準備では
#   手札に温存する。
# - キュレム(トライフロスト、sv6pt5-47、2026-09-16): このデッキ(ヤドキングデッキ)での役割は
#   「夜のアカデミーで山札の一番上に置き、ヤドキングの「ひらめきチャレンジ」で借りて使う」
#   ための山札内の資材であり、対戦準備で場に出してしまうとこの組み合わせに使えなくなる。
# - キチキギスex(Fezandipiti ex、sv6pt5-38、2026-09-19): 特性「さかてにとる」(Flip the Script)は
#   「相手の直前の番に自分のポケモンがきぜつしていた場合のみ」使える(_ability_actionsの
#   player.pokemon_ko_last_turnゲートと同じ判定)。対戦準備中はまだ戦闘が起きていないため
#   pokemon_ko_last_turnは常にFalseで、この特性は絶対に使えない。試合開始後も同じ条件下でのみ
#   場に出すことをユーザーが指定しているため(下のKICHIKIGISU_EX_PLAY_REQUIRES_KO_LAST_TURN参照)、
#   対戦準備での配置もこの集合で一律扱う。
_SETUP_PLACEMENT_PROHIBITED_UNLESS_ONLY_OPTION_IDS = {
    "me3-62", "me3-107", "me3-121",  # ニャースex(起死回生のキャッチ)
    "sv6pt5-47",  # キュレム(トライフロスト)
    "sv6pt5-38",  # キチキギスex(Fezandipiti ex、さかてにとる)
}

# 禁止行動(data/prohibited_actions.md参照、AI学習より優先、2026-09-19): ロケット団のドンカラス
# デッキのキチキギスex(Fezandipiti ex、sv6pt5-38)は、試合開始後も「特性さかてにとるが実際に
# 使えるターン」(player.pokemon_ko_last_turn、上のコメント参照)に限って手札から場に出す
# (対戦準備中の扱いは_SETUP_PLACEMENT_PROHIBITED_UNLESS_ONLY_OPTION_IDS参照、こちらには
# 「他に選択肢が無ければ許可」の例外は無い―― ユーザー指定は試合開始後については無条件)。
_KICHIKIGISU_EX_CARD_ID = "sv6pt5-38"


# 禁止行動(data/prohibited_actions.md参照、AI学習より優先): 特定のデッキ(ばけがくれ、PJCS2026
# 準優勝フカセカブ選手/ベスト8 R選手)では、リーリエのピッピex(sv9-56)を対戦準備でバトル場に
# 出すのはそこまで強くない、というユーザー判断(2026-09-09。AIの評価値が対戦準備の初期選択で
# 極端に偏る調査の中で判明)。エンジンには「今どのデッキで対戦しているか」を判定する仕組みが
# 無いため、実質的にこの2つのデッキでしか同時に採用されない特定カードの組み合わせ(手札に
# 同時にいるか)で代用する: ダダリン(Dhelmise, me5-39)/ノコッチ(Dunsparce, sv9-120)/
# カゲボウズ(Shuppet, me5-33)/スピンロトム(Fan Rotom, sv7-118)のいずれかが同時に手札にある
# 場合、リーリエのピッピexをバトル場の初期選択から除外する(他に選択肢が無ければ許可する)。
# ベンチへの配置(通常のPlayBasicPokemon)は対象外 ―― ユーザー指定は「バトル場に出すこと」のみ。
_INITIAL_ACTIVE_COMPANION_PROHIBITIONS: dict[str, frozenset[str]] = {
    "sv9-56": frozenset({"me5-39", "sv9-120", "me5-33", "sv7-118"}),  # リーリエのピッピex
}


def _prohibited_as_initial_active_by_companions(hand: list[str], card_id: str) -> bool:
    companions = _INITIAL_ACTIVE_COMPANION_PROHIBITIONS.get(card_id)
    return companions is not None and any(c in companions for c in hand)


def _setup_actions(state: GameState, card_db: CardDatabase) -> list[Action]:
    if state.mulligan_bonus_draw_pending_players:
        actor = state.mulligan_bonus_draw_pending_players[0]
        max_count = state.pending_mulligan_bonus_draws[actor]
        return [ChooseMulliganBonusDrawCount(n) for n in range(max_count + 1)]
    actor = state.setup_player
    player = state.player(actor)
    if not state.setup_active_chosen[actor]:
        goes_second = actor != state.first_player
        candidates = [i for i, c in enumerate(player.hand) if _can_be_initial_active(card_db, c, goes_second)]
        if _user_prohibitions_active():
            non_restricted_candidates = [
                i for i in candidates if player.hand[i] not in _SETUP_PLACEMENT_PROHIBITED_UNLESS_ONLY_OPTION_IDS
            ]
            if non_restricted_candidates:
                candidates = non_restricted_candidates
            non_companion_restricted_candidates = [
                i for i in candidates
                if not _prohibited_as_initial_active_by_companions(player.hand, player.hand[i])
            ]
            if non_companion_restricted_candidates:
                candidates = non_companion_restricted_candidates
        return [ChooseInitialActive(i) for i in candidates]
    actions: list[Action] = [
        a
        for a in _play_basic_pokemon_actions(state, player, card_db)
        if not (
            _user_prohibitions_active()
            and isinstance(a, PlayBasicPokemon)
            and player.hand[a.hand_index] in _SETUP_PLACEMENT_PROHIBITED_UNLESS_ONLY_OPTION_IDS
        )
    ]
    actions.append(ConfirmSetupDone())
    return actions


# 禁止行動(data/prohibited_actions.md参照、AI学習より優先): なかよしポフィン(Buddy-Buddy Poffin、
# sv5-144、山札からHP70以下のたねポケモンを2体までベンチに出す)の検索選択で、先攻1ターン目・
# 後攻1ターン目(どちらのプレイヤーもturns_taken==1の初手番)に限り「対象なし」(0体選ぶ)を
# 禁止する。この選択画面はベンチに空きがあり候補も存在する場合のみ出る(_trigger_search_choice
# 参照)ため、この制限が発動する時点で必ず他に選べる組み合わせが存在する(2026-09-10)。
_EMPTY_SEARCH_CHOICE_PROHIBITED_ON_FIRST_TURN = {"sv5-144"}  # なかよしポフィン(Buddy-Buddy Poffin)

# 禁止行動(data/prohibited_actions.md参照、AI学習より優先): 以下のカードは、山札に条件に合う
# ポケモンが実際に存在する(=検索選択画面が出た)時点で「対象なし」を選ぶことを常に禁止する
# (ターンを問わない、2026-09-10・09-11)。
_EMPTY_SEARCH_CHOICE_PROHIBITED_ALWAYS = {
    # ポケパッド(Poké Pad、印刷違い4種)。mp1-15は2026-09-19、Claudeの試験対局中に発見した
    # 実装漏れ(既存3種と全く同じ実カードテキストだが集合に含まれておらず「対象なし」を
    # 選べてしまっていた)。
    "me2pt5-198", "me3-113", "me3-81", "mp1-15",
    "me1-131", "me2pt5-213", "me2pt5-264", "sm1-135", "sm35-68",
    "sv1-196", "swsh9-150", "xy10-113", "xy2-99", "xy6-93",  # ハイパーボール(Ultra Ball、印刷違い10種)
}


def _prohibited_empty_search_choice(state: GameState, choice: PendingSearchChoice) -> bool:
    if not _user_prohibitions_active():
        return False
    if choice.source_card_id in _EMPTY_SEARCH_CHOICE_PROHIBITED_ALWAYS:
        return True
    if choice.source_card_id in _EMPTY_SEARCH_CHOICE_PROHIBITED_ON_FIRST_TURN:
        return state.player(choice.player_index).turns_taken == 1
    return False


# 禁止行動(data/prohibited_actions.md参照、AI学習より優先、2026-09-19): ドラパルトライン
# (ドラメシヤ→ドロンチ→ドラパルト)を採用するデッキでなかよしポフィン(sv5-144)を使ったとき、
# 場(バトル場・ベンチ)にドラメシヤ(sv6-128)が1体もいなければドラメシヤを2体、1体いれば
# ドラメシヤを含む組み合わせを選ばせる。「ドラパルト系列のデッキ」を専用の判定ロジックで
# 検出するのではなく、なかよしポフィンの候補にドラメシヤが実際に含まれているか(=山札に
# ドラメシヤが残っているデッキかどうか)で自然に絞り込む(候補にドラメシヤが無ければ
# ドラパルトラインを採用していないデッキと同じなので何も制限しない)。
_DRAGAPULT_LINE_POFFIN_CARD_ID = "sv5-144"  # なかよしポフィン(Buddy-Buddy Poffin)
_DREEPY_CARD_ID = "sv6-128"  # ドラメシヤ(Dreepy)


def _dragapult_poffin_forced_choice_actions(
    state: GameState, choice: PendingSearchChoice, actions: list[Action]
) -> list[Action]:
    """呼び出し元のlegal_actions()が組み立てた(候補数が多い場合は先頭_MAX_COMBOS_PER_SIZE件に
    切り詰められている)actionsをそのままフィルタすると、ドラメシヤがたまたま候補一覧の後方に
    並んでいた場合に列挙上限で弾かれてしまう恐れがある。ドラメシヤの候補数はデッキ内の残り枚数
    (最大4枚程度)しかないため、組み合わせを候補一覧から直接組み立て直す(組合せ爆発の心配がない)。"""
    if not _user_prohibitions_active():
        return actions
    if choice.source_card_id != _DRAGAPULT_LINE_POFFIN_CARD_ID:
        return actions
    player = state.player(choice.player_index)
    in_play = ([player.active] if player.active else []) + list(player.bench)
    dreepy_in_play = sum(1 for mon in in_play if mon.card_id == _DREEPY_CARD_ID)
    if dreepy_in_play >= 2:
        return actions

    dreepy_indices = [i for i, cid in enumerate(choice.card_ids) if cid == _DREEPY_CARD_ID]
    if not dreepy_indices:
        return actions  # 山札にもう候補が無ければ制限しようがない(選択の余地が無いため許可)
    other_indices = [i for i in range(len(choice.card_ids)) if i not in dreepy_indices]

    if dreepy_in_play == 0:
        target_size = min(2, len(dreepy_indices), choice.max_count)
        filtered = [
            ResolveSearchChoice(combo) for combo in combinations(dreepy_indices, target_size)
        ]
    else:  # dreepy_in_play == 1
        filtered = []
        for size in range(max(choice.min_count, 1), choice.max_count + 1):
            for dreepy_count in range(1, min(size, len(dreepy_indices)) + 1):
                other_count = size - dreepy_count
                if other_count > len(other_indices):
                    continue
                for d_combo in combinations(dreepy_indices, dreepy_count):
                    for o_combo in combinations(other_indices, other_count):
                        filtered.append(ResolveSearchChoice(tuple(sorted(d_combo + o_combo))))
    # 何らかの理由で1件も組み立てられなければ元のactionsをそのまま返す(選択の余地が無い状況で
    # 合法手を0件にしてしまうと対局が進行不能になるため、他の禁止行動と同じ方針)。
    return filtered if filtered else actions


# 禁止行動(data/prohibited_actions.md参照、AI学習より優先、2026-09-19): ドラパルトラインを
# 採用するデッキでは、先攻1ターン目〜後攻2ターン目(=state.player(actor).turns_taken<=2、
# 先攻・後攻どちらも対象)の間、手札になかよしポフィンがあり実際に使える状況なら、他の行動より
# 最優先でそれを使わせる(ユーザー指定: 進化ラインの展開を遅らせないため)。「ドラパルト系列の
# デッキ」の判定は項目9と同じ考え方で、見えている範囲(山札・手札・トラッシュ・場)にドラメシヤが
# 実在するかどうかで自然に絞り込む。
_DRAGAPULT_POFFIN_PRIORITY_MAX_TURNS_TAKEN = 2


def _dragapult_deck_uses_dreepy(player: PlayerState) -> bool:
    if any(cid == _DREEPY_CARD_ID for cid in player.deck):
        return True
    if any(cid == _DREEPY_CARD_ID for cid in player.hand):
        return True
    if any(cid == _DREEPY_CARD_ID for cid in player.discard):
        return True
    if player.active is not None and player.active.card_id == _DREEPY_CARD_ID:
        return True
    return any(mon.card_id == _DREEPY_CARD_ID for mon in player.bench)


def _dragapult_poffin_priority_actions(player: PlayerState, actions: list[Action]) -> list[Action]:
    if not _user_prohibitions_active():
        return actions
    if player.turns_taken > _DRAGAPULT_POFFIN_PRIORITY_MAX_TURNS_TAKEN:
        return actions
    if not _dragapult_deck_uses_dreepy(player):
        return actions
    poffin_actions = [
        a
        for a in actions
        if isinstance(a, PlayItem) and player.hand[a.hand_index] == _DRAGAPULT_LINE_POFFIN_CARD_ID
    ]
    return poffin_actions if poffin_actions else actions


def legal_actions(state: GameState, card_db: CardDatabase) -> list[Action]:
    # シンオウ神殿が場にある間は、特殊エネルギーの固有効果を無効にして判定する(engine.energy参照)
    with special_energy_suppression_for(state, card_db):
        return _legal_actions_impl(state, card_db)


def _legal_actions_impl(state: GameState, card_db: CardDatabase) -> list[Action]:
    return _with_optional_borrowed_variants(_legal_actions_core(state, card_db))


def _with_optional_borrowed_variants(actions: list[Action]) -> list[Action]:
    """借りたワザ(UseBorrowedAttack)が「エネルギーを捨てて追加ダメージを出してもよい」ワザ(メタグロスの
    「Metallic Hammer」等)なら、通常のAttackと同じく「捨てない」(target_bench_index=None)と「捨てる」(=0)の
    2通りに増やす(借りる側の生成箇所が多いので、ここで一括して展開する)。"""
    expanded: list[Action] = []
    for action in actions:
        expanded.append(action)
        if isinstance(action, UseBorrowedAttack) and action.target_bench_index is None:
            script = get_attack_script(action.source_card_id, action.attack_name)
            if has_optional_variant(script):
                expanded.append(replace(action, target_bench_index=0))
    return expanded


def _legal_actions_core(state: GameState, card_db: CardDatabase) -> list[Action]:
    if state.is_game_over():
        return []

    if not state.setup_complete:
        return _setup_actions(state, card_db)

    if state.pending_power_spray_window is not None:
        return _power_spray_window_actions(state, card_db)

    if state.pending_trigger is not None:
        return _trigger_choice_actions(state)

    if state.pending_damage_distribution is not None:
        return _damage_distribution_actions(state, card_db)

    if state.pending_search_choice is not None:
        # 実際のUIは専用エンドポイント(/api/resolve_search_choice)で任意の組み合わせを送るが、
        # ランダムエージェント等がここから選べるように、選択可能な枚数ごとの組み合わせを列挙しておく
        # (min_count>=1の効果(コストとして必ず選ぶ discard 等)では、その枚数ちょうどの組み合わせのみが合法)。
        # 候補数が多いsizeではC(n,k)が組合せ爆発する(例: 30枚から10枚=3000万通り)ため、1つのsizeあたり
        # 列挙する組み合わせ数に上限を設ける(2026-08-13: 深読み探索有効化後、自己対戦ワーカーが
        # この爆発でMemoryErrorを起こし学習が繰り返しクラッシュする不具合が発生したため追加)。
        # 上限に達しても打ち切って先頭からisliceするだけで、そのsizeで選べる組み合わせが1つも
        # 無くなるわけではない。人間側UIはこの一覧に依存しないため実プレイへの影響は無い。
        choice = state.pending_search_choice
        actions: list[Action] = []
        allowed = choice.allowed_counts
        if choice.min_count == 0 and not _prohibited_empty_search_choice(state, choice) and (allowed is None or 0 in allowed):
            actions.append(ResolveSearchChoice(()))
        lo = max(choice.min_count, 1)
        _MAX_COMBOS_PER_SIZE = 200
        for size in range(lo, choice.max_count + 1):
            if allowed is not None and size not in allowed:
                continue
            combos = combinations(range(len(choice.card_ids)), size)
            if choice.exclusive_subtype is not None:
                combos = (c for c in combos if _exclusive_subtype_selection_ok(choice, c, card_db))
            actions.extend(ResolveSearchChoice(combo) for combo in islice(combos, _MAX_COMBOS_PER_SIZE))
        actions = _dragapult_poffin_forced_choice_actions(state, choice, actions)
        return actions

    actor = next_actor(state)
    player = state.player(actor)

    if actor in state.pending_active_choice:
        return [ChooseNewActive(i) for i in range(len(player.bench))]

    if player.pending_second_attack:
        # ホルビーの「Ω Barrage」/カミッチュの「おまつりおんど」: 1回目のワザの直後、他の行動を
        # 挟まず、もう一度同じワザを使うか(あるいは使わずにターンを終えるか)だけを選べる。
        second_attack_actions = list(_attack_actions(state, player, card_db))
        second_attack_actions.append(EndTurn())
        return second_attack_actions

    hand_locked = player.hand_cards_locked_until_turn > 0 and player.turns_taken <= player.hand_cards_locked_until_turn
    actions: list[Action] = []
    actions.extend(
        a
        for a in ([] if hand_locked else _play_basic_pokemon_actions(state, player, card_db))
        if not (
            _user_prohibitions_active()
            and isinstance(a, PlayBasicPokemon)
            and player.hand[a.hand_index] == _KICHIKIGISU_EX_CARD_ID
            and not player.pokemon_ko_last_turn
        )
    )
    if not hand_locked:
        actions.extend(_evolve_actions(state, player, card_db))
        actions.extend(_level_up_actions(player, card_db))
        actions.extend(_attach_energy_actions(player, card_db))
        if _trainers_allowed(state, actor, player):
            actions.extend(_item_actions(state, player, card_db))
            actions.extend(_stadium_actions(state, actor, player, card_db))
        actions.extend(_supporter_actions(state, actor, player, card_db))
    actions.extend(_stadium_ability_actions(state, player, card_db))
    # ポケモンのどうぐは「先攻1ターン目トレーナーズ禁止」の対象外(グッズ/サポート/スタジアムのみが対象)。
    # がブレンミラーはエナジーゲインを先攻1ターン目から使う前提のデッキのため、ここを分けないと壊れる。
    if not hand_locked:
        actions.extend(_pokemon_tool_actions(player, card_db))
    actions.extend(_ability_actions(state, player, card_db))
    actions.extend(_discard_ability_actions(state, player, card_db))
    actions.extend(_retreat_actions(state, player, card_db))
    actions.extend(_discard_robo_substitute_actions(player))
    if not _attacks_allowed(state, actor, player) and _is_first_players_first_turn(state, actor, player) and not (
        player.attack_locked_until_turn > 0 and player.turns_taken <= player.attack_locked_until_turn
    ):
        # Fast Raid等「先攻なら、最初の番からこのワザを使える」ワザだけは、先攻1ターン目のワザ禁止の例外
        actions.extend(_attack_actions(state, player, card_db, first_turn_exception_only=True))
    if _attacks_allowed(state, actor, player):
        actions.extend(_attack_actions(state, player, card_db))
        actions.extend(_perfection_attack_actions(state, player, card_db))
        actions.extend(_versatile_attack_actions(state, player, card_db))
        actions.extend(_passive_borrowed_attack_actions(state, player, card_db))
        actions.extend(_memories_of_dawn_attack_actions(state, player, card_db))
        actions.extend(_tool_granted_attack_actions(state, player, card_db))
        actions.extend(_memory_capsule_attack_actions(state, player, card_db))
        actions.extend(_shadow_hunt_attack_actions(state, player, card_db))
        actions.extend(_copycat_attack_actions(state, player, card_db))
        actions.extend(_attack_copy_actions(state, player, card_db))
    actions.append(EndTurn())
    return _dragapult_poffin_priority_actions(player, actions)


def _is_first_players_first_turn(state: GameState, actor: int, player: PlayerState) -> bool:
    return actor == state.first_player and player.turns_taken == 1


def _trainers_allowed(state: GameState, actor: int, player: PlayerState) -> bool:
    if _is_first_players_first_turn(state, actor, player) and not state.ruleset.first_player_can_play_trainers_turn1:
        return False
    return True


def _supporter_allowed(state: GameState, actor: int, player: PlayerState) -> bool:
    if not _trainers_allowed(state, actor, player):
        return False
    if _is_first_players_first_turn(state, actor, player) and not state.ruleset.first_player_can_play_supporter_turn1:
        return False
    return True


def _attacks_allowed(state: GameState, actor: int, player: PlayerState) -> bool:
    if _is_first_players_first_turn(state, actor, player) and not state.ruleset.first_player_can_attack_turn1:
        return False
    if player.attack_locked_until_turn > 0 and player.turns_taken <= player.attack_locked_until_turn:  # アイアンルールGX等
        return False
    return True


def _play_basic_pokemon_actions(state: GameState, player: PlayerState, card_db: CardDatabase) -> list[Action]:
    if len(player.bench) >= effective_bench_limit(state, player, card_db):
        return []
    actions = []
    player_index = 0 if player is state.players[0] else 1
    from effects.passives_ext import ability_pokemon_play_locked

    for i, card_id in enumerate(player.hand):
        card = card_db.get(card_id)
        if card is not None and card.is_basic:
            if ability_pokemon_play_locked(state, card_db, player_index, card):
                continue  # Potent Glare
            actions.append(PlayBasicPokemon(i))
        elif card_id in ITEM_AS_POKEMON:
            # みがわりロボ(xy4-102)/Antique〜Fossil: グッズだが「無色たねポケモン」として場に出せる特殊カード。
            actions.append(PlayBasicPokemon(i))
        elif not state.setup_complete and "bench" in setup_face_down_modes(card_db, card_id, player_index != state.first_player):
            actions.append(PlayBasicPokemon(i))  # デンリュウ(Electric Start): 後攻なら、対戦準備でベンチにも裏向きに出せる
    return actions


def _discard_robo_substitute_actions(player: PlayerState) -> list[Action]:
    """みがわりロボ(xy4-102)は自分の番のいつでも(ワザの前に)場からトラッシュしてよい。"""
    actions: list[Action] = []
    if player.active is not None and player.active.card_id in POKEMON_AS_ITEM:
        actions.append(DiscardRoboSubstitute(zone=Zone.ACTIVE))
    from cards.card_db import POKE_DOLL_ITEM_IDS

    for bi, mon in enumerate(player.bench):
        if mon.card_id in POKEMON_AS_ITEM and POKEMON_AS_ITEM[mon.card_id] not in POKE_DOLL_ITEM_IDS:  # ポケ人形はバトル場にいるときだけ
            actions.append(DiscardRoboSubstitute(zone=Zone.BENCH, bench_index=bi))
    return actions


def _evolve_actions(state: GameState, player: PlayerState, card_db: CardDatabase) -> list[Action]:
    from effects.passives import evolution_banned

    if evolution_banned(state, card_db):
        return []  # Ancient Power: 両プレイヤーとも、手札からポケモンを進化させられない
    actions: list[Action] = []
    from effects.passives_ext import ability_pokemon_play_locked

    evolve_player_index = 0 if player is state.players[0] else 1
    for i, card_id in enumerate(player.hand):
        card = card_db.get(card_id)
        if card is None or not card.is_pokemon or card.is_basic or not card.evolves_from:
            continue
        if ability_pokemon_play_locked(state, card_db, evolve_player_index, card):
            continue  # Potent Glare
        if player.active is not None and _can_evolve_target(state, player.active, card, player, card_db):
            actions.append(Evolve(i, Zone.ACTIVE))
        for bi, mon in enumerate(player.bench):
            if _can_evolve_target(state, mon, card, player, card_db):
                actions.append(Evolve(i, Zone.BENCH, bi))
    return actions


_FOREST_OF_GIANT_PLANTS_ID = "xy7-74"  # Forest of Giant Plants: くさポケモンは出したターンでも進化できる
_VITAL_FOREST_ID = "m1s-61"  # 活力の森: おたがいのくさポケモンは(自分の最初の番をのぞき)出したこの番に進化できる
# (実カード確認の結果、pokemon-card.com公式サイトの生HTMLで"くさ"がicon-grassという空のspanタグに
# なっており、通常のテキスト抽出では消えて見える(2026-08-23、ユーザー指摘で発覚。ワンダーパッチ
# (mbd-15)/ムチュール(sv8-75)と同じ失敗パターン)。以前はこの制限が無く、くさタイプ以外の
# ポケモンも出したターンに進化できてしまっていた)。


def _has_evolutionary_advantage(state: GameState, mon: PokemonInPlay, player: PlayerState, card_db: CardDatabase) -> bool:
    """ドーミラー(sm9-100)の特性「Evolutionary Advantage」実カードテキスト: "If you go second, this Pokémon
    can evolve during your first turn." ―― 後攻のプレイヤーの最初の番に限り、このポケモン(場に出たその番を
    除く)は進化できる。特性が封じられていれば使えない。"""
    card = card_db.get(mon.card_id)
    if card is None or not any(a.name == "Evolutionary Advantage" for a in card.abilities):
        return False
    player_index = 0 if player is state.players[0] else 1
    if player_index == state.first_player or player.turns_taken != 1:
        return False
    return not ability_suppressed(state, card_db, player_index, mon)


def _can_evolve_target(
    state: GameState, mon: PokemonInPlay, evolution_card, player: PlayerState, card_db: CardDatabase
) -> bool:
    from effects.passives import can_evolve_on_play_turn

    player_index = 0 if player is state.players[0] else 1
    evolves_any_time = can_evolve_on_play_turn(state, card_db, player_index, mon)  # Adaptive Evolution/Stimulated Evolution
    if player.turns_taken <= 1 and not evolves_any_time and not _has_evolutionary_advantage(state, mon, player, card_db):
        return False
    if mon.no_evolve_until_turn > 0 and player.turns_taken <= mon.no_evolve_until_turn:
        return False  # Time Freeze: 相手の次の番、このポケモンは進化できない
    if player.evolve_locked_until_turn > 0 and player.turns_taken <= player.evolve_locked_until_turn:
        return False  # Evolution Jammer: 相手の次の番、手札のポケモンで進化できない
    target_card = card_db.get(mon.card_id)
    if target_card is None or target_card.name != evolution_card.evolves_from:
        return False
    if mon.turn_played == player.turns_taken and not evolves_any_time:
        forest_active = state.stadium_in_play == _FOREST_OF_GIANT_PLANTS_ID and "Grass" in target_card.types
        # 活力の森(公式サイト: 「おたがいの{草}ポケモン全員は、出したばかりの番でも{草}ポケモンに進化できる」):
        # 進化前だけでなく進化先も草ポケモンのとき
        vital_forest_active = (
            state.stadium_in_play == _VITAL_FOREST_ID and "Grass" in target_card.types and "Grass" in evolution_card.types
        )
        if not forest_active and not vital_forest_active:
            return False
    return True


def _level_up_actions(player: PlayerState, card_db: CardDatabase) -> list[Action]:
    """Lv.Xを場のポケモンに重ねる。通常の進化と違い、出したばかりのターンでもよい。"""
    actions: list[Action] = []
    for i, card_id in enumerate(player.hand):
        card = card_db.get(card_id)
        if card is None or not card.is_level_up:
            continue
        base_name = card.level_up_base_name
        if base_name is None:
            continue
        if player.active is not None and _can_level_up_target(player.active, base_name, card_db):
            actions.append(PlayLevelUp(i, Zone.ACTIVE))
        for bi, mon in enumerate(player.bench):
            if _can_level_up_target(mon, base_name, card_db):
                actions.append(PlayLevelUp(i, Zone.BENCH, bi))
    return actions


def _can_level_up_target(mon: PokemonInPlay, base_name: str, card_db: CardDatabase) -> bool:
    if mon.leveled_up:
        return False
    target_card = card_db.get(mon.card_id)
    return target_card is not None and target_card.name == base_name


# 禁止行動(data/prohibited_actions.md参照、AI学習より優先): 以下のカードへのエネルギー添付を
# デッキを問わず一律禁止する。
# - ラティアスex(スカイライナー、sv8-76): 特性「Skyliner」(スカイライナー)を持つ。
# - スボミー(むずむずかふん、sv8pt5-4、2026-09-17): 唯一のワザ「Itchy Pollen」(むずむずかふん)は
#   コストがゼロ(無色0個)で使えるため、エネルギーを張る意味が無い。HP30の使い捨て要員でも
#   あり、張ったエネルギーがそのまま無駄になりやすい。
_ENERGY_ATTACH_PROHIBITED_CARD_IDS = {"sv8-76", "sv8pt5-4"}


def _energy_attach_allowed(card_db: CardDatabase, energy_card_id: str, target_mon: PokemonInPlay) -> bool:
    """一部の特殊エネルギーは、つけられるポケモンの種類が限定されている
    (れんげきエネルギー: 「Rapid Strike」サブタイプ限定、スプラッシュエネルギー: みずタイプ限定)。"""
    if _user_prohibitions_active() and target_mon.card_id in _ENERGY_ATTACH_PROHIBITED_CARD_IDS:
        return False
    target_card = card_db.get(target_mon.card_id)
    if target_card is None:
        return True
    if energy_card_id == RAPID_STRIKE_ENERGY_ID:
        return "Rapid Strike" in target_card.subtypes
    if energy_card_id == SPLASH_ENERGY_ID:
        return "Water" in target_card.types
    if energy_card_id in (TEAM_ROCKET_ENERGY_ID, TEAM_ROCKET_ENERGY_REPRINT_ID):
        return is_team_rockets_pokemon(target_card)
    if energy_card_id == WONDER_ENERGY_ID:
        return "Fairy" in target_card.types
    from effects.era_trainers import era_energy_attach_allowed

    return era_energy_attach_allowed(energy_card_id, target_card)  # ハーブエネルギー: くさポケモン限定


def _exclusive_subtype_selection_ok(choice, selected, card_db: CardDatabase) -> bool:
    """PendingSearchChoice.exclusive_subtype の検証: 指定サブタイプのカードを選ぶなら、それをちょうど1枚だけ選ぶ。"""
    subtype = choice.exclusive_subtype
    flagged = [i for i in selected if (c := card_db.get(choice.card_ids[i])) is not None and subtype in c.subtypes]
    return not flagged or (len(flagged) == 1 and len(selected) == 1)


def _attach_energy_actions(player: PlayerState, card_db: CardDatabase) -> list[Action]:
    if player.energy_attached_this_turn:
        return []
    has_energy_in_hand = any((card_db.get(c) or _NullCard()).is_energy for c in player.hand)
    if not has_energy_in_hand:
        return []
    from effects.passives import special_energy_attach_locked
    from engine.energy import current_state

    bound = current_state()
    special_locked = bound is not None and special_energy_attach_locked(
        bound, card_db, 0 if player is bound.players[0] else 1
    )  # Cursed Glare: 相手のバトルポケモンの特性で、手札から特殊エネルギーをつけられない
    if player.special_energy_attach_locked_until_turn > 0 and player.turns_taken <= player.special_energy_attach_locked_until_turn:
        special_locked = True  # Bind Pulse: 相手の次の番、手札から特殊エネルギーをつけられない
    actions: list[Action] = []
    for i, card_id in enumerate(player.hand):
        card = card_db.get(card_id)
        if card is None or not card.is_energy:
            continue
        if special_locked and card.is_special_energy:
            continue
        from effects.era_energy_j import attach_needs_other_hand_card

        if attach_needs_other_hand_card(card_db, card_id) and len(player.hand) < 2:
            continue  # オーロラエネルギー: つけるには、手札のほかのカードを1枚トラッシュする
        if card.is_special_energy and player.special_energy_locked_until_turn > 0 and player.turns_taken <= player.special_energy_locked_until_turn:
            continue  # Chaos Wheel: 相手の次の番、手札から特殊エネルギーをつけられない
        if (
            player.active is not None
            and _energy_attach_allowed(card_db, card_id, player.active)
            and not _energy_attach_blocked_by_effect(player, player.active)
        ):
            actions.append(AttachEnergy(i, Zone.ACTIVE))
        for bi, mon in enumerate(player.bench):
            if _energy_attach_allowed(card_db, card_id, mon) and not _energy_attach_blocked_by_effect(player, mon):
                actions.append(AttachEnergy(i, Zone.BENCH, bi))
    return actions


def _energy_attach_blocked_by_effect(player: PlayerState, mon: PokemonInPlay) -> bool:
    """Cross Slicer等: 「相手は次の番、手札からこのポケモンにエネルギーをつけられない」。"""
    return mon.no_energy_attach_until_turn > 0 and player.turns_taken <= mon.no_energy_attach_until_turn


_ITEM_TARGETS_OPPONENT_BENCH = {"sv4-160", "sm4-91", "sv5-157", "sm12-192"}  # Counter Catcher(2種) / Prime Catcher / グレートキャッチャー: 相手のベンチポケモンをバトル場に呼び出す(Escape Ropeは相手が自分で選ぶので対象指定は不要)
_ITEM_TARGETS_OWN_BENCH = {"swsh10-139", "bw5-93", "swsh1-170", "sv9-153", "mbd-15"}  # ダークパッチ(2種)/メタルソーサー/マルチつけかえ/Nのポイントアップ/ワンダーパッチ: 自分のベンチポケモンを対象に取る
_SCOOP_UP_NET_ID = "swsh2-165"  # スクープアップネット: 自分の場のポケモン(バトル場もベンチも)から、ポケモンV・ポケモンGX以外の1匹を手札に戻す
_RARE_CANDY_IDS = {"sm1-129", "sv1-191", "me1-125"}  # ふしぎなアメ(印刷違い)


def _has_rare_candy_evolution_in_hand(player: PlayerState, mon: PokemonInPlay, card_db: CardDatabase) -> bool:
    """このたねポケモンが「出したばかり」でなく、対応する2進化先が手札にあるか(ふしぎなアメの対象判定)。"""
    if mon.turn_played == player.turns_taken:
        return False
    target_card = card_db.get(mon.card_id)
    if target_card is None or not target_card.is_basic:
        return False
    for card_id in player.hand:
        card = card_db.get(card_id)
        if card is None or "Stage 2" not in card.subtypes or card.evolves_from is None:
            continue
        if any(c.name == card.evolves_from and c.evolves_from == target_card.name for c in card_db.find_by_name(card.evolves_from)):
            return True
    return False
_CRAM_O_MATIC_ID = "swsh8-229"  # ウッウロボ: 手札の他のグッズカードを1枚捨てなければ使えない
_POKEMON_COMMUNICATION_ID = "sm9-152"  # ポケモン通信: 手札に他のポケモンがいなければ使えない
_MANDATORY_PAIR_ITEM_IDS = {"swsh8-230", "me4-83"}  # クロススイッチャー/Transformation Tome  # クロススイッチャー: 実カードでは単独プレイ不可、2枚同時使用が必須
_PAIRED_EFFECT_TARGETS_OPPONENT_BENCH = {"sm8-171", "swsh8-230"}  # カスタムキャッチャー/クロススイッチャー: 2枚同時使用時のみ相手ベンチが対象になる
_GX_EX_SUBTYPES = {"GX", "EX"}  # "Pokémon-GX"/"Pokémon-EX"(旧EX)のみ。現行の小文字"ex"は別メカニクスのため対象外
_ITEM_TARGETS_OPPONENT_BENCH_GX_EX_ONLY = {"sm12-192"}  # グレートキャッチャー: 対象は相手のベンチのGX/EXポケモンのみ
_BEAST_RING_ID = "sm6-102"  # ビーストリング: 相手の残りサイドが3か4枚のときのみ使え、対象は自分のウルトラビースト限定
_COUNTER_CATCHER_ID = "sv4-160"  # Counter Catcher: 自分の残りサイドが相手より多いときのみ使える
_HEAD_RINGER_ID = "xy4-97"  # ヘッドノイザー(Head Ringer): 相手のバトルポケモン(EX、どうぐ無し)につける道具
_CRUSHING_HAMMER_IDS = ("sv1-168", "me3-71", "me5-105")  # クラッシュハンマー(Crushing Hammer): エネルギーがついている相手のポケモン(バトル/ベンチ問わず)限定
_POKEMON_CATCHER_IDS = ("sv1-187", "me3-82")  # ポケモンキャッチャー(Pokémon Catcher): コインオモテなら相手のベンチポケモン1匹を選んでバトル場に呼び出す
# (2026-08-26発覚: 以前はこのカードの対象選択が一切ゲートされておらず、target_bench_indexが常に
# Noneのままprint_effects側のForceOpponentSwitchChosenBenchが早期returnして不発になっていた)


_ACE_SPEC_LOCK_OWNER_CARD_IDS = {"sv6a-40"}  # ゲノセクトの特性「エースキャンセラー」: どうぐがついていれば相手のACE SPECを封じる


def _ace_spec_locked_by_opponent(opponent: PlayerState, card_db: CardDatabase) -> bool:
    """opponentが場にエースキャンセラー持ちのポケモン(どうぐ付き)を出しているか
    (=このプレイヤーはACE SPECのカードを手札から出して使えない)。Sealing Scream(両プレイヤーがACE SPECを使えない)も含む。"""
    from effects.passives import ace_spec_locked
    from engine.energy import current_state

    bound = current_state()
    if bound is not None and ace_spec_locked(bound, card_db):
        return True
    return any(
        mon.card_id in _ACE_SPEC_LOCK_OWNER_CARD_IDS and mon.attached_tool is not None
        for mon in opponent.all_pokemon_in_play()
    )


def _requires_bench_space(card_id: str) -> bool:
    """山札/トラッシュからたねポケモンを直接ベンチに出す効果を持つか(ネストボール/ポフィン/
    げんきのかけら等はベンチが埋まっていると使えない)。"""
    return any(
        isinstance(e, (SearchDeckForBasicPokemonToBench, SearchDiscardForBasicPokemonToBench, SearchDiscardForPokemonOfTypeToBench))
        for e in get_trainer_script(card_id)
    )


def _discard_search_match_predicate(effect):
    """トラッシュから何かを探すトレーナーエフェクトの「対象に合致するか」判定関数を返す
    (対象がトラッシュに1枚も無ければ、使っても何も起きないため合法手として出さないゲート用)。
    該当しないエフェクトクラスならNone。"""
    if isinstance(effect, (ShuffleFromDiscardIntoDeck, SearchDiscardForPokemonOrEnergy)):
        return lambda c: c is not None and (c.is_pokemon or (c.is_energy and not c.is_special_energy))
    if isinstance(effect, ShuffleSupportersFromDiscardIntoDeck):
        return lambda c: c is not None and c.is_supporter
    if isinstance(effect, SearchDiscardForSPAndEnergy):
        return lambda c: c is not None and (c.is_sp_pokemon or (c.is_energy and not c.is_special_energy))
    if isinstance(effect, SearchDiscardForPokemonToHand):
        return lambda c: c is not None and c.is_pokemon
    if isinstance(effect, SearchDiscardForBasicEnergyToHand):
        et = effect.energy_type
        return lambda c: c is not None and c.is_energy and not c.is_special_energy and (et is None or c.basic_energy_type == et)
    if isinstance(effect, (SearchDiscardForPokemonOfTypeToHand, SearchDiscardForPokemonOfTypeToBench)):
        pt = effect.pokemon_type
        return lambda c: c is not None and c.is_pokemon and pt in c.types
    if isinstance(effect, ShuffleSpecialEnergyFromDiscardIntoDeck):
        return lambda c: c is not None and c.is_special_energy
    if isinstance(effect, SearchDiscardForBasicPokemonToBench):
        return lambda c: c is not None and c.is_basic
    if isinstance(effect, (AttachEnergyFromDiscardToOwnPokemon, AttachEnergyFromDiscardToSelf)):
        et = effect.energy_type
        return lambda c: c is not None and (c.basic_energy_type == et if et else (c.is_energy and not c.is_special_energy))
    if isinstance(effect, AttachEnergyFromDiscardToEachOwnBenchedOfType):
        return lambda c: c is not None and c.is_energy and not c.is_special_energy
    if isinstance(effect, SearchDiscardForSupporterToHand):
        return lambda c: c is not None and c.is_supporter
    if isinstance(effect, SearchDiscardForSupporterOrStadiumToHand):
        return lambda c: c is not None and (c.is_supporter or c.is_stadium)
    if isinstance(effect, SearchDiscardAnyCardToHand):
        return lambda c: c is not None
    if isinstance(effect, SearchDiscardForSubtypeToHand):
        st = effect.subtype
        return lambda c: c is not None and st in c.subtypes
    if isinstance(effect, SearchDiscardForTrainerToHand):
        return lambda c: c is not None and (c.is_item or c.is_supporter or c.is_stadium)
    return None


def _blocked_by_missing_discard_target(card_id: str, card_db: CardDatabase, player: PlayerState) -> bool:
    """トラッシュから何かを探す効果を持つトレーナーズカードで、実際にトラッシュに対象が
    1枚も無ければ、使っても無意味なので合法手として出さない(すごいつりざお/ともだちてちょう/
    オーリム博士の気迫の道具版等、多数のカードに共通するパターン)。"""
    for effect in get_trainer_script(card_id):
        predicate = _discard_search_match_predicate(effect)
        if predicate is not None and not any(predicate(card_db.get(cid)) for cid in player.discard):
            return True
    return False


def _blocked_by_insufficient_discard_cost(card_id: str, card_db: CardDatabase, player: PlayerState) -> bool:
    """DiscardCardsFromHandを必須コストとして持つトレーナーズカード(ハイパーボール等)で、
    自分自身を除いた手札に条件に合うカードが足りず、コストを支払いきれなければ合法手として
    出さない(手札がハイパーボール自身しか無いのに、コストを実質0枚で使えてしまう不具合があった。
    DiscardCardsFromHand.executeはn=min(count, len(hand))で静かに枚数を切り下げるだけで、
    本来は「支払えないなら使えない」が実際のルールのため、legal_actions側でゲートする)。"""
    remaining_hand = list(player.hand)
    if card_id in remaining_hand:
        remaining_hand.remove(card_id)
    for effect in get_trainer_script(card_id):
        if not isinstance(effect, DiscardCardsFromHand):
            continue
        matches = 0
        for cid in remaining_hand:
            c = card_db.get(cid)
            if effect.only_item and not (c is not None and c.is_item):
                continue
            if effect.only_energy_type and not (c is not None and c.basic_energy_type == effect.only_energy_type):
                continue
            if effect.only_energy_types_any and not (
                c is not None and c.basic_energy_type in effect.only_energy_types_any
            ):
                continue
            matches += 1
        if matches < effect.count:
            return True
    return False


def _is_ultra_beast(card_db: CardDatabase, card_id: str) -> bool:
    card = card_db.get(card_id)
    return card is not None and "Ultra Beast" in card.subtypes


def _has_gx_ex_subtype(card_db: CardDatabase, card_id: str) -> bool:
    card = card_db.get(card_id)
    return card is not None and bool(_GX_EX_SUBTYPES & set(card.subtypes))


def _item_actions(state: GameState, player: PlayerState, card_db: CardDatabase) -> list[Action]:
    if player.items_locked_until_turn > 0 and player.turns_taken <= player.items_locked_until_turn:
        return []  # オーシャンカース/かゆいかふん等: 相手の次の番、グッズを使えない
    if items_blocked_by_vileplume(state, card_db):
        return []  # ラフレシアの「Irritating Pollen」: 両プレイヤーがグッズを使えない
    opponent = state.players[1] if player is state.players[0] else state.players[0]
    if items_blocked_by_active_trevenant(opponent):
        return []  # オーロットの「Forest's Curse」: 相手がバトル場にいる間、グッズを使えない
    from effects.passives import items_locked

    if items_locked(state, card_db, 0 if player is state.players[0] else 1):
        return []  # Magic Room/Oceanic Curse: 相手のバトルポケモンの特性でグッズを使えない
    actions: list[Action] = []
    for i, raw_card_id in enumerate(player.hand):
        card_id = canonical_id(raw_card_id)  # 同名・同文面の再録は代表のIDとして扱う(effects/card_aliases.py)
        card = card_db.get(card_id)
        # ヘッドノイザー(xy4-97)はpokemontcg.io上のsubtypesが"Pokémon Tool F"という特殊表記のため
        # is_item判定に乗らない。相手のポケモンにつく道具でPlayPokemonToolの対象にもならないため、
        # 通常のグッズと同じPlayItem経路で個別に許可する。
        if card is None or not (card.is_item or card_id == _HEAD_RINGER_ID):
            continue
        if "ACE SPEC" in card.subtypes and _ace_spec_locked_by_opponent(opponent, card_db):
            continue  # ゲノセクトの特性「エースキャンセラー」
        if card_id in ITEM_AS_POKEMON:
            continue  # みがわりロボ/Antique〜Fossil: 通常のグッズとしては使えず、_play_basic_pokemon_actions経由のみ
        if _requires_bench_space(card_id) and len(player.bench) >= effective_bench_limit(state, player, card_db):
            continue
        from effects.era_trainers import trainer_playable

        if not trainer_playable(state, player, 0 if player is state.players[0] else 1, card_id, card_db):
            continue  # スクープアップサイクロン/ふっかつそう等: 対象が無ければ使えない(effects/era_trainers.py)
        if _blocked_by_missing_discard_target(card_id, card_db, player):
            continue  # すごいつりざお/ともだちてちょう等: トラッシュに対象が無ければ使えない
        if _blocked_by_insufficient_discard_cost(card_id, card_db, player):
            continue  # ハイパーボール等: 手札(自分自身を除く)にコスト分捨てられるカードが無ければ使えない
        if card_id == "sv9-153" and (
            not any(
                (c := card_db.get(cid)) is not None and c.is_energy and not c.is_special_energy
                for cid in player.discard
            )
            or not any(
                (c := card_db.get(mon.card_id)) is not None and c.name.startswith("N's ")
                for mon in player.bench
            )
        ):
            continue  # Nのポイントアップ: トラッシュに基本エネルギーが無い、またはベンチにN'sポケモンがいなければ使えない
        if card_id == _BEAST_RING_ID and len(opponent.prizes) not in (3, 4):
            continue
        if card_id in ("me4-82", "me4-113") and len(opponent.prizes) > 3:
            continue  # スペシャルレッドカード(2種の絵柄違い): 相手の残りサイドが3枚以下でないと使えない
        if card_id in (_COUNTER_CATCHER_ID, "sm4-91") and not (len(player.prizes) > len(opponent.prizes)):
            continue  # sm4-91はCounter Catcherの旧版(SM期)で実カードテキストは同一
        if card_id == _HEAD_RINGER_ID:  # ヘッドノイザー: 相手の場の任意のEXポケモン(どうぐ無し)が対象
            def _is_valid_head_ringer_target(mon) -> bool:
                if mon is None or mon.attached_tool is not None:
                    return False
                mon_card = card_db.get(mon.card_id)
                return mon_card is not None and "EX" in mon_card.subtypes

            if opponent.active is not None and _is_valid_head_ringer_target(opponent.active):
                actions.append(PlayItem(i, None))
            for bi, mon in enumerate(opponent.bench):
                if _is_valid_head_ringer_target(mon):
                    actions.append(PlayItem(i, bi))
            continue
        if card_id == _POWER_SPRAY_ID:
            # パワースプレーは「相手がポケパワーを使った瞬間」にのみ使える割り込み専用カードで、
            # 自分の番に通常のグッズとしては使えない(UsePowerSprayアクション経由でのみ発動する)。
            continue
        if card_id in _MANDATORY_PAIR_ITEM_IDS:  # クロススイッチャー: 単独プレイは合法手に出さない(下のペア列挙のみ)
            continue
        if card_id == "sv2-189" and len(player.hand) < 3:  # スーパーエネルギー回収: 自分自身を除き手札に2枚以上無ければ使えない
            continue
        if card_id == "swsh11-162" and len(player.hand) < 2:  # ロストバキューム: 自分自身を除き手札に1枚以上無ければ使えない
            continue
        if card_id == "swsh11-163" and len(player.lost_zone) < 7:  # ミラージュゲート: ロストゾーンに7枚以上無ければ使えない
            continue
        if card_id == "sv6-165" and not player.pokemon_ko_last_turn:  # アンフェアスタンプ: 相手の直前の番に自分のポケモンがきぜつしていたときのみ
            continue
        if card_id == "dp7-86" and "dp7-86" in player.discard:
            continue  # ラグジュアリーボール: 自分のトラッシュにラグジュアリーボールがあるときは使えない
        if card_id == "m2-73" and (player.active is None or len(player.active.attached_energy) < 3):
            continue  # ジャンボアイス: 自分のバトルポケモンにエネルギーが3個以上ついていなければ使えない
            # (以前は条件を満たさなくても使用でき、何も回復せず無駄にトラッシュされてしまっていた、
            # 2026-09-02ユーザー報告「使えない状態で選択肢に出てくる」で発覚)
        if card_id == "sv7-135" and (
            not any(
                (c := card_db.get(mon.card_id)) is not None and "Tera" in c.subtypes
                for mon in player.all_pokemon_in_play()
            )
            or not any(
                (e := card_db.get(eid)) is not None and e.is_energy and not e.is_special_energy
                for eid in player.discard
            )
        ):
            continue  # ガラスのラッパ: 自分の場にテラスタルポケモンがいない、またはトラッシュに
            # 基本エネルギーが1枚も無ければ使えない(2026-08-21再発覚: is_basic限定の修正だけでは
            # 解消しておらず、ユーザーから再度指摘を受けた)
        if card_id in ("bw6-116", "me2pt5-212", "rsv10pt5-85", "me4-115") and not any(
            mon.attached_tool is not None for player_side in state.players for mon in player_side.all_pokemon_in_play()
        ):
            continue  # どうぐハンター(Tool Scrapper): 場(自分・相手どちらも)にどうぐが1枚も無ければ
            # 使えない(2026-09-03ユーザー報告「お互いのポケモンについていないのに使える」で発覚)
        if card_id == "sm2-125" and not (
            any(mon.attached_tool is not None for player_side in state.players for mon in player_side.all_pokemon_in_play())
            or state.stadium_in_play is not None
        ):
            continue  # かるいし(Field Blower): 場にどうぐもスタジアムも無ければ使えない(Tool Scrapperと同根のバグ)
        if card_id in ("bw5-94", "sm2-124") and not any(
            (e := card_db.get(eid)) is not None and e.is_special_energy
            for mon in opponent.all_pokemon_in_play()
            for eid in mon.attached_energy
        ):
            continue  # 改造ハンマー/つよいひっぱりハンマー(Enhanced Hammer): 相手の場に特殊エネルギーが
            # 1枚も無ければ使えない(以前はこの前提条件が一切ゲートされておらず、対象が無くても
            # 使えてしまっていた、2026-08-23ユーザー報告で発覚)
        if card_id == "xy3-89" and (
            len(player.all_pokemon_in_play()) < 2
            or not any(
                (c := card_db.get(eid)) is not None and c.basic_energy_type is not None
                for mon in player.all_pokemon_in_play()
                for eid in mon.attached_energy
            )
        ):
            continue  # エネルギーつけかえ: 移動先が無い(場のポケモンが1匹だけ)、または場のどのポケモンにも基本エネルギーがついていなければ使えない
        from effects.era_trainers import era_item_targets

        era_targets = era_item_targets(card_id, state, player, opponent, card_db)
        if era_targets is not None:  # フェアリードロップ/メガキャッチャー等: 対象を選べるものだけ(effects/era_trainers.py)
            for target in era_targets:
                actions.append(PlayItem(i, target))
            continue
        if card_id == _CRAM_O_MATIC_ID:  # ウッウロボ: 他に捨てられるグッズがなければ使えない
            has_other_item = any(
                j != i and (card_db.get(cid2) or _NullCard()).is_item for j, cid2 in enumerate(player.hand)
            )
            if not has_other_item:
                continue
            actions.append(PlayItem(i))
        elif card_id == _POKEMON_COMMUNICATION_ID:  # ポケモン通信: 手札に他のポケモンがいなければ使えない
            has_other_pokemon = any(
                j != i and (card_db.get(cid2) or _NullCard()).is_pokemon for j, cid2 in enumerate(player.hand)
            )
            if not has_other_pokemon:
                continue
            actions.append(PlayItem(i))
        elif card_id == "sm2-129":  # マルチつけかえ: ベンチにエネルギーのついたポケモンがいて、バトルポケモンがいるときだけ(移すエネルギーはプレイヤーが選ぶ)
            if player.active is not None and any(mon.attached_energy for mon in player.bench):
                actions.append(PlayItem(i))
        elif card_id == "sm2-130":  # レスキュータンカ: ①ポケモン1枚を手札に(target None) ②ポケモン3枚を山札に(target 0、3枚以上のとき)
            pokemon_in_discard = sum(1 for cid in player.discard if (card_db.get(cid) or _NullCard()).is_pokemon)
            if pokemon_in_discard >= 1:
                actions.append(PlayItem(i, None))
            if pokemon_in_discard >= 3:
                actions.append(PlayItem(i, 0))
        elif card_id in ("xy0-38", "sv1-194", "swsh1-183", "sm1-132"):  # Switch: ベンチポケモンが必須、対象は必ずベンチ
            for bi in range(len(player.bench)):
                actions.append(PlayItem(i, bi))
        elif card_id == "swsh10-154":  # のりかえチケット(Switch Cart): バトルポケモンがたねポケモンのときのみ、対象は必ずベンチ
            if player.active is not None and (c := card_db.get(player.active.card_id)) is not None and c.is_basic:
                for bi in range(len(player.bench)):
                    actions.append(PlayItem(i, bi))
        elif card_id in ("xy0-37", "sm2-128", "me3-83", "bw2-94", "bw9-121"):  # Potion / Max Potion: 自分のバトル/ベンチどちらでも対象にできる
            if player.active is not None:
                actions.append(PlayItem(i, None))
            for bi in range(len(player.bench)):
                actions.append(PlayItem(i, bi))
        elif card_id == "xy6-86":  # メガターボ(Mega Turbo): 対象は自分のメガシンカポケモンのみ(バトル場/ベンチどちらも可)
            if player.active is not None and (c := card_db.get(player.active.card_id)) is not None and "MEGA" in c.subtypes:
                actions.append(PlayItem(i, None))
            for bi, mon in enumerate(player.bench):
                bc = card_db.get(mon.card_id)
                if bc is not None and "MEGA" in bc.subtypes:
                    actions.append(PlayItem(i, bi))
        elif card_id == _BEAST_RING_ID:  # ビーストリング: 対象は自分のウルトラビーストのみ
            if player.active is not None and _is_ultra_beast(card_db, player.active.card_id):
                actions.append(PlayItem(i, None))
            for bi, mon in enumerate(player.bench):
                if _is_ultra_beast(card_db, mon.card_id):
                    actions.append(PlayItem(i, bi))
        elif card_id == "pl1-118":  # Poké Turn: 場のSPポケモン(バトル場・ベンチどちらも)が対象
            active_card = card_db.get(player.active.card_id) if player.active is not None else None
            if active_card is not None and active_card.is_sp_pokemon:
                actions.append(PlayItem(i, None))
            for bi, mon in enumerate(player.bench):
                bench_card = card_db.get(mon.card_id)
                if bench_card is not None and bench_card.is_sp_pokemon:
                    actions.append(PlayItem(i, bi))
        elif card_id in _CRUSHING_HAMMER_IDS:  # クラッシュハンマー: エネルギーがついている相手の場のポケモン(バトル/ベンチ問わず)のみ対象
            if opponent.active is not None and opponent.active.attached_energy:
                actions.append(PlayItem(i, None))
            for bi, mon in enumerate(opponent.bench):
                if mon.attached_energy:
                    actions.append(PlayItem(i, bi))
        elif card_id in _POKEMON_CATCHER_IDS:  # ポケモンキャッチャー: 相手のベンチポケモン1匹を選ぶ(コインの結果に関わらず、まず対象を決めてから実行時にコインを振る)
            for bi in range(len(opponent.bench)):
                actions.append(PlayItem(i, bi))
        elif card_id in _ITEM_TARGETS_OPPONENT_BENCH:
            gx_ex_only = card_id in _ITEM_TARGETS_OPPONENT_BENCH_GX_EX_ONLY
            for bi, mon in enumerate(opponent.bench):
                if gx_ex_only and not _has_gx_ex_subtype(card_db, mon.card_id):
                    continue
                actions.append(PlayItem(i, bi))
        elif card_id == _SCOOP_UP_NET_ID:
            def _scoopable(mon_card_id: str) -> bool:
                scoop_card = card_db.get(mon_card_id)
                return scoop_card is not None and not ({"V", "GX"} & set(scoop_card.subtypes))

            if player.active is not None and _scoopable(player.active.card_id):
                actions.append(PlayItem(i, None))
            for bi, mon in enumerate(player.bench):
                if _scoopable(mon.card_id):
                    actions.append(PlayItem(i, bi))
        elif card_id in _ITEM_TARGETS_OWN_BENCH:
            type_filter, subtype_filter, name_prefix_filter = _attach_target_filters(get_trainer_script(card_id))
            for bi, mon in enumerate(player.bench):
                if type_filter is not None or subtype_filter is not None or name_prefix_filter is not None:
                    bc = card_db.get(mon.card_id)
                    if bc is None:
                        continue
                    if type_filter is not None and type_filter not in bc.types:
                        continue
                    if subtype_filter is not None and subtype_filter not in bc.subtypes:
                        continue
                    if name_prefix_filter is not None and not bc.name.startswith(name_prefix_filter):
                        continue
                actions.append(PlayItem(i, bi))
        elif card_id in _RARE_CANDY_IDS:  # ふしぎなアメ: 該当2進化先が手札にあるたねポケモンのみが対象
            if player.turns_taken > 1:
                if player.active is not None and _has_rare_candy_evolution_in_hand(player, player.active, card_db):
                    actions.append(PlayItem(i, None))
                for bi, mon in enumerate(player.bench):
                    if _has_rare_candy_evolution_in_hand(player, mon, card_db):
                        actions.append(PlayItem(i, bi))
        elif card_id == "sv10-179":  # ロケット団の切り札爆弾(Team Rocket's Venture Bomb): 表なら相手の
            # 場のポケモン1匹(バトル/ベンチどちらも可)を選んでダメカン、裏なら自分のバトルポケモンに
            # ダメカン。コインの結果に関わらず対象を先に決め、実行時にコインを振る
            if opponent.active is not None:
                actions.append(PlayItem(i, None))
            for bi in range(len(opponent.bench)):
                actions.append(PlayItem(i, bi))
        else:
            actions.append(PlayItem(i))

    # 「2枚同時使用」カードのペア使用を追加で列挙する(同じカードが2枚以上手札にある場合のみ)
    seen_paired_ids: set[str] = set()
    for i, card_id in enumerate(player.hand):
        if card_id in seen_paired_ids:
            continue
        paired_script = get_trainer_paired_script(card_id)
        if not paired_script:
            continue
        other_indices = [j for j, cid2 in enumerate(player.hand) if cid2 == card_id and j != i]
        if not other_indices:
            continue
        seen_paired_ids.add(card_id)
        j = other_indices[0]
        if card_id in _PAIRED_EFFECT_TARGETS_OPPONENT_BENCH:
            for bi in range(len(opponent.bench)):
                actions.append(PlayItem(i, bi, paired_hand_index=j))
        else:
            actions.append(PlayItem(i, paired_hand_index=j))
    # 「4枚同時使用」カード(ミッシングクローバー/カルテットストーン): 同じカードが4枚以上手札にあるときの4枚使用
    from effects.registry import TRAINER_QUAD_EFFECTS

    seen_quad_ids: set[str] = set()
    for i, card_id in enumerate(player.hand):
        if card_id in seen_quad_ids or card_id not in TRAINER_QUAD_EFFECTS:
            continue
        same = [j for j, cid2 in enumerate(player.hand) if cid2 == card_id and j != i]
        if len(same) < 3:
            continue
        seen_quad_ids.add(card_id)
        actions.append(PlayItem(i, paired_hand_index=same[0], extra_hand_indices=(same[1], same[2])))
    return actions


_SUPPORTER_TARGETS_OPPONENT_BENCH = {"me1-114", "sv2-172", "swsh9-132", "swsh2-154", "sm3-115"}  # Boss's Orders: 相手のベンチポケモンをバトル場に呼び出す
_SUPPORTER_TARGETS_OWN_BENCH = {"sm12-198", "me2pt5-200", "me4-106", "me4-120"}  # カミツレのきらめき/マオ&スイレン/サーファー/AZのやすらぎ(2種): 自分のベンチポケモンを対象に取る
_JACINTHE_IDS = ("me3-75", "me3-110", "me3-122")  # ジャシンテ(Jacinthe): 自分の超タイプのポケモン(バトル/ベンチ)が対象。150ダメージ回復
_GREENS_EXPLORATION_ID = "sm10-175"  # ブルーの探索(Green's Exploration): 自分の場に特性持ちポケモンがいると使えない
_BRIAR_ID = "sv7-132"  # ブライアー: 相手の残りサイドがちょうど2枚のときのみ使える
_TEAMMATES_ID = "xy5-141"  # Teammates: 相手の直前の番に自分のポケモンがきぜつしたときのみ使える
_ACE_TRAINER_ID = "xy7-69"  # エリートトレーナー: 自分の残りサイドが相手より多いときのみ使える
_ARCHIE_ACE_IN_THE_HOLE_ID = "xy5-124"  # アオギリの切り札(Archie's Ace in the Hole): 手札の最後の1枚のときのみ使える
_MAY_ENCOURAGEMENT_IDS = (
    "m3-75",  # メイのはげまし: 自分の残りサイドが相手より多いときのみ使える
    "me3-114", "me3-123",  # Rosa's Encouragement(同じ実カードテキストの別収録版、2026-08-26追加)
)
_MATSUBA_CONVICTION_ID = "sv5k-69"  # マツバの確信: 手札を1枚トラッシュしなければ使えない(このカード自身を除いて1枚以上必要)
_GIOVANNI_TEAM_ROCKET_ID = "sv10-174"  # ロケット団のサカキ: バトル場もベンチ入れ替え先も「Team Rocket's」ポケモン限定


_SUPPORTER_TURN1_EXCEPTION_IDS = {
    "sv10-177",  # ロケット団のランス(Team Rocket's Proton)実カードテキスト:
    # "If you go first, you may use this card during your first turn."
    "me2pt5-208", "sv10-227",  # ロケット団のランス 別絵柄
}


def _supporter_actions(state: GameState, actor: int, player: PlayerState, card_db: CardDatabase) -> list[Action]:
    from effects.passives import can_play_two_supporters, supporters_locked

    if player.supporter_played_this_turn and not (
        (player.supporters_played_count_this_turn < 2 and can_play_two_supporters(state, card_db, actor))
        or player.supporters_played_count_this_turn < player.supporters_allowed_this_turn
    ):
        return []  # Dual Brains/Lt. Surge's Strategy: 自分の番にサポートを2枚/3枚使える
    if supporters_locked(state, card_db, actor):
        return []  # Sentinel: 相手のバトルポケモンの特性でサポートを使えない
    if player.supporters_locked_until_turn > 0 and player.turns_taken <= player.supporters_locked_until_turn:
        return []  # Blockade等: 相手の次の番、サポートを使えない
    opponent = state.players[1] if player is state.players[0] else state.players[0]
    turn1_supporter_blocked = not _supporter_allowed(state, actor, player)
    actions: list[Action] = []
    for i, raw_card_id in enumerate(player.hand):
        card_id = canonical_id(raw_card_id)
        card = card_db.get(card_id)
        if card is None or not card.is_supporter:
            continue
        if turn1_supporter_blocked and card_id not in _SUPPORTER_TURN1_EXCEPTION_IDS:
            from effects.era_trainer_gates import turn1_exception_ids

            if card_id not in turn1_exception_ids():  # 自動生成したカード(Carmine等)の「先攻でも最初の番に使える」例外
                continue
        if "ACE SPEC" in card.subtypes and _ace_spec_locked_by_opponent(opponent, card_db):
            continue  # ゲノセクトの特性「エースキャンセラー」
        if _requires_bench_space(card_id) and len(player.bench) >= effective_bench_limit(state, player, card_db):
            continue
        from effects.era_trainers import trainer_playable

        if not trainer_playable(state, player, actor, card_id, card_db):
            continue  # カシウス/フレア団のしたっぱ等: 対象が無ければ使えない(effects/era_trainers.py)
        if _blocked_by_missing_discard_target(card_id, card_db, player):
            continue  # シロナ&カトレア/ルザミーネ等: トラッシュに対象が無ければ使えない
        if _blocked_by_insufficient_discard_cost(card_id, card_db, player):
            continue  # 手札(自分自身を除く)にコスト分捨てられるカードが無ければ使えない
        if card_id in ("me5-81", "me5-112") and not player.pokemon_ko_last_turn:  # ラストシンジケートのしたっぱ(Rust Syndicate Grunt、2種の絵柄違い): 相手の直前の番に自分のポケモンがきぜつしていたときのみ
            continue
        if card_id == "swsh7-152" and not player.pokemon_ko_last_turn:  # カイ(Raihan): 相手の直前の番に自分のポケモンがきぜつしていたときのみ
            continue
        if card_id == _GREENS_EXPLORATION_ID and any(
            (c := card_db.get(mon.card_id)) is not None and c.abilities for mon in player.all_pokemon_in_play()
        ):
            continue
        if card_id == _BRIAR_ID and len(opponent.prizes) != 2:
            continue
        if card_id == _TEAMMATES_ID and not player.pokemon_ko_last_turn:
            continue
        if card_id == _ACE_TRAINER_ID and not (len(player.prizes) > len(opponent.prizes)):
            continue
        if card_id in _MAY_ENCOURAGEMENT_IDS and not (len(player.prizes) > len(opponent.prizes)):
            continue
        if card_id == _MATSUBA_CONVICTION_ID and len(player.hand) < 2:
            continue
        if card_id in ("sv10-170", "me2pt5-201", "sv10-223") and not player.team_rocket_pokemon_ko_last_turn:
            continue  # ロケット団のアポロ(Team Rocket's Archer): 直前の相手の番に自分の「Team Rocket's」ポケモンがきぜつしていなければ使えない
        if card_id == _GIOVANNI_TEAM_ROCKET_ID and (
            player.active is None
            or not is_team_rockets_pokemon(card_db.get(player.active.card_id))
            or not any(is_team_rockets_pokemon(card_db.get(mon.card_id)) for mon in player.bench)
        ):
            continue
        if card_id == _ARCHIE_ACE_IN_THE_HOLE_ID and len(player.hand) != 1:
            continue
        if card_id == "sv4-170" and (  # オーリム博士の気迫: 場に「Ancient」ポケモンが無い、またはトラッシュに基本エネルギーが無ければ使えない
            not any(
                (c := card_db.get(mon.card_id)) is not None and "Ancient" in c.subtypes
                for mon in player.all_pokemon_in_play()
            )
            or not any(
                (c := card_db.get(cid)) is not None and c.is_energy and not c.is_special_energy
                for cid in player.discard
            )
        ):
            continue
        if card_id in _SUPPORTER_TARGETS_OPPONENT_BENCH:
            for bi in range(len(opponent.bench)):
                actions.append(PlaySupporter(i, bi))
        elif card_id == "sv8pt5-113":  # スグリ(Kieran): target_bench_index=Noneなら「この番+30ダメージ」、指定ありなら「そのベンチと入れ替え」
            actions.append(PlaySupporter(i, None))
            for bi in range(len(player.bench)):
                actions.append(PlaySupporter(i, bi))
        elif card_id in ("sm10-189", "swsh7-152"):  # 溶接工/カイ(Raihan): 自分のバトル/ベンチどちらでも対象にできる
            if player.active is not None:
                actions.append(PlaySupporter(i, None))
            for bi in range(len(player.bench)):
                actions.append(PlaySupporter(i, bi))
        elif card_id == "swsh6-146":  # メロン(Melony): 自分のVポケモン(バトル/ベンチ)が対象
            if player.active is not None and (c := card_db.get(player.active.card_id)) is not None and "V" in c.subtypes:
                actions.append(PlaySupporter(i, None))
            for bi, mon in enumerate(player.bench):
                bc = card_db.get(mon.card_id)
                if bc is not None and "V" in bc.subtypes:
                    actions.append(PlaySupporter(i, bi))
        elif card_id in ("sv4-171", "xy4-91", "xy2-93"):  # フトゥー博士のシナリオ/AZ/ポケモンセンターのお姉さん: 自分の場のポケモン(バトル/ベンチ、たね制限なし)が対象
            if player.active is not None:
                actions.append(PlaySupporter(i, None))
            for bi in range(len(player.bench)):
                actions.append(PlaySupporter(i, bi))
        elif card_id == "xy11-103":  # ニンジャごっこ: 自分のたねポケモン(バトル/ベンチ)が対象
            if player.active is not None and (c := card_db.get(player.active.card_id)) is not None and c.is_basic:
                actions.append(PlaySupporter(i, None))
            for bi, mon in enumerate(player.bench):
                bc = card_db.get(mon.card_id)
                if bc is not None and bc.is_basic:
                    actions.append(PlaySupporter(i, bi))
        elif card_id == "sv1-183":  # ペニー: 自分のたねポケモン(バトル/ベンチ)が対象
            if player.active is not None and (c := card_db.get(player.active.card_id)) is not None and c.is_basic:
                actions.append(PlaySupporter(i, None))
            for bi, mon in enumerate(player.bench):
                bc = card_db.get(mon.card_id)
                if bc is not None and bc.is_basic:
                    actions.append(PlaySupporter(i, bi))
        elif card_id == "sm3-112":  # アセロラ: ダメカンがのっている自分のポケモン(バトル/ベンチ)が対象
            if player.active is not None and player.active.damage > 0:
                actions.append(PlaySupporter(i, None))
            for bi, mon in enumerate(player.bench):
                if mon.damage > 0:
                    actions.append(PlaySupporter(i, bi))
        elif card_id in _SUPPORTER_TARGETS_OWN_BENCH:
            for bi in range(len(player.bench)):
                actions.append(PlaySupporter(i, bi))
        elif card_id == _GIOVANNI_TEAM_ROCKET_ID:  # ロケット団のサカキ: 自分のベンチの「Team Rocket's」ポケモンが対象
            for bi, mon in enumerate(player.bench):
                if is_team_rockets_pokemon(card_db.get(mon.card_id)):
                    actions.append(PlaySupporter(i, bi))
        elif card_id in ("me1-132", "me1-176"):  # ミツルの思いやり(Wally's Compassion、2種の絵柄違い): 自分のメガシンカex(MEGA+ex)ポケモンが対象
            if (
                player.active is not None
                and (c := card_db.get(player.active.card_id)) is not None
                and "MEGA" in c.subtypes
                and "ex" in c.subtypes
            ):
                actions.append(PlaySupporter(i, None))
            for bi, mon in enumerate(player.bench):
                bc = card_db.get(mon.card_id)
                if bc is not None and "MEGA" in bc.subtypes and "ex" in bc.subtypes:
                    actions.append(PlaySupporter(i, bi))
        elif card_id in _MAY_ENCOURAGEMENT_IDS:  # メイのはげまし/Rosa's Encouragement: 自分の2進化ポケモン(バトル/ベンチ)が対象
            if player.active is not None and (c := card_db.get(player.active.card_id)) is not None and "Stage 2" in c.subtypes:
                actions.append(PlaySupporter(i, None))
            for bi, mon in enumerate(player.bench):
                bc = card_db.get(mon.card_id)
                if bc is not None and "Stage 2" in bc.subtypes:
                    actions.append(PlaySupporter(i, bi))
        elif card_id in _JACINTHE_IDS:  # ジャシンテ: 自分の超タイプのポケモン(バトル/ベンチ)が対象
            if player.active is not None and (c := card_db.get(player.active.card_id)) is not None and "Psychic" in c.types:
                actions.append(PlaySupporter(i, None))
            for bi, mon in enumerate(player.bench):
                bc = card_db.get(mon.card_id)
                if bc is not None and "Psychic" in bc.types:
                    actions.append(PlaySupporter(i, bi))
        elif card_id == "sv9-157":  # ワル者(Ruffian): 相手の場のポケモン1匹(バトル/ベンチどちらでも
            # 指定可)を選ぶ。実際にどうぐ/特殊エネルギーがついているかはeffects.primitives側で判定する
            if opponent.active is not None:
                actions.append(PlaySupporter(i, None))
            for bi in range(len(opponent.bench)):
                actions.append(PlaySupporter(i, bi))
        else:
            actions.append(PlaySupporter(i))
    return actions


_ORIENTED_STADIUM_IDS = {"xy8-145"}  # パラレルシティ(Parallel City): 出すときに「↓」側(効果を受ける側)を選べる


def _stadium_actions(state: GameState, actor: int, player: PlayerState, card_db: CardDatabase) -> list[Action]:
    from effects.era_trainers_g import ANGE_FLOETTE_IDS, PRISM_TOWER_IDS

    prism_tower_in_play = state.stadium_in_play in PRISM_TOWER_IDS
    if player.stadium_played_this_turn:
        # Ange Floette: 場のPrism Towerをトラッシュする場合に限り、Prism Towerを出した同じ番にも出せる(「1番に1枚」の例外)
        if prism_tower_in_play and not (player.stadiums_locked_until_turn > 0 and player.turns_taken <= player.stadiums_locked_until_turn):
            return [PlayStadium(i) for i, cid in enumerate(player.hand) if cid in ANGE_FLOETTE_IDS]
        return []
    if player.stadiums_locked_until_turn > 0 and player.turns_taken <= player.stadiums_locked_until_turn:
        return []  # Chaos Wheel/Frigid Breath: 手札からスタジアムを使えない
    from effects.passives_ext import stadium_play_locked

    if stadium_play_locked(state, card_db):
        return []  # Barrier Shrine: 両プレイヤーが手札からスタジアムを使えない
    from effects.passives_cond import cond_locked

    if cond_locked(state, card_db, actor, "stadium"):
        return []  # Icy Barrier等: 相手の特性で手札からスタジアムを使えない
    opponent = state.players[1 - actor]
    actions: list[Action] = []
    for i, card_id in enumerate(player.hand):
        card = card_db.get(card_id)
        if card is None or not card.is_stadium or card_id == state.stadium_in_play:
            continue
        if card_id in ANGE_FLOETTE_IDS and not prism_tower_in_play:
            continue  # Ange Floette: 場にPrism Towerがあるときだけ出せる
        if "ACE SPEC" in card.subtypes and _ace_spec_locked_by_opponent(opponent, card_db):
            continue  # ゲノセクトの特性「エースキャンセラー」
        if card_id in _ORIENTED_STADIUM_IDS:
            actions.append(PlayStadium(i, orientation_target=actor))
            actions.append(PlayStadium(i, orientation_target=1 - actor))
        else:
            actions.append(PlayStadium(i))
    return actions


_STADIUM_ABILITY_HAND_COST: dict[str, int] = {
    "sm9-156": 1,  # トキワの森: 手札1枚を捨てる
    "sm11-197": 1,  # 巨大なカマド: 手札1枚を捨てる
    "me4-80": 2,  # プリズムタワー: 手札2枚を捨てる
}


def _stadium_ability_actions(state: GameState, player: PlayerState, card_db: CardDatabase) -> list[Action]:
    """「各プレイヤーの番に1回、使ってもよい」スタジアム効果(ウルトラスペース等)。"""
    if player.used_stadium_ability_this_turn or state.stadium_in_play is None:
        return []
    script = get_stadium_ability_script(state.stadium_in_play)
    if not script:
        return []
    hand_cost = _STADIUM_ABILITY_HAND_COST.get(state.stadium_in_play, 0)
    if hand_cost and len(player.hand) < hand_cost:
        return []
    from effects.era_trainers import stadium_ability_playable

    if not stadium_ability_playable(state, player, card_db):
        return []  # ポケモンセンター/ツイストマウンテン/トロピカルビーチ等(effects/era_trainers.py)
    if any(isinstance(e, SearchDeckForBasicPokemonToBench) for e in script) and len(player.bench) >= effective_bench_limit(state, player, card_db):
        return []  # ボウルタウン/せせらぎの丘等: ベンチが埋まっていると使えない
    if state.stadium_in_play == "sm8-178":  # ヒートファクトリー◇: 手札に炎エネルギーが無ければ使えない
        has_fire_energy = any(
            (c := card_db.get(cid)) is not None and c.basic_energy_type == "Fire" for cid in player.hand
        )
        if not has_fire_energy:
            return []
    if state.stadium_in_play in ("sv10-173", "me2pt5-203") and not player.team_rocket_supporter_played_this_turn:
        return []  # ロケット団のファクトリー: この番に「Team Rocket's」の名を含むサポートを使っていなければ使えない
    if state.stadium_in_play == "sv7-136" and not _grand_tree_has_eligible_target(state, player, card_db):
        return []  # グランドツリー: 進化元になれる(出したばかりでない)たねポケモンかつ山札に1進化先が無ければ使えない
    return [UseStadiumAbility()]


def _grand_tree_has_eligible_target(state: GameState, player: PlayerState, card_db: CardDatabase) -> bool:
    """グランドツリー(sv7-136)の対象条件を、effects.primitives.
    InstantEvolveAnyOwnPokemonFromDeckThenChainEvolveのexecute()と同じ基準で事前判定する
    (以前はこの事前チェックが無く、対象になれるポケモンが一切いなくてもUseStadiumAbilityが
    常に合法手に出てしまっていた、2026-08-20発覚)。"""
    if player.turns_taken <= 1:
        return False
    candidates = ([player.active] if player.active is not None else []) + list(player.bench)
    for target in candidates:
        if target.turn_played == player.turns_taken:
            continue
        target_card = card_db.get(target.card_id)
        if target_card is None or not target_card.is_basic:
            continue
        if any(
            (c := card_db.get(cid)) is not None and c.evolves_from == target_card.name and "Stage 1" in c.subtypes
            for cid in player.deck
        ):
            return True
    return False


def _pokemon_tool_actions(player: PlayerState, card_db: CardDatabase) -> list[Action]:
    """ポケモンのどうぐ: 自分の場のポケモン1匹につき1枚まで、自分の番に何枚でも使える。"""
    from effects.passives import tools_locked
    from effects.passives_ext import tool_attach_locked
    from engine.energy import current_state

    bound = current_state()
    if bound is not None and tools_locked(bound, card_db, 0 if player is bound.players[0] else 1):
        return []  # Oceanic Curse: 相手のバトルポケモンの特性でポケモンのどうぐを使えない
    if bound is not None and tool_attach_locked(bound, card_db):
        return []  # Slip Trip: 両プレイヤーが手札からポケモンのどうぐをつけられない
    if player.tools_locked_until_turn > 0 and player.turns_taken <= player.tools_locked_until_turn:
        return []  # Chaos Wheel: 相手の次の番、手札からポケモンのどうぐを使えない
    actions: list[Action] = []
    from effects.era_tools_j import attach_allowed

    for i, card_id in enumerate(player.hand):
        card = card_db.get(card_id)
        if card is None or not card.is_pokemon_tool:
            continue
        if player.active is not None and player.active.attached_tool is None and attach_allowed(bound, card_db, card_id, player.active):
            actions.append(PlayPokemonTool(i, Zone.ACTIVE))
        for bi, mon in enumerate(player.bench):
            if mon.attached_tool is None and attach_allowed(bound, card_db, card_id, mon):
                actions.append(PlayPokemonTool(i, Zone.BENCH, bi))
    return actions


_STATUS_LOCKED_ABILITY_CARD_IDS = {"pl1-41", "dp6-146"}  # 特殊状態中は使えない特性(Galactic Switch/Trade Off)


def _is_vstar_power_ability(ability) -> bool:
    return "VSTAR Power in a game" in (ability.text or "")


_UNLIMITED_ABILITY_USE_CAP = 8  # 「自分の番に何度でも使える」特性の、1番あたりの実効的な上限使用回数


# ユーザー指定の「禁止行動」リスト(2026-09-07〜)。実際のカードルールではなく、学習効率化
# (時短)のためにユーザーが明示的に選択肢から除外することを指定した特性。自己対戦(学習)・
# 対人戦どちらのlegal_actions()にも共通で効き、学習した方策の判断より常に優先される
# (=そもそも合法手として出てこない)。人間が読める一覧はdata/prohibited_actions.mdを参照
# (このコードと二重管理になるため、追加・変更時は両方を更新すること)。
# キー: (card_id, ability.name)。値: (state, player, mon) -> bool(Trueを返すと使用禁止)。
_USER_PROHIBITED_ABILITY_CONDITIONS = {
    # 2026-09-07、LO(山札切れ)対策第1弾: 山札が10枚以下のとき、山札を消費するこの3特性の使用を
    # 一律禁止する(ユーザー指示)。
    ("sv6-129", "Recon Directive"): lambda state, player, mon: len(player.deck) <= 10,  # ドロンチ「ていさつしれい」
    ("sv6pt5-38", "Flip the Script"): lambda state, player, mon: len(player.deck) <= 10,  # キチキギスex「さかてにとる」
    # Nのゾロアークex「とりひき」(Trade): カード検索の結果、実カードデータベース中に同一テキストの
    # 印刷違いが6種類存在するため、全てに適用する(ゾロアークGX(sm35-53)の同名特性は別カードなので対象外)。
    ("sv9-98", "Trade"): lambda state, player, mon: len(player.deck) <= 10,
    ("sv9-175", "Trade"): lambda state, player, mon: len(player.deck) <= 10,
    ("sv9-185", "Trade"): lambda state, player, mon: len(player.deck) <= 10,
    ("sv9-189", "Trade"): lambda state, player, mon: len(player.deck) <= 10,
    ("me2pt5-137", "Trade"): lambda state, player, mon: len(player.deck) <= 10,
    ("me2pt5-286", "Trade"): lambda state, player, mon: len(player.deck) <= 10,
}


# どうぐが「ついているポケモン」に与える特性(どうぐ自身のカードに印刷された特性)。値は、与えられる対象の
# サブタイプ(森の封印石: 「ついているポケモンVはこのカードのVSTARパワーを使える」)。
TOOL_GRANTED_ABILITY_HOST_SUBTYPE: dict[str, str] = {"swsh12-156": "V"}


def _tool_granted_ability_actions(
    state: GameState, player: PlayerState, card_db: CardDatabase, zone: Zone, bi: int | None, mon: PokemonInPlay, card
) -> list[Action]:
    """森の封印石(swsh12-156)実カードテキスト: "The Pokémon V this card is attached to can use the VSTAR
    Power on this card."(VSTARパワー「Star Alchemy」: 山札から好きなカード1枚を手札に加える、1ゲームに1回)。
    ポケモン自身の特性とは別枠なので、ポケモンがその番に自分の特性を使っていても使える。"""
    tool_id = mon.attached_tool
    required_subtype = TOOL_GRANTED_ABILITY_HOST_SUBTYPE.get(tool_id) if tool_id else None
    if required_subtype is None or required_subtype not in card.subtypes or tools_disabled(state.stadium_in_play):
        return []
    tool_card = card_db.get(tool_id)
    if tool_card is None:
        return []
    actions: list[Action] = []
    for ability in tool_card.abilities:
        script = get_ability_script(tool_id, ability.name)
        if not script or all(isinstance(e, NotImplementedEffect) for e in script):
            continue
        if _is_vstar_power_ability(ability) and player.used_vstar_power_this_game:
            continue
        if not _ability_is_feasible(script, mon, card_db, player):
            continue
        actions.append(UseAbility(zone, bi, None, from_tool=True))
    return actions


def _ability_actions(state: GameState, player: PlayerState, card_db: CardDatabase) -> list[Action]:
    from engine.rules_engine import _UNLIMITED_PER_TURN_ABILITY_CARD_IDS  # 循環import回避のため遅延import

    actions: list[Action] = []
    positions: list[tuple[Zone, int | None, PokemonInPlay]] = []
    if player.active is not None:
        positions.append((Zone.ACTIVE, None, player.active))
    for bi, mon in enumerate(player.bench):
        positions.append((Zone.BENCH, bi, mon))

    if state.global_ability_lock_owner >= 0 and state.player(state.global_ability_lock_owner).turns_taken <= state.global_ability_lock_until_turn:
        return []  # サポート「Hex Maniac」: 相手の次の番が終わるまで両者の特性が使えない
    player_index = 0 if player is state.players[0] else 1
    if (
        state.opponent_ability_lock_target == player_index
        and player.turns_taken <= state.opponent_ability_lock_until_turn
    ):
        return []  # ゲッコウガの「Shadow Stitching」: 相手の次の番が終わるまで、この効果の対象プレイヤーの特性が使えない

    for zone, bi, mon in positions:
        card = card_db.get(mon.card_id)
        if card is None:
            continue
        if ability_suppressed(state, card_db, player_index, mon):
            continue  # スタジアム・ダストダス・ミミッキュ等による特性の封印(engine.continuous.ability_suppressed)
        actions.extend(_tool_granted_ability_actions(state, player, card_db, zone, bi, mon, card))
        if mon.used_ability_this_turn:
            # 特性/ポケパワーは「1回の自分の番に1回」が基本(このエンジンに登録している起動型の
            # 特性はすべてこの制限を持つ実在カードのみのため、一律で適用してよい)
            continue
        for ability in card.abilities:
            script = get_ability_script(mon.card_id, ability.name)
            if not script or all(isinstance(e, NotImplementedEffect) for e in script):
                continue
            _prohibited_condition = _USER_PROHIBITED_ABILITY_CONDITIONS.get((mon.card_id, ability.name))
            if _prohibited_condition is not None and _user_prohibitions_active() and _prohibited_condition(state, player, mon):
                continue  # ユーザー指定の禁止行動(data/prohibited_actions.md参照、AI学習より優先)
            if ability_blocked_by_damp(state, mon.card_id, ability.name):
                continue  # コダックの「Damp」: 自身のきぜつを要する特性を封じる
            if (
                mon.card_id in _UNLIMITED_PER_TURN_ABILITY_CARD_IDS
                and mon.unlimited_ability_uses_this_turn >= _UNLIMITED_ABILITY_USE_CAP
            ):
                continue  # 「自分の番に何度でも使える」特性(メガフシギバナexの「Solar Transfer」等)は
                # ルール上無制限だが、自分のポケモン間でエネルギーを行ったり来たりさせ続けるだけの
                # 退化ループで対局が終わらなくなるのを防ぐため、この番での使用回数に上限を設ける
            if mon.card_id in _STATUS_LOCKED_ABILITY_CARD_IDS and mon.status.is_any:
                continue
            if mon.card_id == "dp5-49" and zone != Zone.BENCH:  # Unown QのQUICKはベンチにいるときのみ
                continue
            if mon.card_id == "sm9-99" and zone != Zone.ACTIVE:  # ジラーチの「スターウィッシュ」はバトル場にいるときのみ
                continue
            if mon.card_id == "sm5-63" and zone != Zone.BENCH:  # ダウンウィングネクロズマGXの「Invasion」はベンチにいるときのみ
                continue
            if mon.card_id == "sm10-81" and (zone != Zone.BENCH or state.stadium_in_play is None):
                continue  # マーシャドーの「Resetting Hole」はベンチにいて、場にスタジアムがあるときのみ
            if mon.card_id == "bw7-49" and zone != Zone.BENCH:  # ケルディオEXの「Rush In」はベンチにいるときのみ
                continue
            if mon.card_id == "xy9-41" and zone != Zone.ACTIVE:  # ゲッコウガBREAKの「Giant Water Shuriken」はバトル場にいるときのみ
                continue
            if mon.card_id == "xy7-30" and zone != Zone.BENCH:  # アンノーンの「Farewell Letter」はベンチにいるときのみ
                continue
            if mon.card_id == "swsh9-48" and zone != Zone.ACTIVE:  # ライコウVの「Fleet-Footed」はバトル場にいるときのみ
                continue
            if mon.card_id == "sv7-118" and player.turns_taken != 1:  # スピンロトムの「ファンコール」は自分の最初の番のみ
                continue
            if mon.card_id == "sv3pt5-132" and (zone != Zone.ACTIVE or player.turns_taken != 1):  # メタモンの「へんしんスタート」はバトル場かつ自分の最初の番のみ
                continue
            if mon.card_id == "cel25-11" and zone != Zone.ACTIVE:  # ミュウの「Mysterious Tail」はバトル場にいるときのみ
                continue
            if mon.card_id == "swsh11-79" and zone != Zone.ACTIVE:  # ネマシュの「Flower Selecting」はバトル場にいるときのみ
                continue
            if mon.card_id == "me1-104" and zone != Zone.ACTIVE:  # メガガルーラexの「おつかいだっしゅ(Run Errand)」はバトル場にいるときのみ
                continue
            if mon.card_id == "sv6pt5-38" and not player.pokemon_ko_last_turn:  # フェザンディプルEXの「Flip the Script」は相手の直前の番に自分のポケモンがきぜつしていたときのみ
                continue
            if mon.card_id == "sv2-169" and player.turns_taken != 1:  # イキリンコexの「Squawk and Seize」は自分の最初の番のみ(1ゲーム中1回)
                continue
            if mon.card_id in ("xy9-41", "xy1-41") and not any(
                (c := card_db.get(cid)) is not None and c.basic_energy_type == "Water" for cid in player.hand
            ):  # 手札にみずエネルギーが無ければ発動できない
                continue
            if mon.card_id == "me2pt5-105" and not any(
                m.card_id == "me2pt5-106" for m in player.all_pokemon_in_play()
            ):  # ルナトーンの「Lunar Cycle」は自分の場にソルロックがいないと使えない
                continue
            if mon.card_id == "sv6-95" and not any(
                energy_matches_type(card_db, eid, "Darkness", mon.card_id, mon.attached_energy)
                for eid in mon.attached_energy
            ):
                continue  # ムンキドリの「Adrena-Brain」実カードテキスト: "if this Pokémon has any
                # Darkness Energy attached"。以前はこの前提条件が一切ゲートされておらず、悪エネルギー
                # が付いていなくても使えてしまっていた(2026-08-21発覚)。
            if _is_vstar_power_ability(ability) and player.used_vstar_power_this_game:
                continue
            if any(
                not e.ability_gate(state, player, mon, zone, card_db) for e in script if hasattr(e, "ability_gate")
            ):
                continue  # AbilityGate(effects/era_abilities.py): バトル場/ベンチ限定・手札/エネルギーの条件等
            if not _ability_is_feasible(script, mon, card_db, player):
                continue
            if any(
                isinstance(e, MoveDamageCountersFromSelfToOpponentActive) or _targets_chosen_opponent_pokemon(e)
                for e in script
            ):
                # サマヨール/ヨノワールの「Cursed Blast」等、「相手の場のポケモン1匹(バトル/ベンチ)を
                # 選ぶ」効果を持つ特性。_targets_chosen_opponent_pokemon自体はワザ用の判定関数だが、
                # 判定条件(エフェクトの型)自体はワザ/特性どちらでも同じなのでそのまま流用する。
                opponent = state.players[1] if player is state.players[0] else state.players[0]
                if opponent.active is not None:
                    actions.append(UseAbility(zone, bi, None))
                for obi in range(len(opponent.bench)):
                    actions.append(UseAbility(zone, bi, obi))
            elif any(isinstance(e, DiscardHandEnergyThenSwitchOpponentBench) for e in script):
                # キュウコンの「Nine Temptations」: 手札に指定タイプの基本エネルギーが必要枚数あり、
                # 相手にベンチがあるときだけ、入れ替える相手のベンチポケモンを選んで使える
                switch_effect = next(e for e in script if isinstance(e, DiscardHandEnergyThenSwitchOpponentBench))
                energy_in_hand = sum(
                    1 for cid in player.hand
                    if (c := card_db.get(cid)) is not None and c.is_energy and not c.is_special_energy
                    and c.basic_energy_type == switch_effect.energy_type
                )
                opponent = state.players[1] if player is state.players[0] else state.players[0]
                if energy_in_hand >= switch_effect.count:
                    for obi in range(len(opponent.bench)):
                        actions.append(UseAbility(zone, bi, obi))
            elif _ability_needs_target(script):
                include_self = _ability_target_includes_self(script)
                type_filter, subtype_filter, name_prefix_filter = _attach_target_filters(script)
                exclude_card_id = _attach_target_exclude_card_id(script)
                self_damage_amount = _attach_self_damage_amount(script)
                candidate_positions = [p for p in positions if include_self or p[2] is not mon]
                for other_zone, other_bi, cand_mon in candidate_positions:
                    if exclude_card_id is not None and cand_mon.card_id == exclude_card_id:
                        continue  # モモワロウexの「しはいのくさり」: "except any Pecharunt ex"
                    if type_filter is not None or subtype_filter is not None or name_prefix_filter is not None:
                        cand_card = card_db.get(cand_mon.card_id)
                        if cand_card is None:
                            continue
                        if type_filter is not None and type_filter not in cand_card.types:
                            continue
                        if subtype_filter is not None and subtype_filter not in cand_card.subtypes:
                            continue
                        if name_prefix_filter is not None and not cand_card.name.startswith(name_prefix_filter):
                            continue
                    if self_damage_amount:
                        # サーナイトexの「Psychic Embrace」等: "You can't use this Ability on a
                        # Pokémon that would be Knocked Out"。つけると同時にのるダメカンで気絶する
                        # 対象は選べない。
                        cand_max_hp = effective_max_hp(card_db, cand_mon.card_id, cand_mon.attached_tool, state.stadium_in_play, cand_mon.attached_energy)
                        if cand_max_hp and cand_mon.damage + self_damage_amount >= cand_max_hp:
                            continue
                    target_bench_index = other_bi if other_zone == Zone.BENCH else None
                    actions.append(UseAbility(zone, bi, target_bench_index))
            else:
                actions.append(UseAbility(zone, bi, None))
    return actions


def _discard_ability_actions(state: GameState, player: PlayerState, card_db: CardDatabase) -> list[Action]:
    """トラッシュにいる状態で発動する「〜してもよい」系の特性(ギラティナ(smp-SM151)の
    「Distortion Door」等)。「1回の自分の番に1回」制限を持つ(同一カードIDが複数トラッシュに
    あっても列挙は1件のみ)。DISCARD_ABILITY_TO_HAND_CARD_IDSに含まれるカード(タマタマの
    「Propagation」等、ベンチではなく手札に戻る)はベンチ枠の空き不要、それ以外はベンチに出す
    ためベンチ枠の空きが必要。"""
    hand_actions = _hand_ability_actions(state, player, card_db)
    if player.used_discard_ability_this_turn:
        return hand_actions
    if state.global_ability_lock_owner >= 0 and state.player(state.global_ability_lock_owner).turns_taken <= state.global_ability_lock_until_turn:
        return []  # サポート「Hex Maniac」
    player_index = 0 if player is state.players[0] else 1
    if (
        state.opponent_ability_lock_target == player_index
        and player.turns_taken <= state.opponent_ability_lock_until_turn
    ):
        # ゲッコウガの「Shadow Stitching」実カードテキスト: "each Pokémon your opponent has in play,
        # in his or her hand, and in his or her discard pile has no Abilities" — 場だけでなく手札・
        # トラッシュのポケモンの特性も対象。トラッシュ発動系の特性(ギラティナの「Distortion Door」等)
        # もここでブロックする。
        return []
    bench_has_space = len(player.bench) < effective_bench_limit(state, player, card_db)
    seen: set[str] = set()
    actions: list[Action] = []
    from effects.registry import discard_ability_dest, has_discard_ability

    for i, card_id in enumerate(player.discard):
        if card_id in seen or not has_discard_ability(card_id):
            continue
        if discard_ability_dest(card_id) in ("bench", "coin_bench") and not bench_has_space:
            continue
        seen.add(card_id)
        actions.append(UseDiscardAbility(i))
    return actions + hand_actions


def _hand_ability_actions(state: GameState, player: PlayerState, card_db: CardDatabase) -> list[Action]:
    """手札にいるときに使える特性(タブンネの「Busybody」)。特性ロック(Hex Maniac/Shadow Stitching)の間は使えない。"""
    from effects.era_special import hand_ability_usable, has_hand_ability

    if not any(has_hand_ability(cid) for cid in player.hand):
        return []
    if state.global_ability_lock_owner >= 0 and state.player(state.global_ability_lock_owner).turns_taken <= state.global_ability_lock_until_turn:
        return []
    player_index = 0 if player is state.players[0] else 1
    if state.opponent_ability_lock_target == player_index and player.turns_taken <= state.opponent_ability_lock_until_turn:
        return []
    seen: set[str] = set()
    actions: list[Action] = []
    for i, card_id in enumerate(player.hand):
        if card_id in seen or not has_hand_ability(card_id) or not hand_ability_usable(state, player, card_db, card_id):
            continue
        seen.add(card_id)
        actions.append(UseDiscardAbility(i, True))
    return actions


def _self_only_attach_effect(e) -> bool:
    """対象選択が必要な「自分のポケモンにつける」系のうち、self_only=Falseで対象を選べるものか
    (AttachEnergyFromDiscardToOwnPokemon/SearchDeckAndAttachEnergy/LookTopNAttachEnergyRestToHand/
    SearchDeckAnyEnergyAttachToSelf/DiscardTopNAttachEnergyFoundが対象)。
    AttachEnergyFromDiscardToOwnPokemonWithChoice/AttachEnergyFromHandToChosenOwnPokemonは
    self_onlyフィールド自体を持たず(=常に対象を選べる設計)、無条件でTrue扱いにする。"""
    return (
        isinstance(
            e,
            (
                AttachEnergyFromDiscardToOwnPokemon,
                SearchDeckAndAttachEnergy,
                LookTopNAttachEnergyRestToHand,
                SearchDeckAnyEnergyAttachToSelf,
                DiscardTopNAttachEnergyFound,
                SearchDeckForBasicEnergyAttachToTarget,
            ),
        )
        and not e.self_only
    ) or isinstance(e, (AttachEnergyFromHandToChosenOwnPokemon, AttachEnergyFromDiscardToOwnPokemonWithChoice))


def _attach_self_damage_amount(script: tuple) -> int:
    """「Psychic Embrace」(サーナイトex)等、対象につけると同時にダメカンをのせる特性の場合、
    そのダメージ量を返す(該当なしは0)。実カードは"You can't use this Ability on a Pokémon that
    would be Knocked Out"のように、これで気絶してしまう対象は選べない制約を持つ。"""
    for e in script:
        if isinstance(e, AttachEnergyFromDiscardToOwnPokemon) and e.self_damage:
            return e.self_damage
    return 0


def _attach_target_filters(script: tuple) -> tuple[str | None, str | None, str | None]:
    """対象選択の絞り込み条件を(タイプ, サブタイプ, 名前の接頭辞)で返す(該当が無ければNone)。
    target_type: ポケモンのタイプ(「Psychic Embrace」はPsychicタイプ限定等)。
    target_subtype: ポケモンのサブタイプ(「Energy Mix」はFusion Strikeサブタイプ限定、
    「Trinity Charge」はVサブタイプ限定等)。target_name_prefix: カード名の接頭辞
    (Nのポイントアップの"N's Pokémon"限定等)。"""
    for e in script:
        if isinstance(e, (AttachEnergyFromDiscardToOwnPokemon, AttachEnergyFromDiscardToOwnPokemonWithChoice)) and (
            e.target_type is not None or e.target_subtype is not None or e.target_name_prefix is not None
        ):
            return e.target_type, e.target_subtype, e.target_name_prefix
        if isinstance(e, SearchDeckAnyEnergyAttachToSelf) and (e.target_type is not None or e.target_subtype is not None):
            return e.target_type, e.target_subtype, None
        if isinstance(e, SearchDeckAndAttachEnergy) and e.target_type is not None:
            return e.target_type, None, None
        if isinstance(e, AttachEnergyFromHandToChosenOwnPokemon) and e.target_type is not None:
            return e.target_type, None, None
        if isinstance(e, HealTarget) and e.target_type is not None:
            return e.target_type, None, None
        if isinstance(e, SwitchActiveWithBenchThenPoisonSelf) and e.required_type is not None:
            return e.required_type, None, None
    return None, None, None


def _attach_target_exclude_card_id(script: tuple) -> str | None:
    """対象選択の候補から除外する特定のカードID(例: モモワロウexの特性「しはいのくさり」実カード
    テキスト "except any Pecharunt ex" ―― 発動元と同じ名前の他個体も対象から除く)。"""
    for e in script:
        if isinstance(e, SwitchActiveWithBenchThenPoisonSelf) and e.exclude_card_id is not None:
            return e.exclude_card_id
    return None


def _ability_needs_target(script: tuple) -> bool:
    from effects.primitives import AttachEnergyFromHandToTarget, AttachSelfAsRetreatReducingTool, SwitchActiveWithBench, SwitchActiveWithBenchThenPoisonSelf

    return any(
        isinstance(
            e,
            (
                MoveEnergyBetweenOwnPokemon,
                AttachSelfAsRetreatReducingTool,
                SwitchActiveWithBenchThenPoisonSelf,
                SwitchActiveWithBench,
                AttachEnergyFromHandToTarget,
                AttachEnergyFromHandToChosenOwnPokemon,
            ),
        )
        or _self_only_attach_effect(e)
        for e in script
    )


def _ability_target_includes_self(script: tuple) -> bool:
    """このワザ/特性の対象選択が、発動元のポケモン自身も候補に含めてよいか
    (AttachEnergyFromDiscardToOwnPokemon/SearchDeckAndAttachEnergyベースの特性は自分自身も正当な
    対象になりうる。MoveEnergyBetweenOwnPokemon等の「自分から他へ移す」系は自分自身を対象にできないため除外する)。"""
    return any(_self_only_attach_effect(e) for e in script)


def _ability_is_feasible(script: tuple, mon: PokemonInPlay, card_db: CardDatabase, player: PlayerState) -> bool:
    """何もできない特性(移動元エネルギーが無い等)を合法手に出さないための簡易な事前チェック。"""
    for effect in script:
        if isinstance(effect, MoveEnergyBetweenOwnPokemon):
            has_matching_energy = any(
                effect.energy_type is None or (card_db.get(e) and card_db.get(e).basic_energy_type == effect.energy_type)
                for e in mon.attached_energy
            )
            if not has_matching_energy:
                return False
        if isinstance(effect, MoveDamageCountersFromSelfToOpponentActive):
            # ムンキドリの「Adrena-Brain」: 自分に悪エネルギーがついていないと使えない。
            # プリズムエネルギー/レガシーエネルギー等、「たねポケモンについていれば全タイプ扱い」の
            # 特殊エネルギーも悪エネルギーとして数える必要があるため、単純なbasic_energy_type比較
            # ではなくenergy_matches_type(イイネイヌの「アドレナパワー」等と同じ判定方法)を使う
            # (以前はbasic_energy_typeがNoneになる特殊エネルギーを一律で除外しており、ムンキドリに
            # プリズムエネルギーだけがついている場合にAdrena-Brainが一切使えなくなっていた、
            # 2026-08-25ユーザー報告で発覚)。
            has_darkness = any(
                energy_matches_type(card_db, e, "Darkness", host_card_id=mon.card_id, all_attached_energy_ids=mon.attached_energy)
                for e in mon.attached_energy
            )
            if not has_darkness:
                return False
            # 自分の場のどのポケモンにもダメカンが無ければ、移動元が無く発動しても何も起きないため
            # 合法手として出さない(以前は発動できてしまい、実際には無意味な空振りになっていた)
            if not any(m.damage > 0 for m in player.all_pokemon_in_play()):
                return False
            # ミネズミの特性「かんしのめ」: 自分の場にいる間、ダメカンののせ替えができない
            # (相手の場のミネズミはここでは判定できないが、実行時はprimitives._damage_counter_relocation_blockedで
            # 必ずブロックされる。ここは合法手のフィルタとしての簡易チェック)
            if any(m.card_id == "m4-yungoos" for m in player.all_pokemon_in_play()):
                return False
        if isinstance(effect, (AttachEnergyFromHandToSelf, AttachEnergyFromHandToChosenOwnPokemon)):
            # オーガポン(みどりのめん)exの「みどりのまい」/カミツオロチexの「Ripening Charge」等:
            # 手札に対象タイプの基本エネルギーが無ければ使えない
            has_matching_energy_in_hand = any(
                (c := card_db.get(cid)) is not None and c.basic_energy_type == effect.energy_type
                for cid in player.hand
            )
            if not has_matching_energy_in_hand:
                return False
        if isinstance(effect, DiscardOwnHandBasicEnergyThenDraw):
            # ルナトーンの「Lunar Cycle」: 手札に対象タイプの基本エネルギーが無ければ使えない
            has_matching_energy_in_hand = any(
                (c := card_db.get(cid)) is not None and c.basic_energy_type == effect.energy_type
                for cid in player.hand
            )
            if not has_matching_energy_in_hand:
                return False
        if isinstance(effect, (AttachEnergyFromDiscardToOwnPokemon, AttachEnergyFromDiscardToOwnPokemonWithChoice)):
            # ロケット団のワナイダーの「チャージアップ」/バシャーモexの「Seething Spirit」等:
            # トラッシュに対象の基本エネルギーが1枚も無ければ発動しても何も起きないため合法手として
            # 出さない(以前はこの前提条件が一切ゲートされておらず、トラッシュが空でも使えてしまって
            # いた、2026-08-22ユーザー報告で発覚)。
            has_matching_energy_in_discard = any(
                (c := card_db.get(cid)) is not None
                and (c.basic_energy_type == effect.energy_type if effect.energy_type else (not c.is_special_energy and c.is_energy))
                for cid in player.discard
            )
            if not has_matching_energy_in_discard:
                return False
        if isinstance(effect, DiscardCardsFromHand):
            # Nのゾロアークexの「とりひき」/Kirliaの「Refinement」/ゾロアークGXの「Trade」等:
            # 手札からトラッシュするカードが無ければ発動自体ができない(公式Q&Aで「自分の手札が
            # 1枚もないとき、特性を使うことはできません」と明言)。トレーナーズ版の同種チェック
            # (_blocked_by_insufficient_discard_cost)の特性版。
            matches = 0
            for cid in player.hand:
                c = card_db.get(cid)
                if effect.only_item and not (c is not None and c.is_item):
                    continue
                if effect.only_energy_type and not (c is not None and c.basic_energy_type == effect.only_energy_type):
                    continue
                if effect.only_energy_types_any and not (
                    c is not None and c.basic_energy_type in effect.only_energy_types_any
                ):
                    continue
                matches += 1
            if matches < effect.count:
                return False
            # 「手札を1枚捨てて2枚引く」系(とりひき/Refinement/Trade): 公式Q&Aで
            # 「自分の山札がないとき、特性を使うことはできません」と明言されている(手札を捨てる
            # コストは払えても、山札が0枚だとそもそも特性自体が使用不可)。
            if not player.deck and any(
                isinstance(e2, Draw) and e2.count > effect.count for e2 in script
            ):
                return False
        if isinstance(effect, DrawThenShuffleSelfIntoDeckIfDrew):
            # ノココッチの「Run Away Draw」: 公式Q&Aで「自分の山札が0枚のとき、特性を使うことは
            # できません」と明言されている(山札0枚でも発動だけはできて何も起きない、ではなく
            # 発動自体が不可)。2026-08-25の公式FAQ監査で発覚。
            if not player.deck:
                return False
        if isinstance(effect, DrawUpTo):
            # ミュウex「リスタート」/ヤレユータン「Instruct」等: 手札が既に目標枚数以上あり
            # 1枚も引けない(=何もできない)なら合法手として出さない。
            target = effect.count
            if effect.bonus_count_if_own_first_turn is not None and player.turns_taken == 1:
                target = effect.bonus_count_if_own_first_turn
            if len(player.hand) >= target:
                return False
    return True


def _retreat_actions(state: GameState, player: PlayerState, card_db: CardDatabase) -> list[Action]:
    if player.retreated_this_turn or player.active is None or not player.bench:
        return []
    if player.active.card_id in POKEMON_AS_ITEM:
        return []  # みがわりロボ(xy4-102)/Antique〜Fossil: このカードはにげられない
    if not player.active.status.can_retreat and player.active.attached_tool != ESCAPE_BOARD_TOOL_ID:
        return []  # エスケープボード(sm5-122): ねむり/まひ中でもにげられる
    if (
        player.active.retreat_disabled_until_turn > 0
        and player.turns_taken <= player.active.retreat_disabled_until_turn
    ):
        return []  # Shadow Bind/ロックアップ等: 相手の次の番、このポケモンはにげられない
    if (
        player.poisoned_cant_retreat_until_turn > 0
        and player.turns_taken <= player.poisoned_cant_retreat_until_turn
        and player.active.status.poisoned
    ):
        return []  # ロクシーの気迫(Roxie's Performance): 相手の次の番、どくのポケモンはにげられない
    from effects.passives import retreat_blocked

    if retreat_blocked(state, card_db, 0 if player is state.players[0] else 1, player.active):
        return []  # Poison Barrier/Block等: 相手のパッシブ特性でにげられない
    active_card = card_db.get(player.active.card_id)
    if active_card is None:
        return []
    cost_count = effective_retreat_cost_count(
        card_db,
        player.active,
        active_card.retreat_cost_count,
        state.stadium_in_play,
        player.turns_taken,
        owner_has_skyliner=has_skyliner_in_play(player),
        owner_has_dark_cloak=has_dark_cloak_in_play(player),
        owner_has_thunderclap_zone=has_thunderclap_zone_in_play(player),
    )
    if not can_pay_retreat_cost(
        card_db, player.active.attached_energy, cost_count, player.active.card_id, double_grass=wild_growth_active(player)
    ):
        return []
    return [Retreat(bi) for bi in range(len(player.bench))]


def _gx_override_applies(player, card) -> bool:
    """「この番、〇〇は、GXワザを使ったあとでもGXワザを使える」(ボニー/ミスティ&ロレイ)が、このポケモンに効いているか。
    ただし、相手の効果でGXワザを使えなくされている(gx_attacks_locked)ときは効かない。"""
    if player.gx_attacks_locked:
        return False
    for entry in player.gx_override_this_turn:
        kind, _, value = entry.partition(":")
        if (kind == "name" and card.name == value) or (kind == "type" and value in card.types):
            return True
    return False


def _is_gx_attack(attack) -> bool:
    return "GX attack in a game" in (attack.text or "")


def _is_vstar_power_attack(attack) -> bool:
    return "VSTAR Power in a game" in (attack.text or "")


_LOST_ZONE_10_GATE_ATTACKS = {
    ("swsh11-131", "Star Requiem"),  # ギラティナVSTAR
    ("swsh11-70", "Lost Mine"),  # ヤミラミ(Sableye)
}  # ロストゾーンに10枚以上あるときのみ使用可能なワザ

# 「後攻なら、自分の最初の番にはこのワザを使えない」ワザ(テラパゴスexの「Unified Beatdown」)
_SECOND_PLAYER_FIRST_TURN_BLOCKED_ATTACKS = {("me2pt5-179", "Unified Beatdown")}
# 「自分のポケモンが前の自分の番にこのワザを使っていたら、このワザは使えない」ワザ名(ミュウツーの「Barrier」)
_NO_REPEAT_FROM_LAST_TURN_ATTACK_NAMES = {"Barrier"}

_MORE_PRIZES_REMAINING_GATE_ATTACKS = {
    ("sm5-63", "Moon's Eclipse-GX"),  # ダウンウィングネクロズマGX: 自分の残りサイドが相手より多いときのみ使用可能
}

_MIN_OWN_POKEMON_IN_PLAY_TO_ATTACK: dict[str, int] = {
    "sm11-78": 5,  # ラティオスGX: 特性「Power Bind」("If you have 4 or fewer Pokemon in play, this Pokemon can't attack")
}

_MIN_NAMED_PREFIX_POKEMON_IN_PLAY_TO_ATTACK: dict[str, tuple[int, str]] = {
    "me2pt5-79": (4, "Team Rocket's"),  # ロケット団のミュウツーex: 特性「Power Saver」("This Pokemon can't attack unless you have 4 or more Team Rocket's Pokemon in play")
    **{
        cid: (4, "Team Rocket's")
        for cid in ("me2pt5-281", "sv10-213", "sv10-231", "sv10-240", "sv10-81")
    },  # ロケット団のミュウツーex 別絵柄
}


def _flatten_script(script) -> tuple:
    """コイン分岐・条件つき効果の中に入っている効果も含めて、スクリプトの全ての効果を平らに並べる(対象選択が必要な効果が
    FlipCoinThen等の中に入っていても、Attackの対象つき選択肢を出せるようにするため)。"""
    out: list = []
    for effect in script:
        out.append(effect)
        for attr in ("heads", "tails", "then"):
            nested = getattr(effect, attr, None)
            if isinstance(nested, tuple):
                out.extend(_flatten_script(nested))
    return tuple(out)


def _targets_chosen_opponent_pokemon(effect) -> bool:
    """このワザの効果が「相手の場のポケモン1匹(バトル/ベンチ)を選ぶ」対象選択を必要とするか。"""
    if getattr(effect, "attack_target", None) == "opp_any":
        return True
    if isinstance(
        effect,
        (
            DealDamageToChosenOpponentPokemon,
            MoveDamageCountersFromAllOwnPokemonToChosenOpponent,
            DamagePerSelfDamageCountersToChosenOpponent,
            DamageCounterOnChosenOpponentPokemon,
            DamagePerSelfEnergyToChosenOpponent,
            DamageCounterOnChosenOpponentThenSelfKnockout,
            DamageToChosenOpponentPokemonScaledByOwnPokemonNamedCoinFlips,
        ),
    ):
        return True
    if isinstance(effect, DamagePerFusionStrikeEnergyAcrossBoard) and effect.choose_target:
        return True
    return False


def _lost_provisions_ignores_energy_cost(
    state: GameState, card_db: CardDatabase, player: PlayerState, mon: PokemonInPlay, card
) -> bool:
    """ウッウ(swsh11-50)の特性「Lost Provisions」実カードテキスト: "If you have 4 or more cards in the Lost
    Zone, ignore all Energy in this Pokémon's attack costs." """
    if not any(a.name == "Lost Provisions" for a in card.abilities) or len(player.lost_zone) < 4:
        return False
    player_index = 0 if player is state.players[0] else 1
    return not ability_suppressed(state, card_db, player_index, mon)


def _attacks_despite_status(state: GameState, mon) -> bool:
    """ゼンマイアーム: ついているポケモンは、ねむりやマヒでもワザを使える。"""
    if mon is None or not mon.attached_tool or tools_disabled(state.stadium_in_play):
        return False
    from effects.era_tools_j import has_reaction

    return has_reaction(mon.attached_tool, "react_attack_despite_status")


def _attack_actions(
    state: GameState, player: PlayerState, card_db: CardDatabase, first_turn_exception_only: bool = False
) -> list[Action]:
    if player.active is None:
        return []
    # ねむり中でも使えるワザ(Dream Waltz)があるため、ねむりだけは個々のワザごとに下で判定する(マヒは常に不可)
    attack_despite_status = _attacks_despite_status(state, player.active)
    if not player.active.status.can_attack and player.active.status.exclusive.name != "ASLEEP" and not attack_despite_status:
        return []
    if (
        player.active.attack_disabled_until_turn > 0
        and player.turns_taken <= player.active.attack_disabled_until_turn
    ):
        return []  # 冷凍ストリーム等: 相手の次の番、このポケモンは攻撃できない
    active_card = card_db.get(player.active.card_id)
    if active_card is None:
        return []
    min_required = _MIN_OWN_POKEMON_IN_PLAY_TO_ATTACK.get(player.active.card_id)
    if min_required is not None and len(player.all_pokemon_in_play()) < min_required:
        return []  # ラティオスGXの特性「Power Bind」等
    named_prefix_gate = _MIN_NAMED_PREFIX_POKEMON_IN_PLAY_TO_ATTACK.get(player.active.card_id)
    if named_prefix_gate is not None:
        min_named, prefix = named_prefix_gate
        if prefix == TEAM_ROCKETS_NAME_PREFIX:
            # ロケット団のワナイダー(sv10a-9、card.nameが日本語未翻訳)を漏れなく数えるため、
            # 共通ヘルパーを使う(2026-08-22、ユーザー報告により発覚)。
            named_count = sum(1 for m in player.all_pokemon_in_play() if is_team_rockets_pokemon(card_db.get(m.card_id)))
        else:
            named_count = sum(
                1
                for m in player.all_pokemon_in_play()
                if (c := card_db.get(m.card_id)) is not None and c.name.startswith(prefix)
            )
        if named_count < min_named:
            return []  # ロケット団のミュウツーexの特性「Power Saver」等
    mon = player.active
    opponent = state.players[1] if player is state.players[0] else state.players[0]
    from effects.passives import attack_restricted, attacks_on_first_turn

    if attack_restricted(state, card_db, 0 if player is state.players[0] else 1, mon):
        return []  # Airhead/Unobservant/Power Bind: パッシブ特性でワザを使えない
    from effects.era_sm_hooks import attack_blocked_by_stadium

    if attack_blocked_by_stadium(state, card_db, mon):
        return []  # ブリザードタウン: 残りHPが40以下のポケモンはワザを使えない
    actions = []
    attacks = active_card.attacks
    if not attacks and "BREAK" in active_card.subtypes and active_card.evolves_from:
        # BREAK進化ルール: 自身のワザを持たず、進化元のワザをそのまま引き継ぐ(ゲッコウガBREAK等)。
        # 効果本体はregistry.pyでBREAKカード自身のIDにも同じ内容を登録済み。
        pre_evolution = card_db.find_by_name(active_card.evolves_from)
        pre_evolution_exact = next((c for c in pre_evolution if c.name == active_card.evolves_from), None)
        if pre_evolution_exact is not None:
            attacks = pre_evolution_exact.attacks
    for i, attack in enumerate(attacks):
        # locked_attack_name is None は「次の自分の番、ワザが一切使えない」(全ワザロック)を表す
        # (LockOwnAttackNextTurn(lock_all_attacks=True)参照)。指定ありなら、そのワザ名のみロック。
        if (
            mon.locked_attack_until_turn > 0
            and player.turns_taken <= mon.locked_attack_until_turn
            and (mon.locked_attack_name is None or mon.locked_attack_name == attack.name)
        ):
            continue
        if (
            mon.forced_attack_until_turn > 0
            and player.turns_taken <= mon.forced_attack_until_turn
            and mon.forced_attack_name is not None
            and mon.forced_attack_name != attack.name
        ):
            continue  # Encore: 次の自分の番は、選ばれたワザしか使えない
        script = get_attack_script(mon.card_id, attack.name)
        if not script:
            # 未登録のワザ(実装対象外にしたものを意図的に未登録にしている)は合法手として出さない。
            # 特性側の「未登録なら使わせない」フィルタと同じ考え方。
            continue
        script = _flatten_script(script)
        if not player.active.status.can_attack and not attack_despite_status and not any(getattr(e, "attack_while_asleep", False) for e in script):
            continue  # ねむり中は、「ねむりでも使える」ワザ以外は使えない
        if first_turn_exception_only and not (
            any(getattr(e, "usable_on_first_turn_if_first_player", False) for e in script)
            or attacks_on_first_turn(state, card_db, 0 if player is state.players[0] else 1, mon)
        ):
            continue
        if any(getattr(e, "usable_only_first_turn_if_second", False) for e in script) and not (
            player.turns_taken == 1 and (0 if player is state.players[0] else 1) != state.first_player
        ):
            continue  # Stall: 後攻のとき、最初の自分の番にしか使えない
        if not all(
            getattr(e, "usable_check", None) is None or e.usable_check(state, player, mon, card_db, attack) for e in script
        ):
            continue  # 「このワザは、〜のときだけ使える」(効果クラスのusable_checkが偽を返したら出さない)
        if _is_gx_attack(attack) and (player.used_gx_attack_this_game or player.gx_attacks_locked) and not _gx_override_applies(player, active_card):
            continue  # player.gx_attacks_lockedはラティオスGXの「Clear Vision-GX」による相手GXワザ封じ
        if _is_vstar_power_attack(attack) and player.used_vstar_power_this_game:
            continue
        if (mon.card_id, attack.name) in _LOST_ZONE_10_GATE_ATTACKS and len(player.lost_zone) < 10:
            continue
        if (
            (mon.card_id, attack.name) in _SECOND_PLAYER_FIRST_TURN_BLOCKED_ATTACKS
            and player.turns_taken == 1
            and (0 if player is state.players[0] else 1) != state.first_player
        ):
            continue  # 「If you go second, you can't use this attack during your first turn」
        if (
            attack.name in _NO_REPEAT_FROM_LAST_TURN_ATTACK_NAMES
            and player.last_turn_attack_used is not None
            and player.last_turn_attack_used[1] == attack.name
        ):
            continue  # 「If 1 of your Pokémon used Barrier during your last turn, this attack can't be used」
        if (mon.card_id, attack.name) in _MORE_PRIZES_REMAINING_GATE_ATTACKS and not (
            len(player.prizes) > len(opponent.prizes)
        ):
            continue
        ahead_on_prizes = len(player.prizes) > len(opponent.prizes)
        cost = effective_attack_cost(
            card_db,
            mon,
            attack.cost,
            state.stadium_in_play,
            ahead_on_prizes,
            opponent_prizes_taken=6 - len(opponent.prizes),
            attack_name=attack.name,
            opponent_discard=opponent.discard,
        )
        from effects.era_trainers import era_attack_cost_ignored

        if _lost_provisions_ignores_energy_cost(state, card_db, player, mon, active_card) or era_attack_cost_ignored(state, card_db, mon):
            cost = ()  # ビクトリーピース: ビクティニEXのワザは、エネルギーに関わらず使える
        if not can_pay_cost(card_db, mon.attached_energy, cost, mon.card_id, double_grass=wild_growth_active(player), ahead_on_prizes=ahead_on_prizes):
            continue
        if any(_targets_chosen_opponent_pokemon(e) for e in script):
            damaged_only = any(getattr(e, "damaged_only", False) for e in script if _targets_chosen_opponent_pokemon(e))
            special_energy_only = any(getattr(e, "special_energy_only", False) for e in script if _targets_chosen_opponent_pokemon(e))

            target_checks = [e.target_ok for e in script if _targets_chosen_opponent_pokemon(e) and hasattr(e, "target_ok")]

            def _target_ok(target_mon, slot: int) -> bool:
                if damaged_only and target_mon.damage <= 0:
                    return False
                if special_energy_only and not any((c := card_db.get(en)) is not None and c.is_special_energy for en in target_mon.attached_energy):
                    return False  # Bone Sniper: 特殊エネルギーがついている相手のポケモンだけが対象
                return all(check(card_db, target_mon, slot) for check in target_checks)  # 対象を絞るワザ(ポケモンGX/EXだけ・ベンチだけ等)

            if opponent.active is not None and _target_ok(opponent.active, 0):
                actions.append(Attack(i, None))
            for bi in range(len(opponent.bench)):
                if _target_ok(opponent.bench[bi], bi + 1):
                    actions.append(Attack(i, bi))
            if (damaged_only or target_checks) and not any(True for a in actions if isinstance(a, Attack) and a.attack_index == i):
                actions.append(Attack(i))  # 対象になる相手のポケモンがいなければ、何もしないワザとして使える
        elif any(isinstance(e, ChooseOwnAttachedEnergyThenShuffleForBonusBenchDamage) for e in script):
            # カブのおめん(Wellspring Mask Ogerpon ex)の「Torrential Pump」等: 実カードは
            # 「してもよい」(エネルギーを山札に戻せば追加ダメージ)。エネルギーが足りていれば
            # 「しない」(target_bench_index=None、通常ダメージのみ)も選べるようにする
            # (足りなければ元々ボーナスが発動しないので通常ダメージの1択のまま)。
            shuffle_effect = next(e for e in script if isinstance(e, ChooseOwnAttachedEnergyThenShuffleForBonusBenchDamage))
            has_enough_energy = len(mon.attached_energy) >= shuffle_effect.energy_count
            if opponent.bench and has_enough_energy:
                actions.append(Attack(i, None))
                for bi in range(len(opponent.bench)):
                    actions.append(Attack(i, bi))
            else:
                actions.append(Attack(i))
        elif any(isinstance(e, DamageWithBonusBenchIfExtraEnergy) for e in script):
            # デオキシス(Deoxys)の「Psyspear」等: 追加エネルギーが足りていればベンチへの追加ダメージ先を
            # 選べる(足りなければボーナスが発動しないのでtarget_bench_index=Noneの1択のまま)。
            extra_effect = next(e for e in script if isinstance(e, DamageWithBonusBenchIfExtraEnergy))
            extra = len(mon.attached_energy) - extra_effect.cost_count
            if opponent.bench and extra >= extra_effect.extra_needed:
                for bi in range(len(opponent.bench)):
                    actions.append(Attack(i, bi))
            else:
                actions.append(Attack(i))
        elif has_optional_variant(script):
            # メタグロスの「Metallic Hammer」/メガライボルトexの「Riotous Blasting」等: 選ばない(None)/選ぶ(0)の2択。
            # Metallic Hammerは公式FAQ上、対象のエネルギーが1枚もついていなくても「捨てる」を選べる。コストを払えない
            # 効果(variant_payableがFalseを返すもの)は「選ぶ」版を出さない
            actions.append(Attack(i))
            if all(
                getattr(e, "variant_payable", None) is None or e.variant_payable(state, player, mon, card_db) for e in script
            ):
                actions.append(Attack(i, 0))
        elif any(isinstance(e, (DamageBonusIfStadiumDiscarded, DiscardStadiumInPlayIfChosen)) for e in script):
            # スタジアムをトラッシュしてもよいワザ(あばれるつきの「Calamity Storm」/ピジョットexの「Blustery Wind」):
            # 場にスタジアムがあるときだけ「トラッシュする」(target_bench_index=0)を選べる
            actions.append(Attack(i))
            if state.stadium_in_play is not None:
                actions.append(Attack(i, 0))
        elif any(
            isinstance(
                e,
                (
                    DealBonusDamageToChosenOpponentBench,
                    DamageWithSupporterBonusToChosenOpponentBench,
                    ForceOpponentSwitchChosenBench,
                    DamageCounterOnChosenOpponentBenchIfActiveHasSpecialCondition,
                ),
            )
            or getattr(e, "attack_target", None) == "opp_bench"
            for e in script
        ):
            # インテレオンの「アクアバレット」等: バトルポケモンへの通常ダメージに加えて、
            # 相手にベンチがあれば追加ダメージ先を必ず選ぶ(ベンチが無ければ追加ダメージ無しで発動)。
            # クレフェアリー(Clefairy)の「Follow Me」(ForceOpponentSwitchChosenBench)も同様、
            # バトル場自身を選ぶ余地は無いのでベンチのみを候補にする(2026-08-26追加)。
            # ゼラオラ(Zeraora)の「Thunder Raid」(ex_only=True)のように対象がexポケモンのみに
            # 絞られる場合は、その条件を満たすベンチのみを候補にする。
            ex_only_effect = next(
                (e for e in script if isinstance(e, DealBonusDamageToChosenOpponentBench) and e.ex_only), None
            )
            damaged_only_effect = next(
                (e for e in script if isinstance(e, DealBonusDamageToChosenOpponentBench) and e.damaged_only), None
            )
            subtype_effect = next((e for e in script if isinstance(e, DealBonusDamageToChosenOpponentBench) and getattr(e, "subtypes", ())), None)
            if subtype_effect is not None:
                bench_candidates = [
                    bi for bi, bm in enumerate(opponent.bench)
                    if (bc := card_db.get(bm.card_id)) is not None and any(s in bc.subtypes for s in subtype_effect.subtypes)
                ]
            elif ex_only_effect is not None:
                bench_candidates = [
                    bi for bi, bm in enumerate(opponent.bench)
                    if (bc := card_db.get(bm.card_id)) is not None and "ex" in bc.subtypes
                ]
            elif damaged_only_effect is not None:
                bench_candidates = [bi for bi, bm in enumerate(opponent.bench) if bm.damage > 0]
            else:
                bench_candidates = list(range(len(opponent.bench)))
            if bench_candidates:
                for bi in bench_candidates:
                    actions.append(Attack(i, bi))
            else:
                actions.append(Attack(i))
        elif any(
            isinstance(e, (MoveEnergyBetweenOwnPokemon, DamageToChosenOwnPokemonIgnoringWeaknessResistance, DamageCounterOnChosenOwnPokemon, HealTarget, ReturnOwnBenchedPokemonAndAttachedToHand))
            or _self_only_attach_effect(e)
            or getattr(e, "attack_target", None) in ("own_any", "own_bench")
            for e in script
        ):
            # アイアンバルジェットexの「ボルトサイクロン」、イベルタルの「Oblivion Wing」、
            # ソルガレオGXの「Sol Burst-GX」、レントラーGL LV.Xの「Flash Impact」等: 自分のベンチ
            # (bench_only=Falseなら自分自身/バトル場も含む)への添付・移動・ダメージ先を選ぶ。
            # self_only=True(Cell Connectorの「Cell Connector」等)はこのブランチに入らず、
            # 下のelse節でtarget_bench_index=None(=自分自身)固定になる。
            bench_only = any(
                isinstance(e, (MoveEnergyBetweenOwnPokemon, ReturnOwnBenchedPokemonAndAttachedToHand))
                or (isinstance(e, AttachEnergyFromDiscardToOwnPokemon) and e.bench_only)
                or (isinstance(e, SearchDeckAndAttachEnergy) and e.bench_only)
                or (isinstance(e, SearchDeckForBasicEnergyAttachToTarget) and e.bench_only)
                or (isinstance(e, HealTarget) and e.bench_only)
                or (isinstance(e, AttachEnergyFromHandToChosenOwnPokemon) and e.bench_only)
                or getattr(e, "attack_target", None) == "own_bench"
                for e in script
            )
            type_filter, subtype_filter, name_prefix_filter = _attach_target_filters(script)

            def _matches_target_filter(cand_mon: PokemonInPlay) -> bool:
                if type_filter is None and subtype_filter is None and name_prefix_filter is None:
                    return True
                cand_card = card_db.get(cand_mon.card_id)
                if cand_card is None:
                    return False
                if type_filter is not None and type_filter not in cand_card.types:
                    return False
                if subtype_filter is not None and subtype_filter not in cand_card.subtypes:
                    return False
                if name_prefix_filter is not None and not cand_card.name.startswith(name_prefix_filter):
                    return False
                return True

            if not bench_only and player.active is not None and _matches_target_filter(player.active):
                actions.append(Attack(i, None))
            for bi, bench_mon in enumerate(player.bench):
                if _matches_target_filter(bench_mon):
                    actions.append(Attack(i, bi))
            if bench_only and not player.bench:
                actions.append(Attack(i))
        elif any(isinstance(e, SwitchActiveWithBench) for e in script):
            # グソクムシャGXの「Crossing Cut-GX」等: ワザの後に自分のベンチと入れ替える先を選ぶ。
            if player.bench:
                for bi in range(len(player.bench)):
                    actions.append(Attack(i, bi))
            else:
                actions.append(Attack(i))
        elif any(getattr(e, "status_choice_options", None) for e in script):
            # Miracle Powder/Conversion Powder/Type Switch: 選ぶ特殊状態/タイプを、target_bench_indexのkで渡す
            options = next(e.status_choice_options for e in script if getattr(e, "status_choice_options", None))
            for k in range(len(options)):
                actions.append(Attack(i, k))
        elif any(isinstance(e, LockChosenOpponentAttackNextTurn) or getattr(e, "chooses_opponent_attack", False) for e in script):
            # ラルトスの「Memory Skip」等: target_bench_indexを相手のバトルポケモンのワザ番号として流用する。
            if opponent.active is not None:
                opponent_card = card_db.get(opponent.active.card_id)
                if opponent_card is not None and opponent_card.attacks:
                    for ai in range(len(opponent_card.attacks)):
                        actions.append(Attack(i, ai))
                else:
                    actions.append(Attack(i))
            else:
                actions.append(Attack(i))
        else:
            actions.append(Attack(i))
    return actions


ATTACK_COPY_SOURCES: dict[str, dict] = {
    # 「〜のワザをこのワザとして使う」系。own_attack_nameは自分自身の(コスト計算に使う)ワザ名、
    # sourceはコピー元の探索先。
    "sv3pt5-151": {"own_attack_name": "Genome Hacking", "source": "opponent_active"},  # ミュウex
    "swsh12-136": {"own_attack_name": "Apex Dragon", "source": "own_discard", "filter_type": "Dragon"},  # レジドラゴVSTAR
    "swsh8-114": {  # ミュウVMAX
        "own_attack_name": "Cross Fusion Strike",
        "source": "own_bench",
        "filter_subtype": "Fusion Strike",
    },
    "sm35-53": {"own_attack_name": "Trickster-GX", "source": "opponent_active"},  # ゾロアークGX
    "sv9-98": {"own_attack_name": "Night Joker", "source": "own_bench", "filter_name_prefix": "N's "},  # Nのゾロアークex
    "me2pt5-137": {"own_attack_name": "Night Joker", "source": "own_bench", "filter_name_prefix": "N's "},  # Nのゾロアークex(Mega系再録、sv9-98と同一テキスト)
}


def _attack_copy_source_candidates(
    config: dict, player: PlayerState, opponent: PlayerState, card_db: CardDatabase
) -> list[tuple[str, str]]:
    """(zone, card_id) のリストを返す(同じカードIDは1回だけ)。"""
    seen: set[str] = set()
    result: list[tuple[str, str]] = []
    if config["source"] == "opponent_active":
        if opponent.active is not None:
            result.append(("opponent_active", opponent.active.card_id))
        return result
    if config["source"] == "own_discard":
        card_ids = player.discard
        zone = "discard"
        matches = lambda c: config["filter_type"] in c.types  # noqa: E731
    else:  # "own_bench"
        card_ids = [m.card_id for m in player.bench]
        zone = "bench"
        if "filter_name_prefix" in config:
            prefix = config["filter_name_prefix"]
            matches = lambda c: c.name.startswith(prefix)  # noqa: E731
        else:
            matches = lambda c: config["filter_subtype"] in c.subtypes  # noqa: E731
    for cid in card_ids:
        if cid in seen:
            continue
        card = card_db.get(cid)
        if card is None or not card.is_pokemon or not matches(card):
            continue
        seen.add(cid)
        result.append((zone, cid))
    return result


def _attack_copy_actions(state: GameState, player: PlayerState, card_db: CardDatabase) -> list[Action]:
    """「〜のワザをこのワザとして使う」系(ミュウexの「Genome Hacking」、レジドラゴVSTARの
    「Apex Dragon」、ミュウVMAXの「Cross Fusion Strike」)。v1簡略版: GXワザ/VSTARパワー自体は
    コピー対象外(1ゲーム1回制限との整合性のため、パーフェクションと同様の簡略化)。
    コストは自分自身の(コピー元ではなく)そのワザの印刷コストで判定する。"""
    if player.active is None or not player.active.status.can_attack:
        return []
    config = ATTACK_COPY_SOURCES.get(player.active.card_id)
    if config is None:
        return []
    own_card = card_db.get(player.active.card_id)
    own_attack = next((a for a in (own_card.attacks if own_card else ()) if a.name == config["own_attack_name"]), None)
    if own_attack is None:
        return []
    if _is_gx_attack(own_attack) and player.used_gx_attack_this_game:
        return []
    opponent = state.players[1] if player is state.players[0] else state.players[0]
    ahead_on_prizes = len(player.prizes) > len(opponent.prizes)
    cost = effective_attack_cost(card_db, player.active, own_attack.cost, state.stadium_in_play, ahead_on_prizes, opponent_prizes_taken=6 - len(opponent.prizes))
    if not can_pay_cost(card_db, player.active.attached_energy, cost, player.active.card_id, double_grass=wild_growth_active(player), ahead_on_prizes=ahead_on_prizes):
        return []
    own_script = get_attack_script(player.active.card_id, own_attack.name)
    actions: list[Action] = []
    for zone, source_card_id in _attack_copy_source_candidates(config, player, opponent, card_db):
        source_card = card_db.get(source_card_id)
        for attack in source_card.attacks:
            if _is_gx_attack(attack) or _is_vstar_power_attack(attack):
                continue
            script = get_attack_script(source_card_id, attack.name)
            if not script:
                continue
            if own_script and script == own_script:
                # ベンチの同名ポケモンの「ナイトジョーカー」等、自分自身と同じコピー効果は選べない
                # (選んでもまた同じ選択肢が出るだけで、無限再帰になる)。
                continue
            if any(isinstance(e, DealDamageToChosenOpponentPokemon) for e in script):
                if opponent.active is not None:
                    actions.append(UseBorrowedAttack(zone, source_card_id, attack.name, None))
                for bi in range(len(opponent.bench)):
                    actions.append(UseBorrowedAttack(zone, source_card_id, attack.name, bi))
            else:
                actions.append(UseBorrowedAttack(zone, source_card_id, attack.name))
    return actions


_PERFECTION_CARD_ID = "sm11-71"  # ミュウツー&ミュウGX: ベンチ/トラッシュのGX/EXポケモンのワザを借りて使える
_BORROWABLE_SUBTYPES = _GX_EX_SUBTYPES  # 実カードテキストは"Pokémon-GX or Pokémon-EX"限定(現行の小文字"ex"は対象外)


def _borrowable_attack_sources(player: PlayerState, card_db: CardDatabase) -> list[tuple[str, str]]:
    """(zone, card_id) のリストを返す。同じカードIDが複数あっても1回だけ列挙する。"""
    seen: set[tuple[str, str]] = set()
    result: list[tuple[str, str]] = []
    for zone, card_ids in (("bench", [m.card_id for m in player.bench]), ("discard", player.discard)):
        for cid in card_ids:
            card = card_db.get(cid)
            if card is None or not card.is_pokemon or not (_BORROWABLE_SUBTYPES & set(card.subtypes)):
                continue
            key = (zone, cid)
            if key in seen:
                continue
            seen.add(key)
            result.append(key)
    return result


def _perfection_attack_actions(state: GameState, player: PlayerState, card_db: CardDatabase) -> list[Action]:
    """ミュウツー&ミュウGXの特性「パーフェクション」: 自分のベンチ/トラッシュのGX/EXポケモンのワザを、
    自分自身についているエネルギーで支払って使う(v1簡略版: GXワザ/VSTARパワー自体は借りられない)。"""
    if player.active is None or player.active.card_id != _PERFECTION_CARD_ID:
        return []
    if not player.active.status.can_attack:
        return []
    mon = player.active
    opponent = state.players[1] if player is state.players[0] else state.players[0]
    actions: list[Action] = []
    for zone, source_card_id in _borrowable_attack_sources(player, card_db):
        source_card = card_db.get(source_card_id)
        for attack in source_card.attacks:
            if _is_gx_attack(attack) or _is_vstar_power_attack(attack):
                continue
            script = get_attack_script(source_card_id, attack.name)
            if not script:
                continue
            ahead_on_prizes = len(player.prizes) > len(opponent.prizes)
            cost = effective_attack_cost(card_db, mon, attack.cost, state.stadium_in_play, ahead_on_prizes, opponent_prizes_taken=6 - len(opponent.prizes))
            if not can_pay_cost(card_db, mon.attached_energy, cost, mon.card_id, double_grass=wild_growth_active(player), ahead_on_prizes=ahead_on_prizes):
                continue
            if any(isinstance(e, DealDamageToChosenOpponentPokemon) for e in script):
                if opponent.active is not None:
                    actions.append(UseBorrowedAttack(zone, source_card_id, attack.name, None))
                for bi in range(len(opponent.bench)):
                    actions.append(UseBorrowedAttack(zone, source_card_id, attack.name, bi))
            else:
                actions.append(UseBorrowedAttack(zone, source_card_id, attack.name))
    return actions


_MEW_EX_VERSATILE_ID = "xyp-XY126"  # ミュウEX: 特性「Versatile」場にいるポケモン(自分・相手問わず)のワザを使える


def _versatile_attack_sources(player: PlayerState, opponent: PlayerState, card_db: CardDatabase) -> list[tuple[str, str]]:
    """(zone, card_id) のリストを返す(自分のバトル場=ミュウEX自身は除く)。同じカードIDは1回だけ列挙する。"""
    seen: set[tuple[str, str]] = set()
    result: list[tuple[str, str]] = []
    sources: list[tuple[str, list[str]]] = [
        ("own_bench", [m.card_id for m in player.bench]),
        ("opponent_active", [opponent.active.card_id] if opponent.active is not None else []),
        ("opponent_bench", [m.card_id for m in opponent.bench]),
    ]
    for zone, card_ids in sources:
        for cid in card_ids:
            card = card_db.get(cid)
            if card is None or not card.is_pokemon:
                continue
            key = (zone, cid)
            if key in seen:
                continue
            seen.add(key)
            result.append(key)
    return result


def _versatile_attack_actions(state: GameState, player: PlayerState, card_db: CardDatabase) -> list[Action]:
    """ミュウEXの特性「Versatile」: 場にいるポケモン(自分・相手問わず)のワザを、自分についている
    エネルギーで支払って使う。v1簡略版: GXワザ/VSTARパワー自体は借りられない(パーフェクションと同様)。"""
    if player.active is None or player.active.card_id != _MEW_EX_VERSATILE_ID:
        return []
    if not player.active.status.can_attack:
        return []
    mon = player.active
    opponent = state.players[1] if player is state.players[0] else state.players[0]
    actions: list[Action] = []
    for zone, source_card_id in _versatile_attack_sources(player, opponent, card_db):
        source_card = card_db.get(source_card_id)
        for attack in source_card.attacks:
            if _is_gx_attack(attack) or _is_vstar_power_attack(attack):
                continue
            script = get_attack_script(source_card_id, attack.name)
            if not script:
                continue
            ahead_on_prizes = len(player.prizes) > len(opponent.prizes)
            cost = effective_attack_cost(card_db, mon, attack.cost, state.stadium_in_play, ahead_on_prizes, opponent_prizes_taken=6 - len(opponent.prizes))
            if not can_pay_cost(card_db, mon.attached_energy, cost, mon.card_id, double_grass=wild_growth_active(player), ahead_on_prizes=ahead_on_prizes):
                continue
            if any(isinstance(e, DealDamageToChosenOpponentPokemon) for e in script):
                if opponent.active is not None:
                    actions.append(UseBorrowedAttack(zone, source_card_id, attack.name, None))
                for bi in range(len(opponent.bench)):
                    actions.append(UseBorrowedAttack(zone, source_card_id, attack.name, bi))
            else:
                actions.append(UseBorrowedAttack(zone, source_card_id, attack.name))
    return actions


_MEW_FCO_MEMORIES_OF_DAWN_ID = "xy10-29"  # ミュウ(Fates Collide版): 特性「Memories of Dawn」


def _memories_of_dawn_attack_sources(player: PlayerState, card_db: CardDatabase) -> list[tuple[str, str]]:
    """(zone, card_id) のリストを返す(自分の場のたねポケモン、自分自身も含む)。同じカードIDは1回だけ列挙する。"""
    seen: set[tuple[str, str]] = set()
    result: list[tuple[str, str]] = []
    sources: list[tuple[str, list[str]]] = [
        ("own_active", [player.active.card_id] if player.active is not None else []),
        ("own_bench", [m.card_id for m in player.bench]),
    ]
    for zone, card_ids in sources:
        for cid in card_ids:
            card = card_db.get(cid)
            if card is None or not card.is_pokemon or "Basic" not in card.subtypes:
                continue
            key = (zone, cid)
            if key in seen:
                continue
            seen.add(key)
            result.append(key)
    return result


_HAND_CODED_BORROW_HOLDER_IDS = {"xyp-XY126", "xy10-29"}  # 専用の合法手生成(_versatile/_memories_of_dawn)がある


def _passive_borrowed_attack_actions(state: GameState, player: PlayerState, card_db: CardDatabase) -> list[Action]:
    """パッシブ特性(effects/generated_abilities.py: borrow_attacks/team_borrow_previous_evolutions)で、他のポケモンのワザを借りて使う
    (Versatile/Time Recall/Metamorphosis Gene/Shadow Hunt等)。コストは自分(バトルポケモン)についているエネルギーで支払う。
    GXワザ/VSTARパワーは借りられない(1ゲーム1回の制限との整合性)。"""
    from effects.passives import borrowed_attack_sources

    mon = player.active
    if mon is None or not mon.status.can_attack or mon.card_id in _HAND_CODED_BORROW_HOLDER_IDS:
        return []
    player_index = 0 if player is state.players[0] else 1
    sources = borrowed_attack_sources(state, card_db, player_index, mon)
    if not sources:
        return []
    own_card = card_db.get(mon.card_id)
    own_names = {a.name for a in own_card.attacks} if own_card is not None else set()
    opponent = state.players[1 - player_index]
    ahead_on_prizes = len(player.prizes) > len(opponent.prizes)
    actions: list[Action] = []
    for zone, source_card_id in sources:
        source_card = card_db.get(source_card_id)
        for attack in source_card.attacks:
            if _is_gx_attack(attack) or _is_vstar_power_attack(attack):
                continue
            if source_card_id == mon.card_id and attack.name in own_names:
                continue  # 自分自身のワザは通常のAttackで出る
            script = get_attack_script(source_card_id, attack.name)
            if not script:
                continue
            cost = effective_attack_cost(
                card_db, mon, attack.cost, state.stadium_in_play, ahead_on_prizes, opponent_prizes_taken=6 - len(opponent.prizes)
            )
            if not can_pay_cost(
                card_db, mon.attached_energy, cost, mon.card_id, double_grass=wild_growth_active(player), ahead_on_prizes=ahead_on_prizes
            ):
                continue
            if any(_targets_chosen_opponent_pokemon(e) for e in _flatten_script(script)):
                if opponent.active is not None:
                    actions.append(UseBorrowedAttack(zone, source_card_id, attack.name, None))
                for bi in range(len(opponent.bench)):
                    actions.append(UseBorrowedAttack(zone, source_card_id, attack.name, bi))
            else:
                actions.append(UseBorrowedAttack(zone, source_card_id, attack.name))
    return actions


def _memories_of_dawn_attack_actions(state: GameState, player: PlayerState, card_db: CardDatabase) -> list[Action]:
    """ミュウ(Fates Collide版)の特性「Memories of Dawn」: 自分の場のたねポケモンのワザを、自分についている
    エネルギーで支払って使う。v1簡略版: GXワザ/VSTARパワー自体は借りられない(パーフェクション等と同様)。"""
    if player.active is None or player.active.card_id != _MEW_FCO_MEMORIES_OF_DAWN_ID:
        return []
    if not player.active.status.can_attack:
        return []
    mon = player.active
    opponent = state.players[1] if player is state.players[0] else state.players[0]
    actions: list[Action] = []
    for zone, source_card_id in _memories_of_dawn_attack_sources(player, card_db):
        source_card = card_db.get(source_card_id)
        for attack in source_card.attacks:
            if _is_gx_attack(attack) or _is_vstar_power_attack(attack):
                continue
            script = get_attack_script(source_card_id, attack.name)
            if not script:
                continue
            ahead_on_prizes = len(player.prizes) > len(opponent.prizes)
            cost = effective_attack_cost(card_db, mon, attack.cost, state.stadium_in_play, ahead_on_prizes, opponent_prizes_taken=6 - len(opponent.prizes))
            if not can_pay_cost(card_db, mon.attached_energy, cost, mon.card_id, double_grass=wild_growth_active(player), ahead_on_prizes=ahead_on_prizes):
                continue
            if any(isinstance(e, DealDamageToChosenOpponentPokemon) for e in script):
                if opponent.active is not None:
                    actions.append(UseBorrowedAttack(zone, source_card_id, attack.name, None))
                for bi in range(len(opponent.bench)):
                    actions.append(UseBorrowedAttack(zone, source_card_id, attack.name, bi))
            else:
                actions.append(UseBorrowedAttack(zone, source_card_id, attack.name))
    return actions


TOOL_GRANTED_ATTACK_IDS = {"sv4-177", "sv4-178", "sv4-179", "bw10-92"}  # わざマシン各種/Gブースター: ついているポケモンがどうぐ自体のワザを使える
_TOOL_GRANTED_ATTACK_RESTRICTED_TO: dict[str, str] = {
    "bw10-92": "Genesect-EX",  # Gブースター: ゲノセクトEXについているときのみワザ「G Booster」を使える(ホストの名前で判定)
}
# どうぐ自体のワザを使える追加条件: tool_id -> (state, player, opponent, mon, card_db) -> bool(effects/era_tools_j.install_granted が登録)
_TOOL_GRANTED_ATTACK_CONDITIONS: dict = {}
END_OF_TURN_DISCARD_TOOL_IDS = {"sv4-177", "sv4-178", "sv4-179"}  # わざマシン各種: ついた番の終わりにトラッシュされる


def _tool_granted_attack_actions(state: GameState, player: PlayerState, card_db: CardDatabase) -> list[Action]:
    """どうぐ自体にワザが印刷されているカード(わざマシン各種、Gブースター等)がついていれば、
    そのワザを自分についているエネルギーで支払って使える。"""
    if player.active is None or not player.active.status.can_attack:
        return []
    mon = player.active
    tool_id = mon.attached_tool
    if tool_id is None or tool_id not in TOOL_GRANTED_ATTACK_IDS:
        return []
    if tools_disabled(state.stadium_in_play):
        # ジャミングタワー/フラダリラボ等、どうぐ無効化スタジアムが出ている間は、どうぐ自体に
        # 印刷されたワザ(わざマシン各種/Gブースター)も使えない(公式Q&Aで確認、2026-08-25発覚)。
        return []
    required_host = _TOOL_GRANTED_ATTACK_RESTRICTED_TO.get(tool_id)
    if required_host is not None:
        host_card = card_db.get(mon.card_id)
        if host_card is None or host_card.name != required_host:
            return []
    tool_card = card_db.get(tool_id)
    if tool_card is None:
        return []
    opponent = state.players[1] if player is state.players[0] else state.players[0]
    ahead_on_prizes = len(player.prizes) > len(opponent.prizes)
    actions: list[Action] = []
    condition = _TOOL_GRANTED_ATTACK_CONDITIONS.get(tool_id)
    if condition is not None and not condition(state, player, opponent, mon, card_db):
        return []
    for attack in tool_card.attacks:
        script = get_attack_script(tool_id, attack.name)
        if not script:
            continue
        if _is_vstar_power_attack(attack) and player.used_vstar_power_this_game:
            continue
        cost = effective_attack_cost(card_db, mon, attack.cost, state.stadium_in_play, ahead_on_prizes, opponent_prizes_taken=6 - len(opponent.prizes))
        if not can_pay_cost(card_db, mon.attached_energy, cost, mon.card_id, double_grass=wild_growth_active(player), ahead_on_prizes=ahead_on_prizes):
            continue
        if any(isinstance(e, DealDamageToChosenOpponentPokemon) for e in script):
            if opponent.active is not None:
                actions.append(UseBorrowedAttack("own_tool", tool_id, attack.name, None))
            for bi in range(len(opponent.bench)):
                actions.append(UseBorrowedAttack("own_tool", tool_id, attack.name, bi))
        else:
            actions.append(UseBorrowedAttack("own_tool", tool_id, attack.name))
    return actions


def _memory_capsule_attack_actions(state: GameState, player: PlayerState, card_db: CardDatabase) -> list[Action]:
    """メモリカプセル(swsh4-155)実カードテキスト: "The Pokémon this card is attached to can use any attack
    from its previous Evolutions. (You still need the necessary Energy to use each attack.)" ―― バトル場の
    ポケモンの進化前(evolution_historyに積まれた全てのカード)のワザを、自分についているエネルギーで
    支払って使える。どうぐを無効化するスタジアム(ジャミングタワー等)の下では使えない。"""
    mon = player.active
    if mon is None or mon.attached_tool != MEMORY_CAPSULE_ID or not mon.evolution_history:
        return []
    if tools_disabled(state.stadium_in_play) or not mon.status.can_attack:
        return []
    opponent = state.players[1] if player is state.players[0] else state.players[0]
    ahead_on_prizes = len(player.prizes) > len(opponent.prizes)
    actions: list[Action] = []
    seen: set[str] = set()
    for source_card_id in mon.evolution_history:
        if source_card_id in seen:
            continue
        seen.add(source_card_id)
        source_card = card_db.get(source_card_id)
        if source_card is None:
            continue
        for attack in source_card.attacks:
            if _is_gx_attack(attack) or _is_vstar_power_attack(attack):
                continue
            script = get_attack_script(source_card_id, attack.name)
            if not script:
                continue
            cost = effective_attack_cost(card_db, mon, attack.cost, state.stadium_in_play, ahead_on_prizes, opponent_prizes_taken=6 - len(opponent.prizes))
            if not can_pay_cost(card_db, mon.attached_energy, cost, mon.card_id, double_grass=wild_growth_active(player), ahead_on_prizes=ahead_on_prizes):
                continue
            if any(isinstance(e, DealDamageToChosenOpponentPokemon) for e in script):
                if opponent.active is not None:
                    actions.append(UseBorrowedAttack("pre_evolution", source_card_id, attack.name, None))
                for bi in range(len(opponent.bench)):
                    actions.append(UseBorrowedAttack("pre_evolution", source_card_id, attack.name, bi))
            else:
                actions.append(UseBorrowedAttack("pre_evolution", source_card_id, attack.name))
    return actions


_SHADOW_HUNT_CARD_ID = "sm3-80"  # マーシャドーGX


def _shadow_hunt_source_candidates(player: PlayerState, card_db: CardDatabase) -> list[str]:
    """(card_id) のリストを返す。トラッシュのたねポケモンのみ(同じカードIDは1回だけ)。"""
    seen: set[str] = set()
    result: list[str] = []
    for cid in player.discard:
        if cid in seen:
            continue
        card = card_db.get(cid)
        if card is None or not card.is_pokemon or not card.is_basic:
            continue
        seen.add(cid)
        result.append(cid)
    return result


def _shadow_hunt_attack_actions(state: GameState, player: PlayerState, card_db: CardDatabase) -> list[Action]:
    """マーシャドーGXの特性「シャドースティール」: 自分のトラッシュのたねポケモンのワザを、
    自分自身についているエネルギーで支払って使う(v1簡略版: GXワザ自体は借りられない)。"""
    if player.active is None or player.active.card_id != _SHADOW_HUNT_CARD_ID:
        return []
    if not player.active.status.can_attack:
        return []
    mon = player.active
    opponent = state.players[1] if player is state.players[0] else state.players[0]
    actions: list[Action] = []
    for source_card_id in _shadow_hunt_source_candidates(player, card_db):
        source_card = card_db.get(source_card_id)
        for attack in source_card.attacks:
            if _is_gx_attack(attack) or _is_vstar_power_attack(attack):
                continue
            script = get_attack_script(source_card_id, attack.name)
            if not script:
                continue
            ahead_on_prizes = len(player.prizes) > len(opponent.prizes)
            cost = effective_attack_cost(card_db, mon, attack.cost, state.stadium_in_play, ahead_on_prizes, opponent_prizes_taken=6 - len(opponent.prizes))
            if not can_pay_cost(card_db, mon.attached_energy, cost, mon.card_id, double_grass=wild_growth_active(player), ahead_on_prizes=ahead_on_prizes):
                continue
            if any(isinstance(e, DealDamageToChosenOpponentPokemon) for e in script):
                if opponent.active is not None:
                    actions.append(UseBorrowedAttack("discard", source_card_id, attack.name, None))
                for bi in range(len(opponent.bench)):
                    actions.append(UseBorrowedAttack("discard", source_card_id, attack.name, bi))
            else:
                actions.append(UseBorrowedAttack("discard", source_card_id, attack.name))
    return actions


_COPYCAT_CARD_ID = "sm2-58"  # ミミッキュ


def _copycat_attack_actions(state: GameState, player: PlayerState, card_db: CardDatabase) -> list[Action]:
    """ミミッキュの「コピーキャット」: 相手が直前の自分の番で使った、GXワザではないワザをこのワザとして使う。
    コストは自分自身(ミミッキュ)の「コピーキャット」の印刷コストで判定する(ワザコピー系の他カードと同様)。"""
    if player.active is None or player.active.card_id != _COPYCAT_CARD_ID:
        return []
    if not player.active.status.can_attack:
        return []
    own_card = card_db.get(player.active.card_id)
    own_attack = next((a for a in own_card.attacks if a.name == "Copycat"), None) if own_card else None
    if own_attack is None:
        return []
    opponent = state.players[1] if player is state.players[0] else state.players[0]
    last = opponent.last_attack_used
    if last is None:
        return []
    source_card_id, attack_name = last
    source_card = card_db.get(source_card_id)
    if source_card is None:
        return []
    attack = next((a for a in source_card.attacks if a.name == attack_name), None)
    if attack is None or _is_gx_attack(attack) or _is_vstar_power_attack(attack):
        return []
    script = get_attack_script(source_card_id, attack_name)
    if not script:
        return []
    ahead_on_prizes = len(player.prizes) > len(opponent.prizes)
    cost = effective_attack_cost(card_db, player.active, own_attack.cost, state.stadium_in_play, ahead_on_prizes, opponent_prizes_taken=6 - len(opponent.prizes))
    if not can_pay_cost(card_db, player.active.attached_energy, cost, player.active.card_id, double_grass=wild_growth_active(player), ahead_on_prizes=ahead_on_prizes):
        return []
    actions: list[Action] = []
    if any(isinstance(e, DealDamageToChosenOpponentPokemon) for e in script):
        if opponent.active is not None:
            actions.append(UseBorrowedAttack("opponent_last", source_card_id, attack_name, None))
        for bi in range(len(opponent.bench)):
            actions.append(UseBorrowedAttack("opponent_last", source_card_id, attack_name, bi))
    else:
        actions.append(UseBorrowedAttack("opponent_last", source_card_id, attack_name))
    return actions


class _NullCard:
    is_energy = False


# 同名・同文面の再録カードのIDを、実装済みの代表カードのIDテーブルに足す(effects/card_aliases.py)
from effects.card_aliases import apply_aliases as _apply_card_aliases  # noqa: E402

_apply_card_aliases()
