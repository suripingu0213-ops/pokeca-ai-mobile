"""唯一の正となる状態遷移関数 `apply_action`。

`scripts/play_match.py` と `rl_env/env.py` の両方がここを通じてのみ
GameStateを変更する。
"""

from __future__ import annotations

from effects.card_aliases import AliasStr

from cards.card_db import CardDatabase, ITEM_AS_POKEMON, POKEMON_AS_ITEM, ROBO_SUBSTITUTE_ITEM_ID, ROBO_SUBSTITUTE_POKEMON_ID
from engine.continuous import effective_max_hp, tools_disabled

_DANGEROUS_RUINS_ID = "m1l-63"  # 危ない廃墟
from effects.context import EffectContext
from effects.interpreter import run_script
from effects.registry import (
    get_ability_script,
    get_after_attack_trigger_script,
    is_mandatory_after_attack_trigger,
    get_attack_script,
    get_become_active_trigger_script,
    get_discard_ability_script,
    DISCARD_ABILITY_TO_HAND_CARD_IDS,
    get_energy_attach_trigger_script,
    get_enter_bench_trigger_script,
    get_evolve_trigger_script,
    get_level_up_trigger_script,
    get_mandatory_energy_attach_trigger_script,
    get_stadium_ability_script,
    get_trainer_paired_script,
    get_trainer_script,
)
from engine.actions import (
    AcceptTrigger,
    Action,
    Attack,
    AttachEnergy,
    ChooseInitialActive,
    ChooseMulliganBonusDrawCount,
    ChooseNewActive,
    ConfirmSetupDone,
    DeclineTrigger,
    DiscardRoboSubstitute,
    EndTurn,
    Evolve,
    PlayBasicPokemon,
    PlayItem,
    PlayLevelUp,
    PlayPokemonTool,
    PlaySupporter,
    PlayStadium,
    PassPowerSprayWindow,
    ResolveDamageDistribution,
    ResolveSearchChoice,
    Retreat,
    UseAbility,
    UseBorrowedAttack,
    UseDiscardAbility,
    UsePowerSpray,
    UseStadiumAbility,
    Zone,
)
from engine.display import ability_kind_label, card_name, jp_ability, jp_attack
from engine.continuous import enforce_status_protection
from engine.energy import (
    BOOMERANG_ENERGY_ID,
    SPLASH_ENERGY_ID,
    energy_effect_present,
    special_energy_effects_suppressed,
    special_energy_suppression_for,
    TELEPATHIC_PSYCHIC_ENERGY_ID,
    TELEPATHIC_PSYCHIC_ENERGY_REPRINT_ID,
    auto_select_retreat_payment,
    effective_retreat_cost_count,
    has_dark_cloak_in_play,
    has_thunderclap_zone_in_play,
    has_skyliner_in_play,
    retreat_discard_choice_count,
)
from engine.legal_actions import ATTACK_COPY_SOURCES, can_play_power_spray, next_actor
from engine.state import GameState, discard_attached_tool, PendingDamageDistribution, PendingPowerSprayWindow, PendingSearchChoice, PendingTrigger, PlayerState, PokemonInPlay
from engine.status import resolve_confusion_attack_check
from engine.turn_manager import advance_turn, begin_game, run_pokemon_checkup
from engine.win_conditions import apply_knockouts, check_win_conditions

POKEMON_PARK_STADIUM_ID = "pop2-10"

# 「〜出したとき/レベルアップしたとき、してもよい」系ポケパワーのうち、対象選択が必要なものの対象範囲。
# (Bright Look: 相手のベンチポケモンを選ぶ / Flash Bite: 相手のポケモン1匹(バトルもベンチも可)を選ぶ)
_TRIGGER_TARGET_KIND: dict[str, str] = {
    "pl2-109": "opponent_bench",  # Luxray GL LV.X: かがやくまなざし(Bright Look)
    "pl1-47": "opponent_any",  # Crobat G: フラッシュバイト(Flash Bite)
    "swsh5-87": "own_bench",  # Rapid Strike Urshifu V: ワザ「Strafe」の後、自分のベンチと入れ替えてもよい
    "xy4-32": "opponent_any",  # ゴルバット(Golbat): Sneaky Bite
    "xy4-33": "opponent_any",  # クロバット(Crobat): Surprise Bite
    "bw10-11": "opponent_bench",  # ゲノセクトEX: Red Signal
    "sv9-136": "opponent_bench",  # ダンデのバイウールー(Hop's Dubwool): Defiant Horn
    "dp7-95": "own_bench",  # ワープエネルギー: バトルポケモンにつけたとき、自分のベンチポケモン1匹と入れ替える
}


def _evolve_trigger_condition_met(card_id: str, player: PlayerState, card_db: CardDatabase) -> bool:
    """進化トリガーの中には発動条件つきのものがある(ヨルノズクの「ジュエルシーカー」: 自分の場に
    テラスタルポケモンがいること)。"""
    if card_id == "sv7-115":  # ヨルノズク(Noctowl): 自分の場にテラスタルポケモンが必要
        return any(
            (c := card_db.get(mon.card_id)) is not None and "Tera" in c.subtypes
            for mon in player.all_pokemon_in_play()
        )
    return True


class IllegalActionError(ValueError):
    pass


def apply_action(state: GameState, card_db: CardDatabase, action: Action) -> GameState:
    # シンオウ神殿が場にある間は、特殊エネルギーの固有効果を無効にして処理する(engine.energy参照)
    with special_energy_suppression_for(state, card_db):
        from effects.era_special import heal_block_active
        from engine.state import HEAL_BLOCK

        from engine.state import HEAL_BLOCKED_MON_IDS

        heal_block_token = HEAL_BLOCK.set(heal_block_active(state, card_db))
        blocked_ids = frozenset(
            id(mon)
            for side, owner in enumerate(state.players)
            for mon in owner.all_pokemon_in_play()
            if mon.heal_blocked_turn and state.current_player == side and owner.turns_taken == mon.heal_blocked_turn
        )
        heal_blocked_token = HEAL_BLOCKED_MON_IDS.set(blocked_ids)
        try:
            return _apply_action_guarded(state, card_db, action)
        finally:
            HEAL_BLOCKED_MON_IDS.reset(heal_blocked_token)
            HEAL_BLOCK.reset(heal_block_token)


def _apply_action_guarded(state: GameState, card_db: CardDatabase, action: Action) -> GameState:
    from effects.passives_ext import active_snapshot, after_active_moved_to_bench

    from effects.era_energy_g import after_action_energy, energy_snapshot

    snapshot = _own_active_snapshot(state)
    actives_before = active_snapshot(state)
    energy_before = energy_snapshot(state, card_db)
    result = _apply_action_impl(state, card_db, action)
    after_action_energy(state, card_db, energy_before, isinstance(action, (Attack, UseBorrowedAttack)))  # リサイクル/ニトロファイア/バーニングエネルギー
    after_active_moved_to_bench(state, card_db, actives_before)  # Holes/Swirling Prose
    _offer_become_active_trigger(state, card_db, snapshot)
    from effects.era_trainers import discard_invalid_special_energy

    discard_invalid_special_energy(state, card_db)  # ハーブエネルギー: くさポケモン以外についたらトラッシュする
    from effects.era_sm_hooks import prism_star_to_lost_zone

    prism_star_to_lost_zone(state, card_db)  # ◇のルール: トラッシュに行くかわりにロストゾーンへ
    return result


def _own_active_snapshot(state: GameState):
    """手番プレイヤーのバトルポケモンとベンチの参照(「ベンチからバトル場に出たとき」系の特性の判定用)。"""
    if not state.setup_complete or state.is_game_over():
        return None
    player = state.player(state.current_player)
    return (state.current_player, state.turn_number, player.active, list(player.bench))


def _offer_become_active_trigger(state: GameState, card_db: CardDatabase, snapshot) -> None:
    """自分の番に、自分のベンチのポケモンがバトル場に出たら、「ベンチからバトル場に出たとき、してもよい」系の特性
    (ヒードランGXの「Burning Road」: "Once during your turn, when this Pokémon moves from your Bench to become your
    Active Pokémon")を発動するか選ばせる。にげる/入れ替えグッズ・サポート/ワザの自己入れ替え等、原因を問わない
    (以前はにげる場合のみだった。2026-10-06訂正)。相手の番にきぜつして出た場合は「自分の番」ではないので対象外。"""
    if snapshot is None or state.is_game_over() or state.pending_trigger is not None:
        return
    player_index, turn_number, old_active, old_bench = snapshot
    if state.current_player != player_index or state.turn_number != turn_number:
        return
    player = state.player(player_index)
    new_active = player.active
    if new_active is None or new_active is old_active or not any(new_active is m for m in old_bench):
        return
    script = get_become_active_trigger_script(new_active.card_id)
    if not script or new_active.used_ability_this_turn:
        return
    from engine.continuous import ability_suppressed

    if ability_suppressed(state, card_db, player_index, new_active):
        return
    _set_pending_trigger(state, player_index, new_active.card_id, new_active, script)


def _apply_action_impl(state: GameState, card_db: CardDatabase, action: Action) -> GameState:
    if state.is_game_over():
        raise IllegalActionError("対局はすでに終了しています")

    actor = next_actor(state)

    if isinstance(action, ChooseNewActive):
        _handle_choose_new_active(state, card_db, actor, action)
        enforce_status_protection(state, card_db)
        return state

    # pending_active_choiceはnext_actor()の優先順位で他の保留(検索選択等)より低いため、
    # それらが同時に立っている間はここでブロックしない(next_actor()自体が既にそちらを優先して
    # actorを解決している。ここで単純に「actorがpending_active_choiceに含まれるか」だけを見ると、
    # 検索選択の解決中に同じプレイヤーの新アクティブ選択が偶然重なったときに膠着してしまう)。
    if (
        state.pending_search_choice is None
        and state.pending_damage_distribution is None
        and state.pending_trigger is None
        and state.pending_power_spray_window is None
        and actor in state.pending_active_choice
    ):
        raise IllegalActionError("新しいバトルポケモンを選ぶ必要があります")

    handler = _HANDLERS.get(type(action))
    if handler is None:
        raise IllegalActionError(f"未知のアクション: {action}")
    handler(state, card_db, actor, action)
    enforce_status_protection(state, card_db)
    return state


def _handle_choose_initial_active(state: GameState, card_db: CardDatabase, actor: int, action: ChooseInitialActive) -> None:
    player = state.player(actor)
    card_id = player.hand.pop(action.hand_index)
    player.active = PokemonInPlay(card_id=card_id, turn_played=0)
    state.setup_active_chosen[actor] = True
    state.add_log(f"player{actor} が {card_name(card_db, card_id)} をバトルポケモンに選んだ")


def _handle_confirm_setup_done(state: GameState, card_db: CardDatabase, actor: int, action: ConfirmSetupDone) -> None:
    if state.setup_player == state.first_player:
        state.setup_player = 1 - state.first_player
        return
    # 両者がバトル/ベンチポケモンを置き終えた後、マリガンのボーナスドローが1枚でもある
    # プレイヤーがいれば、何枚引くか(公式ルール上、相手のマリガン回数まで好きな枚数でよい)を
    # 選んでもらう。誰にも無ければそのまま対局開始。
    pending_players = tuple(i for i, count in enumerate(state.pending_mulligan_bonus_draws) if count > 0)
    if not pending_players:
        state.setup_complete = True
        begin_game(state, card_db)
        return
    state.mulligan_bonus_draw_pending_players = pending_players


def _handle_choose_mulligan_bonus_draw_count(
    state: GameState, card_db: CardDatabase, actor: int, action: ChooseMulliganBonusDrawCount
) -> None:
    max_count = state.pending_mulligan_bonus_draws[actor]
    count = max(0, min(action.count, max_count))
    player = state.player(actor)
    drawn = 0
    for _ in range(count):
        if not player.deck:
            break
        player.hand.append(player.deck.pop(0))
        drawn += 1
    if drawn:
        state.add_log(f"player{actor} はマリガンのボーナスドローを{drawn}枚引いた(最大{max_count}枚まで選べた)")
    else:
        state.add_log(f"player{actor} はマリガンのボーナスドローを引かないことを選んだ(最大{max_count}枚まで選べた)")
    state.pending_mulligan_bonus_draws = tuple(
        0 if i == actor else c for i, c in enumerate(state.pending_mulligan_bonus_draws)
    )
    state.mulligan_bonus_draw_pending_players = tuple(
        p for p in state.mulligan_bonus_draw_pending_players if p != actor
    )
    if not state.mulligan_bonus_draw_pending_players:
        state.setup_complete = True
        begin_game(state, card_db)


def _apply_forced_turn_end(state: GameState, card_db: CardDatabase) -> bool:
    """「この効果を使ったら、自分の番は終わる」(オーキド博士のヒント/トロピカルビーチ/ルミオスシティ/ミスティの活力等)の処理。
    選択待ちが残っている場合は、その選択(の連鎖)が終わったあとにターンを終えるよう印を引き継ぐ(then_end_turn)。ターンを終えたらTrue。"""
    if not state.forced_turn_end_after_ability:
        return False
    state.forced_turn_end_after_ability = False
    if state.is_game_over() or state.pending_active_choice:
        return False
    pending = state.pending_search_choice
    if pending is not None:
        pending.then_end_turn = True
        if isinstance(pending.custom_data, dict):
            pending.custom_data["then_end_turn"] = True
        return False
    if state.pending_damage_distribution is not None or state.pending_trigger is not None:
        return False
    _end_current_turn(state, card_db)
    return True


def _maybe_end_turn_after_pending_choice(state: GameState, card_db: CardDatabase, then_end_turn: bool) -> None:
    """検索選択/ダメカン配分の保留がワザの効果として発生していた場合、解決後にターンを終了する
    (ワザは通常ターンを終える効果のため。トレーナーズ/特性由来の保留はthen_end_turn=Falseなので
    何もしない、_handle_accept_trigger/_handle_decline_triggerと同じ考え方)。"""
    if not then_end_turn or state.is_game_over():
        return
    if state.pending_search_choice is not None or state.pending_damage_distribution is not None:
        return  # remaining_script等で選択がさらに連鎖しているので、まだ終了しない
    if state.pending_active_choice:
        state.then_after_choice = "advance"
    else:
        _finish_attack_or_offer_second(state, card_db)


def _run_remaining_after_generic(
    state: GameState, card_db: CardDatabase, choice, last_attach_succeeded: bool = False
) -> None:
    """汎用選択(effects/era_primitives_b.py)が終わった後、元の効果スクリプトの続き(choice.remaining_script)を実行する。
    選択がさらに続く(新しい保留ができた)なら、続きはその保留に引き継ぐ。"""
    rest = tuple(choice.remaining_script)
    if not rest:
        return
    pending = state.pending_search_choice
    if pending is not None:
        pending.remaining_script = pending.remaining_script + rest
        pending.cont_source_pokemon = choice.cont_source_pokemon
        pending.cont_source_card_id = choice.cont_source_card_id
        pending.cont_target_bench_index = choice.cont_target_bench_index
        return
    ctx = EffectContext(
        state=state, card_db=card_db, acting_player=choice.actor(), source_pokemon=choice.cont_source_pokemon,
        source_card_id=choice.cont_source_card_id, target_bench_index=choice.cont_target_bench_index, rng=state.rng,
        effect_source=choice.effect_source,
    )
    ctx.last_attach_succeeded = last_attach_succeeded
    run_script(rest, ctx)


def _propagate_then_end_turn(state: GameState, then_end_turn: bool) -> None:
    """選択の解決が新しい選択待ちを作った場合、ワザの効果として発生した保留(then_end_turn)を引き継ぐ。"""
    pending = state.pending_search_choice
    if pending is not None and then_end_turn:
        pending.then_end_turn = True
        if isinstance(pending.custom_data, dict):
            pending.custom_data["then_end_turn"] = True


def _handle_resolve_search_choice(
    state: GameState, card_db: CardDatabase, actor: int, action: ResolveSearchChoice
) -> None:
    """検索/選択の解決。きぜつ時の効果(エキスパートシェア等)の選択(custom_dataにko_contを持つ)は、解決が終わったら
    きぜつ後の続き(残りのきぜつ時の効果→サイド選択→新アクティブ選択→ターンの続き)に戻る。"""
    choice = state.pending_search_choice
    ko_cont = choice.custom_data.get("ko_cont") if choice is not None and isinstance(choice.custom_data, dict) else None
    if ko_cont is None:
        _handle_resolve_search_choice_inner(state, card_db, actor, action)
        _apply_forced_turn_end(state, card_db)  # 選択のあとで「自分の番は終わる」が確定した効果(ルミオスシティ/ミスティの活力)
        return
    saved_followups = state.ko_followups
    state.ko_followups = []  # 内側の処理(_resolve_incidental_knockouts等)が、残りのきぜつ時の効果を勝手に始めないよう退避する
    try:
        _handle_resolve_search_choice_inner(state, card_db, actor, action)
    finally:
        state.ko_followups = saved_followups + state.ko_followups
    if (
        state.pending_search_choice is None and not state.pending_active_choice and state.pending_trigger is None
        and state.pending_damage_distribution is None and not state.is_game_over()
    ):
        _resume_after_ko_followups(state, card_db, ko_cont)


def _resume_after_ko_followups(state: GameState, card_db: CardDatabase, cont: dict) -> None:
    """きぜつ時の効果の選択が終わった後、元のきぜつ処理の続き(次のきぜつ時の効果/サイド選択/新アクティブ選択/ターンの続き)を行う。"""
    then_after_choice = cont.get("then_after_choice", "continue")
    then_end_turn = cont.get("then_end_turn", False)
    if _start_knockout_followups(
        state, cont.get("needs_new_active", []), cont.get("needs_prize_choice", []), then_after_choice,
        then_end_turn=then_end_turn, card_db=card_db,
    ):
        return
    check_win_conditions(state)
    if state.is_game_over():
        return
    if then_after_choice == "checkup":
        _run_checkup_and_advance(state, card_db)
    elif then_after_choice == "advance":
        advance_turn(state, card_db)
    elif then_after_choice == "attack_again":
        state.player(state.current_player).pending_second_attack = True
    else:
        _maybe_end_turn_after_pending_choice(state, card_db, then_end_turn)


def _handle_resolve_search_choice_inner(
    state: GameState, card_db: CardDatabase, actor: int, action: ResolveSearchChoice
) -> None:
    choice = state.pending_search_choice
    if choice is None:
        raise IllegalActionError("保留中の検索がありません")
    selected = sorted(set(action.selected_indices))
    if len(selected) < choice.min_count or len(selected) > choice.max_count:
        raise IllegalActionError("選択できる枚数の範囲外です")
    if choice.allowed_counts is not None and len(selected) not in choice.allowed_counts:
        raise IllegalActionError(f"選べる枚数は{'か'.join(str(n) for n in choice.allowed_counts)}枚です")
    if any(i < 0 or i >= len(choice.card_ids) for i in selected):
        raise IllegalActionError("不正な選択です")
    if choice.exclusive_subtype is not None:
        from engine.legal_actions import _exclusive_subtype_selection_ok

        if not _exclusive_subtype_selection_ok(choice, selected, card_db):
            raise IllegalActionError(f"{choice.exclusive_subtype}は1枚だけ選ぶか、それ以外だけを選んでください")

    player = state.player(choice.player_index)
    then_end_turn = choice.then_end_turn

    if choice.zone == "field_attachment":
        _resolve_field_attachment_choice(state, card_db, choice, selected)
        _maybe_end_turn_after_pending_choice(state, card_db, then_end_turn)
        return
    if choice.zone == "revealed_card_attack_choice":
        # ヤドキングの「ひらめきチャレンジ」: 山札からトラッシュしたポケモンのワザを1つ選んで使う。
        from effects.primitives import run_borrowed_attack_script

        mode_data = choice.custom_data if isinstance(choice.custom_data, dict) else {}
        revealed_card_id = mode_data.get("revealed_card_id")
        option_card_ids = mode_data.get("option_card_ids")
        if option_card_ids and selected and 0 <= selected[0] < len(option_card_ids):
            revealed_card_id = option_card_ids[selected[0]]  # Assist等: 複数のポケモンのワザから選ぶとき、選んだワザの持ち主
        state.pending_search_choice = None
        options = mode_data.get("options")
        use_optional_variant = False
        attack_index = selected[0] if selected else None
        if options is not None and attack_index is not None and 0 <= attack_index < len(options):
            # 選択肢は(ワザの番号, 「エネルギーを捨てて追加ダメージ」版か)。後者はAttackのtarget_bench_index=0と同じ意味
            attack_index, use_optional_variant = options[attack_index]
        source_card = card_db.get(revealed_card_id) if revealed_card_id else None
        if source_card is not None and attack_index is not None and 0 <= attack_index < len(source_card.attacks):
            cont_ctx = EffectContext(
                state=state,
                card_db=card_db,
                acting_player=choice.actor(),
                source_pokemon=choice.cont_source_pokemon,
                source_card_id=choice.cont_source_card_id,
                target_bench_index=0 if use_optional_variant else None,
                rng=state.rng,
            )
            run_borrowed_attack_script(cont_ctx, revealed_card_id, source_card.attacks[attack_index].name)
        if state.pending_search_choice is not None or state.pending_damage_distribution is not None:
            # トライフロスト(複数の相手ポケモンを選んでダメージ)等、借りたワザ自体が新しい選択待ちを
            # 作る場合、then_end_turnをその新しい保留にも伝えないと、選択が解決してもターンが
            # 終わらなくなる(_handle_use_borrowed_attackと同じ理由の同型バグ)。
            if state.pending_search_choice is not None:
                state.pending_search_choice.then_end_turn = then_end_turn
                if isinstance(state.pending_search_choice.custom_data, dict):
                    state.pending_search_choice.custom_data["then_end_turn"] = then_end_turn
            if state.pending_damage_distribution is not None:
                state.pending_damage_distribution.then_end_turn = then_end_turn
            return
        # _handle_attackと同じ理由: 借りたワザ自身に「ワザ後にしてもよい」効果(メタグロスの
        # 「Metallic Hammer」等)が登録されている場合、ひらめきチャレンジで借りて使ったときも
        # 同様に提示する。コピー元(revealed_card_id)ではなく実際に攻撃しているポケモン
        # (choice.cont_source_pokemon)自身を発動元にする。
        if source_card is not None and attack_index is not None and 0 <= attack_index < len(source_card.attacks):
            after_script = get_after_attack_trigger_script(revealed_card_id, source_card.attacks[attack_index].name)
            if (
                after_script
                and (player.bench or not _after_attack_trigger_needs_bench(after_script))
                and choice.cont_source_pokemon is not None
            ):
                jp_after_attack_name, _ = jp_attack(revealed_card_id, source_card.attacks[attack_index])
                _set_pending_trigger(
                    state,
                    choice.player_index,
                    choice.cont_source_card_id,
                    choice.cont_source_pokemon,
                    after_script,
                    then_end_turn=then_end_turn,
                    override_kind="ワザ",
                    override_label=jp_after_attack_name,
                )
                return
        _resolve_incidental_knockouts(state, card_db, then_end_turn=then_end_turn)
        _maybe_end_turn_after_pending_choice(state, card_db, then_end_turn)
        return
    if choice.zone == "opponent_hand_to_discard":
        # メガアブソルexの「Claw of Darkness」: 相手の手札から見つけた1枚をトラッシュする。
        opponent = state.player(state.opponent_index(choice.player_index))
        removed_indices = sorted((choice.source_indices[pos] for pos in selected), reverse=True)
        for idx in removed_indices:
            if 0 <= idx < len(opponent.hand):
                opponent.discard.append(opponent.hand.pop(idx))
        state.pending_search_choice = None
        _resolve_incidental_knockouts(state, card_db, then_end_turn=then_end_turn)
        _maybe_end_turn_after_pending_choice(state, card_db, then_end_turn)
        return
    if choice.zone == "opponent_hand_to_bottom_of_deck":
        # N's Purrloinの「Thieving Swipe」: 相手の手札から見つけた1枚を相手の山札の下に置く。
        opponent = state.player(state.opponent_index(choice.player_index))
        removed_indices = sorted((choice.source_indices[pos] for pos in selected), reverse=True)
        for idx in removed_indices:
            if 0 <= idx < len(opponent.hand):
                opponent.deck.append(opponent.hand.pop(idx))
        state.pending_search_choice = None
        _resolve_incidental_knockouts(state, card_db, then_end_turn=then_end_turn)
        _maybe_end_turn_after_pending_choice(state, card_db, then_end_turn)
        return
    from effects.era_primitives_b import GENERIC_ZONES

    if choice.zone in GENERIC_ZONES:
        # エネルギーを自由につける/移す・相手の手札/山札の上を見る系の汎用選択(effects/era_primitives_b.py)
        from effects.era_primitives_b import resolve_generic_zone

        state.pending_search_choice = None
        result = resolve_generic_zone(state, card_db, choice, selected, action)
        if not result.consumed_remaining:
            _run_remaining_after_generic(state, card_db, choice, result.last_attach_succeeded)
        _propagate_then_end_turn(state, then_end_turn)
        _resolve_incidental_knockouts(state, card_db, then_end_turn=then_end_turn)
        _maybe_end_turn_after_pending_choice(state, card_db, then_end_turn)
        return
    if choice.zone == "own_pokemon_target":
        _resolve_own_pokemon_target_choice(state, card_db, choice, selected)
        _maybe_end_turn_after_pending_choice(state, card_db, then_end_turn)
        return
    if choice.zone == "own_pokemon_energy_target":
        _resolve_own_pokemon_energy_target_choice(state, card_db, choice, selected)
        _maybe_end_turn_after_pending_choice(state, card_db, then_end_turn)
        return
    if choice.zone == "opponent_pokemon_target":
        _resolve_opponent_pokemon_target_choice(state, card_db, choice, selected)
        _maybe_end_turn_after_pending_choice(state, card_db, then_end_turn)
        return
    if choice.zone == "retreat_energy_discard":
        _resolve_retreat_energy_discard_choice(state, card_db, choice, selected)
        _maybe_end_turn_after_pending_choice(state, card_db, then_end_turn)
        return
    if choice.zone == "status_condition_remove_choice":
        from effects.primitives import clear_status_by_label

        mode_data = choice.custom_data if isinstance(choice.custom_data, dict) else {}
        pokemon = mode_data.get("pokemon")
        state.pending_search_choice = None
        if pokemon is not None and selected:
            label = choice.card_ids[selected[0]]
            clear_status_by_label(pokemon.status, label)
            state.add_log(f"バトルポケモンの「{label}」を治した")
        _maybe_end_turn_after_pending_choice(state, card_db, then_end_turn)
        return
    if choice.zone == "damage_counter_amount_choice":
        # ムンキドリの「Adrena-Brain」等: 移動元・移動先が確定した後、実際に何個(0個でもよい)
        # 移すかを選ぶ。選択肢の位置(0始まり)がそのまま移動する個数に対応する。
        from effects.primitives import (
            _BATTLE_COLOSSEUM_STADIUM_ID,
            _blocks_damage_counters,
            _defender_blocks_attack_and_ability_non_damage_effects,
            _defender_is_shielded,
        )
        from engine.continuous import tools_disabled

        mode_data = choice.custom_data if isinstance(choice.custom_data, dict) else {}
        source_mon = mode_data.get("source_pokemon")
        target_mon = mode_data.get("target_pokemon")
        state.pending_search_choice = None
        amount = selected[0] if selected else 0
        if source_mon is not None and target_mon is not None and amount > 0:
            move_amount = min(source_mon.damage, amount * 10)
            source_mon.remove_counters(move_amount)
            # 公式Q&A確認済み: バトルコロシアム等で移動先にダメカンをのせられない場合でも、
            # 移動元からの除去(選んだぶんを取り除く)自体は必ず起こる。「移動先にのらない」だけが
            # 阻まれる(移動全体が丸ごとキャンセルされるわけではない)。以前はこの区別が無く、
            # 単純に「移動先の免疫チェックで丸ごとブロック」としていたため、公式ルールと逆の挙動に
            # なっていた(2026-08-23、ユーザー提示の公式FAQで訂正)。
            target_owner = state.player(state.opponent_index(choice.player_index))
            block_ctx = EffectContext(
                state=state,
                card_db=card_db,
                acting_player=choice.actor(),
                source_pokemon=source_mon,
                source_card_id=source_mon.card_id,
                rng=state.rng,
            )
            # ムンキドリの「Adrena-Brain」は特性由来の効果なので、ワザ限定免疫(ミストエネルギー等、
            # 実カードテキストが「相手のポケモンのワザの効果を受けない」と明記されたもの)はここでは
            # 適用しない(2026-09-02、ユーザー指摘・公式FAQで裏取り)。一方、ばけがくれ等の「ワザ/特性
            # 共通」免疫(実カードテキスト: "Prevent all effects of your opponent's Pokémon's attacks
            # and Abilities done to this Pokémon.")は特性由来の効果にも適用されるため、こちらは見る
            # (2026-09-04、ムンキドリ「Adrena-Brain」vsばけがくれの誤判定を修正)。
            blocked = (
                _defender_is_shielded(block_ctx, target_mon)
                or _defender_blocks_attack_and_ability_non_damage_effects(block_ctx, target_mon)
                or (not tools_disabled(state.stadium_in_play) and _blocks_damage_counters(target_mon))
                or (
                    state.stadium_in_play == _BATTLE_COLOSSEUM_STADIUM_ID
                    and target_mon is not target_owner.active
                )
            )
            if not blocked:
                target_mon.damage += move_amount
                state.add_log(f"{choice.prompt}: ダメカンを{amount}個移した")
            else:
                state.add_log(f"{choice.prompt}: 移動先にダメカンをのせられないため、{amount}個を取り除いた")
        else:
            state.add_log(f"{choice.prompt}: 移動しなかった")
        _resolve_incidental_knockouts(state, card_db, then_end_turn=then_end_turn)
        _maybe_end_turn_after_pending_choice(state, card_db, then_end_turn)
        return
    if choice.zone == "own_source_pokemon_energy":
        # ドータクンBREAKの「メタルレイン」等: ワザ使用ポケモンについているエネルギーのうち、
        # トラッシュする分(0枚でもよい)を選ぶ。選んだ枚数×damage_perのダメージを、続けて
        # 相手のポケモンに自由に分配する。
        player = state.player(choice.player_index)
        source_mon = choice.cont_source_pokemon
        mode_data = choice.custom_data if isinstance(choice.custom_data, dict) else {}
        damage_per = mode_data.get("damage_per", 0)
        state.pending_search_choice = None
        if source_mon is None:
            _maybe_end_turn_after_pending_choice(state, card_db, then_end_turn)
            return
        chosen_indices = sorted((choice.source_indices[pos] for pos in selected), reverse=True)
        discarded: list[str] = []
        for idx in chosen_indices:
            if 0 <= idx < len(source_mon.attached_energy):
                discarded.append(source_mon.attached_energy.pop(idx))
        player.discard.extend(discarded)
        names = [card_name(card_db, cid) for cid in discarded]
        state.add_log(f"{choice.prompt}: {', '.join(names) if names else '(選ばなかった)'} をトラッシュした")
        n = len(discarded)
        if n > 0:
            opponent = state.player(1 - choice.player_index)
            num_targets = len(opponent.bench) + (1 if opponent.active is not None else 0)
            if num_targets > 0:
                state.pending_damage_distribution = PendingDamageDistribution(
                    player_index=choice.player_index,
                    total_counters=n * (damage_per // 10),
                    source_card_id=choice.cont_source_card_id,
                    then_end_turn=then_end_turn,
                )
                _resolve_incidental_knockouts(state, card_db)
                return
        _resolve_incidental_knockouts(state, card_db, then_end_turn=then_end_turn)
        _maybe_end_turn_after_pending_choice(state, card_db, then_end_turn)
        return
    if choice.zone == "deck_top_n_energy_take":
        # マックスげんき/でんきはっせいき等: 山札の上から見つけた基本エネルギーのうち、実際に
        # つける分を選ぶ。選ばなかった分・対象外だった分は山札に戻してシャッフルする
        # ("Shuffle the other cards back into your deck")。選んだ分は続けて対象ポケモンを選ばせる
        # ("in any way you like"、1枚ずつ対象を選び直せる自由分配)。
        from effects.primitives import _attach_found_energies_freely

        player = state.player(choice.player_index)
        mode_data = choice.custom_data if isinstance(choice.custom_data, dict) else {}
        non_eligible = mode_data.get("non_eligible", [])
        taken = tuple(choice.card_ids[pos] for pos in selected)
        unchosen = [choice.card_ids[pos] for pos in range(len(choice.card_ids)) if pos not in selected]
        if mode_data.get("rest_to_hand"):
            # サーナイトの「Shining Arcana」/ザシアンVの「Intrepid Sword」: 選ばなかった残りは山札に戻さず手札に加える
            player.hand.extend(non_eligible)
            player.hand.extend(unchosen)
        else:
            player.deck.extend(non_eligible)
            player.deck.extend(unchosen)
            state.rng.shuffle(player.deck)
        state.add_log(f"{choice.prompt}: {len(taken)}枚を選んだ")
        state.pending_search_choice = None
        if taken and mode_data.get("self_only") and choice.cont_source_pokemon is not None:
            choice.cont_source_pokemon.attached_energy.extend(taken)
        elif taken:
            cont_ctx = EffectContext(
                state=state, card_db=card_db, acting_player=choice.actor(),
                source_pokemon=choice.cont_source_pokemon, source_card_id=choice.cont_source_card_id, rng=state.rng,
            )
            _attach_found_energies_freely(
                cont_ctx, taken, bench_only=mode_data.get("bench_only", False),
                target_pokemon_type=mode_data.get("target_pokemon_type"),
                basic_stage_only=mode_data.get("basic_stage_only", True), then_end_turn=then_end_turn,
            )
        _resolve_incidental_knockouts(state, card_db, then_end_turn=then_end_turn)
        _maybe_end_turn_after_pending_choice(state, card_db, then_end_turn)
        return
    if choice.zone == "own_prizes_take":
        # きぜつ後、実カードルール通り「残りサイドを見て自分でどれを取るか選ぶ」(win_conditions.
        # apply_knockoutsが選ぶ余地があるときだけこの選択を立てる)。選んだ分を手札に移し、
        # まだキューに残っている別のきぜつぶんのサイド選択があれば続けて立てる。無ければ
        # 新アクティブ選択→勝敗判定→(checkup/advance/continue)の元の続きに戻る。
        mode_data = choice.custom_data if isinstance(choice.custom_data, dict) else {}
        removed_indices = sorted((choice.source_indices[pos] for pos in selected), reverse=True)
        taken: list[str] = []
        for idx in removed_indices:
            if 0 <= idx < len(player.prizes):
                taken.append(player.take_prize(idx))
        player.hand.extend(taken)
        # サイドの中身は本人だけが知る私的情報なので、実際に取ったカード名はログに出さない
        # (取った枚数だけ分かるようにする。choice.reveal_to_opponent=Falseの既存の使い分けと同じ扱い)。
        state.add_log(f"player{choice.player_index} がサイドから{len(taken)}枚を選んで手札に加えた")
        state.pending_search_choice = None

        check_win_conditions(state)
        if state.is_game_over():
            return

        remaining_queue = mode_data.get("remaining_prize_queue", [])
        needs_new_active = mode_data.get("needs_new_active", [])
        stored_then_after_choice = mode_data.get("then_after_choice", "continue")
        stored_then_end_turn = mode_data.get("then_end_turn", False)
        if remaining_queue:
            _start_prize_choice(state, remaining_queue, needs_new_active, stored_then_after_choice, then_end_turn=stored_then_end_turn)
            return
        if needs_new_active:
            state.pending_active_choice = needs_new_active
            state.then_after_choice = stored_then_after_choice
            state.then_end_turn_after_active_choice = stored_then_end_turn
            return
        if stored_then_after_choice == "checkup":
            _run_checkup_and_advance(state, card_db)
        elif stored_then_after_choice == "advance":
            advance_turn(state, card_db)
        elif stored_then_after_choice == "attack_again":
            # ホルビーの「Ω Barrage」/カミッチュの「おまつりおんど」: サイド選択が終わったので、
            # もう一度ワザを使うか選べる状態にする(_finish_attack_or_offer_second参照)。
            state.player(state.current_player).pending_second_attack = True
        else:
            # "continue" は通常、現在のプレイヤーのメインフェーズを継続する合図だが、この保留自体が
            # ワザの効果(ダメカン配分等)の途中でのきぜつから発生していた場合はthen_end_turnが
            # 立っているはずで、その場合はここでターンを終了させる必要がある(そうしないと
            # ファントムダイブ等、ワザの後にダメカン配分の保留を経由してきぜつが起きるカードで
            # ターンが永遠に終わらなくなる)。
            _maybe_end_turn_after_pending_choice(state, card_db, then_end_turn)
        return
    if choice.zone == "own_prizes_swap_for_basic":
        # ヒスイヘビーボール: 選んだたねポケモンを手札に加え、ヘビーボール自身(使用後処理でトラッシュに置かれたもの)を
        # 代わりにサイドに裏向きで置く。その後、裏向きのサイドをシャッフルする(表向きのサイドは動かさない)。
        player = state.player(choice.player_index)
        state.pending_search_choice = None
        mode_data = choice.custom_data if isinstance(choice.custom_data, dict) else {}
        ball_id = mode_data.get("card_id")
        if not selected or ball_id not in player.discard:
            state.add_log(f"{choice.prompt}: (選ばなかった)")
            _maybe_end_turn_after_pending_choice(state, card_db, then_end_turn)
            return
        idx = choice.source_indices[selected[0]]
        found = player.prizes[idx]
        player.discard.remove(ball_id)
        player.prizes[idx] = ball_id
        if len(player.prize_marks) == len(player.prizes):
            player.prize_marks[idx] = 0  # 入れ替わったカードは裏向き
        player.hand.append(found)
        face_down = [i for i in range(len(player.prizes)) if player.prize_mark(i) != 2]
        shuffled = [player.prizes[i] for i in face_down]
        state.rng.shuffle(shuffled)
        for i, card in zip(face_down, shuffled):
            player.prizes[i] = card
            if len(player.prize_marks) == len(player.prizes):
                player.prize_marks[i] = 0  # 裏向きのサイドをシャッフルしたので、以前見た位置の記憶は無効
        name = card_db.get(found).name if card_db.get(found) else found
        state.add_log(f"サイドから{name}を手札に加え、代わりにヘビーボールをサイドに置いた")
        _maybe_end_turn_after_pending_choice(state, card_db, then_end_turn)
        return
    if choice.zone == "own_prizes_pokemon_to_hand":
        # アグノムの特性「Time Walk」1段階目: サイドから手札に加えるポケモンを選ぶ(選ばなくてもよい)。
        # 選んだ場合は続けて、新しくサイドにするカードを手札から選ばせる(2段階目、必須選択)。
        player = state.player(choice.player_index)
        if not selected:
            state.add_log(f"{choice.prompt}: (選ばなかった)")
            state.pending_search_choice = None
            _maybe_end_turn_after_pending_choice(state, card_db, then_end_turn)
            return
        pos = selected[0]
        idx = choice.source_indices[pos]
        taken = player.take_prize(idx)
        player.hand.append(taken)
        name = card_db.get(taken).name if card_db.get(taken) else taken
        state.add_log(f"{choice.prompt}: {name} を手札に加えた")
        state.pending_search_choice = PendingSearchChoice(
            player_index=choice.player_index,
            zone="hand",
            source_indices=list(range(len(player.hand))),
            card_ids=list(player.hand),
            min_count=1,
            max_count=1,
            prompt="タイムウォーク: 新しくサイドにするカードを手札から選ぶ",
            shuffle_after=False,
            all_card_ids=list(player.hand),
            destination="own_prize_facedown",
            reveal_to_opponent=False,
            then_end_turn=then_end_turn,
        )
        return
    if choice.zone == "opponent_hand_to_prizes":
        # デンジュモクGXの「Lighting-GX」: 相手の手札を公開させ、自分が選んだ1枚を相手のサイド
        # (裏向き)に加える。手札からの除去も相手のサイド追加も、選ぶのは自分(choice.player_index)側。
        opponent = state.player(1 - choice.player_index)
        removed_indices = sorted((choice.source_indices[pos] for pos in selected), reverse=True)
        moved: list[str] = []
        for idx in removed_indices:
            if 0 <= idx < len(opponent.hand):
                moved.append(opponent.hand.pop(idx))
        opponent.add_prizes(moved)
        names = [card_db.get(cid).name if card_db.get(cid) else cid for cid in moved]
        state.add_log(f"{choice.prompt}: {', '.join(names) if names else '(選ばなかった)'} を相手のサイドに加えた")
        state.pending_search_choice = None
        _maybe_end_turn_after_pending_choice(state, card_db, then_end_turn)
        return
    if choice.zone == "opponent_discard_to_their_prizes":
        # アーゴヨンGXの「Injection-GX」: 相手のトラッシュから自分が選んだ1枚を、相手のサイド(裏向き)に加える。
        opponent = state.player(1 - choice.player_index)
        removed_indices = sorted((choice.source_indices[pos] for pos in selected), reverse=True)
        moved: list[str] = []
        for idx in removed_indices:
            if 0 <= idx < len(opponent.discard):
                moved.append(opponent.discard.pop(idx))
        opponent.add_prizes(moved)
        names = [card_db.get(cid).name if card_db.get(cid) else cid for cid in moved]
        state.add_log(f"{choice.prompt}: {', '.join(names) if names else '(選ばなかった)'} を相手のサイドに加えた")
        state.pending_search_choice = None
        _maybe_end_turn_after_pending_choice(state, card_db, then_end_turn)
        return
    if choice.zone == "opponent_discard":
        opponent = state.player(1 - choice.player_index)
        removed_indices = sorted((choice.source_indices[pos] for pos in selected), reverse=True)
        moved: list[str] = []
        for idx in removed_indices:
            if 0 <= idx < len(opponent.discard):
                moved.append(opponent.discard.pop(idx))
        opponent.lost_zone.extend(moved)
        names = [card_db.get(cid).name if card_db.get(cid) else cid for cid in moved]
        state.add_log(f"{choice.prompt}: {', '.join(names) if names else '(選ばなかった)'}")
        state.pending_search_choice = None
        _resolve_incidental_knockouts(state, card_db, then_end_turn=then_end_turn)
        _maybe_end_turn_after_pending_choice(state, card_db, then_end_turn)
        return
    if choice.zone == "rare_candy_evolve_choice":
        # ふしぎなアメ: 手札に該当する2進化先が複数種類あるとき、どれに進化させるか選ぶ。
        # run_script側でcont_source_pokemonが(Itemカードのctx.source_pokemon=Noneで)上書きされて
        # しまうため、対象はcont_source_pokemonではなくtarget_bench_indexから引き直す。
        from effects.primitives import _evolve_own_basic_directly_from_hand

        mode_data = choice.custom_data if isinstance(choice.custom_data, dict) else {}
        target_bench_index = mode_data.get("target_bench_index")
        target = player.active if target_bench_index is None else (
            player.bench[target_bench_index] if 0 <= target_bench_index < len(player.bench) else None
        )
        state.pending_search_choice = None
        if target is not None and selected:
            card_id = choice.card_ids[selected[0]]
            cont_ctx = EffectContext(
                state=state, card_db=card_db, acting_player=choice.actor(),
                source_pokemon=target, source_card_id=card_id, rng=state.rng,
            )
            _evolve_own_basic_directly_from_hand(cont_ctx, target, card_id, target_bench_index)
        _resolve_incidental_knockouts(state, card_db, then_end_turn=then_end_turn)
        _maybe_end_turn_after_pending_choice(state, card_db, then_end_turn)
        return
    if choice.zone == "opponent_discard_to_their_bench":
        # こだまのつのぶえ(Echoing Horn)/ターゲットホイッスル(Target Whistle)等: 相手のトラッシュから
        # 選んだたねポケモンを相手のベンチに出す(選ぶのはカードを使った側=choice.player_index)。
        opponent = state.player(1 - choice.player_index)
        removed_indices = sorted((choice.source_indices[pos] for pos in selected), reverse=True)
        moved: list[str] = []
        for idx in removed_indices:
            if 0 <= idx < len(opponent.discard):
                moved.append(opponent.discard.pop(idx))
        for card_id in moved:
            opponent.bench.append(PokemonInPlay(card_id=card_id, turn_played=opponent.turns_taken))
        names = [card_db.get(cid).name if card_db.get(cid) else cid for cid in moved]
        state.add_log(f"{choice.prompt}: {', '.join(names) if names else '(選ばなかった)'} を相手のベンチに出した")
        state.pending_search_choice = None
        _resolve_incidental_knockouts(state, card_db, then_end_turn=then_end_turn)
        _maybe_end_turn_after_pending_choice(state, card_db, then_end_turn)
        return

    if choice.zone == "deck":
        zone_list = player.deck
    elif choice.zone == "hand":
        zone_list = player.hand
    else:
        zone_list = player.discard
    remaining_positions = [i for i in range(len(choice.card_ids)) if i not in selected]

    # zone内の位置は後ろから取り除かないと、手前の要素を消したときに残りのインデックスがずれる。
    # (選んだ分・選ばなかった分の両方を同時に取り除いてから、それぞれ手札/山札下に振り分ける)
    removals = sorted(
        [(pos, choice.source_indices[pos]) for pos in selected]
        + (
            [(pos, choice.source_indices[pos]) for pos in remaining_positions]
            if choice.remaining_to_bottom or choice.remaining_to_discard
            else []
        ),
        key=lambda pair: pair[1],
        reverse=True,
    )
    removed_by_position: dict[int, str] = {}
    for pos, src_idx in removals:
        removed_by_position[pos] = zone_list.pop(src_idx)

    picked_card_ids = [removed_by_position[pos] for pos in selected]
    evolved_via_deck_search: "PokemonInPlay | None" = None
    if choice.destination == "bench":
        for card_id in picked_card_ids:
            new_mon = PokemonInPlay(card_id=ITEM_AS_POKEMON.get(card_id, card_id), turn_played=player.turns_taken)  # 化石グッズはポケモンとして出る
            player.bench.append(new_mon)
            _apply_dangerous_ruins_damage(state, card_db, card_id, new_mon)
        verb = "ベンチに出した"
    elif choice.destination == "discard":
        player.discard.extend(picked_card_ids)
        verb = "トラッシュした"
    elif choice.destination == "deck":
        player.deck.extend(picked_card_ids)
        verb = "山札に戻した"
    elif choice.destination == "deck_top":
        # 暗号マニアの解読等: 残りの山札をシャッフルしてから、選んだカードをプレイヤーが選んだ順番
        # (=一番上に来る順)で戻す。selected(位置の昇順)ではなく、action.selected_indicesの
        # 元の並び(=プレイヤーが実際にクリックした順)を使う必要がある。
        ordered_positions = list(dict.fromkeys(action.selected_indices))
        picked_card_ids = [removed_by_position[pos] for pos in ordered_positions]
        state.rng.shuffle(player.deck)
        player.deck[0:0] = picked_card_ids
        verb = "シャッフルして山札の一番上に(選んだ順で)戻した"
    elif choice.destination == "deck_top_no_shuffle":
        # 夜のアカデミー(Academy at Night)等: 手札のカードを、山札をシャッフルせずそのまま一番上に置く。
        ordered_positions = list(dict.fromkeys(action.selected_indices))
        picked_card_ids = [removed_by_position[pos] for pos in ordered_positions]
        player.deck[0:0] = picked_card_ids
        verb = "山札の一番上に置いた"
    elif choice.destination == "deck_bottom":
        # カトレア(Caitlin)等: 手札のカードを、プレイヤーが選んだ順に山札の下に置く(シャッフルしない)。
        ordered_positions = list(dict.fromkeys(action.selected_indices))
        picked_card_ids = [removed_by_position[pos] for pos in ordered_positions]
        player.deck.extend(picked_card_ids)
        verb = "山札の下に置いた"
    elif choice.destination == "attach_energy":
        if choice.attach_target_pokemon is not None:
            choice.attach_target_pokemon.attached_energy.extend(picked_card_ids)
            if (
                picked_card_ids
                and isinstance(choice.custom_data, dict)
                and choice.custom_data.get("poison_if_attached_to_active")
                and choice.attach_target_pokemon is player.active
            ):
                # ジェニーの秘技: バトルポケモンにエネルギーをつけたら、そのポケモンはどくになる
                choice.attach_target_pokemon.status.poisoned = True
                state.add_log("バトルポケモンがどくになった")
        verb = "につけた"
    elif choice.destination == "lost_zone":
        player.lost_zone.extend(picked_card_ids)
        verb = "ロストゾーンに送った"
    elif choice.destination == "evolve_target":
        # わざマシン進化/グランドツリー: 進化先候補が複数あるとき選ばれた1枚で、対象を直接重ねて進化させる。
        from effects.primitives import _evolve_in_place_from_deck

        target = choice.attach_target_pokemon
        if target is not None and picked_card_ids:
            evolved_via_deck_search = _evolve_in_place_from_deck(player, target, picked_card_ids[0])
            extra_counters = (choice.custom_data or {}).get("counters_on_evolved", 0) if isinstance(choice.custom_data, dict) else 0
            if extra_counters and evolved_via_deck_search is not None:
                evolved_via_deck_search.damage += 10 * extra_counters  # Spiteful Evolution: 進化させたポケモンにダメカンをのせる
        verb = "に進化させた"
    elif choice.destination == "swap_hand_identity":
        # ギルガルドの「Stance Change」/メタモンの「Transform」: 手札のポケモンと入れ替わる/重なってそのポケモンになる
        from effects.era_special import resolve_swap_hand_identity

        verb = resolve_swap_hand_identity(
            player, choice.attach_target_pokemon, picked_card_ids, (choice.custom_data or {}).get("swap_kind", "stance")
        ) or "(何もしなかった)"
    elif choice.destination == "swap_identity":
        # ニンジャごっこ: 選んだ自分のたねポケモンを、山札から選んだ別のたねポケモンと入れ替える
        # (ついているカード・ダメカン・特殊状態等はtarget自身なのでそのまま引き継がれる)。
        target = choice.attach_target_pokemon
        if target is not None and picked_card_ids:
            old_id = target.card_id
            target.card_id = picked_card_ids[0]
            player.deck.append(old_id)
        verb = "と入れ替えた"
    elif choice.destination == "own_prize_facedown":
        # アグノムの特性「Time Walk」2段階目: 選んだ手札のカードを新しいサイド(裏向き)にする。
        player.add_prizes(picked_card_ids)
        verb = "サイドにした"
    elif choice.destination == "active_in_place":
        # メタモンの「Transformative Start」等: 自分自身をトラッシュし、選んだポケモンをそのままバトル場に出す。
        old_mon = choice.cont_source_pokemon
        if old_mon is not None and player.active is old_mon and picked_card_ids:
            player.discard.extend(old_mon.evolution_history)
            player.discard.append(old_mon.card_id)
            player.discard.extend(old_mon.attached_energy)
            if old_mon.attached_tool:
                player.discard.append(old_mon.attached_tool)
            player.active = PokemonInPlay(card_id=picked_card_ids[0], turn_played=player.turns_taken)
        verb = "と入れ替わった"
    else:
        player.hand.extend(picked_card_ids)
        verb = "手札に加えた"
        if choice.reveal_to_opponent and picked_card_ids:
            # ハイパーボール等、山札/トラッシュから「公開して」手札に加える検索効果は、相手に
            # 「このカードが少なくともこの枚数、手札にある」という部分的な手札情報を与える。
            # PlayerState.known_opponent_hand(元々は「手札を丸ごと公開する」効果専用だった)に
            # そのまま追加する形で相乗りさせる: エンコード側(_known_opponent_hand_counts)は
            # 実際の現在の手札構成でカードIDごとにクランプ済みの数だけを返すため、後でそのカードが
            # ベンチに出る/使われる等で手札から失われれば、追跡側で何も手を加えなくても自動的に
            # 反映される(2026-09-01、ユーザー提案の「軽い手札予測」機能。手札を丸ごと公開する
            # 効果と同じフィールド・同じ状態エンコード次元を再利用するため、学習中のネットワークの
            # 入力次元を一切変更せずに追加できる)。
            state.player(1 - choice.player_index).known_opponent_hand.extend(picked_card_ids)

    if choice.reveal_to_opponent:
        names = [card_db.get(cid).name if card_db.get(cid) else cid for cid in picked_card_ids]
        state.add_log(f"{choice.prompt}: {', '.join(names) if names else '(選ばなかった)'} を{verb}")
    else:
        # 実カードのテキストが公開("reveal")を指定していない私的な検索/山札閲覧効果
        # (ドロンチの「ていさつしれい」等)。何をした/何枚かは分かるが、具体的なカード名は伏せる。
        state.add_log(f"{choice.prompt}: {len(picked_card_ids)}枚を{verb}")

    if choice.remaining_to_bottom:
        zone_list.extend(removed_by_position[pos] for pos in remaining_positions)
    elif choice.remaining_to_discard:
        player.discard.extend(removed_by_position[pos] for pos in remaining_positions)

    if choice.shuffle_after:
        state.rng.shuffle(player.deck)
    state.pending_search_choice = None

    mode_data = choice.custom_data if isinstance(choice.custom_data, dict) else {}
    if mode_data.get("mode") == "discard_hand_energy_scaling_damage":
        # サーフゴーexの「Make It Rain」/ヒスイのジュナイパーVSTARの「Somersault Feathers」等:
        # 選んで捨てたエネルギーの枚数ぶんダメージを上乗せする。
        from effects.primitives import DealDamage

        base = mode_data.get("base", 0)
        damage_per = mode_data.get("damage_per", 0)
        cont_ctx = EffectContext(
            state=state,
            card_db=card_db,
            acting_player=choice.actor(),
            source_pokemon=choice.cont_source_pokemon,
            source_card_id=choice.cont_source_card_id,
            rng=state.rng,
        )
        DealDamage(base + damage_per * len(picked_card_ids)).execute(cont_ctx)
        _resolve_incidental_knockouts(state, card_db, then_end_turn=then_end_turn)
        _maybe_end_turn_after_pending_choice(state, card_db, then_end_turn)
        return
    if mode_data.get("mode") == "gen_continue":
        from effects.era_primitives_b import resolve_generic_continue

        result = resolve_generic_continue(state, card_db, choice, picked_card_ids)
        _run_remaining_after_generic(state, card_db, choice, result.last_attach_succeeded)
        _propagate_then_end_turn(state, then_end_turn)
        _resolve_incidental_knockouts(state, card_db, then_end_turn=then_end_turn)
        _maybe_end_turn_after_pending_choice(state, card_db, then_end_turn)
        return
    if mode_data.get("mode") == "attach_deck_energy_freely_continue":
        from effects.primitives import _attach_deck_energy_freely

        remaining = mode_data.get("remaining", 0)
        picked_types = frozenset(mode_data.get("picked_types", ()))
        if picked_card_ids:
            picked_card = card_db.get(picked_card_ids[0])
            if picked_card is not None:
                picked_types = picked_types | {picked_card.basic_energy_type}
        cont_ctx = EffectContext(
            state=state,
            card_db=card_db,
            acting_player=choice.actor(),
            source_pokemon=choice.cont_source_pokemon,
            source_card_id=choice.cont_source_card_id,
            rng=state.rng,
        )
        _attach_deck_energy_freely(
            cont_ctx, remaining, picked_types=picked_types, distinct_types=mode_data.get("distinct_types", False),
            bench_only=mode_data.get("bench_only", False), then_end_turn=mode_data.get("then_end_turn", False),
            energy_type=mode_data.get("energy_type"), optional=mode_data.get("optional", False),
            target_name_prefix=mode_data.get("target_name_prefix"),
        )
        _resolve_incidental_knockouts(state, card_db, then_end_turn=then_end_turn)
        _maybe_end_turn_after_pending_choice(state, card_db, then_end_turn)
        return
    if mode_data.get("mode") == "attach_discard_energy_freely_continue":
        from effects.primitives import _attach_discard_energy_freely

        remaining = mode_data.get("remaining", 0)
        if remaining > 0:
            cont_ctx = EffectContext(
                state=state,
                card_db=card_db,
                acting_player=choice.actor(),
                source_pokemon=choice.cont_source_pokemon,
                source_card_id=choice.cont_source_card_id,
                rng=state.rng,
            )
            _attach_discard_energy_freely(
                cont_ctx,
                remaining,
                energy_type=mode_data.get("energy_type"),
                then_end_turn=mode_data.get("then_end_turn", False),
                target_type=mode_data.get("target_type"),
                optional=mode_data.get("optional", False),
            )
        _resolve_incidental_knockouts(state, card_db, then_end_turn=then_end_turn)
        _maybe_end_turn_after_pending_choice(state, card_db, then_end_turn)
        return
    if mode_data.get("mode") == "attach_discard_energy_continue":
        from effects.primitives import _attach_discard_energy_to_each_target

        rest = mode_data.get("rest", ())
        if rest:
            cont_ctx = EffectContext(
                state=state,
                card_db=card_db,
                acting_player=choice.actor(),
                source_pokemon=choice.cont_source_pokemon,
                source_card_id=choice.cont_source_card_id,
                rng=state.rng,
            )
            _attach_discard_energy_to_each_target(cont_ctx, rest)
        _resolve_incidental_knockouts(state, card_db, then_end_turn=then_end_turn)
        _maybe_end_turn_after_pending_choice(state, card_db, then_end_turn)
        return
    if mode_data.get("mode") == "tech_machine_evolution_continue":
        from effects.primitives import InstantEvolveEachTargetFromDeck

        rest = mode_data.get("rest", ())
        if rest:
            cont_ctx = EffectContext(
                state=state,
                card_db=card_db,
                acting_player=choice.actor(),
                source_pokemon=choice.cont_source_pokemon,
                source_card_id=choice.cont_source_card_id,
                rng=state.rng,
            )
            InstantEvolveEachTargetFromDeck(rest, then_end_turn=mode_data.get("then_end_turn", False)).execute(cont_ctx)
        _resolve_incidental_knockouts(state, card_db, then_end_turn=then_end_turn)
        _maybe_end_turn_after_pending_choice(state, card_db, then_end_turn)
        return
    if mode_data.get("mode") == "grand_tree_chain_stage2_continue":
        # グランドツリー: stage1進化先を選ばせた直後、続けてstage2への連鎖進化を試みる。
        from effects.primitives import _grand_tree_chain_stage2

        if evolved_via_deck_search is not None:
            cont_ctx = EffectContext(
                state=state,
                card_db=card_db,
                acting_player=choice.actor(),
                source_pokemon=choice.cont_source_pokemon,
                source_card_id=choice.cont_source_card_id,
                rng=state.rng,
            )
            _grand_tree_chain_stage2(cont_ctx, evolved_via_deck_search)
            if state.pending_search_choice is None:
                state.rng.shuffle(player.deck)
        _resolve_incidental_knockouts(state, card_db, then_end_turn=then_end_turn)
        _maybe_end_turn_after_pending_choice(state, card_db, then_end_turn)
        return
    if mode_data.get("mode") == "hacking_opponent_discard_one":
        # ロケット団のポリゴンの「Hacking」: 実際に1枚捨てられたときだけ、相手も手札から1枚
        # 自分で選んで捨てる(実カードテキストに"random"の指定が無いため、捨てる本人=相手が選ぶ)。
        opponent_index = state.opponent_index(choice.player_index)
        opponent = state.player(opponent_index)
        if picked_card_ids and opponent.hand:
            state.pending_search_choice = PendingSearchChoice(
                player_index=opponent_index,
                zone="hand",
                source_indices=list(range(len(opponent.hand))),
                card_ids=list(opponent.hand),
                min_count=1,
                max_count=1,
                prompt="捨てるカードを1枚選ぶ",
                shuffle_after=False,
                all_card_ids=list(opponent.hand),
                destination="discard",
                then_end_turn=then_end_turn,
            )
            return
        _resolve_incidental_knockouts(state, card_db, then_end_turn=then_end_turn)
        _maybe_end_turn_after_pending_choice(state, card_db, then_end_turn)
        return
    if mode_data.get("mode") == "brocks_scouting_pick_first":
        # タケシのスカウト: 1枚目にたねポケモンを選んだ場合のみ、続けて2枚目(たねポケモン限定)を選べる。
        # 進化ポケモンを選んだ場合、または何も選ばなかった場合はここでシャッフルして終了。
        picked_card = card_db.get(picked_card_ids[0]) if picked_card_ids else None
        if picked_card is not None and picked_card.is_basic:
            eligible_indices = [
                i for i, cid in enumerate(player.deck)
                if (c := card_db.get(cid)) is not None and c.is_pokemon and c.is_basic
            ]
            if eligible_indices:
                state.pending_search_choice = PendingSearchChoice(
                    player_index=choice.player_index,
                    zone="deck",
                    source_indices=eligible_indices,
                    card_ids=[player.deck[i] for i in eligible_indices],
                    min_count=0,
                    max_count=1,
                    prompt="山札からもう1枚、たねポケモンを選ぶ(選ばなくてもよい)",
                    shuffle_after=True,
                    all_card_ids=list(player.deck),
                    destination="hand",
                    then_end_turn=then_end_turn,
                )
                return
        state.rng.shuffle(player.deck)
        _resolve_incidental_knockouts(state, card_db, then_end_turn=then_end_turn)
        _maybe_end_turn_after_pending_choice(state, card_db, then_end_turn)
        return
    if mode_data.get("mode") == "may_discard_then_draw":
        # シンジ&カトレア等: 実際に1枚捨てられたときだけ引く。
        if picked_card_ids:
            from effects.primitives import Draw

            draw_ctx = EffectContext(
                state=state,
                card_db=card_db,
                acting_player=choice.actor(),
                source_pokemon=choice.cont_source_pokemon,
                source_card_id=choice.cont_source_card_id,
                rng=state.rng,
            )
            Draw(mode_data.get("draw_count", 0)).execute(draw_ctx)
        _resolve_incidental_knockouts(state, card_db, then_end_turn=then_end_turn)
        _maybe_end_turn_after_pending_choice(state, card_db, then_end_turn)
        return
    if mode_data.get("mode") == "discard_then_draw_per_count":
        # ムク(Gwynn): 捨てたポケモンの枚数ぶん、それぞれdraw_per_count枚引く。
        if picked_card_ids:
            from effects.primitives import Draw

            draw_ctx = EffectContext(
                state=state,
                card_db=card_db,
                acting_player=choice.actor(),
                source_pokemon=choice.cont_source_pokemon,
                source_card_id=choice.cont_source_card_id,
                rng=state.rng,
            )
            Draw(mode_data.get("draw_per_count", 0) * len(picked_card_ids)).execute(draw_ctx)
        _resolve_incidental_knockouts(state, card_db, then_end_turn=then_end_turn)
        _maybe_end_turn_after_pending_choice(state, card_db, then_end_turn)
        return

    if mode_data.get("mode") == "trekking_shoes":
        # トレッキングシューズ: 手札に加えなかった場合、見た山札の一番上をそのままトラッシュして1枚引く。
        if not picked_card_ids and player.deck:
            top_id = player.deck.pop(0)
            player.discard.append(top_id)
            top_name = card_db.get(top_id).name if card_db.get(top_id) else top_id
            state.add_log(f"{top_name} をトラッシュした")
            from effects.primitives import Draw

            draw_ctx = EffectContext(
                state=state,
                card_db=card_db,
                acting_player=choice.actor(),
                source_pokemon=choice.cont_source_pokemon,
                source_card_id=choice.cont_source_card_id,
                rng=state.rng,
            )
            Draw(1).execute(draw_ctx)
        _resolve_incidental_knockouts(state, card_db, then_end_turn=then_end_turn)
        _maybe_end_turn_after_pending_choice(state, card_db, then_end_turn)
        return

    if mode_data.get("mode") == "superior_energy_retrieval":
        # スーパーエネルギー回収: このコストで今捨てた2枚(と同一card_idの、同じ枚数ぶんの出現)は、
        # 続く基本エネルギー回収の対象から除外する(同名カードが元々トラッシュにあった分は対象のまま)。
        excluded_counts: dict[str, int] = {}
        for cid in picked_card_ids:
            excluded_counts[cid] = excluded_counts.get(cid, 0) + 1
        energy_count = mode_data.get("energy_count", 0)
        eligible = []
        from engine.continuous import discard_to_hand_blocked

        if discard_to_hand_blocked(state, card_db, choice.player_index):
            energy_count = 0  # リククラゲの「Slime Mold Colony」: トラッシュから手札に加えられない
        for i, cid in enumerate(player.discard):
            c = card_db.get(cid)
            if c is None or not c.is_energy or c.is_special_energy:
                continue
            if excluded_counts.get(cid, 0) > 0:
                excluded_counts[cid] -= 1
                continue
            eligible.append(i)
        if eligible and energy_count > 0:
            chosen = eligible[:energy_count]
            chosen_ids = [player.discard[i] for i in chosen]
            for i in sorted(chosen, reverse=True):
                player.discard.pop(i)
            player.hand.extend(chosen_ids)
            names = [card_db.get(cid).name if card_db.get(cid) else cid for cid in chosen_ids]
            state.add_log(f"トラッシュから {', '.join(names)} を手札に加えた")
        _resolve_incidental_knockouts(state, card_db, then_end_turn=then_end_turn)
        _maybe_end_turn_after_pending_choice(state, card_db, then_end_turn)
        return

    if choice.remaining_script:
        ctx = EffectContext(
            state=state,
            card_db=card_db,
            acting_player=choice.actor(),
            source_pokemon=choice.cont_source_pokemon,
            source_card_id=choice.cont_source_card_id,
            target_bench_index=choice.cont_target_bench_index,
            rng=state.rng,
            last_picked_card_ids=tuple(picked_card_ids),
            effect_source=choice.effect_source,
        )
        run_script(choice.remaining_script, ctx)
        if state.pending_search_choice is not None:
            # 連鎖でさらに選択が発生した場合、ワザ由来のフラグを引き継ぐ(そうしないと連鎖の
            # 最後の選択が解決されてもターンが終わらなくなる)。
            state.pending_search_choice.then_end_turn = then_end_turn
    _resolve_incidental_knockouts(state, card_db, then_end_turn=then_end_turn)
    _maybe_end_turn_after_pending_choice(state, card_db, then_end_turn)


def _field_attachment_owner_and_mon(state: GameState, entry: tuple):
    """("tool"|"energy", side, slot[, energy_index])形式のsource_indicesエントリから
    (持ち主のPlayerState, 対象PokemonInPlay)を解決する。slot: "active" または ベンチindex。"""
    side = entry[1]
    slot = entry[2]
    side_player = state.players[side]
    mon = side_player.active if slot == "active" else (side_player.bench[slot] if 0 <= slot < len(side_player.bench) else None)
    return side_player, mon


def _deliver_field_attachment_card(choice, side_player: PlayerState, card_id: str) -> None:
    if choice.destination == "attach_energy" and choice.attach_target_pokemon is not None:
        choice.attach_target_pokemon.attached_energy.append(card_id)
    elif choice.destination == "lost_zone":
        side_player.lost_zone.append(card_id)
    elif choice.destination == "hand":
        side_player.hand.append(card_id)
    elif choice.destination == "deck":
        side_player.deck.append(card_id)
    elif choice.destination == "deck_top":
        side_player.deck.insert(0, card_id)
    else:
        side_player.discard.append(card_id)


def _resolve_field_attachment_choice(
    state: GameState, card_db: CardDatabase, choice, selected: list[int]
) -> None:
    """クセロシキ/フィールドブロアー/Burning Road等: 場のどうぐ/特殊エネルギー(+スタジアム)を選ぶ
    選択(zone="field_attachment")の解決。destination="attach_energy"ならattach_target_pokemonへ移動、
    それ以外(既定"discard")なら持ち主のトラッシュへ送る。同じポケモンのattached_energyから複数枚選ばれた
    場合、pop時のインデックスずれを避けるため、そのポケモンぶんはenergy_indexの降順にまとめて処理する。"""
    from effects.primitives import DealBonusDamageToChosenOpponentBench, DealDamage

    picked_card_ids: list[str] = []
    energy_positions_by_mon: dict[tuple, list[int]] = {}

    for pos in selected:
        entry = choice.source_indices[pos]
        kind = entry[0]
        if kind == "stadium":
            card_id = state.stadium_in_play
            if card_id is None:
                continue
            owner = state.player(state.stadium_owner) if state.stadium_owner is not None else state.player(choice.player_index)
            (owner.lost_zone if choice.destination == "lost_zone" else owner.discard).append(card_id)
            state.stadium_in_play = None
            state.stadium_owner = None
            state.stadium_orientation_target = None
            picked_card_ids.append(card_id)
        elif kind == "tool":
            side_player, mon = _field_attachment_owner_and_mon(state, entry)
            if mon is None or mon.attached_tool is None:
                continue
            card_id = mon.attached_tool
            mon.attached_tool = None
            mon.attached_tool_owner = None
            _deliver_field_attachment_card(choice, side_player, card_id)
            picked_card_ids.append(card_id)
        elif kind == "energy":
            energy_positions_by_mon.setdefault((entry[1], entry[2]), []).append(pos)

    for (side, slot), positions in energy_positions_by_mon.items():
        side_player = state.players[side]
        mon = side_player.active if slot == "active" else (side_player.bench[slot] if 0 <= slot < len(side_player.bench) else None)
        if mon is None:
            continue
        for pos in sorted(positions, key=lambda p: choice.source_indices[p][3], reverse=True):
            energy_index = choice.source_indices[pos][3]
            if 0 <= energy_index < len(mon.attached_energy):
                card_id = mon.attached_energy.pop(energy_index)
                _deliver_field_attachment_card(choice, side_player, card_id)
                picked_card_ids.append(card_id)

    names = [card_db.get(cid).name if card_db.get(cid) else cid for cid in picked_card_ids]
    state.add_log(f"{choice.prompt}: {', '.join(names) if names else '(選ばなかった)'}")
    state.pending_search_choice = None

    if choice.destination == "deck" and choice.shuffle_after and picked_card_ids:
        state.rng.shuffle(state.player(choice.player_index).deck)

    mode_data = choice.custom_data if isinstance(choice.custom_data, dict) else {}
    if (
        mode_data.get("mode") == "shuffle_self_energy_bonus_bench_damage"
        and picked_card_ids
        and mode_data.get("bonus_amount")
    ):
        # オーガポン いどのめんex(Wellspring Mask Ogerpon ex)の「Torrential Pump」: 実際に山札へ
        # 戻したエネルギーがあれば(=「してもよい」を実行したなら)、攻撃時に選んだベンチポケモンへ
        # 追加ダメージ。target_bench_indexはワザ実行時点でのAttackアクションの指定をcustom_data経由で
        # そのまま引き継ぐ(このエネルギー選択自体は攻撃対象の選択とは独立した後続の選択のため)。
        ctx = EffectContext(
            state=state,
            card_db=card_db,
            acting_player=choice.actor(),
            source_pokemon=choice.cont_source_pokemon,
            source_card_id=choice.cont_source_card_id,
            target_bench_index=mode_data.get("target_bench_index"),
            rng=state.rng,
        )
        DealBonusDamageToChosenOpponentBench(mode_data["bonus_amount"]).execute(ctx)

    if mode_data.get("mode") == "bellowing_thunder" and (
        (picked_card_ids and mode_data.get("damage_per")) or mode_data.get("base", 0) > 0
    ):
        # タケルライコexの「Bellowing Thunder」/ズガドーンGXの「Mind Blown」: 移動させた基本エネルギーの
        # 枚数ぶんダメージ(damage_per=0のギラティナVSTARの「Lost Impact」等はダメージ計算をスキップする)。
        ctx = EffectContext(
            state=state,
            card_db=card_db,
            acting_player=choice.actor(),
            source_pokemon=choice.cont_source_pokemon,
            source_card_id=choice.cont_source_card_id,
            rng=state.rng,
        )
        DealDamage(mode_data.get("base", 0) + mode_data["damage_per"] * len(picked_card_ids)).execute(ctx)

    if mode_data.get("mode") == "move_energy_then_switch_active" and picked_card_ids:
        # カプ・コケコGXの特性「Aero Trail」: エネルギーを1枚でも移したら、このポケモンをバトル場と入れ替える。
        player = state.player(choice.player_index)
        target = choice.attach_target_pokemon
        if target is not None and target in player.bench and player.active is not None:
            bench_index = player.bench.index(target)
            new_active = player.bench.pop(bench_index)
            old_active = player.active
            old_active.status.clear_all()
            player.bench.append(old_active)
            new_active.status.clear_all()
            new_active.became_active_turn = player.turns_taken
            player.active = new_active
            state.add_log(f"player{choice.player_index} が {card_name(card_db, new_active.card_id)} とバトル場を入れ替えた")

    if choice.remaining_script:
        cont_ctx = EffectContext(
            state=state,
            card_db=card_db,
            acting_player=choice.actor(),
            source_pokemon=choice.cont_source_pokemon,
            source_card_id=choice.cont_source_card_id,
            target_bench_index=choice.cont_target_bench_index,
            rng=state.rng,
            last_picked_card_ids=tuple(picked_card_ids),
            effect_source=choice.effect_source,
        )
        run_script(choice.remaining_script, cont_ctx)
        if state.pending_search_choice is not None:
            state.pending_search_choice.then_end_turn = choice.then_end_turn

    # then_end_turnを明示的に渡さないと既定Falseになり、ここでのダメージ(bellowing_thunder等)が
    # きぜつを引き起こした場合、サイド選択→新アクティブ選択の解決後にターンが終わらなくなる不具合が
    # あった(ロケット団のミュウツーexの「Erasure Ball」でエネルギーをトラッシュしたときの追加
    # ダメージできぜつさせると、ターンが無限に続いて勝ってしまうバグとして発覚、2026-08-27)。
    _resolve_incidental_knockouts(state, card_db, then_end_turn=choice.then_end_turn)


def _resolve_move_counters_between_opponent_pokemon(
    state: GameState, card_db: CardDatabase, choice, selected: list[int], mode_data: dict
) -> None:
    """アブソルの「Cursed Eyes」: 相手のポケモン1匹(移動元)→別の相手のポケモン(移動先)の順に選び、ダメカンを移す。"""
    from effects.primitives import (
        _BATTLE_COLOSSEUM_STADIUM_ID,
        _blocks_damage_counters,
        _defender_blocks_attack_and_ability_non_damage_effects,
        _defender_is_shielded,
        _opponent_pokemon_slots,
    )
    from engine.continuous import tools_disabled

    opponent = state.player(1 - choice.player_index)
    slots = dict(_opponent_pokemon_slots(opponent))
    state.pending_search_choice = None
    if not selected:
        return
    picked_slot = choice.source_indices[selected[0]]
    picked = slots.get(picked_slot)
    if picked is None:
        return
    count = mode_data.get("count", 0)
    if mode_data["mode"] == "move_counters_pick_source":
        destinations = [(slot, mon) for slot, mon in slots.items() if slot != picked_slot]
        if not destinations:
            return
        state.pending_search_choice = PendingSearchChoice(
            player_index=choice.player_index,
            zone="opponent_pokemon_target",
            source_indices=[slot for slot, _ in destinations],
            card_ids=[mon.card_id for _, mon in destinations],
            min_count=1,
            max_count=1,
            prompt="ダメカンを移す先の相手のポケモンを選ぶ",
            shuffle_after=False,
            all_card_ids=[mon.card_id for _, mon in destinations],
            cont_source_pokemon=choice.cont_source_pokemon,
            cont_source_card_id=choice.cont_source_card_id,
            effect_source=choice.effect_source,
            custom_data={"mode": "move_counters_pick_dest", "count": count, "source_slot": picked_slot},
        )
        return
    source_mon = slots.get(mode_data.get("source_slot"))
    if source_mon is None or source_mon is picked:
        return
    move_amount = min(source_mon.damage, count * 10)
    if move_amount <= 0:
        return
    source_mon.remove_counters(move_amount)
    block_ctx = EffectContext(
        state=state, card_db=card_db, acting_player=choice.actor(),
        source_pokemon=choice.cont_source_pokemon, source_card_id=choice.cont_source_card_id, rng=state.rng,
        effect_source=choice.effect_source,
    )
    # 公式Q&A(ムンキドリの「Adrena-Brain」と同じ扱い): 移動先にのせられなくても、移動元からの除去は起きる
    blocked = (
        _defender_is_shielded(block_ctx, picked)
        or _defender_blocks_attack_and_ability_non_damage_effects(block_ctx, picked)
        or (not tools_disabled(state.stadium_in_play) and _blocks_damage_counters(picked))
        or (state.stadium_in_play == _BATTLE_COLOSSEUM_STADIUM_ID and picked is not opponent.active)
    )
    if not blocked:
        picked.damage += move_amount
        state.add_log(f"相手のポケモンのダメカンを{move_amount // 10}個、別の相手のポケモンに移した")
    else:
        state.add_log(f"移動先にダメカンをのせられないため、{move_amount // 10}個を取り除いた")
    _resolve_incidental_knockouts(state, card_db, then_end_turn=choice.then_end_turn)


def _resolve_opponent_pokemon_target_choice(
    state: GameState, card_db: CardDatabase, choice, selected: list[int]
) -> None:
    """複数の相手ポケモンに同じ量のダメージを与える選択(zone="opponent_pokemon_target")の解決
    (ラディアントゲッコウガの「Moonlight Shuriken」等)。ベンチ対象は弱点・抵抗力を計算しない。"""
    from effects.primitives import _defender_is_shielded, resolve_attack_damage

    opponent = state.player(1 - choice.player_index)
    mode_data = choice.custom_data if isinstance(choice.custom_data, dict) else {}
    if mode_data.get("mode") in ("move_counters_pick_source", "move_counters_pick_dest"):
        _resolve_move_counters_between_opponent_pokemon(state, card_db, choice, selected, mode_data)
        return
    amount = mode_data.get("amount", 0)
    attacker_card = card_db.get(choice.cont_source_card_id) if choice.cont_source_card_id else None
    state.pending_search_choice = None

    ctx = EffectContext(
        state=state,
        card_db=card_db,
        acting_player=choice.actor(),
        source_pokemon=choice.cont_source_pokemon,
        source_card_id=choice.cont_source_card_id,
        rng=state.rng,
    )
    damage_dealt = 0
    for pos in selected:
        slot = choice.source_indices[pos]
        target = opponent.active if slot == 0 else (opponent.bench[slot - 1] if 0 <= slot - 1 < len(opponent.bench) else None)
        if target is None or _defender_is_shielded(ctx, target):
            continue
        defender_card = card_db.get(target.card_id)
        if defender_card is None:
            continue
        apply_wr = (slot == 0 or bool(mode_data.get("wr_bench"))) and attacker_card is not None
        scale = mode_data.get("scale", "")
        each = amount
        if scale == "energy":
            each = amount * len(target.attached_energy)  # 対象についているエネルギー1枚につき
        elif scale == "retreat_colorless":
            each = amount * sum(1 for t in defender_card.retreat_cost if t == "Colorless")  # 対象のにげるコストの無色1個につき
        if each <= 0:
            continue
        dmg = resolve_attack_damage(ctx, target, defender_card, each, apply_weakness=apply_wr, apply_resistance=apply_wr)
        target.damage += dmg
        damage_dealt += dmg
    state.add_log(f"{choice.prompt}: {damage_dealt}ダメージの合計を与えた")
    # then_end_turnを明示的に渡さないと既定Falseになり、ここでのダメージがきぜつを引き起こした場合
    # (ヤドキングの「ひらめきチャレンジ」でトライフロストを借りて相手を複数体きぜつさせた等)、
    # サイド選択の解決後にターンが終わらなくなる不具合があった。
    _resolve_incidental_knockouts(state, card_db, then_end_turn=choice.then_end_turn)


def _resolve_retreat_energy_discard_choice(
    state: GameState, card_db: CardDatabase, choice, selected: list[int]
) -> None:
    """にげるコストとして手放すエネルギーの選択(zone="retreat_energy_discard")を解決する。"""
    player = state.player(choice.player_index)
    mode_data = choice.custom_data if isinstance(choice.custom_data, dict) else {}
    bench_slot = mode_data.get("bench_slot")
    state.pending_search_choice = None
    if bench_slot is None or not (0 <= bench_slot < len(player.bench)):
        return
    mon = player.bench[bench_slot]
    energy_indices = sorted((choice.source_indices[pos] for pos in selected), reverse=True)
    discarded = []
    for idx in energy_indices:
        if 0 <= idx < len(mon.attached_energy):
            discarded.append(mon.attached_energy.pop(idx))
    from effects.era_tools_j import retreat_discards_to_hand

    for cid in discarded:
        (player.hand if retreat_discards_to_hand(state, card_db, mon.attached_tool, cid) else player.discard).append(cid)
    names = [card_db.get(cid).name if card_db.get(cid) else cid for cid in discarded]
    state.add_log(f"{choice.prompt}: {', '.join(names)} をトラッシュした")
    _resolve_incidental_knockouts(state, card_db)


def _own_pokemon_at_slot(player: PlayerState, slot: int):
    """own_pokemon_target系zoneのスロット番号(0=バトル場、1..=ベンチ+1)からPokemonInPlayを引く。"""
    if slot == 0:
        return player.active
    bi = slot - 1
    return player.bench[bi] if 0 <= bi < len(player.bench) else None


def _trigger_own_pokemon_move_source_choice(
    state: GameState, player_index: int, then_end_turn: bool = False
) -> None:
    """ミュウEXの「Replace」/Forretressの「Iron Shake-Up」: 移動元にする自分のポケモンを選ぶ
    (選ばなければ終了)。then_end_turnはワザ(Iron Shake-Up)経由かどうかを、次の移動元選択にも
    伝播させるためのフラグ(ミュウEXの特性経由ならFalseのまま)。"""
    player = state.player(player_index)
    candidates = []
    if player.active is not None and player.active.attached_energy:
        candidates.append((0, player.active))
    for i, mon in enumerate(player.bench):
        if mon.attached_energy:
            candidates.append((i + 1, mon))
    if not candidates:
        return
    state.pending_search_choice = PendingSearchChoice(
        player_index=player_index,
        zone="own_pokemon_target",
        source_indices=[slot for slot, _ in candidates],
        card_ids=[mon.card_id for _, mon in candidates],
        min_count=0,
        max_count=1,
        prompt="エネルギーを移動する元のポケモンを選ぶ(選ばなければ終了)",
        shuffle_after=False,
        all_card_ids=[mon.card_id for _, mon in candidates],
        then_end_turn=then_end_turn,
        custom_data={"mode": "replace_pick_source", "then_end_turn": then_end_turn},
    )


def _resolve_own_pokemon_target_choice(
    state: GameState, card_db: CardDatabase, choice, selected: list[int]
) -> None:
    """ゼルネアスの「Geomancy」(mode="geomancy")とミュウEXの「Replace」の移動元/移動先選択
    (mode="replace_pick_source"/"replace_pick_dest")、いずれも zone="own_pokemon_target" を解決する。"""
    from effects.primitives import AttachDiscardEnergyToEachAncientTargetThenDraw, SearchEnergyAttachToEachTarget

    player = state.player(choice.player_index)
    slots = [choice.source_indices[pos] for pos in selected]
    mode_data = choice.custom_data if isinstance(choice.custom_data, dict) else {}
    mode = mode_data.get("mode")
    state.pending_search_choice = None

    if mode == "grand_tree_pick_source":
        from effects.primitives import _grand_tree_evolve_step1

        target = _own_pokemon_at_slot(player, slots[0]) if slots else None
        if target is not None:
            state.add_log(f"{choice.prompt}: {target.card_id} を選んだ")
            ctx = EffectContext(
                state=state,
                card_db=card_db,
                acting_player=choice.actor(),
                source_pokemon=target,
                source_card_id=target.card_id,
                rng=state.rng,
            )
            _grand_tree_evolve_step1(ctx, target)
        _resolve_incidental_knockouts(state, card_db)
        return

    if mode == "adrena_brain_pick_source":
        from effects.primitives import _trigger_move_damage_counters_amount_choice

        source = _own_pokemon_at_slot(player, slots[0]) if slots else None
        target = choice.attach_target_pokemon
        if source is not None and target is not None:
            ctx = EffectContext(
                state=state,
                card_db=card_db,
                acting_player=choice.actor(),
                source_pokemon=source,
                source_card_id=source.card_id,
                rng=state.rng,
            )
            _trigger_move_damage_counters_amount_choice(ctx, source, target, mode_data.get("max_count", 3))
        _resolve_incidental_knockouts(state, card_db)
        return

    if mode == "attach_discard_energy_to_chosen_targets":
        from effects.primitives import _attach_discard_energy_to_each_target

        targets = tuple(m for s in slots if (m := _own_pokemon_at_slot(player, s)) is not None)
        state.add_log(f"{choice.prompt}: {len(targets)}体を選んだ")
        if targets:
            ctx = EffectContext(
                state=state,
                card_db=card_db,
                acting_player=choice.actor(),
                source_pokemon=choice.cont_source_pokemon,
                source_card_id=choice.cont_source_card_id,
                rng=state.rng,
            )
            _attach_discard_energy_to_each_target(ctx, targets)
        _resolve_incidental_knockouts(state, card_db)
        return

    if mode == "heal_chosen_bench":
        # タプ・レレGXの「Tapu Cure-GX」はワザなので、この選択解決後にたまたま保留きぜつ処理で
        # サイド選択/新アクティブ選択が発生した場合、ターンを終了させる必要がある
        # (prime_catcher_own_switch/giovanni_opponent_switchと同じ理由、2026-09-11の修正を横展開)。
        chain_then_end_turn = mode_data.get("then_end_turn", False)
        targets = tuple(m for s in slots if (m := _own_pokemon_at_slot(player, s)) is not None)
        state.add_log(f"{choice.prompt}: {len(targets)}体を選んだ")
        for mon in targets:
            mon.damage = 0
        _resolve_incidental_knockouts(state, card_db, then_end_turn=chain_then_end_turn)
        return

    if mode == "tech_machine_evolution":
        # わざマシン エヴォリューションのようなどうぐ由来のワザ(UseBorrowedAttack)経由でもここに
        # 辿り着くため、下のprime_catcher_own_switch等と同じ理由でthen_end_turnを伝播させる。
        from effects.primitives import InstantEvolveEachTargetFromDeck

        chain_then_end_turn = mode_data.get("then_end_turn", False)
        targets = tuple(m for s in slots if (m := _own_pokemon_at_slot(player, s)) is not None)
        state.add_log(f"{choice.prompt}: {len(targets)}体を選んだ")
        if targets:
            ctx = EffectContext(
                state=state,
                card_db=card_db,
                acting_player=choice.actor(),
                source_pokemon=choice.cont_source_pokemon,
                source_card_id=choice.cont_source_card_id,
                rng=state.rng,
            )
            run_script((InstantEvolveEachTargetFromDeck(targets, then_end_turn=choice.then_end_turn),), ctx)
        _resolve_incidental_knockouts(state, card_db, then_end_turn=chain_then_end_turn)
        return

    if mode == "sada_vitality":
        targets = tuple(m for s in slots if (m := _own_pokemon_at_slot(player, s)) is not None)
        state.add_log(f"{choice.prompt}: {len(targets)}体を選んだ")
        if targets:
            initial_counts = tuple(len(m.attached_energy) for m in targets)
            ctx = EffectContext(
                state=state,
                card_db=card_db,
                acting_player=choice.actor(),
                source_pokemon=choice.cont_source_pokemon,
                source_card_id=choice.cont_source_card_id,
                rng=state.rng,
            )
            run_script((AttachDiscardEnergyToEachAncientTargetThenDraw(targets, targets, initial_counts),), ctx)
        _resolve_incidental_knockouts(state, card_db)
        return

    if mode == "geomancy":
        # ゼルネアスの「Geomancy」はワザ(トレーナーズのJanine's Secret Artからも同モードに来るが
        # そちらはthen_end_turnが元々False)なので、下のprime_catcher_own_switch等と同じ理由で
        # ここもthen_end_turnを伝播させる。
        chain_then_end_turn = mode_data.get("then_end_turn", False)
        targets = tuple(m for s in slots if (m := _own_pokemon_at_slot(player, s)) is not None)
        state.add_log(f"{choice.prompt}: {len(targets)}体を選んだ")
        if targets:
            ctx = EffectContext(
                state=state,
                card_db=card_db,
                acting_player=choice.actor(),
                source_pokemon=choice.cont_source_pokemon,
                source_card_id=choice.cont_source_card_id,
                rng=state.rng,
            )
            run_script(
                (
                    SearchEnergyAttachToEachTarget(
                        targets, mode_data.get("energy_type", ""), mode_data.get("poison_active", False),
                        mode_data.get("energy_card_name", ""),
                    ),
                ),
                ctx,
            )
        _resolve_incidental_knockouts(state, card_db, then_end_turn=chain_then_end_turn)
        return

    if mode == "replace_pick_source":
        # Forretressの「Iron Shake-Up」(ワザ)からもここに来る(ミュウEXの「Replace」は特性)ため、
        # 下のprime_catcher_own_switch等と同じ理由でthen_end_turnを最後まで伝播させる必要がある。
        chain_then_end_turn = mode_data.get("then_end_turn", False)
        if not slots:
            state.add_log(f"{choice.prompt}: (これ以上移動しない)")
            _resolve_incidental_knockouts(state, card_db, then_end_turn=chain_then_end_turn)
            return
        source_slot = slots[0]
        source_mon = _own_pokemon_at_slot(player, source_slot)
        if source_mon is None or not source_mon.attached_energy:
            _resolve_incidental_knockouts(state, card_db, then_end_turn=chain_then_end_turn)
            return
        state.pending_search_choice = PendingSearchChoice(
            player_index=choice.player_index,
            zone="own_pokemon_energy_target",
            source_indices=list(range(len(source_mon.attached_energy))),
            card_ids=list(source_mon.attached_energy),
            min_count=1,
            max_count=1,
            prompt="移動するエネルギーを選ぶ",
            shuffle_after=False,
            all_card_ids=list(source_mon.attached_energy),
            then_end_turn=chain_then_end_turn,
            custom_data={"source_slot": source_slot, "then_end_turn": chain_then_end_turn},
        )
        return

    if mode == "energy_switch_pick_source":
        if not slots:
            _resolve_incidental_knockouts(state, card_db)
            return
        source_slot = slots[0]
        source_mon = _own_pokemon_at_slot(player, source_slot)
        if source_mon is None:
            _resolve_incidental_knockouts(state, card_db)
            return
        move_energy_type = mode_data.get("energy_type")
        basic_energy_indices = [
            i for i, e in enumerate(source_mon.attached_energy)
            if (c := card_db.get(e)) is not None
            and c.is_energy
            and not c.is_special_energy
            and (move_energy_type is None or c.basic_energy_type == move_energy_type)
        ]
        if not basic_energy_indices:
            _resolve_incidental_knockouts(state, card_db)
            return
        state.pending_search_choice = PendingSearchChoice(
            player_index=choice.player_index,
            zone="own_pokemon_energy_target",
            source_indices=basic_energy_indices,
            card_ids=[source_mon.attached_energy[i] for i in basic_energy_indices],
            min_count=1,
            max_count=1,
            prompt="移動する基本エネルギーを選ぶ",
            shuffle_after=False,
            all_card_ids=[source_mon.attached_energy[i] for i in basic_energy_indices],
            custom_data={"source_slot": source_slot, "next_mode": "energy_switch_pick_dest"},
        )
        return

    if mode == "escape_rope_opponent_first":
        # エスケープロープ: 相手(choice.player_index)が自分のベンチから出すポケモンを選んで入れ替えた後、
        # 続けて自分(acting_player)が入れ替える先を選ぶ。
        bi = slots[0] - 1 if slots else -1
        if 0 <= bi < len(player.bench):
            new_active = player.bench.pop(bi)
            old_active = player.active
            if old_active is not None:
                old_active.status.clear_all()
                player.bench.append(old_active)
            new_active.status.clear_all()
            player.active = new_active
            state.add_log(f"player{choice.player_index} が自分のバトルポケモンを入れ替えた")
        acting = mode_data.get("acting_player", state.current_player)
        acting_player = state.player(acting)
        if acting_player.bench:
            state.pending_search_choice = PendingSearchChoice(
                player_index=acting,
                zone="own_pokemon_target",
                source_indices=[i + 1 for i in range(len(acting_player.bench))],
                card_ids=[mon.card_id for mon in acting_player.bench],
                min_count=1,
                max_count=1,
                prompt="入れ替える自分のベンチポケモンを選ぶ",
                shuffle_after=False,
                all_card_ids=[mon.card_id for mon in acting_player.bench],
                custom_data={"mode": "prime_catcher_own_switch"},
            )
        _resolve_incidental_knockouts(state, card_db)
        return

    if mode == "prime_catcher_own_switch":
        # メタグロスの「Bounce Back」等、ワザ由来でこの選択に辿り着いた場合はthen_end_turnが
        # custom_data経由で伝わっているはず(_handle_attack/revealed_card_attack_choice参照)。
        # ここで読み落とすと、入れ替え中にきぜつが起きてサイド選択が発生した場合に「ワザ後」の
        # 情報が失われ、選択解決後もターンが終わらなくなる(2026-09-11ユーザー報告の実バグ、
        # ヤドキングの「ひらめきチャレンジ」で借りたBounce Backが原因できぜつが起き、その後
        # ターンが終わらず再度ワザが使えてしまっていた)。
        chain_then_end_turn = mode_data.get("then_end_turn", False)
        if not slots:
            _resolve_incidental_knockouts(state, card_db, then_end_turn=chain_then_end_turn)
            return
        bi = slots[0] - 1
        if not (0 <= bi < len(player.bench)):
            _resolve_incidental_knockouts(state, card_db, then_end_turn=chain_then_end_turn)
            return
        new_active = player.bench.pop(bi)
        old_active = player.active
        if old_active is not None:
            old_active.status.clear_all()
            player.bench.append(old_active)
        new_active.status.clear_all()
        player.active = new_active
        state.add_log(f"player{choice.player_index} が自分のバトルポケモンを入れ替えた")
        _resolve_incidental_knockouts(state, card_db, then_end_turn=chain_then_end_turn)
        return

    if mode == "giovanni_opponent_switch":
        # ロケット団のサカキ(Team Rocket's Giovanni): 自分の入れ替え後、続けて相手のバトルポケモンを
        # 選んだ相手のベンチポケモンと強制的に入れ替える。上のprime_catcher_own_switchと同じ理由で
        # then_end_turnを伝播させる。
        opponent = state.player(state.opponent_index(choice.player_index))
        chain_then_end_turn = mode_data.get("then_end_turn", False)
        if not slots:
            _resolve_incidental_knockouts(state, card_db, then_end_turn=chain_then_end_turn)
            return
        bi = slots[0] - 1
        if not (0 <= bi < len(opponent.bench)):
            _resolve_incidental_knockouts(state, card_db, then_end_turn=chain_then_end_turn)
            return
        new_active = opponent.bench.pop(bi)
        old_active = opponent.active
        if old_active is not None:
            old_active.status.clear_all()
            opponent.bench.append(old_active)
        new_active.status.clear_all()
        opponent.active = new_active
        state.add_log(f"player{choice.player_index} が相手のバトルポケモンを強制的に入れ替えた")
        _resolve_incidental_knockouts(state, card_db, then_end_turn=chain_then_end_turn)
        return

    if mode == "mirage_gate":
        from effects.primitives import SearchDeckDistinctBasicEnergyAttachToEachTarget

        targets = tuple(m for s in slots if (m := _own_pokemon_at_slot(player, s)) is not None)
        state.add_log(f"{choice.prompt}: {len(targets)}体を選んだ")
        if targets:
            ctx = EffectContext(
                state=state,
                card_db=card_db,
                acting_player=choice.actor(),
                source_pokemon=choice.cont_source_pokemon,
                source_card_id=choice.cont_source_card_id,
                rng=state.rng,
            )
            run_script((SearchDeckDistinctBasicEnergyAttachToEachTarget(targets),), ctx)
        _resolve_incidental_knockouts(state, card_db)
        return

    if mode == "crispin_attach":
        from effects.primitives import _trigger_search_choice

        target = _own_pokemon_at_slot(player, slots[0]) if slots else None
        if target is None:
            _resolve_incidental_knockouts(state, card_db)
            return
        exclude_type = mode_data.get("exclude_type")

        def _matches_different_basic_energy(card):
            return (
                card is not None
                and card.is_energy
                and not card.is_special_energy
                and (exclude_type is None or card.basic_energy_type != exclude_type)
            )

        ctx = EffectContext(
            state=state,
            card_db=card_db,
            acting_player=choice.actor(),
            source_pokemon=choice.cont_source_pokemon,
            source_card_id=choice.cont_source_card_id,
            rng=state.rng,
        )
        _trigger_search_choice(
            ctx, player, "deck", _matches_different_basic_energy, 1,
            "つける基本エネルギーを探す(手札に加えた方と異なるタイプ)", shuffle_after=True, destination="attach_energy",
        )
        if ctx.state.pending_search_choice is not None:
            ctx.state.pending_search_choice.attach_target_pokemon = target
        _resolve_incidental_knockouts(state, card_db)
        return

    if mode == "attach_found_energy_pick_target":
        # マックスげんき/でんきはっせいき等: 山札の上から見つけて既に手元にある基本エネルギー1枚を
        # 選んだ対象につける。続けて残りのカードについても対象を選ばせる。
        from effects.primitives import _attach_found_energies_freely

        card_id = mode_data.get("card_id")
        rest = tuple(mode_data.get("rest", ()))
        chain_then_end_turn = mode_data.get("then_end_turn", False)
        target = _own_pokemon_at_slot(player, slots[0]) if slots else None
        if target is not None and card_id is not None:
            target.attached_energy.append(card_id)
            state.add_log(f"player{choice.player_index} が{card_name(card_db, card_id)}を{card_name(card_db, target.card_id)}につけた")
        cont_ctx = EffectContext(
            state=state, card_db=card_db, acting_player=choice.actor(),
            source_pokemon=choice.cont_source_pokemon, source_card_id=choice.cont_source_card_id, rng=state.rng,
        )
        _attach_found_energies_freely(
            cont_ctx, rest, bench_only=mode_data.get("bench_only", False),
            target_pokemon_type=mode_data.get("target_pokemon_type"),
            basic_stage_only=mode_data.get("basic_stage_only", True), then_end_turn=chain_then_end_turn,
        )
        _resolve_incidental_knockouts(state, card_db)
        return

    if mode == "attach_deck_energy_freely_pick_target":
        # ビクティニの「Victory Sign」/わざマシン エナジーターボ等: 山札の基本エネルギーを1枚ずつ、
        # 対象を選び直しながら自由につけていく。対象を確定したら、続けてどの基本エネルギーをつけるか
        # 選ばせる(候補が1種類しかなければ選択なしでそのまま自動的につける)。
        from effects.primitives import _attach_deck_energy_freely

        remaining = mode_data.get("remaining", 0)
        picked_types = frozenset(mode_data.get("picked_types", ()))
        distinct_types = mode_data.get("distinct_types", False)
        bench_only = mode_data.get("bench_only", False)
        chain_then_end_turn = mode_data.get("then_end_turn", False)
        energy_type_filter = mode_data.get("energy_type")
        optional = mode_data.get("optional", False)
        target_name_prefix = mode_data.get("target_name_prefix")
        if optional and not slots:
            # 「Nまで」の任意枚数: これ以上つけないことを選んだ(0枚選択で打ち切り)。
            state.add_log(f"{choice.prompt}: (これ以上つけない)")
            state.rng.shuffle(player.deck)
            _resolve_incidental_knockouts(state, card_db)
            return
        target = _own_pokemon_at_slot(player, slots[0]) if slots else None
        if target is None:
            state.rng.shuffle(player.deck)
            _resolve_incidental_knockouts(state, card_db)
            return

        def deck_matches(card):
            return (
                card is not None
                and card.is_energy
                and not card.is_special_energy
                and (energy_type_filter is None or card.basic_energy_type == energy_type_filter)
                and (not distinct_types or card.basic_energy_type not in picked_types)
            )

        eligible_indices = [i for i, cid in enumerate(player.deck) if deck_matches(card_db.get(cid))]
        if not eligible_indices:
            state.rng.shuffle(player.deck)
            _resolve_incidental_knockouts(state, card_db)
            return
        distinct_ids = {player.deck[i] for i in eligible_indices}
        if len(distinct_ids) == 1:
            idx = eligible_indices[0]
            energy_id = player.deck.pop(idx)
            energy_card = card_db.get(energy_id)
            target.attached_energy.append(energy_id)
            state.add_log(f"player{choice.player_index} が{card_name(card_db, energy_id)}を{card_name(card_db, target.card_id)}につけた")
            next_types = picked_types | {energy_card.basic_energy_type} if energy_card else picked_types
            cont_ctx = EffectContext(
                state=state, card_db=card_db, acting_player=choice.actor(),
                source_pokemon=choice.cont_source_pokemon, source_card_id=choice.cont_source_card_id, rng=state.rng,
            )
            _attach_deck_energy_freely(
                cont_ctx, remaining - 1, picked_types=next_types, distinct_types=distinct_types,
                bench_only=bench_only, then_end_turn=chain_then_end_turn, energy_type=energy_type_filter,
                optional=optional, target_name_prefix=target_name_prefix,
            )
            _resolve_incidental_knockouts(state, card_db)
            return
        state.pending_search_choice = PendingSearchChoice(
            player_index=choice.player_index,
            zone="deck",
            source_indices=eligible_indices,
            card_ids=[player.deck[i] for i in eligible_indices],
            min_count=1,
            max_count=1,
            prompt=f"{card_name(card_db, target.card_id)}につける基本エネルギーを選ぶ",
            shuffle_after=False,
            all_card_ids=list(player.deck),
            destination="attach_energy",
            attach_target_pokemon=target,
            cont_source_pokemon=choice.cont_source_pokemon,
            cont_source_card_id=choice.cont_source_card_id,
            then_end_turn=chain_then_end_turn,
            custom_data={
                "mode": "attach_deck_energy_freely_continue",
                "remaining": remaining - 1,
                "picked_types": sorted(picked_types),
                "distinct_types": distinct_types,
                "bench_only": bench_only,
                "then_end_turn": chain_then_end_turn,
                "energy_type": energy_type_filter,
                "optional": optional,
                "target_name_prefix": target_name_prefix,
            },
        )
        return

    if mode == "attach_discard_energy_freely_pick_target":
        # ライボルトGXの「Full Voltage-GX」等: トラッシュの基本エネルギーを1枚ずつ、対象を選び直し
        # ながら自由につけていく。対象を確定したら、続けてどの基本エネルギーをつけるか選ばせる
        # (種類が1つしかなければ選択なしでそのまま自動的につける)。
        remaining = mode_data.get("remaining", 0)
        energy_type_filter = mode_data.get("energy_type")
        chain_then_end_turn = mode_data.get("then_end_turn", False)
        target_type_filter = mode_data.get("target_type")
        optional = mode_data.get("optional", False)
        if optional and not slots:
            # 「Nまで」の任意枚数: これ以上つけないことを選んだ(0枚選択で打ち切り)。
            state.add_log(f"{choice.prompt}: (これ以上つけない)")
            _resolve_incidental_knockouts(state, card_db)
            return
        target = _own_pokemon_at_slot(player, slots[0]) if slots else None
        if target is None:
            _resolve_incidental_knockouts(state, card_db)
            return
        eligible_indices = [
            i for i, cid in enumerate(player.discard)
            if (c := card_db.get(cid)) is not None and c.is_energy and not c.is_special_energy
            and (energy_type_filter is None or c.basic_energy_type == energy_type_filter)
        ]
        if not eligible_indices:
            _resolve_incidental_knockouts(state, card_db)
            return
        distinct_ids = {player.discard[i] for i in eligible_indices}
        if len(distinct_ids) == 1:
            from effects.primitives import _attach_discard_energy_freely

            idx = eligible_indices[0]
            energy_id = player.discard.pop(idx)
            target.attached_energy.append(energy_id)
            state.add_log(f"player{choice.player_index} が{card_name(card_db, energy_id)}を{card_name(card_db, target.card_id)}につけた")
            cont_ctx = EffectContext(
                state=state, card_db=card_db, acting_player=choice.actor(),
                source_pokemon=choice.cont_source_pokemon, source_card_id=choice.cont_source_card_id, rng=state.rng,
            )
            _attach_discard_energy_freely(
                cont_ctx, remaining - 1, energy_type=energy_type_filter, then_end_turn=chain_then_end_turn,
                target_type=target_type_filter, optional=optional,
            )
            _resolve_incidental_knockouts(state, card_db)
            return
        state.pending_search_choice = PendingSearchChoice(
            player_index=choice.player_index,
            zone="discard",
            source_indices=eligible_indices,
            card_ids=[player.discard[i] for i in eligible_indices],
            min_count=1,
            max_count=1,
            prompt=f"{card_name(card_db, target.card_id)}につける基本エネルギーを選ぶ",
            shuffle_after=False,
            all_card_ids=list(player.discard),
            destination="attach_energy",
            attach_target_pokemon=target,
            cont_source_pokemon=choice.cont_source_pokemon,
            cont_source_card_id=choice.cont_source_card_id,
            then_end_turn=chain_then_end_turn,
            custom_data={
                "mode": "attach_discard_energy_freely_continue",
                "remaining": remaining - 1,
                "energy_type": energy_type_filter,
                "then_end_turn": chain_then_end_turn,
                "target_type": target_type_filter,
                "optional": optional,
            },
        )
        return

    if mode == "attach_specific_card_to_target":
        # ズガドーンGXの「バーストGX」等: あらかじめ決まっているカード(custom_data["card_id"])を
        # 選んだ対象につける。バーストGXはワザなので、下のprime_catcher_own_switch等と同じ理由で
        # then_end_turnを伝播させる(Ripening Charge等の特性経由の場合は元々Falseのまま)。
        chain_then_end_turn = mode_data.get("then_end_turn", False)
        card_id = mode_data.get("card_id")
        target = _own_pokemon_at_slot(player, slots[0]) if slots else None
        if target is None or card_id is None:
            _resolve_incidental_knockouts(state, card_db, then_end_turn=chain_then_end_turn)
            return
        target.attached_energy.append(card_id)
        state.add_log(f"player{choice.player_index} が{card_name(card_db, card_id)}を{card_name(card_db, target.card_id)}につけた")
        heal_amount = mode_data.get("heal_amount", 0)
        if heal_amount:
            target.damage = max(0, target.damage - heal_amount)
        _resolve_incidental_knockouts(state, card_db, then_end_turn=chain_then_end_turn)
        return

    if mode == "return_to_hand_target":
        # スーパーポケモン回収: 選んだポケモンをついているカードごと手札に戻す。
        # バトル場が空になったら、きぜつ時と同じ新アクティブ選択の流れに合流する。
        slot = slots[0] if slots else None
        mon = _own_pokemon_at_slot(player, slot) if slot is not None else None
        if mon is None:
            _resolve_incidental_knockouts(state, card_db)
            return
        if slot == 0:
            player.active = None
        else:
            player.bench.pop(slot - 1)
        player.hand.extend(mon.evolution_history)
        player.hand.append(mon.card_id)
        player.hand.extend(mon.attached_energy)
        if mon.attached_tool:
            player.hand.append(mon.attached_tool)
        state.add_log(f"player{choice.player_index} が {card_name(card_db, mon.card_id)} を手札に戻した")
        if player.active is None:
            if player.bench:
                state.pending_active_choice = [choice.player_index]
                state.then_after_choice = "checkup"
                return
            check_win_conditions(state)
            return
        _resolve_incidental_knockouts(state, card_db)
        return

    if mode == "bench_limit_discard":
        # ゼロの大空洞/スカイフィールド/崩れたスタジアム等でベンチ上限が縮小したとき、実カード
        # ルール通りプレイヤー自身が好きな組み合わせを選んでベンチを上限まで減らす(以前は
        # ベンチの末尾から機械的にトラッシュするv1簡略版だった)。
        bench_positions = sorted((s - 1 for s in slots if 1 <= s <= len(player.bench)), reverse=True)
        discarded_names = []
        for bi in bench_positions:
            mon = player.bench.pop(bi)
            player.discard.extend(mon.evolution_history)
            player.discard.append(mon.card_id)
            player.discard.extend(mon.attached_energy)
            if mon.attached_tool:
                player.discard.append(mon.attached_tool)
            discarded_names.append(card_name(card_db, mon.card_id))
        state.add_log(
            f"player{choice.player_index} がベンチの上限を超えたため {', '.join(discarded_names)} をトラッシュした"
        )
        remaining_players = mode_data.get("remaining_players", [])
        chain_then_end_turn = mode_data.get("then_end_turn", False)
        stashed_needs_new_active = mode_data.get("needs_new_active", [])
        stashed_needs_prize_choice = mode_data.get("needs_prize_choice", [])
        stashed_then_after_choice = mode_data.get("then_after_choice", "continue")
        if remaining_players:
            _start_bench_limit_discard_choice(
                state, card_db, remaining_players[0], remaining_players[1:], then_end_turn=chain_then_end_turn,
                needs_new_active=stashed_needs_new_active, needs_prize_choice=stashed_needs_prize_choice,
                then_after_choice=stashed_then_after_choice,
            )
            return
        # このベンチ上限選択の裏で判明していたサイド選択/新アクティブ選択があれば、ここで再開する
        # (apply_knockouts()を呼び直すと、既にトラッシュ済みのポケモンは「きぜつ無し」と判定されて
        # 結果が失われてしまうため、_resolve_incidental_knockoutsではなくここで直接再開する)。
        if _start_knockout_followups(
            state, stashed_needs_new_active, stashed_needs_prize_choice, stashed_then_after_choice,
            then_end_turn=chain_then_end_turn, card_db=card_db,
        ):
            return
        check_win_conditions(state)
        return

    if mode == "replace_pick_dest" or mode == "energy_switch_pick_dest":
        # replace_pick_dest はForretressの「Iron Shake-Up」(ワザ)からも来るため、then_end_turnを
        # 下のprime_catcher_own_switch等と同じ理由で伝播させる(energy_switch_pick_destは
        # 特性/どうぐ経由のみで元々Falseのまま)。ループで次の移動元選択に戻る場合も引き継ぐ。
        chain_then_end_turn = mode_data.get("then_end_turn", False)
        source_slot = mode_data.get("source_slot")
        energy_id = mode_data.get("energy_id")
        dest_mon = _own_pokemon_at_slot(player, slots[0]) if slots else None
        if dest_mon is None or energy_id is None:
            _resolve_incidental_knockouts(state, card_db, then_end_turn=chain_then_end_turn)
            return
        dest_mon.attached_energy.append(energy_id)
        state.add_log(f"player{choice.player_index} が{card_name(card_db, energy_id)}を移動した")
        if mode == "replace_pick_dest":
            # ミュウEXの「Replace」だけ、次の移動元選択に戻ってループする(エネルギーつけかえは1回で終了)。
            _trigger_own_pokemon_move_source_choice(state, choice.player_index, then_end_turn=chain_then_end_turn)
        _resolve_incidental_knockouts(state, card_db, then_end_turn=chain_then_end_turn)
        return

    _resolve_incidental_knockouts(state, card_db)


def _resolve_own_pokemon_energy_target_choice(
    state: GameState, card_db: CardDatabase, choice, selected: list[int]
) -> None:
    """ミュウEXの「Replace」/エネルギーつけかえ: 移動元ポケモンから移動するエネルギーを1枚選ぶ
    (zone="own_pokemon_energy_target")。custom_data["next_mode"]で移動先選択後の遷移先モードを
    指定できる(省略時は"replace_pick_dest")。"""
    player = state.player(choice.player_index)
    custom_data = choice.custom_data if isinstance(choice.custom_data, dict) else {}

    if custom_data.get("mode") == "optional_energy_return_bonus":
        # ゲッコウガの「Moonlight Slash」等: 指定タイプの基本エネルギーを1枚、手札に戻してもよい。
        # 戻したなら追加ダメージ、戻さない(選ばない)なら基本ダメージのみ。ワザ由来なので、下の
        # prime_catcher_own_switch等と同じ理由でthen_end_turnを伝播させる(このモードは常にワザ
        # 経由でのみ発生する)。
        from effects.primitives import DealDamage

        chain_then_end_turn = custom_data.get("then_end_turn", False)
        state.pending_search_choice = None
        mon = choice.cont_source_pokemon
        base = custom_data.get("base", 0)
        bonus = custom_data.get("bonus", 0)
        ctx = EffectContext(
            state=state, card_db=card_db, acting_player=choice.actor(),
            source_pokemon=mon, source_card_id=choice.cont_source_card_id, rng=state.rng,
        )
        amount = base
        if selected and mon is not None:
            energy_index = choice.source_indices[selected[0]]
            if 0 <= energy_index < len(mon.attached_energy):
                energy_id = mon.attached_energy.pop(energy_index)
                player.hand.append(energy_id)
                state.add_log(f"{choice.prompt}: {card_name(card_db, energy_id)}を手札に戻した")
                amount = base + bonus
        DealDamage(amount).execute(ctx)
        _resolve_incidental_knockouts(state, card_db, then_end_turn=chain_then_end_turn)
        return

    # replace_pick_source(Forretressの「Iron Shake-Up」経由もありうる)からの続き。
    # then_end_turnは元のcustom_dataから引き継ぎ、この先の移動先選択(replace_pick_dest/
    # energy_switch_pick_dest)にも伝播させる(prime_catcher_own_switch等と同じ理由)。
    chain_then_end_turn = custom_data.get("then_end_turn", False)
    source_slot = custom_data.get("source_slot")
    next_mode = custom_data.get("next_mode", "replace_pick_dest")
    state.pending_search_choice = None
    source_mon = _own_pokemon_at_slot(player, source_slot) if source_slot is not None else None
    if source_mon is None or not selected:
        _resolve_incidental_knockouts(state, card_db, then_end_turn=chain_then_end_turn)
        return
    energy_index = choice.source_indices[selected[0]]
    if not (0 <= energy_index < len(source_mon.attached_energy)):
        _resolve_incidental_knockouts(state, card_db, then_end_turn=chain_then_end_turn)
        return
    energy_id = source_mon.attached_energy.pop(energy_index)

    candidates = []
    if player.active is not None and source_slot != 0:
        candidates.append((0, player.active))
    for i, mon in enumerate(player.bench):
        if (i + 1) != source_slot:
            candidates.append((i + 1, mon))
    if not candidates:
        # 移動先が無い(起こりえないはずだが安全のため元に戻す)。
        source_mon.attached_energy.append(energy_id)
        _resolve_incidental_knockouts(state, card_db, then_end_turn=chain_then_end_turn)
        return
    state.pending_search_choice = PendingSearchChoice(
        player_index=choice.player_index,
        zone="own_pokemon_target",
        source_indices=[slot for slot, _ in candidates],
        card_ids=[mon.card_id for _, mon in candidates],
        min_count=1,
        max_count=1,
        prompt="エネルギーを移動する先のポケモンを選ぶ",
        shuffle_after=False,
        all_card_ids=[mon.card_id for _, mon in candidates],
        then_end_turn=chain_then_end_turn,
        custom_data={
            "mode": next_mode, "source_slot": source_slot, "energy_id": energy_id,
            "then_end_turn": chain_then_end_turn,
        },
    )


def _handle_resolve_damage_distribution(
    state: GameState, card_db: CardDatabase, actor: int, action: ResolveDamageDistribution
) -> None:
    from effects.primitives import (
        _BATTLE_COLOSSEUM_STADIUM_ID,
        _blocks_damage_counters,
        _defender_blocks_effect,
        _defender_is_shielded,
    )
    from engine.continuous import tools_disabled

    dist = state.pending_damage_distribution
    if dist is None:
        raise IllegalActionError("保留中のダメカン配分がありません")
    side_player = (
        state.player(dist.player_index)
        if dist.target_own_side
        else state.player(state.opponent_index(dist.player_index))
    )
    targets: list[PokemonInPlay] = []
    if not dist.bench_only and side_player.active is not None:
        targets.append(side_player.active)
    targets.extend(side_player.bench)
    if (
        len(action.counts) != len(targets)
        or sum(action.counts) != dist.total_counters
        or any(c < 0 for c in action.counts)
        or (dist.max_per_target is not None and any(c > dist.max_per_target for c in action.counts))
    ):
        raise IllegalActionError("不正なダメカン配分です")

    ctx = EffectContext(
        state=state,
        card_db=card_db,
        acting_player=dist.player_index,
        source_pokemon=None,
        source_card_id=dist.source_card_id,
        rng=state.rng,
        effect_source=dist.effect_source,
    )
    applied_total = 0
    for target, count in zip(targets, action.counts):
        if count <= 0:
            continue
        if not dist.target_own_side:
            if _defender_is_shielded(ctx, target):
                continue
            if _defender_blocks_effect(ctx, target):
                # ダメカンを直接のせる=ワザ自体のダメージではなく「効果」のため、ばけがくれ
                # (Hide 'n' Sneak)等の「ダメージ以外の効果を受けない」特性の対象になる
                # (ドラパルトexの「Phantom Dive」のばらまきダメカン等、2026-08-23ユーザー報告で発覚)。
                continue
            if not tools_disabled(state.stadium_in_play) and _blocks_damage_counters(target):
                continue
            if state.stadium_in_play == _BATTLE_COLOSSEUM_STADIUM_ID and target is not side_player.active:
                # バトルコロシアム実カードテキスト: "おたがいのベンチポケモン全員は、相手のワザや
                # 特性の効果でダメカンがのらない。(ワザのダメージは受ける。)" ここは
                # DistributeDamageCountersFreely(ドラパルトexの「Phantom Dive」等)の解決だが
                # このバトルコロシアムのチェックが漏れており、この効果だけスタジアムを無視して
                # ベンチにダメカンがのっていた(2026-09-22発覚)。
                continue
        target.damage += count * dist.damage_per_counter
        applied_total += count
    side_label = "自分" if dist.target_own_side else "相手"
    state.add_log(f"player{dist.player_index} が{side_label}のポケモンにダメカンを合計{applied_total}個のせた")
    state.pending_damage_distribution = None
    then_end_turn = dist.then_end_turn
    _resolve_incidental_knockouts(state, card_db, then_end_turn=then_end_turn)
    _maybe_end_turn_after_pending_choice(state, card_db, then_end_turn)


_POWER_SPRAY_ID = "pl1-117"  # パワースプレー


def _try_offer_power_spray(
    state: GameState,
    card_db: CardDatabase,
    actor: int,
    mon: PokemonInPlay,
    source_card_id: str,
    script: tuple,
    target_bench_index: int | None,
) -> bool:
    """使おうとしているのがポケパワーで、かつ相手がパワースプレーを打てる状態なら割り込みウィンドウを開く。
    ウィンドウを開いた場合はTrueを返す(呼び出し側はここで処理を中断し、効果解決はウィンドウ解決後に行う)。
    「使った」扱い(used_ability_this_turn等)は呼び出し側でこの関数を呼ぶ前に確定させておくこと
    (公式ルール通り、パワースプレーで打ち消されても使用自体はカウントされるため)。"""
    card = card_db.get(source_card_id)
    if card is None or not card.abilities or card.abilities[0].ability_type != "Poké-Power":
        return False
    opponent_index = state.opponent_index(actor)
    opponent = state.player(opponent_index)
    if not can_play_power_spray(opponent, card_db):
        return False
    state.pending_power_spray_window = PendingPowerSprayWindow(
        actor=actor,
        opponent_index=opponent_index,
        source_card_id=source_card_id,
        mon=mon,
        script=script,
        target_bench_index=target_bench_index,
    )
    return True


def _set_pending_trigger(
    state: GameState,
    actor: int,
    card_id: str,
    mon: PokemonInPlay,
    script: tuple,
    then_end_turn: bool = False,
    override_kind: str = "",
    override_label: str = "",
    attached_energy_id: str = "",
    mandatory: bool = False,
) -> None:
    target_kind = _TRIGGER_TARGET_KIND.get(card_id, "")
    if not target_kind and any(type(e).__name__ == "SwitchActiveWithBench" for e in script):
        # ワザの後の「このポケモンをベンチポケモンと入れ替える」系(ドンファンの「Spinning Turn」、ゲンガーEXの
        # 「Dark Corridor」、パルキアEXの「Strafe」等): 入れ替え先のベンチポケモンを選ぶ必要がある。
        # 以前はカードIDごとの登録(_TRIGGER_TARGET_KIND)に無いカードでは対象が選べず、使っても何も起きなかった
        # (2026-10-06、ドンファンで実際に不発になることをテストで確認して訂正)。
        target_kind = "own_bench"
    state.pending_trigger = PendingTrigger(
        player_index=actor,
        source_card_id=card_id,
        mon=mon,
        script=script,
        needs_target=bool(target_kind),
        target_kind=target_kind,
        then_end_turn=then_end_turn,
        override_kind=override_kind,
        override_label=override_label,
        attached_energy_id=attached_energy_id,
        mandatory=mandatory,
    )


def _trigger_ability_label(card_db: CardDatabase, trig: PendingTrigger) -> str:
    if trig.override_label:
        return trig.override_label
    card = card_db.get(trig.source_card_id)
    if card and card.abilities:
        name, _ = jp_ability(trig.source_card_id, card.abilities[0])
        return name
    return ""


def _trigger_ability_kind(card_db: CardDatabase, trig: PendingTrigger) -> str:
    if trig.override_kind:
        return trig.override_kind
    card = card_db.get(trig.source_card_id)
    if card and card.abilities:
        return ability_kind_label(card.abilities[0].ability_type)
    return "特性"


def _handle_accept_trigger(state: GameState, card_db: CardDatabase, actor: int, action: AcceptTrigger) -> None:
    trig = state.pending_trigger
    if trig is None:
        raise IllegalActionError("保留中のポケパワーがありません")
    state.add_log(
        f"player{trig.player_index} が {card_name(card_db, trig.source_card_id)} の"
        f"{_trigger_ability_kind(card_db, trig)}「{_trigger_ability_label(card_db, trig)}」を使った"
    )
    state.pending_trigger = None
    from effects.registry import get_sibling_evolve_trigger

    if get_sibling_evolve_trigger(trig.source_card_id) is not None or get_become_active_trigger_script(trig.source_card_id):
        trig.mon.used_ability_this_turn = True  # 「自分の番に1回」(使わないと選んだ場合は消費しない)
    if _try_offer_power_spray(
        state, card_db, trig.player_index, trig.mon, trig.source_card_id, trig.script, action.target_bench_index
    ):
        return
    ctx = EffectContext(
        state=state,
        card_db=card_db,
        acting_player=trig.player_index,
        source_pokemon=trig.mon,
        source_card_id=trig.source_card_id,
        target_bench_index=action.target_bench_index,
        rng=state.rng,
        triggering_energy_id=trig.attached_energy_id,
        effect_source="ability",
    )
    run_script(trig.script, ctx)
    if get_sibling_evolve_trigger(trig.source_card_id) is not None and state.sibling_evolve_queue:
        if state.pending_search_choice is not None:
            from effects.primitives import ContinueSiblingEvolveQueue

            state.pending_search_choice.remaining_script = state.pending_search_choice.remaining_script + (ContinueSiblingEvolveQueue(),)
        else:
            _offer_next_sibling_evolve_trigger(state, card_db, trig.player_index)
    trigger_player = state.player(trig.player_index)
    if trigger_player.active is None:
        # Psychic Restore等、ワザ後の「してもよい」効果でバトル場を離れた場合(きぜつ以外)、
        # きぜつ時と同じ新アクティブ選択を挟む。
        state.pending_active_choice = [trig.player_index]
        state.then_after_choice = "advance" if trig.then_end_turn else "continue"
        return
    _resolve_incidental_knockouts(state, card_db)
    if trig.then_end_turn and not state.is_game_over():
        if state.pending_active_choice:
            state.then_after_choice = "advance"
        else:
            _end_current_turn(state, card_db)


def _handle_decline_trigger(state: GameState, card_db: CardDatabase, actor: int, action: DeclineTrigger) -> None:
    trig = state.pending_trigger
    if trig is None:
        raise IllegalActionError("保留中のポケパワーがありません")
    state.add_log(
        f"player{trig.player_index} は {card_name(card_db, trig.source_card_id)} の"
        f"{_trigger_ability_kind(card_db, trig)}「{_trigger_ability_label(card_db, trig)}」を使わなかった"
    )
    state.pending_trigger = None
    from effects.registry import get_sibling_evolve_trigger

    if get_sibling_evolve_trigger(trig.source_card_id) is not None:
        _offer_next_sibling_evolve_trigger(state, card_db, trig.player_index)  # 他のイーブイにも続けて聞く
    _resolve_incidental_knockouts(state, card_db)
    if trig.then_end_turn and not state.is_game_over():
        if state.pending_active_choice:
            state.then_after_choice = "advance"
        else:
            _end_current_turn(state, card_db)


def _handle_use_power_spray(state: GameState, card_db: CardDatabase, actor: int, action: UsePowerSpray) -> None:
    window = state.pending_power_spray_window
    if window is None:
        raise IllegalActionError("パワースプレーを使える場面ではありません")
    player = state.player(actor)
    idx = next((i for i, cid in enumerate(player.hand) if cid == _POWER_SPRAY_ID), None)
    if idx is None:
        raise IllegalActionError("手札にパワースプレーがありません")
    player.hand.pop(idx)
    player.discard.append(_POWER_SPRAY_ID)
    state.add_log(
        f"player{actor} が「パワースプレー」を使い、{card_name(card_db, window.source_card_id)}の特性の効果を防いだ"
    )
    state.pending_power_spray_window = None
    _resolve_incidental_knockouts(state, card_db)


def _handle_pass_power_spray_window(
    state: GameState, card_db: CardDatabase, actor: int, action: PassPowerSprayWindow
) -> None:
    window = state.pending_power_spray_window
    if window is None:
        raise IllegalActionError("パワースプレーを使える場面ではありません")
    state.pending_power_spray_window = None
    ctx = EffectContext(
        state=state,
        card_db=card_db,
        acting_player=window.actor,
        source_pokemon=window.mon,
        source_card_id=window.source_card_id,
        target_bench_index=window.target_bench_index,
        rng=state.rng,
        effect_source="ability",  # パワースプレーの割り込み対象は常にポケパワー(特性)由来
    )
    run_script(window.script, ctx)
    _resolve_incidental_knockouts(state, card_db)


def _apply_dangerous_ruins_damage(state: GameState, card_db: CardDatabase, card_id: str, mon: PokemonInPlay) -> None:
    """危ない廃墟(m1l-63)実カードテキスト: "Both players put 2 damage counters on each Basic
    Pokémon (except Darkness-type Pokémon) they put into play on the bench on their turn."
    除外されるのは「悪タイプ」であって「ルールボックス持ち」ではない(以前はルールボックス持ちを
    誤って除外しており、悪タイプの基本ポケモンには誤って乗り、悪以外のex/V等の基本ポケモンには
    誤って乗らなかった、2026-08-20発覚)。手札から直接出す場合だけでなく、山札検索でベンチに
    出す効果(以前はこの関数自体が無く、_handle_play_basic内にしか無かったため反映されて
    いなかった)からも呼べるよう共通化した。"""
    if state.stadium_in_play != _DANGEROUS_RUINS_ID:
        return
    played_card = card_db.get(card_id)
    if played_card is not None and played_card.is_basic and "Darkness" not in played_card.types:
        max_hp = effective_max_hp(card_db, mon.card_id, mon.attached_tool, state.stadium_in_play, mon.attached_energy)
        mon.damage = min(mon.damage + 20, max_hp)
        state.add_log(f"{card_name(card_db, card_id)} に危ない廃墟でダメカンを2個のせた")


def _handle_play_basic(state: GameState, card_db: CardDatabase, actor: int, action: PlayBasicPokemon) -> None:
    player = state.player(actor)
    card_id = player.hand.pop(action.hand_index)
    if card_id in ITEM_AS_POKEMON and card_id != ROBO_SUBSTITUTE_ITEM_ID:
        # Antique〜Fossil: グッズだが「60HPの無色たねポケモン」として場に出す。場にいる間だけ合成カードID(<ID>-mon)のポケモン。
        # 特殊状態にならない・にげられない(legal_actions/passives側)。きぜつすると相手はサイドを1枚取る(通常のポケモンと同じ)。
        from cards.card_db import POKE_DOLL_ITEM_IDS

        mon = PokemonInPlay(
            card_id=ITEM_AS_POKEMON[card_id], turn_played=player.turns_taken,
            no_prize_on_ko_until_turn=_ROBO_SUBSTITUTE_PERMANENT_SHIELD_TURN if card_id in POKE_DOLL_ITEM_IDS else 0,  # ポケ人形: きぜつしてもサイドは取られない
        )
        player.bench.append(mon)
        state.add_log(f"player{actor} が {card_name(card_db, mon.card_id)} をベンチに出した")
        if state.setup_complete:
            from effects.era_trainers import era_on_basic_benched_from_hand

            era_on_basic_benched_from_hand(state, card_db, actor, mon)
        return
    if card_id == ROBO_SUBSTITUTE_ITEM_ID:
        # みがわりロボ(xy4-102): グッズだが「30HPの無色たねポケモン」として場に出す特殊カード。
        # 場にいる間だけ合成カードID(xy4-102-mon)のポケモンとして扱う(手札/トラッシュでは
        # 引き続き本来のxy4-102のまま)。きぜつしても相手はサイドを取れない(永続シールド)。
        mon = PokemonInPlay(
            card_id=ROBO_SUBSTITUTE_POKEMON_ID,
            turn_played=player.turns_taken,
            no_prize_on_ko_until_turn=_ROBO_SUBSTITUTE_PERMANENT_SHIELD_TURN,
        )
        player.bench.append(mon)
        state.add_log(f"player{actor} が {card_name(card_db, ROBO_SUBSTITUTE_POKEMON_ID)} をベンチに出した")
        return
    mon = PokemonInPlay(card_id=card_id, turn_played=player.turns_taken)
    player.bench.append(mon)
    state.add_log(f"player{actor} が {card_name(card_db, card_id)} をベンチに出した")
    _apply_dangerous_ruins_damage(state, card_db, card_id, mon)
    if state.setup_complete:
        from effects.era_trainers import era_on_basic_benched_from_hand

        era_on_basic_benched_from_hand(state, card_db, actor, mon)  # チームマグマ団のひみつきち

    # 対戦準備(セットアップ)中にベンチへ置くポケモンは、実際のルール上「手札から出した」扱いには
    # ならない(両プレイヤーが同時に伏せて並べる特殊な処理のため)。「手札からベンチに出したとき」
    # 系の特性(ニャースexの「起死回生のキャッチ」等、ENTER_BENCH_TRIGGER_EFFECTS登録分すべて)は
    # 通常のターン中にベンチへ出したときだけ発動すべきで、セットアップ時には発動してはいけない。
    # 以前はこのガードが無く、_handle_play_basicがセットアップ・通常ターンを区別せず一律で
    # トリガーを立てていたため、セットアップ時にも(本来ありえない)特性発動の選択肢が出てしまい、
    # それを狙った不自然な配置をAIが学習してしまっていた(2026-09-05ユーザー報告で発覚)。
    if state.setup_complete:
        trigger_script = get_enter_bench_trigger_script(card_id)
        if trigger_script:
            # 上級ルール上「してもよい」ポケパワーなので、ここでは即実行せずプレイヤーに使う/使わないを選ばせる
            _set_pending_trigger(state, actor, card_id, mon, trigger_script)


def _handle_discard_robo_substitute(
    state: GameState, card_db: CardDatabase, actor: int, action: DiscardRoboSubstitute
) -> None:
    player = state.player(actor)
    if action.zone == Zone.ACTIVE:
        if player.active is None or player.active.card_id not in POKEMON_AS_ITEM:
            raise IllegalActionError("バトル場にみがわりロボ/化石グッズがいません")
        from cards.card_db import POKE_DOLL_ITEM_IDS

        item_id = POKEMON_AS_ITEM[player.active.card_id]
        (player.deck if item_id in POKE_DOLL_ITEM_IDS else player.discard).append(item_id)  # ポケ人形: 山札の下に置く
        player.discard.extend(player.active.attached_energy)
        if player.active.attached_tool:
            player.discard.append(player.active.attached_tool)
        player.active = None
        if player.bench:
            state.pending_active_choice = [actor]
            state.then_after_choice = "checkup"
    else:
        if action.bench_index is None or not (0 <= action.bench_index < len(player.bench)):
            raise IllegalActionError("指定したベンチにみがわりロボがいません")
        mon = player.bench[action.bench_index]
        if mon.card_id not in POKEMON_AS_ITEM or POKEMON_AS_ITEM[mon.card_id] in _poke_doll_ids():
            raise IllegalActionError("指定したベンチにみがわりロボ/化石グッズがいません")
        player.bench.pop(action.bench_index)
        player.discard.append(POKEMON_AS_ITEM[mon.card_id])
        player.discard.extend(mon.attached_energy)
        if mon.attached_tool:
            player.discard.append(mon.attached_tool)
    state.add_log(f"player{actor} が みがわりロボ/化石グッズを場からトラッシュした")


def _poke_doll_ids():
    from cards.card_db import POKE_DOLL_ITEM_IDS

    return POKE_DOLL_ITEM_IDS


def _handle_evolve(state: GameState, card_db: CardDatabase, actor: int, action: Evolve) -> None:
    player = state.player(actor)
    card_id = player.hand.pop(action.hand_index)
    old = player.active if action.target_zone == Zone.ACTIVE else player.bench[action.target_bench_index]
    evolved = PokemonInPlay(
        card_id=card_id,
        attached_energy=list(old.attached_energy),
        damage=old.damage,
        turn_played=player.turns_taken,
        attached_tool=old.attached_tool,
        evolution_history=[*old.evolution_history, old.card_id],
    )
    if action.target_zone == Zone.ACTIVE:
        player.active = evolved
    else:
        player.bench[action.target_bench_index] = evolved
    from effects.era_trainers_g import keep_confusion_on_evolve

    keep_confusion_on_evolve(state, old, evolved)  # Dizzying Valley
    from effects.era_sm_hooks import keeps_status_on_evolve, on_evolved_from_hand as _po_town

    if keeps_status_on_evolve(state):
        evolved.status = old.status  # 無の海(Sea of Nothingness): 進化しても特殊状態は治らない
    _po_town(state, card_db, evolved)  # ポ・タウン
    state.add_log(f"player{actor} が {card_name(card_db, old.card_id)} を {card_name(card_db, card_id)} に進化させた")
    from effects.passives_ext import on_evolved_from_hand

    on_evolved_from_hand(state, card_db, actor, evolved)  # Darkest Impulse

    # 「手札から進化させて出したとき、してもよい」系の特性(リザードンexの「インフェルノリボーン」等)。
    trigger_script = get_evolve_trigger_script(card_id)
    if trigger_script and _evolve_trigger_condition_met(card_id, player, card_db):
        _set_pending_trigger(state, actor, card_id, evolved, trigger_script)

    # 「別の同名ポケモンを手札から進化させたとき、してもよい」系の特性(イーブイの「Resonant Evolution」)。
    if state.pending_trigger is None:
        _offer_sibling_evolve_trigger(state, card_db, actor, old, evolved)

    # XY期のメガシンカポケモン(M ○○EX)のルール: "When 1 of your Pokémon becomes a Mega Evolution Pokémon,
    # your turn ends."(カードに印刷されたルール文)。進化させたら自分の番は終わる。メガタブンネEXは
    # タブンネソウルリンク(xy10-92)をつけていれば終わらない。2026年のメガシンカポケモンex(Mega ○○ ex)には
    # このルールは無い(印刷されているのは「きぜつしたらサイドを3枚取られる」だけ)。
    evolved_card = card_db.get(card_id)
    if evolved_card is not None and any("your turn ends" in rule for rule in evolved_card.rules):
        if _mega_spirit_link_keeps_turn(state, evolved, evolved_card):
            state.add_log("ソウルリンクの効果で、メガシンカしても番は終わらない")
        elif state.pending_trigger is not None:
            state.pending_trigger.then_end_turn = True  # 進化時の特性を解決してから番を終える
        else:
            state.add_log("メガシンカしたので、自分の番は終わる")
            _end_current_turn(state, card_db)


def _offer_sibling_evolve_trigger(
    state: GameState, card_db: CardDatabase, actor: int, old: PokemonInPlay, evolved: PokemonInPlay
) -> None:
    """イーブイ(swsh10-119)の特性「Resonant Evolution」実カードテキスト: "Once during your turn, when you play a
    Pokémon from your hand to evolve 1 of your other Eevee, you may search your deck for a card that evolves from
    this Pokémon and put it onto this Pokémon to evolve it. Then, shuffle your deck." ―― 別のイーブイを進化
    させたとき、特性を持つ場の他のイーブイ(この番にまだ特性を使っていない、特性が封じられていない)が、
    山札の進化先に自分自身を進化させてよい。山札に進化先が無ければ使う意味が無いので提案しない。
    (複数の持ち主が同時にいる場合は、場の先頭の1匹だけに提案する。)"""
    from effects.registry import get_sibling_evolve_trigger

    old_card = card_db.get(old.card_id)
    if old_card is None:
        return
    player = state.player(actor)
    state.sibling_evolve_queue = [
        mon for mon in player.all_pokemon_in_play()
        if mon is not evolved
        and (trigger := get_sibling_evolve_trigger(mon.card_id)) is not None
        and trigger[0] == old_card.name
    ]
    _offer_next_sibling_evolve_trigger(state, card_db, actor)


def _offer_next_sibling_evolve_trigger(state: GameState, card_db: CardDatabase, actor: int) -> None:
    """待ち行列の先頭から、今も使える持ち主(この番にまだ特性を使っていない・特性が封じられていない・山札に進化先がある)を
    探して「使う/使わない」を提案する。持ち主が複数いる場合は、1匹ずつ順に聞く(以前は先頭の1匹にしか提案しなかった)。"""
    from effects.registry import get_sibling_evolve_trigger
    from engine.continuous import ability_suppressed

    player = state.player(actor)
    while state.sibling_evolve_queue and state.pending_trigger is None:
        mon = state.sibling_evolve_queue.pop(0)
        trigger = get_sibling_evolve_trigger(mon.card_id)
        mon_card = card_db.get(mon.card_id)
        if (
            trigger is None
            or mon_card is None
            or mon.used_ability_this_turn
            or not any(m is mon for m in player.all_pokemon_in_play())
            or ability_suppressed(state, card_db, actor, mon)
        ):
            continue
        has_target = any(
            (c := card_db.get(cid)) is not None and c.evolves_from == mon_card.name for cid in player.deck
        )
        if not has_target:
            continue
        _set_pending_trigger(state, actor, mon.card_id, mon, trigger[1])
        return


_MEGA_SPIRIT_LINK_TOOLS: dict[str, str] = {"xy10-92": "M Audino-EX"}  # タブンネソウルリンク: メガタブンネEXになっても番は終わらない


def _mega_spirit_link_keeps_turn(state: GameState, evolved: PokemonInPlay, evolved_card) -> bool:
    from engine.continuous import tools_disabled

    tool_id = evolved.attached_tool
    return (
        tool_id is not None
        and _MEGA_SPIRIT_LINK_TOOLS.get(tool_id) == evolved_card.name
        and not tools_disabled(state.stadium_in_play)
    )


def _handle_level_up(state: GameState, card_db: CardDatabase, actor: int, action: PlayLevelUp) -> None:
    player = state.player(actor)
    card_id = player.hand.pop(action.hand_index)
    old = player.active if action.target_zone == Zone.ACTIVE else player.bench[action.target_bench_index]
    leveled = PokemonInPlay(
        card_id=card_id,
        attached_energy=list(old.attached_energy),
        damage=old.damage,
        status=old.status,
        turn_played=old.turn_played,  # 進化タイミング制限には影響しない
        attached_tool=old.attached_tool,
        leveled_up=True,
    )
    if action.target_zone == Zone.ACTIVE:
        player.active = leveled
    else:
        player.bench[action.target_bench_index] = leveled
    state.add_log(f"player{actor} が {card_name(card_db, old.card_id)} を {card_name(card_db, card_id)} にレベルアップさせた")

    # レベルアップ時のポケパワー(Bright Look/Healing Breath等)は、バトルポケモンに
    # 重ねたときだけ発動する(公式テキストの "onto your Active X" 相当)
    if action.target_zone == Zone.ACTIVE:
        trigger_script = get_level_up_trigger_script(card_id)
        if trigger_script:
            _set_pending_trigger(state, actor, card_id, leveled, trigger_script)


_RAINBOW_ENERGY_ID = AliasStr("sm1-137")  # レインボーエネルギー: 手札からつけたとき、ダメカンを1個のせる
_ROBO_SUBSTITUTE_PERMANENT_SHIELD_TURN = 10**9  # みがわりロボ: きぜつしても相手はサイドを取れない(常時有効の巨大な番号で表現)
_PLASMA_ENERGY_ID = AliasStr("bw10-91")  # プラズマエネルギー: ゲノセクトEXの「Red Signal」はこれを付けた場合のみ発動
_RED_SIGNAL_CARD_ID = "bw10-11"  # ゲノセクトEX
_TELEPATHIC_PSYCHIC_ENERGY_ID = TELEPATHIC_PSYCHIC_ENERGY_ID  # テレパス超エネルギー: 手札から[超]ポケモンに
# つけたとき、山札から[超]タイプのたねポケモンを2枚までベンチに出す(それ以外のタイプのポケモンに
# つけた場合、コストとしては超1個ぶんとして機能するが=engine.energy.energy_tokens、この検索効果は発動しない)
_WARP_ENERGY_ID = "dp7-95"  # ワープエネルギー: 手札からバトルポケモンにつけたとき、そのポケモンをベンチポケモン(自分で選ぶ)と入れ替える
_JET_ENERGY_ID = "sv2-190"  # ジェットエネルギー: 手札からベンチポケモンにつけたとき、そのポケモンをバトルポケモンと入れ替える
_CAPTURE_ENERGY_ID = "swsh2-171"  # キャプチャーエネルギー: 手札からポケモンにつけたとき、山札からたねポケモンを1枚ベンチに出す
_RICH_ENERGY_ID = "sv8-191"  # リッチエネルギー(Enriching Energy、ACE SPEC): 手札からつけたとき4枚引く
# (基本コスト面はengine.energy.energy_tokensのフォールバック(basic_energy_type=None→Colorless)で
# 既に対応済みだったが、この「つけたとき4枚引く」トリガーが未実装だった、2026-08-23ユーザー報告で発覚)


def _handle_attach_energy(state: GameState, card_db: CardDatabase, actor: int, action: AttachEnergy) -> None:
    player = state.player(actor)
    card_id = player.hand.pop(action.hand_index)
    target = player.active if action.target_zone == Zone.ACTIVE else player.bench[action.target_bench_index]
    target.attached_energy.append(card_id)
    player.energy_attached_this_turn = True
    state.add_log(f"player{actor} が {card_name(card_db, target.card_id)} に {card_name(card_db, card_id)} をつけた")
    if state.stadium_in_play == POKEMON_PARK_STADIUM_ID and action.target_zone == Zone.BENCH:
        target.heal(10)
    from effects.era_primitives_f import era_on_energy_attached_to
    from effects.era_trainers import era_on_energy_attached_from_hand

    era_on_energy_attached_from_hand(state, card_db, actor, target)  # フローズンシティ
    era_on_energy_attached_to(state, player, target)  # Boo-Hoo
    from effects.era_energy_g import on_energy_attached

    on_energy_attached(state, card_db, actor, target, card_id)  # ダブルアクア/ダブルマグマ: つけた番の終わりにトラッシュ
    if target.attach_counters_until_turn > 0 and player.turns_taken <= target.attach_counters_until_turn:
        from effects.primitives import _blocks_damage_counters

        if not _blocks_damage_counters(target):
            target.damage += 10 * target.attach_counters_amount  # Electrified Incisors: 手札からエネルギーをつけるたびにダメカン
            state.add_log(f"相手のワザの効果で、エネルギーをつけたポケモンにダメカンを{target.attach_counters_amount}個のせた")
    suppressed = special_energy_effects_suppressed()  # シンオウ神殿: 特殊エネルギーの「つけたとき」効果もすべて無効
    if card_id == _RAINBOW_ENERGY_ID and not suppressed:
        target.damage += 10
    if card_id == _RICH_ENERGY_ID and not suppressed:
        from effects.primitives import Draw

        trigger_ctx = EffectContext(
            state=state, card_db=card_db, acting_player=actor,
            source_pokemon=target, source_card_id=target.card_id, rng=state.rng,
        )
        run_script((Draw(4),), trigger_ctx)
    if card_id == _JET_ENERGY_ID and action.target_zone == Zone.BENCH and not suppressed:
        # 実カードテキスト: 「このカードを手札からベンチポケモンにつけたとき、そのポケモンをバトルポケモンと入れ替える」
        if player.active is not None:
            old_active = player.active
            player.bench.pop(action.target_bench_index)
            old_active.status.clear_all()
            player.bench.append(old_active)
            target.status.clear_all()
            target.became_active_turn = player.turns_taken
            player.active = target
            state.add_log(f"ジェットエネルギー: {card_name(card_db, target.card_id)} をバトル場に出した")
    if card_id == _CAPTURE_ENERGY_ID and not suppressed:
        from effects.primitives import SearchDeckForBasicPokemonToBench

        trigger_ctx = EffectContext(
            state=state, card_db=card_db, acting_player=actor,
            source_pokemon=target, source_card_id=target.card_id, rng=state.rng,
        )
        run_script((SearchDeckForBasicPokemonToBench(count=1),), trigger_ctx)
    if card_id in (_TELEPATHIC_PSYCHIC_ENERGY_ID, TELEPATHIC_PSYCHIC_ENERGY_REPRINT_ID) and not suppressed:
        target_card = card_db.get(target.card_id)
        if target_card is not None and "Psychic" in target_card.types:
            from effects.primitives import SearchDeckForBasicPokemonToBench

            trigger_ctx = EffectContext(
                state=state, card_db=card_db, acting_player=actor,
                source_pokemon=target, source_card_id=target.card_id, rng=state.rng,
            )
            run_script((SearchDeckForBasicPokemonToBench(count=2, pokemon_type="Psychic"),), trigger_ctx)
    from effects.primitives import clear_status_if_festival_grounds_protects, clear_status_if_verdant_wind_protects

    clear_status_if_verdant_wind_protects(player, target, card_db)
    clear_status_if_festival_grounds_protects(state, target)

    # 「手札からエネルギーをつけたとき」の強制発動特性(ホエルオーEXの「Water Veil」等)。
    mandatory_script = get_mandatory_energy_attach_trigger_script(target.card_id)
    if mandatory_script:
        trigger_ctx = EffectContext(
            state=state, card_db=card_db, acting_player=actor,
            source_pokemon=target, source_card_id=target.card_id, rng=state.rng,
            effect_source="ability",
        )
        run_script(mandatory_script, trigger_ctx)

    from effects.passives import on_energy_attached_from_hand

    on_energy_attached_from_hand(state, card_db, actor, target)  # Earthen Awakening/Auto Heal/Electromagnetic Wall

    # 「手札からエネルギーをつけたとき、してもよい」系の特性(カラマネロEXの「Hyper Hypnosis」等)。
    # ゲノセクトEXの「Red Signal」はプラズマエネルギーを付けた場合のみ発動する。
    if target.card_id == _RED_SIGNAL_CARD_ID and card_id != _PLASMA_ENERGY_ID:
        pass
    else:
        trigger_script = get_energy_attach_trigger_script(target.card_id)
        if trigger_script and all(
            e.trigger_gate(card_id, card_db) for e in trigger_script if hasattr(e, "trigger_gate")
        ):  # 生成された特性の発動条件(つけたエネルギーの名前: Red Signal等)
            _set_pending_trigger(state, actor, target.card_id, target, trigger_script, attached_energy_id=card_id)

    if (
        (card_id == _WARP_ENERGY_ID or card_id in _sm_warp_ids())
        and not suppressed
        and action.target_zone == Zone.ACTIVE
        and player.bench
        and state.pending_trigger is None
        and state.pending_search_choice is None
    ):
        # ワープエネルギー: 入れ替え先のベンチポケモンは自分で選ぶ(必ず行う効果なので、使わない選択肢は出さない)
        from effects.primitives import SwitchActiveWithBench

        _set_pending_trigger(
            state, actor, card_id, target, (SwitchActiveWithBench(),),
            override_kind="特殊エネルギー", override_label=card_name(card_db, card_id), mandatory=True,
        )


def _sm_warp_ids():
    from effects.era_sm_hooks import WARP_ENERGY_SM_IDS

    return WARP_ENERGY_SM_IDS


_HEAD_RINGER_ID = "xy4-97"  # ヘッドノイザー(Head Ringer): 相手のバトルポケモン(EX)につける道具


def _handle_play_item(state: GameState, card_db: CardDatabase, actor: int, action: PlayItem) -> None:
    player = state.player(actor)
    if action.extra_hand_indices:
        # 「4枚同時使用」カード: 4枚を先にトラッシュしてから、4枚同時使用時の効果を実行する(大きい位置から先にpop)
        from effects.registry import get_trainer_quad_script

        indices = sorted({action.hand_index, action.paired_hand_index, *action.extra_hand_indices}, reverse=True)
        popped = [player.hand.pop(i) for i in indices]
        card_id = popped[-1]
        player.discard.extend(popped)
        state.add_log(f"player{actor} が グッズ「{card_name(card_db, card_id)}」を4枚同時に使った")
        script = get_trainer_quad_script(card_id)
    elif action.paired_hand_index is not None:
        # 「2枚同時使用」カード: 両方を先にトラッシュしてから2枚同時使用時の効果を実行する
        # (インデックスのずれを避けるため、大きい方から先にpopする)
        hi, lo = sorted((action.hand_index, action.paired_hand_index), reverse=True)
        card_id_hi = player.hand.pop(hi)
        card_id_lo = player.hand.pop(lo)
        card_id = card_id_lo  # 表示・効果検索には同じIDのどちらを使っても同じ
        player.discard.extend([card_id_hi, card_id_lo])
        state.add_log(f"player{actor} が グッズ「{card_name(card_db, card_id)}」を2枚同時に使った")
        script = get_trainer_paired_script(card_id)
    else:
        card_id = player.hand.pop(action.hand_index)
        state.add_log(f"player{actor} が グッズ「{card_name(card_db, card_id)}」を使った")
        script = get_trainer_script(card_id)
    ctx = EffectContext(
        state=state,
        card_db=card_db,
        acting_player=actor,
        source_pokemon=None,
        source_card_id=card_id,
        target_bench_index=action.target_bench_index,
        rng=state.rng,
    )
    from effects.era_primitives_f import era_trainer_coin_blocks
    from effects.era_special import item_effects_shielded
    from effects.era_trainers_g import thunder_mountain_shields

    if era_trainer_coin_blocks(state, actor):
        pass  # Dizzying Wind: コインがウラ。カードはトラッシュされるが、効果は無い
    elif item_effects_shielded(state, card_db, actor, script, "item", action.target_bench_index) or thunder_mountain_shields(state, script):
        state.add_log("特性(Bright Veil/Snow Camouflage)で、このグッズの相手のポケモンへの効果は無効になった")
    else:
        from effects.era_sm_hooks import dust_island_apply, dust_island_snapshot

        dust_snapshot = dust_island_snapshot(state)
        run_script(script, ctx)
        dust_island_apply(state, dust_snapshot)  # ダストアイランド
    if action.paired_hand_index is None:
        # ヘッドノイザー(xy4-97)は自分のトラッシュではなく相手のポケモンにつく道具なので、
        # 実際についたときは(通常のグッズと違い)自分のトラッシュに送らない。
        opponent = state.player(state.opponent_index(actor))
        attached_to_opponent = card_id == _HEAD_RINGER_ID and (
            (opponent.active is not None and opponent.active.attached_tool == card_id)
            or any(mon.attached_tool == card_id for mon in opponent.bench)
        )
        if not attached_to_opponent:
            _place_played_card(state, player, card_id)
    if player.active is None:
        # スーパーポケモン回収等、自分のバトルポケモンを手札に戻す効果でバトル場が空になった場合。
        # きぜつ時の新アクティブ選択と同じ流れで処理する。
        if player.bench:
            state.pending_active_choice = [actor]
            state.then_after_choice = "checkup"
            return
        check_win_conditions(state)
        return
    if state.pending_search_choice is None:
        _resolve_incidental_knockouts(state, card_db)


def _place_played_card(state: GameState, player: PlayerState, card_id: str) -> None:
    """使い終えたグッズ/サポートを置く。効果が行き先を指定していれば("hand"=手札/"prizes"=サイドに混ぜる)そこへ、無ければトラッシュ。"""
    destination = state.played_card_destination
    state.played_card_destination = None
    if destination == "hand":
        player.hand.append(card_id)
    elif destination == "deck":
        player.deck.append(card_id)
        state.rng.shuffle(player.deck)  # このカードを山札に混ぜる(用務員)
    elif destination == "bottom":
        player.deck.append(card_id)  # このカードを山札の下に置く(タマゴふ化器)
    elif destination == "prizes":
        player.add_prizes([card_id])  # シャッフルは、選んだカードを手札に加えたあとに効果の側が行う(選ぶ位置がずれないように)
    else:
        player.discard.append(card_id)


def _handle_play_supporter(state: GameState, card_db: CardDatabase, actor: int, action: PlaySupporter) -> None:
    player = state.player(actor)
    card_id = player.hand.pop(action.hand_index)
    state.add_log(f"player{actor} が サポート「{card_name(card_db, card_id)}」を使った")
    ctx = EffectContext(
        state=state,
        card_db=card_db,
        acting_player=actor,
        source_pokemon=None,
        source_card_id=card_id,
        target_bench_index=action.target_bench_index,
        rng=state.rng,
    )
    from effects.era_primitives_f import era_trainer_coin_blocks

    from effects.era_special import item_effects_shielded

    supporter_script = get_trainer_script(card_id)
    if era_trainer_coin_blocks(state, actor):  # Dizzying Wind: コインがウラなら効果なし
        pass
    elif item_effects_shielded(state, card_db, actor, supporter_script, "supporter", action.target_bench_index):
        state.add_log("Protective Sail/Snow Camouflageの特性で、このサポートの相手のポケモンへの効果は無効になった")
    else:
        from effects.era_sm_hooks import dust_island_apply, dust_island_snapshot

        dust_snapshot = dust_island_snapshot(state)
        run_script(supporter_script, ctx)
        dust_island_apply(state, dust_snapshot)  # ダストアイランド
    _place_played_card(state, player, card_id)
    player.supporter_played_this_turn = True
    player.supporters_played_count_this_turn += 1
    if _apply_forced_turn_end(state, card_db):  # オーキド博士のヒント/ミスティの活力: 使ったら自分の番は終わる
        return
    played_card = card_db.get(card_id)
    if played_card is not None:
        player.supporter_names_this_turn.append(played_card.name)
    if played_card is not None and "Team Rocket" in played_card.name:
        player.team_rocket_supporter_played_this_turn = True
    if player.active is None:
        # フトゥー博士のシナリオ/ペニー等、自分のバトルポケモンを手札に戻す効果でバトル場が空になった場合。
        # きぜつ時の新アクティブ選択と同じ流れで処理する。
        if player.bench:
            state.pending_active_choice = [actor]
            state.then_after_choice = "checkup"
            return
        check_win_conditions(state)
        return
    if state.pending_search_choice is None:
        _resolve_incidental_knockouts(state, card_db)


def _handle_play_stadium(state: GameState, card_db: CardDatabase, actor: int, action: PlayStadium) -> None:
    player = state.player(actor)
    card_id = player.hand.pop(action.hand_index)
    outgoing_stadium_owner = state.stadium_owner
    from effects.era_sm_hooks import CHAOTIC_SWELL_IDS

    if state.stadium_in_play in CHAOTIC_SWELL_IDS and state.stadium_owner is not None:
        # カオティックスウェル: おたがいに、スタジアムを手札から出したら、このカードをトラッシュしたあとで、その新しいスタジアムもトラッシュする(効果は無い)
        state.player(state.stadium_owner).discard.append(state.stadium_in_play)
        player.discard.append(card_id)
        state.stadium_in_play = None
        state.stadium_owner = None
        state.stadium_orientation_target = None
        player.stadium_played_this_turn = True
        state.add_log("カオティックスウェルの効果で、出したスタジアムもトラッシュされた")
        return
    if state.stadium_in_play is not None and state.stadium_owner is not None:
        state.player(state.stadium_owner).discard.append(state.stadium_in_play)
    state.stadium_in_play = card_id
    state.stadium_owner = actor
    state.stadium_orientation_target = action.orientation_target
    player.stadium_played_this_turn = True
    # 「1人のプレイヤーの番に1回」の制限はスタジアムカードごとに独立している(アルタイル市等)。
    # 前のスタジアムの効果を使用済みでも、別のスタジアムに張り替えたら新しいカードの効果として
    # あらためて使えるようにリセットする。
    player.used_stadium_ability_this_turn = False
    if action.orientation_target is not None:
        state.add_log(
            f"player{actor} が スタジアム「{card_name(card_db, card_id)}」を"
            f"player{action.orientation_target}に向けて出した"
        )
    else:
        state.add_log(f"player{actor} が スタジアム「{card_name(card_db, card_id)}」を出した")
    from effects.primitives import FESTIVAL_GROUNDS_STADIUM_ID, clear_status_if_festival_grounds_protects

    if card_id == FESTIVAL_GROUNDS_STADIUM_ID:
        # お祭り会場: 出た瞬間、既にエネルギーがついている(自分・相手どちらの)ポケモンの特殊状態を解除する。
        for p in state.players:
            for mon in p.all_pokemon_in_play():
                clear_status_if_festival_grounds_protects(state, mon)
    # ゼロの大空洞等が場を離れた場合、上限超過ぶんをプレイヤーが選んでトラッシュする(実カードの
    # 「離れる原因を作った本人=出した本人が先に選ぶ」ルールに合わせ、離脱したスタジアムの持ち主を
    # 優先させる)。
    _enforce_bench_limits(state, card_db, priority_player=outgoing_stadium_owner)


def _handle_use_stadium_ability(
    state: GameState, card_db: CardDatabase, actor: int, action: UseStadiumAbility
) -> None:
    player = state.player(actor)
    stadium_id = state.stadium_in_play
    if stadium_id is None:
        raise IllegalActionError("場にスタジアムがありません")
    state.add_log(f"player{actor} が スタジアム「{card_name(card_db, stadium_id)}」の効果を使った")
    ctx = EffectContext(
        state=state,
        card_db=card_db,
        acting_player=actor,
        source_pokemon=None,
        source_card_id=stadium_id,
        rng=state.rng,
        effect_source="ability",
    )
    run_script(get_stadium_ability_script(stadium_id), ctx)
    player.used_stadium_ability_this_turn = True
    if state.pending_search_choice is None:
        _resolve_incidental_knockouts(state, card_db)
    _apply_forced_turn_end(state, card_db)  # トロピカルビーチ/ルミオスシティ: 使ったら自分の番は終わる


def _handle_use_discard_ability(state: GameState, card_db: CardDatabase, actor: int, action: UseDiscardAbility) -> None:
    """トラッシュにいる状態で発動する特性(ギラティナ(smp-SM151)の「Distortion Door」等)。
    そのポケモンをベンチに出してから、付随効果を実行する。DISCARD_ABILITY_TO_HAND_CARD_IDSに
    含まれるカード(タマタマの「Propagation」等)はベンチではなく手札に戻る(付随効果は無し)。"""
    player = state.player(actor)
    if action.from_hand:
        # 手札にいるポケモンの特性(タブンネの「Busybody」): 公開して効果を行い、そのポケモンはトラッシュする
        from effects.era_special import HAND_ABILITY_SCRIPTS

        card_id = player.hand.pop(action.discard_index)
        state.add_log(f"player{actor} が 手札の {card_name(card_db, card_id)} を公開して特性を使った")
        ctx = EffectContext(
            state=state, card_db=card_db, acting_player=actor, source_pokemon=player.active, source_card_id=card_id,
            rng=state.rng, effect_source="ability",
        )
        run_script(HAND_ABILITY_SCRIPTS.get(card_id, ()), ctx)
        player.discard.append(card_id)
        return
    card_id = player.discard.pop(action.discard_index)
    player.used_discard_ability_this_turn = True
    from effects.registry import discard_ability_dest

    dest = discard_ability_dest(card_id)
    if dest == "hand":
        player.hand.append(card_id)
        state.add_log(f"player{actor} が トラッシュの {card_name(card_db, card_id)} の特性で手札に戻した")
        return
    if dest == "deck_bottom":
        player.deck.append(card_id)
        state.add_log(f"player{actor} が トラッシュの {card_name(card_db, card_id)} の特性で山札の下に戻した")
        return
    if dest == "coin_bench":
        heads = state.rng.random() < 0.5
        state.add_log("コイン: オモテ" if heads else "コイン: ウラ")
        if not heads:
            player.discard.append(card_id)
            return
    mon = PokemonInPlay(card_id=card_id, turn_played=player.turns_taken)
    player.bench.append(mon)
    state.add_log(f"player{actor} が トラッシュの {card_name(card_db, card_id)} の特性でベンチに出た")
    ctx = EffectContext(
        state=state,
        card_db=card_db,
        acting_player=actor,
        source_pokemon=mon,
        source_card_id=card_id,
        rng=state.rng,
        effect_source="ability",
    )
    run_script(get_discard_ability_script(card_id), ctx)
    if state.pending_search_choice is None and state.pending_damage_distribution is None:
        _resolve_incidental_knockouts(state, card_db)


def _handle_play_pokemon_tool(state: GameState, card_db: CardDatabase, actor: int, action: PlayPokemonTool) -> None:
    player = state.player(actor)
    card_id = player.hand.pop(action.hand_index)
    target = player.active if action.target_zone == Zone.ACTIVE else player.bench[action.target_bench_index]
    target.attached_tool = card_id
    state.add_log(f"player{actor} が {card_name(card_db, target.card_id)} に どうぐ「{card_name(card_db, card_id)}」をつけた")
    from effects.era_trainers import era_on_tool_attached

    era_on_tool_attached(state, card_db, actor, target)  # スパークリングローブ


_UNLIMITED_PER_TURN_ABILITY_CARD_IDS = {
    "base1-4",  # Charizard「エネルギー円」: "As often as you like during your turn"(1回制限ではない)
    "base1-15",  # Venusaur「エネルギー転送」: 同上
    "sv1-86",  # Gardevoir ex「サイコエンブレイス」: 同上
    "bw10-16",  # カメックス「げきりゅう」(Deluge): 同上
    "xy1-93",  # フレフワン「Fairy Transfer」: 同上
    "me1-3",  # メガフシギバナex「Solar Transfer」: "As often as you like during your turn"
}
try:  # 生成された「何度でも使える」起動型特性(scripts/generate_abilities.py)
    from effects.registry import GENERATED_UNLIMITED_ABILITY_IDS as _GENERATED_UNLIMITED_ABILITY_IDS

    _UNLIMITED_PER_TURN_ABILITY_CARD_IDS |= set(_GENERATED_UNLIMITED_ABILITY_IDS)
except ImportError:  # pragma: no cover
    pass


def _handle_use_tool_granted_ability(
    state: GameState, card_db: CardDatabase, actor: int, action: UseAbility, mon: PokemonInPlay
) -> None:
    """森の封印石のように、どうぐ自身に印刷された特性(VSTARパワー)をついているポケモンが使う。"""
    player = state.player(actor)
    tool_card = card_db.get(mon.attached_tool) if mon.attached_tool else None
    if tool_card is None or not tool_card.abilities:
        return
    ability = tool_card.abilities[0]
    jp_ability_name, _ = jp_ability(tool_card.id, ability)
    state.add_log(
        f"player{actor} の {card_name(card_db, mon.card_id)} が {card_name(card_db, tool_card.id)} の"
        f"{ability_kind_label(ability.ability_type)}「{jp_ability_name}」を使った"
    )
    if "VSTAR Power in a game" in (ability.text or ""):
        player.used_vstar_power_this_game = True
    ctx = EffectContext(
        state=state, card_db=card_db, acting_player=actor, source_pokemon=mon, source_card_id=tool_card.id,
        target_bench_index=action.target_bench_index, rng=state.rng, effect_source="ability",
    )
    run_script(get_ability_script(tool_card.id, ability.name), ctx)
    _resolve_incidental_knockouts(state, card_db)


def _handle_use_ability(state: GameState, card_db: CardDatabase, actor: int, action: UseAbility) -> None:
    player = state.player(actor)
    mon = player.active if action.zone == Zone.ACTIVE else player.bench[action.bench_index]
    if getattr(action, "from_tool", False):
        _handle_use_tool_granted_ability(state, card_db, actor, action, mon)
        return
    card = card_db.get(mon.card_id)
    if card is None or not card.abilities:
        return
    ability_name = card.abilities[0].name
    jp_ability_name, _ = jp_ability(mon.card_id, card.abilities[0])
    kind = ability_kind_label(card.abilities[0].ability_type)
    state.add_log(f"player{actor} の {card_name(card_db, mon.card_id)} が{kind}「{jp_ability_name}」を使った")
    # 「使った」扱い(1回制限のカウント等)はパワースプレーで打ち消されても確定するため、
    # 効果解決(run_script)より前に行う。
    if mon.card_id not in _UNLIMITED_PER_TURN_ABILITY_CARD_IDS:
        mon.used_ability_this_turn = True
    else:
        mon.unlimited_ability_uses_this_turn += 1
    if "VSTAR Power in a game" in (card.abilities[0].text or ""):
        player.used_vstar_power_this_game = True

    script = get_ability_script(mon.card_id, ability_name)
    if _try_offer_power_spray(state, card_db, actor, mon, mon.card_id, script, action.target_bench_index):
        return
    ctx = EffectContext(
        state=state,
        card_db=card_db,
        acting_player=actor,
        source_pokemon=mon,
        source_card_id=mon.card_id,
        target_bench_index=action.target_bench_index,
        rng=state.rng,
        effect_source="ability",
    )
    run_script(script, ctx)
    _resolve_incidental_knockouts(state, card_db)
    _apply_forced_turn_end(state, card_db)  # 特性を使ったら自分の番は終わる(選択待ちが残るときは、その解決後に終わる)


def _handle_retreat(state: GameState, card_db: CardDatabase, actor: int, action: Retreat) -> None:
    from engine.continuous import wild_growth_active

    player = state.player(actor)
    from effects.passives_ext import retreat_fails_by_coin

    if retreat_fails_by_coin(state, card_db, actor):
        player.retreated_this_turn = True  # Slimy Sliding: コストを払わず入れ替わらない(にげる行動は済んだ扱い)
        return
    active_card = card_db.get(player.active.card_id)
    base_cost = active_card.retreat_cost_count if active_card else 0
    cost = effective_retreat_cost_count(
        card_db,
        player.active,
        base_cost,
        state.stadium_in_play,
        player.turns_taken,
        owner_has_skyliner=has_skyliner_in_play(player),
        owner_has_dark_cloak=has_dark_cloak_in_play(player),
        owner_has_thunderclap_zone=has_thunderclap_zone_in_play(player),
    )
    double_grass = wild_growth_active(player)
    choice_count = retreat_discard_choice_count(card_db, player.active.attached_energy, cost, double_grass=double_grass)
    paid: list[str] = []
    if choice_count is None:
        paid = auto_select_retreat_payment(card_db, player.active.attached_energy, cost, double_grass=double_grass)
        from effects.era_tools_j import retreat_discards_to_hand

        for energy_id in paid:
            player.active.attached_energy.remove(energy_id)
            (player.hand if retreat_discards_to_hand(state, card_db, player.active.attached_tool, energy_id) else player.discard).append(energy_id)  # ダッシュポーチ/スケーターズパーク

    new_active = player.bench.pop(action.bench_index)
    old_active = player.active
    old_active.status.clear_all()
    player.bench.append(old_active)
    new_active.status.clear_all()
    new_active.became_active_turn = player.turns_taken
    player.active = new_active
    player.retreated_this_turn = True
    state.add_log(
        f"player{actor} が {card_name(card_db, old_active.card_id)} から {card_name(card_db, new_active.card_id)} ににげた"
    )
    from effects.era_tools_j import on_active_moved_to_bench

    on_active_moved_to_bench(state, card_db, actor, old_active)  # スパイクタウン

    # 「ベンチからバトル場に出たとき、してもよい」系の特性(ヒードランGXの「Burning Road」等)は、
    # apply_actionの_offer_become_active_triggerが原因を問わず(にげる含む)まとめて判定する。

    if choice_count is not None:
        # にげるコストとして手放すエネルギーをプレイヤーに選ばせる(全て同じ価値のときのみ)。
        # 道連れ等でold_activeがすでにきぜつ処理待ちの場合でも、ベンチに戻った時点のスロットを
        # そのまま参照すればよい(この時点でold_activeは必ずplayer.benchの末尾にいる)。
        bench_slot = len(player.bench) - 1
        state.pending_search_choice = PendingSearchChoice(
            player_index=actor,
            zone="retreat_energy_discard",
            source_indices=list(range(len(old_active.attached_energy))),
            card_ids=list(old_active.attached_energy),
            min_count=choice_count,
            max_count=choice_count,
            prompt=f"にげるためにトラッシュするエネルギーを{choice_count}枚選ぶ",
            shuffle_after=False,
            all_card_ids=list(old_active.attached_energy),
            custom_data={"bench_slot": bench_slot},
        )


def _reattach_boomerang_energy_after_attack(player: PlayerState, source_mon: PokemonInPlay, count_before: int) -> None:
    """ブーメランエネルギー実カードテキスト: "If this card is discarded by an effect of an attack
    used by the Pokémon this card is attached to, attach this card from your discard pile to that
    Pokémon after attacking."。count_beforeはワザを使う前についていた枚数(複数枚ついていた場合も
    正しく対応するため、「ついているか」の有無ではなく枚数の差分でワザの効果によるトラッシュ枚数を
    判定する)。ワザの「ダメージ」自体でトラッシュされるわけではない(ダメージでは通常エネルギーは
    トラッシュされない)ため、ここではワザの「効果」によるトラッシュのみを扱えば十分。ロストゾーンに
    送られた場合(トラッシュではない)は対象外(2026-08-25ユーザー報告「ブーメランエネルギーの効果が
    発動しません」で発覚。以前は無色エネルギートークンとしてのみ機能し、この再付け効果自体が
    完全に未実装だった)。"""
    if count_before <= 0 or special_energy_effects_suppressed():
        return
    count_after = source_mon.attached_energy.count(BOOMERANG_ENERGY_ID)
    discarded_count = count_before - count_after
    if discarded_count <= 0:
        return
    reattach_count = min(discarded_count, player.discard.count(BOOMERANG_ENERGY_ID))
    for _ in range(reattach_count):
        player.discard.remove(BOOMERANG_ENERGY_ID)
        source_mon.attached_energy.append(BOOMERANG_ENERGY_ID)


def _mark_ko_by_attack(state: GameState, card_db: CardDatabase, actor: int) -> None:
    """このワザで、相手のポケモンがダメージ計算を経由した実際のダメージ(ダメカンを直接のせる
    効果ではなく)を受けてきぜつ状態になったら、相手側に「自分のポケモンが相手のワザのダメージで
    きぜつした」フラグを立てる(毒リベンジ等の「直前の相手の番にきぜつしたか」判定/レガシー
    エネルギー/スプラッシュエネルギー/道連れの発動条件用。いずれも実カードテキストが
    「ワザによるダメージで」ときぜつの原因を明示しており、ドラパルトexの「Phantom Dive」の
    追加ダメカンのような「ダメージ計算を経由しない、ワザの効果でダメカンをのせる」だけの
    きぜつには適用されない。2026-08-25の公式FAQ監査で発覚: 以前はこの区別をせず、同じワザの
    中でダメカン付与効果だけできぜつした場合でも一律で発動条件を満たしてしまっていた)。
    実際のknockout処理(apply_knockouts)より前に呼ぶことで、まだ場に残っているダメージ状態から
    判定できる。あわせて、道連れ(Gastlyの「Destiny Bond」)が有効なポケモンがきぜつした場合は
    攻撃側のバトルポケモンも道連れできぜつさせ、スプラッシュエネルギーがついたみずポケモンが
    きぜつした場合はapply_knockoutsが後で手札に戻せるようフラグを立てる。"""
    player = state.player(actor)
    opponent = state.player(state.opponent_index(actor))
    for mon in opponent.all_pokemon_in_play():
        if not mon.hit_by_calculated_attack_damage:
            continue
        mon_card = card_db.get(mon.card_id)
        mon_max_hp = effective_max_hp(card_db, mon.card_id, mon.attached_tool, state.stadium_in_play, mon.attached_energy)
        if mon_card is not None and mon_max_hp and mon.is_knocked_out(mon_max_hp):
            opponent.pokemon_ko_by_attack_pending = True
            opponent.ko_by_attack_names_pending.append(mon_card.name)
            if player.active is not None:
                mon.ko_attacker_card_id = player.active.card_id
            from effects.passives import on_knocked_out_by_attack

            on_knocked_out_by_attack(
                EffectContext(
                    state=state, card_db=card_db, acting_player=actor, source_pokemon=player.active,
                    source_card_id=player.active.card_id if player.active is not None else "", rng=state.rng,
                    effect_source="ability",
                ),
                mon, state.opponent_index(actor),
            )
            if (
                mon.destiny_bond_until_turn > 0
                and player.turns_taken <= mon.destiny_bond_until_turn
                and player.active is not None
            ):
                attacker_max_hp = effective_max_hp(card_db, player.active.card_id, player.active.attached_tool, state.stadium_in_play, player.active.attached_energy)
                if attacker_max_hp and not player.active.is_knocked_out(attacker_max_hp):
                    player.active.damage = max(player.active.damage, attacker_max_hp)
                    state.add_log(
                        f"{card_name(card_db, mon.card_id)} の「道連れ」の効果で "
                        f"player{actor} の {card_name(card_db, player.active.card_id)} もきぜつした"
                    )
            if energy_effect_present(mon.attached_energy, SPLASH_ENERGY_ID) and "Water" in mon_card.types:
                mon.rescued_to_hand_pending = True
            from effects.era_trainers import on_mon_ko_by_attack

            on_mon_ko_by_attack(state, card_db, mon)  # レスキュースカーフ
            from effects.era_primitives_f import era_ko_retaliate

            era_ko_retaliate(state, card_db, actor, mon)  # Little Grudge
    if player.bonus_prize_name_prefix_this_turn is not None and opponent.active is not None:
        prefix, extra_prizes = player.bonus_prize_name_prefix_this_turn
        opponent_active_max_hp = effective_max_hp(card_db, opponent.active.card_id, opponent.active.attached_tool, state.stadium_in_play, opponent.active.attached_energy)
        attacker_card = card_db.get(player.active.card_id) if player.active is not None else None
        if (
            attacker_card is not None
            and attacker_card.name.startswith(prefix)
            and opponent_active_max_hp
            and opponent.active.is_knocked_out(opponent_active_max_hp)
        ):
            player.bonus_prize_next_knockout = extra_prizes  # Anthea & Concordia: 追加でサイドを取る
    if player.bonus_prize_if_tera_ko_this_turn and opponent.active is not None:
        opponent_active_max_hp = effective_max_hp(card_db, opponent.active.card_id, opponent.active.attached_tool, state.stadium_in_play, opponent.active.attached_energy)
        attacker_card = card_db.get(player.active.card_id) if player.active is not None else None
        if (
            attacker_card is not None
            and "Tera" in attacker_card.subtypes
            and opponent_active_max_hp
            and opponent.active.is_knocked_out(opponent_active_max_hp)
        ):
            player.bonus_prize_next_knockout = 1  # ブライアー: 追加でサイド+1


def _attacks_for_card(card_db: CardDatabase, card) -> tuple:
    """BREAK進化ルール: 自身のワザを持たないBREAKカードは進化元のワザ一覧を使う(ゲッコウガBREAK等)。"""
    if card.attacks or "BREAK" not in card.subtypes or not card.evolves_from:
        return card.attacks
    pre_evolution = next((c for c in card_db.find_by_name(card.evolves_from) if c.name == card.evolves_from), None)
    return pre_evolution.attacks if pre_evolution is not None else card.attacks


def _after_attack_trigger_needs_bench(after_script: tuple) -> bool:
    """AFTER_ATTACK_TRIGGER_EFFECTSのうち、自分をバトル場から離す系(ベンチと入れ替え/山札の下に
    戻す)は、代わりに出すベンチポケモンが無ければ提示する意味が無い。メタグロスの「Metallic
    Hammer」(自分のエネルギーを捨てて追加ダメージ)等、バトル場を離れない効果はベンチの有無を
    問わず提示してよい(2026-08-26、ベンチが無いだけで選択肢自体が出ない不具合として発覚)。"""
    from effects.primitives import MoveSelfAndAttachedToBottomOfDeck, ShuffleSelfIntoDeck, SwitchActiveWithBench

    return any(isinstance(e, (SwitchActiveWithBench, ShuffleSelfIntoDeck, MoveSelfAndAttachedToBottomOfDeck)) for e in after_script)


def _handle_attack(state: GameState, card_db: CardDatabase, actor: int, action: Attack) -> None:
    player = state.player(actor)
    player.pending_second_attack = False  # ホルビー/カミッチュ: 2回目のワザが始まったので、選択待ち状態は解除する
    # 前のワザで立った「ダメージ計算を経由した実際のダメージを受けたか」フラグ(レガシーエネルギー等の
    # 判定用)は、このワザの結果だけを反映するよう毎回ここでリセットする(_mark_ko_by_attack/
    # apply_knockoutsが読み終えるまで、ダメカン配分保留(Phantom Dive等)を挟んでも消えないよう、
    # あえて_mark_ko_by_attack側ではリセットしない設計にしている)。
    for mon in player.all_pokemon_in_play():
        mon.hit_by_calculated_attack_damage = False
    opponent_player = state.player(state.opponent_index(actor))
    for mon in opponent_player.all_pokemon_in_play():
        mon.hit_by_calculated_attack_damage = False
    active_card = card_db.get(player.active.card_id)
    attack = _attacks_for_card(card_db, active_card)[action.attack_index]

    jp_attack_name, _ = jp_attack(player.active.card_id, attack)
    success, self_damage = resolve_confusion_attack_check(player.active.status, state.rng)
    coin_blocked = False
    if success and player.active.attack_coinflip_until_turn > 0 and player.turns_taken <= player.active.attack_coinflip_until_turn:
        # 「ワザを使おうとしたら相手がコインを投げ、ウラならそのワザは失敗する」(Attract等)
        coin_blocked = state.rng.random() >= 0.5
    if coin_blocked:
        state.add_log(
            f"player{actor} の {card_name(card_db, player.active.card_id)} が「{jp_attack_name}」を出そうとしたが、"
            f"コインがウラでワザは失敗した"
        )
    elif not success:
        player.active.damage += self_damage
        state.add_log(
            f"player{actor} の {card_name(card_db, player.active.card_id)} が「{jp_attack_name}」を出そうとしたが"
            f"こんらんで失敗し、自分に{self_damage}ダメージ"
        )
    else:
        state.add_log(f"player{actor} の {card_name(card_db, player.active.card_id)} が「{jp_attack_name}」を使った")
        ctx = EffectContext(
            state=state,
            card_db=card_db,
            acting_player=actor,
            source_pokemon=player.active,
            source_card_id=player.active.card_id,
            target_bench_index=action.target_bench_index,
            rng=state.rng,
        )
        attacked_card_id = player.active.card_id
        player.active.current_attack_name = attack.name
        boomerang_count_before = ctx.source_pokemon.attached_energy.count(BOOMERANG_ENERGY_ID)
        run_script(get_attack_script(player.active.card_id, attack.name), ctx)
        from effects.era_sm_hooks import kos_bonus_prize_after_attack

        if not tools_disabled(state.stadium_in_play):
            player.bonus_prize_next_knockout += kos_bonus_prize_after_attack(state, card_db, ctx.source_pokemon, actor)  # ビーストブリンガー
        _reattach_boomerang_energy_after_attack(player, ctx.source_pokemon, boomerang_count_before)
        if "GX attack in a game" in (attack.text or ""):
            player.used_gx_attack_this_game = True
        if "VSTAR Power in a game" in (attack.text or ""):
            player.used_vstar_power_this_game = True
        player.last_attack_used = (attacked_card_id, attack.name)
        _mark_ko_by_attack(state, card_db, actor)

        if state.pending_search_choice is not None or state.pending_damage_distribution is not None:
            # Geomancy等、ワザの効果自体がプレイヤーの選択待ちで中断した場合はターンを進めない
            # (ResolveSearchChoice/ResolveDamageDistributionで再開されるまでここで待つ)。
            # ワザ由来と分かるようフラグを立てておき、選択が解決されたときにターンを終了させる
            # (タケルライコexの「Bellowing Thunder」等、ワザの効果自体が選択待ちになるケース)。
            if state.pending_search_choice is not None:
                state.pending_search_choice.then_end_turn = True
                # 「自由に分配」系(エナジーターボ等)のように選択が複数ラウンドに連鎖する効果は、
                # 各ラウンドの継続処理がcustom_data["then_end_turn"]を読んで次のPendingSearchChoiceを
                # 組み立て直す。ここで.then_end_turnだけ書き換えてcustom_dataを直さないと、2ラウンド目
                # 以降は「ワザ由来」の情報が失われて(構築時の既定値Falseのまま)ターンが終わらなくなる
                # (わざマシン エナジーターボ使用後にターンが終わらず、番の終わりのどうぐトラッシュも
                # 発動しない不具合の原因だった)。
                if isinstance(state.pending_search_choice.custom_data, dict):
                    state.pending_search_choice.custom_data["then_end_turn"] = True
            if state.pending_damage_distribution is not None:
                state.pending_damage_distribution.then_end_turn = True
            return

        if player.active is None:
            # ReturnSelfToHand等、ワザの効果でバトルポケモンが場からいなくなった(きぜつ以外のケース)。
            # きぜつ時の新アクティブ選択と同じ流れで、選択後にチェックアップ→ターン交代へ進める。
            state.pending_active_choice = [actor]
            state.then_after_choice = "checkup"
            return

        # ワザの後に「してもよい」効果(ウーラオスVの「Strafe」等)。メインの効果が選択待ちを
        # 残さず完了した場合のみ、続けてこの「してもよい」を提示する。
        after_script = get_after_attack_trigger_script(player.active.card_id, attack.name)
        if (
            after_script
            and (player.bench or not _after_attack_trigger_needs_bench(after_script))
            and state.pending_search_choice is None
            and state.pending_damage_distribution is None
        ):
            _set_pending_trigger(
                state,
                actor,
                player.active.card_id,
                player.active,
                after_script,
                then_end_turn=True,
                override_kind="ワザ",
                override_label=jp_attack_name,
                mandatory=is_mandatory_after_attack_trigger(player.active.card_id, attack.name),
            )
            return

    _finish_attack_or_offer_second(state, card_db)


def _handle_use_borrowed_attack(
    state: GameState, card_db: CardDatabase, actor: int, action: UseBorrowedAttack
) -> None:
    """ミュウツー&ミュウGXの特性「パーフェクション」: ベンチ/トラッシュのGX/EXポケモンのワザを借りて使う。"""
    player = state.player(actor)
    player.pending_second_attack = False  # ホルビー/カミッチュ: 2回目のワザが始まったので、選択待ち状態は解除する
    source_card = card_db.get(action.source_card_id)
    attack = next(a for a in source_card.attacks if a.name == action.attack_name)
    jp_attack_name, _ = jp_attack(action.source_card_id, attack)

    success, self_damage = resolve_confusion_attack_check(player.active.status, state.rng)
    if not success:
        player.active.damage += self_damage
        state.add_log(
            f"player{actor} の {card_name(card_db, player.active.card_id)} が「{jp_attack_name}」"
            f"({card_name(card_db, action.source_card_id)}のワザを借用)を出そうとしたがこんらんで失敗し、自分に{self_damage}ダメージ"
        )
    else:
        state.add_log(
            f"player{actor} の {card_name(card_db, player.active.card_id)} が"
            f"{card_name(card_db, action.source_card_id)}のワザ「{jp_attack_name}」を借りて使った"
        )
        ctx = EffectContext(
            state=state,
            card_db=card_db,
            acting_player=actor,
            source_pokemon=player.active,
            source_card_id=player.active.card_id,
            target_bench_index=action.target_bench_index,
            rng=state.rng,
        )
        boomerang_count_before = ctx.source_pokemon.attached_energy.count(BOOMERANG_ENERGY_ID)
        ctx.source_pokemon.current_attack_name = attack.name
        run_script(get_attack_script(action.source_card_id, attack.name), ctx)
        _reattach_boomerang_energy_after_attack(player, ctx.source_pokemon, boomerang_count_before)
        player.last_attack_used = (action.source_card_id, attack.name)
        if "VSTAR Power in a game" in (attack.text or ""):
            player.used_vstar_power_this_game = True  # シールストーン等のどうぐのVSTARパワー

        # ゾロアークGXの「トリックスターGX」等: コピー元は通常ワザでも、コピーする側自身のワザ(このカードの
        # own_attack_name)がGXワザなら1ゲーム1回のカウントを消費する。
        copy_config = ATTACK_COPY_SOURCES.get(player.active.card_id) if player.active is not None else None
        if copy_config is not None:
            own_card = card_db.get(player.active.card_id)
            own_attack = next(
                (a for a in (own_card.attacks if own_card else ()) if a.name == copy_config["own_attack_name"]), None
            )
            if own_attack is not None and "GX attack in a game" in (own_attack.text or ""):
                player.used_gx_attack_this_game = True

        if state.pending_search_choice is not None or state.pending_damage_distribution is not None:
            # _handle_attackと同じ理由(ワザマシン エヴォリューション等の借用ワザ自体の効果が選択待ちで
            # 中断した場合、選択が解決されるまでターンを進めず、解決時にターンを終了させる)。
            # 以前はここでthen_end_turnを立てていなかったため、ワザマシン エヴォリューションを使っても
            # ターンが終わらないバグになっていた。
            if state.pending_search_choice is not None:
                state.pending_search_choice.then_end_turn = True
                # _handle_attackと同じ理由: 複数ラウンドに連鎖する選択(エナジーターボ等)は
                # custom_data["then_end_turn"]も直さないと2ラウンド目以降でターンが終わらなくなる。
                if isinstance(state.pending_search_choice.custom_data, dict):
                    state.pending_search_choice.custom_data["then_end_turn"] = True
            if state.pending_damage_distribution is not None:
                state.pending_damage_distribution.then_end_turn = True
            return

        if player.active is None:
            state.pending_active_choice = [actor]
            state.then_after_choice = "checkup"
            return

        # _handle_attackと同じ理由: 借りたワザ自身に「ワザ後にしてもよい」効果(メタグロスの
        # 「Metallic Hammer」等)が登録されている場合、借りて使ったときも同様に提示する。
        # コピー元(action.source_card_id)ではなく実際に攻撃しているポケモン(player.active)
        # 自身を発動元にする(自己参照効果はコピー元ではなく借用者自身を見るという既存ルール通り)。
        after_script = get_after_attack_trigger_script(action.source_card_id, attack.name)
        if (
            after_script
            and (player.bench or not _after_attack_trigger_needs_bench(after_script))
            and state.pending_search_choice is None
            and state.pending_damage_distribution is None
        ):
            _set_pending_trigger(
                state,
                actor,
                player.active.card_id,
                player.active,
                after_script,
                then_end_turn=True,
                override_kind="ワザ",
                override_label=jp_attack_name,
                mandatory=is_mandatory_after_attack_trigger(action.source_card_id, attack.name),
            )
            return

    _finish_attack_or_offer_second(state, card_db)


def _handle_end_turn(state: GameState, card_db: CardDatabase, actor: int, action: EndTurn) -> None:
    _end_current_turn(state, card_db)


def _handle_choose_new_active(state: GameState, card_db: CardDatabase, actor: int, action: ChooseNewActive) -> None:
    player = state.player(actor)
    new_active = player.bench.pop(action.bench_index)
    new_active.status.clear_all()
    player.active = new_active
    state.add_log(f"player{actor} が {card_name(card_db, new_active.card_id)} を新しいバトルポケモンにした")
    state.pending_active_choice = [p for p in state.pending_active_choice if p != actor]

    if state.pending_active_choice:
        return

    check_win_conditions(state)
    if state.is_game_over():
        return

    if state.then_after_choice == "checkup":
        _run_checkup_and_advance(state, card_db)
    elif state.then_after_choice == "advance":
        advance_turn(state, card_db)
    elif state.then_after_choice == "attack_again":
        # ホルビーの「Ω Barrage」/カミッチュの「おまつりおんど」: 相手が新アクティブを選び終えた
        # ので、もう一度ワザを使うか選べる状態にする(_finish_attack_or_offer_second参照)。
        state.player(state.current_player).pending_second_attack = True
    else:
        # "continue" は通常、現在のプレイヤーのメインフェーズを継続する合図だが、ワザの効果
        # (ダメカン配分等)の途中できぜつ→新アクティブ選択が発生していた場合はターンを終了させる
        # 必要がある(ファントムダイブ等、_resolve_incidental_knockoutsのthen_end_turn伝播と対応)。
        then_end_turn = state.then_end_turn_after_active_choice
        state.then_end_turn_after_active_choice = False
        _maybe_end_turn_after_pending_choice(state, card_db, then_end_turn)


_OPPONENT_TURN_END_DISCARD_TOOL_IDS = {"xy9-97"}  # 炸裂バルーン(Bursting Balloon): ついている側の相手の番の終わりにトラッシュされる


def _discard_end_of_turn_tools(state: GameState, card_db: CardDatabase) -> None:
    """わざマシン各種: ついている番の終わりにトラッシュされるどうぐを処理する。
    ジャミングタワー等のどうぐ無効化スタジアムが出ている間は、この自己トラッシュ効果自体もどうぐの
    効果の一部として無効化されるため発動しない(公式Q&Aで確認、2026-08-25発覚: 以前はtools_disabled
    を一切見ておらず、ジャミングタワー下でもわざマシンが番の終わりにトラッシュされてしまっていた)。"""
    from engine.continuous import tools_disabled
    from engine.legal_actions import END_OF_TURN_DISCARD_TOOL_IDS

    player = state.player(state.current_player)
    opponent = state.player(state.opponent_index(state.current_player))
    if not tools_disabled(state.stadium_in_play):
        for mon in player.all_pokemon_in_play():
            if mon.attached_tool in END_OF_TURN_DISCARD_TOOL_IDS:
                discard_attached_tool(state, player, mon)

        for mon in opponent.all_pokemon_in_play():
            if mon.attached_tool in _OPPONENT_TURN_END_DISCARD_TOOL_IDS:
                discard_attached_tool(state, opponent, mon)

    from engine.energy import IGNITION_ENERGY_ID, IGNITION_ENERGY_REPRINT_ID

    for mon in player.all_pokemon_in_play():
        for ignition_id in (IGNITION_ENERGY_ID, IGNITION_ENERGY_REPRINT_ID):
            if energy_effect_present(mon.attached_energy, ignition_id):
                mon.attached_energy.remove(ignition_id)
                player.discard.append(ignition_id)


def _start_prize_choice(
    state: GameState,
    queue: list[tuple[int, int]],
    needs_new_active: list[int],
    then_after_choice: str,
    then_end_turn: bool = False,
) -> None:
    """apply_knockoutsが返した「どのサイドを取るか選ぶ必要がある」キューの先頭を
    PendingSearchChoiceとして立てる(実カードルール通り、プレイヤーは自分の残りサイドを
    見て自由に選んで取れる)。残りのキュー・新アクティブ選択・その後の続き(checkup/advance/
    continue)はcustom_dataに保持し、_handle_resolve_search_choiceのown_prizes_take分岐で
    1つずつ消化していく。then_end_turn: ワザの効果(ダメカン配分等)の途中できぜつが発生した場合、
    then_after_choice="continue"であってもこのサイド選択が解決され次第ターンを終了させる必要がある
    (ファントムダイブ等。Turbo Energize等と同根のthen_end_turn/custom_data staleness対策)。"""
    player_index, count = queue[0]
    player = state.player(player_index)
    # countはapply_knockouts側で「このきぜつ単独で見て何枚取るべきか」を計算した時点の値で、
    # 同時に複数のきぜつが起きてキューに複数件積まれている場合、後続のキュー分を解決する頃には
    # 先に解決された選択で既にサイドが減っている(=count時点の前提が古くなっている)。ここで
    # 実際に残っているサイド枚数にクランプしないと、例えば「2枚取る」が2件キューにあるのに
    # 残りサイドが合計3枚しか無いようなケースで、2件目の選択がmin_count=2のまま残りサイド1枚
    # (=選択の余地が無いのに2枚選べと要求する)という矛盾した状態になり、行動不能でスタックして
    # いた(2026-09-02ユーザー報告「サイドを２枚や三枚取るときに残りのサイドが１枚だと、
    # サイドを最低２枚選べずにスタックしました」)。
    count = min(count, len(player.prizes))
    state.pending_search_choice = PendingSearchChoice(
        player_index=player_index,
        zone="own_prizes_take",
        source_indices=list(range(len(player.prizes))),
        card_ids=list(player.prizes),
        min_count=count,
        max_count=count,
        prompt=f"取るサイドを{count}枚選ぶ",
        shuffle_after=False,
        all_card_ids=list(player.prizes),
        reveal_to_opponent=False,
        then_end_turn=then_end_turn,
        custom_data={
            "mode": "own_prizes_take",
            "remaining_prize_queue": queue[1:],
            "needs_new_active": needs_new_active,
            "then_after_choice": then_after_choice,
            "then_end_turn": then_end_turn,
        },
    )


def _start_knockout_followups(
    state: GameState,
    needs_new_active: list[int],
    needs_prize_choice: list[tuple[int, int]],
    then_after_choice: str,
    then_end_turn: bool = False,
    card_db: CardDatabase | None = None,
) -> bool:
    """apply_knockouts()の戻り値を受け、サイド選択→新アクティブ選択の順で必要な保留を立てる
    (サイド選択の方を先に解決する: 実際のゲームでもきぜつ直後にまずサイドを取ってから、
    バトルポケモンがいなくなった側が新しいポケモンを出す)。何か保留を立てたらTrueを返すので、
    呼び出し側はその場でreturnしてよい。then_end_turnはワザ由来の保留かどうかを、この後に
    立てる選択に伝播させるためのフラグ(呼び出し側で参照)。
    きぜつ時に発動するどうぐ等の効果(state.ko_followups: エキスパートシェア/リバーサルトリガー)があれば、
    サイド選択・新アクティブ選択より先に1つずつ選ばせる(選択が終わったら_resume_after_ko_followupsで続きに戻る)。"""
    while state.ko_followups and card_db is not None:
        entry = state.ko_followups.pop(0)
        from effects.era_trainers import start_ko_followup

        cont = {
            "needs_new_active": list(needs_new_active), "needs_prize_choice": list(needs_prize_choice),
            "then_after_choice": then_after_choice, "then_end_turn": then_end_turn,
        }
        if start_ko_followup(state, card_db, entry, cont):
            return True
    if needs_prize_choice:
        _start_prize_choice(state, needs_prize_choice, needs_new_active, then_after_choice, then_end_turn=then_end_turn)
        return True
    if needs_new_active:
        state.pending_active_choice = needs_new_active
        state.then_after_choice = then_after_choice
        state.then_end_turn_after_active_choice = then_end_turn
        return True
    return False


def _finish_attack_or_offer_second(state: GameState, card_db: CardDatabase) -> None:
    """ワザの解決が完了し、通常であればそのままターンを終了する場面で呼ぶ。ホルビーの
    「Ω Barrage」/カミッチュの「おまつりおんど」の対象なら、このワザによるきぜつを即座に処理し
    (相手の新アクティブ選択・サイド選択が必要ならそちらを先に解決してから)、もう一度ワザを
    使うか選べる状態(player.pending_second_attack)にする。対象外、またはこの番で既にこの
    ボーナス攻撃を使い切っていれば、通常通りターンを終了する。"""
    from engine.continuous import attack_twice_eligible

    player = state.player(state.current_player)
    if not attack_twice_eligible(state, player):
        _end_current_turn(state, card_db)
        return
    player.used_attack_twice_bonus_this_turn = True
    needs_new_active, needs_prize_choice = apply_knockouts(state, card_db)
    if _start_knockout_followups(state, needs_new_active, needs_prize_choice, "attack_again", card_db=card_db):
        return
    check_win_conditions(state)
    if state.is_game_over():
        return
    player.pending_second_attack = True
    state.add_log(f"player{state.current_player} はもう一度ワザを使うか選べる")


def _apply_end_of_turn_player_effects(state: GameState, card_db: CardDatabase) -> bool:
    """「この番の終わりに」発動するカードの効果(ブルーのたくらみ=手札がN枚になるまで引く/リーリエの全力=手札を山札に戻す)。
    選択が必要なとき(手札を山札に戻す)は選択待ちを作ってTrueを返す(選択が終わるとターンの終了処理がもう一度呼ばれる)。"""
    player = state.player(state.current_player)
    if player.end_turn_draw_to:
        target = player.end_turn_draw_to
        player.end_turn_draw_to = 0
        while len(player.hand) < target and player.deck:
            player.hand.append(player.deck.pop(0))
        state.add_log(f"番の終わりに、手札が{len(player.hand)}枚になるまで山札を引いた")
    if player.end_turn_hand_limit is not None:
        threshold, keep = player.end_turn_hand_limit
        player.end_turn_hand_limit = None
        if len(player.hand) >= threshold:
            n = len(player.hand) - keep
            state.pending_search_choice = PendingSearchChoice(
                player_index=state.current_player,
                zone="hand",
                source_indices=list(range(len(player.hand))),
                card_ids=list(player.hand),
                min_count=n,
                max_count=n,
                prompt=f"番の終わりに、手札が{keep}枚になるまで、山札に戻す手札を{n}枚選ぶ",
                shuffle_after=True,
                all_card_ids=list(player.hand),
                destination="deck",
                then_end_turn=True,
            )
            return True
    from engine.continuous import tools_disabled

    if not tools_disabled(state.stadium_in_play):
        from effects.era_tools_j import start_powerglass

        if start_powerglass(state, card_db):  # パワフルグラス: 番の終わりにトラッシュの基本エネルギーをつけてもよい
            return True
    return False


def _end_current_turn(state: GameState, card_db: CardDatabase) -> None:
    if _apply_end_of_turn_player_effects(state, card_db):
        return
    _discard_end_of_turn_tools(state, card_db)
    from effects.era_primitives_f import era_end_of_turn_removals
    from effects.era_trainers import era_end_of_turn_tools

    era_end_of_turn_removals(state, card_db)  # Doom Desire/Cacophony
    era_end_of_turn_tools(state, card_db)  # フローラルクラウン
    needs_new_active, needs_prize_choice = apply_knockouts(state, card_db)
    if _start_knockout_followups(state, needs_new_active, needs_prize_choice, "checkup", card_db=card_db):
        return
    check_win_conditions(state)
    if state.is_game_over():
        return
    _run_checkup_and_advance(state, card_db)


_SHRINE_OF_PUNISHMENT_ID = "sm7-143"  # 戒めの祠
_GX_EX_SUBTYPES_FOR_STADIUM = {"GX", "EX"}  # 実カードテキストは"Pokémon-GX and Pokémon-EX"限定(現行の小文字"ex"は対象外)


def _apply_between_turns_stadium_effects(state: GameState, card_db: CardDatabase) -> None:
    """「番の合間に」発動するスタジアム効果(戒めの祠等)。ターン終了処理の中で1度だけ呼ばれる。"""
    from effects.era_trainers import era_between_turns

    era_between_turns(state, card_db)  # ふるびたまち
    if state.stadium_in_play != _SHRINE_OF_PUNISHMENT_ID:
        return
    from effects.primitives import _blocks_damage_counters
    from engine.continuous import tools_disabled

    if tools_disabled(state.stadium_in_play):
        return
    hit_names = []
    for player in state.players:
        for mon in player.all_pokemon_in_play():
            card = card_db.get(mon.card_id)
            if card is None or not (_GX_EX_SUBTYPES_FOR_STADIUM & set(card.subtypes)):
                continue
            if _blocks_damage_counters(mon):
                continue
            mon.damage += 10
            hit_names.append(card_name(card_db, mon.card_id))
    if hit_names:
        state.add_log(f"戒めの祠の効果で {', '.join(hit_names)} にダメカンがのった")


def _run_checkup_and_advance(state: GameState, card_db: CardDatabase) -> None:
    if not state.extra_turn_pending:  # 「もう1回自分の番を行う」ときは、ポケモンチェックを飛ばす
        _apply_between_turns_stadium_effects(state, card_db)
        run_pokemon_checkup(state, card_db)
    from engine.continuous import tools_disabled as _tools_off

    if not _tools_off(state.stadium_in_play):
        from effects.era_tools_j import between_turns

        between_turns(state, card_db)  # オボンのみ/ラムのみ/ふっかつジェリー
    needs_new_active, needs_prize_choice = apply_knockouts(state, card_db)
    if _start_knockout_followups(state, needs_new_active, needs_prize_choice, "advance", card_db=card_db):
        return
    check_win_conditions(state)
    if state.is_game_over():
        return
    advance_turn(state, card_db)


def _start_bench_limit_discard_choice(
    state: GameState,
    card_db: CardDatabase,
    player_index: int,
    remaining_players: list[int],
    then_end_turn: bool = False,
    needs_new_active: list[int] | None = None,
    needs_prize_choice: list[tuple[int, int]] | None = None,
    then_after_choice: str = "continue",
) -> None:
    from engine.continuous import effective_bench_limit

    player = state.player(player_index)
    limit = effective_bench_limit(state, player, card_db)
    excess = len(player.bench) - limit
    state.pending_search_choice = PendingSearchChoice(
        player_index=player_index,
        zone="own_pokemon_target",
        source_indices=list(range(1, len(player.bench) + 1)),
        card_ids=[mon.card_id for mon in player.bench],
        min_count=excess,
        max_count=excess,
        prompt=f"ベンチの上限({limit}体)を超えたため、トラッシュする{excess}体を選ぶ",
        shuffle_after=False,
        all_card_ids=[mon.card_id for mon in player.bench],
        then_end_turn=then_end_turn,
        custom_data={
            "mode": "bench_limit_discard",
            "remaining_players": remaining_players,
            "then_end_turn": then_end_turn,
            # apply_knockouts()はきぜつしたポケモンを場から取り除きながら結果を返すため、この選択の
            # 解決後に改めてapply_knockouts()を呼び直しても同じ結果は再現できない(既にトラッシュ済み
            # で「きぜつしたポケモンが無い」と判定されてしまう)。そのため、この選択を挟む時点で
            # 判明していたneeds_new_active/needs_prize_choiceをそのままここに保持しておき、
            # 選択解決後に再開する。
            "needs_new_active": list(needs_new_active or []),
            "needs_prize_choice": list(needs_prize_choice or []),
            "then_after_choice": then_after_choice,
        },
    )


def _enforce_bench_limits(
    state: GameState,
    card_db: CardDatabase,
    priority_player: int | None = None,
    then_end_turn: bool = False,
    needs_new_active: list[int] | None = None,
    needs_prize_choice: list[tuple[int, int]] | None = None,
    then_after_choice: str = "continue",
) -> bool:
    """ベンチの上限(通常5、ゼロの大空洞+自分の場のテラスタルポケモンで8等)を超えているプレイヤーが
    いれば、実カードルール通りプレイヤー自身に好きな組み合わせを選ばせてトラッシュする
    (以前はベンチの末尾から機械的にトラッシュするv1簡略版だった)。priority_player指定時は
    そのプレイヤーから先に選ばせる(ゼロの大空洞が場を離れるとき「出した本人が先に選ぶ」実カード
    ルールに対応)。選択が発生すればTrueを返す(呼び出し側はその場でreturnしてよい)。
    needs_new_active/needs_prize_choice/then_after_choiceは、この選択の裏で既に判明している
    きぜつ後続処理(サイド選択/新アクティブ選択)がある場合に、選択解決後へ持ち越すためのもの。"""
    from engine.continuous import effective_bench_limit

    order = list(range(len(state.players)))
    if priority_player is not None and priority_player in order:
        order.remove(priority_player)
        order.insert(0, priority_player)
    players_over = [i for i in order if len(state.players[i].bench) > effective_bench_limit(state, state.players[i], card_db)]
    if not players_over:
        return False
    _start_bench_limit_discard_choice(
        state, card_db, players_over[0], players_over[1:], then_end_turn=then_end_turn,
        needs_new_active=needs_new_active, needs_prize_choice=needs_prize_choice, then_after_choice=then_after_choice,
    )
    return True


def _resolve_incidental_knockouts(state: GameState, card_db: CardDatabase, then_end_turn: bool = False) -> None:
    """ワザ以外(道具・サポート・特性)の効果でもきぜつが起こりうるので念のため処理する。

    効果の実行中に(検索の連鎖等で)新たなpending_search_choiceが既に立っている場合はここでは
    何もしない: pending_active_choiceを同時に立ててしまうと、次のResolveSearchChoiceが
    next_actor()経由でブロックされてしまう(両方待ちの膠着状態になる)。きぜつ処理は、その
    search_choiceが解決されたあと(=このヘルパーが再度呼ばれるタイミング)まで先送りすれば安全。

    then_end_turn: ワザの効果(ダメカン配分の保留等)を経由してこのきぜつ処理に辿り着いた場合はTrue。
    ここでサイド選択/新アクティブ選択が新たに発生すると、その解決はthen_after_choice="continue"
    (=現在のプレイヤーのメインフェーズを継続)扱いになるが、本来はワザ後なのでターンを終了させる
    必要がある。そのためthen_end_turnをその先の選択にも伝播させる(ファントムダイブ等、ダメカン配分の
    保留を経由してきぜつが起きるカードでターンが永遠に終わらなくなっていたバグの対策)。
    """
    if state.pending_search_choice is not None:
        return
    needs_new_active, needs_prize_choice = apply_knockouts(state, card_db)
    if _enforce_bench_limits(
        state, card_db, then_end_turn=then_end_turn,
        needs_new_active=needs_new_active, needs_prize_choice=needs_prize_choice, then_after_choice="continue",
    ):
        # ベンチ上限超過の選択が発生した場合、apply_knockouts()が返したneeds_new_active/
        # needs_prize_choiceはこの選択のcustom_dataに保持され、選択解決後(bench_limit_discard
        # モードの末尾)に改めて処理される。
        return
    if _start_knockout_followups(state, needs_new_active, needs_prize_choice, "continue", then_end_turn=then_end_turn, card_db=card_db):
        return
    check_win_conditions(state)


_HANDLERS = {
    PlayBasicPokemon: _handle_play_basic,
    Evolve: _handle_evolve,
    PlayLevelUp: _handle_level_up,
    AttachEnergy: _handle_attach_energy,
    PlayItem: _handle_play_item,
    PlaySupporter: _handle_play_supporter,
    PlayStadium: _handle_play_stadium,
    UseStadiumAbility: _handle_use_stadium_ability,
    UseDiscardAbility: _handle_use_discard_ability,
    PlayPokemonTool: _handle_play_pokemon_tool,
    UseAbility: _handle_use_ability,
    Retreat: _handle_retreat,
    DiscardRoboSubstitute: _handle_discard_robo_substitute,
    Attack: _handle_attack,
    UseBorrowedAttack: _handle_use_borrowed_attack,
    EndTurn: _handle_end_turn,
    ChooseInitialActive: _handle_choose_initial_active,
    ConfirmSetupDone: _handle_confirm_setup_done,
    ChooseMulliganBonusDrawCount: _handle_choose_mulligan_bonus_draw_count,
    ResolveSearchChoice: _handle_resolve_search_choice,
    ResolveDamageDistribution: _handle_resolve_damage_distribution,
    AcceptTrigger: _handle_accept_trigger,
    DeclineTrigger: _handle_decline_trigger,
    UsePowerSpray: _handle_use_power_spray,
    PassPowerSprayWindow: _handle_pass_power_spray_window,
}


# 同名・同文面の再録カードのIDを、実装済みの代表カードのIDテーブルに足す(effects/card_aliases.py)
from effects.card_aliases import apply_aliases as _apply_card_aliases  # noqa: E402

from effects.era_special import install as _install_era_special  # noqa: E402
from effects.era_trainers import install as _install_era_trainers  # noqa: E402

_install_era_trainers()
_install_era_special()
_apply_card_aliases()
