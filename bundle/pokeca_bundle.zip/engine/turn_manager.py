"""ゲーム開始処理・ターンの開始/終了・ポケモンチェックを扱う。"""

from __future__ import annotations

import random

from cards.card_db import CardDatabase
from engine.ruleset import DEFAULT_RULESET, Ruleset
from engine.state import GameState, PRIZE_COUNT, PlayerState, STARTING_HAND_SIZE
from engine.status import resolve_pokemon_checkup


def _is_basic_pokemon(card_db: CardDatabase, card_id: str) -> bool:
    card = card_db.get(card_id)
    return card is not None and card.is_basic


def _draw_opening_hand(deck: list[str], card_db: CardDatabase, rng: random.Random, goes_second: bool = False) -> tuple[list[str], list[str], int]:
    """たねポケモンが1枚もない手札はマリガン(引き直し)する。戻り値にマリガン回数を含む
    (公式ルール: マリガンした回数ぶん、相手はサイドを置いたあとにボーナスドローできる。ただし
    両者がマリガンした場合は相殺され、回数の少ない側だけが差分ぶん引ける)。"""
    working_deck = list(deck)
    mulligans = 0
    for _ in range(50):
        rng.shuffle(working_deck)
        hand = working_deck[:STARTING_HAND_SIZE]
        rest = working_deck[STARTING_HAND_SIZE:]
        from engine.legal_actions import setup_face_down_modes

        # たねポケモンが無くても、裏向きにバトル場へ出せる特性(Gale Wings等)のポケモンがあればマリガンしない
        if any(_is_basic_pokemon(card_db, c) or "active" in setup_face_down_modes(card_db, c, goes_second) for c in hand):
            return hand, rest, mulligans
        working_deck = hand + rest
        mulligans += 1
    # 50回試しても失敗したら諦めてそのまま返す(理論上ほぼ起こらない)
    rng.shuffle(working_deck)
    return working_deck[:STARTING_HAND_SIZE], working_deck[STARTING_HAND_SIZE:], mulligans


def deal_starting_hands(
    deck_a: list[str],
    deck_b: list[str],
    card_db: CardDatabase,
    rng: random.Random | None = None,
    ruleset: Ruleset = DEFAULT_RULESET,
) -> GameState:
    """じゃんけん(コイン)で先攻・後攻を決め、マリガン+ボーナスドローも含めて手札・サイドを準備する。
    先攻/後攻はstate.first_playerで管理し、deck_a/deck_b自体は入れ替えない(players[0]は常にdeck_a、
    players[1]は常にdeck_b。以前はここでdeck_a/deck_bを入れ替えて「players[0]が常に先攻」としていたが、
    Webアプリ側は「player0=常に人間が操作する座席」という前提でplayer1_agentを振り分けているため、
    コイントスの結果によってplayer0とplayer1の中身(=人間かAIか)が入れ替わってしまうバグになっていた)。"""
    rng = rng or random.Random()
    log_entries: list[str] = []

    # コイントスで先攻・後攻を決める(公式は「じゃんけん」だが確率的な意味は同じ)
    first_player = 0 if rng.random() < 0.5 else 1
    log_entries.append(f"コイントスの結果、player{first_player} が先攻、player{1 - first_player} が後攻")

    hand_a, rest_a, mulligans_a = _draw_opening_hand(deck_a, card_db, rng, goes_second=first_player != 0)
    hand_b, rest_b, mulligans_b = _draw_opening_hand(deck_b, card_db, rng, goes_second=first_player != 1)
    log_entries.append("player0 が初期手札7枚を引いた")
    if mulligans_a:
        log_entries.append(f"player0 はたねポケモンがなくマリガン({mulligans_a}回引き直した)")
    log_entries.append("player1 が初期手札7枚を引いた")
    if mulligans_b:
        log_entries.append(f"player1 はたねポケモンがなくマリガン({mulligans_b}回引き直した)")

    prizes_a, deck_a_final = rest_a[:PRIZE_COUNT], rest_a[PRIZE_COUNT:]
    prizes_b, deck_b_final = rest_b[:PRIZE_COUNT], rest_b[PRIZE_COUNT:]

    # マリガンした回数ぶんのボーナスドローは、公式ルール上バトル/ベンチポケモンを両者が置き終えて
    # サイドを準備した「後」に行う(準備中の手札に混ざって初期配置に使われてしまわないようにするため)。
    # ここでは保留しておき、対戦準備完了時(_handle_confirm_setup_done)に引かせる。
    # 2026-09-23発覚: 両者がマリガンした場合は相殺し、マリガン回数の少ない側だけがその差分だけ
    # ボーナスドローできる(公式Play! Pokémon TCG Tournament Handbookの裁定: 例えば両者とも2回
    # マリガンした後、片方がさらに3回マリガンしたら、もう片方は3枚まで引ける=差分の3枚)。
    # 以前は相手の生のマリガン回数をそのまま渡しており、自分のマリガン回数が引かれず相殺されて
    # いなかった(例: 自分2回/相手1回のケースで、本来は相手が1枚引けるだけなのに、実装では
    # 自分も1枚・相手も2枚引けてしまっていた)。
    bonus_draws_a = max(0, mulligans_b - mulligans_a)
    bonus_draws_b = max(0, mulligans_a - mulligans_b)

    player_a = PlayerState(deck=deck_a_final, hand=hand_a, prizes=prizes_a)
    player_b = PlayerState(deck=deck_b_final, hand=hand_b, prizes=prizes_b)
    from effects.era_trainers import apply_first_ticket

    first_player = apply_first_ticket((player_a, player_b), first_player, log_entries)  # ファーストチケット

    return GameState(
        players=(player_a, player_b),
        rng=rng,
        ruleset=ruleset,
        setup_complete=False,
        first_player=first_player,
        setup_player=first_player,  # 対戦準備は先攻側から選ぶ
        log=log_entries,
        pending_mulligan_bonus_draws=(bonus_draws_a, bonus_draws_b),
    )


def begin_game(state: GameState, card_db: CardDatabase) -> None:
    state.turn_number = 1
    state.current_player = state.first_player
    state.is_first_turn_of_game = True
    start_turn(state, card_db)


def start_turn(state: GameState, card_db: CardDatabase) -> None:
    player = state.player(state.current_player)
    player.turns_taken += 1
    player.reset_turn_flags()
    from effects.era_primitives_f import era_reset_turn_marks

    era_reset_turn_marks(state)
    state.add_log(f"――― player{state.current_player} のターン{state.turn_number} ―――")

    # 番の最初に山札を1枚引く。先攻プレイヤーの最初の番も引く(2026-09-25、ユーザー指摘で修正。
    # 先攻の最初の番にできないのはワザ・サポート・進化であって、ドローではない。公式「上級プレイヤー用
    # ルールガイド Ver.3.4」p.13にも、自分の番の最初に山札を引けなかった場合は負け、とあり例外の記載は無い)。
    # ただし過去のレギュレーション(日本のADV〜DP期、英語版2004〜2006年)は先攻の最初の番に引けなかった
    # (engine/ruleset.pyのfirst_player_draws_turn1、2026-10-03)。現行を含む既存のレギュレーションは全て引く。
    if state.turn_number == 1 and not state.ruleset.first_player_draws_turn1:
        state.is_first_turn_of_game = False
        return
    if player.no_turn_draw_on_turn > 0 and player.no_turn_draw_on_turn == player.turns_taken:
        state.add_log(f"player{state.current_player} は効果で番のはじめに山札を引けない")
        state.is_first_turn_of_game = False
        return
    if not player.deck:
        state.winner = state.opponent_index(state.current_player)
        state.win_reason = "deck_out"
        state.add_log(f"player{state.current_player} は山札切れで敗北")
        return
    drawn = player.deck.pop(0)
    from effects.era_tools_j import offer_on_draw

    if not offer_on_draw(state, card_db, state.current_player, drawn):  # ナゲット/トップエントリー: 手札に加える前に使う/出すか選ぶ
        player.hand.append(drawn)
    state.add_log(f"player{state.current_player} が山札から1枚引いた")

    state.is_first_turn_of_game = False


def advance_turn(state: GameState, card_db: CardDatabase) -> None:
    if state.extra_turn_pending:
        state.extra_turn_pending = False  # 同じプレイヤーがもう1回番を行う(相手に番は渡らない)
        state.turn_number += 1
        start_turn(state, card_db)
        return
    state.current_player = state.opponent_index(state.current_player)
    state.turn_number += 1
    start_turn(state, card_db)


def setup_new_game(
    deck_a: list[str],
    deck_b: list[str],
    card_db: CardDatabase,
    rng: random.Random | None = None,
    ruleset: Ruleset = DEFAULT_RULESET,
) -> GameState:
    """シャッフル・マリガン・サイド配置までを行う。バトルポケモンの選択(対戦準備フェーズ)は
    プレイヤー自身の行動(ChooseInitialActive/ConfirmSetupDone)で行い、両者が準備完了した
    時点で `rules_engine` が自動的に `begin_game` を呼んで1ターン目を開始する。"""
    return deal_starting_hands(deck_a, deck_b, card_db, rng, ruleset=ruleset)


_VIRBANK_CITY_GYM_ID = "bw8-126"  # タチワキシティジム: 両プレイヤーのどく状態のポケモンにダメカンを2個追加
_MOMOWAROU_TOXIC_ID = "sv8-momowarou"  # モモワロウ「もうどくしはい」: バトル場にいる間、相手のどくのポケモンはどくで乗せるダメカンが5個多くなる
_FREEZING_SHROUD_ID = "sv6-53"  # ユキメノコの特性「Freezing Shroud」: ポケモンチェックで、特性を持つ全ポケモン(自分・相手とも、ユキメノコ自身を除く)にダメカンを1個のせる


def run_pokemon_checkup(state: GameState, card_db: CardDatabase) -> None:
    from engine.continuous import enforce_status_protection

    from effects.passives import apply_between_turns, checkup_burn_extra_damage, prepare_checkup

    enforce_status_protection(state, card_db)  # 特殊状態にならないポケモン(Verdant Wind/Metal Symbol等)の状態を先に解除する
    prepare_checkup(state, card_db)
    for i, player in enumerate(state.players):
        if player.active is None:
            continue
        was_burned = player.active.status.burned
        from effects.era_sm_hooks import checkup_options

        sleep_flips, burn_stays = checkup_options(state)
        result = resolve_pokemon_checkup(player.active.status, state.rng, sleep_flips=sleep_flips, burn_stays=burn_stays)
        if was_burned:
            result.damage_dealt += checkup_burn_extra_damage(state, card_db, i)  # Scorching Scales
        if result.damage_dealt:
            player.active.damage += result.damage_dealt
        if state.stadium_in_play == _VIRBANK_CITY_GYM_ID and player.active.status.poisoned:
            player.active.damage += 20
            state.add_log("タチワキシティジム: どくのダメカンを2個追加")
        opponent = state.players[state.opponent_index(i)]
        if (
            player.active.status.poisoned
            and opponent.active is not None
            and opponent.active.card_id == _MOMOWAROU_TOXIC_ID
        ):
            player.active.damage += 50
            state.add_log("もうどくしはい: どくのダメカンを5個追加")
        for event in result.events:
            state.add_log(event)

    freezing_shroud_count = sum(
        1 for p in state.players for mon in p.all_pokemon_in_play() if mon.card_id == _FREEZING_SHROUD_ID
    )
    if freezing_shroud_count > 0:
        # 実カード確認の結果、同名の特性を持つユキメノコが複数体場にいる場合、それぞれが独立して
        # 発動し重複する(場のユキメノコ以外の特性持ちポケモン全員が、ユキメノコの数だけダメカンを
        # 受ける)。以前はany()で「1体でもいれば1回だけ」に丸めてしまっており、重複が発生しない
        # バグだった(2026-08-22、ユーザー報告により発覚)。
        from effects.primitives import _blocks_damage_counters

        for _ in range(freezing_shroud_count):
            for player in state.players:
                for mon in player.all_pokemon_in_play():
                    if mon.card_id == _FREEZING_SHROUD_ID:
                        continue
                    card = card_db.get(mon.card_id)
                    if card is not None and card.abilities and not _blocks_damage_counters(mon):
                        mon.damage += 10
        state.add_log(f"Freezing Shroud: 特性を持つポケモンにダメカンを{freezing_shroud_count}個のせた")
    apply_between_turns(state, card_db)  # Royal Heal/Sparkling Particles/Rain Dish/Sand Slammer等(effects/passives.py)
