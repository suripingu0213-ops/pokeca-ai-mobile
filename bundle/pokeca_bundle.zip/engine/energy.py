"""エネルギーのコスト計算(ワザのコスト・にげるコストで共通利用)。

にげるコストは実際のルールでは色を問わないため、
「合計ポイント数(基本エネルギー=1、ダブルレスエネルギー=2)」だけを見ればよい。
ワザのコストは特定タイプの指定があるので、タイプ別に判定する。
"""

from __future__ import annotations

from effects.card_aliases import AliasStr

import contextvars
from contextlib import contextmanager

from cards.card_db import CardDatabase
from engine.state import PokemonInPlay

TEMPLE_OF_SINNOH_STADIUM_ID = "swsh10-155"  # シンオウ神殿: 場のすべての特殊エネルギーは無色エネルギー1個ぶんを提供し、他の効果を持たない
_special_energy_suppressed: contextvars.ContextVar[bool] = contextvars.ContextVar(
    "special_energy_suppressed", default=False
)


_bound_state: contextvars.ContextVar = contextvars.ContextVar("bound_game_state", default=None)
_bound_card_db: contextvars.ContextVar = contextvars.ContextVar("bound_card_db", default=None)


def current_card_db():
    """current_state()と同時にバインドされるCardDatabase(特性によるどうぐ無効化など、state単体では判定できない箇所用)。"""
    return _bound_card_db.get()


def current_state():
    """いま処理中(legal_actions/apply_actionの呼び出し中)のGameState。ポケモン単体の引数しか持たないコスト/HP計算関数が、
    場の他のポケモンの特性(effects/passives.py)を参照するために使う。呼び出しの外ではNone。"""
    return _bound_state.get()


def special_energy_effects_suppressed() -> bool:
    """シンオウ神殿が場に出ている間はTrue(legal_actions/apply_actionの呼び出し中だけ有効。
    special_energy_suppression_for()で設定する)。"""
    return _special_energy_suppressed.get()


@contextmanager
def special_energy_suppression_for(state, card_db=None):
    """stateのスタジアムがシンオウ神殿なら、この呼び出し中だけ特殊エネルギーの固有効果を無効にする
    (コスト計算上は無色1個ぶんに固定。HP増加・ダメージ増減・ワザ効果の無効化・番の終わりに手放す等も全て無効)。"""
    token = _special_energy_suppressed.set(state.stadium_in_play == TEMPLE_OF_SINNOH_STADIUM_ID)
    state_token = _bound_state.set(state)
    db_token = _bound_card_db.set(card_db)
    try:
        yield
    finally:
        _bound_card_db.reset(db_token)
        _bound_state.reset(state_token)
        _special_energy_suppressed.reset(token)


def energy_effect_present(attached_energy, *energy_ids: str) -> bool:
    """attached_energyに、指定した特殊エネルギー(いずれか)があり、かつその固有効果が有効かどうか。
    シンオウ神殿が場にある間は常にFalse(特殊エネルギーは「無色エネルギーを提供し、他の効果を持たない」ため)。"""
    if _special_energy_suppressed.get():
        return False
    return any(eid in attached_energy for eid in energy_ids)

DOUBLE_COLORLESS_ENERGY_ID = "base1-96"
DOUBLE_TURBO_ENERGY_ID = "swsh9-151"  # ダブルターボエネルギー(無色2つぶん。ワザダメージ-20の副作用は未実装)
FUSION_STRIKE_ENERGY_ID = "swsh8-244"  # フュージョンエネルギー(どのタイプのコストにも1つぶんとして使える)
WILDCARD_TOKEN = "Wildcard"
RAPID_STRIKE_ENERGY_ID = "swsh5-140"  # れんげきエネルギー(無色2つぶんだが、闘/水どちらのコストにも使える。れんげきポケモン限定の縛りは未実装)
RAPID_STRIKE_TOKEN = "RapidStrikeWF"
RAPID_STRIKE_ELIGIBLE_TYPES = {"Water", "Fighting"}
BEAST_ENERGY_ID = "sm6-117"  # ビーストエネルギー◇(ウルトラビーストについているときのみどのタイプにも使える。それ以外は無色エネルギー扱い。
# +30ダメージ効果はeffects.primitives._apply_continuous_damage_modifiers経由で対応済み)
STRONG_ENERGY_ID = AliasStr("xy10-115")  # つよいエネルギー(闘エネルギーとして扱う。闘ポケモン専用の制限と、ついていないと外れる制限は未実装。+20ダメージ効果はengine.continuous.fighting_pokemon_flat_bonus_damage経由で対応済み)
RAINBOW_ENERGY_ID = AliasStr("sm1-137")  # レインボーエネルギー(どのタイプにも使えるが1度に1個ぶんのみ。手札からつけたときダメカン1個はengine.rules_engine._handle_attach_energy経由で対応済み)
LUMINOUS_ENERGY_ID = "sv2-191"  # ルミナスエネルギー(どのタイプにも1個ぶんとして使えるが、同じポケモンに他の特殊エネルギーがついていると無色エネルギー扱いになる)
SPLASH_ENERGY_ID = "xy9-113"  # スプラッシュエネルギー(みずポケモン専用エネルギーとして扱う。きぜつ時に手札へ戻る効果はrules_engineのrescued_to_hand_pendingで実装済み)
ENERGY_GAIN_TOOL_ID = "pl1-116"  # Team Galactic's Invention G-101 Energy Gain(SPポケモン限定でワザコストが1少なくなる)
UNOWN_Q_TOOL_ID = "dp5-49"  # Unown Q の特性でどうぐ化した状態(にげるコストが1少なくなる)
AIR_BALLOON_TOOL_IDS = {"zsv10pt5-79", "swsh1-156", "me1-166", "me2pt5-181"}  # ふうせん(にげるコストが2少なくなる。印刷違いの4種)
FLOAT_STONE_TOOL_ID = AliasStr("xy8-137")  # かるいし(Float Stone): にげるコストが0になる
FUTURE_BOOSTER_ENERGY_CAPSULE_TOOL_ID = "sv5-149"  # みらいステップアップパック(未来ポケモンのにげるコストが0になる。相手バトルポケモンへの+20ダメージは未実装)
RESCUE_BOARD_TOOL_ID = "sv5-159"  # レスキューボード(にげるコストが1少なくなる。残りHP30以下なら0になる)
NEO_UPPER_ENERGY_ID = "sv5-162"  # ネオアッパーエネルギー(ACE SPEC): 通常は無色1つぶん。2進化ポケモンについているときのみ、どのタイプにも使える代わりに2つぶん提供する
ESCAPE_BOARD_TOOL_ID = "sm5-122"  # エスケープボード(にげるコストが1少なくなる。ねむり/まひ中でもにげられる=legal_actions._retreat_actions側で対応)
TELEPATHIC_PSYCHIC_ENERGY_ID = "m3-79"  # テレパス超エネルギー: 公式サイトの生HTML確認で判明した通り、
# 「エネルギー1個ぶんとしてはたらく」の直前に見えないicon-psychicスパンがあり、実際は超1個ぶん
# (無色ではない)。この関数に個別対応が無く既定の"Colorless"にフォールバックしていたため、
# 超タイプのコストを要求するワザで「エネルギーはついているのに攻撃できない」不具合になっていた。
PRISM_ENERGY_REPRINT_IDS = frozenset({"me2pt5-216", "zsv10pt5-86"})  # 同カードの別絵柄
PRISM_ENERGY_ID = "bw4-93"  # プリズムエネルギー(Prism Energy、英語版キャッシュテキストで確認):
# "This card provides Colorless Energy. If the Pokémon this card is attached to is a Basic
# Pokémon, this card provides every type of Energy but provides only 1 Energy at a time."
# ―― たねポケモンについているときのみどのタイプにも1個ぶんとして使える万能扱い、進化ポケモンに
# ついていると無色1個ぶんのみ。この関数に個別対応が無く、常に無色扱いのフォールバックに
# 落ちていた(実在デッキ複数で採用されているカードだが未実装のままだった)。
GROW_GRASS_ENERGY_ID = "m3-78"  # グロウ草エネルギー(公式サイトの生HTML確認、icon-grassスパン):
# 草エネルギー1個ぶん。つけている草ポケモンの最大HP+20効果は未実装(このモジュールの守備範囲外)。
GROW_GRASS_ENERGY_REPRINT_ID = "me3-86"  # Growing Grass Energy(Jレギュレーション新規、m3-78と同一テキスト)
TELEPATHIC_PSYCHIC_ENERGY_REPRINT_ID = "me3-88"  # Telepathic Psychic Energy(m3-79と同一テキスト)
ROCKY_FIGHTING_ENERGY_ID = "me3-87"  # Rocky Fighting Energy: 闘エネルギー1個ぶん。ミストエネルギーと
# 同文の「Prevent all effects of attacks used by your opponent's Pokémon done to the Pokémon this
# card is attached to」を持つ(型が闘限定な点のみ異なる)。効果無効化はeffects.primitives.
# _defender_blocks_non_damage_effects経由でMIST_ENERGY_IDと同じ扱い。
MAGNETIC_METAL_ENERGY_ID = "me4-85"  # Magnetic Metal Energy: 鋼エネルギー1個ぶん。つけている鋼
# ポケモンはにげるコストが0になる(かるいし(FLOAT_STONE_TOOL_ID)と同じ考え方をエネルギー側で実装)。
VOLTAIC_LIGHTNING_ENERGY_ID = "me5-84"  # Voltaic Lightning Energy: 雷エネルギー1個ぶん。つけている
# 雷ポケモンのワザは相手のバトルポケモンに+20ダメージ(effects.primitives._apply_attacker_side_
# damage_modifiers内、BEAST_ENERGY_IDと同じ書き方で対応済み)。
LEGACY_ENERGY_ID = "sv6-167"  # レガシーエネルギー(ACE SPEC、英語版キャッシュテキストで確認): "provides
# every type of Energy but provides only 1 Energy at a time" ―― 無条件の万能1個ぶん。きぜつ時の
# サイド減免効果は未実装。
WONDER_ENERGY_ID = "xy5-144"  # ワンダーエネルギー(英語版キャッシュテキストで確認): フェアリー
# ポケモンについているときのみフェアリー1個ぶん(それ以外は本来トラッシュされるはずだが、
# 手放し処理は未実装のため無色1個ぶんとして扱う)。効果無効化はeffects.primitives.
# _defender_blocks_non_damage_effects経由で対応済み。
MIST_ENERGY_ID = "sv5-161"  # ミストエネルギー(英語版キャッシュテキストで確認): 無色1個ぶん(型の制限無し)。
# "Prevent all effects of attacks used by your opponent's Pokémon done to the Pokémon this card is
# attached to."(ダメージ自体は防がない)効果無効化はeffects.primitives._defender_blocks_non_damage_effects
# 経由で対応(2026-08-25の公式FAQ監査で発覚、以前は無色トークンとしてのみ機能し効果無効化が未実装だった)。
BOOMERANG_ENERGY_ID = "sv6-166"  # ブーメランエネルギー(英語版キャッシュテキストで確認): 無色1個ぶん。
# "If this card is discarded by an effect of an attack used by the Pokémon this card is attached
# to, attach this card from your discard pile to that Pokémon after attacking."(ワザの効果で
# このカード自身がトラッシュされたとき、ワザの処理が終わった後、同じポケモンにつけなおす。
# ワザによる直接のダメージやロストゾーンに送る効果では発動しない)。再付け処理はengine.rules_engine.
# _handle_attack末尾で対応(2026-08-25ユーザー報告「ブーメランエネルギーの効果が発動しません」で発覚、
# 以前は無色トークンとしてのみ機能し再付け効果が未実装だった)。
IGNITION_ENERGY_ID = "rsv10pt5-86"  # イグニッションエネルギー(英語版キャッシュテキストで確認):
# 進化ポケモンについていれば無色3個ぶん、たねポケモンなら無色1個ぶん。番の終わりに手放す効果は
# engine/rules_engine.py側のターン終了処理で対応済み。
IGNITION_ENERGY_REPRINT_ID = "me2-124"  # Ignition Energy 別絵柄(rsv10pt5-86と同一テキスト)
UNIT_ENERGY_LPM_ID = "sm5-138"  # ユニットエネルギーLPM(英語版キャッシュテキストで確認): "provides
# Lightning, Psychic, and Metal Energy but provides only 1 Energy at a time" ―― 電気/超/鋼の
# いずれか1個ぶんとして使える(れんげきエネルギーのRAPID_STRIKE_TOKENと同じ「限定万能」の仕組み)。
UNIT_ENERGY_LPM_TOKEN = "UnitEnergyLPM"
UNIT_ENERGY_LPM_ELIGIBLE_TYPES = {"Lightning", "Psychic", "Metal"}
TEAM_ROCKET_ENERGY_REPRINT_ID = "me2pt5-217"  # 同カードの別絵柄(Iレギュレーション ME02.5収録)
TEAM_ROCKET_ENERGY_ID = "sv10-182"  # ロケット団のエネルギー(英語版キャッシュテキストで確認): "provides
# 2 in any combination of Psychic Energy and Darkness Energy" ―― 超/悪を自由に組み合わせて2個ぶん。
# ロケット団のポケモン以外につけると手放す制限は未実装。
# 「◯◯、△△、□□のいずれか1個ぶんとして使える」型のエネルギーのトークン(ブレンドエネルギー等)と、そのトークンが表せるタイプ
EXTRA_MULTI_TYPE_TOKENS: dict[str, frozenset] = {
    "BlendGFPD": frozenset({"Grass", "Fire", "Psychic", "Darkness"}),
    "BlendWLFM": frozenset({"Water", "Lightning", "Fighting", "Metal"}),
    "UnitGFW": frozenset({"Grass", "Fire", "Water"}),  # ユニットエネルギー 草炎水
    "UnitFDF": frozenset({"Fighting", "Darkness", "Fairy"}),  # ユニットエネルギー 闘悪妖
}
TEAM_ROCKET_ENERGY_TOKEN = "TeamRocketPD"
TEAM_ROCKET_ENERGY_ELIGIBLE_TYPES = {"Psychic", "Darkness"}
REVERSAL_ENERGY_ID = "sv2-192"  # リバーサルエネルギー(英語版キャッシュテキストで確認): 通常は無色1個
# ぶん、サイドで勝っておりルール箱を持たない進化ポケモンについているときのみ万能3個ぶんになる
# (プレイヤーのサイド枚数差が要る唯一のケースなので、ahead_on_prizesを明示的に受け取る)。
_REVERSAL_ENERGY_RULE_BOX_SUBTYPES = {"ex", "EX", "GX", "V", "VMAX", "VSTAR", "Radiant", "BREAK", "MEGA", "Tera", "Level-Up"}


def energy_tokens(card_db: CardDatabase, energy_card_id: str, *args, **kwargs) -> list[str]:
    """このエネルギーカードが提供するタイプトークン。パッシブ特性(Dark Aura/Psychic Mirage)の効果を反映する。"""
    from effects.passives import adjust_energy_tokens

    tokens = _energy_tokens_impl(card_db, energy_card_id, *args, **kwargs)
    host_card_id = args[0] if len(args) > 0 else kwargs.get("host_card_id")
    if tokens and len(tokens) == 1 and tokens[0] == WILDCARD_TOKEN and current_state() is not None:
        from effects.era_sm_hooks import super_boost_extra_tokens

        tokens = tokens + [WILDCARD_TOKEN] * super_boost_extra_tokens(current_state(), card_db, energy_card_id, host_card_id)  # スーパーブースト: ステージ2が3匹以上で4個ぶん
    attached = args[1] if len(args) > 1 else kwargs.get("all_attached_energy_ids")
    return adjust_energy_tokens(card_db, energy_card_id, host_card_id, attached, tokens)


def _energy_tokens_impl(
    card_db: CardDatabase,
    energy_card_id: str,
    host_card_id: str | None = None,
    all_attached_energy_ids: list[str] | None = None,
    double_grass: bool = False,
    ahead_on_prizes: bool = False,
) -> list[str]:
    """このエネルギーカードが提供する「タイプトークン」のリストを返す。host_card_idはこのエネルギーが
    ついているポケモンのcard_id(判定にホスト側のサブタイプが必要なビーストエネルギー◇用、省略可)。
    all_attached_energy_idsは同じポケモンについている全エネルギーのIDリスト(ルミナスエネルギー用、
    「他に特殊エネルギーがついていれば無色扱い」の判定に自分以外の枚数が必要なため。省略可)。
    ahead_on_prizesは自分の残りサイドが相手より多いか(リバーサルエネルギー用、省略可)。"""
    if _special_energy_suppressed.get():
        _suppressed_card = card_db.get(energy_card_id)
        if _suppressed_card is not None and _suppressed_card.is_special_energy:
            return ["Colorless"]
    if energy_card_id == LUMINOUS_ENERGY_ID:
        if all_attached_energy_ids is not None:
            special_count = sum(
                1
                for eid in all_attached_energy_ids
                if (c := card_db.get(eid)) is not None and c.is_special_energy
            )
            if special_count > 1:
                return ["Colorless"]
        return [WILDCARD_TOKEN]
    if energy_card_id in (DOUBLE_COLORLESS_ENERGY_ID, DOUBLE_TURBO_ENERGY_ID):
        return ["Colorless", "Colorless"]
    if energy_card_id == FUSION_STRIKE_ENERGY_ID:
        return [WILDCARD_TOKEN]
    if energy_card_id == RAPID_STRIKE_ENERGY_ID:
        return [RAPID_STRIKE_TOKEN, RAPID_STRIKE_TOKEN]
    if energy_card_id == BEAST_ENERGY_ID:
        host_card = card_db.get(host_card_id) if host_card_id else None
        if host_card is not None and "Ultra Beast" in host_card.subtypes:
            return [WILDCARD_TOKEN]
        return ["Colorless"]
    if energy_card_id == STRONG_ENERGY_ID:
        return ["Fighting"]
    if energy_card_id == RAINBOW_ENERGY_ID:
        return [WILDCARD_TOKEN]
    if energy_card_id == SPLASH_ENERGY_ID:
        return ["Water"]
    if energy_card_id == MYSTERY_ENERGY_ID:
        return ["Psychic"]
    if energy_card_id in (TELEPATHIC_PSYCHIC_ENERGY_ID, TELEPATHIC_PSYCHIC_ENERGY_REPRINT_ID):
        return ["Psychic"]
    if energy_card_id == PRISM_ENERGY_ID or energy_card_id in PRISM_ENERGY_REPRINT_IDS:
        host_card = card_db.get(host_card_id) if host_card_id else None
        if host_card is not None and host_card.is_basic:
            return [WILDCARD_TOKEN]
        return ["Colorless"]
    if energy_card_id in (GROW_GRASS_ENERGY_ID, GROW_GRASS_ENERGY_REPRINT_ID):
        return ["Grass"]
    if energy_card_id == ROCKY_FIGHTING_ENERGY_ID:
        return ["Fighting"]
    if energy_card_id == MAGNETIC_METAL_ENERGY_ID:
        return ["Metal"]
    if energy_card_id == VOLTAIC_LIGHTNING_ENERGY_ID:
        return ["Lightning"]
    if energy_card_id == LEGACY_ENERGY_ID:
        return [WILDCARD_TOKEN]
    if energy_card_id == WONDER_ENERGY_ID:
        host_card = card_db.get(host_card_id) if host_card_id else None
        if host_card is not None and "Fairy" in host_card.types:
            return ["Fairy"]
        return ["Colorless"]
    if energy_card_id in (IGNITION_ENERGY_ID, IGNITION_ENERGY_REPRINT_ID):
        host_card = card_db.get(host_card_id) if host_card_id else None
        if host_card is not None and not host_card.is_basic:
            return ["Colorless", "Colorless", "Colorless"]
        return ["Colorless"]
    from effects.era_sm_hooks import energy_tokens_sm

    sm_tokens = energy_tokens_sm(card_db, energy_card_id, host_card_id, ahead_on_prizes)
    if sm_tokens is not None:
        return sm_tokens  # トリプルアクセレーション/ウィークネスガード/ドロー/カウンター/スーパーブースト/ユニット(草炎水・闘悪妖)
    from effects.era_trainers import era_energy_tokens

    era_tokens = era_energy_tokens(card_db, energy_card_id, host_card_id)
    if era_tokens is not None:
        return era_tokens  # ブレンドエネルギー/ハーブエネルギー/(旧)あくエネルギー
    if energy_card_id == UNIT_ENERGY_LPM_ID:
        return [UNIT_ENERGY_LPM_TOKEN]
    if energy_card_id in (TEAM_ROCKET_ENERGY_ID, TEAM_ROCKET_ENERGY_REPRINT_ID):
        return [TEAM_ROCKET_ENERGY_TOKEN, TEAM_ROCKET_ENERGY_TOKEN]
    if energy_card_id == REVERSAL_ENERGY_ID:
        host_card = card_db.get(host_card_id) if host_card_id else None
        if (
            ahead_on_prizes
            and host_card is not None
            and not host_card.is_basic
            and not (_REVERSAL_ENERGY_RULE_BOX_SUBTYPES & set(host_card.subtypes))
        ):
            return [WILDCARD_TOKEN, WILDCARD_TOKEN, WILDCARD_TOKEN]
        return ["Colorless"]
    if energy_card_id == NEO_UPPER_ENERGY_ID:
        host_card = card_db.get(host_card_id) if host_card_id else None
        if host_card is not None and "Stage 2" in host_card.subtypes:
            return [WILDCARD_TOKEN, WILDCARD_TOKEN]
        return ["Colorless"]
    from effects.era_energy_j import era_energy_tokens_j

    tokens_j = era_energy_tokens_j(card_db, energy_card_id, host_card_id)
    if tokens_j is not None:
        return tokens_j  # SWSH/SVの特殊エネルギー: 文面から導いたタイプ(エフェクトは TOOL_PASSIVES/TOOL_REACTIONS)
    card = card_db.get(energy_card_id)
    if card is None:
        return ["Colorless"]
    if double_grass and card.basic_energy_type == "Grass":
        # メガニウムの特性「Wild Growth」: 自分の場の全ポケモンについている基本くさエネルギーは
        # くさエネルギー2つぶんとして働く(効果は重複しない)。
        return ["Grass", "Grass"]
    return [card.basic_energy_type or "Colorless"]


def energy_matches_type(
    card_db: CardDatabase,
    energy_card_id: str,
    required_type: str,
    host_card_id: str | None = None,
    all_attached_energy_ids: list[str] | None = None,
) -> bool:
    """「このポケモンに◯◯エネルギーがついているなら」系の特性(イイネイヌの「アドレナパワー」等)の
    判定用。基本エネルギーのタイプ判定にはCard.basic_energy_typeを使う(以前はCard.typesを見ており、
    エネルギーカードは常にtypes=()なので常にFalseになっていた=この種の特性が絶対に発動しない
    バグだった、2026-08-20発覚)。Legacy Energy/Team Rocket's Energyのように「◯◯エネルギーを
    提供する」と明記された特殊エネルギーは、energy_tokens()が返すトークンで判定する(万能
    トークン・複数タイプ選択制トークンいずれも対応)。"""
    card = card_db.get(energy_card_id)
    if card is None or not card.is_energy:
        return False
    if card.basic_energy_type == required_type:
        return True
    tokens = energy_tokens(card_db, energy_card_id, host_card_id, all_attached_energy_ids)
    if required_type in tokens or WILDCARD_TOKEN in tokens:
        return True
    if RAPID_STRIKE_TOKEN in tokens and required_type in RAPID_STRIKE_ELIGIBLE_TYPES:
        return True
    if UNIT_ENERGY_LPM_TOKEN in tokens and required_type in UNIT_ENERGY_LPM_ELIGIBLE_TYPES:
        return True
    if TEAM_ROCKET_ENERGY_TOKEN in tokens and required_type in TEAM_ROCKET_ENERGY_ELIGIBLE_TYPES:
        return True
    if any(t in EXTRA_MULTI_TYPE_TOKENS and required_type in EXTRA_MULTI_TYPE_TOKENS[t] for t in tokens):
        return True
    return False


def total_points(
    card_db: CardDatabase,
    attached_energy_ids: list[str],
    host_card_id: str | None = None,
    double_grass: bool = False,
    ahead_on_prizes: bool = False,
) -> int:
    return sum(
        len(energy_tokens(card_db, e, host_card_id, double_grass=double_grass, ahead_on_prizes=ahead_on_prizes))
        for e in attached_energy_ids
    )


def can_pay_cost(
    card_db: CardDatabase,
    attached_energy_ids: list[str],
    cost: tuple[str, ...],
    host_card_id: str | None = None,
    double_grass: bool = False,
    ahead_on_prizes: bool = False,
) -> bool:
    available: list[str] = []
    for e in attached_energy_ids:
        available.extend(
            energy_tokens(
                card_db, e, host_card_id, attached_energy_ids, double_grass=double_grass, ahead_on_prizes=ahead_on_prizes
            )
        )

    colorless_needed = 0
    for requirement in cost:
        if requirement == "Colorless":
            colorless_needed += 1
            continue
        if requirement in available:
            available.remove(requirement)
        elif WILDCARD_TOKEN in available:
            available.remove(WILDCARD_TOKEN)
        elif requirement in RAPID_STRIKE_ELIGIBLE_TYPES and RAPID_STRIKE_TOKEN in available:
            available.remove(RAPID_STRIKE_TOKEN)
        elif requirement in UNIT_ENERGY_LPM_ELIGIBLE_TYPES and UNIT_ENERGY_LPM_TOKEN in available:
            available.remove(UNIT_ENERGY_LPM_TOKEN)
        elif requirement in TEAM_ROCKET_ENERGY_ELIGIBLE_TYPES and TEAM_ROCKET_ENERGY_TOKEN in available:
            available.remove(TEAM_ROCKET_ENERGY_TOKEN)
        else:
            multi = next((t for t in available if t in EXTRA_MULTI_TYPE_TOKENS and requirement in EXTRA_MULTI_TYPE_TOKENS[t]), None)
            if multi is None:
                return False
            available.remove(multi)

    return len(available) >= colorless_needed


def can_pay_retreat_cost(
    card_db: CardDatabase,
    attached_energy_ids: list[str],
    cost_count: int,
    host_card_id: str | None = None,
    double_grass: bool = False,
) -> bool:
    return total_points(card_db, attached_energy_ids, host_card_id, double_grass=double_grass) >= cost_count


def auto_select_retreat_payment(
    card_db: CardDatabase, attached_energy_ids: list[str], cost_count: int, double_grass: bool = False
) -> list[str]:
    """にげるコストを支払うために手放すエネルギーカードのIDリストを選ぶ(単純に先頭から)。
    retreat_discard_choice_countがNoneを返した場合(選ぶ余地が無い/価値が混在する)のフォールバック用。
    double_grass: メガニウムの特性「Wild Growth」実カードテキスト("Each Basic Grass Energy attached to
    all of your Pokémon provides GrassGrass Energy")は攻撃コストに限らず自分の場の全ポケモンの基本くさ
    エネルギーに効くため、にげるコストの支払いでも2つぶんとして数える必要がある(以前は攻撃コストの
    判定にしか反映されておらず、にげるコストの支払いには一切効いていなかった)。"""
    paid: list[str] = []
    points = 0
    for energy_id in attached_energy_ids:
        if points >= cost_count:
            break
        paid.append(energy_id)
        points += len(energy_tokens(card_db, energy_id, double_grass=double_grass))
    return paid


def retreat_discard_choice_count(
    card_db: CardDatabase, attached_energy_ids: list[str], cost_count: int, double_grass: bool = False
) -> int | None:
    """にげるコストの支払いにプレイヤーの選択が必要な場合、選ばせる枚数を返す(選ぶ余地が無ければNone)。
    ついているエネルギーが全て同じ価値(枚数)のときのみ対応(混在時はauto_select_retreat_paymentに
    委ねるv1簡略版)。"""
    if cost_count <= 0 or not attached_energy_ids:
        return None
    values = [len(energy_tokens(card_db, eid, double_grass=double_grass)) for eid in attached_energy_ids]
    if len(set(values)) != 1:
        return None
    per_value = values[0]
    if per_value <= 0:
        return None
    needed = -(-cost_count // per_value)  # 切り上げ除算
    if needed >= len(attached_energy_ids):
        return None
    return needed


KARATE_BELT_TOOL_ID = "sm11-201"  # くろおび(サイド枚数が相手より多いとき、闘エネルギー1つぶんコストが少なくなる)
HEAD_RINGER_TOOL_ID = "xy4-97"  # ヘッドノイザー(Head Ringer、相手のEXポケモンにつける。ワザのコストが無色1つぶん増える)
DIMENSION_VALLEY_STADIUM_ID = "xy4-93"  # 次元の谷(Dimension Valley): エスパーポケモンのワザが無色1つぶん少なくなる(両プレイヤー)
BLOODMOON_URSALUNA_EX_ID = "sv6-141"  # ガチグマアカツキex「Seasoned Skill」: 相手が取ったサイド1枚につき、
# このポケモンが使う「Blood Moon」(このポケモン自身が持つワザ限定、ワザマシン等のどうぐで使えるように
# なったワザは対象外)のコストが無色1つぶん少なくなる
KYUREM_PLASMA_BANE_ID = "sv6pt5-47"  # キュレムの特性「Plasma Bane」: 相手のトラッシュに"Colress"を含むカードがあれば、Trifrostが無色1つで使える


def effective_attack_cost(card_db: CardDatabase, mon: PokemonInPlay, *args, **kwargs) -> tuple[str, ...]:
    """ワザの実効コスト。パッシブ特性(effects/passives.py)の効果を反映する。"""
    from effects.passives import adjust_attack_cost

    cost = _effective_attack_cost_impl(card_db, mon, *args, **kwargs)
    cost = adjust_attack_cost(card_db, mon, cost, kwargs.get("attack_name"))
    bound = current_state()
    if bound is not None and mon.attack_cost_extra:
        from effects.era_primitives_f import era_attack_cost_extra

        cost = tuple(cost) + ("Colorless",) * era_attack_cost_extra(mon, bound.turn_number)  # Sticky Shot/Slowing Beam
    return cost


def _effective_attack_cost_impl(
    card_db: CardDatabase,
    mon: PokemonInPlay,
    cost: tuple[str, ...],
    stadium_in_play: str | None = None,
    ahead_on_prizes: bool = False,
    opponent_prizes_taken: int = 0,
    attack_name: str | None = None,
    opponent_discard: list[str] | None = None,
) -> tuple[str, ...]:
    """どうぐ「エナジーゲイン」がついたSPポケモンはワザのコストが1少なくなる(どうぐ無効化スタジアムがあれば無効)。
    「くろおび」がついたポケモンは、サイド枚数で相手より優勢なとき闘エネルギー1つぶんコストが少なくなる。
    「ヘッドノイザー」がついたポケモンは、ワザのコストが無色1つぶん増える。
    スタジアム「次元の谷」が場にあるとき、エスパーポケモンのワザは無色1つぶん少なくなる(両プレイヤー)。
    ガチグマアカツキexの「Seasoned Skill」: 相手が既に取ったサイド1枚につき、Blood Moonのコストが
    無色1つぶん少なくなる(どうぐではなく特性由来のためtools_disabledの影響は受けない)。公式Q&Aで
    「ワザマシン かじばのいっぱつ」等、どうぐで使えるようになった別のワザには適用されないと確認済み
    (attack_name=="Blood Moon"のときのみ適用、2026-08-25の公式FAQ監査で発覚・修正)。
    キュレムの特性「Plasma Bane」: 相手のトラッシュに"Colress"を含む名前のカードがあれば、
    Trifrostのコストが無色1つになる(どうぐではなく特性由来のためtools_disabledの影響は受けない)。
    """
    from engine.continuous import tools_disabled

    card = card_db.get(mon.card_id)
    if (
        mon.card_id == KYUREM_PLASMA_BANE_ID
        and attack_name == "Trifrost"
        and opponent_discard is not None
        and any((c := card_db.get(cid)) is not None and "Colress" in c.name for cid in opponent_discard)
    ):
        return ("Colorless",)
    if (
        stadium_in_play == DIMENSION_VALLEY_STADIUM_ID
        and card is not None
        and "Psychic" in card.types
        and cost
        and cost[-1] == "Colorless"
    ):
        cost = cost[:-1]
    from effects.era_sm_hooks import attack_cost_extra, counter_gain_reduces

    extra = attack_cost_extra(stadium_in_play, card)  # ふしぎなラビリンス◇: フェアリー以外のワザは無色+1
    if extra:
        cost = tuple(cost) + ("Colorless",) * extra

    if (
        mon.card_id == BLOODMOON_URSALUNA_EX_ID
        and attack_name == "Blood Moon"
        and opponent_prizes_taken > 0
        and "Colorless" in cost
    ):
        cost = list(cost)
        for _ in range(min(opponent_prizes_taken, cost.count("Colorless"))):
            cost.remove("Colorless")
        cost = tuple(cost)

    if tools_disabled(stadium_in_play):
        return cost
    if mon.attached_tool == ENERGY_GAIN_TOOL_ID and card is not None and card.is_sp_pokemon and cost:
        return cost[:-1]
    if mon.attached_tool == HEAD_RINGER_TOOL_ID:
        return tuple(cost) + ("Colorless",)
    if mon.attached_tool == KARATE_BELT_TOOL_ID and ahead_on_prizes and "Fighting" in cost:
        cost = list(cost)
        cost.remove("Fighting")
        return tuple(cost)
    if counter_gain_reduces(mon.attached_tool) and ahead_on_prizes and "Colorless" in cost:
        cost = list(cost)
        cost.remove("Colorless")  # カウンターゲイン: サイドが相手より多いとき、ワザのコストが無色1個少ない
        return tuple(cost)
    return cost


WIMPOD_ID = "sm3-16"  # Wimpod「Wimp Out」: 自分の最初の番の間、にげるコストが0
ZUBAT_FREE_FLIGHT_ID = "bw8-53"  # ズバット「Free Flight」: エネルギーが1枚もついていなければにげるコストが0
SKYARROW_BRIDGE_STADIUM_ID = "bw4-91"  # スカイアローブリッジ(Skyarrow Bridge): たねポケモンのにげるコストが無色1つぶん少なくなる(両プレイヤー)
FAIRY_GARDEN_STADIUM_ID = "xy1-117"  # フェアリーガーデン(Fairy Garden): フェアリーエネルギーがついていればにげるコスト0(両プレイヤー)
N_CASTLE_STADIUM_ID = "sv9-152"  # Nの城(N's Castle): 「N's」ポケモンはにげるコストが0になる(両プレイヤー)
MYSTERY_ENERGY_ID = "xy4-112"  # ミステリーエネルギー(Mystery Energy): ついているポケモンのにげるコストが無色2つぶん少なくなる
LATIAS_EX_SKYLINER_ID = "sv8-76"  # ラティアスex「Skyliner」: 自分のたねポケモンはにげるコストが0になる
DARKRAI_EX_DARK_CLOAK_ID = "bw11-88"  # ダークライEX「Dark Cloak」: 悪エネルギーがついている自分のポケモンはにげるコストが0になる
ZERAORA_GX_THUNDERCLAP_ZONE_ID = "sm8-86"  # ライボルトGX「Thunderclap Zone」: 雷エネルギーがついている自分のポケモンはにげるコストが0になる


def has_skyliner_in_play(player) -> bool:
    return any(mon.card_id == LATIAS_EX_SKYLINER_ID for mon in player.all_pokemon_in_play())


def has_dark_cloak_in_play(player) -> bool:
    return any(mon.card_id == DARKRAI_EX_DARK_CLOAK_ID for mon in player.all_pokemon_in_play())


def has_thunderclap_zone_in_play(player) -> bool:
    return any(mon.card_id == ZERAORA_GX_THUNDERCLAP_ZONE_ID for mon in player.all_pokemon_in_play())


def effective_retreat_cost_count(card_db: CardDatabase, mon: PokemonInPlay, *args, **kwargs) -> int:
    """にげるコスト(無色の個数)。パッシブ特性(effects/passives.py)の効果を反映する。"""
    from effects.passives import adjust_retreat_cost

    count = adjust_retreat_cost(card_db, mon, _effective_retreat_cost_count_impl(card_db, mon, *args, **kwargs))
    bound = current_state()
    if bound is not None and mon.retreat_cost_extra:
        from effects.era_primitives_f import era_retreat_cost_extra

        count += era_retreat_cost_extra(mon, bound.turn_number)  # Sticky Shot
    if bound is not None and bound.stadium_in_play is not None:
        from effects.era_trainers import era_stadium_retreat_extra

        count = max(0, count + era_stadium_retreat_extra(bound, card_db, mon))  # チームアクア団のひみつきち/ラナキラマウンテン/月の祭壇
    return count


def _effective_retreat_cost_count_impl(
    card_db: CardDatabase,
    mon: PokemonInPlay,
    base_cost_count: int,
    stadium_in_play: str | None = None,
    player_turns_taken: int | None = None,
    owner_has_skyliner: bool = False,
    owner_has_dark_cloak: bool = False,
    owner_has_thunderclap_zone: bool = False,
) -> int:
    """Unown Qの特性でどうぐ化された状態、またはふうせんがついたポケモンは、にげるコストが少なくなる
    (どうぐ無効化スタジアムがあれば無効)。スタジアム「スカイアローブリッジ」があれば、たねポケモンは
    にげるコストが無色1つぶん少なくなる(両プレイヤー)。スタジアム「フェアリーガーデン」があれば、
    フェアリーエネルギーがついているポケモンはにげるコストが0になる(両プレイヤー)。
    自分の場にラティアスex「Skyliner」がいれば、自分のたねポケモンはにげるコストが0になる。
    自分の場にダークライEX「Dark Cloak」がいれば、悪エネルギーがついている自分のポケモンは
    にげるコストが0になる。自分の場にライボルトGX「Thunderclap Zone」がいれば、雷エネルギーが
    ついている自分のポケモンはにげるコストが0になる。"""
    from engine.continuous import tools_disabled

    from effects.era_sm_hooks import U_TURN_BOARD_IDS, dark_city_zeroes_retreat

    if dark_city_zeroes_retreat(stadium_in_play, card_db.get(mon.card_id)):
        return 0  # ダークシティ: たねあくポケモンはにげるコストが無い(両プレイヤー)
    if mon.card_id == WIMPOD_ID and player_turns_taken == 1:
        return 0
    if mon.card_id == ZUBAT_FREE_FLIGHT_ID and not mon.attached_energy:
        return 0

    if energy_effect_present(mon.attached_energy, MAGNETIC_METAL_ENERGY_ID):
        card = card_db.get(mon.card_id)
        if card is not None and "Metal" in card.types:
            return 0

    if stadium_in_play == FAIRY_GARDEN_STADIUM_ID and any(
        (e := card_db.get(eid)) is not None and e.basic_energy_type == "Fairy" for eid in mon.attached_energy
    ):
        return 0

    if stadium_in_play == N_CASTLE_STADIUM_ID:
        card = card_db.get(mon.card_id)
        if card is not None and card.name.startswith("N's "):
            return 0

    if owner_has_skyliner:
        card = card_db.get(mon.card_id)
        if card is not None and card.is_basic:
            return 0

    if owner_has_dark_cloak and any(
        (e := card_db.get(eid)) is not None and e.basic_energy_type == "Darkness" for eid in mon.attached_energy
    ):
        return 0

    if owner_has_thunderclap_zone and any(
        (e := card_db.get(eid)) is not None and e.basic_energy_type == "Lightning" for eid in mon.attached_energy
    ):
        return 0

    if stadium_in_play == SKYARROW_BRIDGE_STADIUM_ID:
        card = card_db.get(mon.card_id)
        if card is not None and card.is_basic:
            base_cost_count = max(0, base_cost_count - 1)

    if tools_disabled(stadium_in_play):
        return base_cost_count
    if mon.attached_tool in (UNOWN_Q_TOOL_ID, ESCAPE_BOARD_TOOL_ID) or mon.attached_tool in U_TURN_BOARD_IDS:
        return max(0, base_cost_count - 1)
    if mon.attached_tool in AIR_BALLOON_TOOL_IDS:
        return max(0, base_cost_count - 2)
    if mon.attached_tool == FLOAT_STONE_TOOL_ID:
        return 0
    if mon.attached_tool == FUTURE_BOOSTER_ENERGY_CAPSULE_TOOL_ID:
        return 0
    if mon.attached_tool == RESCUE_BOARD_TOOL_ID:
        card = card_db.get(mon.card_id)
        if card is not None and card.hp is not None and (card.hp - mon.damage) <= 30:
            return 0
        return max(0, base_cost_count - 1)
    if energy_effect_present(mon.attached_energy, MYSTERY_ENERGY_ID):  # ミステリーエネルギー: にげるコストが無色2つぶん少なくなる
        base_cost_count = max(0, base_cost_count - 2)
    return base_cost_count
