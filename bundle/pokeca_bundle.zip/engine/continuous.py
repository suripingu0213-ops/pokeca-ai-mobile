"""カード自体を「使う」アクションを持たない、常に場に影響し続けるタイプの効果をまとめる。

このエンジンの大半のカード効果は「使う瞬間に実行するプリミティブ」として表現しているが、
スタジアム/どうぐの一部やポケモンの一部の特性には、発動アクションを持たず常に場に効き続ける
ものがある(例:「ルールボックス持ちの特性を封じるスタジアム」「どうぐを無効化するスタジアム」)。
そうした効果は判定関数として実装し、特性の使用可否チェックやダメージ計算の際に参照する。
"""

from __future__ import annotations

from effects.card_aliases import AliasStr

from typing import TYPE_CHECKING

from cards.models import Card

if TYPE_CHECKING:
    from engine.state import GameState

# ---- 最大HPを増やすどうぐ(対象タイプ限定あり) ----
# 値は (増加量, 対象を限定するサブタイプ or None)。
HP_BONUS_TOOLS: dict[str, tuple[int, str | None]] = {
    "xy9-99": (40, "Basic"),  # ファイティングフューリーベルト(Fighting Fury Belt): たねポケモン限定
    "sv2-173": (50, "Basic"),  # 勇気のおまもり(Bravery Charm): たねポケモン限定
    "sv5m-64": (100, None),  # ヒーローマント(ACE SPEC): 全ポケモン対象
}

# ---- 最大HPを増やすどうぐ(対象をカード名の接頭辞で限定) ----
NAME_PREFIX_HP_BONUS_TOOLS: dict[str, tuple[str, int]] = {
    "sv10-162": ("Cynthia's", 70),  # シンジタチのパワーウェイト(Cynthia's Power Weight)
}


# ---- 場のポケモンの最大HPを減らすスタジアム(対象を限定するサブタイプつき) ----
STAGE_HP_PENALTY_STADIUMS: dict[str, tuple[int, str]] = {
    "sv8-177": (30, "Stage 2"),  # グラビティマウンテン(Gravity Mountain): たねから2進化限定
}


# ---- 特定タイプのエネルギーがついていれば最大HPが増える特性 ----
HP_BONUS_IF_ENERGY_TYPE: dict[str, tuple[int, str]] = {
    "sv8a-90": (100, "Darkness"),  # イイネイヌ(Okidogi)「アドレナパワー」: 悪エネルギーがついていれば最大HP+100
}


# ---- 特殊エネルギーが(タイプ問わず)何か1枚でもついていれば最大HPが増える特性 ----
HP_BONUS_IF_ANY_SPECIAL_ENERGY: dict[str, int] = {
    "me3-45": 150,  # バンバドロ(Tyrantrum)「Tyrannically Gutsy」: "If this Pokémon has any Special
    # Energy attached, it gets +150 HP."
}


def effective_max_hp(
    card_db,
    card_id: str,
    attached_tool: str | None,
    stadium_in_play: str | None = None,
    attached_energy: list[str] | None = None,
) -> int:
    """最大HP(どうぐ・スタジアム・エネルギーの効果に加え、場のポケモンのパッシブ特性による増減を反映する)。"""
    from effects.passives import adjust_max_hp

    return adjust_max_hp(
        card_db, card_id, attached_energy,
        _effective_max_hp_impl(card_db, card_id, attached_tool, stadium_in_play, attached_energy),
    )


def _effective_max_hp_impl(
    card_db,
    card_id: str,
    attached_tool: str | None,
    stadium_in_play: str | None = None,
    attached_energy: list[str] | None = None,
) -> int:
    """どうぐによる最大HP増加(ファイティングフューリーベルト等)・スタジアムによる最大HP減少
    (グラビティマウンテン等)・特定タイプのエネルギー添付による最大HP増加(イイネイヌ等)を
    反映した実際の最大HPを返す。"""
    card = card_db.get(card_id)
    base = card.hp if card is not None and card.hp else 0
    if base <= 0:
        return 0
    if attached_tool is not None and attached_tool in HP_BONUS_TOOLS:
        bonus, required_subtype = HP_BONUS_TOOLS[attached_tool]
        if required_subtype is None or (card is not None and required_subtype in card.subtypes):
            base += bonus
    if attached_tool is not None and attached_tool in NAME_PREFIX_HP_BONUS_TOOLS:
        required_prefix, bonus = NAME_PREFIX_HP_BONUS_TOOLS[attached_tool]
        if card is not None and card.name.startswith(required_prefix):
            base += bonus
    if stadium_in_play is not None and stadium_in_play in STAGE_HP_PENALTY_STADIUMS:
        penalty, required_subtype = STAGE_HP_PENALTY_STADIUMS[stadium_in_play]
        if card is not None and required_subtype in card.subtypes:
            base = max(base - penalty, 10)
    if card_id in HP_BONUS_IF_ENERGY_TYPE and attached_energy:
        from engine.energy import energy_matches_type

        bonus, required_type = HP_BONUS_IF_ENERGY_TYPE[card_id]
        if any(
            energy_matches_type(card_db, eid, required_type, card_id, attached_energy) for eid in attached_energy
        ):
            base += bonus
    if card_id in HP_BONUS_IF_ANY_SPECIAL_ENERGY and attached_energy:
        if any((e_card := card_db.get(eid)) is not None and e_card.is_special_energy for eid in attached_energy):
            base += HP_BONUS_IF_ANY_SPECIAL_ENERGY[card_id]
    from engine.energy import GROW_GRASS_ENERGY_ID, GROW_GRASS_ENERGY_REPRINT_ID, energy_effect_present

    if (
        attached_energy
        and energy_effect_present(attached_energy, GROW_GRASS_ENERGY_ID, GROW_GRASS_ENERGY_REPRINT_ID)
        and card is not None
        and "Grass" in card.types
    ):
        base += 20  # グロウ草エネルギー: 実カードテキスト「つけている草ポケモンは、最大HPが+20される」
    from effects.era_trainers import era_hp_adjust

    return era_hp_adjust(card, attached_tool, stadium_in_play, base)  # ジャイアントケープ/クリスタルウォール/アスペルチアシティジム/トレーニングセンター


# ---- 特性/ポケパワーを封じるスタジアム ----
# 値は「封じる対象のルールボックス種別」の集合。Noneなら「ルールボックス全般」を意味する。
ABILITY_BLOCKING_STADIUM_RULE_BOX_SUBTYPES: dict[str, set[str] | None] = {
    "swsh6-148": None,  # 頂への雪道(Path to the Peak): ルールボックス全般(V/VMAX/VSTAR/GX/EX/ex等)
    "sm10-183": {"GX", "EX"},  # 無人発電所(Power Plant): GX/EXのみ
    "xy5-140": {"Basic"},  # ひっそりとした山小屋(Silent Lab): たねポケモン全般(subtype判定を流用)
}
_RULE_BOX_SUBTYPES = {"V", "VMAX", "VSTAR", "GX", "EX", "ex", "Prism Star", "TAG TEAM", "Radiant", "MEGA", "Mega"}


_TEAM_ROCKETS_WATCHTOWER_IDS = {"sv10-180", "me2pt5-210"}  # ロケット団の監視塔(Team Rocket's Watchtower、印刷違い2種)


def abilities_blocked_by_stadium(stadium_in_play: str | None, card: Card) -> bool:
    if stadium_in_play in _TEAM_ROCKETS_WATCHTOWER_IDS:  # 無色タイプ全般
        return "Colorless" in card.types
    if stadium_in_play is None or stadium_in_play not in ABILITY_BLOCKING_STADIUM_RULE_BOX_SUBTYPES:
        return False
    target_subtypes = ABILITY_BLOCKING_STADIUM_RULE_BOX_SUBTYPES[stadium_in_play]
    card_subtypes = set(card.subtypes)
    if target_subtypes is None:
        return bool(card_subtypes & _RULE_BOX_SUBTYPES)
    return bool(card_subtypes & target_subtypes)


# ---- ポケモンのどうぐを無効化するスタジアム ----
TOOL_DISABLING_STADIUM_IDS = {"sv6-153", "sm6-111"}  # ジャミングタワー、フラダリラボ


def tools_disabled(stadium_in_play: str | None) -> bool:
    if stadium_in_play in TOOL_DISABLING_STADIUM_IDS:
        return True
    from engine.energy import current_card_db, current_state

    state, card_db = current_state(), current_card_db()
    if state is None or card_db is None:
        return False
    from effects.passives_ext import tools_disabled_by_ability

    return tools_disabled_by_ability(state, card_db)  # Tool Concealment/Fright Night


# ---- ダストダス(Garbodor)の特性「Garbotoxin」: どうぐがついていれば、Garbotoxin以外の特性を全て封じる ----
GARBOTOXIN_CARD_IDS = {"xy9-57", "bw11-68"}  # ダストダス(Garbodor、印刷違い2種)


def abilities_blocked_by_garbotoxin(state: "GameState", card: Card) -> bool:
    """場のどこかにどうぐのついたGarbodorがいれば、Garbotoxin以外の特性を全て封じる。
    v1簡略版: 手札・トラッシュのポケモンへの効果は、このエンジンではそもそも場のポケモンしか
    特性を使わないため対象外(実質的な挙動には影響しない)。"""
    if "Garbotoxin" in {a.name for a in card.abilities}:
        return False
    from effects.passives import ids_with_kind

    garbotoxin_ids = GARBOTOXIN_CARD_IDS | set(ids_with_kind("garbotoxin"))
    for player in state.players:
        for mon in player.all_pokemon_in_play():
            if mon.card_id in garbotoxin_ids and mon.attached_tool is not None:
                return True
    return False


# ---- テツノイバラex(Iron Thorns ex)の特性「Initialization Ability」:
# バトル場にいる間、自分・相手ともルールボックス持ちポケモンの特性を封じる(未来ポケモンを除く) ----
IRON_THORNS_EX_ID = "sv6-77"


GIRATINA_DEVOUR_LIGHT_ID = "xyp-184"


def abilities_blocked_by_giratina_devour_light(state: "GameState", card: Card) -> bool:
    """実カードテキスト: "Each Pokémon BREAK has no Abilities (this includes Abilities of its
    previous Evolution)." ギラティナ(xyp-184)がどちらかの場(バトル場・ベンチ問わず)にいる間、
    両プレイヤーのBREAKポケモンの特性を封じる(進化前から引き継いだ特性は、BREAKカード自身の
    IDにそのまま登録されているため、ここではsubtypeの判定だけでよい)。"""
    if "BREAK" not in card.subtypes:
        return False
    return any(p.card_id == GIRATINA_DEVOUR_LIGHT_ID for player in state.players for p in player.all_pokemon_in_play())


# ---- コダック(Psyduck)の特性「Damp」:
# 場のポケモン(両者とも)は、使用に自分自身のきぜつを必要とする特性を失う ----
DAMP_CARD_IDS = {"me2pt5-39", "me2pt5-40", "me2pt5-226"}  # 2種とも実カードテキストは同一の「Damp」
# 「自分自身をきぜつさせることで発動する特性」を持つカード(card_id, ability_name)。
# サマヨール/ヨノワールの「Cursed Blast」(2026-09-22発覚: コダックの「Damp」が場にいる時に
# これらの特性を封じる処理が未実装だった。ability_blocked_by_damp自体は実装済みだったが、
# このセットが空のままで実質的に何も封じていなかった)。
SELF_KO_REQUIRED_ABILITY_KEYS: set[tuple[str, str]] = {
    ("sv8pt5-36", "Cursed Blast"),  # サマヨール(Dusclops)
    ("sv8pt5-37", "Cursed Blast"),  # ヨノワール(Dusknoir)
}


WILD_GROWTH_HOLDER_ID = "me1-10"  # メガニウムの特性「Wild Growth」


def wild_growth_active(player) -> bool:
    """メガニウムの特性「Wild Growth」実カードテキスト: "Each Basic Grass Energy attached to all of
    your Pokémon provides GrassGrass Energy. The effect of Wild Growth doesn't stack." 場のどこかに
    メガニウムがいれば、自分の場の全ポケモンの基本くさエネルギーがコスト計算上2つぶんになる。"""
    return any(p.card_id == WILD_GROWTH_HOLDER_ID for p in player.all_pokemon_in_play())


WONDER_KISS_HOLDER_ID = "sv8-72"  # トゲキッスの特性「Wonder Kiss」


def wonder_kiss_active(state: "GameState", card_db, player) -> bool:
    """トゲキッスの特性「Wonder Kiss」実カードテキスト: "When your opponent's Active Pokémon is
    Knocked Out, flip a coin. If heads, take 1 more Prize card. The effect of Wonder Kiss doesn't
    stack." playerの場(バトル場・ベンチ問わず)にWonder Kiss持ちのトゲキッスがいて、特性が
    封じられていなければTrue。「doesn't stack」は、この関数を(トゲキッスの数に関わらず)
    1回だけ判定する呼び出し側の実装(engine.win_conditions.apply_knockouts)で自然に満たす。"""
    for mon in player.all_pokemon_in_play():
        if mon.card_id != WONDER_KISS_HOLDER_ID:
            continue
        card = card_db.get(mon.card_id)
        if card is None:
            continue
        if abilities_blocked_by_stadium(state.stadium_in_play, card):
            continue
        if abilities_blocked_by_garbotoxin(state, card):
            continue
        return True
    return False


def ability_blocked_by_damp(state: "GameState", card_id: str, ability_name: str) -> bool:
    """コダックの「Damp」: 場のどちらかにコダックがいれば、(card_id, ability_name)が
    SELF_KO_REQUIRED_ABILITY_KEYSに該当する特性は封じられる。"""
    if (card_id, ability_name) not in SELF_KO_REQUIRED_ABILITY_KEYS:
        return False
    return any(p.card_id in DAMP_CARD_IDS for player in state.players for p in player.all_pokemon_in_play())


def abilities_blocked_by_iron_thorns_ex(state: "GameState", card: Card) -> bool:
    """実カードテキスト: "As long as this Pokémon is in the Active Spot, Pokémon with a Rule Box
    in play (both yours and your opponent's) have no Abilities, except for Future Pokémon."
    発動アクションを持たない常時効果(Cornerstone Stance等と同じ扱い)。"""
    if "Future" in card.subtypes:
        return False
    if not (set(card.subtypes) & _RULE_BOX_SUBTYPES):
        return False
    return any(p.active is not None and p.active.card_id == IRON_THORNS_EX_ID for p in state.players)


# ---- はばたくかみ(Flutter Mane)の特性「Midnight Fluttering」:
# 自分のバトル場にいる間、相手のバトルポケモンの特性を(Midnight Fluttering自身を除いて)封じる ----
FLUTTER_MANE_ID = "sv5-78"


def abilities_blocked_by_flutter_mane(state: "GameState", card: Card, owner_index: int, is_active: bool) -> bool:
    """実カードテキスト: "As long as this Pokémon is in the Active Spot, your opponent's Active
    Pokémon has no Abilities, except for Midnight Fluttering." — 対象は相手の"バトル場"の
    ポケモンのみ(ベンチは対象外)で、封じられる側自身がMidnight Fluttering持ちなら例外的に働く。"""
    if not is_active:
        return False
    if "Midnight Fluttering" in {a.name for a in card.abilities}:
        return False
    opponent = state.player(state.opponent_index(owner_index))
    return opponent.active is not None and opponent.active.card_id == FLUTTER_MANE_ID


# ---- 相手のGX/EXバトルポケモンへの追加ダメージを持つどうぐ ----
GX_EX_BONUS_DAMAGE_TOOLS: dict[str, int] = {
    "sm3-162": 30,  # つよいちからのハチマキ(Choice Band、Burning Shadows版)
    "sm2-121": 30,  # つよいちからのハチマキ(Choice Band、Guardians Rising版)
}
_GX_EX_SUBTYPES_FOR_TOOLS = {"GX", "EX", "ex"}


def gx_ex_bonus_damage(tool_id: str | None, defender_card: Card) -> int:
    if tool_id is None or tool_id not in GX_EX_BONUS_DAMAGE_TOOLS:
        return 0
    if not (_GX_EX_SUBTYPES_FOR_TOOLS & set(defender_card.subtypes)):
        return 0
    return GX_EX_BONUS_DAMAGE_TOOLS[tool_id]


# ---- 自分がたねポケモンのときだけ、相手のバトルポケモンへ追加ダメージを持つどうぐ ----
BASIC_ONLY_BONUS_DAMAGE_TOOLS: dict[str, int] = {
    "xy9-99": 10,  # ファイティングフューリーベルト(Fighting Fury Belt): +40HPと合わせて対応
}


def basic_only_bonus_damage(tool_id: str | None, attacker_card: Card) -> int:
    if tool_id is None or tool_id not in BASIC_ONLY_BONUS_DAMAGE_TOOLS:
        return 0
    if "Basic" not in attacker_card.subtypes:
        return 0
    return BASIC_ONLY_BONUS_DAMAGE_TOOLS[tool_id]


# ---- 自分が「Future」サブタイプのときだけ、相手のバトルポケモンへ追加ダメージを持つどうぐ ----
FUTURE_BONUS_DAMAGE_TOOLS: dict[str, int] = {
    "sv5-149": 20,  # みらいステップアップパック(Future Booster Energy Capsule)
}


def future_bonus_damage(tool_id: str | None, attacker_card: Card) -> int:
    if tool_id is None or tool_id not in FUTURE_BONUS_DAMAGE_TOOLS:
        return 0
    if "Future" not in attacker_card.subtypes:
        return 0
    return FUTURE_BONUS_DAMAGE_TOOLS[tool_id]


# ---- 相手のGX/EXバトルポケモンから受けるダメージを軽減するどうぐ(防御側のどうぐ) ----
GX_EX_ATTACKER_DAMAGE_REDUCTION_TOOLS: dict[str, int] = {
    "sm8-169": 30,  # チョイスヘルメット(Choice Helmet)
}


def gx_ex_attacker_damage_reduction(tool_id: str | None, attacker_card: Card) -> int:
    if tool_id is None or tool_id not in GX_EX_ATTACKER_DAMAGE_REDUCTION_TOOLS:
        return 0
    if not (_GX_EX_SUBTYPES_FOR_TOOLS & set(attacker_card.subtypes)):
        return 0
    return GX_EX_ATTACKER_DAMAGE_REDUCTION_TOOLS[tool_id]


# ---- 自分にルール箱が無いときだけ、相手のバトル場のexポケモンへ追加ダメージを持つどうぐ ----
EX_ATTACKER_NO_RULE_BOX_BONUS_DAMAGE_TOOLS: dict[str, int] = {
    "rsv10pt5-80": 30,  # ブレイブバングル(Brave Bangle)
}


def ex_attacker_no_rule_box_bonus_damage(tool_id: str | None, attacker_card: Card, defender_card: Card) -> int:
    if tool_id is None or tool_id not in EX_ATTACKER_NO_RULE_BOX_BONUS_DAMAGE_TOOLS:
        return 0
    if _RULE_BOX_SUBTYPES & set(attacker_card.subtypes):
        return 0
    if "ex" not in defender_card.subtypes:
        return 0
    return EX_ATTACKER_NO_RULE_BOX_BONUS_DAMAGE_TOOLS[tool_id]


# ---- 相手のバトルポケモンへの追加ダメージを持つどうぐ(対象に制限なし) ----
FLAT_BONUS_DAMAGE_TOOLS: dict[str, int] = {
    "xy1-121": 20,  # ちからのハチマキ(Muscle Band)
}


def flat_bonus_damage(tool_id: str | None) -> int:
    if tool_id is None:
        return 0
    return FLAT_BONUS_DAMAGE_TOOLS.get(tool_id, 0)


# ---- サイドを相手より多く残している間、追加ダメージを持つどうぐ ----
PRIZE_LEAD_BONUS_DAMAGE_TOOLS: dict[str, int] = {
    "sv1-169": 30,  # まけんきハチマキ(Defiance Band)
}


def prize_lead_bonus_damage(tool_id: str | None, attacker_player, defender_player) -> int:
    if tool_id is None or tool_id not in PRIZE_LEAD_BONUS_DAMAGE_TOOLS:
        return 0
    if len(attacker_player.prizes) <= len(defender_player.prizes):
        return 0
    return PRIZE_LEAD_BONUS_DAMAGE_TOOLS[tool_id]


# ---- 自分自身がどく状態の間、追加ダメージを持つどうぐ ----
POISONED_SELF_BONUS_DAMAGE_TOOLS: dict[str, int] = {
    "sv8pt5-95": 40,  # モチこらし(Binding Mochi)
}


def poisoned_self_bonus_damage(tool_id: str | None, attacker_is_poisoned: bool) -> int:
    if tool_id is None or tool_id not in POISONED_SELF_BONUS_DAMAGE_TOOLS or not attacker_is_poisoned:
        return 0
    return POISONED_SELF_BONUS_DAMAGE_TOOLS[tool_id]


# ---- 相手のバトル場のEXポケモンへの追加ダメージを持つどうぐ(自分自身がEXの場合は乗らない) ----
EX_EXCLUSIVE_BONUS_DAMAGE_TOOLS: dict[str, int] = {
    "bw10-88": 30,  # シルバーバングル(Silver Bangle)
}


def ex_exclusive_bonus_damage(tool_id: str | None, attacker_card: Card, defender_card: Card) -> int:
    if tool_id is None or tool_id not in EX_EXCLUSIVE_BONUS_DAMAGE_TOOLS:
        return 0
    if "EX" in attacker_card.subtypes:
        return 0
    if "EX" not in defender_card.subtypes:
        return 0
    return EX_EXCLUSIVE_BONUS_DAMAGE_TOOLS[tool_id]


# ---- 相手のバトル場のexポケモン(SV期の小文字ex)への追加ダメージを持つどうぐ(自分自身への制約なし) ----
MODERN_EX_BONUS_DAMAGE_TOOLS: dict[str, int] = {
    "sv5-154": 50,  # プライムベルト(Maximum Belt、ACEスペック)
}


def modern_ex_bonus_damage(tool_id: str | None, defender_card: Card) -> int:
    if tool_id is None or tool_id not in MODERN_EX_BONUS_DAMAGE_TOOLS:
        return 0
    if "ex" not in defender_card.subtypes:
        return 0
    return MODERN_EX_BONUS_DAMAGE_TOOLS[tool_id]


# ---- 相手のバトル場のVポケモンへの追加ダメージを持つどうぐ(VMAX/VSTARは対象外) ----
V_BONUS_DAMAGE_TOOLS: dict[str, int] = {
    "sv2-176": 30,  # こだわりベルト(Choice Belt、SV期)
    "swsh9-135": 30,  # こだわりベルト(Choice Belt、SWSH期)
}


def v_bonus_damage(tool_id: str | None, defender_card: Card) -> int:
    if tool_id is None or tool_id not in V_BONUS_DAMAGE_TOOLS:
        return 0
    if "V" not in defender_card.subtypes:
        return 0
    return V_BONUS_DAMAGE_TOOLS[tool_id]


# ---- 闘ポケモンのワザに常時ダメージを上乗せする効果(相手のバトルポケモン限定)----
# 弱点・抵抗力適用前(攻撃側の効果)として加算される。effects.primitives._apply_attacker_side_damage_modifiers
# 経由で正しい順序で適用済み。
_DIANCIE_PRISM_STAR_ID = "sm6-74"  # ディアンシー◇「Princess's Cheers」: 自分のベンチにいる間、+20
_REGIROCK_EX_ID = "xy10-43"  # レジロックEX「Regi Power」: レジロックEX以外の闘ポケモンに+10
_STRONG_ENERGY_ID = AliasStr("xy10-115")  # つよいエネルギー: ついている闘ポケモンに+20


# ---- ラフレシア(Vileplume)の特性「Irritating Pollen」: 場に出ている間、両プレイヤーがグッズを使えない ----
VILEPLUME_IRRITATING_POLLEN_ID = "xy7-3"  # ラフレシア(Vileplume)


TREVENANT_FORESTS_CURSE_ID = "xy1-55"  # オーロット「Forest's Curse」: バトル場にいる間、相手はグッズを使えない
_ITEMS_BLOCKED_BY_ACTIVE_HOLDER_IDS = {
    TREVENANT_FORESTS_CURSE_ID,
    "sv9-95",  # バンギラス(Tyranitar)特性「Daunting Gaze」: バトル場にいる間、相手はグッズを使えない
}


def items_blocked_by_active_trevenant(opponent) -> bool:
    """opponentのバトル場にForest's Curse持ちのオーロットがいれば、その相手(=opponentの対戦相手)は
    グッズを使えない。ラフレシアと違い、バトル場固定・相手側のみが対象の非対称な効果。"""
    mon = opponent.active
    return mon is not None and mon.card_id in _ITEMS_BLOCKED_BY_ACTIVE_HOLDER_IDS


def items_blocked_by_vileplume(state: "GameState", card_db) -> bool:
    for player in state.players:
        for mon in player.all_pokemon_in_play():
            if mon.card_id != VILEPLUME_IRRITATING_POLLEN_ID:
                continue
            card = card_db.get(mon.card_id)
            if card is None:
                continue
            if abilities_blocked_by_stadium(state.stadium_in_play, card):
                continue
            if abilities_blocked_by_garbotoxin(state, card):
                continue
            return True
    return False


# ---- デオキシスEX「Power Connect」: 自分のNプラズマ団ポケモンのワザ(デオキシスEX自身を除く)は、
# 相手のバトルポケモンに常時+10(弱点・抵抗力適用前) ----
_DEOXYS_EX_POWER_CONNECT_ID = "bw9-53"


def team_plasma_power_connect_bonus_damage(player, attacker_mon, attacker_card: Card) -> int:
    if "Team Plasma" not in attacker_card.subtypes:
        return 0
    if attacker_mon.card_id == _DEOXYS_EX_POWER_CONNECT_ID:
        return 0
    if any(mon.card_id == _DEOXYS_EX_POWER_CONNECT_ID for mon in player.all_pokemon_in_play()):
        return 10
    return 0


# ---- パワータブレット(Power Tablet): この番の間、自分のFusion Strikeポケモンのワザは
# 相手のバトルポケモンに+30(弱点・抵抗力適用前) ----
def fusion_strike_damage_bonus(attacker_player, attacker_card: Card) -> int:
    if "Fusion Strike" not in attacker_card.subtypes:
        return 0
    if (
        attacker_player.fusion_strike_damage_bonus_until_turn <= 0
        or attacker_player.fusion_strike_damage_bonus_until_turn < attacker_player.turns_taken
    ):
        return 0
    return 30


# ---- スグリ(Kieran): この番の間、自分のワザは相手のバトル場のex/Vポケモンに+30(VMAX/VSTARは対象外、弱点・抵抗力適用前) ----
def kieran_ex_v_bonus_damage(attacker_player, defender_card: Card, defender_is_active: bool) -> int:
    if (
        not defender_is_active
        or attacker_player.ex_v_bonus_damage_until_turn <= 0
        or attacker_player.ex_v_bonus_damage_until_turn < attacker_player.turns_taken
    ):
        return 0
    if "ex" in defender_card.subtypes or ("V" in defender_card.subtypes and "VMAX" not in defender_card.subtypes and "VSTAR" not in defender_card.subtypes):
        return 30
    return 0


# ---- からておうの稽古(Black Belt's Training): この番の間、自分のワザは相手のバトル場のexポケモンに+40(弱点・抵抗力適用前) ----
def black_belt_training_bonus_damage(attacker_player, defender_card: Card, defender_is_active: bool) -> int:
    if (
        not defender_is_active
        or attacker_player.ex_bonus_damage_40_until_turn <= 0
        or attacker_player.ex_bonus_damage_40_until_turn < attacker_player.turns_taken
    ):
        return 0
    return 40 if "ex" in defender_card.subtypes else 0


def fighting_pokemon_flat_bonus_damage(
    state: "GameState", acting_player_index: int, attacker_mon, attacker_card: Card
) -> int:
    if "Fighting" not in attacker_card.types:
        return 0
    player = state.player(acting_player_index)
    bonus = 0
    if any(mon.card_id == _DIANCIE_PRISM_STAR_ID for mon in player.bench):
        bonus += 20
    if any(
        mon.card_id == _REGIROCK_EX_ID and mon is not attacker_mon for mon in player.all_pokemon_in_play()
    ):
        bonus += 10
    from engine.energy import energy_effect_present

    if energy_effect_present(attacker_mon.attached_energy, _STRONG_ENERGY_ID):
        bonus += 20
    return bonus


# ---- イイネイヌ(Okidogi)「アドレナパワー」: 悪エネルギーがついていれば相手バトルポケモンへのダメージ+100 ----
_ADRENA_POWER_ENERGY_BONUS_IDS: dict[str, tuple[int, str]] = {
    "sv8a-90": (100, "Darkness"),
}


def adrena_power_bonus_damage(card_db, attacker_mon, attacker_card: Card) -> int:
    if attacker_card.id not in _ADRENA_POWER_ENERGY_BONUS_IDS:
        return 0
    from engine.energy import energy_matches_type

    bonus, required_type = _ADRENA_POWER_ENERGY_BONUS_IDS[attacker_card.id]
    if any(
        energy_matches_type(card_db, eid, required_type, attacker_card.id, attacker_mon.attached_energy)
        for eid in attacker_mon.attached_energy
    ):
        return bonus
    return 0


# ---- ファイティングスタジアム(Fighting Stadium): 闘ポケモンのワザは相手のバトル場のEXポケモンに+20(両プレイヤー) ----
FIGHTING_STADIUM_ID = "xy3-90"


def fighting_stadium_ex_bonus_damage(stadium_in_play: str | None, attacker_card: Card, defender_card: Card) -> int:
    if stadium_in_play != FIGHTING_STADIUM_ID or "Fighting" not in attacker_card.types:
        return 0
    if not ({"EX", "ex"} & set(defender_card.subtypes)):
        return 0
    return 20


# ---- ゼロの大空洞(Area Zero Underdepths): テラスタルポケモンが場にいるプレイヤーはベンチ8匹まで ----
AREA_ZERO_UNDERDEPTHS_ID = "sv7-131"  # ゼロの大空洞
EXPANDED_BENCH_SIZE = 8


def player_has_tera_pokemon(player, card_db) -> bool:
    return any(
        (c := card_db.get(mon.card_id)) is not None and "Tera" in c.subtypes for mon in player.all_pokemon_in_play()
    )


COLLAPSED_STADIUM_ID = "swsh9-137"  # 崩れたスタジアム(Collapsed Stadium): 両プレイヤーともベンチ上限4

# スカイフィールド(Sky Field): 両プレイヤーともベンチ上限8(テラスタル等の条件なし)。
# 実カードにはこのスタジアムが場を離れる際「ベンチが5匹を超えていればカードの持ち主から先に
# 5匹になるまで選んで トラッシュする」という追加ルールがあるが、v1簡略版としてこの離脱時の
# 強制トラッシュ選択は未実装(スタジアムが入れ替わった時点でeffective_bench_limitが5に戻るのみで、
# 既に6匹以上ベンチにいる場合でも自動トラッシュはされない)。
SKY_FIELD_ID = "xy6-89"
SKY_FIELD_EXPANDED_BENCH_SIZE = 8


PARALLEL_CITY_ID = "xy8-145"  # パラレルシティ: 出すときに選んだ「↓」側のプレイヤーはベンチ上限3


def effective_bench_limit(state: "GameState", player, card_db) -> int:
    """通常はMAX_BENCH_SIZE(5)。ゼロの大空洞が場にあり、そのプレイヤーが自分の場に
    テラスタルポケモンを1匹以上出していれば8まで拡張される。スカイフィールドが場にあれば
    無条件で両プレイヤーとも8まで拡張される。崩れたスタジアムが場にあれば両プレイヤーとも4に縮小される。
    パラレルシティが場にあれば、出すときに選んだ「↓」側のプレイヤーのみベンチ上限3に縮小される
    (もう片方のプレイヤーは通常通り)。"""
    from engine.state import MAX_BENCH_SIZE

    base = _stadium_bench_limit(state, player, card_db)
    from effects.passives_cond import bench_limit_override

    return bench_limit_override(state, card_db, 0 if player is state.players[0] else 1, base)  # 特性によるベンチ上限の変更


def _stadium_bench_limit(state: "GameState", player, card_db) -> int:
    from engine.state import MAX_BENCH_SIZE

    if state.stadium_in_play == AREA_ZERO_UNDERDEPTHS_ID and player_has_tera_pokemon(player, card_db):
        return EXPANDED_BENCH_SIZE
    if state.stadium_in_play == SKY_FIELD_ID:
        return SKY_FIELD_EXPANDED_BENCH_SIZE
    if state.stadium_in_play == COLLAPSED_STADIUM_ID:
        return 4
    if state.stadium_in_play == PARALLEL_CITY_ID and state.stadium_orientation_target is not None:
        player_index = 0 if player is state.players[0] else 1
        if player_index == state.stadium_orientation_target:
            return 3
    return MAX_BENCH_SIZE


# ---- 「1回の自分の番にワザを2回使ってよい」特性 ----
# ホルビー(xy5-121)の「Ω Barrage」: 常に対象。カミッチュ(sv6-103)の「おまつりおんど」:
# 場に「お祭り会場」(sv6-149)が出ているときのみ対象。値は条件となるスタジアムのcard_id
# (Noneなら無条件)。
FESTIVAL_GROUNDS_ID = "sv6-149"
ATTACK_TWICE_ABILITY_CARD_IDS: dict[str, str | None] = {
    "xy5-121": None,
    "sv6-103": FESTIVAL_GROUNDS_ID,
}


def attack_twice_eligible(state: "GameState", player) -> bool:
    """このプレイヤーの現在のバトルポケモンが「1回の自分の番にワザを2回使ってよい」特性を持ち、
    かつ条件(スタジアム等)を満たしているか。この番で既にこのボーナス攻撃を使い切っていれば
    Falseになる(1番につき1回まで)。"""
    if player.used_attack_twice_bonus_this_turn or player.active is None:
        return False
    required_stadium = ATTACK_TWICE_ABILITY_CARD_IDS.get(player.active.card_id, "__not_found__")
    if required_stadium == "__not_found__":
        return False
    if required_stadium is not None and state.stadium_in_play != required_stadium:
        return False
    return True


# =====================================================================================
# 特性の封印判定(passive特性・起動型特性とも共通)と、デッキ採用カード監査(2026-10-06)で追加した
# 常時発動の特性(ルール変更型/修正型)。
# 以前は封印判定(abilities_blocked_by_*)が起動型特性(legal_actions._ability_actions)でしか
# 使われておらず、ダメージ計算等に組み込まれた常時特性は、ダストダスの「Garbotoxin」等で封じられても
# 効いてしまっていた。新規に追加する常時特性は必ず ability_suppressed() を通すこと。
# =====================================================================================

MIMIKYU_SHADOW_BOX_ABILITY = "Shadow Box"  # ミミッキュ(sm12-97)
JOLTEON_THUNDEROUS_AWAKENING_ABILITY = "Thunderous Awakening"  # サンダース(swsh4-47)
MEMORY_CAPSULE_ID = "swsh4-155"  # メモリカプセル


def ability_suppressed(
    state: "GameState", card_db, owner_index: int, mon, *, _holder_check: bool = False
) -> bool:
    """owner_indexのプレイヤーの場にいるmonの特性が(スタジアム・他のポケモンの特性・サポート等で)
    封じられているか。_holder_check=Trueは、封印効果の発生源(ミミッキュの「Shadow Box」等)自身が
    封じられているかを調べるときに、相互再帰を避けるための内部フラグ。"""
    card = card_db.get(mon.card_id)
    if card is None:
        return False
    owner = state.player(owner_index)
    if (
        state.global_ability_lock_owner >= 0
        and state.player(state.global_ability_lock_owner).turns_taken <= state.global_ability_lock_until_turn
    ):
        return True  # サポート「Hex Maniac」: 相手の次の番が終わるまで両者の特性が使えない
    if state.opponent_ability_lock_target == owner_index and owner.turns_taken <= state.opponent_ability_lock_until_turn:
        return True  # ゲッコウガの「Shadow Stitching」等
    if owner.active_abilities_blocked_on_turn == state.turn_number and mon is owner.active:
        return True  # キャンセリングコロン: この番の間、バトルポケモンは特性を持たない
    if mon.abilities_off_until_turn > 0:
        # Gastro Acid: 「あなたの次の番の終わりまで、そのポケモンは特性を持たない」。攻撃側(相手)のturns_takenで判定し、
        # 攻撃側の次の番が終わったら(相手=持ち主の番になったら)解除する
        attacker_index = state.opponent_index(owner_index)
        attacker = state.player(attacker_index)
        if attacker.turns_taken < mon.abilities_off_until_turn or (
            attacker.turns_taken == mon.abilities_off_until_turn and state.current_player == attacker_index
        ):
            return True
    if abilities_blocked_by_stadium(state.stadium_in_play, card):
        return True
    if abilities_blocked_by_garbotoxin(state, card):
        return True
    if abilities_blocked_by_iron_thorns_ex(state, card):
        return True
    if abilities_blocked_by_flutter_mane(state, card, owner_index, mon is owner.active):
        return True
    if abilities_blocked_by_giratina_devour_light(state, card):
        return True
    from effects.passives import break_has_no_abilities

    if not _holder_check and break_has_no_abilities(state, card_db, card):
        return True  # Devour Light: ポケモンBREAKは特性を持たない
    if not _holder_check:
        if abilities_blocked_by_shadow_box(state, card_db, card, mon):
            return True
        if abilities_blocked_by_thunderous_awakening(state, card_db, card):
            return True
        from effects.passives_ext import abilities_locked_except_type

        if abilities_locked_except_type(state, card_db, card):
            return True  # Bide Barricade
        from effects.passives_cond import cond_ability_locked

        if cond_ability_locked(state, card_db, card, mon, owner_index):
            return True  # Freezing Gaze/Lazy/Sol Shade等
    return False


def ability_holders_in_play(
    state: "GameState",
    card_db,
    ability_name: str,
    *,
    owner_index: int | None = None,
    card_name: str | None = None,
    _holder_check: bool = False,
) -> list:
    """場(両者またはowner_index側のみ)にいて、指定の特性を持ち、かつその特性が封じられていないポケモン。
    ability_nameは特性の英語名(カードDB上の名前)、card_nameを指定すると同名カードにも限定する。"""
    holders = []
    for idx, player in enumerate(state.players):
        if owner_index is not None and idx != owner_index:
            continue
        for mon in player.all_pokemon_in_play():
            card = card_db.get(mon.card_id)
            if card is None:
                continue
            if card_name is not None and card.name != card_name:
                continue
            if not any(a.name == ability_name for a in card.abilities):
                continue
            if ability_suppressed(state, card_db, idx, mon, _holder_check=_holder_check):
                continue
            holders.append(mon)
    return holders


def abilities_blocked_by_shadow_box(state: "GameState", card_db, card: Card, mon) -> bool:
    """ミミッキュ(sm12-97)の特性「Shadow Box」実カードテキスト: "Pokémon-GX that have any damage
    counters on them (both yours and your opponent's) have no Abilities." — ダメカンがのったGXポケモン
    (自分・相手とも、ミミッキュ自身はGXではない)は特性を失う。"""
    if "GX" not in card.subtypes or mon.damage <= 0:
        return False
    return bool(
        ability_holders_in_play(state, card_db, MIMIKYU_SHADOW_BOX_ABILITY, card_name="Mimikyu", _holder_check=True)
    )


def abilities_blocked_by_thunderous_awakening(state: "GameState", card_db, card: Card) -> bool:
    """サンダース(swsh4-47)の特性「Thunderous Awakening」実カードテキスト: "If this Pokémon has a Memory
    Capsule attached, Water Pokémon in play (both yours and your opponent's) have no Abilities." """
    if "Water" not in card.types:
        return False
    for idx, player in enumerate(state.players):
        for mon in player.all_pokemon_in_play():
            if mon.attached_tool != MEMORY_CAPSULE_ID:
                continue
            holder_card = card_db.get(mon.card_id)
            if holder_card is None or not any(a.name == JOLTEON_THUNDEROUS_AWAKENING_ABILITY for a in holder_card.abilities):
                continue
            if ability_suppressed(state, card_db, idx, mon, _holder_check=True):
                continue
            return True
    return False


# ---- ジラーチGX「Psychic Zone」: 場にいる間、両者のポケモンはワザのダメージを受けるときエスパーの弱点を計算しない ----
def psychic_weakness_ignored(state: "GameState", card_db) -> bool:
    return bool(ability_holders_in_play(state, card_db, "Psychic Zone", card_name="Jirachi-GX"))


# ---- サンダー(pgo-29)「Lightning Symbol」: 自分のたねの雷ポケモン(サンダー自身を除く)のワザは、
# 相手のバトルポケモンへのダメージが+10(弱点・抵抗力を計算する前)。サンダーが複数いれば重複する ----
def lightning_symbol_bonus_damage(state: "GameState", card_db, owner_index: int, attacker_card: Card) -> int:
    if not attacker_card.is_basic or "Lightning" not in attacker_card.types or attacker_card.name == "Zapdos":
        return 0
    holders = ability_holders_in_play(state, card_db, "Lightning Symbol", owner_index=owner_index, card_name="Zapdos")
    return 10 * len(holders)


# ---- オドリドリ(swsh8-42)「Lesson in Zeal」: 自分のフュージョンストライクポケモンは相手のポケモンの
# ワザで受けるダメージが-20(弱点・抵抗力の後)。この特性は2つ以上同時には効かない ----
def lesson_in_zeal_reduction(state: "GameState", card_db, defender_owner_index: int, defender_card: Card) -> int:
    if "Fusion Strike" not in defender_card.subtypes:
        return 0
    if ability_holders_in_play(
        state, card_db, "Lesson in Zeal", owner_index=defender_owner_index, card_name="Oricorio"
    ):
        return 20
    return 0


# ---- ブースター(xy7-13)「Flare Effect」: 自分の場の進化1ポケモンはすべて、元のタイプに加えてほのおタイプにもなる ----
def effective_attacker_types(state: "GameState", card_db, owner_index: int, card: Card) -> tuple[str, ...]:
    """ワザを使うポケモンのタイプ(弱点判定・「ほのおポケモンからのダメージを受けない」等の攻撃側タイプ判定用)。
    ブースターの「Flare Effect」で追加されるほのおタイプを反映する。"""
    types = tuple(card.types)
    if "Stage 1" in card.subtypes and "Fire" not in types:
        if ability_holders_in_play(state, card_db, "Flare Effect", owner_index=owner_index, card_name="Flareon"):
            return types + ("Fire",)
    return types


# ---- 特殊状態にならないポケモン(ビリジオンEX「Verdant Wind」: くさエネルギー、コバルオンGX「Metal Symbol」:
# はがねエネルギー、お祭り会場(スタジアム): エネルギーがついているポケモン) ----
def status_conditions_blocked(state: "GameState", card_db, owner_index: int, mon) -> bool:
    if state.stadium_in_play == FESTIVAL_GROUNDS_ID and mon.attached_energy:
        return True
    from effects.era_trainers import era_status_blocked
    from effects.passives import status_immune_all

    if era_status_blocked(state, mon, card_db):
        return True  # スパークリングローブ/スチールシェルター
    from effects.era_primitives_f import era_status_immune

    if era_status_immune(state, owner_index, mon):
        return True  # Shining Breath
    if status_immune_all(state, card_db, owner_index, mon):
        return True  # Immunity/Sweet Veil等(生成されたパッシブ特性)

    def has_basic_energy(energy_type: str) -> bool:
        return any(
            (e := card_db.get(eid)) is not None and e.basic_energy_type == energy_type for eid in mon.attached_energy
        )

    if has_basic_energy("Grass") and ability_holders_in_play(
        state, card_db, "Verdant Wind", owner_index=owner_index, card_name="Virizion-EX"
    ):
        return True
    if has_basic_energy("Metal") and ability_holders_in_play(
        state, card_db, "Metal Symbol", owner_index=owner_index, card_name="Cobalion-GX"
    ):
        return True
    return False


# ---- マギアナEX(xy11-75)「Mystic Heart」: はがねエネルギーがついている自分のポケモンは、相手のワザの
# ダメージ以外の効果を受けない ----
def attack_effects_blocked_by_mystic_heart(state: "GameState", card_db, owner_index: int, mon) -> bool:
    if not any(
        (e := card_db.get(eid)) is not None and e.basic_energy_type == "Metal" for eid in mon.attached_energy
    ):
        return False
    return bool(ability_holders_in_play(state, card_db, "Mystic Heart", owner_index=owner_index, card_name="Magearna-EX"))


def enforce_status_protection(state: "GameState", card_db) -> None:
    """「特殊状態にならない」ポケモン(status_conditions_blocked)に既に特殊状態がかかっていれば、すべて解除する
    (「Remove any Special Conditions affecting those Pokémon」)。エネルギーを後からつけた場合・ポケモンが
    場に出た場合・効果で特殊状態が付与された場合など、経路を問わず1アクションごとの最後に呼ぶ。"""
    from effects.passives import blocked_statuses

    for idx, player in enumerate(state.players):
        for mon in player.all_pokemon_in_play():
            if mon.status.is_any and status_conditions_blocked(state, card_db, idx, mon):
                mon.status.clear_all()
                continue
            partial = blocked_statuses(state, card_db, idx, mon) if mon.status.is_any else set()
            if "poisoned" in partial:
                mon.status.poisoned = False
            if "burned" in partial:
                mon.status.burned = False
            for name in ("asleep", "confused", "paralyzed"):
                if name in partial and mon.status.exclusive.name == name.upper():
                    mon.status.exclusive = type(mon.status.exclusive).NONE


# ---- リククラゲ(sv4-17)「Slime Mold Colony」: 相手のトラッシュのカードは、相手の特性やトレーナーズの効果では
# 手札に加えられない(ワザ由来の効果には及ばない) ----
def discard_to_hand_blocked(state: "GameState", card_db, discard_owner_index: int) -> bool:
    """discard_owner_indexのトラッシュから、特性またはトレーナーズの効果でカードを手札に加えられないか
    (相手の場にリククラゲがいて、その特性が封じられていない場合)。"""
    opponent_index = state.opponent_index(discard_owner_index)
    return bool(
        ability_holders_in_play(state, card_db, "Slime Mold Colony", owner_index=opponent_index, card_name="Toedscruel")
    )


# 発動アクションを持たず、engine/continuous.py・effects/primitives.py・engine/legal_actions.py等の判定関数で
# 常時効果として実装している特性の名前(scripts/dump_card_implementation_status.pyが「実装済み」と判定するための一覧)。
PASSIVE_ABILITY_NAMES = frozenset({
    "Shadow Box", "Thunderous Awakening", "Psychic Zone", "Lightning Symbol", "Lesson in Zeal", "Flare Effect",
    "Verdant Wind", "Metal Symbol", "Mystic Heart", "Slime Mold Colony", "Evolutionary Advantage", "Lost Provisions",
    "Shining Mane", "Wave Veil", "Bench Barrier",
})
