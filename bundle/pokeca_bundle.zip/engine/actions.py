"""プレイヤーが選べる行動の定義。

`legal_actions.py` が現在の状態から合法なActionを列挙し、
`rules_engine.apply_action` がそれを状態に適用する。
"""

from __future__ import annotations

from dataclasses import dataclass
from enum import Enum, auto


class Zone(Enum):
    ACTIVE = auto()
    BENCH = auto()


@dataclass(frozen=True)
class PlayBasicPokemon:
    """手札のたねポケモンをベンチに出す。"""

    hand_index: int


@dataclass(frozen=True)
class Evolve:
    """手札の進化ポケモンを場のポケモンに重ねる。"""

    hand_index: int
    target_zone: Zone
    target_bench_index: int | None = None  # target_zone==BENCH のとき使用


@dataclass(frozen=True)
class PlayLevelUp:
    """手札のLv.Xカードを、対応する場のポケモンに重ねる。

    通常の進化(Evolve)と異なり、出したばかりのターンでも使え、ターン制限を受けない。
    """

    hand_index: int
    target_zone: Zone
    target_bench_index: int | None = None


@dataclass(frozen=True)
class AttachEnergy:
    hand_index: int
    target_zone: Zone
    target_bench_index: int | None = None


@dataclass(frozen=True)
class PlayItem:
    hand_index: int
    target_bench_index: int | None = None  # 効果が対象を必要とする場合に使用
    paired_hand_index: int | None = None  # 「2枚同時使用」カード(カスタムキャッチャー等)の2枚目
    extra_hand_indices: tuple = ()  # 「4枚同時使用」カード(ミッシングクローバー/カルテットストーン)の、3枚目・4枚目(paired_hand_indexが2枚目)


@dataclass(frozen=True)
class PlaySupporter:
    hand_index: int
    target_bench_index: int | None = None


@dataclass(frozen=True)
class PlayStadium:
    hand_index: int
    orientation_target: int | None = None  # パラレルシティ等「出すときに向きを選べる」スタジアム用


@dataclass(frozen=True)
class PlayPokemonTool:
    hand_index: int
    target_zone: Zone
    target_bench_index: int | None = None


@dataclass(frozen=True)
class UseAbility:
    zone: Zone
    bench_index: int | None
    target_bench_index: int | None = None  # 例: Venusaurのエネルギー移動先
    from_tool: bool = False  # True: ポケモン自身ではなく、ついているどうぐが与える特性(森の封印石の「Star Alchemy」)を使う


@dataclass(frozen=True)
class DiscardRoboSubstitute:
    """みがわりロボ(xy4-102)を、自分の番のいつでも(ワザの前に)場からトラッシュしてよい効果。"""

    zone: Zone
    bench_index: int | None = None


@dataclass(frozen=True)
class Retreat:
    bench_index: int  # 新しくバトル場に出すベンチのインデックス


@dataclass(frozen=True)
class Attack:
    attack_index: int
    target_bench_index: int | None = None  # ベンチ範囲攻撃の対象指定に使う場合がある


@dataclass(frozen=True)
class UseBorrowedAttack:
    """ミュウツー&ミュウGXの「パーフェクション」等、自分のベンチ/トラッシュのGX/EXポケモンのワザを
    借りて使う。source_zoneは"bench"か"discard"、source_card_idは借りる元のカードID、
    attack_nameは借りるワザ名。コストは自分自身(バトル場のポケモン)についているエネルギーで支払う。
    """

    source_zone: str
    source_card_id: str
    attack_name: str
    target_bench_index: int | None = None


@dataclass(frozen=True)
class ChooseNewActive:
    """きぜつ後、ベンチから新しいバトルポケモンを選ぶ強制アクション。"""

    bench_index: int


@dataclass(frozen=True)
class EndTurn:
    pass


@dataclass(frozen=True)
class ChooseInitialActive:
    """対戦準備: 手札のたねポケモンから最初のバトルポケモンを選ぶ。"""

    hand_index: int


@dataclass(frozen=True)
class ConfirmSetupDone:
    """対戦準備: ベンチ配置を終えて準備完了を宣言する(先攻→後攻の順)。"""

    pass


@dataclass(frozen=True)
class ChooseMulliganBonusDrawCount:
    """対戦準備: 相手がマリガンした回数ぶんのボーナスドローのうち、実際に何枚引くかを選ぶ
    (公式ルール上、相手のマリガン回数までなら好きな枚数を引いてよく、全部引く必要はない)。
    countは0以上、相手のマリガン回数以下でなければならない。"""

    count: int


@dataclass(frozen=True)
class AcceptTrigger:
    """「〜してもよい」系ポケパワーの発動を選ぶ(対象が必要な場合はtarget_bench_indexで指定)。"""

    target_bench_index: int | None = None


@dataclass(frozen=True)
class DeclineTrigger:
    """「〜してもよい」系ポケパワーを使わないことを選ぶ。"""

    pass


@dataclass(frozen=True)
class ResolveDamageDistribution:
    """保留中のダメカン自由配分(PendingDamageDistribution)で、各対象への配分数を確定する。

    counts は対象一覧(bench_onlyでなければ[バトル場, ベンチ0, ベンチ1, ...]、bench_onlyなら
    [ベンチ0, ベンチ1, ...])に対応する配分数のタプルで、合計が total_counters と一致する必要がある。
    """

    counts: tuple[int, ...]


@dataclass(frozen=True)
class UseStadiumAbility:
    """場に出ているスタジアムの「各プレイヤーの番に1回使ってよい」効果を使う(ウルトラスペース等)。"""

    pass


@dataclass(frozen=True)
class UsePowerSpray:
    """パワースプレー割り込みウィンドウ中、パワースプレーを使って相手のポケパワーを打ち消す。"""

    pass


@dataclass(frozen=True)
class PassPowerSprayWindow:
    """パワースプレー割り込みウィンドウ中、何もせず相手のポケパワーの効果をそのまま解決させる。"""

    pass


@dataclass(frozen=True)
class UseDiscardAbility:
    """トラッシュにいる状態で発動する「〜してもよい」系の特性を使い、そのポケモンをベンチに出す
    (ギラティナ(smp-SM151)の「Distortion Door」等)。discard_indexは自分のトラッシュ内の位置。"""

    discard_index: int
    from_hand: bool = False  # Trueなら、手札にいるポケモンの特性(タブンネの「Busybody」)。discard_indexは手札内の位置


@dataclass(frozen=True)
class ResolveSearchChoice:
    """保留中の山札/トラッシュ検索(PendingSearchChoice)で選んだカードを確定する。

    selected_indices は PendingSearchChoice.card_ids に対するインデックス。
    """

    selected_indices: tuple[int, ...] = ()


Action = (
    PlayBasicPokemon
    | Evolve
    | PlayLevelUp
    | AttachEnergy
    | PlayItem
    | PlaySupporter
    | PlayStadium
    | PlayPokemonTool
    | UseAbility
    | Retreat
    | Attack
    | ChooseNewActive
    | EndTurn
    | ChooseInitialActive
    | ConfirmSetupDone
    | ResolveSearchChoice
    | AcceptTrigger
    | DeclineTrigger
    | UseStadiumAbility
    | ResolveDamageDistribution
    | UseBorrowedAttack
    | UsePowerSpray
    | PassPowerSprayWindow
    | UseDiscardAbility
    | DiscardRoboSubstitute
)
