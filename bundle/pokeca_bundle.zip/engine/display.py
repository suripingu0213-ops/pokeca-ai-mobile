"""CLIとWebアプリで共有する表示用ヘルパー(行動の説明文生成など)。"""

from __future__ import annotations

import json
from pathlib import Path

from cards.card_db import CardDatabase
from engine.continuous import effective_max_hp
from engine.energy import RAPID_STRIKE_TOKEN, WILDCARD_TOKEN, energy_tokens
from engine.actions import (
    AcceptTrigger,
    Action,
    Attack,
    AttachEnergy,
    ChooseInitialActive,
    ChooseMulliganBonusDrawCount,
    ChooseNewActive,
    ConfirmSetupDone,
    DeclineTrigger,
    EndTurn,
    Evolve,
    PlayBasicPokemon,
    PlayItem,
    PlayLevelUp,
    PlayPokemonTool,
    PlaySupporter,
    PlayStadium,
    PassPowerSprayWindow,
    ResolveDamageDistribution,
    ResolveSearchChoice,
    Retreat,
    UseAbility,
    UseBorrowedAttack,
    UseDiscardAbility,
    UsePowerSpray,
    UseStadiumAbility,
    Zone,
)
from engine.legal_actions import legal_actions, next_actor
from engine.state import GameState, PlayerState, PokemonInPlay


_JP_NAMES_PATH = Path(__file__).resolve().parent.parent / "cards" / "jp_names.json"
with open(_JP_NAMES_PATH, encoding="utf-8") as _f:
    _JP_NAMES: dict[str, str] = {k: v for k, v in json.load(_f).items() if not k.startswith("_")}

_JP_EFFECTS_PATH = Path(__file__).resolve().parent.parent / "cards" / "jp_effects.json"
with open(_JP_EFFECTS_PATH, encoding="utf-8") as _f:
    _JP_EFFECTS: dict[str, dict] = {k: v for k, v in json.load(_f).items() if not k.startswith("_")}


_STATUS_TYPE_LABELS = {
    "asleep": "ねむり", "poisoned": "どく", "burned": "やけど", "confused": "こんらん", "paralyzed": "マヒ",
    "Grass": "くさ", "Fire": "ほのお", "Water": "みず", "Lightning": "でんき", "Psychic": "エスパー", "Fighting": "かくとう",
    "Darkness": "あく", "Metal": "はがね", "Fairy": "フェアリー", "Dragon": "ドラゴン",
}


def _status_or_type_label(key: str) -> str:
    return _STATUS_TYPE_LABELS.get(key, key)


def card_name(card_db: CardDatabase, card_id: str) -> str:
    if card_id in _JP_NAMES:
        return _JP_NAMES[card_id]
    card = card_db.get(card_id)
    return card.name if card else card_id


def jp_attack(card_id: str, attack) -> tuple[str, str]:
    override = _JP_EFFECTS.get(card_id, {}).get("attacks", {}).get(attack.name)
    return (override["name"], override["text"]) if override else (attack.name, attack.text)


def jp_ability(card_id: str, ability) -> tuple[str, str]:
    override = _JP_EFFECTS.get(card_id, {}).get("abilities", {}).get(ability.name)
    return (override["name"], override["text"]) if override else (ability.name, ability.text)


_ABILITY_KIND_LABELS = {"Poké-Power": "ポケパワー", "Poké-Body": "ポケボディ"}


def ability_kind_label(ability_type: str) -> str:
    """特性の呼び方は時代によって違う(現行は「特性」、DP〜HGSS期は「ポケパワー」「ポケボディ」)。"""
    return _ABILITY_KIND_LABELS.get(ability_type, "特性")


def ability_kind_label_for_card(card_db: CardDatabase, card_id: str) -> str:
    card = card_db.get(card_id)
    if card and card.abilities:
        return ability_kind_label(card.abilities[0].ability_type)
    return "特性"


def jp_trainer_text(card_id: str, fallback: str) -> str:
    return _JP_EFFECTS.get(card_id, {}).get("trainer_text") or fallback


def zone_label(
    zone: Zone, bench_index: int | None, bench_player: PlayerState | None = None, card_db: CardDatabase | None = None
) -> str:
    if zone == Zone.ACTIVE:
        if bench_player is not None and bench_player.active is not None and card_db is not None:
            return f"バトル({card_name(card_db, bench_player.active.card_id)})"
        return "バトル"
    if bench_index is None:
        return "ベンチ"
    if bench_player is not None and card_db is not None:
        return _bench_slot_label(bench_player, bench_index, card_db)
    return f"ベンチ{bench_index + 1}"


def _bench_slot_label(bench_player: PlayerState | None, bench_index: int, card_db: CardDatabase) -> str:
    """ベンチ番号だけでなく、実際にそこにいるポケモンの名前も添えたラベルを返す
    (「ベンチ2」だけでは盤面を見比べないとどのポケモンか分からず、プレイヤー視点で分かりにくいため。
    番号は盤面表示(_own_pokemon_target_slot_label)と揃えて1始まりにする)。"""
    label = f"ベンチ{bench_index + 1}"
    if bench_player is not None and 0 <= bench_index < len(bench_player.bench):
        label += f"({card_name(card_db, bench_player.bench[bench_index].card_id)})"
    return label


def _damage_distribution_detail(action, player: PlayerState, card_db: CardDatabase, state: GameState | None) -> str:
    """ダメカン配分の中身(どのポケモンに何個のせるか)。以前は全ての配分が「ダメカン配分を確定する
    (合計6個)」と同じ文言で並び、どれがどの配分か分からなかった(2026-09-25、ユーザー指示)。
    対象の並びはengine.legal_actions側(バトル場→ベンチ順、bench_onlyならベンチのみ)と同じ。"""
    dist = state.pending_damage_distribution if state is not None else None
    if dist is None:
        return ""
    side = state.player(dist.player_index) if dist.target_own_side else state.player(state.opponent_index(dist.player_index))
    labels: list[str] = []
    if not dist.bench_only and side.active is not None:
        labels.append(f"バトル場({card_name(card_db, side.active.card_id)})")
    for i, mon in enumerate(side.bench):
        labels.append(f"ベンチ{i + 1}({card_name(card_db, mon.card_id)})")
    parts = [f"{labels[i]}に{count}個" for i, count in enumerate(action.counts) if count > 0 and i < len(labels)]
    return ": " + "、".join(parts) if parts else ""


def describe_action(action, player: PlayerState, card_db: CardDatabase, state: GameState | None = None) -> str:
    opponent = None
    if state is not None:
        opponent = state.players[1] if player is state.players[0] else state.players[0]
    if isinstance(action, PlayBasicPokemon):
        return f"たねポケモンを出す: {card_name(card_db, player.hand[action.hand_index])}"
    if isinstance(action, Evolve):
        zone = zone_label(action.target_zone, action.target_bench_index, player, card_db)
        return f"進化させる: {card_name(card_db, player.hand[action.hand_index])} -> {zone}"
    if isinstance(action, PlayLevelUp):
        zone = zone_label(action.target_zone, action.target_bench_index, player, card_db)
        return f"Lv.Xにする: {card_name(card_db, player.hand[action.hand_index])} -> {zone}"
    if isinstance(action, AttachEnergy):
        zone = zone_label(action.target_zone, action.target_bench_index, player, card_db)
        return f"エネルギーをつける: {card_name(card_db, player.hand[action.hand_index])} -> {zone}"
    if isinstance(action, PlayPokemonTool):
        zone = zone_label(action.target_zone, action.target_bench_index, player, card_db)
        return f"どうぐをつける: {card_name(card_db, player.hand[action.hand_index])} -> {zone}"
    if isinstance(action, PlayItem):
        target = ""
        if 0 <= action.hand_index < len(player.hand) and player.hand[action.hand_index] == "sm2-130":
            mode = "トラッシュのポケモン3枚を山札に戻す" if action.target_bench_index == 0 else "トラッシュのポケモン1枚を手札に加える"
            return f"グッズを使う: {card_name(card_db, player.hand[action.hand_index])} ({mode})"
        if action.target_bench_index is not None:
            item_id = player.hand[action.hand_index] if 0 <= action.hand_index < len(player.hand) else None
            from engine.legal_actions import _ITEM_TARGETS_OPPONENT_BENCH, _ITEM_TARGETS_OWN_BENCH, _SCOOP_UP_NET_ID

            target_player = opponent if item_id in _ITEM_TARGETS_OPPONENT_BENCH else player if (item_id in _ITEM_TARGETS_OWN_BENCH or item_id == _SCOOP_UP_NET_ID) else None
            target = f" (対象: {_bench_slot_label(target_player, action.target_bench_index, card_db)})"
        return f"グッズを使う: {card_name(card_db, player.hand[action.hand_index])}{target}"
    if isinstance(action, PlaySupporter):
        target = ""
        if action.target_bench_index is not None and 0 <= action.hand_index < len(player.hand):
            # 対象を取るサポート(ボスの指令など)は、どのポケモンが対象か選択肢に出す
            # (2026-09-25、ユーザー指示。以前は全員同じ文言で、内部の値を見ないと区別できなかった)。
            from engine.legal_actions import _SUPPORTER_TARGETS_OPPONENT_BENCH

            supporter_id = player.hand[action.hand_index]
            target_player = opponent if supporter_id in _SUPPORTER_TARGETS_OPPONENT_BENCH or supporter_id == "sv9-157" else player
            target = f" (対象: {_bench_slot_label(target_player, action.target_bench_index, card_db)})"
        return f"サポートを使う: {card_name(card_db, player.hand[action.hand_index])}{target}"
    if isinstance(action, PlayStadium):
        orientation = ""
        if action.orientation_target is not None and state is not None:
            actor = next_actor(state)
            orientation = "(自分に向ける)" if action.orientation_target == actor else "(相手に向ける)"
        return f"スタジアムを出す: {card_name(card_db, player.hand[action.hand_index])}{orientation}"
    if isinstance(action, UseAbility):
        zone = zone_label(action.zone, action.bench_index, player, card_db)
        mon = player.active if action.zone == Zone.ACTIVE else player.bench[action.bench_index]
        card = card_db.get(mon.card_id)
        ability_label = ""
        kind = "特性"
        if getattr(action, "from_tool", False) and mon.attached_tool:
            tool_card = card_db.get(mon.attached_tool)
            if tool_card is not None and tool_card.abilities:
                jp_ability_name, _ = jp_ability(tool_card.id, tool_card.abilities[0])
                kind = ability_kind_label(tool_card.abilities[0].ability_type)
                return f"{kind}を使う「{jp_ability_name}」({card_name(card_db, tool_card.id)}): {card_name(card_db, mon.card_id)}({zone})"
        if card and card.abilities:
            jp_ability_name, _ = jp_ability(mon.card_id, card.abilities[0])
            ability_label = f"「{jp_ability_name}」"
            kind = ability_kind_label(card.abilities[0].ability_type)
        return f"{kind}を使う{ability_label}: {card_name(card_db, mon.card_id)}({zone})"
    if isinstance(action, Retreat):
        return f"にげる -> {_bench_slot_label(player, action.bench_index, card_db)}"
    if isinstance(action, Attack):
        card = card_db.get(player.active.card_id)
        attack = card.attacks[action.attack_index]
        jp_attack_name, _ = jp_attack(player.active.card_id, attack)
        target = ""
        if action.target_bench_index is not None:
            from effects.primitives import (
                LockChosenOpponentAttackNextTurn,
                SearchDeckForBasicEnergyAttachToTarget,
                SwitchActiveWithBench,
            )
            from effects.registry import get_attack_script

            from engine.legal_actions import _flatten_script

            script = _flatten_script(get_attack_script(player.active.card_id, attack.name))
            choice_options = next((e.status_choice_options for e in script if getattr(e, "status_choice_options", None)), None)
            if choice_options is not None:
                if 0 <= action.target_bench_index < len(choice_options):
                    target = f" -> {_status_or_type_label(choice_options[action.target_bench_index])}を選ぶ"
            elif any(getattr(e, "attack_target", None) in ("own_bench", "own_any") for e in script):
                target = f" -> 自分{_bench_slot_label(player, action.target_bench_index, card_db)}"
            elif any(getattr(e, "chooses_opponent_attack", False) for e in script):
                opponent_card = card_db.get(opponent.active.card_id) if opponent.active is not None else None
                if opponent_card is not None and 0 <= action.target_bench_index < len(opponent_card.attacks):
                    target_attack_name, _ = jp_attack(opponent.active.card_id, opponent_card.attacks[action.target_bench_index])
                    target = f" -> 相手の「{target_attack_name}」だけを使えるようにする"
            elif any(type(e).__name__ in ("DamageBonusIfStadiumDiscarded", "DiscardStadiumInPlayIfChosen") for e in script):
                target = " -> 場のスタジアムをトラッシュする"
            elif any(type(e).__name__ == "DamageBonusWithOptionalEnergyDiscard" for e in script):
                target = " -> エネルギーをトラッシュして追加ダメージ"
            elif any(type(e).__name__ == "DamageBonusWithOptionalSelfDamage" for e in script):
                target = " -> 自分にダメージを受けて追加ダメージ"
            elif any(getattr(e, "optional_variant", False) for e in script):
                target = " -> 「してもよい」効果を使う"
            elif any(isinstance(e, LockChosenOpponentAttackNextTurn) for e in script):
                # ラルトスの「Memory Skip」/ロケット団のヤミカラスの「Torment」等: target_bench_indexは
                # ベンチ位置ではなく「相手のバトルポケモンのワザ一覧の何番目か」の流用。以前は汎用の
                # ベンチ枠ラベルをそのまま使っており、相手にベンチポケモンが1匹もいなくても
                # 「ベンチ1」等と表示されていた(2026-08-21発覚)。
                opponent_card = card_db.get(opponent.active.card_id) if opponent.active is not None else None
                if opponent_card is not None and 0 <= action.target_bench_index < len(opponent_card.attacks):
                    target_attack_name, _ = jp_attack(opponent.active.card_id, opponent_card.attacks[action.target_bench_index])
                    target = f" -> 相手の「{target_attack_name}」を封じる"
            elif any(
                isinstance(e, SearchDeckForBasicEnergyAttachToTarget) and not e.self_only for e in script
            ) or any(isinstance(e, SwitchActiveWithBench) for e in script):
                # ムチュールの「Delightful Kiss」/ケーシィの「Teleportation Attack」等: target_bench_index
                # は相手ではなく自分のベンチ位置(山札から選んだエネルギーをつける先、または自分と
                # 入れ替えるベンチポケモン)を指す。以前は汎用の「相手」ラベルをそのまま使っており、
                # 自分のベンチを選ぶだけなのに「→ 相手ベンチN」と表示されて紛らわしかった
                # (2026-08-25ユーザー報告、2026-09-23にSwitchActiveWithBench系の攻撃でも同種の
                # 表示バグが発覚――「Teleportation Attack」のような「自分のベンチと入れ替える」
                # ワザ(実カードテキスト: "Switch this Pokémon with 1 of your Benched Pokémon.")
                # を含む、この効果を使う全カード共通のバグだった)。
                target = f" -> 自分{_bench_slot_label(player, action.target_bench_index, card_db)}"
            else:
                target = f" -> 相手{_bench_slot_label(opponent, action.target_bench_index, card_db)}"
        return f"ワザ: {jp_attack_name} ({attack.damage or '0'}ダメージ){target}"
    if isinstance(action, ChooseNewActive):
        return f"新しいバトルポケモン: {_bench_slot_label(player, action.bench_index, card_db)}"
    if isinstance(action, EndTurn):
        return "ターン終了"
    if isinstance(action, ChooseInitialActive):
        return f"バトルポケモンにする: {card_name(card_db, player.hand[action.hand_index])}"
    if isinstance(action, ConfirmSetupDone):
        return "準備完了"
    if isinstance(action, ChooseMulliganBonusDrawCount):
        return (
            f"マリガンのボーナスドローを{action.count}枚引く"
            if action.count > 0
            else "マリガンのボーナスドローを引かない"
        )
    if isinstance(action, ResolveSearchChoice):
        if not action.selected_indices:
            return "検索: 何も選ばない"
        if state is not None and state.pending_search_choice is not None:
            choice = state.pending_search_choice
            if choice.zone == "revealed_card_attack_choice":
                # ヤドキングの「ひらめきチャレンジ」等: card_idsは選ばれたポケモン1体を技の数ぶん
                # 繰り返しただけの配列(選択肢そのものは技の何番目かで区別される)なので、
                # card_nameだけを表示すると同じポケモン名が並ぶだけになり、どちらが「ゆびをふる」で
                # どちらが「みずでっぽう」なのか区別が付かなかった(2026-08-25ユーザー報告
                # 「技が二個あるぽけもんにおいてどちらの技を使うか選べるようにしてください」で発覚。
                # 選択自体はできていたが、ラベルが同じに見えるため選べないように感じられていた)。
                revealed_card_id = (choice.custom_data or {}).get("revealed_card_id") if isinstance(choice.custom_data, dict) else None
                source_card = card_db.get(revealed_card_id) if revealed_card_id else None
                if source_card is not None:
                    attack_names = []
                    options = (choice.custom_data or {}).get("options") if isinstance(choice.custom_data, dict) else None
                    for i in action.selected_indices:
                        variant = False
                        if options is not None and 0 <= i < len(options):
                            i, variant = options[i]
                        if 0 <= i < len(source_card.attacks):
                            name, _ = jp_attack(revealed_card_id, source_card.attacks[i])
                            attack_names.append(name + ("(追加ダメージを選ぶ)" if variant else ""))
                    if attack_names:
                        return f"検索: {card_name(card_db, revealed_card_id)}の「{'、'.join(attack_names)}」を選ぶ"
            if choice.zone == "own_prizes_take":
                # サイドは実物を取るまで裏向きのままの私的情報(実カードルール通り、本人も含めて
                # 中身を見ずに取る)なので、ここでも位置(サイド1, サイド2, ...)だけを表示し、
                # 実際の中身(card_name)は絶対に見せない(2026-08-26、ユーザー報告「AIがサイドを
                # 取るときにサイドが見えている可能性があります」で発覚。choice-overlay用の
                # _search_choice_overlay_optionsは既に位置だけを見せていたが、この関数(ログ/
                # CLI/AI行動ラベル用)は別経路のため中身が漏れていた)。
                labels = [f"サイド{i + 1}" for i in action.selected_indices]
                return f"サイドを取る: {'、'.join(labels)}"
            candidates = choice.card_ids
            names = [
                card_name(card_db, candidates[i]) for i in action.selected_indices if 0 <= i < len(candidates)
            ]
            if names:
                return f"検索: {'、'.join(names)} を選ぶ"
        return f"検索: {len(action.selected_indices)}枚選ぶ"
    if isinstance(action, (DeclineTrigger, AcceptTrigger)):
        # override_kind/override_label(メタグロスの「Metallic Hammer」等、ワザ後の「してもよい」
        # 効果)が設定されていれば、汎用の「特性」表記ではなくそちらを使う。以前はここで
        # ability_kind_label_for_card(常に「特性」またはカード自身の特性名にフォールバックする)
        # しか見ておらず、ワザ由来の選択(「メタリックハンマーを使う/使わない」等)でも
        # 「特性を使う/使わない」という無関係な表記になっていた(engine.rules_engine側の
        # ログメッセージ生成(_trigger_ability_kind/_trigger_ability_label)は元々override優先
        # だったのに、この行動選択肢のラベル側だけ揃っていなかった、2026-09-02発覚)。
        kind = "特性"
        label = ""
        if state is not None and state.pending_trigger is not None:
            trig = state.pending_trigger
            kind = trig.override_kind or ability_kind_label_for_card(card_db, trig.source_card_id)
            label = trig.override_label
        suffix = f"「{label}」" if label else ""
        if isinstance(action, DeclineTrigger):
            return f"{kind}{suffix}を使わない"
        if action.target_bench_index is None:
            return f"{kind}{suffix}を使う"
        if state is not None and state.pending_trigger is not None and state.pending_trigger.target_kind == "own_bench":
            return f"{kind}{suffix}を使う -> 自分{_bench_slot_label(player, action.target_bench_index, card_db)}"
        return f"{kind}{suffix}を使う -> 相手{_bench_slot_label(opponent, action.target_bench_index, card_db)}"
    if isinstance(action, UseStadiumAbility):
        name = card_name(card_db, state.stadium_in_play) if state is not None and state.stadium_in_play else "スタジアム"
        return f"スタジアムの効果を使う: {name}"
    if isinstance(action, UseDiscardAbility):
        if action.from_hand:
            return f"手札の特性を使う: {card_name(card_db, player.hand[action.discard_index])}(公開して効果を行い、トラッシュする)"
        card_id = player.discard[action.discard_index]
        return f"トラッシュの特性を使う: {card_name(card_db, card_id)}(ベンチに出す)"
    if isinstance(action, UseBorrowedAttack):
        source_card = card_db.get(action.source_card_id)
        attack = next((a for a in source_card.attacks if a.name == action.attack_name), None) if source_card else None
        jp_attack_name = jp_attack(action.source_card_id, attack)[0] if attack else action.attack_name
        target = f" -> 相手{_bench_slot_label(opponent, action.target_bench_index, card_db)}" if action.target_bench_index is not None else ""
        if action.target_bench_index is not None:
            from effects.primitives import has_optional_variant
            from effects.registry import get_attack_script

            if has_optional_variant(get_attack_script(action.source_card_id, action.attack_name)):
                target = " -> 追加ダメージを選ぶ(エネルギーのトラッシュ/自分へのダメージ)"
        return f"ワザを借りて使う({card_name(card_db, action.source_card_id)}): {jp_attack_name}{target}"
    if isinstance(action, ResolveDamageDistribution):
        return f"ダメカン配分を確定する(合計{sum(action.counts)}個){_damage_distribution_detail(action, player, card_db, state)}"
    if isinstance(action, UsePowerSpray):
        name = ""
        if state is not None and state.pending_power_spray_window is not None:
            name = card_name(card_db, state.pending_power_spray_window.source_card_id)
        return f"パワースプレーを使って{name}の特性を防ぐ" if name else "パワースプレーを使う"
    if isinstance(action, PassPowerSprayWindow):
        return "パワースプレーを使わない"
    return str(action)


def action_origin(action, player: PlayerState) -> dict:
    """このアクションを始めるためにクリックすべき盤面要素。"""
    if isinstance(
        action,
        (PlayBasicPokemon, Evolve, PlayLevelUp, AttachEnergy, PlayPokemonTool, PlayItem, PlaySupporter, PlayStadium, ChooseInitialActive),
    ):
        return {"kind": "hand", "index": action.hand_index}
    if isinstance(action, ConfirmSetupDone):
        return {"kind": "turn"}
    if isinstance(action, (Attack, Retreat)):
        return {"kind": "own_active"}
    if isinstance(action, UseAbility):
        return {"kind": "own_active"} if action.zone == Zone.ACTIVE else {"kind": "own_bench", "index": action.bench_index}
    if isinstance(action, ChooseNewActive):
        return {"kind": "own_bench", "index": action.bench_index}
    if isinstance(action, ResolveSearchChoice):
        return {"kind": "search_choice"}
    if isinstance(action, (AcceptTrigger, DeclineTrigger)):
        return {"kind": "trigger"}
    if isinstance(action, UseStadiumAbility):
        return {"kind": "stadium"}
    if isinstance(action, UseDiscardAbility):
        if action.from_hand:
            return {"kind": "hand", "index": action.discard_index}
        return {"kind": "own_discard", "index": action.discard_index}
    if isinstance(action, UseBorrowedAttack):
        return {"kind": "own_active"}
    if isinstance(action, ResolveDamageDistribution):
        return {"kind": "damage_distribution"}
    if isinstance(action, (UsePowerSpray, PassPowerSprayWindow)):
        return {"kind": "power_spray"}
    return {"kind": "turn"}


STATUS_LABELS = {
    "ASLEEP": "ねむり",
    "PARALYZED": "まひ",
    "CONFUSED": "こんらん",
}


def serialize_pokemon(card_db: CardDatabase, mon: PokemonInPlay, stadium_in_play: str | None = None) -> dict:
    card = card_db.get(mon.card_id)
    max_hp = effective_max_hp(card_db, mon.card_id, mon.attached_tool, stadium_in_play, mon.attached_energy)
    statuses = []
    if mon.status.poisoned:
        statuses.append("どく")
    if mon.status.burned:
        statuses.append("やけど")
    if mon.status.exclusive.name != "NONE":
        statuses.append(STATUS_LABELS.get(mon.status.exclusive.name, mon.status.exclusive.name))
    return {
        "card_id": mon.card_id,
        "name": card_name(card_db, mon.card_id),
        "image": card.image_small if card else "",
        "hp": mon.remaining_hp(max_hp) if max_hp else None,
        "max_hp": max_hp,
        "energy": [
            {
                "card_id": e,
                "name": card_name(card_db, e),
                "type": (card_db.get(e).basic_energy_type if card_db.get(e) else None),
                "symbol": energy_card_symbol(card_db, e),
            }
            for e in mon.attached_energy
        ],
        "tool": (
            {"card_id": mon.attached_tool, "name": card_name(card_db, mon.attached_tool)}
            if mon.attached_tool
            else None
        ),
        "statuses": statuses,
    }


def _card_stub(card_db: CardDatabase, card_id: str) -> dict:
    card = card_db.get(card_id)
    return {"card_id": card_id, "name": card_name(card_db, card_id), "image": card.image_small if card else ""}


def _own_pokemon_target_slot_label(slot: int) -> str:
    return "バトル場" if slot == 0 else f"ベンチ{slot}"


def _opponent_pokemon_target_slot_label(state: GameState, choice, slot: int) -> str:
    """相手の場のポケモンを複数選ぶ場面(キュレムの「Trifrost」等)のスロットラベル。
    同じcard_id(同名ポケモン)が複数いる場合、位置とダメカン(ダメージを受けているか)が
    見分けられないと選べなくなるため、位置ラベルにダメージ情報も添える。"""
    opponent = state.player(state.opponent_index(choice.player_index))
    mon = opponent.active if slot == 0 else (opponent.bench[slot - 1] if 0 <= slot - 1 < len(opponent.bench) else None)
    label = "バトル場" if slot == 0 else f"ベンチ{slot}"
    if mon is not None:
        label += f"(ダメージ{mon.damage}点)" if mon.damage > 0 else "(ダメージなし)"
    return label


def _field_attachment_slot_label(entry: tuple, viewer_side: int) -> str:
    if entry[0] == "stadium":
        return "スタジアム"
    side = entry[1]
    slot = entry[2]
    side_label = "自分の" if side == viewer_side else "相手の"
    pos_label = "バトル場" if slot == "active" else f"ベンチ{slot + 1}"
    kind_label = "どうぐ" if entry[0] == "tool" else "エネルギー"
    return f"{side_label}{pos_label}の{kind_label}"


def _search_choice_candidate_stubs(
    state: GameState, card_db: CardDatabase, choice, card_ids: list[str], viewer_side: int
) -> list[dict]:
    """own_pokemon_target/field_attachment/opponent_pokemon_targetは同じカードIDの盤面ポケモンが
    複数存在しうるため、どの位置を指しているかを見分けられるようslot_labelを付ける(検索choice-overlayが
    card_idだけでグルーピングしてしまうと、同名ポケモンが2体いる場合に選べなくなる)。"""
    if choice.zone == "own_prizes_take":
        # 自分の残りサイドからどれを取るか選ぶ場面: 実物のサイドは取るまで裏向きのままなので、
        # カード名/絵柄は伏せて位置(サイド1, サイド2, ...)だけで選ばせる。
        # (タウンマップで表向きにした/Eye Openerで見たサイドは中身が分かっているので、そのカードを見せる)
        owner = state.player(choice.player_index)
        stubs_for_prizes = []
        for pos, cid in enumerate(card_ids):
            slot = choice.source_indices[pos] if pos < len(choice.source_indices) else pos
            if owner.prize_mark(slot) >= 1:
                stub = _card_stub(card_db, cid)
                stub["slot_label"] = f"サイド{slot + 1}"
                stubs_for_prizes.append(stub)
            else:
                stubs_for_prizes.append({"card_id": None, "name": "", "image": "", "hidden": True, "slot_label": f"サイド{slot + 1}"})
        return stubs_for_prizes
    stubs = [_card_stub(card_db, cid) for cid in card_ids]
    if choice.zone == "own_pokemon_target" and len(choice.source_indices) == len(stubs):
        for stub, slot in zip(stubs, choice.source_indices):
            stub["slot_label"] = _own_pokemon_target_slot_label(slot)
    elif choice.zone == "field_attachment" and len(choice.source_indices) == len(stubs):
        for stub, entry in zip(stubs, choice.source_indices):
            stub["slot_label"] = _field_attachment_slot_label(entry, viewer_side)
    elif choice.zone == "opponent_pokemon_target" and len(choice.source_indices) == len(stubs):
        for stub, slot in zip(stubs, choice.source_indices):
            stub["slot_label"] = _opponent_pokemon_target_slot_label(state, choice, slot)
    return stubs


def serialize_player(
    card_db: CardDatabase,
    player: PlayerState,
    is_viewer: bool,
    hide_active_bench: bool = False,
    stadium_in_play: str | None = None,
) -> dict:
    return {
        "active": (
            {"hidden": True}
            if hide_active_bench and player.active
            else (serialize_pokemon(card_db, player.active, stadium_in_play) if player.active else None)
        ),
        "bench": (
            [{"hidden": True} for _ in player.bench]
            if hide_active_bench
            else [serialize_pokemon(card_db, mon, stadium_in_play) for mon in player.bench]
        ),
        "hand": ([_card_stub(card_db, c) for c in player.hand] if is_viewer else None),
        "hand_count": len(player.hand),
        "deck_count": len(player.deck),
        "discard_count": len(player.discard),
        "discard": [_card_stub(card_db, c) for c in player.discard],  # トラッシュは公開情報
        "lost_zone_count": len(player.lost_zone),
        "lost_zone": [_card_stub(card_db, c) for c in player.lost_zone],  # ロストゾーンもトラッシュと同様に公開情報
        "prizes_remaining": len(player.prizes),
        # 中身が分かっているサイド(タウンマップ=両者に公開 / Eye Opener=本人のみ)。裏向きのスロットは
        # card=Noneのまま。誰にも公開されていないサイドがある限り、位置(順番)だけを持つ。
        "prize_cards": [
            (
                _card_stub(card_db, player.prizes[i])
                if (player.prize_mark(i) == 2 or (player.prize_mark(i) == 1 and is_viewer))
                else None
            )
            for i in range(len(player.prizes))
        ]
        if any(player.prize_mark(i) > 0 for i in range(len(player.prizes)))
        else None,
    }


def _serialize_pending_trigger(state: GameState, card_db: CardDatabase) -> dict:
    trig = state.pending_trigger
    card = card_db.get(trig.source_card_id)
    ability_name = ""
    kind = "特性"
    if card and card.abilities:
        ability_name, _ = jp_ability(trig.source_card_id, card.abilities[0])
        kind = ability_kind_label(card.abilities[0].ability_type)
    return {
        "player_index": trig.player_index,
        "source_card_id": trig.source_card_id,
        "source_name": card_name(card_db, trig.source_card_id),
        "ability_name": ability_name,
        "prompt": f"{card_name(card_db, trig.source_card_id)}の{kind}「{ability_name}」を使いますか？",
        "needs_target": trig.needs_target,
    }


def _serialize_pending_power_spray_window(state: GameState, card_db: CardDatabase) -> dict:
    window = state.pending_power_spray_window
    ability_name = ""
    card = card_db.get(window.source_card_id)
    if card and card.abilities:
        ability_name, _ = jp_ability(window.source_card_id, card.abilities[0])
    return {
        "actor": window.actor,
        "opponent_index": window.opponent_index,
        "source_card_id": window.source_card_id,
        "source_name": card_name(card_db, window.source_card_id),
        "ability_name": ability_name,
        "prompt": f"相手の{card_name(card_db, window.source_card_id)}が特性「{ability_name}」を使いました。"
        "パワースプレーで防ぎますか？",
    }


_ENERGY_SYMBOLS = {
    "Fire": "🔥",
    "Water": "💧",
    "Grass": "🌿",
    "Lightning": "⚡",
    "Psychic": "🔮",
    "Fighting": "👊",
    "Darkness": "🌑",
    "Metal": "⚙",
    "Fairy": "✨",
    "Dragon": "🐉",
    "Colorless": "⚪",
    WILDCARD_TOKEN: "🌈",  # フュージョンエネルギー/レインボーエネルギー/ビーストエネルギー等: どのタイプにも使える
    RAPID_STRIKE_TOKEN: "🌀",  # れんげきエネルギー: 無色2つぶんだが闘/水どちらのコストにも使える
}


def energy_symbol(energy_type: str | None) -> str:
    return _ENERGY_SYMBOLS.get(energy_type or "Colorless", "⚪")


def energy_card_symbol(card_db: CardDatabase, card_id: str) -> str:
    """このエネルギーカードが実際に提供するタイプの記号(特殊エネルギーは複数タイプぶん連結する)。"""
    tokens = energy_tokens(card_db, card_id)
    return "".join(energy_symbol(t) for t in tokens) or "⚪"


def _serialize_attack_options(state: GameState, card_db: CardDatabase) -> list[dict]:
    """自分の番に使えるワザを、コスト・ダメージつきで一覧化する(PTCGLのワザ表示相当)。

    ミュウツー&ミュウGXの「パーフェクション」等で借りて使うワザも、通常のワザと同じ
    パネルに(借用元を明記して)一覧表示する。
    """
    actor = next_actor(state)
    player = state.player(actor)
    if player.active is None:
        return []
    legal = legal_actions(state, card_db)
    options = []

    card = card_db.get(player.active.card_id)
    if card is not None:
        for i, attack in enumerate(card.attacks):
            action_indices = [idx for idx, a in enumerate(legal) if isinstance(a, Attack) and a.attack_index == i]
            if not action_indices:
                continue
            jp_name, _ = jp_attack(player.active.card_id, attack)
            options.append(
                {
                    "attack_index": i,
                    "name": jp_name,
                    "cost": list(attack.cost),
                    "cost_symbols": [energy_symbol(c) for c in attack.cost],
                    "damage": attack.damage,
                    "action_indices": action_indices,
                    "borrowed_from": None,
                }
            )

    borrowed_order: list[tuple[str, str, str]] = []
    borrowed_indices: dict[tuple[str, str, str], list[int]] = {}
    for idx, a in enumerate(legal):
        if not isinstance(a, UseBorrowedAttack):
            continue
        key = (a.source_zone, a.source_card_id, a.attack_name)
        if key not in borrowed_indices:
            borrowed_indices[key] = []
            borrowed_order.append(key)
        borrowed_indices[key].append(idx)
    for source_zone, source_card_id, attack_name in borrowed_order:
        source_card = card_db.get(source_card_id)
        attack = next((a for a in source_card.attacks if a.name == attack_name), None) if source_card else None
        if attack is None:
            continue
        jp_name, _ = jp_attack(source_card_id, attack)
        options.append(
            {
                "attack_index": None,
                "name": jp_name,
                "cost": list(attack.cost),
                "cost_symbols": [energy_symbol(c) for c in attack.cost],
                "damage": attack.damage,
                "action_indices": borrowed_indices[(source_zone, source_card_id, attack_name)],
                "borrowed_from": card_name(card_db, source_card_id),
            }
        )
    return options


def _serialize_pending_damage_distribution(state: GameState, card_db: CardDatabase) -> dict:
    dist = state.pending_damage_distribution
    opponent = state.player(state.opponent_index(dist.player_index))
    targets: list[tuple[str, int | None, PokemonInPlay]] = []
    if not dist.bench_only and opponent.active is not None:
        targets.append(("active", None, opponent.active))
    for i, mon in enumerate(opponent.bench):
        targets.append(("bench", i, mon))
    return {
        "player_index": dist.player_index,
        "total_counters": dist.total_counters,
        "bench_only": dist.bench_only,
        "max_per_target": dist.max_per_target,
        "source_card_id": dist.source_card_id,
        "source_name": card_name(card_db, dist.source_card_id),
        "targets": [
            {"kind": kind, "index": idx, **serialize_pokemon(card_db, mon, state.stadium_in_play)}
            for kind, idx, mon in targets
        ],
    }


def serialize_state(state: GameState, card_db: CardDatabase) -> dict:
    actor = next_actor(state)
    return {
        "turn_number": state.turn_number,
        "current_player": state.current_player,
        "actor": actor,
        "in_setup": not state.setup_complete,
        "awaiting_active_choice": bool(state.pending_active_choice),
        "pending_search_choice": (
            {
                "player_index": state.pending_search_choice.player_index,
                "zone": state.pending_search_choice.zone,
                "prompt": state.pending_search_choice.prompt,
                "min_count": state.pending_search_choice.min_count,
                "max_count": state.pending_search_choice.max_count,
                "destination": state.pending_search_choice.destination,
                "candidates": _search_choice_candidate_stubs(
                    state, card_db, state.pending_search_choice, state.pending_search_choice.card_ids,
                    state.pending_search_choice.player_index,
                ),
                "all_candidates": _search_choice_candidate_stubs(
                    state, card_db, state.pending_search_choice, state.pending_search_choice.all_card_ids,
                    state.pending_search_choice.player_index,
                ),
            }
            if state.pending_search_choice is not None
            else None
        ),
        "pending_trigger": (_serialize_pending_trigger(state, card_db) if state.pending_trigger is not None else None),
        "pending_power_spray_window": (
            _serialize_pending_power_spray_window(state, card_db)
            if state.pending_power_spray_window is not None
            else None
        ),
        "pending_damage_distribution": (
            _serialize_pending_damage_distribution(state, card_db)
            if state.pending_damage_distribution is not None
            else None
        ),
        "attack_options": _serialize_attack_options(state, card_db),
        "winner": state.winner,
        "stadium": (
            {
                "card_id": state.stadium_in_play,
                "name": card_name(card_db, state.stadium_in_play),
                "image": (card_db.get(state.stadium_in_play).image_small if card_db.get(state.stadium_in_play) else ""),
                "owner": ("self" if state.stadium_owner == actor else "opponent") if state.stadium_owner is not None else None,
            }
            if state.stadium_in_play
            else None
        ),
        "players": [
            serialize_player(
                card_db,
                state.players[i],
                is_viewer=(i == actor),
                # 対戦準備中(お互いバトル/ベンチポケモンを裏向きに置く段階)は、まだ準備を終えていない
                # 相手側の場を見せない。上級プレイヤー用ルールガイドの通り、両者が置き終えたら
                # バトルスタートで同時に表向きにする(setup_complete化のタイミングで自然に解除される)。
                hide_active_bench=(not state.setup_complete and i != actor),
                stadium_in_play=state.stadium_in_play,
            )
            for i in range(2)
        ],
        "log_tail": state.log,  # 表示上限を撤廃し、対戦開始からの全ログを返す(以前は直近40件までしか
        # 見られず、対局が長引くと序盤の履歴を確認できなかった)。
        "last_reveal": (
            {
                "title": state.last_reveal["title"],
                "cards": [_card_stub(card_db, cid) for cid in state.last_reveal["card_ids"]],
                "seq": state.last_reveal_seq,  # ログ行数(増え続ける)ではなくこの通し番号でWeb UI側の
                # 既読判定をさせる(以前はログ行数を使っており、対局が続くほど古い通知が
                # ポーリングのたびに再表示され続けるバグだった)。
            }
            if state.last_reveal is not None
            else None
        ),
    }


def serialize_card_detail(card_db: CardDatabase, card_id: str) -> dict | None:
    """右クリック等でのカード拡大表示用に、カードの全情報を返す。"""
    card = card_db.get(card_id)
    if card is None:
        return None
    return {
        "card_id": card.id,
        "name": card_name(card_db, card_id),
        "image": card.image_large or card.image_small,
        "supertype": card.supertype,
        "subtypes": list(card.subtypes),
        "hp": card.hp,
        "types": list(card.types),
        "attacks": [
            {
                "name": jp_attack(card_id, a)[0],
                "cost": list(a.cost),
                "cost_symbols": [energy_symbol(c) for c in a.cost],
                "damage": a.damage,
                "text": jp_attack(card_id, a)[1],
            }
            for a in card.attacks
        ],
        "abilities": [
            {"name": jp_ability(card_id, a)[0], "type": a.ability_type, "text": jp_ability(card_id, a)[1]}
            for a in card.abilities
        ],
        "weaknesses": [{"type": w.type, "value": w.value} for w in card.weaknesses],
        "resistances": [{"type": r.type, "value": r.value} for r in card.resistances],
        "retreat_cost": card.retreat_cost_count,
        "trainer_text": jp_trainer_text(card_id, card.trainer_text),
        "rules": list(card.rules),
    }


def serialize_actions(state: GameState, card_db: CardDatabase) -> list[dict]:
    actor = next_actor(state)
    player = state.player(actor)
    actions: list[Action] = legal_actions(state, card_db)
    return [
        {
            "index": i,
            "description": describe_action(a, player, card_db, state),
            "origin": action_origin(a, player),
            "type": type(a).__name__,  # Web UI側で「ワザ/特性/にげる」等、確認ダイアログを出すべき
            # 行動かどうかを判定するために使う(候補が1つだけでも即実行せず確認させたい操作向け)。
            # ダメカン自由配分(専用UIで組み立てるため通常のボタン一覧には出ないが、フロント側で
            # 「今組んでいる配分」や「AI推奨の配分」をai_scoreと突き合わせられるよう、実際の
            # 配分内訳もここで一緒に返す)。
            "counts": list(a.counts) if isinstance(a, ResolveDamageDistribution) else None,
        }
        for i, a in enumerate(actions)
    ]
