"""ダメージ計算: 基本ダメージ → 弱点 → 抵抗力 の順(公式ルール準拠)。

弱点/抵抗力の表記は時代によって異なる:
- 現行(概ね2011年以降): 弱点は「×2」の倍率表記、抵抗力は「-30」の固定値表記
- 旧時代(プラチナ/ダイヤモンド&パール期など): 弱点も「+10」のような加算表記だった

カードごとの実際の `value` 文字列を見て判定するため、どちらの時代のカードでも正しく計算できる。
"""

from __future__ import annotations

from cards.models import Card


def _apply_modifier(damage: int, value: str) -> int:
    value = value.strip()
    if value.startswith(("×", "x", "X")):
        return damage * int(value[1:])
    # "+10" や "-30" のような加算/減算表記。int()は符号付き文字列をそのまま解釈できる。
    return damage + int(value)


def calculate_damage(
    base_damage: int, attacker_types: tuple[str, ...], defender_card: Card, apply_weakness: bool = True
) -> int:
    if base_damage <= 0:
        return 0

    damage = base_damage

    if apply_weakness:
        for weakness in defender_card.weaknesses:
            if weakness.type in attacker_types:
                damage = _apply_modifier(damage, weakness.value)
                break

    for resistance in defender_card.resistances:
        if resistance.type in attacker_types:
            damage = _apply_modifier(damage, resistance.value)
            break

    return max(0, damage)
