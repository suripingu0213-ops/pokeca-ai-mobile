"""プロジェクト全体の設定値。"""

import os
from pathlib import Path

PROJECT_ROOT = Path(__file__).resolve().parent.parent
DATA_DIR = PROJECT_ROOT / "data"
CACHE_DIR = DATA_DIR / "cache"
REPLAY_DIR = DATA_DIR / "replays"
CHECKPOINT_DIR = DATA_DIR / "checkpoints"
HUMAN_GAMES_DIR = DATA_DIR / "human_games"  # Web UIで人間が対局した際の各手の記録(模倣学習の教師データ)
BUG_REPORTS_DIR = DATA_DIR / "bug_reports"  # Web UIの「バグ報告」で保存された対局(盤面ログ+最終状態)

CARDS_CACHE_FILE = CACHE_DIR / "cards.json"
CURATED_POOL_FILE = PROJECT_ROOT / "cards" / "curated_pool.json"

POKEMONTCG_API_BASE = "https://api.pokemontcg.io/v2"
# 未設定でも動くが、レート制限を上げたい場合は環境変数で指定する
POKEMONTCG_API_KEY = os.environ.get("POKEMONTCG_API_KEY")

for _dir in (DATA_DIR, CACHE_DIR, REPLAY_DIR, CHECKPOINT_DIR, HUMAN_GAMES_DIR, BUG_REPORTS_DIR):
    _dir.mkdir(parents=True, exist_ok=True)
