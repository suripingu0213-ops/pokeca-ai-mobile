"""スマホ版用: デッキ別AI(実績の勝率AI)の定義だけ。実績データ(20GB超のSQLite)はスマホに載せないので、実際には使えない。

DECK_AISはweb/app.pyが読み込み時に専用枠の定義で参照する(deck_fileのキー)ためだけに残し、
pwa_server.pyが読み込み後にclear()して「選べるAIが無い」状態にする。
"""

from __future__ import annotations

from pathlib import Path

DECK_AIS: dict[str, dict[str, str]] = {
    "osaka_alakazam": {"label": "フーディンAI", "deck_file": "cl2026osaka_alakazam_dudunsparce_akagi.yaml"},
    "aichi_dragapult": {"label": "ドラパAI", "deck_file": "cl2026aichimay_dragapult_dusknoir_shiokawa.yaml"},
}


def ai_key_for_deck(deck_path):
    return None


def store_path(ai_key: str) -> Path:
    return Path("/nonexistent") / f"{ai_key}.db"
