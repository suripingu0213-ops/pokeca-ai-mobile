"""スマホ版(Pyodide)用の方策エージェント: agents/policy_agent.py と同じ振る舞い(推論だけ。学習用の確率・エントロピーは持たない)。"""

from __future__ import annotations

import random

import numpy as np

from agents.network import PolicyValueNetwork
from cards.card_db import CardDatabase
from engine.actions import Action
from engine.state import GameState
from rl_env.encoding import CardVocab, encode_action, encode_state


class PolicyAgent:
    def __init__(
        self,
        network: PolicyValueNetwork,
        vocab: CardVocab,
        actor_index: int,
        greedy: bool = False,
        frozen: bool = False,
        epsilon: float = 0.0,
    ) -> None:
        self.network = network
        self.vocab = vocab
        self.actor_index = actor_index
        self.greedy = greedy
        self.frozen = frozen
        self.epsilon = epsilon
        self.last_value = None
        self.last_was_exploratory = False
        self.last_scores = None
        self.hidden_state = None  # 一局を通した記憶(GRU隠れ状態)。呼び出し側(web/app.py)が持ち回る

    def reset_memory(self) -> None:
        self.hidden_state = None

    def observe(self, state: GameState, card_db: CardDatabase) -> None:
        state_features = encode_state(state, card_db, self.vocab, self.actor_index)
        self.hidden_state = self.network.observe(state_features, self.hidden_state)

    def choose_action(self, state: GameState, card_db: CardDatabase, actions: list[Action]) -> Action:
        state_features = encode_state(state, card_db, self.vocab, self.actor_index)
        player = state.player(self.actor_index)
        action_features = [encode_action(a, player, card_db, self.vocab, state) for a in actions]
        scores, value, new_hidden = self.network(state_features, action_features, self.hidden_state)
        self.hidden_state = new_hidden
        self.last_value = value
        self.last_scores = scores
        self.last_was_exploratory = False
        if len(actions) == 1:
            return actions[0]
        if self.greedy:
            choice = int(np.argmax(scores))
        elif self.epsilon > 0.0 and random.random() < self.epsilon:
            choice = random.randrange(len(actions))
            self.last_was_exploratory = True
        else:
            probs = np.exp(scores - scores.max())
            probs /= probs.sum()
            choice = int(np.random.default_rng().choice(len(actions), p=probs))
        return actions[choice]
