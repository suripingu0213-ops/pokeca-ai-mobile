"""スマホ版(Pyodide)用の方策/価値ネットワーク: agents/network.py(PyTorch)と同じ計算をnumpyだけで行う。

重みの名前・形状はPyTorch版のstate_dictと同じ。PC上で本物のtorch版と照合済み
(pwa/tests/test_numpy_network.py: 評価値の差は1e-4以下)。学習はしない(推論専用)。
"""

from __future__ import annotations

import math

import numpy as np

from rl_env.encoding import ACTION_FEATURE_DIM, GLOBAL_FEATURE_DIM, POKEMON_SLOT_FEATURE_DIM

_COUNT_MLPS = (
    "hand_mlp",
    "own_discard_mlp",
    "opp_discard_mlp",
    "own_lost_zone_mlp",
    "opp_lost_zone_mlp",
    "known_opponent_hand_mlp",
    "own_deck_prize_mlp",
)


def _sigmoid(x):
    return 1.0 / (1.0 + np.exp(-x))


def _layer_norm(x, weight, bias, eps=1e-5):
    mean = x.mean(-1, keepdims=True)
    var = ((x - mean) ** 2).mean(-1, keepdims=True)
    return (x - mean) / np.sqrt(var + eps) * weight + bias


class PolicyValueNetwork:
    def __init__(self, vocab_size: int, embed_dim: int = 32, hidden: int = 128, state_dim: int = 128) -> None:
        self.vocab_size = vocab_size
        self.embed_dim = embed_dim
        self.hidden = hidden
        self.state_dim = state_dim
        self._score_scale = math.sqrt(state_dim)
        self.w = self._initial_weights()

    # ---- 重み -------------------------------------------------------------------------
    def _shapes(self) -> dict[str, tuple[int, ...]]:
        v, e, h, s = self.vocab_size, self.embed_dim, self.hidden, self.state_dim
        shapes: dict[str, tuple[int, ...]] = {"card_embedding.embedding.weight": (v + 1, e)}
        shapes["state_encoder.slot_mlp.0.weight"] = (h, e * 4 + POKEMON_SLOT_FEATURE_DIM)
        shapes["state_encoder.slot_mlp.0.bias"] = (h,)
        for name in _COUNT_MLPS:
            shapes[f"state_encoder.{name}.0.weight"] = (h, v)
            shapes[f"state_encoder.{name}.0.bias"] = (h,)
        shapes["state_encoder.global_mlp.0.weight"] = (h, GLOBAL_FEATURE_DIM)
        shapes["state_encoder.global_mlp.0.bias"] = (h,)
        fusion_in = h * 9 + e * 4 + h
        shapes["state_encoder.fusion.0.weight"] = (s, fusion_in)
        shapes["state_encoder.fusion.0.bias"] = (s,)
        shapes["state_encoder.fusion.2.weight"] = (s, s)
        shapes["state_encoder.fusion.2.bias"] = (s,)
        shapes["state_encoder.fusion.3.weight"] = (s,)
        shapes["state_encoder.fusion.3.bias"] = (s,)
        shapes["action_encoder.mlp.0.weight"] = (h, ACTION_FEATURE_DIM + e)
        shapes["action_encoder.mlp.0.bias"] = (h,)
        shapes["action_encoder.mlp.2.weight"] = (s, h)
        shapes["action_encoder.mlp.2.bias"] = (s,)
        shapes["action_encoder.mlp.3.weight"] = (s,)
        shapes["action_encoder.mlp.3.bias"] = (s,)
        shapes["memory_cell.weight_ih"] = (3 * s, s)
        shapes["memory_cell.weight_hh"] = (3 * s, s)
        shapes["memory_cell.bias_ih"] = (3 * s,)
        shapes["memory_cell.bias_hh"] = (3 * s,)
        shapes["memory_gate.weight"] = (s, s)
        shapes["memory_gate.bias"] = (s,)
        shapes["value_head.0.weight"] = (h, s)
        shapes["value_head.0.bias"] = (h,)
        shapes["value_head.2.weight"] = (1, h)
        shapes["value_head.2.bias"] = (1,)
        return shapes

    def _initial_weights(self) -> dict[str, np.ndarray]:
        """未学習(チェックポイントが無い)ときの初期値。PyTorchの既定初期化と同じ考え方で、意味のある精度にはならない。"""
        rng = np.random.default_rng(0)
        out: dict[str, np.ndarray] = {}
        for name, shape in self._shapes().items():
            if name == "card_embedding.embedding.weight":
                arr = rng.standard_normal(shape)
                arr[0] = 0
            elif name.startswith("memory_gate."):
                arr = np.zeros(shape)
            elif name.endswith("fusion.3.weight") or name.endswith("mlp.3.weight"):
                arr = np.ones(shape)
            elif name.endswith("fusion.3.bias") or name.endswith("mlp.3.bias"):
                arr = np.zeros(shape)
            else:
                fan_in = shape[-1] if len(shape) == 2 else self.hidden
                bound = 1.0 / math.sqrt(fan_in)
                arr = rng.uniform(-bound, bound, shape)
            out[name] = arr.astype(np.float32)
        return out

    def load_state_dict(self, state: dict, strict: bool = False) -> None:
        """PyTorch版と同じ名前の重みを読み込む。既存キーの形状が合わなければRuntimeError(web/app.pyが互換性なしと判断する)。"""
        shapes = self._shapes()
        embedding_keys = (
            "card_embedding.embedding.weight",
            "state_encoder.card_embedding.embedding.weight",
            "action_encoder.card_embedding.embedding.weight",
        )
        for key in embedding_keys:  # 3か所に同じ表がある(共有パラメータ)。最初に見つかったものを使う
            if key in state:
                state = {**state, "card_embedding.embedding.weight": state[key]}
                break
        for key, array in state.items():
            if key not in shapes:
                continue
            if tuple(array.shape) != shapes[key]:
                raise RuntimeError(f"size mismatch for {key}: {tuple(array.shape)} vs {shapes[key]}")
            self.w[key] = np.ascontiguousarray(array, dtype=np.float32)
        self.w["card_embedding.embedding.weight"][0] = 0

    def eval(self) -> "PolicyValueNetwork":
        return self

    def initial_hidden_state(self, device=None) -> np.ndarray:
        return np.zeros(self.state_dim, dtype=np.float32)

    # ---- 計算 -------------------------------------------------------------------------
    def _emb(self, idx) -> np.ndarray:
        return self.w["card_embedding.embedding.weight"][np.asarray(idx) + 1]

    def _linear(self, x, name: str) -> np.ndarray:
        return x @ self.w[name + ".weight"].T + self.w[name + ".bias"]

    def _encode_slots(self, slot, tool, pre, energy, features) -> np.ndarray:
        combined = np.concatenate(
            [self._emb(slot), np.asarray(features, np.float32), self._emb(tool), self._emb(pre), self._emb(energy).sum(axis=1)], axis=-1
        )
        return np.maximum(self._linear(combined, "state_encoder.slot_mlp.0"), 0).sum(axis=0)

    def _state_embedding(self, f) -> np.ndarray:
        own = self._encode_slots(f.own_slot_card_idx, f.own_slot_tool_idx, f.own_slot_pre_evolution_idx, f.own_slot_energy_idxs, f.own_slot_features)
        opp = self._encode_slots(f.opp_slot_card_idx, f.opp_slot_tool_idx, f.opp_slot_pre_evolution_idx, f.opp_slot_energy_idxs, f.opp_slot_features)

        def counts(name: str, vec) -> np.ndarray:
            return np.maximum(self._linear(np.asarray(vec, np.float32), f"state_encoder.{name}.0"), 0)

        last = self._emb([f.own_last_attack_used_idx, f.opp_last_attack_used_idx, f.pending_ability_choice_source_idx])
        fused = np.concatenate(
            [
                own,
                opp,
                counts("hand_mlp", f.own_hand_counts),
                counts("own_discard_mlp", f.own_discard_counts),
                counts("opp_discard_mlp", f.opp_discard_counts),
                counts("own_lost_zone_mlp", f.own_lost_zone_counts),
                counts("opp_lost_zone_mlp", f.opp_lost_zone_counts),
                counts("known_opponent_hand_mlp", f.own_known_opponent_hand_counts),
                counts("own_deck_prize_mlp", f.own_deck_and_prize_counts),
                self._emb([f.stadium_idx])[0],
                last[0],
                last[1],
                last[2],
                counts("global_mlp", f.global_features),
            ]
        )
        x = np.maximum(self._linear(fused, "state_encoder.fusion.0"), 0)
        x = self._linear(x, "state_encoder.fusion.2")
        return _layer_norm(x, self.w["state_encoder.fusion.3.weight"], self.w["state_encoder.fusion.3.bias"])

    def _memory(self, state_emb: np.ndarray, hidden: np.ndarray | None) -> np.ndarray:
        if hidden is None:
            hidden = self.initial_hidden_state()
        gi = state_emb @ self.w["memory_cell.weight_ih"].T + self.w["memory_cell.bias_ih"]
        gh = hidden @ self.w["memory_cell.weight_hh"].T + self.w["memory_cell.bias_hh"]
        i_r, i_z, i_n = np.split(gi, 3)
        h_r, h_z, h_n = np.split(gh, 3)
        r = _sigmoid(i_r + h_r)
        z = _sigmoid(i_z + h_z)
        n = np.tanh(i_n + r * h_n)
        return ((1.0 - z) * n + z * hidden).astype(np.float32)

    def observe(self, state_features, hidden_state=None) -> np.ndarray:
        return self._memory(self._state_embedding(state_features), hidden_state)

    def _action_embeddings(self, action_features) -> np.ndarray:
        type_and_target = np.stack([a.type_and_target for a in action_features]).astype(np.float32)
        max_cards = max(1, max(len(a.involved_card_idxs) for a in action_features))
        padded = np.full((len(action_features), max_cards), -1, dtype=np.int64)
        for i, a in enumerate(action_features):
            for j, idx in enumerate(a.involved_card_idxs):
                padded[i, j] = idx
        x = np.concatenate([type_and_target, self._emb(padded).sum(axis=1)], axis=-1)
        x = np.maximum(self._linear(x, "action_encoder.mlp.0"), 0)
        x = self._linear(x, "action_encoder.mlp.2")
        return _layer_norm(x, self.w["action_encoder.mlp.3.weight"], self.w["action_encoder.mlp.3.bias"])

    def __call__(self, state_features, action_features, hidden_state=None):
        """戻り値: (合法手ごとの生スコア, 状態価値(スカラー), 更新後の隠れ状態)。PyTorch版と同じ並び。"""
        state_emb = self._state_embedding(state_features)
        new_hidden = self._memory(state_emb, hidden_state)
        combined = state_emb + self._linear(new_hidden, "memory_gate")
        action_embs = self._action_embeddings(action_features)
        scores = (action_embs @ combined) / self._score_scale
        value_hidden = np.maximum(self._linear(combined, "value_head.0"), 0)
        value = np.tanh(self._linear(value_hidden, "value_head.2"))[0]
        return scores.astype(np.float32), value, new_hidden
