"""スマホ版用のスタブ(実績の勝率AIはスマホでは使わない)。"""


class EmpiricalWinRateAgent:
    def __init__(self, *args, **kwargs) -> None:
        raise RuntimeError("実績の勝率AIはスマホ版では使えません")
