"""actor視点で「見えている盤面+選んだ行動」を一意のキーに変換する。

自己対戦で同じ局面・同じ選択が何回出現したかを数えるための下準備(2026-09-24、ユーザー要望
「推定勝率の隣に、全く同じ盤面でその選択肢を何回選んだかを出してほしい」)。

「同じ盤面」の定義は独自に作らず、rl_env.encoding.encode_state()が既に厳密に切り分けている
「actorから見える情報だけ」(相手の手札・山札の中身は一切含まない)をそのまま再利用する。
これにより、推定勝率(価値ヘッドの入力)と出現回数の集計が同じ「盤面」の定義に基づくようになる。
"""

from __future__ import annotations

import hashlib

from cards.card_db import CardDatabase
from engine.actions import Action
from engine.state import GameState
from rl_env.encoding import CardVocab, StateFeatures, encode_state

# StateFeaturesの配列フィールド(np.ndarray)。tobytes()でそのままハッシュに投入する。
_ARRAY_FIELDS = (
    "own_slot_card_idx",
    "own_slot_features",
    "opp_slot_card_idx",
    "opp_slot_features",
    "own_slot_tool_idx",
    "opp_slot_tool_idx",
    "own_slot_pre_evolution_idx",
    "opp_slot_pre_evolution_idx",
    "own_slot_energy_idxs",
    "opp_slot_energy_idxs",
    "own_hand_counts",
    "own_discard_counts",
    "opp_discard_counts",
    "own_lost_zone_counts",
    "opp_lost_zone_counts",
    "own_known_opponent_hand_counts",
    "own_deck_and_prize_counts",
    "global_features",
)
# StateFeaturesのスカラーint フィールド。
_SCALAR_FIELDS = (
    "stadium_idx",
    "own_last_attack_used_idx",
    "opp_last_attack_used_idx",
    "pending_ability_choice_source_idx",
)


def _hash_state_features(features: StateFeatures) -> str:
    h = hashlib.sha256()
    for name in _ARRAY_FIELDS:
        h.update(getattr(features, name).tobytes())
    for name in _SCALAR_FIELDS:
        h.update(int(getattr(features, name)).to_bytes(8, "little", signed=True))
    return h.hexdigest()


def state_key(state: GameState, card_db: CardDatabase, vocab: CardVocab, actor: int) -> str:
    """actorから見える情報だけで一意化した、現在の盤面のキー(16進文字列)。"""
    features = encode_state(state, card_db, vocab, actor)
    return _hash_state_features(features)


def _canonicalize_action_repr(state: GameState, actor: int, action: Action) -> str:
    """行動の文字列表現を作る。hand_index/paired_hand_indexは、手札内の「何番目か」という
    (エンコーディングでは意味を持たない)並び順情報の代わりに、実際に指しているカードIDへ
    置き換える(手札は own_hand_counts という順不同の集合として符号化されているため、同じ
    手札構成でも山札から引いた順によってhand_indexがずれ、同じ選択が別のキーとして数えられて
    しまうのを防ぐ)。bench_index等の位置情報はそのまま使う(エンコーディング自体がベンチを
    固定スロットの配列として扱っており、位置そのものが状態の一部になっているため)。"""
    hand = state.player(actor).hand
    parts = [type(action).__name__]
    for field_name, value in sorted(vars(action).items()):
        if field_name == "extra_hand_indices":
            if not value:
                continue  # 既定値(4枚同時使用でない)のときは、従来のキーと同じ文字列にする(キーの互換性)
            value = tuple(f"card:{hand[i]}" if 0 <= i < len(hand) else i for i in value)
        if field_name in ("hand_index", "paired_hand_index") and isinstance(value, int) and 0 <= value < len(hand):
            value = f"card:{hand[value]}"
        parts.append(f"{field_name}={value!r}")
    return "|".join(parts)


def state_action_key(state: GameState, card_db: CardDatabase, vocab: CardVocab, actor: int, action: Action) -> str:
    """state_key()に、その局面で実際に選んだ行動を組み合わせた一意キー。行動適用前のstateを渡すこと。"""
    base = state_key(state, card_db, vocab, actor)
    return f"{base}::{_canonicalize_action_repr(state, actor, action)}"


def state_action_keys(
    state: GameState, card_db: CardDatabase, vocab: CardVocab, actor: int, actions: list[Action]
) -> list[str]:
    """actionsそれぞれのstate_action_key()を返す。盤面のエンコードは1回だけ行う。"""
    base = state_key(state, card_db, vocab, actor)
    return [f"{base}::{_canonicalize_action_repr(state, actor, a)}" for a in actions]
