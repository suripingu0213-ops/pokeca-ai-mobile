"""GameStateとActionを、方策ネットワークに入力できる固定長の数値表現に変換する。

不完全情報ゲームであることを踏まえ、エンコード対象は「行動主体プレイヤーから見て
公開されている情報」のみに限定する: 自分の手札・トラッシュの中身、盤面(自分・相手とも)、
相手のトラッシュの中身(公開情報)は入れるが、相手の手札・山札の中身は絶対に入れない
(枚数のみ)。これはテストで明示的に検証する(tests/test_encoding.py)。
"""

from __future__ import annotations

from dataclasses import dataclass, field

import numpy as np

from cards.card_db import ROBO_SUBSTITUTE_POKEMON_ID, CardDatabase
from engine.actions import (
    AcceptTrigger,
    Action,
    Attack,
    AttachEnergy,
    ChooseInitialActive,
    ChooseMulliganBonusDrawCount,
    ChooseNewActive,
    ConfirmSetupDone,
    DeclineTrigger,
    DiscardRoboSubstitute,
    EndTurn,
    Evolve,
    PassPowerSprayWindow,
    PlayBasicPokemon,
    PlayItem,
    PlayLevelUp,
    PlayPokemonTool,
    PlayStadium,
    PlaySupporter,
    ResolveDamageDistribution,
    ResolveSearchChoice,
    Retreat,
    UseAbility,
    UseBorrowedAttack,
    UseDiscardAbility,
    UsePowerSpray,
    UseStadiumAbility,
    Zone,
)
from engine.continuous import effective_max_hp
from engine.state import GameState, PlayerState, PokemonInPlay

# ---- カード語彙 ----

ENERGY_TYPES: tuple[str, ...] = (
    "Grass",
    "Fire",
    "Water",
    "Lightning",
    "Psychic",
    "Fighting",
    "Darkness",
    "Metal",
    "Fairy",
    "Dragon",
    "Colorless",
)
_ENERGY_TYPE_INDEX = {t: i for i, t in enumerate(ENERGY_TYPES)}
_ENERGY_OTHER_INDEX = len(ENERGY_TYPES)  # 基本タイプ名から判定できない特殊エネルギー用のバケット
ENERGY_TYPE_BUCKETS = len(ENERGY_TYPES) + 1

STATUS_NAMES: tuple[str, ...] = ("poisoned", "burned", "asleep", "paralyzed", "confused")

# StatusState内の「特殊状態の有無」だけでは表現しきれない強度・持続情報。以前は「どく」も
# 「2倍どく」も同じ1つのフラグにしか見えず、実際に受け続けるダメージ量が全く違うにもかかわらず
# 区別できていなかった(2026-08-20発覚、どうぐ/エネルギーの種類が集計値に埋もれていたのと
# 同じパターン)。
STATUS_INTENSITY_FEATURE_DIM = (
    1  # poison_severity(通常1=10ダメージ、一部カードは2以上に強化。正規化)
    + 1  # sleep_flip_count(通常1枚、カビゴンの「爆音イビキ」等は2枚。正規化)
    + 1  # paralysis_survives_next_checkup(マヒを与えた側の番の終わりのチェックでは治らない、
    # という一時的な内部タイミングの違い。これが立っている間は次のチェックでは治らない)
)

# PokemonInPlayが持つ「一時的な効果・封印」のうち、これまでAIの入力に一切含まれていなかったもの。
# 合法手の一覧(何ができるか)には正しく反映されていたため対局の進行自体に不具合は無かったが、
# 「なぜ選択肢が少ないのか」「この番だけ弱っているのか」を評価値の判断材料にできていなかった
# (2026-08-20、ユーザー指摘を受けて追加)。
DAMAGE_IMMUNITY_SCOPES: tuple[str, ...] = ("basic", "evolution", "gx_ex")
POKEMON_CONDITION_FEATURE_DIM = (
    1  # locked_attack_all_active(次の自分の番、全てのワザが使えない。LockOwnAttackNextTurn(
    # lock_all_attacks=True)、ザシアンVの「Brave Blade」/Nのゼクロムの「Rampaging Thunder」等)
    + 1  # locked_attack_specific_active(次の自分の番、特定の1ワザだけ使えない。他のワザは使用可)
    + 1  # locked_attack_specific_index(上記が有効なとき、ロックされているワザがcard.attacksの
    # 何番目か(正規化)。以前は「何かのワザがロックされている」ことしか分からず、複数ワザを
    # 持つポケモンでどのワザが封じられているかをAIが区別できていなかった)
    + 1  # attack_disabled_active(次の自分の番、攻撃できない)
    + 1  # retreat_disabled_active(次の自分の番、にげられない)
    + 1  # shielded_active(次の相手の番、ワザの効果を受けない)
    + 1  # damage_reduction_active(次の相手の番、受けるダメージ軽減)
    + 1  # damage_reduction_amount(軽減量、正規化)
    + 1  # destiny_bond_active(次の相手の番、きぜつしたら道連れ)
    + 1  # retaliate_on_damaged_active(次の相手の番、ダメージを受けたら反撃ダメカン)
    + 1  # retaliate_on_damaged_counters(反撃ダメカン数、正規化)
    + 1  # damage_immunity_active(次の相手の番、特定種別のワザダメージを受けない)
    + len(DAMAGE_IMMUNITY_SCOPES)  # damage_immunity_scope(対象種別のonehot)
    + 1  # damage_debuff_active(次の自分の番、このワザの基本ダメージが変わる)
    + 1  # no_prize_on_ko_active(次の相手の番、きぜつしてもサイドを取られない)
    + 1  # outgoing_damage_debuff_active(次の相手の番、このポケモンのワザダメージが減る)
    + 1  # outgoing_damage_debuff_amount(軽減量、正規化)
    + 1  # became_active_this_turn(この自分の番にベンチから出てきたばかりか)
    + 1  # used_ability_this_turn(1番に1回制限の特性を既に使ったか)
    + 1  # unlimited_ability_uses_this_turn(この番に何度でも使える特性を使った回数、正規化)
    + 1  # leveled_up(Lv.Xに進化済みか)
)

# 1体ぶんのポケモンスロット特徴量の次元(hp割合1 + ダメカン1 + エネルギータイプ内訳12
# + どうぐ有無1 + 特殊状態5 + 経過ターン1 + たねポケモンか1 + 上記の一時効果群)
POKEMON_SLOT_FEATURE_DIM = (
    1 + 1 + ENERGY_TYPE_BUCKETS + 1 + len(STATUS_NAMES) + STATUS_INTENSITY_FEATURE_DIM + 1 + 1
    + POKEMON_CONDITION_FEATURE_DIM
)
BENCH_SIZE = 5
SLOTS_PER_SIDE = 1 + BENCH_SIZE  # バトル場 + ベンチ5

# 1体のポケモンにつく個々のエネルギーカードの「種類」自体(どうぐ・進化元と同じ理由)。以前は
# ENERGY_TYPE_BUCKETSによるタイプ内訳(基本水エネルギー2枚、等)しか無く、Legacy Energy/Wonder
# Energy/Reversal Energy/Prism Energy/グロウ草エネルギー等、実カードのbasic_energy_typeがNone
# (=単一タイプに分類できない)特殊エネルギーは全て同じ「その他」バケットに埋もれ、AIからは
# 「何らかの特殊エネルギーがついている」以上のことが一切区別できなかった(2026-08-20発覚。
# 直前のセッションでこれらの特殊エネルギーの固有の追加効果(HP増加・サイド減少シールド・
# 効果無効・攻撃対象縛り等)を多数実装したにもかかわらず、AIの観測には反映されていなかった)。
# 1体につく枚数は可変なので、どうぐ(1枚専用)と違い固定長にパディングした配列で持ち、
# ActionEncoderが1つの行動に関与する複数カードを埋め込みの合計で表現しているのと同じ手法
# (StateEncoder._encode_slotsでカード埋め込みをスロットごとに合計する)で表現する。
MAX_ATTACHED_ENERGY_PER_SLOT = 8  # 現実のデッキでこれを超えることはまず無い安全マージン

# PlayerState単位の「今どんなリソースを使い切ったか/どんな一時ボーナス・封印が掛かっているか」。
# 人間のプレイヤーには対局画面から常に見えている情報(このターン既にエネルギーを付けた/
# サポートを使った、GXワザを既に使い切った、鋼タイプへの永続ダメージ軽減、次のきぜつで
# サイド+1、等)だが、以前はAIの入力に一切含まれておらず、当該ターンの合法手一覧に間接的に
# しか反映されていなかった(=先読みや価値評価では見えない)。2026-08-20、ユーザーからの
# 「本当に人間に見えている要素すべてがAIに見えているか」という指摘を受けて追加。
PLAYER_RESOURCE_FEATURE_DIM = (
    1  # energy_attached_this_turn
    + 1  # supporter_played_this_turn
    + 1  # stadium_played_this_turn
    + 1  # retreated_this_turn
    + 1  # used_stadium_ability_this_turn
    + 1  # used_gx_attack_this_game(1ゲームに1回制限、使い切ったか)
    + 1  # used_vstar_power_this_game(同上)
    + 1  # gx_attacks_locked(このゲーム中GXワザを一切使えない)
    + 1  # attack_locked_until_turn active(プレイヤー単位のワザ封印。ポケモン単位のattack_disabled_
    # until_turnとは別物で、以前はポケモン単位の方しか追加していなかった)
    + 1  # metal_damage_reduction_active(永続: 鋼ポケモンの被ダメージ-30)
    + 1  # pokemon_ko_by_attack_pending(相手の今の番の間に自分のポケモンがワザできぜつしたか)
    + 1  # pokemon_ko_by_attack_last_turn(直前の相手の番で同上)
    + 1  # pokemon_ko_pending(相手の今の番の間に自分のポケモンが原因問わずきぜつしたか)
    + 1  # pokemon_ko_last_turn(直前の相手の番で同上)
    + 1  # team_rocket_pokemon_ko_pending
    + 1  # team_rocket_pokemon_ko_last_turn
    + 1  # bonus_prize_next_knockout(次のきぜつで追加サイド、正規化)
    + 1  # bonus_prize_if_tera_ko_this_turn
    + 1  # legacy_energy_prize_denial_used(1ゲーム1回のサイド減少シールドを既に使ったか)
    + 1  # fusion_strike_damage_bonus_until_turn active
    + 1  # ex_v_bonus_damage_until_turn active
    + 1  # ex_bonus_damage_40_until_turn active
    + 1  # team_rocket_supporter_played_this_turn
    + 1  # used_discard_ability_this_turn
    + 1  # pending_second_attack(2回目のワザを選べる状態)
    + 1  # used_attack_twice_bonus_this_turn
)

# GameState単位(プレイヤーどちらかに属さない)の一時効果。Hex Maniacの特性封じ・ゲッコウガの
# Shadow Stitching・パラレルシティの向きは、以前はどれもAIの入力に含まれていなかった。
GLOBAL_LOCK_FEATURE_DIM = 3  # 両者の特性封印(Hex Maniac)/自分が対象のShadow Stitching/相手が対象の同効果
STADIUM_ORIENTATION_STATE_FEATURE_DIM = 2  # パラレルシティ等の「↓」効果が自分/相手のどちらに掛かっているか
# last_attack_used(card_idはStateFeatures.own/opp_last_attack_used_idxでカード埋め込みとして表現するが、
# 「どの技か」までは同じカードの複数ワザを区別できない。card.attacks内でのインデックス(正規化)を
# 追加で持たせ、ミミッキュの「コピーキャット」等で「直前に高火力ワザ/低火力ワザのどちらが使われたか」
# を近似的に区別できるようにする(engine/actions.pyのAttack行動特徴量で使っているのと同じ
# 「インデックスを正規化して1マスに詰める」近似手法)。
LAST_ATTACK_INDEX_FEATURE_DIM = 2  # own + opp

GLOBAL_FEATURE_DIM = (
    15
    + PLAYER_RESOURCE_FEATURE_DIM * 2  # own + opp
    + GLOBAL_LOCK_FEATURE_DIM
    + STADIUM_ORIENTATION_STATE_FEATURE_DIM
    + LAST_ATTACK_INDEX_FEATURE_DIM
)


class CardVocab:
    """カードID <-> 埋め込みインデックスの対応表。CardDatabaseから決定的な順序で構築する。"""

    def __init__(self, card_db: CardDatabase) -> None:
        self.card_ids: list[str] = sorted(c.id for c in card_db.all())
        self._index: dict[str, int] = {cid: i for i, cid in enumerate(self.card_ids)}

    @classmethod
    def from_card_ids(cls, card_ids: list[str]) -> "CardVocab":
        """チェックポイント保存時の語彙を復元する(cards/data/cache/cards.jsonは以後のセッションで
        カードが追加され続けるため、CardDatabaseから作り直すと埋め込みインデックスがずれてしまう)。"""
        vocab = cls.__new__(cls)
        vocab.card_ids = list(card_ids)
        vocab._index = {cid: i for i, cid in enumerate(vocab.card_ids)}
        return vocab

    def __len__(self) -> int:
        return len(self.card_ids)

    def index_of(self, card_id: str | None) -> int:
        """未知のカードIDやNoneには-1を返す(埋め込み側で「なし」として扱う)。"""
        if card_id is None:
            return -1
        return self._index.get(card_id, -1)


@dataclass
class StateFeatures:
    """encode_stateの出力。方策ネットワークがそのまま消費できる形にまとめてある。"""

    own_slot_card_idx: np.ndarray  # shape (SLOTS_PER_SIDE,) int64、空きスロットは-1
    own_slot_features: np.ndarray  # shape (SLOTS_PER_SIDE, POKEMON_SLOT_FEATURE_DIM) float32
    opp_slot_card_idx: np.ndarray
    opp_slot_features: np.ndarray
    own_slot_tool_idx: np.ndarray  # shape (SLOTS_PER_SIDE,) int64、どうぐ無し/空きスロットは-1。
    # どうぐの「有無」だけでなく「どのどうぐか」自体をカード埋め込みで見せる(以前はPOKEMON_SLOT_FEATURE_DIM
    # 内の2値フラグ1つしか無く、ふうせんも勇気のおまもりも同じ「どうぐ有り」にしか見えなかった)。
    opp_slot_tool_idx: np.ndarray
    own_slot_pre_evolution_idx: np.ndarray  # shape (SLOTS_PER_SIDE,) int64、進化前(直前)のcard_id。
    # 進化していない/空きスロットは-1。何から進化したか自体をカード埋め込みで見せる(BREAK進化の
    # ワザ引き継ぎ・退化ワザ等、進化元に依存する判断のため)。
    opp_slot_pre_evolution_idx: np.ndarray
    own_slot_energy_idxs: np.ndarray  # shape (SLOTS_PER_SIDE, MAX_ATTACHED_ENERGY_PER_SLOT) int64、
    # ついているエネルギーカードそれぞれのcard_id語彙インデックス(空き分は-1でパディング)。
    # ENERGY_TYPE_BUCKETSのタイプ内訳だけでは区別できない特殊エネルギーの「どれがついているか」を
    # カード埋め込みで見せる(MAX_ATTACHED_ENERGY_PER_SLOT参照)。
    opp_slot_energy_idxs: np.ndarray
    own_hand_counts: np.ndarray  # shape (vocab_size,) float32
    own_discard_counts: np.ndarray
    opp_discard_counts: np.ndarray  # 相手のトラッシュは公開情報なので中身を見てよい
    own_lost_zone_counts: np.ndarray  # ロストゾーンはトラッシュと同様、実カードルール上どちらの
    # プレイヤーからも見える公開情報(以前はAIの入力に一切含まれていなかった。レジドラゴVSTARの
    # 「Star Requiem」(自分のロストゾーンが10枚以上でのみ使用可)等、ロストゾーンの枚数そのものが
    # 攻め筋に直結するカードがあるため、しきい値に近づいているかをAIが判断できる必要がある)。
    opp_lost_zone_counts: np.ndarray  # 相手のロストゾーンも同様に公開情報
    own_known_opponent_hand_counts: np.ndarray  # 過去に相手の手札を公開させる効果(メガアブソルexの
    # 「Claw of Darkness」等)で見た内容のうち、現在も実際に相手の手札にありうる分(実際の手札構成
    # でクランプ済み。PlayerState.known_opponent_handのコメント参照)。以前はこの種の情報が公開
    # された直後の1手にしか使えず、以後のターンでは(状態として何も保持していなかったため)
    # 忘れてしまっていた(2026-08-20、ユーザー指摘を受けて追加)。
    own_deck_and_prize_counts: np.ndarray  # 自分の山札+サイド(未確定な部分)の構成。自分の元々の
    # デッキレシピは常に自分自身に既知の情報なので、「手札・トラッシュ・場に出た分」を引いた残り
    # (=山札に眠っているか、裏向きのサイドに埋まっているか、どちらかは自分でも分からない)を
    # そのまま見せてよい(相手の隠し情報を覗くわけではない)。
    stadium_idx: int  # 場にスタジアムが無ければ-1
    own_last_attack_used_idx: int  # 直前の自分の番で使ったワザのポケモンのcard_id語彙インデックス(-1=無し)。
    # ミミッキュの「コピーキャット」(相手が直前の番で使ったワザと同じダメージを出す)等の判定用。
    # 技名までは表現していない(同じポケモンの複数の技を区別する仕組みが無いため、stadium_idxと
    # 同じ「カード埋め込みをそのまま1つ足す」方式で近似する)。
    opp_last_attack_used_idx: int
    pending_ability_choice_source_idx: int  # 「してもよい」系ポケパワー(AcceptTrigger/DeclineTrigger)
    # またはパワースプレー割り込みウィンドウ(UsePowerSpray/PassPowerSprayWindow)が保留中のとき、
    # その発動元カードのcard_id語彙インデックス(どちらも保留していなければ-1)。Web UI上では
    # 「XXXの特性「YYY」を使いますか？」のように具体名が人間には常に見えているが、以前はAIの
    # 観測に一切含まれておらず、盤面から間接的に(このターンに出たばかりのポケモンか等)推測する
    # しかなかった(2026-08-20)。
    global_features: np.ndarray  # shape (GLOBAL_FEATURE_DIM,) float32


def _energy_bucket_counts(card_db: CardDatabase, energy_ids: list[str]) -> np.ndarray:
    vec = np.zeros(ENERGY_TYPE_BUCKETS, dtype=np.float32)
    for eid in energy_ids:
        card = card_db.get(eid)
        energy_type = card.basic_energy_type if card is not None else None
        idx = _ENERGY_TYPE_INDEX.get(energy_type, _ENERGY_OTHER_INDEX)
        vec[idx] += 1.0
    return vec


def _attack_index_normalized(card_db: CardDatabase, last_attack_used: tuple[str, str] | None) -> float:
    """last_attack_used=(card_id, attack_name)から、そのカードの技一覧の何番目かを正規化して返す。
    見つからなければ0.0(card_idそのものはown/opp_last_attack_used_idxで別途表現している)。"""
    if last_attack_used is None:
        return 0.0
    card_id, attack_name = last_attack_used
    card = card_db.get(card_id)
    if card is None:
        return 0.0
    attack_names = [a.name for a in card.attacks]
    if attack_name not in attack_names:
        return 0.0
    return min(attack_names.index(attack_name) / 3.0, 1.0)


def _condition_active(until_turn: int, reference_turns_taken: int) -> bool:
    """PokemonInPlayの`*_until_turn`系フィールド共通の有効判定(0なら無効、というルール全体で共通)。"""
    return until_turn > 0 and reference_turns_taken <= until_turn


def _player_resource_features(player: PlayerState) -> np.ndarray:
    """PlayerState単位のリソース消費状況/一時ボーナス・封印(PLAYER_RESOURCE_FEATURE_DIM参照)。"""
    vec = np.zeros(PLAYER_RESOURCE_FEATURE_DIM, dtype=np.float32)
    i = 0
    vec[i] = 1.0 if player.energy_attached_this_turn else 0.0
    i += 1
    vec[i] = 1.0 if player.supporter_played_this_turn else 0.0
    i += 1
    vec[i] = 1.0 if player.stadium_played_this_turn else 0.0
    i += 1
    vec[i] = 1.0 if player.retreated_this_turn else 0.0
    i += 1
    vec[i] = 1.0 if player.used_stadium_ability_this_turn else 0.0
    i += 1
    vec[i] = 1.0 if player.used_gx_attack_this_game else 0.0
    i += 1
    vec[i] = 1.0 if player.used_vstar_power_this_game else 0.0
    i += 1
    vec[i] = 1.0 if player.gx_attacks_locked else 0.0
    i += 1
    vec[i] = 1.0 if _condition_active(player.attack_locked_until_turn, player.turns_taken) else 0.0
    i += 1
    vec[i] = 1.0 if player.metal_damage_reduction_active else 0.0
    i += 1
    vec[i] = 1.0 if player.pokemon_ko_by_attack_pending else 0.0
    i += 1
    vec[i] = 1.0 if player.pokemon_ko_by_attack_last_turn else 0.0
    i += 1
    vec[i] = 1.0 if player.pokemon_ko_pending else 0.0
    i += 1
    vec[i] = 1.0 if player.pokemon_ko_last_turn else 0.0
    i += 1
    vec[i] = 1.0 if player.team_rocket_pokemon_ko_pending else 0.0
    i += 1
    vec[i] = 1.0 if player.team_rocket_pokemon_ko_last_turn else 0.0
    i += 1
    vec[i] = min(player.bonus_prize_next_knockout / 3.0, 1.0)
    i += 1
    vec[i] = 1.0 if player.bonus_prize_if_tera_ko_this_turn else 0.0
    i += 1
    vec[i] = 1.0 if player.legacy_energy_prize_denial_used else 0.0
    i += 1
    vec[i] = 1.0 if _condition_active(player.fusion_strike_damage_bonus_until_turn, player.turns_taken) else 0.0
    i += 1
    vec[i] = 1.0 if _condition_active(player.ex_v_bonus_damage_until_turn, player.turns_taken) else 0.0
    i += 1
    vec[i] = 1.0 if _condition_active(player.ex_bonus_damage_40_until_turn, player.turns_taken) else 0.0
    i += 1
    vec[i] = 1.0 if player.team_rocket_supporter_played_this_turn else 0.0
    i += 1
    vec[i] = 1.0 if player.used_discard_ability_this_turn else 0.0
    i += 1
    vec[i] = 1.0 if player.pending_second_attack else 0.0
    i += 1
    vec[i] = 1.0 if player.used_attack_twice_bonus_this_turn else 0.0
    i += 1
    return vec


def _encode_pokemon_slot(
    card_db: CardDatabase,
    mon: PokemonInPlay | None,
    current_turn: int,
    stadium_in_play: str | None = None,
    owner_turns_taken: int = 0,
    attacker_turns_taken: int = 0,
) -> tuple[int, np.ndarray]:
    features = np.zeros(POKEMON_SLOT_FEATURE_DIM, dtype=np.float32)
    if mon is None:
        return -1, features
    card = card_db.get(mon.card_id)
    # どうぐ/エネルギー/スタジアムによる最大HP増減(勇気のおまもり・グロウ草エネルギー・
    # グラビティマウンテン等)を反映しないと、実際にはまだ倒れていないポケモンのHP割合が
    # 誤って0(=きぜつ済みと見分けがつかない)近くまで下がって見えることがあった
    # (raw card.hpだけで割合を計算していたことによるAI側の観測バグ、2026-08-20)。
    max_hp = effective_max_hp(card_db, mon.card_id, mon.attached_tool, stadium_in_play, mon.attached_energy)
    hp_fraction = (mon.remaining_hp(max_hp) / max_hp) if max_hp else 0.0
    offset = 0
    features[offset] = hp_fraction
    offset += 1
    features[offset] = min(mon.damage / 100.0, 3.0)  # 大きすぎる値で勾配が荒れないよう緩くクリップ
    offset += 1
    features[offset : offset + ENERGY_TYPE_BUCKETS] = _energy_bucket_counts(card_db, mon.attached_energy)
    offset += ENERGY_TYPE_BUCKETS
    features[offset] = 1.0 if mon.attached_tool else 0.0
    offset += 1
    if mon.status.poisoned:
        features[offset] = 1.0
    if mon.status.burned:
        features[offset + 1] = 1.0
    status_name = mon.status.exclusive.name.lower()
    if status_name == "asleep":
        features[offset + 2] = 1.0
    elif status_name == "paralyzed":
        features[offset + 3] = 1.0
    elif status_name == "confused":
        features[offset + 4] = 1.0
    offset += len(STATUS_NAMES)
    features[offset] = min(mon.status.poison_severity / 3.0, 1.0) if mon.status.poisoned else 0.0
    offset += 1
    features[offset] = min(mon.status.sleep_flip_count / 3.0, 1.0) if status_name == "asleep" else 0.0
    offset += 1
    features[offset] = 1.0 if (status_name == "paralyzed" and mon.status.paralysis_survives_next_checkup) else 0.0
    offset += 1
    turns_since_played = max(0, current_turn - mon.turn_played) if mon.turn_played >= 0 else 0
    features[offset] = min(turns_since_played / 10.0, 1.0)
    offset += 1
    features[offset] = 1.0 if (card is not None and card.is_basic) else 0.0
    offset += 1

    # ここから一時効果群(PokemonInPlayの各*_until_turn等)。自分自身のturns_taken基準のものは
    # owner_turns_taken、相手(攻撃側)のturns_taken基準のものはattacker_turns_takenで判定する
    # (engine/state.pyの各フィールドのコメントに明記された基準と一致させる)。
    locked_attack_active = _condition_active(mon.locked_attack_until_turn, owner_turns_taken)
    features[offset] = 1.0 if (locked_attack_active and mon.locked_attack_name is None) else 0.0
    offset += 1
    locked_attack_specific = locked_attack_active and mon.locked_attack_name is not None
    features[offset] = 1.0 if locked_attack_specific else 0.0
    offset += 1
    if locked_attack_specific and card is not None:
        attack_names = [a.name for a in card.attacks]
        if mon.locked_attack_name in attack_names:
            features[offset] = min(attack_names.index(mon.locked_attack_name) / 3.0, 1.0)
    offset += 1
    features[offset] = 1.0 if _condition_active(mon.attack_disabled_until_turn, owner_turns_taken) else 0.0
    offset += 1
    features[offset] = 1.0 if _condition_active(mon.retreat_disabled_until_turn, owner_turns_taken) else 0.0
    offset += 1
    features[offset] = 1.0 if _condition_active(mon.shielded_until_turn, attacker_turns_taken) else 0.0
    offset += 1
    damage_reduction_active = _condition_active(mon.damage_reduction_until_turn, attacker_turns_taken)
    features[offset] = 1.0 if damage_reduction_active else 0.0
    offset += 1
    features[offset] = min(mon.damage_reduction_amount / 100.0, 1.0) if damage_reduction_active else 0.0
    offset += 1
    features[offset] = 1.0 if _condition_active(mon.destiny_bond_until_turn, attacker_turns_taken) else 0.0
    offset += 1
    retaliate_active = _condition_active(mon.retaliate_on_damaged_until_turn, attacker_turns_taken)
    features[offset] = 1.0 if retaliate_active else 0.0
    offset += 1
    features[offset] = min(mon.retaliate_on_damaged_counters / 10.0, 1.0) if retaliate_active else 0.0
    offset += 1
    damage_immunity_active = _condition_active(mon.damage_immunity_until_turn, attacker_turns_taken)
    features[offset] = 1.0 if damage_immunity_active else 0.0
    offset += 1
    if damage_immunity_active and mon.damage_immunity_scope in DAMAGE_IMMUNITY_SCOPES:
        features[offset + DAMAGE_IMMUNITY_SCOPES.index(mon.damage_immunity_scope)] = 1.0
    offset += len(DAMAGE_IMMUNITY_SCOPES)
    features[offset] = 1.0 if _condition_active(mon.damage_debuff_until_turn, owner_turns_taken) else 0.0
    offset += 1
    features[offset] = 1.0 if _condition_active(mon.no_prize_on_ko_until_turn, attacker_turns_taken) else 0.0
    offset += 1
    outgoing_debuff_active = _condition_active(mon.outgoing_damage_debuff_until_turn, owner_turns_taken)
    features[offset] = 1.0 if outgoing_debuff_active else 0.0
    offset += 1
    features[offset] = min(mon.outgoing_damage_debuff_amount / 100.0, 1.0) if outgoing_debuff_active else 0.0
    offset += 1
    features[offset] = 1.0 if (mon.became_active_turn >= 0 and mon.became_active_turn == owner_turns_taken) else 0.0
    offset += 1
    features[offset] = 1.0 if mon.used_ability_this_turn else 0.0
    offset += 1
    from engine.legal_actions import _UNLIMITED_ABILITY_USE_CAP  # 循環import回避のため遅延import
    # 実際の上限(_UNLIMITED_ABILITY_USE_CAP=8)より小さい値(以前は5.0)で正規化していたため、
    # 5回以上使った時点で特徴量が1.0に張り付き、「まだ使える(5〜7回目)」と「もう使えない
    # (8回目=上限到達)」をAIが区別できなくなっていた(2026-08-22発覚)。上限と正規化の分母を
    # 一致させることで、legal_actionsのゲート判定と完全に対応するようにした。
    features[offset] = min(mon.unlimited_ability_uses_this_turn / _UNLIMITED_ABILITY_USE_CAP, 1.0)
    offset += 1
    features[offset] = 1.0 if mon.leveled_up else 0.0
    return vocab_index_or_neg1(card_db, mon.card_id), features


def vocab_index_or_neg1(card_db: CardDatabase, card_id: str) -> int:
    # encode_state呼び出し側がCardVocabを持っているので、実際のインデックス解決はそちらで行う。
    # ここではプレースホルダのcard_idを返さず、呼び出し元でvocab.index_ofするための橋渡しとして
    # card_idそのものではなくNoneを返さないようにするためだけの関数(下のencode_stateで上書きする)。
    return -1


def _encode_side_slots(
    card_db: CardDatabase,
    vocab: CardVocab,
    player: PlayerState,
    current_turn: int,
    stadium_in_play: str | None = None,
    owner_turns_taken: int = 0,
    attacker_turns_taken: int = 0,
) -> tuple[np.ndarray, np.ndarray, np.ndarray, np.ndarray, np.ndarray]:
    slot_idx = np.full(SLOTS_PER_SIDE, -1, dtype=np.int64)
    tool_idx = np.full(SLOTS_PER_SIDE, -1, dtype=np.int64)
    pre_evolution_idx = np.full(SLOTS_PER_SIDE, -1, dtype=np.int64)
    energy_idxs = np.full((SLOTS_PER_SIDE, MAX_ATTACHED_ENERGY_PER_SLOT), -1, dtype=np.int64)
    slot_features = np.zeros((SLOTS_PER_SIDE, POKEMON_SLOT_FEATURE_DIM), dtype=np.float32)
    mons: list[PokemonInPlay | None] = [player.active] + [
        player.bench[i] if i < len(player.bench) else None for i in range(BENCH_SIZE)
    ]
    for i, mon in enumerate(mons):
        _, features = _encode_pokemon_slot(
            card_db, mon, current_turn, stadium_in_play, owner_turns_taken, attacker_turns_taken
        )
        slot_features[i] = features
        if mon is not None:
            slot_idx[i] = vocab.index_of(mon.card_id)
            if mon.attached_tool:
                tool_idx[i] = vocab.index_of(mon.attached_tool)
            if mon.evolution_history:
                pre_evolution_idx[i] = vocab.index_of(mon.evolution_history[-1])
            for j, energy_id in enumerate(mon.attached_energy[:MAX_ATTACHED_ENERGY_PER_SLOT]):
                energy_idxs[i, j] = vocab.index_of(energy_id)
    return slot_idx, tool_idx, pre_evolution_idx, energy_idxs, slot_features


def _zone_count_vector(vocab: CardVocab, card_ids: list[str]) -> np.ndarray:
    vec = np.zeros(len(vocab), dtype=np.float32)
    for cid in card_ids:
        idx = vocab.index_of(cid)
        if idx >= 0:
            vec[idx] += 1.0
    return vec


def _known_opponent_hand_counts(vocab: CardVocab, believed: list[str], actual_hand: list[str]) -> np.ndarray:
    """PlayerState.known_opponent_hand(過去に公開された時点のスナップショット)を、実際の現在の
    手札構成でカード種別ごとにクランプして返す。believedに残っていても、実際の手札に既に無い
    (使われた/捨てられた等)分は数えない。believedを能動的に書き換えなくても、この関数が呼ばれる
    たびに現実と自動的に整合する(手札を操作する効果1つ1つにこの記憶の更新処理を追加して回る
    必要が無く、実装漏れのリスクが無い)。"""
    believed_counts: dict[str, int] = {}
    for cid in believed:
        believed_counts[cid] = believed_counts.get(cid, 0) + 1
    actual_counts: dict[str, int] = {}
    for cid in actual_hand:
        actual_counts[cid] = actual_counts.get(cid, 0) + 1
    vec = np.zeros(len(vocab), dtype=np.float32)
    for cid, count in believed_counts.items():
        idx = vocab.index_of(cid)
        if idx >= 0:
            vec[idx] = min(count, actual_counts.get(cid, 0))
    return vec


def encode_state(state: GameState, card_db: CardDatabase, vocab: CardVocab, actor: int) -> StateFeatures:
    """actor視点でGameStateをエンコードする。相手の手札・山札の中身は一切参照しない。"""
    own = state.player(actor)
    opp = state.player(1 - actor)

    # 各ポケモンの一時効果(*_until_turn)は、フィールドごとに「持ち主自身のturns_taken基準」か
    # 「相手(攻撃側)のturns_taken基準」かが異なる(engine/state.py参照)。ownスロットにとっての
    # 攻撃側はopp、oppスロットにとっての攻撃側はownなので、side別に役割を入れ替えて渡す。
    own_slot_idx, own_tool_idx, own_pre_evo_idx, own_energy_idxs, own_slot_features = _encode_side_slots(
        card_db, vocab, own, state.turn_number, state.stadium_in_play, own.turns_taken, opp.turns_taken
    )
    opp_slot_idx, opp_tool_idx, opp_pre_evo_idx, opp_energy_idxs, opp_slot_features = _encode_side_slots(
        card_db, vocab, opp, state.turn_number, state.stadium_in_play, opp.turns_taken, own.turns_taken
    )

    stadium_idx = vocab.index_of(state.stadium_in_play) if state.stadium_in_play else -1

    global_features = np.zeros(GLOBAL_FEATURE_DIM, dtype=np.float32)
    global_features[0] = min(state.turn_number / 20.0, 1.0)
    global_features[1] = 1.0 if actor == state.first_player else 0.0  # 先攻かどうか
    global_features[2] = len(own.prizes) / 6.0
    global_features[3] = len(opp.prizes) / 6.0
    global_features[4] = min(len(own.hand) / 10.0, 1.0)
    global_features[5] = min(len(opp.hand) / 10.0, 1.0)  # 中身は入れない、枚数のみ
    global_features[6] = min(len(own.deck) / 60.0, 1.0)
    global_features[7] = min(len(opp.deck) / 60.0, 1.0)  # 中身は入れない、枚数のみ
    global_features[8] = len(own.bench) / BENCH_SIZE
    global_features[9] = len(opp.bench) / BENCH_SIZE
    global_features[10] = 1.0 if (own.items_locked_until_turn > 0 and own.turns_taken <= own.items_locked_until_turn) else 0.0
    global_features[11] = 1.0 if (opp.items_locked_until_turn > 0 and opp.turns_taken <= opp.items_locked_until_turn) else 0.0
    # ルール環境そのものを明示的に与える(レギュレーションIDのonehotにすると未知のレギュレーションに
    # 汎化できなくなるため、代わりにルールの意味=ブール値を渡す。同じネットワークで年代の異なる
    # 対局を学習させても、先攻1ターン目の制約差がここで明示されるので判断が混ざりにくくなる)。
    global_features[12] = 1.0 if state.ruleset.first_player_can_attack_turn1 else 0.0
    global_features[13] = 1.0 if state.ruleset.first_player_can_play_trainers_turn1 else 0.0
    global_features[14] = 1.0 if state.ruleset.first_player_can_play_supporter_turn1 else 0.0

    offset = 15
    global_features[offset : offset + PLAYER_RESOURCE_FEATURE_DIM] = _player_resource_features(own)
    offset += PLAYER_RESOURCE_FEATURE_DIM
    global_features[offset : offset + PLAYER_RESOURCE_FEATURE_DIM] = _player_resource_features(opp)
    offset += PLAYER_RESOURCE_FEATURE_DIM

    # サポート「Hex Maniac」(両者の特性を封じる)/ゲッコウガの「Shadow Stitching」(対象プレイヤー
    # のみ特性を封じる)。以前はどちらもAIの入力に無く、当該ターンの合法手からUseAbilityが
    # 消えることでしか間接的にしか分からなかった。
    global_ability_lock_active = (
        state.global_ability_lock_owner >= 0
        and state.player(state.global_ability_lock_owner).turns_taken <= state.global_ability_lock_until_turn
    )
    global_features[offset] = 1.0 if global_ability_lock_active else 0.0
    offset += 1
    global_features[offset] = (
        1.0
        if (state.opponent_ability_lock_target == actor and own.turns_taken <= state.opponent_ability_lock_until_turn)
        else 0.0
    )
    offset += 1
    global_features[offset] = (
        1.0
        if (
            state.opponent_ability_lock_target == (1 - actor)
            and opp.turns_taken <= state.opponent_ability_lock_until_turn
        )
        else 0.0
    )
    offset += 1

    # パラレルシティ等「出すときに向きを選べる」スタジアムの、現在どちらの側が効果を受けているか。
    # 以前は行動時(PlayStadium.orientation_target)しか反映されておらず、出した後の継続効果として
    # 場に残っている間はAIから見えなかった。
    global_features[offset] = 1.0 if state.stadium_orientation_target == actor else 0.0
    offset += 1
    global_features[offset] = 1.0 if state.stadium_orientation_target == (1 - actor) else 0.0
    offset += 1

    own_last_attack_used_idx = vocab.index_of(own.last_attack_used[0]) if own.last_attack_used else -1
    opp_last_attack_used_idx = vocab.index_of(opp.last_attack_used[0]) if opp.last_attack_used else -1
    global_features[offset] = _attack_index_normalized(card_db, own.last_attack_used)
    offset += 1
    global_features[offset] = _attack_index_normalized(card_db, opp.last_attack_used)
    offset += 1

    if state.pending_trigger is not None:
        pending_ability_choice_source_idx = vocab.index_of(state.pending_trigger.source_card_id)
    elif state.pending_power_spray_window is not None:
        pending_ability_choice_source_idx = vocab.index_of(state.pending_power_spray_window.source_card_id)
    else:
        pending_ability_choice_source_idx = -1

    return StateFeatures(
        own_slot_card_idx=own_slot_idx,
        own_slot_features=own_slot_features,
        opp_slot_card_idx=opp_slot_idx,
        opp_slot_features=opp_slot_features,
        own_slot_tool_idx=own_tool_idx,
        opp_slot_tool_idx=opp_tool_idx,
        own_slot_pre_evolution_idx=own_pre_evo_idx,
        opp_slot_pre_evolution_idx=opp_pre_evo_idx,
        own_slot_energy_idxs=own_energy_idxs,
        opp_slot_energy_idxs=opp_energy_idxs,
        own_hand_counts=_zone_count_vector(vocab, own.hand),
        own_discard_counts=_zone_count_vector(vocab, own.discard),
        opp_discard_counts=_zone_count_vector(vocab, opp.discard),  # トラッシュは公開情報
        own_lost_zone_counts=_zone_count_vector(vocab, own.lost_zone),
        opp_lost_zone_counts=_zone_count_vector(vocab, opp.lost_zone),  # ロストゾーンも公開情報
        own_known_opponent_hand_counts=_known_opponent_hand_counts(vocab, own.known_opponent_hand, opp.hand),
        # 中身が分かっているサイド(タウンマップ/Eye Opener)は「山札かサイドのどちらか」の不確定な集合から除く
        own_deck_and_prize_counts=_zone_count_vector(
            vocab, own.deck + [c for i, c in enumerate(own.prizes) if own.prize_mark(i) == 0]
        ),
        stadium_idx=stadium_idx,
        own_last_attack_used_idx=own_last_attack_used_idx,
        opp_last_attack_used_idx=opp_last_attack_used_idx,
        pending_ability_choice_source_idx=pending_ability_choice_source_idx,
        global_features=global_features,
    )


# ---- 行動エンコーディング ----

ACTION_TYPES: tuple[type, ...] = (
    PlayBasicPokemon,
    Evolve,
    PlayLevelUp,
    AttachEnergy,
    PlayItem,
    PlaySupporter,
    PlayStadium,
    PlayPokemonTool,
    UseAbility,
    Retreat,
    Attack,
    UseBorrowedAttack,
    ChooseNewActive,
    EndTurn,
    ChooseInitialActive,
    ConfirmSetupDone,
    ChooseMulliganBonusDrawCount,
    ResolveSearchChoice,
    AcceptTrigger,
    DeclineTrigger,
    UseStadiumAbility,
    ResolveDamageDistribution,
    UsePowerSpray,
    PassPowerSprayWindow,
    UseDiscardAbility,
    DiscardRoboSubstitute,  # みがわりロボ(xy4-102)を自分の番にトラッシュする効果。ACTION_TYPESに
    # 含まれていなかったため、種別onehotが常に全ゼロ(=どの行動種別なのか一切表現されない)に
    # なっていた(2026-08-20発覚。実際の自己対戦データ(data/replays/)に出現する手であるにも
    # かかわらず、AIの行動特徴量からは事実上見えていなかった)。
)
_ACTION_TYPE_INDEX = {t: i for i, t in enumerate(ACTION_TYPES)}
NUM_ACTION_TYPES = len(ACTION_TYPES)

# アクション特徴量: 種別onehot + 関与カードの語彙インデックス用に予約した1マス(埋め込みは呼び出し側)
# + 対象スロットonehot(なし/バトル場/ベンチ0-4の7通り)
ACTION_TARGET_SLOTS = 1 + SLOTS_PER_SIDE  # なし + バトル場 + ベンチ5
# ResolveDamageDistribution(ダメカン自由配分)専用: 対象スロットごとの配分数(なし/バトル場/ベンチ0-4)。
# 以前はcounts自体が行動特徴量に一切反映されておらず、同じ選択肢の中でどう配分しても
# type_and_target/involved_card_idxsが完全に同一になっていた(2026-08-20発覚。ユーザー報告の
# 「ファントムダイブのダメージの乗せ方についてAIの評価値がありません」の根本原因。UI側の表示
# 修正は別途この時点までに入っていたが、ネットワークの行動特徴量自体は依然として区別できて
# いなかった)。target_slot onehotと同じ並び順(0=なし/1=バトル場/2..6=ベンチ0-4)を再利用する。
DAMAGE_DISTRIBUTION_SLOTS = ACTION_TARGET_SLOTS
# PlayStadium.orientation_target(パラレルシティ等「自分/相手どちらに向けて出すか」)専用の1マス。
# 以前はorientation_targetが行動特徴量に一切反映されておらず、パラレルシティを自分向け/相手向け
# のどちらで出しても行動特徴量が完全に同一になっていた(2026-08-20発覚、ダメカン配分と同じ
# パターンのバグ)。1.0=自分に向ける/0.0=相手に向ける(またはorientation_targetを持たない行動)。
STADIUM_ORIENTATION_FEATURE_DIM = 1
# Attack.target_bench_indexが「相手のバトルポケモンのワザ一覧の何番目を選んだか」として流用されて
# いる場合(ロケット団のヤミカラスの「Torment」等、LockChosenOpponentAttackNextTurn)専用の1マス。
# 以前はこの流用がAIの行動特徴量に一切反映されておらず(盤面スロットとしても誤ってベンチ扱い
# されていた)、相手のどのワザを封じる選択なのか区別できていなかった(2026-08-21発覚)。
OPPONENT_ATTACK_CHOICE_FEATURE_DIM = 1
# ChooseMulliganBonusDrawCount.count(マリガンボーナスドローを何枚引くか、0〜相手のマリガン回数)
# 専用の1マス。他のcount系選択(ResolveDamageDistribution等)と同じく、この値自体を行動特徴量に
# 反映しないと同じ選択肢の中でどの枚数を選んでも区別できなくなる(2026-09-01、マリガンボーナス
# ドローの枚数選択を新規追加した際に同じ轍を踏まないよう最初から対応)。
MULLIGAN_BONUS_DRAW_COUNT_FEATURE_DIM = 1
ACTION_FEATURE_DIM = (
    NUM_ACTION_TYPES
    + ACTION_TARGET_SLOTS
    + DAMAGE_DISTRIBUTION_SLOTS
    + STADIUM_ORIENTATION_FEATURE_DIM
    + OPPONENT_ATTACK_CHOICE_FEATURE_DIM
    + MULLIGAN_BONUS_DRAW_COUNT_FEATURE_DIM
)


@dataclass
class ActionFeatures:
    type_and_target: np.ndarray  # shape (ACTION_FEATURE_DIM,) float32
    involved_card_idxs: list[int]  # このアクションが直接関与するカード全ての語彙インデックス(無ければ空リスト)。
    # ActionEncoder側で各カードを埋め込んでから合計する(集合の表現として標準的な手法。空リストの合計は
    # ゼロベクトルになるので「関与カードなし」も自然に表現できる)。1枚だけのアクション(大多数)は
    # 要素1つのリストになり、旧来のスカラー版と数学的に同じ結果になる。


def _involved_card_ids(
    action: Action, player: PlayerState, card_db: CardDatabase, state: GameState | None = None
) -> list[str]:
    """このアクションが手札から出す/使う/選ぶ対象のカードID一覧(describe_actionと同じ抽出ロジックの
    多枚数版)。ResolveSearchChoiceで複数選ぶ場合は選んだ全てのカードを返す。"""
    if isinstance(
        action, (PlayBasicPokemon, Evolve, PlayLevelUp, AttachEnergy, PlayPokemonTool, PlayStadium, ChooseInitialActive)
    ):
        if 0 <= action.hand_index < len(player.hand):
            return [player.hand[action.hand_index]]
        return []
    if isinstance(action, Attack):
        if player.active is None:
            return []
        card = card_db.get(player.active.card_id)
        if card is None or not (0 <= action.attack_index < len(card.attacks)):
            return []
        # 同じポケモンの複数の技を区別するための応急措置: involved_card_idxsは複数枚のカードの
        # 埋め込みを合計する仕組み(ActionEncoder参照)なので、同じカードIDを(attack_index+1)回
        # 含めることで技ごとに合計ベクトルの大きさを変え、最低限の差別化を行う(本来は技名/技
        # インデックス専用の特徴量を持たせるのが正攻法だが、それには行動特徴量の次元数を増やす
        # 必要があり、既存チェックポイントとの互換性が壊れるため見送っている。2026-08-18に、
        # 2つ技を持つポケモンの技の評価値が常に同一になるバグとして発覚)。
        return [player.active.card_id] * (action.attack_index + 1)
    if isinstance(action, UseAbility):
        mon = player.active if action.zone == Zone.ACTIVE else (player.bench[action.bench_index] if action.bench_index is not None and action.bench_index < len(player.bench) else None)
        if mon is None:
            return []
        ids = [mon.card_id]
        if getattr(action, "from_tool", False) and mon.attached_tool:
            ids.append(mon.attached_tool)  # 森の封印石等、どうぐ由来の特性は、そのどうぐも行動特徴量に含める
        # 特性が対象を選ぶ場合(サマヨール/ヨノワールの「Cursed Blast」、ムンキドリの「Adrena-Brain」の
        # 対象選択1歩目、フシギバナEXの「Solar Transfer」等のエネルギー移動先等)、以前はaction.
        # target_bench_indexが行動特徴量に一切反映されておらず、どの対象を選んでも(発動元の
        # ポケモン1匹ぶんのIDしか無いため)完全に同一の行動特徴量になっていた(2026-08-31発覚:
        # ユーザー報告「カーストボム/アドレナブレインの評価値が同じ」)。
        if state is not None:
            card = card_db.get(mon.card_id)
            if card is not None:
                from effects.primitives import MoveDamageCountersFromSelfToOpponentActive
                from effects.registry import NotImplementedEffect, get_ability_script
                from engine.legal_actions import _ability_needs_target, _targets_chosen_opponent_pokemon

                script: tuple = ()
                for ability in card.abilities:
                    candidate = get_ability_script(mon.card_id, ability.name)
                    if candidate and not all(isinstance(e, NotImplementedEffect) for e in candidate):
                        script = candidate
                        break
                if any(
                    isinstance(e, MoveDamageCountersFromSelfToOpponentActive) or _targets_chosen_opponent_pokemon(e)
                    for e in script
                ):
                    opponent = state.players[1] if player is state.players[0] else state.players[0]
                    target = (
                        opponent.active
                        if action.target_bench_index is None
                        else (opponent.bench[action.target_bench_index] if action.target_bench_index < len(opponent.bench) else None)
                    )
                    if target is not None:
                        ids.append(target.card_id)
                elif _ability_needs_target(script):
                    target = (
                        player.active
                        if action.target_bench_index is None
                        else (player.bench[action.target_bench_index] if action.target_bench_index < len(player.bench) else None)
                    )
                    if target is not None:
                        ids.append(target.card_id)
        return ids
    if isinstance(action, UseBorrowedAttack):
        # Attackと同じ理由(751行目付近のコメント参照): 借りる元のポケモンが複数のワザを持つ場合
        # (Nのゾロアークexの「Night Joker」でNのゼクロムの「Shred」/「Rampaging Thunder」のどちらを
        # 借りるか等)、以前はsource_card_idしか返しておらず、どのワザを借りたかが行動特徴量に
        # 一切反映されていなかった(2026-08-25発覚。type_and_target/involved_card_idxsが完全に同一に
        # なり、借りるワザによって価値が大きく異なる場合でもAIが区別できなかった)。
        source_card = card_db.get(action.source_card_id)
        if source_card is not None:
            attack_names = [a.name for a in source_card.attacks]
            if action.attack_name in attack_names:
                return [action.source_card_id] * (attack_names.index(action.attack_name) + 1)
        return [action.source_card_id]
    if isinstance(action, DiscardRoboSubstitute):
        return [ROBO_SUBSTITUTE_POKEMON_ID]
    if isinstance(action, UseDiscardAbility):
        if action.from_hand:
            return [player.hand[action.discard_index]] if 0 <= action.discard_index < len(player.hand) else []
        if 0 <= action.discard_index < len(player.discard):
            return [player.discard[action.discard_index]]
        return []
    if isinstance(action, (PlaySupporter, PlayItem)):
        played_ids = [player.hand[action.hand_index]] if 0 <= action.hand_index < len(player.hand) else []
        if isinstance(action, PlayItem):
            # 2枚/4枚同時使用は、1枚だけ使う行動と区別するため、同時に使うカードも含める(合計ベクトルの大きさが変わる)
            for extra in ((action.paired_hand_index,) if action.paired_hand_index is not None else ()) + tuple(action.extra_hand_indices):
                if 0 <= extra < len(player.hand):
                    played_ids.append(player.hand[extra])
        if action.target_bench_index is not None:
            # ボスの指令/プライムキャッチャー等、相手(またはカミツレのきらめき等、自分)のベンチ
            # ポケモンを対象に選ぶトレーナーズ。以前は再生した手札のカードIDしか含めておらず、
            # 「どのベンチ位置のどのポケモンを狙ったか」が行動特徴量に一切反映されていなかった
            # (2026-08-18に発覚: ベンチ位置が違っても評価値が完全に同一になっていた)。
            from engine.legal_actions import (
                _ITEM_TARGETS_OPPONENT_BENCH,
                _ITEM_TARGETS_OWN_BENCH,
                _SUPPORTER_TARGETS_OPPONENT_BENCH,
                _SUPPORTER_TARGETS_OWN_BENCH,
            )

            card_id = played_ids[0] if played_ids else None
            target_player = None
            if state is not None and (card_id in _SUPPORTER_TARGETS_OPPONENT_BENCH or card_id in _ITEM_TARGETS_OPPONENT_BENCH):
                target_player = state.players[1] if player is state.players[0] else state.players[0]
            elif card_id in _SUPPORTER_TARGETS_OWN_BENCH or card_id in _ITEM_TARGETS_OWN_BENCH:
                target_player = player
            if target_player is not None and 0 <= action.target_bench_index < len(target_player.bench):
                played_ids.append(target_player.bench[action.target_bench_index].card_id)
        return played_ids
    if isinstance(action, ResolveSearchChoice):
        # ハイパーボールで持ってくるカード/コストとして捨てるカード等、「どのカードを選んだか」を
        # 表現しないと、同じ選択肢の中のどの組み合わせを選んでも行動特徴量が完全に同一になってしまい、
        # ネットワークがこの種の選択を一切学習できなくなる(2026-08-14に発覚したバグ)。複数選択
        # (min_count<max_countで2枚以上選ぶ場合)は選んだ全てのカードを返す(ActionEncoder側で
        # 各カードの埋め込みを合計するため、1枚選択と同じ仕組みで自然に多枚数も表現できる)。
        choice = state.pending_search_choice if state is not None else None
        if choice is None or not action.selected_indices:
            return []
        if choice.zone == "own_prizes_take":
            # サイドを取る選択: 実物のサイドは取るまで裏向きの私的情報であり、実カードルール上
            # プレイヤー自身も中身を見ずに選ぶ(アグノムやタウンマップ等の特殊カードを使わない限り
            # 見えない)。ここでcard_ids(=実際の中身)をそのまま返すと、AIの行動特徴量に本来
            # 見えないはずのサイドの中身が漏れ、隠し情報にアクセスして意思決定するモデルになって
            # しまう(2026-08-26、ユーザー報告「AIがサイドを取るときにサイドが見えている可能性が
            # あります」で発覚)。この選択は常に同じ枚数(min_count==max_count)を選ぶだけの
            # 「どの位置を取るか」であり中身に基づく区別をすべきではないため、関与カードなし
            # (空リスト)を返す。
            return []
        if choice.zone == "revealed_card_attack_choice":
            # ひらめきチャレンジ等、山札から見つけたポケモンのワザを選ぶ選択: card_idsは同じカードを
            # 技の数ぶん繰り返しているだけ(751行目付近のAttackと同じ理由)なので、選んだ位置だけでは
            # どの技を選んだか行動特徴量に反映されず、評価値が常に同一(50/50)になってしまっていた
            # (2026-08-26、ユーザー報告で発覚)。Attack/UseBorrowedAttackと同じ「(技インデックス+1)回
            # 繰り返す」応急措置で最低限の差別化を行う。
            result: list[str] = []
            for i in action.selected_indices:
                if not (0 <= i < len(choice.card_ids)):
                    continue
                attack_index = choice.source_indices[i] if i < len(choice.source_indices) else 0
                result.extend([choice.card_ids[i]] * (attack_index + 1))
            return result
        if choice.zone == "damage_counter_amount_choice":
            # ムンキドリの特性「Adrena-Brain」: 何個移すか選ぶ選択。card_idsは実カードIDではなく
            # "0個"/"1個"/"2個"/"3個"という表示用ラベル文字列そのものなので、そのまま返すと
            # CardVocab側で全て「未知のカード」(=同一の埋め込み)扱いになり、選んだ個数によらず
            # 行動特徴量が完全に一致して評価値が常に同一になっていた(revealed_card_attack_choiceと
            # 同種のバグ、2026-08-27ユーザー報告で発覚)。移動元ポケモンの実カードIDを
            # 「(選んだ個数+1)回」繰り返す同じ応急措置で最低限の差別化を行う。
            mode_data = choice.custom_data if isinstance(choice.custom_data, dict) else {}
            source_pokemon = mode_data.get("source_pokemon")
            source_card_id = getattr(source_pokemon, "card_id", None)
            if source_card_id is None:
                return []
            result = []
            for i in action.selected_indices:
                if not (0 <= i < len(choice.source_indices)):
                    continue
                amount = choice.source_indices[i]
                result.extend([source_card_id] * (amount + 1))
            return result
        return [choice.card_ids[i] for i in action.selected_indices if 0 <= i < len(choice.card_ids)]
    return []


def _attack_targets_opponent_attack_choice(action: Action, player: PlayerState | None, card_db: CardDatabase | None) -> bool:
    """Attackのtarget_bench_indexが「相手のベンチ位置」ではなく「相手のバトルポケモンのワザ一覧の
    何番目か」として流用されているケース(ロケット団のヤミカラスの「Torment」/ラルトスの
    「Memory Skip」等、LockChosenOpponentAttackNextTurn)かどうかを判定する。"""
    if not isinstance(action, Attack) or player is None or card_db is None:
        return False
    if player.active is None:
        return False
    card = card_db.get(player.active.card_id)
    if card is None or not (0 <= action.attack_index < len(card.attacks)):
        return False
    from effects.primitives import LockChosenOpponentAttackNextTurn
    from effects.registry import get_attack_script

    script = get_attack_script(player.active.card_id, card.attacks[action.attack_index].name)
    return any(isinstance(e, LockChosenOpponentAttackNextTurn) for e in script)


def _target_slot_index(action: Action, player: PlayerState | None = None, card_db: CardDatabase | None = None) -> int:
    """0=対象なし、1=バトル場、2..6=ベンチ0..4。

    ベンチはゼロの大空洞(sv7-131)等で最大8体まで拡張されうるが、この行動エンコーディングの
    次元(ACTION_TARGET_SLOTS)は既存の学習済みチェックポイントとの互換性を保つため5体分のまま
    固定している。ベンチindexが表現できる範囲を超える場合は末尾スロットにまとめる(6体目以降は
    5体目と同じ表現になり区別できなくなるが、クラッシュを避けるための実用上の割り切り)。
    """
    target_zone = getattr(action, "target_zone", None)
    target_bench_index = getattr(action, "target_bench_index", None)
    if target_zone is not None:
        if target_zone == Zone.ACTIVE:
            return 1
        if target_bench_index is not None:
            return min(2 + target_bench_index, ACTION_TARGET_SLOTS - 1)
        return 0
    if isinstance(action, (UseAbility, DiscardRoboSubstitute)):
        return 1 if action.zone == Zone.ACTIVE else min(2 + (action.bench_index or 0), ACTION_TARGET_SLOTS - 1)
    if isinstance(action, (Retreat, ChooseNewActive)):
        return min(2 + action.bench_index, ACTION_TARGET_SLOTS - 1)
    if isinstance(action, (Attack, UseBorrowedAttack)) and action.target_bench_index is not None:
        if _attack_targets_opponent_attack_choice(action, player, card_db):
            # ベンチ位置ではなく相手のワザ選択の流用なので、盤面スロットとしては「対象なし」にする
            # (以前はベンチ位置と誤って解釈され、相手にベンチポケモンが無い場合でも「ベンチN」相当の
            # 特徴量になっていた、2026-08-21発覚)。実際にどのワザを選んだかは別の専用特徴量で表現する。
            return 0
        return min(2 + action.target_bench_index, ACTION_TARGET_SLOTS - 1)
    if isinstance(action, (AcceptTrigger,)) and action.target_bench_index is not None:
        return min(2 + action.target_bench_index, ACTION_TARGET_SLOTS - 1)
    if isinstance(action, (PlaySupporter, PlayItem)) and action.target_bench_index is not None:
        # ボスの指令/プライムキャッチャー等、相手のベンチポケモンを対象に選ぶトレーナーズ。
        # 以前はこの分岐が無く、どのベンチ位置を狙っても常にスロット0(対象なし)扱いになっていた
        # ため、行動特徴量が完全に同一になり学習できていなかった(2026-08-18に発覚)。
        return min(2 + action.target_bench_index, ACTION_TARGET_SLOTS - 1)
    return 0


def _damage_distribution_slot_counts(action: ResolveDamageDistribution, state: GameState | None) -> np.ndarray:
    vec = np.zeros(DAMAGE_DISTRIBUTION_SLOTS, dtype=np.float32)
    dist = state.pending_damage_distribution if state is not None else None
    if dist is None:
        return vec
    # _handle_resolve_damage_distribution(engine/rules_engine.py)と同じ対象の並び:
    # bench_onlyでなければ[バトル場, ベンチ0, ...]、bench_onlyなら[ベンチ0, ...]。
    offset = 1 if not dist.bench_only else 2
    for i, count in enumerate(action.counts):
        slot = offset + i
        if slot < DAMAGE_DISTRIBUTION_SLOTS:
            vec[slot] = min(count / 20.0, 1.0)
    return vec


def _stadium_orientation_self_flag(action: PlayStadium, player: PlayerState, state: GameState | None) -> float:
    if action.orientation_target is None or state is None:
        return 0.0
    actor_index = 0 if player is state.players[0] else 1
    return 1.0 if action.orientation_target == actor_index else 0.0


def encode_action(
    action: Action, player: PlayerState, card_db: CardDatabase, vocab: CardVocab, state: GameState | None = None
) -> ActionFeatures:
    """state: ResolveSearchChoiceの選択カードを特定するために必要(pending_search_choice.card_idsを
    参照する)、ResolveDamageDistributionのダメカン配分先・PlayStadiumの向きを特定するためにも必要。
    呼び出し側で利用可能なら必ず渡すこと(省略するとサーチ/トラッシュの中身選びやダメカン配分・
    パラレルシティの向きの行動特徴量が全て同一になり、その種の選択が一切学習されなくなる)。"""
    vec = np.zeros(ACTION_FEATURE_DIM, dtype=np.float32)
    type_idx = _ACTION_TYPE_INDEX.get(type(action))
    if type_idx is not None:
        vec[type_idx] = 1.0
    slot = _target_slot_index(action, player, card_db)
    vec[NUM_ACTION_TYPES + slot] = 1.0
    damage_dist_offset = NUM_ACTION_TYPES + ACTION_TARGET_SLOTS
    if isinstance(action, ResolveDamageDistribution):
        vec[damage_dist_offset : damage_dist_offset + DAMAGE_DISTRIBUTION_SLOTS] = _damage_distribution_slot_counts(
            action, state
        )
    stadium_orientation_offset = damage_dist_offset + DAMAGE_DISTRIBUTION_SLOTS
    if isinstance(action, PlayStadium):
        vec[stadium_orientation_offset] = _stadium_orientation_self_flag(action, player, state)
    opponent_attack_choice_offset = stadium_orientation_offset + STADIUM_ORIENTATION_FEATURE_DIM
    if (
        isinstance(action, Attack)
        and action.target_bench_index is not None
        and _attack_targets_opponent_attack_choice(action, player, card_db)
    ):
        vec[opponent_attack_choice_offset] = min(action.target_bench_index / 3.0, 1.0)
    mulligan_bonus_draw_offset = opponent_attack_choice_offset + OPPONENT_ATTACK_CHOICE_FEATURE_DIM
    if isinstance(action, ChooseMulliganBonusDrawCount):
        vec[mulligan_bonus_draw_offset] = min(action.count / 7.0, 1.0)
    involved_card_ids = _involved_card_ids(action, player, card_db, state)
    involved_idxs = [vocab.index_of(cid) for cid in involved_card_ids]
    return ActionFeatures(type_and_target=vec, involved_card_idxs=involved_idxs)
