"""scripts/build_era_trainer_ids.py が生成した、effects/era_trainer_specs.py の各キーに当てはまるカードID(手で編集しない)。"""

from __future__ import annotations

IDS: dict[str, tuple[tuple[str, str], ...]] = {
    'iris': (
        ('bw10-101', ''),
        ('bw10-81', ''),
    ),
    'plus_power': (
        ('bw1-96', ''),
    ),
    'master_ball': (
        ('bw10-94', ''),
        ('sv5-153', ''),
    ),
    'scoop_up_cyclone': (
        ('bw10-95', ''),
        ('sv6-162', ''),
        ('sv8pt5-128', ''),
    ),
    'recycle': (
        ('bw2-96', ''),
    ),
    'xtransceiver': (
        ('bw3-96', ''),
    ),
    'devolution_spray': (
        ('bw6-113', ''),
        ('xy10-95', ''),
        ('xy12-76', ''),
    ),
    'gold_potion': (
        ('bw7-140', ''),
    ),
    'ether': (
        ('bw8-121', ''),
    ),
    'scramble_switch': (
        ('bw8-129', ''),
        ('sv8-186', ''),
    ),
    'max_revive': (
        ('g1-65', ''),
        ('xy1-120', ''),
    ),
    'red_card': (
        ('g1-71', ''),
        ('xy1-124', ''),
    ),
    'fiery_torch': (
        ('xy2-89', ''),
    ),
    'trick_shovel': (
        ('xy2-98', ''),
    ),
    'tool_retriever': (
        ('xy3-101', ''),
    ),
    'maintenance': (
        ('g1-64', ''),
        ('xy12-79', ''),
        ('xy3-96', ''),
    ),
    'gym_badge': (
        ('xyp-XY203', ''),
        ('xyp-XY204', ''),
        ('xyp-XY205', ''),
        ('xyp-XY206', ''),
        ('xyp-XY207', ''),
        ('xyp-XY208', ''),
        ('xyp-XY209', ''),
        ('xyp-XY210', ''),
    ),
    'bw_pokemon_catcher': (
        ('bw10-83', ''),
        ('bw2-95', ''),
        ('bw5-111', ''),
    ),
    'fossil_cover': (
        ('bw10-79', ''),
        ('bw3-90', ''),
    ),
    'fossil_plume': (
        ('bw10-82', ''),
        ('bw3-93', ''),
    ),
    'fossil_root': (
        ('bw10-87', ''),
    ),
    'fossil_old_amber': (
        ('bw5-97', ''),
        ('xy10-106', ''),
    ),
    'fossil_jaw': (
        ('xy3-94', ''),
    ),
    'fossil_sail': (
        ('xy3-98', ''),
    ),
    'first_ticket': (
        ('dv1-19', ''),
    ),
    'caitlin': (
        ('bw10-78', ''),
        ('swsh6-132', ''),
        ('swsh6-189', ''),
        ('swsh6-213', ''),
    ),
    'elesa': (
        ('bw11-RC20', ''),
    ),
    'hooligans_jim_cas': (
        ('bw5-95', ''),
    ),
    'hugh': (
        ('bw7-130', ''),
    ),
    'team_plasma_grunt': (
        ('bw8-125', ''),
    ),
    'ghetsis': (
        ('bw9-101', ''),
        ('bw9-115', ''),
    ),
    'cassius': (
        ('xy1-115', ''),
    ),
    'team_flare_grunt': (
        ('g1-73', ''),
        ('g1-73a', ''),
        ('xy1-129', ''),
    ),
    'blacksmith': (
        ('xy2-88', ''),
        ('xy2-88a', ''),
    ),
    'battle_reporter': (
        ('xy3-109', ''),
        ('xy3-88', ''),
    ),
    'fossil_researcher': (
        ('xy3-110', ''),
        ('xy3-92', ''),
    ),
    'karen_shuffle_pokemon': (
        ('xyp-XY177', ''),
        ('xyp-XY177a', ''),
    ),
    'premium_power_pro': (
        ('me1-124', ''),
        ('me1-174', ''),
        ('me2pt5-199', ''),
    ),
    'electropower': (
        ('sm8-172', ''),
        ('sm8-172a', ''),
        ('sm8-232', ''),
    ),
    'gladion_final_battle': (
        ('me5-108', ''),
        ('me5-118', ''),
        ('me5-77', ''),
    ),
    'iron_defender': (
        ('me1-118', ''),
        ('me5-110', ''),
    ),
    'lusamine_prism': (
        ('sm8-182', ''),
    ),
    'lt_surge_bargain': (
        ('me1-120', ''),
        ('me1-170', ''),
        ('me1-185', ''),
    ),
    'lt_surge_strategy': (
        ('sm10-178', ''),
        ('sm115-60', ''),
    ),
    'acerolas_mischief': (
        ('me1-113', ''),
        ('me1-165', ''),
        ('me1-183', ''),
        ('me2pt5-180', ''),
    ),
    'grimsley_move': (
        ('me2-120', ''),
        ('me2-90', ''),
    ),
    'waitress': (
        ('me2pt5-215', ''),
    ),
    'naveen': (
        ('me3-112', ''),
        ('me3-79', ''),
    ),
    'blowtorch': (
        ('me2-117', ''),
        ('me2-86', ''),
    ),
    'energy_swatter': (
        ('me3-73', ''),
    ),
    'great_haul_net': (
        ('me4-78', ''),
    ),
    'misty_vitality': (
        ('me5-111', ''),
        ('me5-80', ''),
    ),
    'anthea_concordia': (
        ('me2pt5-182', ''),
        ('me2pt5-254', ''),
    ),
    'ethans_adventure': (
        ('sv10-165', ''),
        ('sv10-221', ''),
        ('sv10-236', ''),
    ),
    'bother_bot': (
        ('sv10-172', ''),
    ),
    'chip_chip_ice_axe': (
        ('sm10-165', ''),
    ),
    'stadium_nav': (
        ('sm11-208', ''),
    ),
    'tag_switch': (
        ('sm11-209', ''),
        ('sm11-254', ''),
    ),
    'cyrus_prism': (
        ('sm5-120', ''),
    ),
    'tate_liza': (
        ('sm7-148', ''),
        ('sm7-148a', ''),
        ('sm7-166', ''),
    ),
    'strange_timepiece': (
        ('me1-128', ''),
    ),
    'transformation_tome': (
        ('me4-83', ''),
    ),
    'mystery_garden': (
        ('me1-122', ''),
        ('me1-172', ''),
        ('me2pt5-194', ''),
    ),
    'surfing_beach': (
        ('me1-129', ''),
        ('me4-114', ''),
    ),
    'lumiose_city': (
        ('me3-111', ''),
        ('me3-77', ''),
    ),
    'fossil_quarry': (
        ('me5-76', ''),
    ),
    'dizzying_valley': (
        ('me2-88', ''),
    ),
    'nighttime_mine': (
        ('me2pt5-197', ''),
    ),
    'granite_cave': (
        ('sv10-166', ''),
    ),
    'postwick': (
        ('sv9-154', ''),
    ),
    'thunder_mountain': (
        ('sm8-191', ''),
    ),
    'ange_floette': (
        ('me4-75', ''),
    ),
    'light_ball': (
        ('me2pt5-191', ''),
    ),
    'core_memory': (
        ('me3-70', ''),
    ),
    'j_st_cycling_road': (
        ('sv3pt5-157', ''),
    ),
    'j_st_moonlit_hill': (
        ('sv4pt5-81', ''),
    ),
    'j_st_community_center': (
        ('sv6-146', ''),
    ),
    'j_st_jubilife_village': (
        ('swsh10-148', ''),
        ('swsh10-212', ''),
    ),
    'j_st_primordial_altar': (
        ('swsh12-161', ''),
    ),
    'j_st_rose_tower': (
        ('swsh3-169', ''),
    ),
    'j_st_shopping_center': (
        ('swsh7-157', ''),
    ),
    'j_st_stormy_mountains': (
        ('swsh7-161', ''),
        ('swsh7-232', ''),
    ),
    'j_st_tower_of_darkness': (
        ('swsh5-137', ''),
    ),
    'j_st_turffield': (
        ('swsh2-170', ''),
        ('swsh35-68', ''),
        ('swsh7-234', ''),
    ),
    'j_st_magma_basin': (
        ('swsh9-144', ''),
        ('swsh9-185', ''),
    ),
    'tm_crisis_punch': (
        ('sv4pt5-90', ''),
    ),
    'tm_fluorite': (
        ('sv8-188', ''),
    ),
    'earthen_seal_stone': (
        ('swsh12-154', ''),
    ),
    'sky_seal_stone': (
        ('swsh12pt5-143', ''),
    ),
    'tremendous_bomb': (
        ('me5-113', ''),
        ('me5-82', ''),
    ),
    'double_aqua': (
        ('dc1-33', ''),
    ),
    'double_magma': (
        ('dc1-34', ''),
    ),
    'double_dragon': (
        ('xy6-97', ''),
    ),
    'shield_energy': (
        ('xy5-143', ''),
    ),
    'dangerous_energy': (
        ('xy7-82', ''),
    ),
    'flash_energy': (
        ('xy7-83', ''),
    ),
    'burning_energy': (
        ('xy8-151', ''),
    ),
    'bubbly_water_energy': (
        ('me4-84', ''),
    ),
    'nitro_fire_energy': (
        ('me4-86', ''),
    ),
    'shadowy_darkness_energy': (
        ('me5-83', ''),
    ),
    'recycle_energy': (
        ('sm11-212', ''),
        ('sm11-257', ''),
    ),
    'spiky_energy': (
        ('sv9-159', ''),
        ('sv9-190', ''),
    ),
    'eviolite': (
        ('bw3-91', ''),
        ('bw8-122', ''),
    ),
    'rocky_helmet': (
        ('bw3-94', ''),
        ('bw7-133', ''),
        ('bw7-153', ''),
        ('sv1-193', ''),
        ('swsh4-159', ''),
    ),
    'exp_share': (
        ('bw4-87', ''),
        ('dv1-18', ''),
        ('sm1-118', ''),
        ('sv1-174', ''),
        ('swsh5-126', ''),
        ('swsh5-180', ''),
        ('xy5-128', ''),
    ),
    'dark_claw': (
        ('bw5-92', ''),
    ),
    'giant_cape': (
        ('bw6-114', ''),
    ),
    'rescue_scarf': (
        ('bw6-115', ''),
    ),
    'crystal_edge': (
        ('bw7-138', ''),
    ),
    'crystal_wall': (
        ('bw7-139', ''),
    ),
    'victory_piece': (
        ('bw8-130', ''),
    ),
    'reversal_trigger': (
        ('bw10-86', ''),
    ),
    'silver_mirror': (
        ('bw10-89', ''),
    ),
    'team_plasma_badge': (
        ('bw9-104', ''),
    ),
    'life_dew': (
        ('bw9-107', ''),
    ),
    'rock_guard': (
        ('bw9-108', ''),
    ),
    'protection_cube': (
        ('xy2-95', ''),
    ),
    'sparkling_robe': (
        ('xy3-99', ''),
    ),
    'spirit_link': (
        ('xy10-90', 'M Alakazam-EX'),
        ('xy10-91', 'M Altaria-EX'),
        ('xy10-92', 'M Audino-EX'),
        ('xy11-101', 'M Gardevoir-EX'),
        ('xy11-106', 'M Steelix-EX'),
        ('xy12-73', 'M Blastoise-EX'),
        ('xy12-75', 'M Charizard-EX'),
        ('xy12-81', 'M Pidgeot-EX'),
        ('xy12-86', 'M Slowbro-EX'),
        ('xy12-89', 'M Venusaur-EX'),
        ('xy4-100', 'M Manectric-EX'),
        ('xy4-95', 'M Gengar-EX'),
        ('xy5-123', 'M Aggron-EX'),
        ('xy5-130', 'M Gardevoir-EX'),
        ('xy5-131', 'Primal Groudon-EX'),
        ('xy5-132', 'Primal Kyogre-EX'),
        ('xy6-83', 'M Gallade-EX'),
        ('xy6-85', 'M Latios-EX'),
        ('xy6-87', 'M Rayquaza-EX'),
        ('xy7-70', 'M Ampharos-EX'),
        ('xy7-80', 'M Sceptile-EX'),
        ('xy7-81', 'M Tyranitar-EX'),
        ('xy8-139', 'M Glalie-EX'),
        ('xy8-142', 'M Houndoom-EX'),
        ('xy8-144', 'M Mewtwo-EX'),
        ('xy9-101', 'M Gyarados-EX'),
        ('xy9-111', 'M Scizor-EX'),
        ('xyp-XY105', 'M Mawile-EX'),
        ('xyp-XY159', 'M Beedrill-EX'),
        ('xyp-XY169', 'M Garchomp-EX'),
        ('xyp-XY172', 'M Salamence-EX'),
        ('xyp-XY199', 'M Camerupt-EX'),
        ('xyp-XY201', 'M Sharpedo-EX'),
        ('xyp-XY211', 'M Lucario-EX'),
        ('xyp-XY99', 'M Aerodactyl-EX'),
    ),
    'blend_gfpd': (
        ('bw6-117', ''),
    ),
    'blend_wlfm': (
        ('bw6-118', ''),
    ),
    'herbal_energy': (
        ('xy3-103', ''),
    ),
    'darkness_energy_hs': (
        ('hgss3-79', ''),
    ),
    'olympia': (
        ('g1-66', ''),
    ),
    'bent_spoon': (
        ('xy10-93', ''),
    ),
    'energy_pouch': (
        ('xy10-97', ''),
    ),
    'floral_crown': (
        ('g1-RC26', ''),
    ),
    'weakness_policy': (
        ('sm3-126', ''),
        ('xy5-142', ''),
        ('xy5-164', ''),
    ),
    'healing_scarf': (
        ('xy6-84', ''),
    ),
    'wide_lens': (
        ('xy6-95', ''),
    ),
    'heavy_boots': (
        ('xy8-141', ''),
    ),
    'assault_vest': (
        ('xy8-133', ''),
    ),
    'lucky_helmet': (
        ('sv6-158', ''),
        ('xy7-77', ''),
    ),
    'fairy_drop': (
        ('xy10-99', ''),
    ),
    'mega_catcher': (
        ('xy10-104', ''),
    ),
    'maxie_trick': (
        ('xy5-133', ''),
        ('xy5-158', ''),
    ),
    'fossil_helix': (
        ('xy10-102', ''),
    ),
    'fossil_dome': (
        ('xy10-96', ''),
    ),
    'fossil_claw': (
        ('xy11-100', ''),
    ),
    'fossil_armor': (
        ('xy11-98', ''),
    ),
    'all_night_party': (
        ('xy9-96', ''),
    ),
    'chaos_tower': (
        ('xy10-94', ''),
    ),
    'reverse_valley': (
        ('xy9-110', ''),
    ),
    'faded_town': (
        ('xy7-73', ''),
    ),
    'shrine_of_memories': (
        ('xy5-139', ''),
    ),
    'steel_shelter': (
        ('xy4-105', ''),
    ),
    'team_aqua_base': (
        ('dc1-28', ''),
    ),
    'team_magma_base': (
        ('dc1-32', ''),
    ),
    'pokemon_center': (
        ('bw4-90', ''),
    ),
    'twist_mountain': (
        ('bw5-101', ''),
    ),
    'aspertia_city_gym': (
        ('bw7-127', ''),
    ),
    'plasma_frigate': (
        ('bw8-124', ''),
    ),
    'frozen_city': (
        ('bw9-100', ''),
    ),
    'battle_city': (
        ('bwp-BW39', ''),
    ),
    'champions_festival': (
        ('bwp-BW95', ''),
        ('smp-SM148', ''),
        ('smp-SM231', ''),
        ('smp-SM78', ''),
        ('swshp-SWSH296', ''),
        ('xyp-XY176', ''),
        ('xyp-XY27', ''),
        ('xyp-XY91', ''),
    ),
    'tropical_beach': (
        ('bwp-BW28', ''),
        ('bwp-BW50', ''),
    ),
    'shadow_circle': (
        ('xy1-126', ''),
    ),
    'magnetic_storm': (
        ('xy2-91', ''),
    ),
    'training_center': (
        ('xy3-102', ''),
    ),
    'mountain_ring': (
        ('xy3-97', ''),
    ),
    'big_malasada': (
        ('sm1-114', ''),
    ),
    'ilima': (
        ('sm1-121', ''),
        ('sm1-146', ''),
    ),
    'kukui_sm': (
        ('sm1-128', ''),
        ('sm1-148', ''),
    ),
    'rotom_dex': (
        ('sm1-131', ''),
        ('sm1-159', ''),
    ),
    'team_skull_grunt': (
        ('sm1-133', ''),
        ('sm1-149', ''),
    ),
    'timer_ball': (
        ('sm1-134', ''),
    ),
    'devolution_spray_z': (
        ('sm10-166', ''),
    ),
    'dusk_stone': (
        ('sm10-167', ''),
    ),
    'giovannis_exile': (
        ('sm10-174', ''),
        ('sm115-57', ''),
        ('sm115-67', ''),
    ),
    'janine_sm': (
        ('sm10-176', ''),
        ('sm10-210', ''),
    ),
    'molayne': (
        ('sm10-181', ''),
        ('sm10-212', ''),
    ),
    'samson_oak': (
        ('sm10-185', ''),
    ),
    'surprise_box': (
        ('sm10-187', ''),
    ),
    'ultra_forest_kartenvoy': (
        ('sm10-188', ''),
    ),
    'blues_tactics': (
        ('sm11-188', ''),
        ('sm11-231', ''),
    ),
    'bug_catcher_sm': (
        ('sm11-189', ''),
        ('swsh8-226', ''),
    ),
    'channeler': (
        ('sm11-190', ''),
        ('sm11-232', ''),
    ),
    'coach_trainer': (
        ('sm11-192', ''),
        ('sm11-233', ''),
    ),
    'grimsley_sm': (
        ('sm11-199', ''),
        ('sm11-234', ''),
    ),
    'poke_maniac': (
        ('sm11-204', ''),
        ('sm11-236', ''),
    ),
    'blaines_last_stand': (
        ('sm115-52', ''),
        ('sm75-58', ''),
        ('sm75-69', ''),
    ),
    'brocks_training': (
        ('sm115-55', ''),
    ),
    'erikas_hospitality': (
        ('sm115-56', ''),
        ('sm9-140', ''),
        ('sm9-174', ''),
    ),
    'jessie_james': (
        ('sm115-58', ''),
        ('sm115-68', ''),
    ),
    'mistys_water_command': (
        ('sm115-63', ''),
    ),
    'sabrinas_suggestion': (
        ('sm115-65', ''),
        ('sm9-154', ''),
        ('sm9-181', ''),
    ),
    'bellelba_brycen': (
        ('sm12-186', ''),
    ),
    'clay_sm': (
        ('sm12-188', ''),
    ),
    'erika_sm': (
        ('sm12-191', ''),
    ),
    'guzma_hala': (
        ('sm12-193', ''),
        ('sm12-229', ''),
    ),
    'lanas_fishing_rod': (
        ('sm12-195', ''),
        ('sm12-266', ''),
    ),
    'lillies_full_force': (
        ('sm12-196', ''),
        ('sm12-230', ''),
    ),
    'misty_lorelei': (
        ('sm12-199', ''),
    ),
    'ns_resolve': (
        ('sm12-200', ''),
        ('sm12-232', ''),
    ),
    'oaks_setup': (
        ('sm12-201', ''),
        ('sm12-233', ''),
    ),
    'red_blue': (
        ('sm12-202', ''),
        ('sm12-234', ''),
    ),
    'roller_skater': (
        ('sm12-203', ''),
        ('sm12-235', ''),
    ),
    'roxie_sm': (
        ('sm12-205', ''),
    ),
    'will_sm': (
        ('sm12-208', ''),
    ),
    'energy_loto': (
        ('sm2-122', ''),
        ('swsh10-140', ''),
    ),
    'hala_sm': (
        ('sm2-126', ''),
        ('sm2-143', ''),
    ),
    'mallow_sm': (
        ('sm2-127', ''),
        ('sm2-145', ''),
    ),
    'lana_sm': (
        ('sm3-117', ''),
        ('sm5-150', ''),
    ),
    'olivia_sm': (
        ('sm3-119', ''),
        ('sm4-111', ''),
    ),
    'rotom_dex_finder': (
        ('sm3-122', ''),
    ),
    'tormenting_spray': (
        ('sm3-125', ''),
    ),
    'wicke': (
        ('sm3-127', ''),
        ('sm3-147', ''),
    ),
    'plumeria_sm': (
        ('sm3-120', ''),
        ('sm3-145', ''),
    ),
    'damage_mover': (
        ('sm35-58', ''),
    ),
    'pokemon_breeder': (
        ('sm35-63', ''),
        ('sm35-73', ''),
    ),
    'gladion_sm': (
        ('sm4-109', ''),
        ('sm4-95', ''),
    ),
    'peeking_red_card': (
        ('sm4-97', ''),
        ('sm5-169', ''),
    ),
    'gardenia_sm': (
        ('sm5-124', ''),
        ('sm5-149', ''),
    ),
    'looker_sm': (
        ('sm5-126', ''),
        ('sm5-152', ''),
    ),
    'looker_whistle': (
        ('sm5-127', ''),
    ),
    'bonnie': (
        ('sm6-103', ''),
        ('sm6-128', ''),
    ),
    'crasher_wake': (
        ('sm6-104', ''),
        ('sm6-129', ''),
    ),
    'diantha': (
        ('sm6-105', ''),
        ('sm6-130', ''),
    ),
    'eneporter': (
        ('sm6-106', ''),
        ('sm6-142', ''),
    ),
    'fossil_excavation_map': (
        ('sm6-107', ''),
    ),
    'judge_sm': (
        ('me3-76', ''),
        ('sm6-108', ''),
        ('sm8-209', ''),
        ('sv1-176', ''),
        ('sv10-167', ''),
        ('sv10-222', ''),
        ('sv4pt5-228', ''),
        ('swsh12tg-TG25', ''),
        ('swsh8-235', ''),
    ),
    'lysandre_prism': (
        ('sm6-110', ''),
    ),
    'ultra_recon_squad': (
        ('sm6-114', ''),
        ('sm6-131', ''),
    ),
    'apricorn_maker': (
        ('sm7-124', ''),
        ('sm7-161', ''),
    ),
    'beast_ball': (
        ('sm7-125', ''),
    ),
    'bills_maintenance': (
        ('sm7-126', ''),
        ('sm7-162', ''),
    ),
    'copycat_sm': (
        ('sm7-127', ''),
        ('sm7-163', ''),
        ('swsh7-143', ''),
        ('swsh7-200', ''),
        ('swsh7-222', ''),
    ),
    'energy_recycle_system': (
        ('sm7-128', ''),
    ),
    'friend_ball': (
        ('sm7-131', ''),
    ),
    'hiker_sm': (
        ('sm7-133', ''),
        ('sma-SV85', ''),
    ),
    'last_chance_potion': (
        ('sm7-135', ''),
    ),
    'life_herb': (
        ('sm7-136', ''),
        ('sm7-180', ''),
    ),
    'lisia': (
        ('sm7-137', ''),
        ('sm7-164', ''),
    ),
    'lure_ball': (
        ('sm7-138', ''),
    ),
    'masked_royal': (
        ('sm7-139', ''),
    ),
    'pokenav': (
        ('sm7-140', ''),
        ('sm7-181', ''),
    ),
    'tv_reporter': (
        ('sm7-149', ''),
        ('sm7-167', ''),
    ),
    'underground_expedition': (
        ('sm7-150', ''),
        ('sm7-168', ''),
    ),
    'lance_prism': (
        ('sm75-61', ''),
    ),
    'switch_raft': (
        ('sm75-62', ''),
        ('sm75-77', ''),
    ),
    'aether_foundation_employee': (
        ('sm8-168', ''),
        ('sma-SV81', ''),
    ),
    'faba': (
        ('sm8-173', ''),
        ('sm8-208', ''),
    ),
    'kahili': (
        ('sm8-179', ''),
        ('sm8-210', ''),
    ),
    'lost_blender': (
        ('sm8-181', ''),
        ('sm8-233', ''),
    ),
    'moomoo_milk': (
        ('sm8-185', ''),
    ),
    'morty_sm': (
        ('sm8-186', ''),
        ('sm8-212', ''),
    ),
    'net_ball': (
        ('sm8-187', ''),
        ('sm8-187a', ''),
        ('sm8-234', ''),
    ),
    'sightseer': (
        ('sm8-189', ''),
        ('sm8-189a', ''),
    ),
    'wait_and_see_hammer': (
        ('sm8-192', ''),
        ('sm8-236', ''),
    ),
    'whitney_sm': (
        ('sm8-193', ''),
        ('sm8-214', ''),
    ),
    'dangerous_drill': (
        ('sm9-138', ''),
        ('sm9-192', ''),
    ),
    'electrocharger': (
        ('sm9-139', ''),
        ('sm9-193', ''),
    ),
    'ingo_emmet': (
        ('sm9-144', ''),
        ('sm9-176', ''),
    ),
    'jasmine_sm': (
        ('sm9-145', ''),
        ('sm9-177', ''),
    ),
    'judge_whistle': (
        ('sm9-146', ''),
        ('sm9-194', ''),
    ),
    'morgan': (
        ('sm9-149', ''),
        ('sm9-178', ''),
    ),
    'nanu': (
        ('sm9-150', ''),
        ('sm9-179', ''),
    ),
    'nita': (
        ('sm9-151', ''),
        ('sm9-180', ''),
    ),
    'return_label': (
        ('sm9-153', ''),
    ),
    'sabrina_brycen': (
        ('smp-SM246', ''),
    ),
    'cynthia_caitlin': (
        ('sm12-189', ''),
        ('sm12-228', ''),
    ),
    'mallow_lana': (
        ('sm12-198', ''),
        ('sm12-231', ''),
    ),
    'metal_frying_pan': (
        ('sm6-112', ''),
        ('sm6-112a', ''),
        ('sm6-144', ''),
    ),
    'metal_core_barrier': (
        ('sm10-180', ''),
        ('sm10-232', ''),
    ),
    'ancient_crystal': (
        ('sm5-118', ''),
    ),
    'giant_bomb': (
        ('sm11-196', ''),
        ('sm11-251', ''),
    ),
    'dragon_talon': (
        ('sm75-59', ''),
        ('sm75-75', ''),
    ),
    'poison_barb': (
        ('sm1-124', ''),
    ),
    'ear_ringing_bell': (
        ('sm11-194', ''),
    ),
    'bodybuilding_dumbbells': (
        ('sm3-113', ''),
        ('sm3-161', ''),
    ),
    'island_challenge_amulet': (
        ('sm12-194', ''),
        ('sm12-265', ''),
    ),
    'buff_padding': (
        ('sm9-136', ''),
    ),
    'hustle_belt': (
        ('sm7-134', ''),
        ('sm7-179', ''),
    ),
    'beastite': (
        ('sm12-185', ''),
    ),
    'beast_bringer': (
        ('sm10-164', ''),
        ('sm10-229', ''),
    ),
    'counter_gain': (
        ('sm8-170', ''),
        ('sm8-230', ''),
        ('sv8-169', ''),
        ('sv8-249', ''),
    ),
    'u_turn_board': (
        ('sm11-211', ''),
        ('sm11-255', ''),
    ),
    'dashing_pouch': (
        ('sm4-92', ''),
    ),
    'spell_tag': (
        ('sm8-190', ''),
        ('sm8-235', ''),
    ),
    'wishful_baton': (
        ('sm3-128', ''),
        ('sm4-121', ''),
    ),
    'stealthy_hood': (
        ('sm10-186', ''),
    ),
    'fairy_charm_grass': (
        ('sm8-174', ''),
    ),
    'fairy_charm_psychic': (
        ('sm8-175', ''),
    ),
    'fairy_charm_fighting': (
        ('sm8-176', ''),
    ),
    'fairy_charm_dragon': (
        ('sm8-177', ''),
    ),
    'fairy_charm_lightning': (
        ('sm10-172', ''),
    ),
    'fairy_charm_ub': (
        ('sm9-142', ''),
    ),
    'fairy_charm_ability': (
        ('sm10-171', ''),
    ),
    'memory_fighting': (
        ('sm4-94', ''),
    ),
    'memory_psychic': (
        ('sm4-98', ''),
    ),
    'memory_electric': (
        ('sm5-121', ''),
    ),
    'memory_fire': (
        ('sm5-123', ''),
    ),
    'memory_grass': (
        ('sm9-143', ''),
    ),
    'memory_water': (
        ('sm9-157', ''),
    ),
    'aether_paradise': (
        ('sm2-116', ''),
        ('sma-SV87', ''),
    ),
    'altar_moone': (
        ('sm2-117', ''),
    ),
    'altar_sunne': (
        ('sm2-118', ''),
    ),
    'mount_lanakila': (
        ('sm3-118', ''),
    ),
    'po_town': (
        ('sm3-121', ''),
    ),
    'devoured_field': (
        ('sm4-93', ''),
    ),
    'sea_of_nothingness': (
        ('sm4-99', ''),
    ),
    'mt_coronet': (
        ('sm5-130', ''),
        ('sma-SV89', ''),
    ),
    'sky_pillar': (
        ('sm7-144', ''),
    ),
    'wela_volcano_park': (
        ('sm75-63', ''),
    ),
    'life_forest': (
        ('sm8-180', ''),
    ),
    'black_market': (
        ('sm9-134', ''),
    ),
    'lavender_town': (
        ('sm9-147', ''),
    ),
    'wondrous_labyrinth': (
        ('sm9-158', ''),
    ),
    'dust_island': (
        ('sm10-168', ''),
    ),
    'blizzard_town': (
        ('sm11-187', ''),
    ),
    'dark_city': (
        ('sm11-193', ''),
    ),
    'pokemon_research_lab': (
        ('sm11-205', ''),
    ),
    'slumbering_forest': (
        ('sm11-207', ''),
    ),
    'brocks_gym': (
        ('sm115-54', ''),
    ),
    'mistys_gym': (
        ('sm115-61', ''),
    ),
    'chaotic_swell': (
        ('sm12-187', ''),
    ),
    'triple_acceleration': (
        ('sm10-190', ''),
        ('sm10-234', ''),
    ),
    'weakness_guard_energy': (
        ('sm11-213', ''),
        ('sm11-258', ''),
    ),
    'draw_energy': (
        ('sm12-209', ''),
        ('sm12-271', ''),
    ),
    'warp_energy_sm': (
        ('dp7-95', ''),
        ('sm35-70', ''),
        ('sm4-123', ''),
    ),
    'counter_energy': (
        ('sm4-100', ''),
        ('sm4-122', ''),
    ),
    'super_boost_energy': (
        ('sm5-136', ''),
    ),
    'unit_energy_gfw': (
        ('sm5-137', ''),
        ('sm5-170', ''),
    ),
    'unit_energy_fdf': (
        ('sm6-118', ''),
        ('sm6-146', ''),
    ),
    'memory_energy': (
        ('sm8-194', ''),
    ),
    'rainbow_brush': (
        ('sm7-141', ''),
        ('sm7-182', ''),
    ),
    'blaines_quiz_show': (
        ('sm11-186', ''),
    ),
    'j_accompanying_flute': (
        ('sv6-142', ''),
    ),
    'j_arc_phone': (
        ('swsh11-152', ''),
    ),
    'j_boost_shake': (
        ('swsh7-142', ''),
        ('swsh7-229', ''),
    ),
    'j_capturing_aroma': (
        ('swsh12-153', ''),
    ),
    'j_chill_teaser': (
        ('sv8-166', ''),
    ),
    'j_damage_pump': (
        ('swsh11-156', ''),
    ),
    'j_deduction_kit': (
        ('sv8-171', ''),
    ),
    'j_delivery_drone': (
        ('sv2-178', ''),
    ),
    'j_dragon_elixir': (
        ('sv8-172', ''),
    ),
    'j_nugget': (
        ('swsh2-162', ''),
    ),
    'j_quad_stone': (
        ('swsh12-163', ''),
    ),
    'j_missing_clover': (
        ('sm5-129', ''),
        ('sm5-168', ''),
    ),
    'j_drone_rotom': (
        ('swsh4-151', ''),
    ),
    'j_egg_incubator': (
        ('pgo-66', ''),
        ('pgo-87', ''),
    ),
    'j_energy_recycler': (
        ('swsh5-124', ''),
    ),
    'j_expedition_uniform': (
        ('swsh6-137', ''),
    ),
    'j_familiar_bell': (
        ('swsh3-161', ''),
    ),
    'j_fan_of_waves': (
        ('swsh5-127', ''),
        ('swsh6-226', ''),
    ),
    'j_full_heal': (
        ('swsh2-159', ''),
    ),
    'j_grabber': (
        ('sv3pt5-162', ''),
    ),
    'j_gutsy_pickaxe': (
        ('swsh10-145', ''),
    ),
    'j_hand_trimmer': (
        ('sv5-150', ''),
    ),
    'j_hyper_potion': (
        ('swsh1-166', ''),
        ('swsh35-54', ''),
    ),
    'j_love_ball': (
        ('sv6-156', ''),
    ),
    'j_lucky_ice_pop': (
        ('swsh7-150', ''),
    ),
    'j_lure_module': (
        ('pgo-67', ''),
        ('pgo-88', ''),
    ),
    'j_meddling_memo': (
        ('sv8-181', ''),
    ),
    'j_megaton_blower': (
        ('sv8-182', ''),
    ),
    'j_moomoo_cheese': (
        ('swsh4-156', ''),
    ),
    'j_ogres_mask': (
        ('sv6-159', ''),
        ('sv8pt5-118', ''),
    ),
    'j_old_pc': (
        ('swsh3-164', ''),
    ),
    'j_picnic_basket': (
        ('sv1-184', ''),
    ),
    'j_poke_ball_coin': (
        ('swshp-SWSH146', ''),
    ),
    'j_poke_vital_a': (
        ('sv6pt5-62', ''),
    ),
    'j_prime_catcher': (
        ('sv5-157', ''),
        ('sv8pt5-119', ''),
    ),
    'j_reboot_pod': (
        ('sv5-158', ''),
    ),
    'j_rescue_carrier': (
        ('swsh12pt5-142', ''),
        ('swsh7-154', ''),
    ),
    'j_rotom_phone': (
        ('swsh35-64', ''),
    ),
    'j_spicy_curry': (
        ('swsh10-151', ''),
    ),
    'j_suspicious_food_tin': (
        ('swsh35-66', ''),
        ('swsh35-80', ''),
    ),
    'j_sweet_honey': (
        ('swsh10-153', ''),
    ),
    'j_switching_cups': (
        ('swsh7-162', ''),
    ),
    'j_team_yell_towel': (
        ('swsh45-63', ''),
    ),
    'j_toy_catcher': (
        ('swsh7-163', ''),
        ('swsh7-233', ''),
    ),
    'j_turbo_patch': (
        ('swsh3-172', ''),
        ('swsh3-200', ''),
    ),
    'j_urn_of_vitality': (
        ('swsh5-139', ''),
        ('swsh6-229', ''),
    ),
    'j_yell_horn': (
        ('swsh3-173', ''),
    ),
    'j_acerola': (
        ('swsh9-129', ''),
        ('swsh9tg-TG24', ''),
    ),
    'j_agatha': (
        ('swsh6-129', ''),
        ('swsh6-186', ''),
        ('swsh6-210', ''),
    ),
    'j_allister': (
        ('swsh10tg-TG24', ''),
        ('swsh4-146', ''),
        ('swsh4-179', ''),
        ('swsh4-192', ''),
    ),
    'j_amarys': (
        ('sv8pt5-132', ''),
        ('sv8pt5-170', ''),
        ('sv8pt5-93', ''),
    ),
    'j_aroma_lady': (
        ('swsh7-141', ''),
        ('swsh7-199', ''),
        ('swsh7-221', ''),
    ),
    'j_avery': (
        ('swsh6-130', ''),
        ('swsh6-187', ''),
        ('swsh6-211', ''),
    ),
    'j_ball_guy': (
        ('swsh45-57', ''),
        ('swsh45-65', ''),
    ),
    'j_bea': (
        ('swsh10tg-TG25', ''),
        ('swsh12pt5-123', ''),
        ('swsh4-147', ''),
        ('swsh4-180', ''),
        ('swsh4-193', ''),
    ),
    'j_bianca': (
        ('sv5-142', ''),
        ('sv5-197', ''),
        ('sv5-209', ''),
    ),
    'j_billy_onare': (
        ('sv9-142', ''),
    ),
    'j_bird_keeper': (
        ('swsh3-159', ''),
        ('swsh45-66', ''),
    ),
    'j_blanche': (
        ('pgo-64', ''),
        ('pgo-82', ''),
        ('swshp-SWSH227', ''),
    ),
    'j_candela': (
        ('pgo-65', ''),
        ('pgo-83', ''),
        ('swshp-SWSH228', ''),
    ),
    'j_spark': (
        ('pgo-70', ''),
        ('pgo-85', ''),
        ('swshp-SWSH226', ''),
    ),
    'j_brassius': (
        ('sv3-187', ''),
        ('sv8pt5-135', ''),
    ),
    'j_cafe_master': (
        ('swsh9-133', ''),
        ('swsh9tg-TG25', ''),
    ),
    'j_caretaker': (
        ('sv6-144', ''),
        ('sv6-203', ''),
    ),
    'j_cheren': (
        ('swsh12pt5gg-GG58', ''),
        ('swsh9-134', ''),
        ('swsh9-168', ''),
        ('swsh9-177', ''),
    ),
    'j_cheryl': (
        ('swsh5-123', ''),
        ('swsh5-159', ''),
        ('swsh5-173', ''),
    ),
    'j_choy': (
        ('swsh10-137', ''),
        ('swsh10-182', ''),
        ('swsh10-200', ''),
    ),
    'j_clive': (
        ('sv4pt5-227', ''),
        ('sv4pt5-236', ''),
        ('sv4pt5-78', ''),
    ),
    'j_cyllene': (
        ('swsh10-138', ''),
        ('swsh10-183', ''),
        ('swsh10-201', ''),
    ),
    'j_daisy': (
        ('sv3pt5-158', ''),
        ('sv3pt5-195', ''),
    ),
    'j_dendra': (
        ('sv2-179', ''),
        ('sv2-250', ''),
        ('sv2-266', ''),
    ),
    'j_digging_duo': (
        ('swsh12pt5-126', ''),
    ),
    'j_drasna': (
        ('sv8-173', ''),
        ('sv8-231', ''),
    ),
    'j_drayton': (
        ('sv8-174', ''),
        ('sv8-232', ''),
        ('sv8-244', ''),
        ('sv8pt5-172', ''),
    ),
    'j_eri': (
        ('sv5-146', ''),
        ('sv5-199', ''),
        ('sv5-210', ''),
        ('sv8pt5-136', ''),
    ),
    'j_erikas_invitation': (
        ('sv3pt5-160', ''),
        ('sv3pt5-196', ''),
        ('sv3pt5-203', ''),
    ),
    'j_fantina': (
        ('swsh11-157', ''),
        ('swsh11-191', ''),
        ('swsh11-206', ''),
    ),
    'j_flannery': (
        ('swsh6-139', ''),
        ('swsh6-191', ''),
        ('swsh6-215', ''),
    ),
    'j_furisode_girl': (
        ('swsh12-157', ''),
        ('swsh12-190', ''),
        ('swsh12-205', ''),
    ),
    'j_gardenias_vigor': (
        ('swsh10-143', ''),
        ('swsh10-184', ''),
        ('swsh10-202', ''),
        ('swsh12pt5gg-GG61', ''),
    ),
    'j_geeta': (
        ('sv3-188', ''),
        ('sv3-218', ''),
        ('sv3-226', ''),
    ),
    'j_giacomo': (
        ('sv2-182', ''),
        ('sv2-252', ''),
        ('sv2-267', ''),
        ('sv8pt5-138', ''),
    ),
    'j_honey': (
        ('swsh6-142', ''),
        ('swsh6-192', ''),
    ),
    'j_jasmines_gaze': (
        ('sv8-178', ''),
        ('sv8-233', ''),
        ('sv8-245', ''),
    ),
    'j_kamado': (
        ('swsh10-149', ''),
        ('swsh10-187', ''),
        ('swsh10-205', ''),
    ),
    'j_karens_conviction': (
        ('swsh6-144', ''),
        ('swsh6-193', ''),
        ('swsh6-216', ''),
    ),
    'j_klara': (
        ('swsh6-145', ''),
        ('swsh6-194', ''),
        ('swsh6-217', ''),
        ('swshp-SWSH302', ''),
    ),
    'j_kofu': (
        ('sv7-138', ''),
        ('sv7-165', ''),
    ),
    'j_larry': (
        ('sv4-165', ''),
        ('sv4-235', ''),
    ),
    'j_larrys_skill': (
        ('sv8pt5-115', ''),
        ('sv8pt5-139', ''),
    ),
    'j_leon': (
        ('swsh12pt5-134', ''),
        ('swsh4-154', ''),
        ('swsh4-182', ''),
        ('swsh4-195', ''),
    ),
    'j_lisias_appeal': (
        ('sv8-179', ''),
        ('sv8-234', ''),
        ('sv8-246', ''),
    ),
    'j_lucian': (
        ('sv6-157', ''),
        ('sv6-208', ''),
    ),
    'j_mela': (
        ('sv4-167', ''),
        ('sv4-236', ''),
        ('sv4-254', ''),
        ('sv8pt5-140', ''),
    ),
    'j_milo': (
        ('swsh10tg-TG27', ''),
        ('swsh2-161', ''),
        ('swsh2-190', ''),
        ('swsh2-201', ''),
        ('swsh35-57', ''),
    ),
    'j_miriam': (
        ('sv1-179', ''),
        ('sv1-238', ''),
        ('sv1-251', ''),
    ),
    'j_miss_fortune_sisters': (
        ('swsh11-164', ''),
        ('swsh11-194', ''),
        ('swsh11-209', ''),
    ),
    'j_mortys_conviction': (
        ('sv5-155', ''),
        ('sv5-201', ''),
        ('sv5-211', ''),
    ),
    'j_oleana': (
        ('swsh2-163', ''),
        ('swsh2-191', ''),
        ('swsh2-202', ''),
    ),
    'j_opal': (
        ('swsh11tg-TG28', ''),
        ('swsh4-158', ''),
        ('swsh4-184', ''),
        ('swsh4-197', ''),
    ),
    'j_ortega': (
        ('sv3-190', ''),
        ('sv3-219', ''),
        ('sv8pt5-141', ''),
    ),
    'j_paldean_student': (
        ('sv4pt5-230', ''),
        ('sv4pt5-231', ''),
        ('sv4pt5-85', ''),
        ('sv4pt5-86', ''),
    ),
    'j_peonia': (
        ('swsh6-149', ''),
        ('swsh6-196', ''),
        ('swsh6-219', ''),
    ),
    'j_peony': (
        ('swsh6-150', ''),
        ('swsh6-197', ''),
        ('swsh6-220', ''),
    ),
    'j_perrin': (
        ('sv6-160', ''),
        ('sv6-209', ''),
        ('sv6-220', ''),
    ),
    'j_phoebe': (
        ('swsh5-130', ''),
        ('swsh5-161', ''),
        ('swsh5-175', ''),
    ),
    'j_breeders_nurturing': (
        ('swsh3-166', ''),
        ('swsh3-188', ''),
        ('swsh3-195', ''),
    ),
    'j_poppy': (
        ('sv3-193', ''),
        ('sv3-220', ''),
        ('sv3-227', ''),
    ),
    'j_burnet': (
        ('swsh12tg-TG26', ''),
        ('swshp-SWSH167', ''),
    ),
    'j_laventon': (
        ('swsh12-162', ''),
    ),
    'j_raifort': (
        ('sv6-161', ''),
        ('sv8pt5-142', ''),
    ),
    'j_rapid_strike_mustard': (
        ('swsh5-132', ''),
        ('swsh5-162', ''),
        ('swsh5-176', ''),
        ('swsh9tg-TG27', ''),
    ),
    'j_single_strike_mustard': (
        ('swsh5-134', ''),
        ('swsh5-163', ''),
        ('swsh5-177', ''),
        ('swsh9tg-TG28', ''),
    ),
    'j_rika': (
        ('sv4-172', ''),
        ('sv4-241', ''),
        ('sv4-258', ''),
    ),
    'j_riley': (
        ('swsh11-166', ''),
    ),
    'j_rose': (
        ('swsh3-168', ''),
        ('swsh3-189', ''),
        ('swsh3-196', ''),
        ('swsh45-71', ''),
    ),
    'j_roseannes_backup': (
        ('swsh9-148', ''),
        ('swsh9-172', ''),
        ('swsh9-180', ''),
    ),
    'j_saguaro': (
        ('sv2-187', ''),
        ('sv2-255', ''),
        ('sv2-270', ''),
    ),
    'j_salvatore': (
        ('sv5-160', ''),
        ('sv5-202', ''),
        ('sv5-212', ''),
    ),
    'j_serena': (
        ('swsh12-164', ''),
        ('swsh12-193', ''),
        ('swsh12-207', ''),
    ),
    'j_sidney': (
        ('swsh8-241', ''),
        ('swsh8-264', ''),
        ('swsh8-279', ''),
    ),
    'j_siebold': (
        ('swsh6-153', ''),
        ('swsh6-198', ''),
        ('swsh6-221', ''),
    ),
    'j_sonia': (
        ('swsh2-167', ''),
        ('swsh2-192', ''),
        ('swsh2-203', ''),
        ('swsh35-65', ''),
    ),
    'j_team_star_grunt': (
        ('sv1-195', ''),
        ('sv1-242', ''),
        ('sv3-195', ''),
    ),
    'j_team_yell_grunt': (
        ('swsh1-184', ''),
        ('swsh1-202', ''),
        ('swsh1-210', ''),
        ('swsh35-67', ''),
    ),
    'j_team_yells_cheer': (
        ('swsh9-149', ''),
    ),
    'j_thorton': (
        ('swsh11-167', ''),
        ('swsh11-195', ''),
        ('swsh11-210', ''),
    ),
    'j_volo': (
        ('swsh11-169', ''),
        ('swsh11-196', ''),
        ('swsh11-211', ''),
        ('swsh12pt5-151', ''),
    ),
    'j_wallace': (
        ('swsh12-166', ''),
        ('swsh12-194', ''),
        ('swsh12-208', ''),
    ),
    'j_zisu': (
        ('swsh10-159', ''),
        ('swsh10-189', ''),
        ('swsh10-207', ''),
    ),
    'j_marnies_pride': (
        ('swsh9-145', ''),
        ('swsh9-171', ''),
    ),
    'final_wish': (
        ('bw8-34', ''),
    ),
    'leap_through_time': (
        ('xyp-XY93', ''),
    ),
    'bright_veil': (
        ('bw8-104', ''),
    ),
    'stance_change': (
        ('swsh5-107', ''),
        ('swsh5-108', ''),
        ('xy1-85', ''),
        ('xy1-86', ''),
    ),
    'transform_bw7': (
        ('bw7-108', ''),
    ),
    'busybody': (
        ('bw7-126', ''),
    ),
    'heal_block': (
        ('bw4-76', ''),
        ('sm3-68', ''),
    ),
}
