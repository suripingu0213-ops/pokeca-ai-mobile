"""scripts/generate_abilities.py が英語原文から自動生成した特性の効果(手で編集しない。再生成で上書きされる)。

文面が完全に一致したパターンだけを登録している。effects/registry.py・effects/passives.pyが、手書きの登録が無い特性だけ取り込む。
"""

from __future__ import annotations

from effects.primitives import (
    ApplyScopedDamageImmunityToSelf,
    ApplyShieldToSelf,
    AttachEnergyFromDiscardToSelf,
    AttachEnergyFromHandToChosenOwnPokemon,
    ChooseOwnPokemonThenMoveOneBasicEnergyToAnother,
    ClearActiveStatusConditions,
    ClearOwnStatusConditions,
    DamageCounterOnChosenOpponentPokemon,
    DamageCounterOnDefender,
    DevolveAllOpponentEvolvedPokemon,
    DiscardAllOpponentTools,
    DiscardHandCostThenRetrieveEnergyExcludingDiscarded,
    DiscardHandThenDraw,
    DiscardOpponentActiveEnergy,
    DiscardOpponentActiveSpecialEnergy,
    DiscardOpponentActiveTool,
    DiscardOwnEnergy,
    DiscardStadiumInPlay,
    DiscardTopNAttachEnergyFound,
    DiscardTopOfOpponentDeck,
    DiscardTopOfOwnDeck,
    DistributeDamageCountersFreely,
    Draw,
    DrawBonusIfActive,
    DrawUpTo,
    EndTurnAfterThisAbility,
    FlipCoinThen,
    ForceOpponentSwitchChosenBench,
    ForceOpponentSwitchOpponentChooses,
    HealAllOwnPokemon,
    HealAllOwnPokemonOfType,
    HealOwnActiveFixed,
    HealSelf,
    HealTarget,
    IfLastAttachSucceeded,
    InflictHeavyPoison,
    InflictStatusOnDefender,
    InstantEvolveAnyOwnPokemonFromDeck,
    InstantEvolveSelfFromDeck,
    LookTopCardMayDiscard,
    LookTopNKeepMRestToDiscard,
    LookTopNReorderOnTop,
    MayDiscardHandCardThenDraw,
    MoveChosenBenchEnergyToActive,
    MoveChosenOwnFireEnergyToSelf,
    MoveEnergyOnOpponentSide,
    OpponentDiscardHandDownTo,
    OpponentHandToBottomOfDeckThenDraw,
    OpponentShuffleHandDrawByPrizes,
    OpponentShuffleHandThenDrawFixed,
    RandomOpponentHandCardToDeck,
    RemoveOneActiveStatusCondition,
    ReturnOwnToolToHand,
    ReturnSelfToHandUnconditional,
    RevealOpponentHand,
    RevealOpponentHandOnly,
    RevealOpponentHandThenDiscardChosen,
    SearchDeckAndAttachEnergy,
    SearchDeckAnyCardToHand,
    SearchDeckByCriterionToHand,
    SearchDeckForBasicEnergyAttachFreely,
    SearchDeckForBasicEnergyToHand,
    SearchDeckForBasicPokemonToBench,
    SearchDeckForNamedPokemonToBench,
    SearchDeckForPokemonToHand,
    SearchDeckForSubtypePokemonToHand,
    SearchDeckMultiCriteria,
    SearchDeckToTopOfDeck,
    SearchDiscardAnyCardToHand,
    SearchDiscardForItemToHand,
    SearchDiscardForSupporterToHand,
    SelfDamage,
    ShuffleHandIntoDeckThenDraw,
    ShuffleSelfIntoDeck,
    SwitchActiveWithBench,
    SwitchSelfFromBenchToActive,
)
from effects.era_abilities import (
    AbilityGate,
    AttachDiscardEnergyToSelfPerOpponentPrizeTaken,
    DiscardAbilityDestination,
    DiscardFromHandBasicEnergyAsCost,
    GrantTypeAttackBonusThisTurn,
    InflictStatusOnOwnActive,
    KnockOutSelfEffect,
    LookTopNTakeOneRestOnTop,
    MarkAbilityNameUsed,
    PickPokemonThen,
    SearchDeckForTeamPlasmaCardToHand,
    SwapHandCardWithDeckTop,
    TeleportRoomEffect,
    TriggerGateAttachedEnergyNamed,
)
from effects.era_attacks_h import (
    SearchDiscardByCriterionToHand,
)
from effects.era_attacks_i import (
    SearchByCriterionToBench,
)
from effects.era_attacks_k import (
    DrawMoreIfSelfActive,
    DrawUntilHandEqualsCount,
    HealAllEvolutionsDiscardEnergy,
    InflictStatusOnBothActive,
    MillTopThenAttachEnergy,
    MoveEnergyToSelfFromOthers,
    SearchDeckPutOnTop,
    ShuffleHandToBottomThenDraw,
)
from effects.era_primitives import (
    DamageCountersOnEachOpponentPokemon,
    DiscardOwnHandBasicEnergyOfChoiceThenDraw,
    OpponentDraws,
)
from effects.era_primitives_b import (
    AttachEnergyGeneric,
    LookOpponentDeckTopReorder,
    MoveEnergyGeneric,
)
from effects.era_primitives_c import (
    MoveOneDamageCounterFromOwnToOpponent,
    PutDiscardCardOnTopOfDeck,
    SearchDeckForNamedCardToHand,
)
from effects.era_primitives_e import (
    MoveDamageCountersFreely,
)
from effects.era_primitives_f import (
    ChooseOneEffectBranch,
    PutOpponentHandBasicsOnTheirBench,
    SearchDiscardForNamedCardsToHand,
)
from effects.era_primitives_g import (
    AttachDiscardCardsToSelf,
    DiscardHandCardAsCost,
    EvolveSelfFromHand,
    PoisonBothActiveExceptType,
    SearchDeckPokemonToBench,
    SearchDiscardPokemonFiltered,
)
from effects.era_trainers_i import (
    DiscardMatchingFromHand,
    LookTopNTake,
    MoveDamageCounters,
)

GENERATED_PASSIVES: dict[str, tuple] = {
    'bw1-32': (
        ('Shell Armor', 'damage_reduction', {'amount': 20}),
    ),
    'bw1-6': (
        ('Royal Heal', 'between_turns_heal', {'amount': 10, 'scope': 'team'}),
    ),
    'bw10-23': (
        ('Cursed Glare', 'lock_opponent_special_energy_attach_while_active', {}),
    ),
    'bw10-35': (
        ('Drifting Balloon', 'attack_cost_reduction_per_opp_subtype', {'subtype': 'Team Plasma', 'amount_per': 1}),
    ),
    'bw10-37': (
        ('Mental Shroud', 'team_no_weakness', {'requires_names': ['Uxie', 'Azelf']}),
    ),
    'bw10-49': (
        ('Badge of Discipline', 'team_ignore_resistance', {'attacker_type': 'Fighting'}),
    ),
    'bw11-102': (
        ('Overflow', 'bonus_prize_on_ko', {'amount': 1}),
    ),
    'bw11-105': (
        ('Smooth Coat', 'coin_prevent', {}),
    ),
    'bw11-106': (
        ('Rough Skin', 'retaliate_counters', {'counters': 2}),
    ),
    'bw11-12': (
        ('Leaf Tailor', 'team_no_weakness', {'requires_energy': True}),
    ),
    'bw11-39': (
        ('Shell Armor', 'damage_reduction', {'amount': 20}),
    ),
    'bw11-66': (
        ('Safeguard', 'immune_from_attackers_with_subtype', {'subtype': 'EX'}),
    ),
    'bw11-72': (
        ('Magic Room', 'lock_opponent_items_while_active', {}),
    ),
    'bw11-8': (
        ('Royal Heal', 'between_turns_heal', {'amount': 10, 'scope': 'team'}),
    ),
    'bw11-80': (
        ('Reflexive Retaliation', 'retaliate_counters', {'counters': 2}),
    ),
    'bw11-87': (
        ('Sealing Scream', 'ace_spec_lock', {}),
    ),
    'bw11-RC19': (
        ('Smooth Coat', 'coin_prevent', {}),
    ),
    'bw11-RC24': (
        ('Versatile', 'borrow_attacks', {'sources': 'any_in_play'}),
    ),
    'bw11-RC3': (
        ('Royal Garden', 'no_retreat_cost', {'if_energy': 'Grass'}),
    ),
    'bw2-47': (
        ('Magic Room', 'lock_opponent_items_while_active', {}),
    ),
    'bw3-26': (
        ('Solid Rock', 'coin_reduce', {'amount': 50}),
    ),
    'bw3-3': (
        ('Leaf Tailor', 'team_no_weakness', {'requires_energy': True}),
    ),
    'bw3-31': (
        ('Cursed Body', 'retaliate_status', {'statuses': ['confused']}),
    ),
    'bw3-47': (
        ('Durable Body', 'survive_coin', {}),
    ),
    'bw3-64': (
        ('Craftsmanship', 'self_hp_per_energy', {'energy_type': 'Fighting', 'amount': 20}),
    ),
    'bw3-67': (
        ('Ancient Power', 'no_evolve_for_both', {}),
    ),
    'bw3-79': (
        ('Dark Aura', 'energy_is_type', {'type': 'Darkness'}),
    ),
    'bw3-89': (
        ('Rough Skin', 'retaliate_counters', {'counters': 2}),
    ),
    'bw4-103': (
        ('Dark Aura', 'energy_is_type', {'type': 'Darkness'}),
    ),
    'bw4-12': (
        ('Blazing Mane', 'retaliate_status', {'statuses': ['burned']}),
    ),
    'bw4-57': (
        ('Psychic Mirage', 'team_energy_double', {'energy_type': 'Psychic', 'pokemon_type': 'Psychic'}),
    ),
    'bw4-64': (
        ('Reflexive Retaliation', 'retaliate_counters', {'counters': 2}),
    ),
    'bw4-85': (
        ('Smooth Coat', 'coin_prevent', {}),
    ),
    'bw5-107': (
        ('Dark Cloak', 'team_no_retreat_if_energy', {'energy_type': 'Darkness'}),
    ),
    'bw5-109': (
        ('Psychic Mirage', 'team_energy_double', {'energy_type': 'Psychic', 'pokemon_type': 'Psychic'}),
    ),
    'bw5-110': (
        ('Ancient Power', 'no_evolve_for_both', {}),
    ),
    'bw5-22': (
        ('Scorching Scales', 'burn_counters', {'counters': 4}),
    ),
    'bw5-24': (
        ('Airhead', 'cant_attack_if_own_prizes_in', {'values': [2, 4, 6]}),
    ),
    'bw5-48': (
        ('Solar Revelation', 'team_attack_effect_immune_if_energy', {}),
    ),
    'bw5-53': (
        ('Ancient Scream', 'team_attack_bonus', {'amount': 10}),
    ),
    'bw5-63': (
        ('Dark Cloak', 'team_no_retreat_if_energy', {'energy_type': 'Darkness'}),
    ),
    'bw6-103': (
        ('Unobservant', 'cant_attack_if_opp_active_basic', {}),
    ),
    'bw6-110': (
        ('Bouffer', 'damage_reduction', {'amount': 20}),
    ),
    'bw6-120': (
        ('Versatile', 'borrow_attacks', {'sources': 'any_in_play'}),
    ),
    'bw6-125': (
        ('Royal Heal', 'between_turns_heal', {'amount': 10, 'scope': 'team'}),
    ),
    'bw6-40': (
        ('Electromagnetic Wall', 'opp_attach_counters_while_active', {'counters': 3}),
    ),
    'bw6-46': (
        ('Versatile', 'borrow_attacks', {'sources': 'any_in_play'}),
    ),
    'bw6-48': (
        ('Empty Shell', 'ko_no_prize', {}),
    ),
    'bw6-52': (
        ('Safeguard', 'immune_from_attackers_with_subtype', {'subtype': 'EX'}),
    ),
    'bw6-54': (
        ('Garbotoxin', 'garbotoxin', {}),
    ),
    'bw6-84': (
        ('Fight Song', 'team_attack_bonus', {'attacker_type': 'Dragon', 'amount': 20}),
    ),
    'bw7-122': (
        ('Sentinel', 'lock_opponent_supporters_while_active', {}),
    ),
    'bw7-141': (
        ('Time Recall', 'team_borrow_previous_evolutions', {}),
    ),
    'bw7-143': (
        ('Sparkling Particles', 'between_turns_heal', {'amount': 10, 'scope': 'self'}),
    ),
    'bw7-152': (
        ('Fight Song', 'team_attack_bonus', {'attacker_type': 'Dragon', 'amount': 20}),
    ),
    'bw7-29': (
        ('Shell Shield', 'bench_damage_immune', {}),
    ),
    'bw7-3': (
        ('Allergy Panic', 'weakness_x4_all', {}),
    ),
    'bw7-45': (
        ('Stickiness', 'opp_retreat_increase', {'amount': 1}),
    ),
    'bw7-67': (
        ('Sparkling Particles', 'between_turns_heal', {'amount': 10, 'scope': 'self'}),
    ),
    'bw7-72': (
        ('Poison Point', 'retaliate_status', {'statuses': ['poisoned']}),
    ),
    'bw7-73': (
        ('Poison Point', 'retaliate_status', {'statuses': ['poisoned']}),
    ),
    'bw7-74': (
        ('Poison Point', 'retaliate_status', {'statuses': ['poisoned']}),
    ),
    'bw7-85': (
        ('Sturdy', 'survive_full_hp', {}),
    ),
    'bw7-9': (
        ('Time Recall', 'team_borrow_previous_evolutions', {}),
    ),
    'bw7-99': (
        ('Sand Slammer', 'between_turns_counters_opponent', {'counters': 1, 'active_only': True}),
    ),
    'bw8-101': (
        ('Block', 'opp_active_cant_retreat_while_active', {}),
    ),
    'bw8-108': (
        ('Overflow', 'bonus_prize_on_ko', {'amount': 1}),
    ),
    'bw8-134': (
        ('Overflow', 'bonus_prize_on_ko', {'amount': 1}),
    ),
    'bw8-22': (
        ('Freefloating', 'no_retreat_cost', {'if_energy': 'none'}),
    ),
    'bw8-31': (
        ('Rain Dish', 'between_turns_heal', {'amount': 20, 'scope': 'self'}),
    ),
    'bw8-33': (
        ('Rough Skin', 'retaliate_counters', {'counters': 2}),
    ),
    'bw8-39': (
        ('Spiteful Spirit', 'ko_retaliate_status', {'statuses': ['confused', 'poisoned'], 'active_only': True}),
    ),
    'bw8-46': (
        ('Dual Brains', 'two_supporters', {}),
    ),
    'bw8-58': (
        ('Aftermath', 'ko_discard_opp_deck', {'count': 3}),
    ),
    'bw8-78': (
        ('Dual Armor', 'types_are', {'types': ['Fighting', 'Metal'], 'if_energy': 'Metal'}),
    ),
    'bw8-90': (
        ('Plasma Steel', 'team_immune_vs_subtype', {'defender_type': 'Metal', 'attacker_subtype': 'EX'}),
    ),
    'bw9-111': (
        ('Power Connect', 'team_attack_bonus', {'attacker_subtype': 'Team Plasma', 'exclude_name': 'Deoxys-EX', 'amount': 10}),
    ),
    'bw9-112': (
        ('Bright Down', 'immune_from_attackers_with_ability', {}),
    ),
    'bw9-118': (
        ('Safeguard', 'immune_from_attackers_with_subtype', {'subtype': 'EX'}),
    ),
    'bw9-119': (
        ('Garbotoxin', 'garbotoxin', {}),
    ),
    'bw9-22': (
        ('Laid-Back', 'damage_reduction', {'amount': 20}),
    ),
    'bw9-23': (
        ('Freeze Zone', 'team_retreat_reduction', {'subtype': 'Team Plasma', 'amount': 2}),
    ),
    'bw9-64': (
        ('Dark Shade', 'team_hp_bonus', {'subtype': 'Team Plasma', 'amount': 20}),
    ),
    'bw9-85': (
        ('Bright Down', 'immune_from_attackers_with_ability', {}),
    ),
    'bw9-94': (
        ('Color Change', 'type_same_as_opp_active', {}),
    ),
    'bwp-BW20': (
        ('Royal Heal', 'between_turns_heal', {'amount': 10, 'scope': 'team'}),
    ),
    'bwp-BW22': (
        ('Shell Armor', 'damage_reduction', {'amount': 20}),
    ),
    'bwp-BW40': (
        ('Scorching Scales', 'burn_counters', {'counters': 4}),
    ),
    'bwp-BW46': (
        ('Dark Cloak', 'team_no_retreat_if_energy', {'energy_type': 'Darkness'}),
    ),
    'bwp-BW48': (
        ('Fight Song', 'team_attack_bonus', {'attacker_type': 'Dragon', 'amount': 20}),
    ),
    'bwp-BW53': (
        ('Sand Slammer', 'between_turns_counters_opponent', {'counters': 1, 'active_only': True}),
    ),
    'bwp-BW55': (
        ('Weak Barrier', 'self_no_weakness_if_energy', {'energy_type': 'Psychic'}),
    ),
    'bwp-BW70': (
        ('Justified', 'self_attack_bonus_vs_type', {'defender_type': 'Darkness', 'amount': 50}),
    ),
    'bwp-BW71': (
        ('Justified', 'self_attack_bonus_vs_type', {'defender_type': 'Darkness', 'amount': 50}),
    ),
    'bwp-BW72': (
        ('Justified', 'self_attack_bonus_vs_type', {'defender_type': 'Darkness', 'amount': 50}),
    ),
    'bwp-BW82': (
        ('Power Connect', 'team_attack_bonus', {'attacker_subtype': 'Team Plasma', 'exclude_name': 'Deoxys-EX', 'amount': 10}),
    ),
    'bwp-BW83': (
        ('Overflow', 'bonus_prize_on_ko', {'amount': 1}),
    ),
    'bwp-BW92': (
        ('Solar Revelation', 'team_attack_effect_immune_if_energy', {}),
    ),
    'cel25-4': (
        ('Absolute Space', 'cond_lock', {'affects': 'opp', 'what': ['stadium'], 'when': ['active']}),
    ),
    'dc1-15': (
        ('Power Saver', 'cant_attack_if_few_subtype', {'count': 4, 'subtype': 'Team Magma'}),
    ),
    'dc1-6': (
        ('Power Saver', 'cant_attack_if_few_subtype', {'count': 4, 'subtype': 'Team Aqua'}),
    ),
    'dc1-8': (
        ('Sludge Festival', 'global_retreat_increase_except_subtype', {'except_subtype': 'Team Aqua', 'amount': 1}),
    ),
    'det1-6': (
        ('Security Guard', 'cond_damage_taken', {'scope': 'team', 'amount': 30, 'when': ['active']}),
    ),
    'det1-9': (
        ('Evasion Jutsu', 'coin_prevent', {}),
    ),
    'dp2-4': (
        ('Downer Material', 'opp_basic_attack_cost_increase', {'amount': 1, 'requires_names': ['Uxie', 'Mesprit']}),
    ),
    'dv1-14': (
        ('Grit', 'self_attack_bonus_if_status', {'amount': 40}),
    ),
    'ex7-14': (
        ('Holy Shield', 'immune_from_attackers_with_name_part', {'part': 'Dark'}),
    ),
    'g1-3': (
        ('Adaptive Evolution', 'evolve_on_play_turn', {}),
    ),
    'g1-4': (
        ('Adaptive Evolution', 'evolve_on_play_turn', {}),
    ),
    'g1-42': (
        ('Fighting Fury', 'team_attack_bonus', {'attacker_type': 'Fighting', 'amount': 20}),
    ),
    'g1-56': (
        ('Retreat Aid', 'bench_active_retreat_reduction', {'amount': 2}),
    ),
    'g1-58': (
        ('Stir and Snooze', 'sleep_flip_count', {'count': 2}),
    ),
    'g1-RC11': (
        ('Bide Barricade', 'global_ability_lock_except_type', {'except_type': 'Psychic'}),
    ),
    'g1-RC8': (
        ('Drag Along', 'ko_coin_knockout_attacker', {'active_only': True}),
    ),
    'me1-144': (
        ('Fragile Husk', 'ko_no_prize_vs_subtype', {'subtype': 'ex'}),
    ),
    'me1-147': (
        ('Powerful a-Salt', 'team_attack_bonus', {'attacker_type': 'Fighting', 'amount': 30}),
    ),
    'me1-148': (
        ('Spiteful Swirl', 'team_active_type_retaliate_counters', {'defender_type': 'Darkness', 'counters': 1}),
    ),
    'me1-24': (
        ('Intimidating Fang', 'opp_active_damage_reduction', {'amount': 30, 'holder_active_only': True}),
    ),
    'me1-61': (
        ('Fragile Husk', 'ko_no_prize_vs_subtype', {'subtype': 'ex'}),
    ),
    'me1-84': (
        ('Powerful a-Salt', 'team_attack_bonus', {'attacker_type': 'Fighting', 'amount': 30}),
    ),
    'me1-87': (
        ('Spiteful Swirl', 'team_active_type_retaliate_counters', {'defender_type': 'Darkness', 'counters': 1}),
    ),
    'me2-11': (
        ('Agile', 'no_retreat_cost', {'if_energy': 'none'}),
    ),
    'me2-112': (
        ('Swirling Prose', 'opp_bench_move_confuse_new_active', {}),
    ),
    'me2-22': (
        ('Thick Fat', 'damage_reduction', {'amount': 30, 'attacker_types': ['Fire', 'Water']}),
    ),
    'me2-36': (
        ('Swirling Prose', 'opp_bench_move_confuse_new_active', {}),
    ),
    'me2-41': (
        ('Diamond Coat', 'damage_reduction', {'amount': 30}),
    ),
    'me2-56': (
        ('Shadowy Concealment', 'team_ko_prize_reduction_vs_subtype', {'defender_type': 'Darkness', 'attacker_subtype': 'ex', 'amount': 1, 'no_stack_key': 'Shadowy Concealment'}),
    ),
    'me2-62': (
        ('Excited Power', 'self_attack_bonus_if_mega_ex', {'type': 'Darkness', 'amount': 120}),
    ),
    'me2-70': (
        ("Emperor's Stance", 'self_attack_effect_immune', {}),
    ),
    'me2-97': (
        ('Thick Fat', 'damage_reduction', {'amount': 30, 'attacker_types': ['Fire', 'Water']}),
    ),
    'me2pt5-101': (
        ('Holes', 'opp_bench_move_counters', {'counters': 2}),
    ),
    'me2pt5-117': (
        ('Double Type', 'types_are', {'types': ['Fighting', 'Psychic']}),
    ),
    'me2pt5-125': (
        ('Shadowy Concealment', 'team_ko_prize_reduction_vs_subtype', {'defender_type': 'Darkness', 'attacker_subtype': 'ex', 'amount': 1, 'no_stack_key': 'Shadowy Concealment'}),
    ),
    'me2pt5-135': (
        ('Counterattacking Crest', 'retaliate_counters', {'counters': 5}),
    ),
    'me2pt5-143': (
        ('Final Chain', 'ko_followup_search_any', {}),
    ),
    'me2pt5-148': (
        ('Supreme Overlord', 'self_attack_bonus_per_opp_prize_taken', {'amount': 30}),
    ),
    'me2pt5-222': (
        ('Melt Away', 'no_retreat_cost', {'if_energy': 'none'}),
    ),
    'me2pt5-223': (
        ('Incandescent Body', 'retaliate_status', {'statuses': ['burned']}),
    ),
    'me2pt5-239': (
        ('Holes', 'opp_bench_move_counters', {'counters': 2}),
    ),
    'me2pt5-24': (
        ('Melt Away', 'no_retreat_cost', {'if_energy': 'none'}),
    ),
    'me2pt5-242': (
        ('Double Type', 'types_are', {'types': ['Fighting', 'Psychic']}),
    ),
    'me2pt5-268': (
        ('Tenacious Body', 'survive_coin', {}),
    ),
    'me2pt5-269': (
        ('Shadowy Concealment', 'team_ko_prize_reduction_vs_subtype', {'defender_type': 'Darkness', 'attacker_subtype': 'ex', 'amount': 1, 'no_stack_key': 'Shadowy Concealment'}),
    ),
    'me2pt5-27': (
        ('Incandescent Body', 'retaliate_status', {'statuses': ['burned']}),
    ),
    'me2pt5-270': (
        ('Counterattacking Crest', 'retaliate_counters', {'counters': 5}),
    ),
    'me2pt5-283': (
        ('Tenacious Body', 'survive_coin', {}),
    ),
    'me2pt5-284': (
        ('Shadowy Concealment', 'team_ko_prize_reduction_vs_subtype', {'defender_type': 'Darkness', 'attacker_subtype': 'ex', 'amount': 1, 'no_stack_key': 'Shadowy Concealment'}),
    ),
    'me2pt5-285': (
        ('Counterattacking Crest', 'retaliate_counters', {'counters': 5}),
    ),
    'me2pt5-68': (
        ('Counterattack Quills', 'retaliate_counters', {'counters': 3}),
    ),
    'me3-100': (
        ("Sniper's Eye", 'ignore_colorless_cost_if_hand_count', {'hand_owner': 'opponent', 'count': 4}),
    ),
    'me3-103': (
        ('Luminous Wing', 'ability_effect_immune', {}),
    ),
    'me3-119': (
        ('Luminous Wing', 'ability_effect_immune', {}),
    ),
    'me3-12': (
        ("Sniper's Eye", 'ignore_colorless_cost_if_hand_count', {'hand_owner': 'opponent', 'count': 4}),
    ),
    'me3-17': (
        ('Shell Spikes', 'retaliate_discard_energy', {'count': 1}),
    ),
    'me3-24': (
        ('Tundra Wall', 'team_damage_reduction', {'energy_type': 'Water', 'amount': 50, 'no_stack_key': 'Tundra Wall'}),
    ),
    'me3-27': (
        ('Fighting Roar', 'evolve_on_play_turn', {'if_opp_active_subtype': 'ex'}),
    ),
    'me3-31': (
        ('Luminous Wing', 'ability_effect_immune', {}),
    ),
    'me3-50': (
        ('Infinite Shadow', 'ko_return_to_hand', {}),
    ),
    'me3-68-mon': (
        ('Intimidating Jaw', 'opp_active_damage_reduction', {'amount': 30, 'holder_active_only': True}),
    ),
    'me3-69-mon': (
        ('Protective Sail', 'self_card_effect_shield', {'kinds': ['supporter']}),
    ),
    'me3-92': (
        ('Tundra Wall', 'team_damage_reduction', {'energy_type': 'Water', 'amount': 50, 'no_stack_key': 'Tundra Wall'}),
    ),
    'me4-105': (
        ('Smooth Coat', 'coin_prevent', {}),
    ),
    'me4-119': (
        ('Smooth Coat', 'coin_prevent', {}),
    ),
    'me4-2': (
        ('Exoskeleton', 'damage_reduction', {'amount': 20}),
    ),
    'me4-29': (
        ('Synchro Pulse', 'self_attack_bonus_if_hand_equal', {'amount': 80}),
    ),
    'me4-52': (
        ('Poison Point', 'retaliate_status', {'statuses': ['poisoned']}),
    ),
    'me4-57': (
        ('Gloomy Garbage', 'opp_active_damage_reduction', {'amount': 20, 'attacker_has_tool': True}),
    ),
    'me4-68': (
        ('Slimy Sliding', 'opp_retreat_coin_fail', {}),
    ),
    'me4-7': (
        ('Needly Armor', 'retaliate_counters_per_energy', {'counters': 3, 'energy_type': 'Grass'}),
    ),
    'me4-70': (
        ('Watchful Eye', 'global_counter_move_lock', {}),
    ),
    'me4-73': (
        ('Smooth Coat', 'coin_prevent', {}),
    ),
    'me4-90': (
        ('Synchro Pulse', 'self_attack_bonus_if_hand_equal', {'amount': 80}),
    ),
    'me5-115': (
        ('Binding Flame', 'opp_active_retreat_increase', {'amount': 1}),
    ),
    'me5-28': (
        ('Photon Cord', 'ko_move_energy_to_bench', {'max': 2, 'energy_type': 'Lightning'}),
    ),
    'me5-38': (
        ('Binding Flame', 'opp_active_retreat_increase', {'amount': 1}),
    ),
    'me5-41': (
        ('Durable Body', 'survive_coin', {}),
    ),
    'me5-62': (
        ('Ancient Bulwark', 'team_damage_immune_vs_low_energy', {'max_energy': 2, 'holder_bench_only': True}),
    ),
    'me5-72-mon': (
        ('Protective Armor', 'team_damage_reduction', {'amount': 10, 'holder_active_only': True}),
    ),
    'me5-73-mon': (
        ('Spiny Skull', 'retaliate_counters', {'counters': 3}),
    ),
    'me5-93': (
        ('Ancient Bulwark', 'team_damage_immune_vs_low_energy', {'max_energy': 2, 'holder_bench_only': True}),
    ),
    'me5-99': (
        ('Binding Flame', 'opp_active_retreat_increase', {'amount': 1}),
    ),
    'pgo-11': (
        ('Excited Heart', 'cond_cost', {'scope': 'self', 'remove_colorless': 1, 'per': 'opp_prizes_taken'}),
    ),
    'pgo-55': (
        ('Block', 'opp_active_cant_retreat_while_active', {}),
    ),
    'pgo-57': (
        ('Primate Dexterity', 'coin_prevent', {}),
    ),
    'pgo-58': (
        ('Kinda Lazy', 'cant_attack_if_own_prizes_in', {'values': [2, 4, 6]}),
    ),
    'pgo-77': (
        ('Kinda Lazy', 'cant_attack_if_own_prizes_in', {'values': [2, 4, 6]}),
    ),
    'pl1-40': (
        ('Anticipation', 'self_attack_effect_immune', {}),
    ),
    'rsv10pt5-160': (
        ('Oceanic Curse', 'lock_opponent_items_and_tools_while_active', {}),
    ),
    'rsv10pt5-161': (
        ('Greedy Eater', 'bonus_prize_on_ko', {'amount': 1, 'defender_basic_only': True}),
    ),
    'rsv10pt5-168': (
        ('Oceanic Curse', 'lock_opponent_items_and_tools_while_active', {}),
    ),
    'rsv10pt5-169': (
        ('Greedy Eater', 'bonus_prize_on_ko', {'amount': 1, 'defender_basic_only': True}),
    ),
    'rsv10pt5-45': (
        ('Oceanic Curse', 'lock_opponent_items_and_tools_while_active', {}),
    ),
    'rsv10pt5-67': (
        ('Greedy Eater', 'bonus_prize_on_ko', {'amount': 1, 'defender_basic_only': True}),
    ),
    'rsv10pt5-79-mon': (
        ('Plume Protection', 'bench_damage_immune', {}),
    ),
    'rsv10pt5-8': (
        ('Stimulated Evolution', 'evolve_on_play_turn', {'if_in_play': 'Karrablast'}),
    ),
    'rsv10pt5-93': (
        ('Stimulated Evolution', 'evolve_on_play_turn', {'if_in_play': 'Karrablast'}),
    ),
    'sm1-46': (
        ('Water Bubble', 'cond_prevent', {'mode': 'damage', 'scope': 'self', 'src': {'type': 'Fire'}}),
    ),
    'sm1-75': (
        ('Wall of Sand', 'damage_reduction', {'amount': 20}),
    ),
    'sm1-82': (
        ('Rough Skin', 'retaliate_counters', {'counters': 3}),
    ),
    'sm1-87': (
        ('Tangling Hair', 'opp_active_retreat_increase', {'amount': 1}),
    ),
    'sm10-106': (
        ('Wall of Stone', 'cond_hp', {'scope': 'self', 'set': 200, 'when': ['opp_prizes_at_most:3']}),
    ),
    'sm10-109': (
        ('Ruler of the Night', 'cond_lock', {'what': ['tool', 'special_energy', 'stadium'], 'when': ['active']}),
    ),
    'sm10-113': (
        ('Intimidating Fang', 'opp_active_damage_reduction', {'amount': 20, 'holder_active_only': True}),
    ),
    'sm10-122': (
        ('Hair Wall', 'cond_damage_taken', {'scope': 'team', 'amount': 10, 'target': {'type': 'Metal'}}),
    ),
    'sm10-127': (
        ('Fast-Flight Configuration', 'cond_retreat', {'scope': 'self', 'when': ['opp_in_play_subtype:GX|EX']}),
    ),
    'sm10-140': (
        ('Fluffy Cotton', 'coin_prevent', {}),
    ),
    'sm10-148': (
        ('Gathering of Cats', 'cond_cost', {'scope': 'team', 'all': True, 'target': {'has_attack': 'Caturday'}}),
    ),
    'sm10-158': (
        ('Lazy Eating', 'between_turns_heal', {'amount': 10, 'scope': 'self'}),
    ),
    'sm10-202': (
        ('Ruler of the Night', 'cond_lock', {'what': ['tool', 'special_energy', 'stadium'], 'when': ['active']}),
    ),
    'sm10-206': (
        ('Fluffy Cotton', 'coin_prevent', {}),
    ),
    'sm10-218': (
        ('Solid Shell', 'damage_reduction', {'amount': 30}),
    ),
    'sm10-223': (
        ('Ruler of the Night', 'cond_lock', {'what': ['tool', 'special_energy', 'stadium'], 'when': ['active']}),
    ),
    'sm10-226': (
        ('Fluffy Cotton', 'coin_prevent', {}),
    ),
    'sm10-29': (
        ('Strong Cheer', 'cond_attack_bonus', {'scope': 'team', 'amount': 30, 'nostack': 'Strong Cheer'}),
    ),
    'sm10-34': (
        ('Solid Shell', 'damage_reduction', {'amount': 20}),
    ),
    'sm10-35': (
        ('Solid Shell', 'damage_reduction', {'amount': 30}),
    ),
    'sm10-59': (
        ('Stealthy Body', 'cond_weakness', {'scope': 'self', 'when': ['stadium']}),
    ),
    'sm10-74': (
        ('Detention Gas', 'between_turns_counters_opponent', {'counters': 1, 'active_only': True, 'basic_only': True}),
    ),
    'sm10-98': (
        ('Free Flight', 'no_retreat_cost', {'if_energy': 'none'}),
    ),
    'sm11-106': (
        ('Primal Winds', 'opp_basic_attack_cost_increase', {'amount': 1, 'active_only': True}),
    ),
    'sm11-11': (
        ('Shell Armor', 'damage_reduction', {'amount': 30}),
    ),
    'sm11-114': (
        ('Avenging Aura', 'cond_attack_bonus', {'scope': 'self', 'amount': 80, 'when': ['own_prizes_more_than_opp']}),
    ),
    'sm11-117': (
        ('Tag Coach', 'cond_damage_taken', {'scope': 'team', 'amount': 20, 'target': {'subtype': ['TAG TEAM']}}),
    ),
    'sm11-124': (
        ('Cellular Companions', 'cond_attack_bonus', {'scope': 'team', 'amount': 20, 'target': {'name_in': ['Zygarde', 'Zygarde-GX']}, 'when': ['bench']}),
    ),
    'sm11-148': (
        ('Aqua Lift', 'cond_retreat', {'scope': 'self', 'when': ['energy_type:Water']}),
    ),
    'sm11-154': (
        ('Unnerve', 'self_card_effect_shield', {'kinds': ['item', 'supporter']}),
    ),
    'sm11-170': (
        ('Counterattack', 'retaliate_counters', {'counters': 4}),
    ),
    'sm11-172': (
        ('Unaware', 'self_attack_effect_immune', {}),
    ),
    'sm11-219': (
        ('Pure Heart', 'cond_prevent', {'mode': 'all', 'scope': 'self', 'src': {'subtype': ['GX', 'EX']}}),
    ),
    'sm11-222': (
        ('Perfection', 'borrow_attacks', {'sources': 'own_gx_ex_bench_or_discard'}),
    ),
    'sm11-223': (
        ('Power Bind', 'cant_attack_if_few_pokemon', {'count': 4}),
    ),
    'sm11-224': (
        ('Primal Winds', 'opp_basic_attack_cost_increase', {'amount': 1, 'active_only': True}),
    ),
    'sm11-240': (
        ('Pure Heart', 'cond_prevent', {'mode': 'all', 'scope': 'self', 'src': {'subtype': ['GX', 'EX']}}),
    ),
    'sm11-242': (
        ('Perfection', 'borrow_attacks', {'sources': 'own_gx_ex_bench_or_discard'}),
    ),
    'sm11-243': (
        ('Power Bind', 'cant_attack_if_few_pokemon', {'count': 4}),
    ),
    'sm11-244': (
        ('Primal Winds', 'opp_basic_attack_cost_increase', {'amount': 1, 'active_only': True}),
    ),
    'sm11-47': (
        ('Pure Heart', 'cond_prevent', {'mode': 'all', 'scope': 'self', 'src': {'subtype': ['GX', 'EX']}}),
    ),
    'sm11-51': (
        ('Emergency Exit', 'cond_retreat', {'scope': 'self', 'when': ['energy_at_most:2']}),
    ),
    'sm11-60': (
        ('Double Type', 'types_are', {'types': ['Lightning', 'Metal']}),
    ),
    'sm11-7': (
        ('Swaddling Leaves', 'damage_reduction', {'amount': 10}),
    ),
    'sm11-71': (
        ('Perfection', 'borrow_attacks', {'sources': 'own_gx_ex_bench_or_discard'}),
    ),
    'sm11-8': (
        ('Swaddling Leaves', 'damage_reduction', {'amount': 30}),
    ),
    'sm11-9': (
        ('Blanket Weaver', 'cond_damage_taken', {'scope': 'team', 'amount': 40, 'target': {'type': 'Grass'}, 'nostack': 'Blanket Weaver'}),
    ),
    'sm12-100': (
        ('Unaware', 'self_attack_effect_immune', {}),
    ),
    'sm12-109': (
        ('Obnoxious Whirring', 'self_card_effect_shield', {'kinds': ['supporter']}),
    ),
    'sm12-110': (
        ('Dusty Defense', 'cond_damage_taken', {'scope': 'team', 'amount': 30, 'when': ['active']}),
    ),
    'sm12-122': (
        ('Solid Shell', 'damage_reduction', {'amount': 30}),
    ),
    'sm12-124': (
        ('Boiling Blood', 'cond_cost', {'scope': 'self', 'remove_colorless': 3, 'when': ['opp_in_play_subtype:GX|EX']}),
    ),
    'sm12-129': (
        ('Smug Face', 'cond_prevent', {'mode': 'all', 'scope': 'self', 'src': {'subtype': ['TAG TEAM', 'Ultra Beast']}}),
        ('Smug Face', 'cond_prevent', {'mode': 'all', 'scope': 'self', 'src': {'special_energy': True}}),
    ),
    'sm12-142': (
        ('Armor of the Sunne', 'cond_damage_taken', {'scope': 'team', 'amount': 50, 'target': {'name_in': ['Solgaleo', 'Lunala']}, 'when': ['own_name_in_play:Lunala'], 'nostack': 'Armor of the Sunne'}),
    ),
    'sm12-182': (
        ('Carry and Run', 'bench_active_retreat_reduction', {'amount': 2}),
    ),
    'sm12-21': (
        ('Beast Boost', 'cond_attack_bonus', {'scope': 'self', 'amount': 20, 'per': 'prizes_taken'}),
    ),
    'sm12-218': (
        ('Dusty Defense', 'cond_damage_taken', {'scope': 'team', 'amount': 30, 'when': ['active']}),
    ),
    'sm12-219': (
        ('Smug Face', 'cond_prevent', {'mode': 'all', 'scope': 'self', 'src': {'subtype': ['TAG TEAM', 'Ultra Beast']}}),
        ('Smug Face', 'cond_prevent', {'mode': 'all', 'scope': 'self', 'src': {'special_energy': True}}),
    ),
    'sm12-244': (
        ('Double Type', 'types_are', {'types': ['Psychic', 'Fighting']}),
    ),
    'sm12-25': (
        ('Power Cheer', 'cond_attack_bonus', {'scope': 'team', 'amount': 30, 'target': {'subtype': ['GX'], 'evolves_from': 'Eevee'}, 'nostack': 'Power Cheer'}),
    ),
    'sm12-256': (
        ('Dusty Defense', 'cond_damage_taken', {'scope': 'team', 'amount': 30, 'when': ['active']}),
    ),
    'sm12-257': (
        ('Smug Face', 'cond_prevent', {'mode': 'all', 'scope': 'self', 'src': {'subtype': ['TAG TEAM', 'Ultra Beast']}}),
        ('Smug Face', 'cond_prevent', {'mode': 'all', 'scope': 'self', 'src': {'special_energy': True}}),
    ),
    'sm12-39': (
        ('Snowed In', 'bench_damage_immune', {}),
    ),
    'sm12-42': (
        ('Vitality Cheer', 'cond_hp', {'scope': 'team', 'amount': 60, 'target': {'subtype': ['GX'], 'evolves_from': 'Eevee'}, 'nostack': 'Vitality Cheer'}),
    ),
    'sm12-70': (
        ('Speed Cheer', 'cond_cost', {'scope': 'team', 'remove_colorless': 1, 'target': {'subtype': ['GX'], 'evolves_from': 'Eevee'}, 'nostack': 'Speed Cheer'}),
    ),
    'sm12-82': (
        ('Double Type', 'types_are', {'types': ['Psychic', 'Fighting']}),
    ),
    'sm2-59': (
        ('Steelworker', 'team_attack_bonus', {'attacker_type': 'Metal', 'amount': 10}),
    ),
    'sm2-64': (
        ('Daunting Pose', 'cond_prevent', {'mode': 'damage', 'scope': 'team', 'target': {'zone': 'bench'}}),
        ('Daunting Pose', 'cond_counter_shield', {'scope': 'team', 'target': {'zone': 'bench'}}),
    ),
    'sm2-66': (
        ('Roadblock', 'cond_bench_limit', {'affects': 'opp', 'limit': 4}),
    ),
    'sm2-9': (
        ('Armor', 'damage_reduction', {'amount': 30}),
    ),
    'sm2-93': (
        ('Flower Shield', 'cond_status_immune', {'scope': 'team', 'statuses': 'all', 'target': {'has_energy_type': 'Fairy'}}),
    ),
    'sm2-98': (
        ('Bulletproof', 'damage_reduction', {'amount': 10}),
    ),
    'sm3-11': (
        ('Guts', 'survive_coin', {}),
    ),
    'sm3-134': (
        ("Light's End", 'cond_prevent', {'mode': 'damage', 'scope': 'self', 'src': {'type': 'Colorless'}}),
    ),
    'sm3-153': (
        ("Light's End", 'cond_prevent', {'mode': 'damage', 'scope': 'self', 'src': {'type': 'Colorless'}}),
    ),
    'sm3-28': (
        ('Luminous Barrier', 'cond_prevent', {'mode': 'all', 'scope': 'self', 'src': {'subtype': ['GX', 'EX']}}),
    ),
    'sm3-35': (
        ('Thick Fat', 'cond_damage_taken', {'scope': 'self', 'amount': 30, 'src': {'type': ['Fire', 'Water']}}),
    ),
    'sm3-50': (
        ('More Poison', 'cond_between_turns', {'counters': 1, 'poisoned': True}),
    ),
    'sm3-80': (
        ('Shadow Hunt', 'borrow_attacks', {'sources': 'own_discard_basic'}),
    ),
    'sm35-37': (
        ('Intimidating Pattern', 'opp_active_damage_reduction', {'amount': 30, 'holder_active_only': True}),
    ),
    'sm35-47': (
        ('Cursed Whirlpool', 'opp_active_cant_retreat_while_active', {}),
    ),
    'sm35-55': (
        ('Scoundrel Guard', 'cond_prevent', {'mode': 'all', 'scope': 'self', 'src': {'subtype': ['GX', 'EX']}}),
    ),
    'sm35-57': (
        ('Fabled Defense', 'cond_prevent', {'mode': 'damage', 'scope': 'team', 'target': {'zone': 'bench'}, 'when': ['active']}),
    ),
    'sm4-108': (
        ('Gyro Unit', 'cond_retreat', {'scope': 'team', 'target': {'basic': True}}),
    ),
    'sm4-11': (
        ('Sap Sipper', 'self_attack_bonus_vs_type', {'defender_type': 'Grass', 'amount': 80}),
    ),
    'sm4-119': (
        ('Gyro Unit', 'cond_retreat', {'scope': 'team', 'target': {'basic': True}}),
    ),
    'sm4-17': (
        ('Submerge', 'bench_damage_immune', {}),
    ),
    'sm4-28': (
        ('Iceberg Shield', 'cond_prevent', {'mode': 'all', 'scope': 'self', 'when': ['own_name_in_play:Regirock'], 'src': {'stage': 'Stage 2'}}),
    ),
    'sm4-31': (
        ('Surge Surfer', 'no_retreat_if_stadium', {}),
    ),
    'sm4-38': (
        ('Gnawing Curse', 'cond_attach_counters', {'n': 2}),
    ),
    'sm4-42': (
        ('Own Tempo', 'cond_status_immune', {'scope': 'self', 'statuses': ['confused']}),
    ),
    'sm4-53': (
        ('Rock Peak Growl', 'team_attack_bonus', {'attacker_name': 'Registeel', 'amount': 10}),
    ),
    'sm4-56': (
        ('Fluffy', 'cond_damage_taken', {'scope': 'self', 'amount': 30, 'src': {'not_type': 'Fire'}}),
    ),
    'sm4-90': (
        ('Gyro Unit', 'cond_retreat', {'scope': 'team', 'target': {'basic': True}}),
    ),
    'sm5-11': (
        ('Weather Guard', 'cond_weakness', {'scope': 'team', 'target': {'type': 'Grass'}}),
    ),
    'sm5-110': (
        ('Roto Motor', 'cond_cost', {'scope': 'self', 'all': True, 'when': ['tools_in_discard_at_least:9']}),
    ),
    'sm5-116': (
        ('Gyro Unit', 'cond_retreat', {'scope': 'team', 'target': {'basic': True}}),
    ),
    'sm5-14': (
        ('Roto Motor', 'cond_cost', {'scope': 'self', 'all': True, 'when': ['tools_in_discard_at_least:9']}),
    ),
    'sm5-141': (
        ('Freezing Gaze', 'cond_ability_lock', {'affects': 'opp', 'target': {'subtype': ['GX', 'EX']}, 'when': ['active'], 'except_ability': 'Freezing Gaze', 'zones_all': True}),
    ),
    'sm5-142': (
        ('Flashing Head', 'cond_prevent', {'mode': 'damage', 'scope': 'self', 'src': {'special_energy': True}}),
    ),
    'sm5-159': (
        ('Freezing Gaze', 'cond_ability_lock', {'affects': 'opp', 'target': {'subtype': ['GX', 'EX']}, 'when': ['active'], 'except_ability': 'Freezing Gaze', 'zones_all': True}),
    ),
    'sm5-160': (
        ('Flashing Head', 'cond_prevent', {'mode': 'damage', 'scope': 'self', 'src': {'special_energy': True}}),
    ),
    'sm5-17': (
        ('Water Bubble', 'cond_prevent', {'mode': 'damage', 'scope': 'self', 'src': {'type': 'Fire'}}),
    ),
    'sm5-19': (
        ('Incandescent Body', 'retaliate_status', {'statuses': ['burned']}),
    ),
    'sm5-23': (
        ('Flaming Fighter', 'burn_counters', {'counters': 6}),
    ),
    'sm5-24': (
        ('Roto Motor', 'cond_cost', {'scope': 'self', 'all': True, 'when': ['tools_in_discard_at_least:9']}),
    ),
    'sm5-39': (
        ('Freezing Gaze', 'cond_ability_lock', {'affects': 'opp', 'target': {'subtype': ['GX', 'EX']}, 'when': ['active'], 'except_ability': 'Freezing Gaze', 'zones_all': True}),
    ),
    'sm5-40': (
        ('Roto Motor', 'cond_cost', {'scope': 'self', 'all': True, 'when': ['tools_in_discard_at_least:9']}),
    ),
    'sm5-41': (
        ('Roto Motor', 'cond_cost', {'scope': 'self', 'all': True, 'when': ['tools_in_discard_at_least:9']}),
    ),
    'sm5-48': (
        ('Intimidating Fang', 'opp_active_damage_reduction', {'amount': 30, 'holder_active_only': True}),
    ),
    'sm5-50': (
        ('Roto Motor', 'cond_cost', {'scope': 'self', 'all': True, 'when': ['tools_in_discard_at_least:9']}),
    ),
    'sm5-70': (
        ('Power Huddle', 'cond_attack_bonus', {'scope': 'team', 'amount': 30, 'target': {'name': 'Passimian'}, 'src': {'evolution': True}, 'when': ['bench']}),
    ),
    'sm5-81': (
        ('Solid Unit', 'bench_damage_immune', {}),
    ),
    'sm5-85': (
        ('Earthen Shield', 'cond_prevent', {'mode': 'damage', 'scope': 'team', 'target': {'type': 'Metal'}, 'src': {'special_energy': True}}),
    ),
    'sm5-97': (
        ('Rock Hiding', 'cond_retreat', {'scope': 'self', 'when': ['energy_type:Fighting']}),
    ),
    'sm6-19': (
        ('Unnerve', 'self_card_effect_shield', {'kinds': ['item', 'supporter']}),
    ),
    'sm6-21': (
        ('Frubbles', 'cond_retreat', {'scope': 'self', 'when': ['energy_type:Water']}),
    ),
    'sm6-40': (
        ('Roto Motor', 'cond_cost', {'scope': 'self', 'all': True, 'when': ['tools_in_discard_at_least:9']}),
    ),
    'sm6-42': (
        ('Silent Waves', 'cond_weakness', {'scope': 'team', 'affects': 'opp', 'fx': 'resistance', 'when': ['own_name_in_play:Azelf']}),
    ),
    'sm6-53': (
        ('Poison Point', 'retaliate_status', {'statuses': ['poisoned']}),
    ),
    'sm6-59': (
        ('Flaming Fighter', 'burn_counters', {'counters': 6}),
    ),
    'sm6-69': (
        ('Tyrannical Heart', 'cond_attack_bonus', {'scope': 'self', 'amount': 60, 'when': ['not_more_in_play']}),
        ('Tyrannical Heart', 'cond_damage_taken', {'scope': 'self', 'amount': 30, 'when': ['not_more_in_play']}),
    ),
    'sm6-71': (
        ('Earthen Aura', 'ignore_weakness_resistance', {}),
    ),
    'sm6-91': (
        ('Sticky Membrane', 'cond_cost', {'scope': 'team', 'affects': 'opp', 'add_colorless': 1, 'when': ['active']}),
    ),
    'sm6-96': (
        ('First Law', 'self_attack_effect_immune', {}),
    ),
    'sm7-10': (
        ('Power of Nature', 'cond_prevent', {'mode': 'damage', 'scope': 'team', 'target': {'has_energy_type': 'Grass'}, 'src': {'subtype': ['Ultra Beast']}}),
    ),
    'sm7-102': (
        ('Ultra Wall', 'cond_damage_taken', {'scope': 'team', 'amount': 10, 'target': {'subtype': ['Ultra Beast']}}),
    ),
    'sm7-10a': (
        ('Power of Nature', 'cond_prevent', {'mode': 'damage', 'scope': 'team', 'target': {'has_energy_type': 'Grass'}, 'src': {'subtype': ['Ultra Beast']}}),
    ),
    'sm7-115': (
        ('Lazy', 'cond_ability_lock', {'affects': 'opp', 'when': ['active'], 'except_ability': 'Lazy'}),
    ),
    'sm7-156': (
        ('Magic Evens', 'cond_damage_taken', {'scope': 'self', 'prevent_values': [20, 40, 60, 80, 100, 120, 140, 160, 180, 200, 220, 240, 260]}),
    ),
    'sm7-158': (
        ('Danger Perception', 'self_attack_bonus_if_low_hp', {'hp': 100, 'amount': 80}),
    ),
    'sm7-159': (
        ('Ultra Wall', 'cond_damage_taken', {'scope': 'team', 'amount': 10, 'target': {'subtype': ['Ultra Beast']}}),
    ),
    'sm7-173': (
        ('Magic Evens', 'cond_damage_taken', {'scope': 'self', 'prevent_values': [20, 40, 60, 80, 100, 120, 140, 160, 180, 200, 220, 240, 260]}),
    ),
    'sm7-175': (
        ('Danger Perception', 'self_attack_bonus_if_low_hp', {'hp': 100, 'amount': 80}),
    ),
    'sm7-176': (
        ('Ultra Wall', 'cond_damage_taken', {'scope': 'team', 'amount': 10, 'target': {'subtype': ['Ultra Beast']}}),
    ),
    'sm7-19': (
        ('Poison Payback', 'retaliate_status', {'statuses': ['poisoned']}),
    ),
    'sm7-20': (
        ('Poison Payback', 'retaliate_status', {'statuses': ['poisoned']}),
    ),
    'sm7-37': (
        ('Aqua Lift', 'cond_retreat', {'scope': 'self', 'when': ['energy_type:Water']}),
    ),
    'sm7-45': (
        ('Icy Barrier', 'cond_lock', {'what': ['stadium'], 'when': ['active']}),
    ),
    'sm7-47': (
        ('Floating Electrons', 'cond_retreat', {'scope': 'self', 'when': ['energy_any']}),
    ),
    'sm7-56': (
        ('Magic Evens', 'cond_damage_taken', {'scope': 'self', 'prevent_values': [20, 40, 60, 80, 100, 120, 140, 160, 180, 200, 220, 240, 260]}),
    ),
    'sm7-62': (
        ('Sunbeam', 'cond_hp', {'scope': 'team', 'set': 130, 'target': {'name': 'Lunatone'}}),
    ),
    'sm7-70': (
        ('Shadow Shield', 'cond_damage_taken', {'scope': 'self', 'amount': 20, 'when': ['energy_type:Psychic']}),
    ),
    'sm7-90': (
        ('Danger Perception', 'self_attack_bonus_if_low_hp', {'hp': 100, 'amount': 80}),
    ),
    'sm7-92': (
        ('Conductive Body', 'self_retreat_reduction_per_bench_name', {'name': 'Beldum', 'amount_per': 1}),
    ),
    'sm7-96': (
        ('Exoskeleton', 'damage_reduction', {'amount': 20}),
    ),
    'sm7-99': (
        ('Full Metal Body', 'cond_weakness', {'scope': 'self', 'when': ['energy_type:Metal']}),
    ),
    'sm75-28': (
        ('Submerge', 'bench_damage_immune', {}),
    ),
    'sm75-30': (
        ('Murmurs of the Sea', 'cond_status_immune', {'scope': 'team', 'statuses': ['confused'], 'target': {'type': 'Water'}}),
    ),
    'sm75-31': (
        ('Meet Up', 'cond_hp', {'scope': 'team', 'amount': 20, 'target': {'name': 'Wishiwashi-GX'}}),
        ('Meet Up', 'cond_attack_bonus', {'scope': 'team', 'amount': 20, 'target': {'name': 'Wishiwashi-GX'}}),
    ),
    'sm75-39': (
        ('Dragon Guard', 'cond_prevent', {'mode': 'effects', 'scope': 'team', 'target': {'type': 'Dragon'}}),
    ),
    'sm75-40': (
        ('Fight Song', 'team_attack_bonus', {'attacker_type': 'Dragon', 'amount': 20}),
    ),
    'sm75-40a': (
        ('Fight Song', 'team_attack_bonus', {'attacker_type': 'Dragon', 'amount': 20}),
    ),
    'sm75-43': (
        ('Energy Guard', 'cond_damage_taken', {'scope': 'self', 'amount': 20, 'when': ['energy_type:basic']}),
    ),
    'sm75-44': (
        ('Dragon Lift', 'cond_retreat', {'scope': 'team', 'target': {'not_subtype': ['GX', 'EX']}}),
    ),
    'sm75-45': (
        ('Rough Skin', 'retaliate_counters', {'counters': 3}),
    ),
    'sm75-73': (
        ('Dragon Lift', 'cond_retreat', {'scope': 'team', 'target': {'not_subtype': ['GX', 'EX']}}),
    ),
    'sm8-114': (
        ('Submerge', 'bench_damage_immune', {}),
    ),
    'sm8-126': (
        ('Exoskeleton', 'damage_reduction', {'amount': 30}),
    ),
    'sm8-148': (
        ('Effect Spore', 'retaliate_status', {'statuses': ['asleep']}),
    ),
    'sm8-17': (
        ('Protective Shell', 'cond_prevent', {'mode': 'damage', 'scope': 'self', 'src': {'energy_at_most': 2}}),
    ),
    'sm8-195': (
        ('Protective Shell', 'cond_prevent', {'mode': 'damage', 'scope': 'self', 'src': {'energy_at_most': 2}}),
    ),
    'sm8-201': (
        ('Thunderclap Zone', 'team_no_retreat_if_energy', {'energy_type': 'Lightning'}),
    ),
    'sm8-202': (
        ('Mirror Counter', 'retaliate_equal_damage_vs_subtype', {'subtypes': ['GX', 'EX']}),
    ),
    'sm8-215': (
        ('Protective Shell', 'cond_prevent', {'mode': 'damage', 'scope': 'self', 'src': {'energy_at_most': 2}}),
    ),
    'sm8-221': (
        ('Thunderclap Zone', 'team_no_retreat_if_energy', {'energy_type': 'Lightning'}),
    ),
    'sm8-222': (
        ('Mirror Counter', 'retaliate_equal_damage_vs_subtype', {'subtypes': ['GX', 'EX']}),
    ),
    'sm8-50': (
        ('Wild Dash', 'cond_retreat', {'scope': 'self', 'when': ['opp_in_play_subtype:GX|EX']}),
    ),
    'sm8-53': (
        ('Secret Alleyway', 'cond_retreat', {'scope': 'self', 'when': ['own_type_in_play:Fairy']}),
    ),
    'sm8-58': (
        ('Mantine Surf', 'cond_retreat', {'scope': 'self', 'when': ['energy_any']}),
    ),
    'sm8-98': (
        ('Mirror Counter', 'retaliate_equal_damage_vs_subtype', {'subtypes': ['GX', 'EX']}),
    ),
    'sm9-109': (
        ('Royal Guard', 'damage_reduction', {'amount': 40}),
    ),
    'sm9-110': (
        ('Key of Secrets', 'team_resistance_override', {'defender_type': 'Metal', 'value': '-40'}),
    ),
    'sm9-111': (
        ('Luminous Barrier', 'cond_prevent', {'mode': 'all', 'scope': 'self', 'src': {'subtype': ['GX', 'EX']}}),
    ),
    'sm9-117': (
        ('Defensive Scales', 'self_attack_effect_immune', {}),
    ),
    'sm9-22': (
        ('Floating Shell', 'cond_retreat', {'scope': 'self', 'when': ['stadium']}),
    ),
    'sm9-4': (
        ('Grass Cushion', 'cond_damage_taken', {'scope': 'self', 'amount': 30, 'when': ['energy_type:Grass']}),
    ),
    'sm9-48': (
        ('Unnerve', 'self_card_effect_shield', {'kinds': ['item', 'supporter']}),
    ),
    'sm9-67': (
        ('Magic Odds', 'cond_damage_taken', {'scope': 'self', 'prevent_values': [10, 30, 50, 70, 90, 110, 130, 150, 170, 190, 210, 230, 250]}),
    ),
    'sm9-69': (
        ('Cosmic Guard', 'bench_damage_immune', {}),
    ),
    'sm9-7': (
        ('Panic Spores', 'cond_between_turns', {'counters': 2, 'confused': True}),
    ),
    'sm9-76': (
        ('Fossil Bind', 'cond_lock', {'what': ['item'], 'when': ['fewer_in_play']}),
    ),
    'sm9-78': (
        ('Fossilized Memories', 'cond_lock', {'what': ['supporter'], 'when': ['active']}),
    ),
    'sm9-88': (
        ('Dark Ambition', 'cond_retreat', {'scope': 'team', 'affects': 'opp', 'amount': 1, 'target': {'zone': 'active', 'basic': True}}),
    ),
    'sma-SV11': (
        ('Frubbles', 'cond_retreat', {'scope': 'self', 'when': ['energy_type:Water']}),
    ),
    'sma-SV13': (
        ('Floating Electrons', 'cond_retreat', {'scope': 'self', 'when': ['energy_any']}),
    ),
    'sma-SV15': (
        ('More Poison', 'cond_between_turns', {'counters': 1, 'poisoned': True}),
    ),
    'sma-SV20': (
        ('Roadblock', 'cond_bench_limit', {'affects': 'opp', 'limit': 4}),
    ),
    'sma-SV37': (
        ('Fight Song', 'team_attack_bonus', {'attacker_type': 'Dragon', 'amount': 20}),
    ),
    'sma-SV4': (
        ('Wimp Out', 'cond_retreat', {'scope': 'self', 'when': ['first_turn']}),
    ),
    'sma-SV55': (
        ('Freezing Gaze', 'cond_ability_lock', {'affects': 'opp', 'target': {'subtype': ['GX', 'EX']}, 'when': ['active'], 'except_ability': 'Freezing Gaze', 'zones_all': True}),
    ),
    'sma-SV58': (
        ('Flashing Head', 'cond_prevent', {'mode': 'damage', 'scope': 'self', 'src': {'special_energy': True}}),
    ),
    'sma-SV72': (
        ('Danger Perception', 'self_attack_bonus_if_low_hp', {'hp': 100, 'amount': 80}),
    ),
    'sma-SV74': (
        ('Ultra Wall', 'cond_damage_taken', {'scope': 'team', 'amount': 10, 'target': {'subtype': ['Ultra Beast']}}),
    ),
    'sma-SV79': (
        ('Gyro Unit', 'cond_retreat', {'scope': 'team', 'target': {'basic': True}}),
    ),
    'smp-SM139': (
        ('Dragon Lift', 'cond_retreat', {'scope': 'team', 'target': {'not_subtype': ['GX', 'EX']}}),
    ),
    'smp-SM147': (
        ('Freezing Gaze', 'cond_ability_lock', {'affects': 'opp', 'target': {'subtype': ['GX', 'EX']}, 'when': ['active'], 'except_ability': 'Freezing Gaze', 'zones_all': True}),
    ),
    'smp-SM157': (
        ('Pika Shield', 'cond_status_immune', {'scope': 'self', 'statuses': ['paralyzed']}),
    ),
    'smp-SM178': (
        ('Hard Coat', 'damage_reduction', {'amount': 30}),
    ),
    'smp-SM180': (
        ('Wall of Stone', 'cond_hp', {'scope': 'self', 'set': 200, 'when': ['opp_prizes_at_most:3']}),
    ),
    'smp-SM182': (
        ('Gathering of Cats', 'cond_cost', {'scope': 'team', 'all': True, 'target': {'has_attack': 'Caturday'}}),
    ),
    'smp-SM187': (
        ('Cursed Body', 'retaliate_status', {'statuses': ['confused']}),
    ),
    'smp-SM189': (
        ('Solid Shell', 'damage_reduction', {'amount': 30}),
    ),
    'smp-SM191': (
        ('Perfection', 'borrow_attacks', {'sources': 'own_gx_ex_bench_or_discard'}),
    ),
    'smp-SM208': (
        ('Stealthy Body', 'cond_weakness', {'scope': 'self', 'when': ['stadium']}),
    ),
    'smp-SM209': (
        ('Wall of Stone', 'cond_hp', {'scope': 'self', 'set': 200, 'when': ['opp_prizes_at_most:3']}),
    ),
    'smp-SM218': (
        ('Beast Boost', 'cond_attack_bonus', {'scope': 'self', 'amount': 20, 'per': 'prizes_taken'}),
    ),
    'smp-SM236': (
        ('Spiky Shield', 'retaliate_counters', {'counters': 3}),
    ),
    'smp-SM239': (
        ('High Density Armor', 'cond_damage_taken', {'scope': 'self', 'amount': 90, 'when': ['full_hp']}),
    ),
    'smp-SM25': (
        ('Sunny Day', 'cond_attack_bonus', {'scope': 'team', 'amount': 20, 'target': {'type': ['Grass', 'Fire']}}),
    ),
    'smp-SM46': (
        ('More Poison', 'cond_between_turns', {'counters': 1, 'poisoned': True}),
    ),
    'smp-SM52': (
        ('Armor', 'damage_reduction', {'amount': 30}),
    ),
    'smp-SM53': (
        ('Steelworker', 'team_attack_bonus', {'attacker_type': 'Metal', 'amount': 10}),
    ),
    'smp-SM58': (
        ("Light's End", 'cond_prevent', {'mode': 'damage', 'scope': 'self', 'src': {'type': 'Colorless'}}),
    ),
    'smp-SM72': (
        ('Surge Surfer', 'no_retreat_if_stadium', {}),
    ),
    'smp-SM74': (
        ('Rock Peak Growl', 'team_attack_bonus', {'attacker_name': 'Registeel', 'amount': 10}),
    ),
    'smp-SM77': (
        ('Pressure', 'opp_active_damage_reduction', {'amount': 20, 'holder_active_only': True}),
    ),
    'smp-SM79': (
        ('Time Recall', 'team_borrow_previous_evolutions', {}),
    ),
    'smp-SM87': (
        ('Flight Support', 'cond_retreat', {'scope': 'team', 'target': {'name': 'Latios'}}),
    ),
    'smp-SM91': (
        ('Gyro Unit', 'cond_retreat', {'scope': 'team', 'target': {'basic': True}}),
    ),
    'smp-SM94': (
        ('Roto Motor', 'cond_cost', {'scope': 'self', 'all': True, 'when': ['tools_in_discard_at_least:9']}),
    ),
    'sv1-121': (
        ('Exoskeleton', 'damage_reduction', {'amount': 20}),
    ),
    'sv1-134': (
        ('Leadership', 'cond_attack_bonus', {'scope': 'team', 'amount': 30, 'target': {'basic': True}}),
    ),
    'sv1-19': (
        ('Trap Territory', 'opp_active_retreat_increase', {'amount': 1}),
    ),
    'sv1-208': (
        ('Electricity Pouches', 'cond_status_immune', {'scope': 'self', 'statuses': ['paralyzed']}),
    ),
    'sv1-220': (
        ('Leadership', 'cond_attack_bonus', {'scope': 'team', 'amount': 30, 'target': {'basic': True}}),
    ),
    'sv1-223': (
        ('Trap Territory', 'opp_active_retreat_increase', {'amount': 1}),
    ),
    'sv1-243': (
        ('Trap Territory', 'opp_active_retreat_increase', {'amount': 1}),
    ),
    'sv1-5': (
        ('Counterattack Quills', 'retaliate_counters', {'counters': 3}),
    ),
    'sv1-6': (
        ('Counterattack Quills', 'retaliate_counters', {'counters': 3}),
    ),
    'sv1-68': (
        ('Electricity Pouches', 'cond_status_immune', {'scope': 'self', 'statuses': ['paralyzed']}),
    ),
    'sv1-8': (
        ('Adaptive Evolution', 'evolve_on_play_turn', {}),
    ),
    'sv1-9': (
        ('Adaptive Evolution', 'evolve_on_play_turn', {}),
    ),
    'sv1-99': (
        ('Well-Baked Body', 'cond_status_immune', {'scope': 'self', 'statuses': ['burned']}),
        ('Well-Baked Body', 'cond_prevent', {'mode': 'damage', 'scope': 'self', 'src': {'type': 'Fire'}}),
    ),
    'sv10-113': (
        ('Potent Glare', 'opp_cant_play_ability_pokemon_while_active', {'except_name_prefix': "Team Rocket's"}),
    ),
    'sv10-210': (
        ('Snow Camouflage', 'self_card_effect_shield', {'kinds': ['item', 'supporter']}),
    ),
    'sv10-36': (
        ('Melt Away', 'no_retreat_cost', {'if_energy': 'none'}),
    ),
    'sv10-55': (
        ("Diver's Catch", 'team_ko_energy_to_hand', {'pokemon_type': 'Water', 'energy_type': 'Water'}),
    ),
    'sv10-65': (
        ('Snow Camouflage', 'self_card_effect_shield', {'kinds': ['item', 'supporter']}),
    ),
    'sv10-74': (
        ('Darkest Impulse', 'opp_evolve_counters', {'counters': 4}),
    ),
    'sv10-8': (
        ('Cheer On to Glory', 'team_attack_bonus', {'attacker_name_prefix': "Cynthia's", 'amount': 30}),
    ),
    'sv10-96': (
        ('Sand Stream', 'between_turns_counters_opponent', {'counters': 2, 'active_only': True, 'basic_only': True}),
    ),
    'sv2-113': (
        ('Arm Thrust Practice', 'cond_damage_taken', {'scope': 'team', 'amount': 10}),
    ),
    'sv2-123': (
        ('Blessed Salt', 'between_turns_heal', {'amount': 20, 'scope': 'team'}),
    ),
    'sv2-127': (
        ('Cursed Land', 'cond_ability_lock', {'affects': 'opp', 'when': ['active'], 'target': {'damaged': True}, 'except_subtype': ['ex']}),
    ),
    'sv2-150': (
        ('Bronze Body', 'damage_reduction', {'amount': 30}),
    ),
    'sv2-151': (
        ('Nutritional Iron', 'cond_hp', {'scope': 'self', 'amount': 100, 'when': ['energy_type_at_least:Metal:3']}),
    ),
    'sv2-2': (
        ('Drifting Dodge', 'coin_prevent', {}),
    ),
    'sv2-224': (
        ('Nutritional Iron', 'cond_hp', {'scope': 'self', 'amount': 100, 'when': ['energy_type_at_least:Metal:3']}),
    ),
    'sv2-243': (
        ('Cursed Land', 'cond_ability_lock', {'affects': 'opp', 'when': ['active'], 'target': {'damaged': True}, 'except_subtype': ['ex']}),
    ),
    'sv2-245': (
        ('Bronze Body', 'damage_reduction', {'amount': 30}),
    ),
    'sv2-263': (
        ('Cursed Land', 'cond_ability_lock', {'affects': 'opp', 'when': ['active'], 'target': {'damaged': True}, 'except_subtype': ['ex']}),
    ),
    'sv2-275': (
        ('Cursed Land', 'cond_ability_lock', {'affects': 'opp', 'when': ['active'], 'target': {'damaged': True}, 'except_subtype': ['ex']}),
    ),
    'sv2-3': (
        ('Drifting Dodge', 'coin_prevent', {}),
    ),
    'sv2-97': (
        ('Safeguard', 'cond_prevent', {'mode': 'damage', 'scope': 'self', 'src': {'subtype': ['ex', 'V']}}),
    ),
    'sv3-120': (
        ('Counterattacking Pincer', 'retaliate_discard_energy', {'count': 1}),
    ),
    'sv3-123': (
        ('Dust Field', 'cond_bench_limit', {'affects': 'opp', 'limit': 3, 'when': ['active']}),
    ),
    'sv3-174': (
        ('Bouffer', 'damage_reduction', {'amount': 20}),
    ),
    'sv3-201': (
        ('Insulator', 'cond_prevent', {'mode': 'damage', 'scope': 'self', 'src': {'type': 'Lightning'}}),
    ),
    'sv3-213': (
        ('Dust Field', 'cond_bench_limit', {'affects': 'opp', 'limit': 3, 'when': ['active']}),
    ),
    'sv3-22': (
        ('Protective Mycelium', 'team_attack_effect_immune_if_energy', {}),
    ),
    'sv3-25': (
        ('Double Type', 'types_are', {'types': ['Grass', 'Fire']}),
    ),
    'sv3-30': (
        ('Pressure', 'opp_active_damage_reduction', {'amount': 20, 'holder_active_only': True}),
    ),
    'sv3-44': (
        ('Scorching Armor', 'retaliate_status', {'statuses': ['burned']}),
    ),
    'sv3-52': (
        ('Quaking Zone', 'cond_cost', {'scope': 'team', 'affects': 'opp', 'add_colorless': 1, 'target': {'zone': 'active'}, 'when': ['active']}),
    ),
    'sv3-70': (
        ('Adverse Weather', 'cond_prevent', {'mode': 'damage', 'scope': 'team', 'target': {'zone': 'bench'}, 'when': ['active']}),
    ),
    'sv3-78': (
        ('Insulator', 'cond_prevent', {'mode': 'damage', 'scope': 'self', 'src': {'type': 'Lightning'}}),
    ),
    'sv3-82': (
        ('Lunar Zone', 'cond_retreat', {'scope': 'team', 'target': {'has_energy_type': 'Psychic'}}),
    ),
    'sv3pt5-107': (
        ('Counterattack', 'retaliate_counters', {'counters': 3}),
    ),
    'sv3pt5-122': (
        ('Mimic Barrier', 'cond_prevent', {'mode': 'damage', 'scope': 'self', 'when': ['same_energy_as_opp_active']}),
    ),
    'sv3pt5-139': (
        ('Primordial Tentacles', 'opp_active_cant_retreat_while_active', {}),
    ),
    'sv3pt5-14': (
        ('Cocoon Cover', 'self_attack_effect_immune', {}),
    ),
    'sv3pt5-144': (
        ('Ice Float', 'cond_retreat', {'scope': 'self', 'when': ['energy_type:Water']}),
    ),
    'sv3pt5-145': (
        ('Voltaic Float', 'cond_retreat', {'scope': 'self', 'when': ['energy_type:Lightning']}),
    ),
    'sv3pt5-146': (
        ('Flare Float', 'cond_retreat', {'scope': 'self', 'when': ['energy_type:Fire']}),
    ),
    'sv3pt5-149': (
        ('Jet Cruise', 'cond_retreat', {'scope': 'team', 'target': {'name': 'Pokémon'}}),
    ),
    'sv3pt5-152': (
        ('Domed Armor', 'damage_reduction', {'amount': 30}),
    ),
    'sv3pt5-153': (
        ('Helical Swell', 'cond_lock', {'affects': 'opp', 'what': ['stadium'], 'when': ['active']}),
    ),
    'sv3pt5-154': (
        ('Amber Protection', 'ability_effect_immune', {}),
    ),
    'sv3pt5-174': (
        ('Enthusiastic King', 'cond_cost', {'scope': 'self', 'all': True, 'when': ['own_name_in_play:Nidoqueen']}),
    ),
    'sv3pt5-179': (
        ('Mimic Barrier', 'cond_prevent', {'mode': 'damage', 'scope': 'self', 'when': ['same_energy_as_opp_active']}),
    ),
    'sv3pt5-184': (
        ('Solid Shell', 'damage_reduction', {'amount': 30}),
    ),
    'sv3pt5-187': (
        ('Expanding Body', 'self_hp_if_special_energy', {'amount': 100}),
    ),
    'sv3pt5-192': (
        ('Voltaic Float', 'cond_retreat', {'scope': 'self', 'when': ['energy_type:Lightning']}),
    ),
    'sv3pt5-200': (
        ('Solid Shell', 'damage_reduction', {'amount': 30}),
    ),
    'sv3pt5-202': (
        ('Voltaic Float', 'cond_retreat', {'scope': 'self', 'when': ['energy_type:Lightning']}),
    ),
    'sv3pt5-34': (
        ('Enthusiastic King', 'cond_cost', {'scope': 'self', 'all': True, 'when': ['own_name_in_play:Nidoqueen']}),
    ),
    'sv3pt5-40': (
        ('Expanding Body', 'self_hp_if_special_energy', {'amount': 100}),
    ),
    'sv3pt5-68': (
        ('Guts', 'survive_coin', {}),
    ),
    'sv3pt5-9': (
        ('Solid Shell', 'damage_reduction', {'amount': 30}),
    ),
    'sv4-121': (
        ('In a Hungry Hurry', 'no_retreat_cost', {'if_energy': 'none'}),
    ),
    'sv4-128': (
        ('Exoskeleton', 'damage_reduction', {'amount': 30}),
    ),
    'sv4-134': (
        ('Mysterious Shield', 'cond_prevent', {'mode': 'damage', 'scope': 'self', 'src': {'subtype': ['ex', 'V']}}),
    ),
    'sv4-206': (
        ('In a Hungry Hurry', 'no_retreat_cost', {'if_energy': 'none'}),
    ),
    'sv4-209': (
        ('Exoskeleton', 'damage_reduction', {'amount': 30}),
    ),
    'sv4-21': (
        ('Monkey Trio', 'cond_cost', {'scope': 'self', 'remove_all_colorless': True, 'when': ['own_name_in_play:Simisage|Simisear|Simipour']}),
    ),
    'sv4-210': (
        ('Mysterious Shield', 'cond_prevent', {'mode': 'damage', 'scope': 'self', 'src': {'subtype': ['ex', 'V']}}),
    ),
    'sv4-218': (
        ('Crimson Armor', 'cond_damage_taken', {'scope': 'self', 'amount': 80, 'when': ['full_hp']}),
    ),
    'sv4-224': (
        ('Gold Coffin', 'ko_followup_search_any', {}),
    ),
    'sv4-27': (
        ('Crimson Armor', 'cond_damage_taken', {'scope': 'self', 'amount': 80, 'when': ['full_hp']}),
    ),
    'sv4-42': (
        ('Monkey Trio', 'cond_cost', {'scope': 'self', 'remove_all_colorless': True, 'when': ['own_name_in_play:Simisage|Simisear|Simipour']}),
    ),
    'sv4-5': (
        ('Monkey Trio', 'cond_cost', {'scope': 'self', 'remove_all_colorless': True, 'when': ['own_name_in_play:Simisage|Simisear|Simipour']}),
    ),
    'sv4-76': (
        ('Gold Coffin', 'ko_followup_search_any', {}),
    ),
    'sv4pt5-107': (
        ('Double Type', 'types_are', {'types': ['Grass', 'Fire']}),
    ),
    'sv4pt5-110': (
        ('Flare Veil', 'self_attack_effect_immune', {}),
    ),
    'sv4pt5-112': (
        ('Pressure', 'opp_active_damage_reduction', {'amount': 20, 'holder_active_only': True}),
    ),
    'sv4pt5-138': (
        ('Electricity Pouches', 'cond_status_immune', {'scope': 'self', 'statuses': ['paralyzed']}),
    ),
    'sv4pt5-139': (
        ('Adverse Weather', 'cond_prevent', {'mode': 'damage', 'scope': 'team', 'target': {'zone': 'bench'}, 'when': ['active']}),
    ),
    'sv4pt5-160': (
        ('Safeguard', 'cond_prevent', {'mode': 'damage', 'scope': 'self', 'src': {'subtype': ['ex', 'V']}}),
    ),
    'sv4pt5-161': (
        ('Well-Baked Body', 'cond_status_immune', {'scope': 'self', 'statuses': ['burned']}),
        ('Well-Baked Body', 'cond_prevent', {'mode': 'damage', 'scope': 'self', 'src': {'type': 'Fire'}}),
    ),
    'sv4pt5-178': (
        ('Blessed Salt', 'between_turns_heal', {'amount': 20, 'scope': 'team'}),
    ),
    'sv4pt5-187': (
        ('Leadership', 'cond_attack_bonus', {'scope': 'team', 'amount': 30, 'target': {'basic': True}}),
    ),
    'sv4pt5-213': (
        ('Protective Mycelium', 'team_attack_effect_immune_if_energy', {}),
    ),
    'sv4pt5-214': (
        ('Dazzling Gaze', 'cond_cost', {'scope': 'team', 'affects': 'opp', 'add_colorless': 1, 'target': {'zone': 'active'}, 'when': ['active']}),
    ),
    'sv4pt5-218': (
        ('Dust Field', 'cond_bench_limit', {'affects': 'opp', 'limit': 3, 'when': ['active']}),
    ),
    'sv4pt5-222': (
        ('Expanding Body', 'self_hp_if_special_energy', {'amount': 100}),
    ),
    'sv4pt5-244': (
        ('Cursed Land', 'cond_ability_lock', {'affects': 'opp', 'when': ['active'], 'target': {'damaged': True}, 'except_subtype': ['ex']}),
    ),
    'sv4pt5-37': (
        ('Safeguard', 'cond_prevent', {'mode': 'damage', 'scope': 'self', 'src': {'subtype': ['ex', 'V']}}),
    ),
    'sv4pt5-39': (
        ('Well-Baked Body', 'cond_status_immune', {'scope': 'self', 'statuses': ['burned']}),
        ('Well-Baked Body', 'cond_prevent', {'mode': 'damage', 'scope': 'self', 'src': {'type': 'Fire'}}),
    ),
    'sv4pt5-5': (
        ('Protective Mycelium', 'team_attack_effect_immune_if_energy', {}),
    ),
    'sv4pt5-6': (
        ('Dazzling Gaze', 'cond_cost', {'scope': 'team', 'affects': 'opp', 'add_colorless': 1, 'target': {'zone': 'active'}, 'when': ['active']}),
    ),
    'sv4pt5-97': (
        ('Drifting Dodge', 'coin_prevent', {}),
    ),
    'sv4pt5-98': (
        ('Drifting Dodge', 'coin_prevent', {}),
    ),
    'sv5-10': (
        ('Solid Shell', 'damage_reduction', {'amount': 20}),
    ),
    'sv5-104': (
        ('Gnawing Curse', 'cond_attach_counters', {'n': 2}),
    ),
    'sv5-139': (
        ('Automated Combat', 'retaliate_counters', {'counters': 3}),
    ),
    'sv5-173': (
        ('Memory Dive', 'team_borrow_previous_evolutions', {}),
    ),
    'sv5-189': (
        ('Azure Seas', 'ignore_defender_effects', {}),
    ),
    'sv5-191': (
        ('Cobalt Command', 'cond_attack_bonus', {'scope': 'team', 'amount': 20, 'target': {'subtype': ['Future'], 'not_name': 'Iron Crown ex'}, 'nostack': 'Cobalt Command'}),
    ),
    'sv5-193': (
        ('Gnawing Curse', 'cond_attach_counters', {'n': 2}),
    ),
    'sv5-205': (
        ('Azure Seas', 'ignore_defender_effects', {}),
    ),
    'sv5-206': (
        ('Cobalt Command', 'cond_attack_bonus', {'scope': 'team', 'amount': 20, 'target': {'subtype': ['Future'], 'not_name': 'Iron Crown ex'}, 'nostack': 'Cobalt Command'}),
    ),
    'sv5-215': (
        ('Azure Seas', 'ignore_defender_effects', {}),
    ),
    'sv5-216': (
        ('Cobalt Command', 'cond_attack_bonus', {'scope': 'team', 'amount': 20, 'target': {'subtype': ['Future'], 'not_name': 'Iron Crown ex'}, 'nostack': 'Cobalt Command'}),
    ),
    'sv5-50': (
        ('Azure Seas', 'ignore_defender_effects', {}),
    ),
    'sv5-8': (
        ('Poison Point', 'retaliate_status', {'statuses': ['poisoned']}),
    ),
    'sv5-81': (
        ('Cobalt Command', 'cond_attack_bonus', {'scope': 'team', 'amount': 20, 'target': {'subtype': ['Future'], 'not_name': 'Iron Crown ex'}, 'nostack': 'Cobalt Command'}),
    ),
    'sv5-84': (
        ('Memory Dive', 'team_borrow_previous_evolutions', {}),
    ),
    'sv5-9': (
        ('Poison Point', 'retaliate_status', {'statuses': ['poisoned']}),
    ),
    'sv6-111': (
        ('Adrena-Power', 'cond_hp', {'scope': 'self', 'amount': 100, 'when': ['energy_type:Darkness']}),
        ('Adrena-Power', 'cond_attack_bonus', {'scope': 'self', 'amount': 100, 'when': ['energy_type:Darkness']}),
    ),
    'sv6-123': (
        ('Incandescent Body', 'retaliate_status', {'statuses': ['burned']}),
    ),
    'sv6-171': (
        ('Storehouse Hideaway', 'bench_attack_immune_full', {}),
    ),
    'sv6-199': (
        ('Cornerstone Stance', 'cond_prevent', {'mode': 'damage', 'scope': 'self', 'src': {'has_ability': True}}),
    ),
    'sv6-2': (
        ('Thicket Body', 'damage_reduction', {'amount': 30}),
    ),
    'sv6-20': (
        ('Storehouse Hideaway', 'bench_attack_immune_full', {}),
    ),
    'sv6-215': (
        ('Cornerstone Stance', 'cond_prevent', {'mode': 'damage', 'scope': 'self', 'src': {'has_ability': True}}),
    ),
    'sv6pt5-37': (
        ("Oh No You Don't", 'ko_fewer_prize_if_named_in_play', {'name': 'Pecharunt ex'}),
    ),
    'sv6pt5-42': (
        ('Massive Body', 'cond_lock', {'affects': 'opp', 'what': ['stadium'], 'when': ['active']}),
    ),
    'sv6pt5-45': (
        ('Unnerve', 'self_card_effect_shield', {'kinds': ['item', 'supporter']}),
    ),
    'sv6pt5-74': (
        ('Adrena-Power', 'cond_hp', {'scope': 'self', 'amount': 100, 'when': ['energy_type:Darkness']}),
        ('Adrena-Power', 'cond_attack_bonus', {'scope': 'self', 'amount': 100, 'when': ['energy_type:Darkness']}),
    ),
    'sv6pt5-77': (
        ('Unnerve', 'self_card_effect_shield', {'kinds': ['item', 'supporter']}),
    ),
    'sv6pt5-83': (
        ("Oh No You Don't", 'ko_fewer_prize_if_named_in_play', {'name': 'Pecharunt ex'}),
    ),
    'sv6pt5-91': (
        ("Oh No You Don't", 'ko_fewer_prize_if_named_in_play', {'name': 'Pecharunt ex'}),
    ),
    'sv7-107': (
        ('Metal Bridge', 'cond_retreat', {'scope': 'team', 'target': {'has_energy_type': 'Metal'}}),
    ),
    'sv7-125': (
        ('Soft Wool', 'damage_reduction', {'amount': 30}),
    ),
    'sv7-129': (
        ('Protective Cover', 'self_attack_effect_immune', {}),
    ),
    'sv7-149': (
        ('Food Prep', 'cond_cost', {'scope': 'self', 'remove_colorless': 1, 'per': 'own_discard_name_part', 'per_arg': 'Kofu'}),
    ),
    'sv7-155': (
        ('Metal Bridge', 'cond_retreat', {'scope': 'team', 'target': {'has_energy_type': 'Metal'}}),
    ),
    'sv7-30': (
        ('Solid Shell', 'damage_reduction', {'amount': 30}),
    ),
    'sv7-42': (
        ('Food Prep', 'cond_cost', {'scope': 'self', 'remove_colorless': 1, 'per': 'own_discard_name_part', 'per_arg': 'Kofu'}),
    ),
    'sv7-45': (
        ('Food Prep', 'cond_cost', {'scope': 'self', 'remove_colorless': 1, 'per': 'own_discard_name_part', 'per_arg': 'Kofu'}),
    ),
    'sv7-89': (
        ('Salty Body', 'status_immune_self', {}),
    ),
    'sv8-150': (
        ('Expert Hider', 'coin_prevent', {}),
    ),
    'sv8-200': (
        ('Counterattack', 'retaliate_counters', {'counters': 3}),
    ),
    'sv8-201': (
        ('Solid Body', 'damage_reduction', {'amount': 30}),
    ),
    'sv8-213': (
        ('Expert Hider', 'coin_prevent', {}),
    ),
    'sv8-216': (
        ('Double Type', 'types_are', {'types': ['Grass', 'Fire']}),
    ),
    'sv8-217': (
        ('Sparkling Scales', 'cond_prevent', {'mode': 'all', 'scope': 'self', 'src': {'subtype': ['Tera']}}),
    ),
    'sv8-219': (
        ('Resolute Heart', 'survive_full_hp', {}),
    ),
    'sv8-220': (
        ('Skyliner', 'cond_retreat', {'scope': 'team', 'target': {'basic': True}}),
    ),
    'sv8-237': (
        ('Sparkling Scales', 'cond_prevent', {'mode': 'all', 'scope': 'self', 'src': {'subtype': ['Tera']}}),
    ),
    'sv8-238': (
        ('Resolute Heart', 'survive_full_hp', {}),
    ),
    'sv8-239': (
        ('Skyliner', 'cond_retreat', {'scope': 'team', 'target': {'basic': True}}),
    ),
    'sv8-247': (
        ('Resolute Heart', 'survive_full_hp', {}),
    ),
    'sv8-31': (
        ('Unaware', 'self_attack_effect_immune', {}),
    ),
    'sv8-37': (
        ('Double Type', 'types_are', {'types': ['Grass', 'Fire']}),
    ),
    'sv8-42': (
        ('Sparkling Scales', 'cond_prevent', {'mode': 'all', 'scope': 'self', 'src': {'subtype': ['Tera']}}),
    ),
    'sv8-49': (
        ('Counterattack', 'retaliate_counters', {'counters': 3}),
    ),
    'sv8-54': (
        ('Solid Body', 'damage_reduction', {'amount': 30}),
    ),
    'sv8-57': (
        ('Resolute Heart', 'survive_full_hp', {}),
    ),
    'sv8pt5-158': (
        ('Cobalt Command', 'cond_attack_bonus', {'scope': 'team', 'amount': 20, 'target': {'subtype': ['Future'], 'not_name': 'Iron Crown ex'}, 'nostack': 'Cobalt Command'}),
    ),
    'sv8pt5-160': (
        ('Cornerstone Stance', 'cond_prevent', {'mode': 'damage', 'scope': 'self', 'src': {'has_ability': True}}),
    ),
    'sv8pt5-178': (
        ('Azure Seas', 'ignore_defender_effects', {}),
    ),
    'sv8pt5-179': (
        ('Resolute Heart', 'survive_full_hp', {}),
    ),
    'sv8pt5-40': (
        ('Safeguard', 'cond_prevent', {'mode': 'damage', 'scope': 'self', 'src': {'subtype': ['ex']}}),
    ),
    'sv8pt5-57': (
        ('Adrena-Power', 'cond_hp', {'scope': 'self', 'amount': 100, 'when': ['energy_type:Darkness']}),
        ('Adrena-Power', 'cond_attack_bonus', {'scope': 'self', 'amount': 100, 'when': ['energy_type:Darkness']}),
    ),
    'sv8pt5-67': (
        ('Protective Bell', 'cond_damage_taken', {'scope': 'team', 'amount': 10}),
    ),
    'sv8pt5-70': (
        ('Metal Bridge', 'cond_retreat', {'scope': 'team', 'target': {'has_energy_type': 'Metal'}}),
    ),
    'sv8pt5-77': (
        ('Insomnia', 'cond_status_immune', {'scope': 'self', 'statuses': ['asleep']}),
    ),
    'sv8pt5-88': (
        ('Fur Coat', 'damage_reduction', {'amount': 20}),
    ),
    'sv9-107': (
        ('Auto Heal', 'team_on_attach_heal_while_active', {'amount': 90}),
    ),
    'sv9-128': (
        ('Tuning Echo', 'ignore_cost_if_hand_equal_for_attack', {'attack': 'Frightening Howl'}),
    ),
    'sv9-160': (
        ('Exploding Needles', 'ko_retaliate_counters', {'counters': 6, 'active_only': True}),
    ),
    'sv9-21': (
        ('Magma Surge', 'burn_counters', {'counters': 5}),
    ),
    'sv9-37': (
        ('Vibrant Dance', 'team_hp_bonus', {'amount': 40, 'no_stack_key': 'Vibrant Dance'}),
    ),
    'sv9-7': (
        ('Sunny Day', 'cond_attack_bonus', {'scope': 'team', 'amount': 20, 'target': {'type': ['Grass', 'Fire']}}),
    ),
    'sv9-8': (
        ('Exploding Needles', 'ko_retaliate_counters', {'counters': 6, 'active_only': True}),
    ),
    'sv9-89': (
        ('Secret Forest Path', 'bench_active_retreat_reduction', {'amount': 2}),
    ),
    'svp-125': (
        ('Crimson Armor', 'cond_damage_taken', {'scope': 'self', 'amount': 80, 'when': ['full_hp']}),
    ),
    'svp-127': (
        ('Azure Seas', 'ignore_defender_effects', {}),
    ),
    'svp-134': (
        ('Food Prep', 'cond_cost', {'scope': 'self', 'remove_colorless': 1, 'per': 'own_discard_name_part', 'per_arg': 'Kofu'}),
    ),
    'svp-139': (
        ('Mist Float', 'cond_retreat', {'scope': 'self', 'when': ['energy_type:Psychic']}),
    ),
    'svp-146': (
        ('Cobalt Command', 'cond_attack_bonus', {'scope': 'team', 'amount': 20, 'target': {'subtype': ['Future'], 'not_name': 'Iron Crown ex'}, 'nostack': 'Cobalt Command'}),
    ),
    'svp-184': (
        ('Extra Helpings', 'team_attack_bonus', {'attacker_name_prefix': "Hop's", 'amount': 30, 'no_stack_key': 'Extra Helpings'}),
    ),
    'svp-49': (
        ('Voltaic Float', 'cond_retreat', {'scope': 'self', 'when': ['energy_type:Lightning']}),
    ),
    'svp-60': (
        ('Mysterious Shield', 'cond_prevent', {'mode': 'damage', 'scope': 'self', 'src': {'subtype': ['ex', 'V']}}),
    ),
    'svp-75': (
        ('Safeguard', 'cond_prevent', {'mode': 'damage', 'scope': 'self', 'src': {'subtype': ['ex', 'V']}}),
    ),
    'swsh1-110': (
        ('Sand Sac', 'damage_reduction', {'amount': 30}),
    ),
    'swsh1-128': (
        ('Steely Spirit', 'team_attack_bonus', {'attacker_type': 'Metal', 'amount': 20}),
    ),
    'swsh1-196': (
        ('Dauntless Shield', 'cond_prevent', {'mode': 'damage', 'scope': 'self', 'src': {'subtype': ['VMAX']}}),
    ),
    'swsh1-212': (
        ('Dauntless Shield', 'cond_prevent', {'mode': 'damage', 'scope': 'self', 'src': {'subtype': ['VMAX']}}),
    ),
    'swsh1-51': (
        ('Poison Point', 'retaliate_status', {'statuses': ['poisoned']}),
    ),
    'swsh10-112': (
        ('Heatproof', 'cond_prevent', {'mode': 'damage', 'scope': 'self', 'src': {'type': 'Fire'}}),
    ),
    'swsh10-126': (
        ('Miracle Body', 'cond_prevent', {'mode': 'damage', 'scope': 'self', 'src': {'subtype': ['V']}}),
    ),
    'swsh10-48': (
        ('Massive Ice', 'damage_reduction', {'amount': 30}),
    ),
    'swsh10-66': (
        ('Mental Shroud', 'team_no_weakness', {'requires_names': ['Uxie', 'Azelf']}),
    ),
    'swsh10-93': (
        ('Carry and Climb', 'bench_active_retreat_reduction', {'amount': 2}),
    ),
    'swsh10tg-TG19': (
        ('Fighting Instinct', 'cond_cost', {'scope': 'self', 'remove_colorless': 1, 'per': 'opp_in_play_subtype', 'per_arg': ['V']}),
    ),
    'swsh10tg-TG22': (
        ('Dauntless Shield', 'cond_prevent', {'mode': 'damage', 'scope': 'self', 'src': {'subtype': ['VMAX']}}),
    ),
    'swsh11-117': (
        ('Cursed Message', 'ko_followup_search_any', {}),
    ),
    'swsh11-118': (
        ('Wild Style', 'cond_cost', {'scope': 'self', 'remove_colorless': 1, 'per': 'opp_in_play_subtype', 'per_arg': ['Single Strike', 'Rapid Strike', 'Fusion Strike']}),
    ),
    'swsh11-182': (
        ('Wild Style', 'cond_cost', {'scope': 'self', 'remove_colorless': 1, 'per': 'opp_in_play_subtype', 'per_arg': ['Single Strike', 'Rapid Strike', 'Fusion Strike']}),
    ),
    'swsh11-52': (
        ('Pika Dash', 'cond_retreat', {'scope': 'self', 'when': ['energy_any']}),
    ),
    'swsh11tg-TG05': (
        ('Pika Dash', 'cond_retreat', {'scope': 'self', 'when': ['energy_any']}),
    ),
    'swsh11tg-TG09': (
        ('Cursed Message', 'ko_followup_search_any', {}),
    ),
    'swsh11tg-TG10': (
        ('Unfazed Fat', 'self_attack_effect_immune', {}),
    ),
    'swsh11tg-TG11': (
        ('Weather Reading', 'cond_cost', {'scope': 'self', 'all': True, 'when': ['stadiums_in_discard_at_least:8']}),
    ),
    'swsh11tg-TG22': (
        ('Eternal Zone', 'cond_bench_limit', {'affects': 'own', 'limit': 8, 'all_type': 'Darkness'}),
    ),
    'swsh12-102': (
        ('Hard Coat', 'damage_reduction', {'amount': 30}),
    ),
    'swsh12-38': (
        ('Jumbo-Sized', 'damage_reduction', {'amount': 30}),
    ),
    'swsh12-72': (
        ('Yoga Guard', 'bench_damage_immune', {}),
    ),
    'swsh12-78': (
        ('Persistent Cells', 'ko_return_to_hand', {}),
    ),
    'swsh12pt5-104': (
        ('Skyscraper', 'cond_prevent', {'mode': 'damage', 'scope': 'self', 'src': {'special_energy': True}}),
    ),
    'swsh12pt5-111': (
        ('Carefree Countenance', 'bench_damage_immune', {}),
    ),
    'swsh12pt5-20': (
        ('Excited Heart', 'cond_cost', {'scope': 'self', 'remove_colorless': 1, 'per': 'opp_prizes_taken'}),
    ),
    'swsh12pt5-21': (
        ('Explosive Heat Dash', 'cond_retreat', {'scope': 'self', 'when': ['energy_type:Fire']}),
    ),
    'swsh12pt5-97': (
        ('Metal Shield', 'damage_reduction_if_energy', {'amount': 30}),
    ),
    'swsh12pt5gg-GG24': (
        ('Miracle Body', 'cond_prevent', {'mode': 'damage', 'scope': 'self', 'src': {'subtype': ['V']}}),
    ),
    'swsh12pt5gg-GG29': (
        ('Carefree Countenance', 'bench_damage_immune', {}),
    ),
    'swsh12pt5gg-GG30': (
        ('Pika Dash', 'cond_retreat', {'scope': 'self', 'when': ['energy_any']}),
    ),
    'swsh12pt5gg-GG49': (
        ('Wild Style', 'cond_cost', {'scope': 'self', 'remove_colorless': 1, 'per': 'opp_in_play_subtype', 'per_arg': ['Single Strike', 'Rapid Strike', 'Fusion Strike']}),
    ),
    'swsh12pt5gg-GG53': (
        ('Two-Faced', 'types_are', {'types': ['Psychic', 'Darkness']}),
    ),
    'swsh12tg-TG08': (
        ('Throwing Coach', 'cond_attack_bonus', {'scope': 'team', 'amount': 30, 'target': {'subtype': ['Rapid Strike']}, 'src': {'subtype': ['V', 'GX'], 'zone': 'bench'}, 'nostack': 'Throwing Coach'}),
    ),
    'swsh12tg-TG19': (
        ('Lustrous Body', 'ability_effect_immune', {}),
    ),
    'swsh12tg-TG21': (
        ('Skyscraper', 'cond_prevent', {'mode': 'damage', 'scope': 'self', 'src': {'special_energy': True}}),
    ),
    'swsh12tg-TG30': (
        ('Skyscraper', 'cond_prevent', {'mode': 'damage', 'scope': 'self', 'src': {'special_energy': True}}),
    ),
    'swsh2-1': (
        ('Adaptive Evolution', 'evolve_on_play_turn', {}),
    ),
    'swsh2-100': (
        ('Submerge', 'bench_damage_immune', {}),
    ),
    'swsh2-110': (
        ('Iron Defense Formation', 'cond_damage_taken', {'scope': 'team', 'amount': 20, 'target': {'name_part': 'Falinks'}}),
    ),
    'swsh2-113': (
        ('Neutralizing Gas', 'cond_ability_lock', {'affects': 'opp', 'when': ['active'], 'except_ability': 'Neutralizing Gas'}),
    ),
    'swsh2-153': (
        ('Soft Wool', 'damage_reduction', {'amount': 30}),
    ),
    'swsh2-178': (
        ('Field Runner', 'cond_retreat', {'scope': 'self', 'when': ['stadium']}),
    ),
    'swsh2-185': (
        ('Iron Defense Formation', 'cond_damage_taken', {'scope': 'team', 'amount': 20, 'target': {'name_part': 'Falinks'}}),
    ),
    'swsh2-188': (
        ('Soft Wool', 'damage_reduction', {'amount': 30}),
    ),
    'swsh2-2': (
        ('Adaptive Evolution', 'evolve_on_play_turn', {}),
    ),
    'swsh2-205': (
        ('Steely Spirit', 'team_attack_bonus', {'attacker_type': 'Metal', 'amount': 20}),
    ),
    'swsh2-35': (
        ('Field Runner', 'cond_retreat', {'scope': 'self', 'when': ['stadium']}),
    ),
    'swsh2-54': (
        ('Ice Face', 'cond_damage_taken', {'scope': 'self', 'amount': 60, 'when': ['full_hp']}),
    ),
    'swsh2-79': (
        ('Perish Body', 'ko_coin_knockout_attacker', {'active_only': False}),
    ),
    'swsh2-80': (
        ('Counterattack', 'retaliate_counters', {'counters': 3}),
    ),
    'swsh2-91': (
        ('Infiltrator', 'coin_prevent', {}),
    ),
    'swsh3-107': (
        ('Limber', 'cond_status_immune', {'scope': 'self', 'statuses': ['paralyzed']}),
    ),
    'swsh3-11': (
        ('Sky Circus', 'cond_cost', {'scope': 'self', 'all': True, 'when': ['played_supporter_named:Bird Keeper']}),
    ),
    'swsh3-117': (
        ('Eternal Zone', 'cond_bench_limit', {'affects': 'own', 'limit': 8, 'all_type': 'Darkness'}),
    ),
    'swsh3-123': (
        ('Sturdy', 'survive_full_hp', {}),
    ),
    'swsh3-128': (
        ('Metal Skin', 'self_hp_per_energy', {'energy_type': 'Metal', 'amount': 20}),
    ),
    'swsh3-13': (
        ('Deep Forest Camo', 'cond_prevent', {'mode': 'damage', 'scope': 'self', 'src': {'subtype': ['V', 'GX']}}),
    ),
    'swsh3-132': (
        ('Antibacterial Skin', 'status_immune_self', {}),
    ),
    'swsh3-145': (
        ('Sky Circus', 'cond_cost', {'scope': 'self', 'all': True, 'when': ['played_supporter_named:Bird Keeper']}),
    ),
    'swsh3-149': (
        ('Sky Circus', 'cond_cost', {'scope': 'self', 'all': True, 'when': ['played_supporter_named:Bird Keeper']}),
    ),
    'swsh3-184': (
        ('Metal Skin', 'self_hp_per_energy', {'energy_type': 'Metal', 'amount': 20}),
    ),
    'swsh3-192': (
        ('Eternal Zone', 'cond_bench_limit', {'affects': 'own', 'limit': 8, 'all_type': 'Darkness'}),
    ),
    'swsh3-24': (
        ('Double Type', 'types_are', {'types': ['Fire', 'Fighting']}),
    ),
    'swsh3-32': (
        ('Scorching Feathers', 'retaliate_status', {'statuses': ['burned']}),
    ),
    'swsh3-66': (
        ('Biting Whirlpool', 'cond_attach_counters', {'n': 2}),
    ),
    'swsh3-91': (
        ('Labyrinth of Sand', 'opp_active_cant_retreat_while_active', {}),
    ),
    'swsh3-92': (
        ('Resistance Shade', 'cond_weakness', {'scope': 'team', 'affects': 'opp', 'fx': 'resistance', 'when': ['own_name_in_play:Lunatone']}),
    ),
    'swsh35-14': (
        ('Solid Shell', 'damage_reduction', {'amount': 30}),
    ),
    'swsh35-15': (
        ('Solid Shell', 'damage_reduction', {'amount': 30}),
    ),
    'swsh35-20': (
        ('Hazard Sensor', 'retaliate_status', {'statuses': ['confused']}),
    ),
    'swsh35-40': (
        ('Limber', 'cond_status_immune', {'scope': 'self', 'statuses': ['paralyzed']}),
    ),
    'swsh35-47': (
        ('Hard Coat', 'damage_reduction', {'amount': 30}),
    ),
    'swsh35-49': (
        ('Miraculous Charm', 'cond_prevent', {'mode': 'damage', 'scope': 'self', 'src': {'subtype': ['V', 'GX']}}),
    ),
    'swsh35-69': (
        ('Solid Shell', 'damage_reduction', {'amount': 30}),
    ),
    'swsh35-75': (
        ('Solid Shell', 'damage_reduction', {'amount': 30}),
    ),
    'swsh4-118': (
        ('Levitation Field', 'cond_retreat', {'scope': 'team', 'target': {'name': 'Pokémon'}}),
    ),
    'swsh4-125': (
        ('Counterattack', 'retaliate_counters', {'counters': 3}),
    ),
    'swsh4-35': (
        ('Swaddling Leaves', 'damage_reduction', {'amount': 30}),
    ),
    'swsh4-57': (
        ('Levitate', 'cond_retreat', {'scope': 'self', 'when': ['energy_any']}),
    ),
    'swsh4-74': (
        ('Unaware', 'self_attack_effect_immune', {}),
    ),
    'swsh4-79': (
        ('Sparkle Veil', 'team_damage_reduction', {'amount': 30, 'holder_active_only': True}),
    ),
    'swsh45-18': (
        ('Field Runner', 'cond_retreat', {'scope': 'self', 'when': ['stadium']}),
    ),
    'swsh45-27': (
        ('Exoskeleton', 'damage_reduction', {'amount': 30}),
    ),
    'swsh45-42': (
        ('Neutralizing Gas', 'cond_ability_lock', {'affects': 'opp', 'when': ['active'], 'except_ability': 'Neutralizing Gas'}),
    ),
    'swsh45-6': (
        ('Sky Circus', 'cond_cost', {'scope': 'self', 'all': True, 'when': ['played_supporter_named:Bird Keeper']}),
    ),
    'swsh45-8': (
        ('Deep Forest Camo', 'cond_prevent', {'mode': 'damage', 'scope': 'self', 'src': {'subtype': ['V', 'GX']}}),
    ),
    'swsh45sv-SV001': (
        ('Sky Circus', 'cond_cost', {'scope': 'self', 'all': True, 'when': ['played_supporter_named:Bird Keeper']}),
    ),
    'swsh45sv-SV003': (
        ('Deep Forest Camo', 'cond_prevent', {'mode': 'damage', 'scope': 'self', 'src': {'subtype': ['V', 'GX']}}),
    ),
    'swsh45sv-SV035': (
        ('Ice Face', 'cond_damage_taken', {'scope': 'self', 'amount': 60, 'when': ['full_hp']}),
    ),
    'swsh45sv-SV046': (
        ('Biting Whirlpool', 'cond_attach_counters', {'n': 2}),
    ),
    'swsh45sv-SV050': (
        ('Perish Body', 'ko_coin_knockout_attacker', {'active_only': False}),
    ),
    'swsh45sv-SV062': (
        ('Infiltrator', 'coin_prevent', {}),
    ),
    'swsh45sv-SV077': (
        ('Neutralizing Gas', 'cond_ability_lock', {'affects': 'opp', 'when': ['active'], 'except_ability': 'Neutralizing Gas'}),
    ),
    'swsh45sv-SV087': (
        ('Steely Spirit', 'team_attack_bonus', {'attacker_type': 'Metal', 'amount': 20}),
    ),
    'swsh45sv-SV091': (
        ('Antibacterial Skin', 'status_immune_self', {}),
    ),
    'swsh45sv-SV096': (
        ('Sky Circus', 'cond_cost', {'scope': 'self', 'all': True, 'when': ['played_supporter_named:Bird Keeper']}),
    ),
    'swsh45sv-SV115': (
        ('Iron Defense Formation', 'cond_damage_taken', {'scope': 'team', 'amount': 20, 'target': {'name_part': 'Falinks'}}),
    ),
    'swsh45sv-SV120': (
        ('Soft Wool', 'damage_reduction', {'amount': 30}),
    ),
    'swsh45sv-SV122': (
        ('Eternal Zone', 'cond_bench_limit', {'affects': 'own', 'limit': 8, 'all_type': 'Darkness'}),
    ),
    'swsh5-110': (
        ('Lustrous Body', 'ability_effect_immune', {}),
    ),
    'swsh5-118': (
        ('Sap Sipper', 'self_attack_bonus_vs_type', {'defender_type': 'Grass', 'amount': 60}),
    ),
    'swsh5-145': (
        ("Emperor's Eyes", 'cond_ability_lock', {'affects': 'opp', 'when': ['active'], 'target': {'basic': True}, 'except_subtype': ['ex', 'V', 'VSTAR', 'VMAX', 'GX', 'EX', 'TAG TEAM', 'MEGA']}),
    ),
    'swsh5-146': (
        ("Emperor's Eyes", 'cond_ability_lock', {'affects': 'opp', 'when': ['active'], 'target': {'basic': True}, 'except_subtype': ['ex', 'V', 'VSTAR', 'VMAX', 'GX', 'EX', 'TAG TEAM', 'MEGA']}),
    ),
    'swsh5-171': (
        ('Lustrous Body', 'ability_effect_immune', {}),
    ),
    'swsh5-40': (
        ("Emperor's Eyes", 'cond_ability_lock', {'affects': 'opp', 'when': ['active'], 'target': {'basic': True}, 'except_subtype': ['ex', 'V', 'VSTAR', 'VMAX', 'GX', 'EX', 'TAG TEAM', 'MEGA']}),
    ),
    'swsh5-70': (
        ('Battle Armor', 'damage_reduction', {'amount': 30}),
    ),
    'swsh5-94': (
        ('Insomnia', 'cond_status_immune', {'scope': 'self', 'statuses': ['asleep']}),
    ),
    'swsh6-101': (
        ('Bursting Needles', 'ko_retaliate_counters', {'counters': 6, 'active_only': True}),
    ),
    'swsh6-121': (
        ('Weather Reading', 'cond_cost', {'scope': 'self', 'all': True, 'when': ['stadiums_in_discard_at_least:8']}),
    ),
    'swsh6-173': (
        ('Fighting Instinct', 'cond_cost', {'scope': 'self', 'remove_colorless': 1, 'per': 'opp_in_play_subtype', 'per_arg': ['V']}),
    ),
    'swsh6-174': (
        ('Fighting Instinct', 'cond_cost', {'scope': 'self', 'remove_colorless': 1, 'per': 'opp_in_play_subtype', 'per_arg': ['V']}),
    ),
    'swsh6-175': (
        ('Wall of Sand', 'damage_reduction', {'amount': 30}),
    ),
    'swsh6-22': (
        ('Weather Reading', 'cond_cost', {'scope': 'self', 'all': True, 'when': ['stadiums_in_discard_at_least:8']}),
    ),
    'swsh6-28': (
        ('Crisis Power', 'cond_attack_bonus', {'scope': 'self', 'amount': 30, 'per': 'opp_prizes_taken'}),
    ),
    'swsh6-33': (
        ('Weather Reading', 'cond_cost', {'scope': 'self', 'all': True, 'when': ['stadiums_in_discard_at_least:8']}),
    ),
    'swsh6-34': (
        ('Weather Reading', 'cond_cost', {'scope': 'self', 'all': True, 'when': ['stadiums_in_discard_at_least:8']}),
    ),
    'swsh6-80': (
        ('Fighting Instinct', 'cond_cost', {'scope': 'self', 'remove_colorless': 1, 'per': 'opp_in_play_subtype', 'per_arg': ['V']}),
    ),
    'swsh6-88': (
        ('Throwing Coach', 'cond_attack_bonus', {'scope': 'team', 'amount': 30, 'target': {'subtype': ['Rapid Strike']}, 'src': {'subtype': ['V', 'GX'], 'zone': 'bench'}, 'nostack': 'Throwing Coach'}),
    ),
    'swsh6-89': (
        ('Wall of Sand', 'damage_reduction', {'amount': 30}),
    ),
    'swsh7-123': (
        ('Skyscraper', 'cond_prevent', {'mode': 'damage', 'scope': 'self', 'src': {'special_energy': True}}),
    ),
    'swsh7-135': (
        ('Intimidating Fang', 'opp_active_damage_reduction', {'amount': 30, 'holder_active_only': True}),
    ),
    'swsh7-208': (
        ('Crystal Veil', 'cond_prevent', {'mode': 'damage', 'scope': 'self', 'src': {'subtype': ['VMAX'], 'not_name': 'Glaceon VMAX'}}),
    ),
    'swsh7-209': (
        ('Crystal Veil', 'cond_prevent', {'mode': 'damage', 'scope': 'self', 'src': {'subtype': ['VMAX'], 'not_name': 'Glaceon VMAX'}}),
    ),
    'swsh7-219': (
        ('Skyscraper', 'cond_prevent', {'mode': 'damage', 'scope': 'self', 'src': {'special_energy': True}}),
    ),
    'swsh7-220': (
        ('Skyscraper', 'cond_prevent', {'mode': 'damage', 'scope': 'self', 'src': {'special_energy': True}}),
    ),
    'swsh7-41': (
        ('Crystal Veil', 'cond_prevent', {'mode': 'damage', 'scope': 'self', 'src': {'subtype': ['VMAX'], 'not_name': 'Glaceon VMAX'}}),
    ),
    'swsh7-46': (
        ('Group Power', 'cond_hp', {'scope': 'self', 'amount': 150, 'when': ['energy_type_at_least:Water:3']}),
    ),
    'swsh8-137': (
        ('Desperate Blast', 'ko_retaliate_counters', {'counters': 10, 'active_only': True}),
    ),
    'swsh8-143': (
        ('Guts', 'survive_coin', {}),
    ),
    'swsh8-2': (
        ('Exoskeleton', 'damage_reduction', {'amount': 20}),
    ),
    'swsh8-252': (
        ('Wall of Sand', 'damage_reduction', {'amount': 30}),
    ),
    'swsh8-253': (
        ('Two-Faced', 'types_are', {'types': ['Psychic', 'Darkness']}),
    ),
    'swsh8-51': (
        ('Shell Armor', 'damage_reduction', {'amount': 30}),
    ),
    'swsh9-12': (
        ('Lively Fruit', 'self_attack_effect_immune', {}),
    ),
    'swsh9-182': (
        ('Fighting Instinct', 'cond_cost', {'scope': 'self', 'remove_colorless': 1, 'per': 'opp_in_play_subtype', 'per_arg': ['V']}),
    ),
    'swshp-SWSH008': (
        ('Steely Spirit', 'team_attack_bonus', {'attacker_type': 'Metal', 'amount': 20}),
    ),
    'swshp-SWSH015': (
        ('Field Runner', 'cond_retreat', {'scope': 'self', 'when': ['stadium']}),
    ),
    'swshp-SWSH019': (
        ('Dauntless Shield', 'cond_prevent', {'mode': 'damage', 'scope': 'self', 'src': {'subtype': ['VMAX']}}),
    ),
    'swshp-SWSH034': (
        ('Sturdy Shield', 'damage_reduction', {'amount': 20}),
    ),
    'swshp-SWSH035': (
        ('Deep Forest Camo', 'cond_prevent', {'mode': 'damage', 'scope': 'self', 'src': {'subtype': ['V', 'GX']}}),
    ),
    'swshp-SWSH036': (
        ('Biting Whirlpool', 'cond_attach_counters', {'n': 2}),
    ),
    'swshp-SWSH045': (
        ('Eternal Zone', 'cond_bench_limit', {'affects': 'own', 'limit': 8, 'all_type': 'Darkness'}),
    ),
    'swshp-SWSH049': (
        ('Soft Wool', 'damage_reduction', {'amount': 30}),
    ),
    'swshp-SWSH072': (
        ('Watery Shroud', 'bench_damage_immune', {}),
    ),
    'swshp-SWSH077': (
        ('Dauntless Shield', 'cond_prevent', {'mode': 'damage', 'scope': 'self', 'src': {'subtype': ['VMAX']}}),
    ),
    'swshp-SWSH108': (
        ("Emperor's Eyes", 'cond_ability_lock', {'affects': 'opp', 'when': ['active'], 'target': {'basic': True}, 'except_subtype': ['ex', 'V', 'VSTAR', 'VMAX', 'GX', 'EX', 'TAG TEAM', 'MEGA']}),
    ),
    'swshp-SWSH112': (
        ('Crisis Power', 'cond_attack_bonus', {'scope': 'self', 'amount': 30, 'per': 'opp_prizes_taken'}),
    ),
    'swshp-SWSH115': (
        ('Throwing Coach', 'cond_attack_bonus', {'scope': 'team', 'amount': 30, 'target': {'subtype': ['Rapid Strike']}, 'src': {'subtype': ['V', 'GX'], 'zone': 'bench'}, 'nostack': 'Throwing Coach'}),
    ),
    'swshp-SWSH135': (
        ('Bladed Armament', 'ignore_defender_effects', {}),
    ),
    'swshp-SWSH155': (
        ('Antidote Jutsu', 'cond_status_immune', {'scope': 'self', 'statuses': ['poisoned']}),
        ('Ninja Body', 'self_card_effect_shield', {'kinds': ['item']}),
    ),
    'swshp-SWSH156': (
        ('Antidote Jutsu', 'cond_status_immune', {'scope': 'self', 'statuses': ['poisoned']}),
        ('Ninja Body', 'self_card_effect_shield', {'kinds': ['item']}),
    ),
    'swshp-SWSH157': (
        ('Antidote Jutsu', 'cond_status_immune', {'scope': 'self', 'statuses': ['poisoned']}),
        ('Ninja Body', 'self_card_effect_shield', {'kinds': ['item']}),
    ),
    'swshp-SWSH158': (
        ('Antidote Jutsu', 'cond_status_immune', {'scope': 'self', 'statuses': ['poisoned']}),
        ('Ninja Body', 'self_card_effect_shield', {'kinds': ['item']}),
    ),
    'swshp-SWSH159': (
        ('Photon Barrier', 'self_attack_effect_immune', {}),
    ),
    'swshp-SWSH160': (
        ('Photon Barrier', 'self_attack_effect_immune', {}),
    ),
    'swshp-SWSH161': (
        ('Photon Barrier', 'self_attack_effect_immune', {}),
    ),
    'swshp-SWSH162': (
        ('Photon Barrier', 'self_attack_effect_immune', {}),
    ),
    'swshp-SWSH176': (
        ('Two-Faced', 'types_are', {'types': ['Psychic', 'Darkness']}),
    ),
    'swshp-SWSH278': (
        ('Crisis Power', 'cond_attack_bonus', {'scope': 'self', 'amount': 30, 'per': 'opp_prizes_taken'}),
    ),
    'swshp-SWSH293': (
        ('Dauntless Shield', 'cond_prevent', {'mode': 'damage', 'scope': 'self', 'src': {'subtype': ['VMAX']}}),
    ),
    'xy1-114': (
        ('Fur Coat', 'damage_reduction', {'amount': 20}),
    ),
    'xy1-14': (
        ('Spiky Shield', 'retaliate_counters', {'counters': 3}),
    ),
    'xy1-44': (
        ('Destiny Burst', 'ko_coin_retaliate_counters', {'counters': 5, 'active_only': True}),
    ),
    'xy1-95': (
        ('Sweet Veil', 'team_status_immune_if_energy', {'energy_type': 'Fairy', 'statuses': 'all'}),
    ),
    'xy10-23': (
        ('Hand Block', 'opp_special_energy_attach_lock_if_stadium', {}),
    ),
    'xy10-43a': (
        ('Regi Power', 'team_attack_bonus', {'attacker_type': 'Fighting', 'exclude_name': 'Regirock-EX', 'amount': 10}),
    ),
    'xy10-50': (
        ('Safeguard', 'immune_from_attackers_with_subtype', {'subtype': 'EX'}),
    ),
    'xy10-61': (
        ('Metal Fortress', 'team_bench_attack_immune_full', {}),
    ),
    'xy10-72': (
        ('Sparkle Veil', 'team_damage_reduction', {'amount': 30, 'holder_active_only': True}),
    ),
    'xy10-78': (
        ('Pressure', 'opp_active_damage_reduction', {'amount': 20, 'holder_active_only': True}),
    ),
    'xy11-45': (
        ("King's Palace", 'team_attack_bonus', {'attacker_name': 'Nidoqueen', 'amount': 20}),
    ),
    'xy11-56': (
        ('Restored Barrier', 'team_no_weakness', {'defender_type': 'Restored'}),
    ),
    'xy11-59': (
        ('Poison Enzyme', 'immune_damage_from_poisoned_attackers', {}),
    ),
    'xy11-7': (
        ('Sonic Vision', 'ignore_colorless_cost_if_hand_count', {'hand_owner': 'self', 'count': 4, 'all_energy': True}),
    ),
    'xy11-73': (
        ('Heavy Bumper', 'damage_reduction_per_opp_retreat', {'amount_per': 10}),
    ),
    'xy12-11': (
        ('Energy Burn', 'energy_is_type', {'type': 'Fire'}),
    ),
    'xy12-53': (
        ('Neutral Shield', 'immune_from_evolution_attackers', {}),
    ),
    'xy12-55': (
        ('Submerge', 'bench_damage_immune', {}),
    ),
    'xy12-59': (
        ('Counterattack', 'retaliate_counters', {'counters': 3}),
    ),
    'xy2-1': (
        ('Adaptive Evolution', 'evolve_on_play_turn', {}),
    ),
    'xy2-2': (
        ('Adaptive Evolution', 'evolve_on_play_turn', {}),
    ),
    'xy2-20': (
        ('Intimidating Mane', 'immune_from_basic_attackers', {}),
    ),
    'xy2-21': (
        ('Counterattack Quills', 'retaliate_counters', {'counters': 2}),
    ),
    'xy2-64': (
        ('Flower Veil', 'team_hp_bonus', {'type': 'Grass', 'amount': 20}),
    ),
    'xy2-71': (
        ('Poison Barrier', 'opp_poisoned_cant_retreat', {}),
    ),
    'xy2-80': (
        ('Stir and Snooze', 'sleep_flip_count', {'count': 2}),
    ),
    'xy3-18': (
        ("King's Song", 'team_ignore_colorless_cost_for_names', {'names': ['Poliwag', 'Poliwhirl', 'Poliwrath']}),
    ),
    'xy3-26': (
        ('Ice Shield', 'team_damage_reduction', {'defender_type': 'Water', 'energy_type': 'Water', 'amount': 20}),
    ),
    'xy3-46': (
        ('Fighting Fury', 'team_attack_bonus', {'attacker_type': 'Fighting', 'amount': 20}),
    ),
    'xy3-52': (
        ('Thick Fat', 'damage_reduction', {'amount': 30, 'attacker_types': ['Fire', 'Water']}),
    ),
    'xy3-63': (
        ('Shining Spirit', 'ignore_weakness_resistance', {}),
    ),
    'xy3-64': (
        ('Counterattack', 'retaliate_counters', {'counters': 2}),
    ),
    'xy3-73': (
        ('Secret Key', 'team_resistance_override', {'defender_type': 'Fairy', 'value': '-40'}),
    ),
    'xy3-77': (
        ('Echolocation', 'coin_prevent', {}),
    ),
    'xy4-36': (
        ('Bide Barricade', 'global_ability_lock_except_type', {'except_type': 'Psychic'}),
    ),
    'xy4-43': (
        ('Fainting Spell', 'ko_coin_knockout_attacker', {'active_only': False}),
    ),
    'xy4-45': (
        ('Gourgantic', 'self_hp_set_if_energy', {'energy_type': 'Grass', 'hp': 200}),
    ),
    'xy4-50': (
        ('High Density Armor', 'damage_reduction_conditional', {'if_full_hp': True, 'amount': 50}),
    ),
    'xy4-65a': (
        ('Mighty Shield', 'immune_damage_from_attackers_with_special_energy', {}),
    ),
    'xy4-77': (
        ('Slip Trip', 'global_tool_attach_lock', {}),
    ),
    'xy5-100': (
        ('Miracle Guard', 'team_no_weakness', {}),
    ),
    'xy5-119': (
        ('Sap Sipper', 'self_attack_bonus_vs_type', {'defender_type': 'Grass', 'amount': 40}),
    ),
    'xy5-21': (
        ('Barrier Shrine', 'global_stadium_play_lock', {}),
    ),
    'xy5-77': (
        ('Rock Wall', 'team_damage_reduction', {'amount': 10}),
    ),
    'xy6-103': (
        ('Dragon Road', 'team_retreat_reduction_if_stadium', {'type': 'Dragon', 'amount': 2}),
    ),
    'xy6-17': (
        ('Δ Plus', 'bonus_prize_on_ko', {'amount': 1}),
    ),
    'xy6-31': (
        ('Tool Concealment', 'global_tools_disabled', {}),
    ),
    'xy6-47': (
        ('Jewel Armor', 'bench_damage_immune', {}),
    ),
    'xy6-5': (
        ('Miraculous Scales', 'immune_damage_from_attackers_with_subtype', {'subtype': 'EX'}),
    ),
    'xy6-56': (
        ('Exoskeleton', 'damage_reduction', {'amount': 10}),
    ),
    'xy6-62': (
        ('Dragon Road', 'team_retreat_reduction_if_stadium', {'type': 'Dragon', 'amount': 2}),
    ),
    'xy6-74': (
        ('Clear Humming', 'team_no_weakness', {'defender_type': 'Colorless'}),
    ),
    'xy7-22': (
        ('Aqua Effect', 'team_add_type_to_stage', {'stage': 'Stage 1', 'type': 'Water'}),
    ),
    'xy7-26': (
        ('Electric Effect', 'team_add_type_to_stage', {'stage': 'Stage 1', 'type': 'Lightning'}),
    ),
    'xy7-35': (
        ('Double Type', 'types_are', {'types': ['Psychic', 'Fighting']}),
    ),
    'xy7-57': (
        ('Renegade Pulse', 'immune_from_attackers_with_subtype', {'subtype': 'MEGA'}),
    ),
    'xy7-93': (
        ('Renegade Pulse', 'immune_from_attackers_with_subtype', {'subtype': 'MEGA'}),
    ),
    'xy8-103': (
        ('Calming Aroma', 'team_attack_cost_remove_type', {'type': 'Fairy'}),
    ),
    'xy8-117': (
        ('Retreat Aid', 'bench_active_retreat_reduction', {'amount': 2}),
    ),
    'xy8-118': (
        ('Plump Body', 'damage_reduction', {'amount': 30}),
    ),
    'xy8-38': (
        ('Dignified Fighter', 'team_attack_bonus', {'attacker_basic': True, 'amount': 20}),
    ),
    'xy8-51': (
        ('Sparkling Induction', 'self_retreat_reduction_per_bench_name', {'name': 'Magnemite', 'amount_per': 1}),
    ),
    'xy8-55': (
        ('Shining Body', 'damage_reduction_conditional', {'if_energy_type': 'Lightning', 'amount': 20}),
    ),
    'xy8-70': (
        ('My Way', 'no_retreat_if_stadium', {}),
    ),
    'xy8-82': (
        ('Thick Fat', 'damage_reduction', {'amount': 30, 'attacker_types': ['Fire', 'Water']}),
    ),
    'xy8-94': (
        ('Fright Night', 'global_tools_disabled_while_active', {}),
    ),
    'xy9-116': (
        ('Aqua Tube', 'team_no_retreat_if_energy', {'energy_type': 'Water'}),
    ),
    'xy9-3': (
        ('Overgrow', 'self_attack_bonus_if_low_hp', {'hp': 50, 'amount': 70}),
    ),
    'xy9-30': (
        ('Wind Charm', 'team_attack_effect_immune_while_active', {}),
    ),
    'xy9-32': (
        ('Aqua Tube', 'team_no_retreat_if_energy', {'energy_type': 'Water'}),
    ),
    'xy9-49': (
        ('Zap Zone', 'team_ignore_defender_effects', {'attacker_type': 'Lightning'}),
    ),
    'xy9-65': (
        ('Nervous Seed', 'opp_basic_attack_cost_increase', {'amount': 1, 'active_only': True}),
    ),
    'xy9-88': (
        ('Antibodies', 'status_immune_self', {}),
    ),
    'xyp-184': (
        ('Devour Light', 'break_no_abilities', {}),
    ),
    'xyp-XY10': (
        ('Poison Barrier', 'opp_poisoned_cant_retreat', {}),
    ),
    'xyp-XY102': (
        ('Frozen Charm', 'team_status_immune_if_energy', {'energy_type': 'Water', 'statuses': ['paralyzed']}),
    ),
    'xyp-XY118': (
        ('Justified', 'self_attack_bonus_vs_type', {'defender_type': 'Darkness', 'amount': 50}),
    ),
    'xyp-XY13': (
        ('Fighting Fury', 'team_attack_bonus', {'attacker_type': 'Fighting', 'amount': 20}),
    ),
    'xyp-XY144': (
        ('Sonic Vision', 'ignore_colorless_cost_if_hand_count', {'hand_owner': 'self', 'count': 4, 'all_energy': True}),
    ),
    'xyp-XY163': (
        ('Levitate', 'no_retreat_cost', {'if_energy': 'any'}),
    ),
    'xyp-XY178': (
        ('Lamentation', 'retaliate_discard_random_hand', {}),
    ),
    'xyp-XY179': (
        ('Immunity', 'status_immune_self', {}),
    ),
    'xyp-XY184': (
        ('Devour Light', 'break_no_abilities', {}),
    ),
    'xyp-XY191': (
        ('Justified', 'self_attack_bonus_vs_type', {'defender_type': 'Darkness', 'amount': 50}),
    ),
    'xyp-XY40': (
        ('Metamorphosis Gene', 'borrow_attacks', {'sources': 'opp_active'}),
    ),
    'xyp-XY46': (
        ('Clear Humming', 'team_no_weakness', {'defender_type': 'Colorless'}),
    ),
    'xyp-XY47': (
        ('Dry Skin', 'damage_reduction', {'amount': 30, 'attacker_types': ['Water']}),
    ),
    'xyp-XY48': (
        ('Mysterious Ears', 'retaliate_status', {'statuses': ['confused']}),
    ),
    'xyp-XY50': (
        ('Benevolent Boss', 'self_hp_per_bench', {'amount': 20}),
    ),
    'xyp-XY58': (
        ('Contrary', 'opp_coins_tails_while_active', {}),
    ),
    'xyp-XY64': (
        ('Ozone Wall', 'bench_damage_immune', {}),
    ),
    'xyp-XY70': (
        ('Despotic Fang', 'ignore_defender_effects', {}),
    ),
    'xyp-XY82': (
        ('Earthen Awakening', 'on_self_attach_heal', {'amount': 20}),
    ),
    'xyp-XY94': (
        ('Nervous Seed', 'opp_basic_attack_cost_increase', {'amount': 1, 'active_only': True}),
    ),
    'zsv10pt5-107': (
        ('Mighty Shell', 'immune_from_attackers_with_special_energy', {}),
    ),
    'zsv10pt5-127': (
        ('Craftsmanship', 'self_hp_per_energy', {'energy_type': 'Fighting', 'amount': 40}),
    ),
    'zsv10pt5-159': (
        ('Debut Performance', 'attack_on_first_turn', {}),
    ),
    'zsv10pt5-164': (
        ('Regal Cheer', 'team_attack_bonus', {'amount': 20}),
    ),
    'zsv10pt5-167': (
        ('Debut Performance', 'attack_on_first_turn', {}),
    ),
    'zsv10pt5-23': (
        ('Mighty Shell', 'immune_from_attackers_with_special_energy', {}),
    ),
    'zsv10pt5-3': (
        ('Regal Cheer', 'team_attack_bonus', {'amount': 20}),
    ),
    'zsv10pt5-44': (
        ('Debut Performance', 'attack_on_first_turn', {}),
    ),
    'zsv10pt5-49': (
        ('Craftsmanship', 'self_hp_per_energy', {'energy_type': 'Fighting', 'amount': 40}),
    ),
    'zsv10pt5-56': (
        ('Poison Point', 'retaliate_status', {'statuses': ['poisoned']}),
    ),
    'zsv10pt5-63': (
        ('Gear Coating', 'team_damage_reduction', {'energy_type': 'Metal', 'amount': 20}),
    ),
    'zsv10pt5-80': (
        ('Protective Cover', 'self_attack_effect_immune', {}),
    ),
    'zsv10pt5-9': (
        ('Stimulated Evolution', 'evolve_on_play_turn', {'if_in_play': 'Shelmet'}),
    ),
    'zsv10pt5-94': (
        ('Stimulated Evolution', 'evolve_on_play_turn', {'if_in_play': 'Shelmet'}),
    ),
}

GENERATED_ABILITY_EFFECTS: dict[str, dict] = {
    'bw1-20': {
        # As often as you like during your turn (before your attack), you may attach a Fire Energy card from your hand to 1 of your Pokémon.
        'Inferno Fandango': (AttachEnergyGeneric(source='hand', energy_type='Fire'),),
    },
    'bw1-57': {
        # As often as you like during your turn (before your attack), you may move 1 damage counter from 1 of your Pokémon to another of your Pokémon.
        'Damage Swap': (MoveDamageCountersFreely(src='own', dest='other_own', count=1),),
    },
    'bw1-76': {
        # As often as you like during your turn (before your attack), you may move a Metal Energy attached to 1 of your Pokémon to another of your Pokémon.
        'Shift Gear': (MoveEnergyGeneric(owner='own', energy_type='Metal'),),
    },
    'bw10-104': {
        # As often as you like during your turn (before your attack), you may move 1 damage counter from 1 of your opponent's Pokémon to another of your opponen
        'Sinister Hand': (MoveDamageCountersFreely(src='opp', dest='other_opp', count=1),),
    },
    'bw10-2': {
        # As often as you like during your turn (before your attack), you may put a Pokémon Tool card attached to 1 of your Pokémon into your hand.
        'Tool Reversal': (PickPokemonThen(action='tool_to_hand', has_tool=True),),
    },
    'bw10-74': {
        # As often as you like during your turn (before your attack), you may move a Plasma Energy attached to 1 of your Pokémon to another of your Pokémon.
        'Plasma Transfer': (MoveEnergyGeneric(owner='own', energy_name='Plasma Energy'),),
    },
    'bw11-27': {
        # As often as you like during your turn (before your attack), you may attach a Fire Energy card from your hand to 1 of your Pokémon.
        'Inferno Fandango': (AttachEnergyGeneric(source='hand', energy_type='Fire'),),
    },
    'bw11-45': {
        # Once during your turn (before your attack), if this Pokémon is on your Bench, you may switch this Pokémon with your Active Pokémon.
        'Rush In': (AbilityGate('bench_only', ''), SwitchSelfFromBenchToActive(),),
    },
    'bw11-99': {
        # As often as you like during your turn (before your attack), you may move a Darkness Energy attached to 1 of your Pokémon to another of your Pokémon.
        'Dark Trance': (MoveEnergyGeneric(owner='own', energy_type='Darkness'),),
    },
    'bw2-62': {
        # Once during your turn (before your attack), if this Pokémon is your Active Pokémon, you may flip a coin. If heads, discard an Energy attached to your 
        'Black Eyes': (AbilityGate('active_only', ''), FlipCoinThen(heads=(DiscardOpponentActiveEnergy(),), tails=()),),
    },
    'bw3-40': {
        # Once during your turn (before your attack), you may attach a Lightning Energy card from your discard pile to 1 of your Benched Pokémon.
        'Dynamotor': (AttachEnergyGeneric(source='discard', energy_type='Lightning', bench_only=True),),
    },
    'bw3-60': {
        # Once during your turn (before your attack), if this Pokémon is your Active Pokémon, you may put 3 damage counters on your opponent's Pokémon in any wa
        'Cursed Shadow': (AbilityGate('active_only', ''), DistributeDamageCountersFreely(3),),
    },
    'bw4-100': {
        # As often as you like during your turn (before your attack), you may attach a Fire Energy card from your hand to 1 of your Pokémon.
        'Inferno Fandango': (AttachEnergyGeneric(source='hand', energy_type='Fire'),),
    },
    'bw4-101': {
        # Once during your turn (before your attack), if this Pokémon is your Active Pokémon, you may put 3 damage counters on your opponent's Pokémon in any wa
        'Cursed Shadow': (AbilityGate('active_only', ''), DistributeDamageCountersFreely(3),),
    },
    'bw4-33': {
        # Once during your turn (before your attack), you may switch your Active Pokémon with 1 of your Benched Pokémon. If you do, your opponent switches his o
        'Slippery Soles': (PickPokemonThen(action='switch_own_active', bench_only=True, then=(ForceOpponentSwitchOpponentChooses(),)),),
    },
    'bw4-59': {
        # Once during your turn (before your attack), you may look at the top 2 cards of your deck, choose 1 of them, and put it into your hand. Put the other c
        'Forewarn': (LookTopNTakeOneRestOnTop(2),),
    },
    'bw5-29': {
        # Once during your turn (before your attack), you may discard 1 card from your hand. If you do, draw 2 cards.
        'Diving Draw': (MayDiscardHandCardThenDraw(draw_count=2),),
    },
    'bw5-3': {
        # Once during your turn (before your attack), you may search your deck for a Pokémon, reveal it, and put it into your hand. Shuffle your deck afterward.
        'Floral Fragrance': (SearchDeckForPokemonToHand(count=1),),
    },
    'bw5-82': {
        # Once during your turn (before your attack), you may flip a coin. If heads, heal 30 damage from your Active Pokémon.
        'Softboiled': (FlipCoinThen(heads=(HealOwnActiveFixed(30),), tails=()),),
    },
    'bw6-126': {
        # As often as you like during your turn (before your attack), you may move 1 damage counter from 1 of your Pokémon to another of your Pokémon.
        'Damage Swap': (MoveDamageCountersFreely(src='own', dest='other_own', count=1),),
    },
    'bw6-3': {
        # Once during your turn (before your attack), you may return this Pokémon and all cards attached to it to your hand.
        'Leave It to the Wind': (ReturnSelfToHandUnconditional(),),
    },
    'bw6-89': {
        # Once during your turn (before your attack), you may search your deck for a Dragon Pokémon, reveal it, and put it into your hand. Shuffle your deck aft
        'Dragon Call': (SearchDeckForPokemonToHand(count=1, pokemon_type='Dragon'),),
    },
    'bw6-97': {
        # As often as you like during your turn (before your attack), you may move a Darkness Energy attached to 1 of your Pokémon to another of your Pokémon.
        'Dark Trance': (MoveEnergyGeneric(owner='own', energy_type='Darkness'),),
    },
    'bw7-142': {
        # Once during your turn (before your attack), if this Pokémon is on your Bench, you may switch this Pokémon with your Active Pokémon.
        'Rush In': (AbilityGate('bench_only', ''), SwitchSelfFromBenchToActive(),),
    },
    'bw7-31': {
        # As often as you like during your turn (before your attack), you may attach a Water Energy card from your hand to 1 of your Pokémon.
        'Deluge': (AttachEnergyGeneric(source='hand', energy_type='Water'),),
    },
    'bw7-63': {
        # As often as you like during your turn (before your attack), you may move 1 damage counter from 1 of your opponent's Pokémon to another of your opponen
        'Sinister Hand': (MoveDamageCountersFreely(src='opp', dest='other_opp', count=1),),
    },
    'bw7-68': {
        # Once during your turn (before your attack), you may flip a coin. If heads, your opponent's Active Pokémon is now Asleep. If tails, your Active Pokémon
        'Long-Distance Hypnosis': (FlipCoinThen(heads=(InflictStatusOnDefender('asleep'),), tails=(InflictStatusOnOwnActive('asleep'),)),),
    },
    'bw8-116': {
        # Once during your turn (before your attack), if this Pokémon is your Active Pokémon, you may have your opponent switch his or her Active Pokémon with 1
        'Big Wing': (AbilityGate('active_only', ''), ForceOpponentSwitchOpponentChooses(),),
    },
    'bw8-137': {
        # As often as you like during your turn (before your attack), you may attach a Water Energy card from your hand to 1 of your Pokémon.
        'Deluge': (AttachEnergyGeneric(source='hand', energy_type='Water'),),
    },
    'bw8-55': {
        # Once during your turn (before your attack), you may draw a card.
        'Night Sight': (Draw(1),),
    },
    'bw8-7': {
        # Once during your turn (before your attack), you may heal 20 damage from 1 of your Pokémon that has any Grass Energy attached to it.
        'Fair-Weather Heal': (PickPokemonThen(action='heal', amount=20, damaged_only=True, require_energy_type='Grass'),),
    },
    'bw8-73': {
        # Once during your turn (before your attack), you may look at the top 2 cards of your deck and put them back on top of your deck in any order.
        'Premonition': (LookTopNReorderOnTop(2),),
    },
    'bw8-98': {
        # Once during your turn (before your attack), you may flip a coin. If heads, search your deck for a card that evolves from 1 of your Pokémon and put it 
        'Moon Guidance': (FlipCoinThen(heads=(InstantEvolveAnyOwnPokemonFromDeck(),), tails=()),),
    },
    'bw9-117': {
        # Once during your turn (before your attack), you may discard 1 card from your hand. Then, draw 2 cards.
        'Diving Draw': (MayDiscardHandCardThenDraw(draw_count=2),),
    },
    'bw9-16': {
        # Once during your turn (before your attack), you may search your deck for a Fire Energy card and attach it to 1 of your Pokémon. If you do, put 1 damag
        'Flare Navigate': (AttachEnergyGeneric(source='deck', energy_type='Fire', counters_on_target=1),),
    },
    'bw9-33': {
        # Once during your turn (before your attack), you may draw cards until you have 4 cards in your hand.
        'Magnetic Draw': (DrawUpTo(4),),
    },
    'bw9-52': {
        # Once during your turn (before your attack), you may search your deck for a Team Plasma card, reveal it, and put it in your hand. Shuffle your deck aft
        'Plasma Search': (AbilityGate('name_not_used', 'Plasma Search'), MarkAbilityNameUsed('Plasma Search'), SearchDeckForTeamPlasmaCardToHand(),),
    },
    'bw9-56': {
        # Once during your turn (before your attack) you may Knock Out this Pokémon. If you do, put 3 damage counters on your opponent's Pokémon in any way you 
        'Six Feet Under': (DistributeDamageCountersFreely(3), KnockOutSelfEffect(),),
    },
    'bwp-BW21': {
        # As often as you like during your turn (before your attack), you may attach a Fire Energy card from your hand to 1 of your Pokémon.
        'Inferno Fandango': (AttachEnergyGeneric(source='hand', energy_type='Fire'),),
    },
    'bwp-BW51': {
        # Once during your turn (before your attack), you may draw a card.
        'Night Sight': (Draw(1),),
    },
    'bwp-BW61': {
        # Once during your turn (before your attack), if this Pokémon is on your Bench, you may switch this Pokémon with your Active Pokémon.
        'Rush In': (AbilityGate('bench_only', ''), SwitchSelfFromBenchToActive(),),
    },
    'bwp-BW75': {
        # Once during your turn (before your attack), you may search your deck for a Team Plasma card, reveal it, and put it in your hand. Shuffle your deck aft
        'Plasma Search': (AbilityGate('name_not_used', 'Plasma Search'), MarkAbilityNameUsed('Plasma Search'), SearchDeckForTeamPlasmaCardToHand(),),
    },
    'bwp-BW84': {
        # As often as you like during your turn (before your attack), you may move a Plasma Energy attached to 1 of your Pokémon to another of your Pokémon.
        'Plasma Transfer': (MoveEnergyGeneric(owner='own', energy_name='Plasma Energy'),),
    },
    'bwp-BW98': {
        # Once during your turn (before your attack), if this Pokémon is your Active Pokémon, you may have your opponent reveal his or her hand.
        'Psyscan': (AbilityGate('active_only', ''), RevealOpponentHandOnly(),),
    },
    'cel25-21': {
        # Once during your turn, if this Pokémon is on your Bench, you may switch it with your Active Pokémon.
        'Rush In': (AbilityGate('bench_only', ''), SwitchSelfFromBenchToActive(),),
    },
    'cel25-25': {
        # Once during your turn, if this Pokémon is in the Active Spot, you may look at the top 6 cards of your deck, reveal an Item card you find there, and pu
        'Mysterious Tail': (AbilityGate('active_only', ''), LookTopNTake(n=6, m=1, criterion='item', exact=False, rest='shuffle'),),
    },
    'dc1-11': {
        # Once during your turn (before your attack), you may move a basic Energy from 1 of your Pokémon to 1 of your Team Magma Pokémon.
        'Magma Switch': (MoveEnergyGeneric(owner='own', sources='any', dests='any', basic_only=True, dest_name_prefix="Team Magma's"),),
    },
    'dc1-2': {
        # Once during your turn (before your attack), you may attach a Fighting or Fire Energy card from your discard pile to this Pokémon.
        'Burning Draft': (AttachDiscardCardsToSelf(energy_types=('Fighting', 'Fire'), count=1),),
    },
    'dc1-21': {
        # Once during your turn (before your attack), you may search your deck for a Team Aqua Pokémon, reveal it, and put it into your hand. Shuffle your deck 
        'Aqua Search': (SearchDeckForSubtypePokemonToHand('Team Aqua'),),
    },
    'det1-2': {
        # Once during your turn (before your attack), you may heal 30 damage from 1 of your Pokémon.
        'Table Service': (HealTarget(30),),
    },
    'dv1-8': {
        # Once during your turn (before your attack), you may have your opponent discard cards from his or her hand until he or she has 4 cards left in his or h
        'Scornful Storm': (OpponentDiscardHandDownTo(4),),
    },
    'g1-36': {
        # Once during your turn (before your attack), if this Pokémon is on your Bench, you may heal 10 damage from your Active Pokémon.
        'Victory Kiss': (AbilityGate('bench_only', ''), HealOwnActiveFixed(10),),
    },
    'g1-37': {
        # Once during your turn (before your attack), if this Pokémon is your Active Pokémon, you may move 1 damage counter from 1 of your Pokémon to 1 of your 
        'Shadow Ear': (AbilityGate('active_only', ''), PickPokemonThen(side='own', action='take_counters', amount=1, damaged_only=True, then=(PickPokemonThen(side='opp', action='give_counters'),)),),
    },
    'g1-RC28': {
        # Once during your turn (before your attack), you may move a Fire Energy from 1 of your Pokémon to this Pokémon.
        'Flash Fire': (MoveChosenOwnFireEnergyToSelf(count=1),),
    },
    'g1-RC6': {
        # Once during your turn (before your attack), you may move a Fire Energy from 1 of your Pokémon to this Pokémon.
        'Flash Fire': (MoveChosenOwnFireEnergyToSelf(count=1),),
    },
    'me1-11': {
        # Once during your turn, if this Pokémon has any Grass Energy attached, you may use this Ability. Heal 30 damage from 1 of your Pokémon.
        'Fermented Juice': (AbilityGate('self_has_energy', 'Grass'), PickPokemonThen(action='heal', amount=30, damaged_only=True),),
    },
    'me1-110': {
        # Once during your turn, you may use this Ability. Switch a card from your hand with the top card of your deck.
        'Evidence Gathering': (SwapHandCardWithDeckTop(),),
    },
    'me1-136': {
        # Once during your turn, if this Pokémon has any Grass Energy attached, you may use this Ability. Heal 30 damage from 1 of your Pokémon.
        'Fermented Juice': (AbilityGate('self_has_energy', 'Grass'), PickPokemonThen(action='heal', amount=30, damaged_only=True),),
    },
    'me1-153': {
        # Once during your turn, you may use this Ability. Switch a card from your hand with the top card of your deck.
        'Evidence Gathering': (SwapHandCardWithDeckTop(),),
    },
    'me1-74': {
        # Once during your turn, if you have Solrock in play, you may discard a Basic Fighting Energy card from your hand in order to use this Ability. Draw 3 c
        'Lunar Cycle': (AbilityGate('has_named_pokemon_in_play', 'Solrock'), AbilityGate('hand_has_basic_energy', 'Fighting'), AbilityGate('name_not_used', 'Lunar Cycle'), MarkAbilityNameUsed('Lunar Cycle'), DiscardFromHandBasicEnergyAsCost('Fighting', then=(Draw(3),)),),
    },
    'me2-103': {
        # Once during your turn, you may use this Ability. Search your deck for a Basic Darkness Energy card and attach it to 1 of your Benched Darkness Pokémon
        'Sinister Surge': (AttachEnergyGeneric(source='deck', count=1, basic_only=True, energy_type='Darkness', bench_only=True, target_type='Darkness', counters_on_target=2),),
    },
    'me2-110': {
        # As often as you like during your turn, if you have any Fire Mega Evolution Pokémon ex in play, you may use this Ability. Attach a Basic Fire Energy ca
        'Excited Turbo': (AbilityGate('mega_ex_in_play', 'Fire'), AbilityGate('hand_has_basic_energy', 'Fire'), AttachEnergyFromHandToChosenOwnPokemon('Fire', target_type='Fire', bench_only=True),),
    },
    'me2-18': {
        # As often as you like during your turn, if you have any Fire Mega Evolution Pokémon ex in play, you may use this Ability. Attach a Basic Fire Energy ca
        'Excited Turbo': (AbilityGate('mega_ex_in_play', 'Fire'), AbilityGate('hand_has_basic_energy', 'Fire'), AttachEnergyFromHandToChosenOwnPokemon('Fire', target_type='Fire', bench_only=True),),
    },
    'me2-68': {
        # Once during your turn, you may use this Ability. Search your deck for a Basic Darkness Energy card and attach it to 1 of your Benched Darkness Pokémon
        'Sinister Surge': (AttachEnergyGeneric(source='deck', count=1, basic_only=True, energy_type='Darkness', bench_only=True, target_type='Darkness', counters_on_target=2),),
    },
    'me2-7': {
        # Once during your turn, if you have any Grass Mega Evolution Pokémon ex in play, you may use this Ability. Heal 60 damage from 1 of your Pokémon.
        'Excited Heal': (AbilityGate('mega_ex_in_play', 'Grass'), PickPokemonThen(action='heal', amount=60, damaged_only=True),),
    },
    'me2-82': {
        # Once during your turn, if this Pokémon is on your Bench, and if you have any Mega Evolution Pokémon ex in play, you may use this Ability. Switch this 
        'Excited Dash': (AbilityGate('bench_only', ''), AbilityGate('mega_ex_in_play', ''), SwitchSelfFromBenchToActive(),),
    },
    'me2-95': {
        # Once during your turn, if you have any Grass Mega Evolution Pokémon ex in play, you may use this Ability. Heal 60 damage from 1 of your Pokémon.
        'Excited Heal': (AbilityGate('mega_ex_in_play', 'Grass'), PickPokemonThen(action='heal', amount=60, damaged_only=True),),
    },
    'me2pt5-175': {
        # Once during your turn, if this Pokémon is on your Bench, you may use this Ability. Attach an Energy card from your hand to your Active Larry's Pokémon
        'Lethargic Charge': (AbilityGate('bench_only', ''), AttachEnergyGeneric(source='hand', count=1, active_only=True, target_name_prefix="Larry's"),),
    },
    'me2pt5-229': {
        # Once during your turn, if you played Canari from your hand this turn, you may use this Ability. Search your deck for up to 2 Basic Lightning Energy ca
        'Frilled Generator': (AbilityGate('played_supporter_named', 'Canari'), SearchDeckAndAttachEnergy('Lightning', count=2, self_only=True),),
    },
    'me2pt5-26': {
        # Once during your turn, you may attach up to 2 Basic Fire Energy cards from your hand to 1 of your Benched Ethan's Pokémon.
        'Golden Flame': (AttachEnergyGeneric(source='hand', count=2, energy_type='Fire', basic_only=True, bench_only=True, single_target=True, optional=True, target_name_prefix="Ethan's"),),
    },
    'me2pt5-279': {
        # As often as you like during your turn, you may attach a Basic Lightning Energy card from your hand to 1 of your Iono's Pokémon.
        'Electric Streamer': (AttachEnergyGeneric(source='hand', energy_type='Lightning', basic_only=True, target_name_prefix="Iono's"),),
    },
    'me2pt5-289': {
        # Once during your turn, you may search your deck for a Basic Psychic Energy card, a Basic Metal Energy card, or 1 of each and attach them to your Psych
        'X-Boot': (AttachEnergyGeneric(source='deck', count=2, energy_types_any=('Psychic', 'Metal'), distinct_energy_types=True, basic_only=True, target_types_any=('Psychic', 'Metal')),),
    },
    'me2pt5-64': {
        # Once during your turn, if you played Canari from your hand this turn, you may use this Ability. Search your deck for up to 2 Basic Lightning Energy ca
        'Frilled Generator': (AbilityGate('played_supporter_named', 'Canari'), SearchDeckAndAttachEnergy('Lightning', count=2, self_only=True),),
    },
    'me2pt5-70': {
        # As often as you like during your turn, you may attach a Basic Lightning Energy card from your hand to 1 of your Iono's Pokémon.
        'Electric Streamer': (AttachEnergyGeneric(source='hand', energy_type='Lightning', basic_only=True, target_name_prefix="Iono's"),),
    },
    'me2pt5-84': {
        # As often as you like during your turn, you may use this Ability. Move an Energy from 1 of your other Pokémon to this Pokémon.
        'Bubble Gathering': (MoveEnergyGeneric(owner='own', sources='any', dests='self'),),
    },
    'me3-19': {
        # As often as you like during your turn, you may use this Ability. Move a Water Energy from 1 of your Benched Pokémon to your Active Pokémon.
        'Wash Out': (MoveEnergyGeneric(owner='own', sources='bench', dests='active', energy_type='Water'),),
    },
    'me3-9': {
        # Once during your turn, you may use this Ability. Your opponent shuffles their hand and puts it on the bottom of their deck. If they put any cards on t
        'Grand Wing': (OpponentHandToBottomOfDeckThenDraw(4),),
    },
    'me4-100': {
        # Once during your turn, if this Pokémon is in the Active Spot, you may discard a Basic Water Energy card from your hand in order to use this Ability. P
        'Mortal Shuriken': (AbilityGate('active_only', ''), AbilityGate('hand_has_basic_energy', 'Water'), DiscardFromHandBasicEnergyAsCost('Water', then=(DistributeDamageCountersFreely(6),)),),
    },
    'me4-116': {
        # Once during your turn, if this Pokémon is in the Active Spot, you may discard a Basic Water Energy card from your hand in order to use this Ability. P
        'Mortal Shuriken': (AbilityGate('active_only', ''), AbilityGate('hand_has_basic_energy', 'Water'), DiscardFromHandBasicEnergyAsCost('Water', then=(DistributeDamageCountersFreely(6),)),),
    },
    'me4-122': {
        # Once during your turn, if this Pokémon is in the Active Spot, you may discard a Basic Water Energy card from your hand in order to use this Ability. P
        'Mortal Shuriken': (AbilityGate('active_only', ''), AbilityGate('hand_has_basic_energy', 'Water'), DiscardFromHandBasicEnergyAsCost('Water', then=(DistributeDamageCountersFreely(6),)),),
    },
    'me4-13': {
        # Once during your turn, you may discard a Basic Fire Energy card from your hand in order to use this Ability. Draw cards until you have 7 cards in your
        'Flaring Magic': (AbilityGate('hand_has_basic_energy', 'Fire'), DiscardFromHandBasicEnergyAsCost('Fire', then=(DrawUpTo(7),)),),
    },
    'me4-22': {
        # Once during your turn, if this Pokémon is in the Active Spot, you may discard a Basic Water Energy card from your hand in order to use this Ability. P
        'Mortal Shuriken': (AbilityGate('active_only', ''), AbilityGate('hand_has_basic_energy', 'Water'), DiscardFromHandBasicEnergyAsCost('Water', then=(DistributeDamageCountersFreely(6),)),),
    },
    'me4-38': {
        # Once during your turn, you may use this Ability. Choose a card in your hand that evolves from this Pokémon and put it onto this Pokémon to evolve it. 
        'Spiteful Evolution': (EvolveSelfFromHand(counters=2),),
    },
    'me4-51': {
        # Once during your turn, if this Pokémon is in the Active Spot, you may use this Ability. Search your deck for a card. Shuffle your deck, then put that 
        'Nighttime Maneuvers': (AbilityGate('active_only', ''), SearchDeckToTopOfDeck(count=1),),
    },
    'me4-93': {
        # Once during your turn, if this Pokémon is in the Active Spot, you may use this Ability. Search your deck for a card. Shuffle your deck, then put that 
        'Nighttime Maneuvers': (AbilityGate('active_only', ''), SearchDeckToTopOfDeck(count=1),),
    },
    'me5-100': {
        # Once during your turn, if this Pokémon is in the Active Spot, you may use this Ability. Flip a coin. If heads, discard an Energy from your opponent's 
        'Destructive Headbutting': (AbilityGate('active_only', ''), FlipCoinThen(heads=(DiscardOpponentActiveEnergy(),), tails=()),),
    },
    'me5-45': {
        # Once during your turn, if this Pokémon is in the Active Spot, you may use this Ability. Flip a coin. If heads, discard an Energy from your opponent's 
        'Destructive Headbutting': (AbilityGate('active_only', ''), FlipCoinThen(heads=(DiscardOpponentActiveEnergy(),), tails=()),),
    },
    'me5-68': {
        # Once during your turn, you may use this Ability. Draw a card.
        'Aerial Draw': (Draw(1),),
    },
    'me5-70': {
        # Once during your turn, if you have no cards in your hand, you may use this Ability. Search your deck for a Supporter card, reveal it, and put it into 
        'Call a Buddy': (AbilityGate('hand_empty', ''), SearchDeckByCriterionToHand('supporter'),),
    },
    'me5-94': {
        # Once during your turn, you may use this Ability. Draw a card.
        'Aerial Draw': (Draw(1),),
    },
    'me5-95': {
        # Once during your turn, if you have no cards in your hand, you may use this Ability. Search your deck for a Supporter card, reveal it, and put it into 
        'Call a Buddy': (AbilityGate('hand_empty', ''), SearchDeckByCriterionToHand('supporter'),),
    },
    'pgo-17': {
        # Once during your turn, you may search your deck for up to 6 Energy cards and attach them to your Pokémon in any way you like. Then, shuffle your deck.
        'Vitality Spring': (AttachEnergyGeneric(source='deck', count=6, optional=True), EndTurnAfterThisAbility(),),
    },
    'pgo-18': {
        # You must discard a Water Energy card from your hand in order to use this Ability. Once during your turn, you may put 2 damage counters on 1 of your op
        'Pump Shot': (AbilityGate('hand_matches', 'energy_type:Water:1'), DiscardMatchingFromHand('energy_type:Water', 1), PickPokemonThen(side='opp', action='put_counters', amount=2, bench_only=True),),
    },
    'pgo-39': {
        # Once during your turn, you may attach a Psychic Energy card from your discard pile to 1 of your Lunatone.
        'Sun Energy': (AttachEnergyGeneric(source='discard', count=1, basic_only=True, energy_type='Psychic', single_target=True, target_names=('Lunatone',)),),
    },
    'rsv10pt5-145': {
        # Once during your turn, you may use this Ability. Your opponent reveals their hand, and you put a Basic Pokémon with 70 HP or less that you find there 
        'Look for Prey': (PutOpponentHandBasicsOnTheirBench(max_hp=70, limit=1),),
    },
    'rsv10pt5-64': {
        # Once during your turn, you may use this Ability. Your opponent reveals their hand, and you put a Basic Pokémon with 70 HP or less that you find there 
        'Look for Prey': (PutOpponentHandBasicsOnTheirBench(max_hp=70, limit=1),),
    },
    'sm1-110': {
        # Once during your turn (before your attack), you may have your opponent reveal their hand.
        'Search the Premises': (RevealOpponentHand(),),
    },
    'sm1-12': {
        # Once during your turn (before your attack), you may put 2 damage counters on 1 of your opponent's Pokémon.
        'Feather Arrow': (DamageCounterOnChosenOpponentPokemon(count=2),),
    },
    'sm1-141': {
        # As often as you like during your turn (before your attack), you may move a Psychic Energy from 1 of your Pokémon to another of your Pokémon.
        'Psychic Transfer': (MoveEnergyGeneric(owner='own', sources='any', dests='any', energy_type='Psychic', basic_only=False),),
    },
    'sm1-143': {
        # Once during your turn (before your attack), you may switch your Active Pokémon with 1 of your Benched Pokémon.
        'Ultra Road': (SwitchActiveWithBench(),),
    },
    'sm1-145': {
        # Once during your turn (before your attack), you may have your opponent reveal their hand.
        'Search the Premises': (RevealOpponentHand(),),
    },
    'sm1-153': {
        # As often as you like during your turn (before your attack), you may move a Psychic Energy from 1 of your Pokémon to another of your Pokémon.
        'Psychic Transfer': (MoveEnergyGeneric(owner='own', sources='any', dests='any', energy_type='Psychic', basic_only=False),),
    },
    'sm1-155': {
        # Once during your turn (before your attack), you may switch your Active Pokémon with 1 of your Benched Pokémon.
        'Ultra Road': (SwitchActiveWithBench(),),
    },
    'sm1-157': {
        # Once during your turn (before your attack), you may have your opponent reveal their hand.
        'Search the Premises': (RevealOpponentHand(),),
    },
    'sm1-17': {
        # Once during your turn (before your attack), you may search your deck for a Grass Pokémon, reveal it, and put it into your hand. Then, shuffle your dec
        'Illuminate': (SearchDeckForPokemonToHand(count=1, pokemon_type='Grass'),),
    },
    'sm1-52': {
        # Once during your turn (before your attack), you may search your deck for a Grass Energy card and a Lightning Energy card and attach them to your Pokém
        'Strong Charge': (AttachEnergyGeneric(source='deck', count=2, energy_types_any=('Grass', 'Lightning'), distinct_energy_types=True),),
    },
    'sm1-66': {
        # As often as you like during your turn (before your attack), you may move a Psychic Energy from 1 of your Pokémon to another of your Pokémon.
        'Psychic Transfer': (MoveEnergyGeneric(owner='own', sources='any', dests='any', energy_type='Psychic', basic_only=False),),
    },
    'sm1-93': {
        # Once during your turn (before your attack), you may heal 20 damage from 1 of your Pokémon.
        'Curative Pollen': (HealTarget(20),),
    },
    'sm10-100': {
        # Once during your turn (before your attack), you may flip a coin. If heads, put 3 damage counters on 1 of your opponent's Pokémon. If you use this Abil
        'Bratty Kick': (FlipCoinThen(heads=(DamageCounterOnChosenOpponentPokemon(count=3),), tails=()), EndTurnAfterThisAbility(),),
    },
    'sm10-129': {
        # Once during your turn (before your attack), you may discard a Metal Pokémon from your hand. If you do, heal 100 damage from this Pokémon.
        'Metal Eater': (AbilityGate('hand_matches', 'type_pokemon:Metal:1'), DiscardMatchingFromHand('type_pokemon:Metal', 1), HealSelf(100),),
    },
    'sm10-131': {
        # Once during your turn (before your attack), you may flip a coin. If heads, shuffle your hand into your deck and then draw 6 cards. If you use this Abi
        'Excitable Draw': (FlipCoinThen(heads=(ShuffleHandIntoDeckThenDraw(6),), tails=()), EndTurnAfterThisAbility(),),
    },
    'sm10-138': {
        # Once during your turn (before your attack), you may heal 30 damage from each of your Fairy Pokémon.
        'Fairy Feast': (HealAllOwnPokemonOfType(pokemon_type='Fairy', amount=30),),
    },
    'sm10-157': {
        # As often as you like during your turn (before your attack), you may attach a Special Energy card from your hand to 1 of your Pokémon.
        'Crazy Code': (AttachEnergyGeneric(source='hand', energy_name='Special Energy'),),
    },
    'sm10-161': {
        # Once during your turn (before your attack), you may flip a coin. If heads, heal 60 damage from 1 of your Pokémon. If you use this Ability, your turn e
        'Playhouse Heal': (FlipCoinThen(heads=(HealTarget(60),), tails=()), EndTurnAfterThisAbility(),),
    },
    'sm10-2': {
        # Once during your turn (before your attack), you may flip a coin. If heads, search your deck for a card that evolves from this Pokémon and put it onto 
        'Pupate': (FlipCoinThen(heads=(InstantEvolveSelfFromDeck(),), tails=()),),
    },
    'sm10-3': {
        # Once during your turn (before your attack), you may flip a coin. If heads, search your deck for a card that evolves from this Pokémon and put it onto 
        'Emerge': (FlipCoinThen(heads=(InstantEvolveSelfFromDeck(),), tails=()),),
    },
    'sm10-31': {
        # Once during your turn (before your attack), you may discard a Fire Energy card from your hand. If you do, draw 3 cards.
        'Roast Reveal': (DiscardOwnHandBasicEnergyOfChoiceThenDraw(draw_count=3, energy_type='Fire'),),
    },
    'sm11-132': {
        # As often as you like during your turn (before your attack), you may move a basic Darkness Energy from 1 of your Pokémon to another of your Pokémon.
        'Shadow Connection': (MoveEnergyGeneric(owner='own', sources='any', dests='any', energy_type='Darkness', basic_only=True),),
    },
    'sm11-151': {
        # Once during your turn (before your attack), you may attach a Water Energy card, a Lightning Energy card, or 1 of each from your hand to your Pokémon i
        'Hurricane Charge': (AttachEnergyGeneric(source='hand', count=2, energy_types_any=('Water', 'Lightning'), distinct_energy_types=True),),
    },
    'sm11-173': {
        # Once during your turn (before your attack), you may flip a coin. If heads, put a card from your discard pile on top of your deck. If you use this Abil
        'Snack Search': (FlipCoinThen(heads=(PutDiscardCardOnTopOfDeck(),), tails=()), EndTurnAfterThisAbility(),),
    },
    'sm11-177': {
        # Once during your turn (before your attack), if this Pokémon is your Active Pokémon, you may draw a card.
        'Hearing': (AbilityGate('active_only', ''), Draw(1),),
    },
    'sm11-19': {
        # Once during your turn (before your attack), you may attach a Grass Energy card from your discard pile to your Active Pokémon.
        'Queenly Reward': (AttachEnergyGeneric(source='discard', count=1, basic_only=True, energy_type='Grass', active_only=True, single_target=True),),
    },
    'sm11-230': {
        # Once during your turn (before your attack), you may discard an Ultra Beast card from your hand. If you do, draw 3 cards.
        'Ultra Conversion': (AbilityGate('hand_matches', 'ultra_beast:1'), DiscardMatchingFromHand('ultra_beast', 1), Draw(3),),
    },
    'sm11-249': {
        # Once during your turn (before your attack), you may discard an Ultra Beast card from your hand. If you do, draw 3 cards.
        'Ultra Conversion': (AbilityGate('hand_matches', 'ultra_beast:1'), DiscardMatchingFromHand('ultra_beast', 1), Draw(3),),
    },
    'sm11-36': {
        # Once during your turn (before your attack), you may put a Misty's Favor card from your discard pile into your hand.
        "Mermaid's Call": (SearchDiscardByCriterionToHand("named:Misty's Favor", count=1),),
    },
    'sm11-76': {
        # Once during your turn (before your attack), you may move 1 damage counter from 1 of your Pokémon to another of your Pokémon.
        'Ominous Posture': (MoveDamageCounters(count=1, scope='own'),),
    },
    'sm11-77': {
        # Once during your turn (before your attack), you may flip a coin. If heads, choose a random card from your opponent's hand. Your opponent reveals that 
        'Peppy Pick': (FlipCoinThen(heads=(RandomOpponentHandCardToDeck(),), tails=()), EndTurnAfterThisAbility(),),
    },
    'sm12-117': {
        # Once during your turn (before your attack), you may search your deck for a card, shuffle your deck, then put that card on top of it.
        'Bulldoze': (SearchDeckPutOnTop('any'),),
    },
    'sm12-146': {
        # Once during your turn (before your attack), you may flip a coin. If heads, attach a basic Energy card from your discard pile to your Active Pokémon. I
        'Growing Up': (FlipCoinThen(heads=(AttachEnergyGeneric(source='discard', count=1, basic_only=True, active_only=True, single_target=True),), tails=()), EndTurnAfterThisAbility(),),
    },
    'sm12-158': {
        # Once during your turn (before your attack), you may discard a Pokémon from your hand. If you do, heal 60 damage from this Pokémon.
        'Violent Appetite': (AbilityGate('hand_matches', 'pokemon:1'), DiscardMatchingFromHand('pokemon', 1), HealSelf(60),),
    },
    'sm12-16': {
        # Once during your turn (before your attack), you may draw a card.
        'Seasonal Blessings': (Draw(1),),
    },
    'sm12-168': {
        # Once during your turn (before your attack), you may flip a coin. If heads, your opponent's Active Pokémon is now Asleep. If you use this Ability, your
        'Sleepy Voice': (FlipCoinThen(heads=(InflictStatusOnDefender('asleep'),), tails=()), EndTurnAfterThisAbility(),),
    },
    'sm12-184': {
        # Once during your turn (before your attack), you may draw cards until you have 5 cards in your hand.
        'Disk Reload': (DrawUpTo(5),),
    },
    'sm12-211': {
        # Once during your turn (before your attack), you may heal 30 damage from each of your Pokémon.
        'Fragrant Flower Garden': (HealAllOwnPokemon(amount=30),),
    },
    'sm12-213': {
        # Once during your turn (before your attack), you may discard a Fire Energy card from your hand. If you do, put 2 damage counters on 1 of your opponent'
        'Flaming Shot': (AbilityGate('hand_matches', 'energy_type:Fire:1'), DiscardMatchingFromHand('energy_type:Fire', 1), DamageCounterOnChosenOpponentPokemon(count=2),),
    },
    'sm12-217': {
        # Once during your turn (before your attack), if any of your Pokémon were Knocked Out during your opponent's last turn, you may draw 3 cards. You can't 
        'Dance of Tribute': (AbilityGate('name_not_used', 'Dance of Tribute'), AbilityGate('g:ko_last_turn', ''), MarkAbilityNameUsed('Dance of Tribute'), Draw(3),),
    },
    'sm12-223': {
        # Once during your turn (before your attack), you may discard a Pokémon from your hand. If you do, heal 60 damage from this Pokémon.
        'Violent Appetite': (AbilityGate('hand_matches', 'pokemon:1'), DiscardMatchingFromHand('pokemon', 1), HealSelf(60),),
    },
    'sm12-224': {
        # Once during your turn (before your attack), you may discard a Pokémon from your hand. If you do, heal 60 damage from this Pokémon.
        'Violent Appetite': (AbilityGate('hand_matches', 'pokemon:1'), DiscardMatchingFromHand('pokemon', 1), HealSelf(60),),
    },
    'sm12-227': {
        # Once during your turn (before your attack), you may draw cards until you have 5 cards in your hand.
        'Disk Reload': (DrawUpTo(5),),
    },
    'sm12-250': {
        # Once during your turn (before your attack), you may heal 30 damage from each of your Pokémon.
        'Fragrant Flower Garden': (HealAllOwnPokemon(amount=30),),
    },
    'sm12-252': {
        # Once during your turn (before your attack), you may discard a Fire Energy card from your hand. If you do, put 2 damage counters on 1 of your opponent'
        'Flaming Shot': (AbilityGate('hand_matches', 'energy_type:Fire:1'), DiscardMatchingFromHand('energy_type:Fire', 1), DamageCounterOnChosenOpponentPokemon(count=2),),
    },
    'sm12-255': {
        # Once during your turn (before your attack), if any of your Pokémon were Knocked Out during your opponent's last turn, you may draw 3 cards. You can't 
        'Dance of Tribute': (AbilityGate('name_not_used', 'Dance of Tribute'), AbilityGate('g:ko_last_turn', ''), MarkAbilityNameUsed('Dance of Tribute'), Draw(3),),
    },
    'sm12-260': {
        # Once during your turn (before your attack), you may discard a Pokémon from your hand. If you do, heal 60 damage from this Pokémon.
        'Violent Appetite': (AbilityGate('hand_matches', 'pokemon:1'), DiscardMatchingFromHand('pokemon', 1), HealSelf(60),),
    },
    'sm12-262': {
        # Once during your turn (before your attack), you may draw cards until you have 5 cards in your hand.
        'Disk Reload': (DrawUpTo(5),),
    },
    'sm12-30': {
        # Once during your turn (before your attack), you may heal 20 damage from 1 of your Benched Pokémon.
        'Victory Heal': (HealTarget(20, bench_only=True),),
    },
    'sm12-35': {
        # Once during your turn (before your attack), you may discard a Fire Energy card from your hand. If you do, put 2 damage counters on 1 of your opponent'
        'Flaming Shot': (AbilityGate('hand_matches', 'energy_type:Fire:1'), DiscardMatchingFromHand('energy_type:Fire', 1), DamageCounterOnChosenOpponentPokemon(count=2),),
    },
    'sm12-4': {
        # Once during your turn (before your attack), you may heal 30 damage from each of your Pokémon.
        'Fragrant Flower Garden': (HealAllOwnPokemon(amount=30),),
    },
    'sm12-72': {
        # As often as you like during your turn (before your attack), you may look at the top card of your opponent's deck.
        'Blinking Lights': (LookOpponentDeckTopReorder(1),),
    },
    'sm12-95': {
        # Once during your turn (before your attack), if any of your Pokémon were Knocked Out during your opponent's last turn, you may draw 3 cards. You can't 
        'Dance of Tribute': (AbilityGate('name_not_used', 'Dance of Tribute'), AbilityGate('g:ko_last_turn', ''), MarkAbilityNameUsed('Dance of Tribute'), Draw(3),),
    },
    'sm2-13': {
        # Once during your turn (before your attack), you may move 1 damage counter from 1 Pokémon to another Pokémon.
        'Shady Move': (MoveDamageCounters(count=1, scope='any'),),
    },
    'sm2-139': {
        # Once during your turn (before your attack), you may attach a Psychic or Metal Energy card from your discard pile to your Active Pokémon.
        'Geotech System': (AttachEnergyGeneric(source='discard', energy_types_any=('Psychic', 'Metal'), active_only=True),),
    },
    'sm2-146': {
        # Once during your turn (before your attack), you may put 2 damage counters on 1 of your opponent's Pokémon.
        'Feather Arrow': (DamageCounterOnChosenOpponentPokemon(count=2),),
    },
    'sm2-157': {
        # Once during your turn (before your attack), you may attach a Psychic or Metal Energy card from your discard pile to your Active Pokémon.
        'Geotech System': (AttachEnergyGeneric(source='discard', energy_types_any=('Psychic', 'Metal'), active_only=True),),
    },
    'sm2-157a': {
        # Once during your turn (before your attack), you may attach a Psychic or Metal Energy card from your discard pile to your Active Pokémon.
        'Geotech System': (AttachEnergyGeneric(source='discard', energy_types_any=('Psychic', 'Metal'), active_only=True),),
    },
    'sm2-20': {
        # Once during your turn (before your attack), you may draw a card.
        'Slush Rush': (Draw(1),),
    },
    'sm2-85': {
        # Once during your turn (before your attack), you may attach a Psychic or Metal Energy card from your discard pile to your Active Pokémon.
        'Geotech System': (AttachEnergyGeneric(source='discard', energy_types_any=('Psychic', 'Metal'), active_only=True),),
    },
    'sm3-140': {
        # Once during your turn (before your attack), you may attach a Fairy Energy card from your hand to 1 of your Pokémon.
        'Secret Spring': (AttachEnergyGeneric(source='hand', count=1, basic_only=True, energy_type='Fairy', single_target=True),),
    },
    'sm3-159': {
        # Once during your turn (before your attack), you may attach a Fairy Energy card from your hand to 1 of your Pokémon.
        'Secret Spring': (AttachEnergyGeneric(source='hand', count=1, basic_only=True, energy_type='Fairy', single_target=True),),
    },
    'sm3-96': {
        # Once during your turn (before your attack), you may search your deck for up to 2 basic Energy cards, reveal them, and put them into your hand. Then, s
        'Honey Gather': (SearchDeckForBasicEnergyToHand(count=2),),
    },
    'sm35-13': {
        # Once during your turn (before your attack), you may have your opponent switch their Active Pokémon with 1 of their Benched Pokémon.
        'Heat Cyclone': (ForceOpponentSwitchOpponentChooses(),),
    },
    'sm35-25': {
        # Once during your turn (before your attack), you may heal 20 damage from 1 of your Pokémon that has any Water Energy attached to it.
        'Blessings of the Deep': (PickPokemonThen(action='heal', amount=20, damaged_only=True, require_energy_type='Water'),),
    },
    'sm35-77': {
        # Once during your turn (before your attack), you may discard a card from your hand. If you do, draw 2 cards.
        'Trade': (AbilityGate('hand_matches', 'any:1'), DiscardMatchingFromHand('any', 1), Draw(2),),
    },
    'sm35-77a': {
        # Once during your turn (before your attack), you may discard a card from your hand. If you do, draw 2 cards.
        'Trade': (AbilityGate('hand_matches', 'any:1'), DiscardMatchingFromHand('any', 1), Draw(2),),
    },
    'sm35-9': {
        # Once during your turn (before your attack), you may move a Grass Energy from 1 of your other Pokémon to this Pokémon.
        'Energy Reload': (MoveEnergyGeneric(owner='own', sources='any', dests='self', energy_type='Grass'),),
    },
    'sm4-16': {
        # Once during your turn (before your attack), you may shuffle this Pokémon and all cards attached to it into your deck.
        'Escape': (ShuffleSelfIntoDeck(),),
    },
    'sm5-13': {
        # If this Pokémon is your Active Pokémon, once during your turn (before your attack), you may heal 50 damage from 1 of your Pokémon that has any Energy 
        'Breath of the Leaves': (AbilityGate('active_only', ''), PickPokemonThen(side='own', action='heal', amount=50, has_energy=True, damaged_only=True),),
    },
    'sm5-139': {
        # If this Pokémon is your Active Pokémon, once during your turn (before your attack), you may heal 50 damage from 1 of your Pokémon that has any Energy 
        'Breath of the Leaves': (AbilityGate('active_only', ''), PickPokemonThen(side='own', action='heal', amount=50, has_energy=True, damaged_only=True),),
    },
    'sm5-143': {
        # Once during your turn (before your attack), if this Pokémon is on your Bench, you may switch it with your Active Pokémon.
        'Invasion': (AbilityGate('bench_only', ''), SwitchSelfFromBenchToActive(),),
    },
    'sm5-157': {
        # If this Pokémon is your Active Pokémon, once during your turn (before your attack), you may heal 50 damage from 1 of your Pokémon that has any Energy 
        'Breath of the Leaves': (AbilityGate('active_only', ''), PickPokemonThen(side='own', action='heal', amount=50, has_energy=True, damaged_only=True),),
    },
    'sm5-161': {
        # Once during your turn (before your attack), if this Pokémon is on your Bench, you may switch it with your Active Pokémon.
        'Invasion': (AbilityGate('bench_only', ''), SwitchSelfFromBenchToActive(),),
    },
    'sm5-172': {
        # As often as you like during your turn (before your attack), you may move a Psychic Energy from 1 of your Pokémon to another of your Pokémon.
        'Psychic Transfer': (MoveEnergyGeneric(owner='own', sources='any', dests='any', energy_type='Psychic', basic_only=False),),
    },
    'sm5-173': {
        # Once during your turn (before your attack), you may switch your Active Pokémon with 1 of your Benched Pokémon.
        'Ultra Road': (SwitchActiveWithBench(),),
    },
    'sm5-67': {
        # Once during your turn (before your attack), if you have Garchomp in play, you may search your deck for a card and put it into your hand. Then, shuffle
        'Precognitive Aura': (AbilityGate('has_named_pokemon_in_play', 'Garchomp'), SearchDeckAnyCardToHand(1),),
    },
    'sm5-83': {
        # As often as you like during your turn (before your attack), you may attach a Metal Energy card from your hand to 1 of your Pokémon.
        'Magnetic Circuit': (AttachEnergyGeneric(source='hand', energy_type='Metal'),),
    },
    'sm5-93': {
        # Once during your turn (before your attack), you may search your deck for a Fairy Pokémon, reveal it, and put it into your hand. Then, shuffle your dec
        'Illuminate': (SearchDeckForPokemonToHand(count=1, pokemon_type='Fairy'),),
    },
    'sm6-17': {
        # Once during your turn (before your attack), you may leave your opponent's Active Pokémon Burned.
        'Mystical Torch': (InflictStatusOnDefender('burned'),),
    },
    'sm6-31': {
        # Once during your turn (before your attack), you may discard a Water Energy card from your hand. If you do, your opponent switches their Active Pokémon
        'Jet Geyser': (AbilityGate('hand_matches', 'energy_type:Water:1'), DiscardMatchingFromHand('energy_type:Water', 1), ForceOpponentSwitchOpponentChooses(),),
    },
    'sm6-36': {
        # As often as you like during your turn (before your attack), you may attach a Lightning Energy card from your hand to 1 of your Pokémon.
        'Magnetic Circuit': (AttachEnergyGeneric(source='hand', energy_type='Lightning'),),
    },
    'sm7-106': {
        # If this Pokémon is your Active Pokémon, once during your turn (before your attack), you may switch 1 of your opponent's Benched Pokémon with their Act
        'Dragon Wind': (AbilityGate('active_only', ''), ForceOpponentSwitchChosenBench(),),
    },
    'sm7-155': {
        # Once during your turn (before your attack), you may attach 5 Energy cards from your discard pile to your Pokémon, except Pokémon-GX or Pokémon-EX, in 
        'Extra Energy Bomb': (AttachEnergyGeneric(source='discard', count=5, exclude_subtype='GX,EX'), KnockOutSelfEffect(),),
    },
    'sm7-157': {
        # Once during your turn (before your attack), if this Pokémon is your Active Pokémon, you may move 1 damage counter from 1 Pokémon to another Pokémon.
        'Shady Move': (AbilityGate('active_only', ''), MoveDamageCounters(count=1, scope='any'),),
    },
    'sm7-172': {
        # Once during your turn (before your attack), you may attach 5 Energy cards from your discard pile to your Pokémon, except Pokémon-GX or Pokémon-EX, in 
        'Extra Energy Bomb': (AttachEnergyGeneric(source='discard', count=5, exclude_subtype='GX,EX'), KnockOutSelfEffect(),),
    },
    'sm7-174': {
        # Once during your turn (before your attack), if this Pokémon is your Active Pokémon, you may move 1 damage counter from 1 Pokémon to another Pokémon.
        'Shady Move': (AbilityGate('active_only', ''), MoveDamageCounters(count=1, scope='any'),),
    },
    'sm7-24': {
        # Once during your turn (before your attack), you may search your deck for a card, shuffle your deck, then put that card on top of it.
        'Smooth Over': (SearchDeckPutOnTop('any'),),
    },
    'sm7-3': {
        # Once during your turn (before your attack), you may flip a coin. If heads, switch 1 of your opponent's Benched Pokémon with their Active Pokémon.
        'Fragrance Trap': (FlipCoinThen(heads=(ForceOpponentSwitchChosenBench(),), tails=()),),
    },
    'sm7-35': {
        # Once during your turn (before your attack), you may discard a card from your hand. If you do, draw 3 cards.
        'Power Draw': (AbilityGate('hand_matches', 'any:1'), DiscardMatchingFromHand('any', 1), Draw(3),),
    },
    'sm7-38': {
        # Once during your turn (before your attack), you may draw a card.
        'Swing Dance': (Draw(1),),
    },
    'sm7-48': {
        # Once during your turn (before your attack), you may attach 5 Energy cards from your discard pile to your Pokémon, except Pokémon-GX or Pokémon-EX, in 
        'Extra Energy Bomb': (AttachEnergyGeneric(source='discard', count=5, exclude_subtype='GX,EX'), KnockOutSelfEffect(),),
    },
    'sm7-66': {
        # Once during your turn (before your attack), if this Pokémon is your Active Pokémon, you may move 1 damage counter from 1 Pokémon to another Pokémon.
        'Shady Move': (AbilityGate('active_only', ''), MoveDamageCounters(count=1, scope='any'),),
    },
    'sm7-88': {
        # Once during your turn (before your attack), you may look at the top card of your deck. You may discard that card.
        'Excavate': (LookTopCardMayDiscard(),),
    },
    'sm75-26': {
        # As often as you like during your turn (before your attack), you may move a Water Energy from 1 of your Benched Pokémon to your Active Pokémon.
        'Wash Out': (MoveEnergyGeneric(owner='own', sources='bench', dests='active', energy_type='Water'),),
    },
    'sm75-6': {
        # Once during your turn (before your attack), you may attach a Fire Energy card from your discard pile to 1 of your Benched Pokémon.
        'Firestarter': (AttachEnergyGeneric(source='discard', energy_type='Fire', bench_only=True),),
    },
    'sm8-154': {
        # Once during your turn (before your attack), you may put any Stage 1 card from your hand onto this Pokémon to evolve it. You can't use this Ability dur
        'Almighty Evolution': (EvolveSelfFromHand(any_stage1=True),),
    },
    'sm8-198': {
        # Once during your turn (before your attack), you may discard the top card of your deck. If it's a basic Energy card, attach it to 1 of your Pokémon.
        'Crushing Charge': (MillTopThenAttachEnergy('basic_energy'),),
    },
    'sm8-200': {
        # Once during your turn (before your attack), if this Pokémon is on your Bench, you may shuffle it and all cards attached to it into your deck.
        'Phantom Winds': (AbilityGate('bench_only', ''), ShuffleSelfIntoDeck(),),
    },
    'sm8-21': {
        # Once during your turn (before your attack), you may search your deck for a Grass Pokémon, reveal it, and put it into your hand. Then, shuffle your dec
        'Sunshine Grace': (SearchDeckForPokemonToHand(count=1, pokemon_type='Grass'),),
    },
    'sm8-218': {
        # Once during your turn (before your attack), you may discard the top card of your deck. If it's a basic Energy card, attach it to 1 of your Pokémon.
        'Crushing Charge': (MillTopThenAttachEnergy('basic_energy'),),
    },
    'sm8-220': {
        # Once during your turn (before your attack), if this Pokémon is on your Bench, you may shuffle it and all cards attached to it into your deck.
        'Phantom Winds': (AbilityGate('bench_only', ''), ShuffleSelfIntoDeck(),),
    },
    'sm8-56': {
        # Once during your turn (before your attack), you may look at the top 2 cards of your deck and put them back in any order.
        'Go for a Swim': (LookTopNReorderOnTop(2),),
    },
    'sm8-59': {
        # Once during your turn (before your attack), if this Pokémon is your Active Pokémon, you may have your opponent switch their Active Pokémon with 1 of t
        'Frozen Flow': (AbilityGate('active_only', ''), ForceOpponentSwitchOpponentChooses(),),
    },
    'sm8-60': {
        # Once during your turn (before your attack), if this Pokémon is on your Bench, you may shuffle it and all cards attached to it into your deck.
        'Phantom Winds': (AbilityGate('bench_only', ''), ShuffleSelfIntoDeck(),),
    },
    'sm8-75': {
        # Once during your turn (before your attack), if this Pokémon is your Active Pokémon, you may leave your opponent's Active Pokémon Asleep.
        'Fluffy Pillow': (AbilityGate('active_only', ''), InflictStatusOnDefender('asleep'),),
    },
    'sm8-82': {
        # Once during your turn (before your attack), you may discard your hand and draw 4 cards.
        'Sprint': (DiscardHandThenDraw(4),),
    },
    'sm9-119': {
        # Once during your turn (before your attack), you may search your deck for a Supporter card, reveal it, and put it into your hand. Then, shuffle your de
        'Fast Call': (SearchDeckMultiCriteria(('supporter',)),),
    },
    'sm9-14': {
        # Once during your turn (before your attack), you may put 2 damage counters on this Pokémon. If you do, search your deck for up to 2 Fire Energy cards a
        'Roaring Resolve': (SelfDamage(20), SearchDeckAndAttachEnergy('Fire', count=2, self_only=True),),
    },
    'sm9-167': {
        # Once during your turn (before your attack), you may put 3 damage counters on this Pokémon. If you do, search your deck for up to 3 Darkness Energy car
        'Scar Charge': (SelfDamage(30), SearchDeckAndAttachEnergy('Darkness', count=3, self_only=True),),
    },
    'sm9-188': {
        # Once during your turn (before your attack), you may put 3 damage counters on this Pokémon. If you do, search your deck for up to 3 Darkness Energy car
        'Scar Charge': (SelfDamage(30), SearchDeckAndAttachEnergy('Darkness', count=3, self_only=True),),
    },
    'sm9-25': {
        # Once during your turn (before your attack), you may look at the top 6 cards of your deck and attach any number of Water Energy cards you find there to
        'Powerful Squall': (AttachEnergyGeneric(source='deck', count=99, deck_limit=6, basic_only=True, energy_type='Water', optional=True),),
    },
    'sm9-46': {
        # Once during your turn (before your attack), you may search your deck for a Pokémon that has the Nuzzle attack, reveal it, and put it into your hand. T
        'Nuzzly Gathering': (SearchDeckForNamedCardToHand('Pokémon that has the Nuzzle attack'),),
    },
    'sm9-56': {
        # Once during your turn (before your attack), you may search your deck for a Pokémon that isn't a Pokémon-GX or Pokémon-EX, reveal it, and put it into y
        "Queen's Call": (SearchDeckForNamedCardToHand("Pokémon that isn't a Pokémon-GX or Pokémon-EX"),),
    },
    'sm9-97': {
        # Once during your turn (before your attack), you may put 3 damage counters on this Pokémon. If you do, search your deck for up to 3 Darkness Energy car
        'Scar Charge': (SelfDamage(30), SearchDeckAndAttachEnergy('Darkness', count=3, self_only=True),),
    },
    'sma-SV10': {
        # As often as you like during your turn (before your attack), you may move a Water Energy from 1 of your Benched Pokémon to your Active Pokémon.
        'Wash Out': (MoveEnergyGeneric(owner='own', sources='bench', dests='active', energy_type='Water'),),
    },
    'sma-SV18': {
        # Once during your turn (before your attack), you may attach a Psychic Energy card from your discard pile to 1 of your Benched Pokémon.
        'Psychic Recharge': (AttachEnergyGeneric(source='discard', energy_type='Psychic', bench_only=True),),
    },
    'sma-SV22': {
        # Once during your turn (before your attack), if you have Garchomp in play, you may search your deck for a card and put it into your hand. Then, shuffle
        'Precognitive Aura': (AbilityGate('has_named_pokemon_in_play', 'Garchomp'), SearchDeckAnyCardToHand(1),),
    },
    'sma-SV29': {
        # As often as you like during your turn (before your attack), you may attach a Metal Energy card from your hand to 1 of your Pokémon.
        'Magnetic Circuit': (AttachEnergyGeneric(source='hand', energy_type='Metal'),),
    },
    'sma-SV44': {
        # Once during your turn (before your attack), you may draw cards until you have 3 cards in your hand.
        'Instruct': (DrawUpTo(3),),
    },
    'sma-SV46': {
        # If this Pokémon is your Active Pokémon, once during your turn (before your attack), you may heal 50 damage from 1 of your Pokémon that has any Energy 
        'Breath of the Leaves': (AbilityGate('active_only', ''), PickPokemonThen(side='own', action='heal', amount=50, has_energy=True, damaged_only=True),),
    },
    'sma-SV47': {
        # Once during your turn (before your attack), you may put 2 damage counters on 1 of your opponent's Pokémon.
        'Feather Arrow': (DamageCounterOnChosenOpponentPokemon(count=2),),
    },
    'sma-SV57': {
        # Once during your turn (before your attack), you may attach 5 Energy cards from your discard pile to your Pokémon, except Pokémon-GX or Pokémon-EX, in 
        'Extra Energy Bomb': (AttachEnergyGeneric(source='discard', count=5, exclude_subtype='GX,EX'), KnockOutSelfEffect(),),
    },
    'sma-SV61': {
        # Once during your turn (before your attack), if this Pokémon is your Active Pokémon, you may move 1 damage counter from 1 Pokémon to another Pokémon.
        'Shady Move': (AbilityGate('active_only', ''), MoveDamageCounters(count=1, scope='any'),),
    },
    'sma-SV75': {
        # Once during your turn (before your attack), you may attach a Fairy Energy card from your hand to 1 of your Pokémon.
        'Secret Spring': (AttachEnergyGeneric(source='hand', count=1, basic_only=True, energy_type='Fairy', single_target=True),),
    },
    'smp-SM10': {
        # Once during your turn (before your attack), you may search your deck for a Grass Pokémon, reveal it, and put it into your hand. Then, shuffle your dec
        'Illuminate': (SearchDeckForPokemonToHand(count=1, pokemon_type='Grass'),),
    },
    'smp-SM101': {
        # Once during your turn (before your attack), if this Pokémon is on your Bench, you may switch it with your Active Pokémon.
        'Invasion': (AbilityGate('bench_only', ''), SwitchSelfFromBenchToActive(),),
    },
    'smp-SM117': {
        # Once during your turn (before your attack), you may attach a Psychic Energy card from your discard pile to 1 of your Benched Pokémon.
        'Psychic Recharge': (AttachEnergyGeneric(source='discard', energy_type='Psychic', bench_only=True),),
    },
    'smp-SM13': {
        # Once during your turn (before your attack), you may draw cards until you have 3 cards in your hand.
        'Instruct': (DrawUpTo(3),),
    },
    'smp-SM140': {
        # If this Pokémon is your Active Pokémon, once during your turn (before your attack), you may switch 1 of your opponent's Benched Pokémon with their Act
        'Dragon Wind': (AbilityGate('active_only', ''), ForceOpponentSwitchChosenBench(),),
    },
    'smp-SM146': {
        # If this Pokémon is your Active Pokémon, once during your turn (before your attack), you may heal 50 damage from 1 of your Pokémon that has any Energy 
        'Breath of the Leaves': (AbilityGate('active_only', ''), PickPokemonThen(side='own', action='heal', amount=50, has_energy=True, damaged_only=True),),
    },
    'smp-SM149': {
        # Once during your turn (before your attack), if this Pokémon is your Active Pokémon, you may have your opponent switch their Active Pokémon with 1 of t
        'Frozen Current': (AbilityGate('active_only', ''), ForceOpponentSwitchOpponentChooses(),),
    },
    'smp-SM158': {
        # Once during your turn (before your attack), you may put 2 damage counters on this Pokémon. If you do, search your deck for up to 2 Fire Energy cards a
        'Roaring Resolve': (SelfDamage(20), SearchDeckAndAttachEnergy('Fire', count=2, self_only=True),),
    },
    'smp-SM16': {
        # Once during your turn (before your attack), you may switch your Active Pokémon with 1 of your Benched Pokémon.
        'Ultra Road': (SwitchActiveWithBench(),),
    },
    'smp-SM160': {
        # Once during your turn (before your attack), you may search your deck for a Pokémon that isn't a Pokémon-GX or Pokémon-EX, reveal it, and put it into y
        "Queen's Call": (SearchDeckForNamedCardToHand("Pokémon that isn't a Pokémon-GX or Pokémon-EX"),),
    },
    'smp-SM164': {
        # Once during your turn (before your attack), you may move an Energy from 1 of your Pokémon to 1 of your Deoxys.
        'Power Suction': (MoveEnergyGeneric(owner='own', sources='any', dests='any', dest_name_prefix='Deoxys'),),
    },
    'smp-SM17': {
        # As often as you like during your turn (before your attack), you may move a Psychic Energy from 1 of your Pokémon to another of your Pokémon.
        'Psychic Transfer': (MoveEnergyGeneric(owner='own', sources='any', dests='any', energy_type='Psychic', basic_only=False),),
    },
    'smp-SM18': {
        # Once during your turn (before your attack), you may draw a card.
        'Slush Rush': (Draw(1),),
    },
    'smp-SM181': {
        # Once during your turn (before your attack), you may discard a Metal Pokémon from your hand. If you do, heal 100 damage from this Pokémon.
        'Metal Eater': (AbilityGate('hand_matches', 'type_pokemon:Metal:1'), DiscardMatchingFromHand('type_pokemon:Metal', 1), HealSelf(100),),
    },
    'smp-SM226': {
        # Once during your turn (before your attack), you may put 2 damage counters on this Pokémon. If you do, search your deck for up to 2 Fire Energy cards a
        'Roaring Resolve': (SelfDamage(20), SearchDeckAndAttachEnergy('Fire', count=2, self_only=True),),
    },
    'smp-SM28': {
        # Once during your turn (before your attack), you may search your deck for a Grass Energy card and a Lightning Energy card and attach them to your Pokém
        'Strong Charge': (AttachEnergyGeneric(source='deck', count=2, energy_types_any=('Grass', 'Lightning'), distinct_energy_types=True),),
    },
    'smp-SM37': {
        # Once during your turn (before your attack), you may put 2 damage counters on 1 of your opponent's Pokémon.
        'Feather Arrow': (DamageCounterOnChosenOpponentPokemon(count=2),),
    },
    'smp-SM84': {
        # Once during your turn (before your attack), you may discard a card from your hand. If you do, draw 2 cards.
        'Trade': (AbilityGate('hand_matches', 'any:1'), DiscardMatchingFromHand('any', 1), Draw(2),),
    },
    'smp-SM95': {
        # Once during your turn (before your attack), if you have Garchomp in play, you may search your deck for a card and put it into your hand. Then, shuffle
        'Precognitive Aura': (AbilityGate('has_named_pokemon_in_play', 'Garchomp'), SearchDeckAnyCardToHand(1),),
    },
    'sv1-125': {
        # Once during your turn, you may attach up to 2 Basic Fighting Energy cards from your discard pile to your Basic Fighting Pokémon in any way you like. I
        'Dino Cry': (AttachEnergyGeneric(source='discard', count=2, basic_only=True, energy_type='Fighting', target_type='Fighting', target_subtype='Basic'), EndTurnAfterThisAbility(),),
    },
    'sv1-137': {
        # Once during your turn, you may switch out your opponent's Active Pokémon to the Bench. (Your opponent chooses the new Active Pokémon.)
        'Intimidating Howl': (ForceOpponentSwitchOpponentChooses(),),
    },
    'sv1-142': {
        # You must discard an Energy card from your hand in order to use this Ability. Once during your turn, you may draw cards until you have 6 cards in your 
        'Rumbling Engine': (AbilityGate('hand_matches', 'any_energy:1'), DiscardMatchingFromHand('any_energy', 1), DrawUpTo(6),),
    },
    'sv1-151': {
        # Once during your turn, you may shuffle your hand and put it on the bottom of your deck. If you put any cards on the bottom of your deck in this way, d
        'Nest Stash': (ShuffleHandToBottomThenDraw(1),),
    },
    'sv1-203': {
        # As often as you like during your turn, you may move a Fire Energy from 1 of your Benched Pokémon to your Active Pokémon.
        'Fire Off': (MoveEnergyGeneric(owner='own', sources='bench', dests='active', energy_type='Fire'),),
    },
    'sv1-209': {
        # Once during your turn, you may search your deck for a Basic Lightning Energy card and attach it to this Pokémon. Then, shuffle your deck.
        'Electrogenesis': (AttachEnergyGeneric(source='deck', count=1, basic_only=True, energy_type='Lightning', self_only=True),),
    },
    'sv1-218': {
        # Once during your turn, you may switch out your opponent's Active Pokémon to the Bench. (Your opponent chooses the new Active Pokémon.)
        'Intimidating Howl': (ForceOpponentSwitchOpponentChooses(),),
    },
    'sv1-222': {
        # Once during your turn, you may shuffle your hand and put it on the bottom of your deck. If you put any cards on the bottom of your deck in this way, d
        'Nest Stash': (ShuffleHandToBottomThenDraw(1),),
    },
    'sv1-227': {
        # Once during your turn, you may search your deck for up to 2 Basic Lightning Pokémon and put them onto your Bench. Then, shuffle your deck.
        'Tandem Unit': (SearchDeckForBasicPokemonToBench(count=2, pokemon_type='Lightning'),),
    },
    'sv1-228': {
        # As often as you like during your turn, you may attach a Basic Psychic Energy card from your discard pile to 1 of your Psychic Pokémon. If you attached
        'Psychic Embrace': (AttachEnergyGeneric(source='discard', energy_type='Psychic', basic_only=True, target_type='Psychic', counters_on_target=2, no_ko_target=True),),
    },
    'sv1-231': {
        # Once during your turn, you may attach up to 2 Basic Fighting Energy cards from your discard pile to your Basic Fighting Pokémon in any way you like. I
        'Dino Cry': (AttachEnergyGeneric(source='discard', count=2, basic_only=True, energy_type='Fighting', target_type='Fighting', target_subtype='Basic'), EndTurnAfterThisAbility(),),
    },
    'sv1-244': {
        # Once during your turn, you may search your deck for up to 2 Basic Lightning Pokémon and put them onto your Bench. Then, shuffle your deck.
        'Tandem Unit': (SearchDeckForBasicPokemonToBench(count=2, pokemon_type='Lightning'),),
    },
    'sv1-245': {
        # As often as you like during your turn, you may attach a Basic Psychic Energy card from your discard pile to 1 of your Psychic Pokémon. If you attached
        'Psychic Embrace': (AttachEnergyGeneric(source='discard', energy_type='Psychic', basic_only=True, target_type='Psychic', counters_on_target=2, no_ko_target=True),),
    },
    'sv1-247': {
        # Once during your turn, you may attach up to 2 Basic Fighting Energy cards from your discard pile to your Basic Fighting Pokémon in any way you like. I
        'Dino Cry': (AttachEnergyGeneric(source='discard', count=2, basic_only=True, energy_type='Fighting', target_type='Fighting', target_subtype='Basic'), EndTurnAfterThisAbility(),),
    },
    'sv1-253': {
        # Once during your turn, you may search your deck for up to 2 Basic Lightning Pokémon and put them onto your Bench. Then, shuffle your deck.
        'Tandem Unit': (SearchDeckForBasicPokemonToBench(count=2, pokemon_type='Lightning'),),
    },
    'sv1-254': {
        # Once during your turn, you may attach up to 2 Basic Fighting Energy cards from your discard pile to your Basic Fighting Pokémon in any way you like. I
        'Dino Cry': (AttachEnergyGeneric(source='discard', count=2, basic_only=True, energy_type='Fighting', target_type='Fighting', target_subtype='Basic'), EndTurnAfterThisAbility(),),
    },
    'sv1-41': {
        # As often as you like during your turn, you may move a Fire Energy from 1 of your Benched Pokémon to your Active Pokémon.
        'Fire Off': (MoveEnergyGeneric(owner='own', sources='bench', dests='active', energy_type='Fire'),),
    },
    'sv1-43': {
        # As often as you like during your turn, you may move 1 damage counter from 1 of your other Pokémon to this Pokémon.
        'Strange Behavior': (MoveDamageCounters(count=1, scope='other_own_to_self'),),
    },
    'sv1-54': {
        # Once during your turn, you may attach a Basic Energy card from your hand to 1 of your Pokémon.
        'Energy Carnival': (AttachEnergyGeneric(source='hand', count=1, basic_only=True, single_target=True),),
    },
    'sv1-76': {
        # Once during your turn, you may search your deck for a Basic Lightning Energy card and attach it to this Pokémon. Then, shuffle your deck.
        'Electrogenesis': (AttachEnergyGeneric(source='deck', count=1, basic_only=True, energy_type='Lightning', self_only=True),),
    },
    'sv10-145': {
        # Once during your turn, you may search your deck for a Basic Psychic Energy card, a Basic Metal Energy card, or 1 of each and attach them to your Psych
        'X-Boot': (AttachEnergyGeneric(source='deck', count=2, energy_types_any=('Psychic', 'Metal'), distinct_energy_types=True, basic_only=True, target_types_any=('Psychic', 'Metal')),),
    },
    'sv10-198': {
        # As often as you like during your turn, you may move 1 damage counter from 1 of your Team Rocket's Pokémon to another of your Pokémon.
        'Rocket Brain': (PickPokemonThen(side='own', action='take_counters', amount=1, damaged_only=True, name_prefix="Team Rocket's", then=(PickPokemonThen(side='own', action='give_counters', exclude_picked=True),)),),
    },
    'sv10-209': {
        # Once during your turn, you may attach up to 2 Basic Fire Energy cards from your hand to 1 of your Benched Ethan's Pokémon.
        'Golden Flame': (AttachEnergyGeneric(source='hand', count=2, energy_type='Fire', basic_only=True, bench_only=True, single_target=True, optional=True, target_name_prefix="Ethan's"),),
    },
    'sv10-230': {
        # Once during your turn, you may attach up to 2 Basic Fire Energy cards from your hand to 1 of your Benched Ethan's Pokémon.
        'Golden Flame': (AttachEnergyGeneric(source='hand', count=2, energy_type='Fire', basic_only=True, bench_only=True, single_target=True, optional=True, target_name_prefix="Ethan's"),),
    },
    'sv10-239': {
        # Once during your turn, you may attach up to 2 Basic Fire Energy cards from your hand to 1 of your Benched Ethan's Pokémon.
        'Golden Flame': (AttachEnergyGeneric(source='hand', count=2, energy_type='Fire', basic_only=True, bench_only=True, single_target=True, optional=True, target_name_prefix="Ethan's"),),
    },
    'sv10-39': {
        # Once during your turn, you may attach up to 2 Basic Fire Energy cards from your hand to 1 of your Benched Ethan's Pokémon.
        'Golden Flame': (AttachEnergyGeneric(source='hand', count=2, energy_type='Fire', basic_only=True, bench_only=True, single_target=True, optional=True, target_name_prefix="Ethan's"),),
    },
    'sv10-89': {
        # As often as you like during your turn, you may move 1 damage counter from 1 of your Team Rocket's Pokémon to another of your Pokémon.
        'Rocket Brain': (PickPokemonThen(side='own', action='take_counters', amount=1, damaged_only=True, name_prefix="Team Rocket's", then=(PickPokemonThen(side='own', action='give_counters', exclude_picked=True),)),),
    },
    'sv2-105': {
        # You must discard a card from your hand in order to use this Ability. Once during your turn, you may draw 3 cards.
        'Gather Materials': (AbilityGate('hand_matches', 'any:1'), DiscardMatchingFromHand('any', 1), Draw(3),),
    },
    'sv2-130': {
        # Once during your turn, if a Stadium is in play, you may make your opponent's Active Pokémon Poisoned.
        'Toxic Wetland': (AbilityGate('g:stadium_in_play', ''), InflictStatusOnDefender('poisoned'),),
    },
    'sv2-15': {
        # You must discard a Basic Grass Energy card from your hand in order to use this Ability. Once during your turn, you may put 3 damage counters on 1 of y
        'Bouquet Magic': (AbilityGate('hand_matches', 'energy_type:Grass:1'), DiscardMatchingFromHand('energy_type:Grass', 1), PickPokemonThen(side='opp', action='put_counters', amount=3, bench_only=True),),
    },
    'sv2-210': {
        # As often as you like during your turn, you may attach a Basic Water Energy card from your hand to 1 of your Pokémon.
        'Super Cold': (AttachEnergyGeneric(source='hand', count=1, basic_only=True, energy_type='Water', single_target=True),),
    },
    'sv2-230': {
        # Once during your turn, you may search your deck for up to 5 Basic Grass Energy cards and attach them to your Pokémon in any way you like. Then, shuffl
        'Exploding Energy': (AttachEnergyGeneric(source='deck', count=5, basic_only=True, energy_type='Grass'), IfLastAttachSucceeded((KnockOutSelfEffect(),)),),
    },
    'sv2-231': {
        # You must discard a Basic Grass Energy card from your hand in order to use this Ability. Once during your turn, you may put 3 damage counters on 1 of y
        'Bouquet Magic': (AbilityGate('hand_matches', 'energy_type:Grass:1'), DiscardMatchingFromHand('energy_type:Grass', 1), PickPokemonThen(side='opp', action='put_counters', amount=3, bench_only=True),),
    },
    'sv2-236': {
        # Once during your turn, if this Pokémon is in the Active Spot, you may search your deck for up to 2 Basic Water Energy cards, reveal them, and put them
        'Shivery Chill': (AbilityGate('active_only', ''), SearchDeckByCriterionToHand('energy_type:Water', count=2),),
    },
    'sv2-244': {
        # Once during your turn, if a Stadium is in play, you may make your opponent's Active Pokémon Poisoned.
        'Toxic Wetland': (AbilityGate('g:stadium_in_play', ''), InflictStatusOnDefender('poisoned'),),
    },
    'sv2-256': {
        # You must discard a Basic Grass Energy card from your hand in order to use this Ability. Once during your turn, you may put 3 damage counters on 1 of y
        'Bouquet Magic': (AbilityGate('hand_matches', 'energy_type:Grass:1'), DiscardMatchingFromHand('energy_type:Grass', 1), PickPokemonThen(side='opp', action='put_counters', amount=3, bench_only=True),),
    },
    'sv2-261': {
        # Once during your turn, if this Pokémon is in the Active Spot, you may search your deck for up to 2 Basic Water Energy cards, reveal them, and put them
        'Shivery Chill': (AbilityGate('active_only', ''), SearchDeckByCriterionToHand('energy_type:Water', count=2),),
    },
    'sv2-271': {
        # You must discard a Basic Grass Energy card from your hand in order to use this Ability. Once during your turn, you may put 3 damage counters on 1 of y
        'Bouquet Magic': (AbilityGate('hand_matches', 'energy_type:Grass:1'), DiscardMatchingFromHand('energy_type:Grass', 1), PickPokemonThen(side='opp', action='put_counters', amount=3, bench_only=True),),
    },
    'sv2-274': {
        # Once during your turn, if this Pokémon is in the Active Spot, you may search your deck for up to 2 Basic Water Energy cards, reveal them, and put them
        'Shivery Chill': (AbilityGate('active_only', ''), SearchDeckByCriterionToHand('energy_type:Water', count=2),),
    },
    'sv2-33': {
        # Once during your turn, you may heal 20 damage from your Active Evolution Pokémon.
        'Ardent Dancing': (PickPokemonThen(side='own', action='heal', amount=20, active_only=True, evolved_only=True),),
    },
    'sv2-5': {
        # Once during your turn, you may search your deck for up to 5 Basic Grass Energy cards and attach them to your Pokémon in any way you like. Then, shuffl
        'Exploding Energy': (AttachEnergyGeneric(source='deck', count=5, basic_only=True, energy_type='Grass'), IfLastAttachSucceeded((KnockOutSelfEffect(),)),),
    },
    'sv2-60': {
        # As often as you like during your turn, you may attach a Basic Water Energy card from your hand to 1 of your Pokémon.
        'Super Cold': (AttachEnergyGeneric(source='hand', count=1, basic_only=True, energy_type='Water', single_target=True),),
    },
    'sv2-61': {
        # Once during your turn, if this Pokémon is in the Active Spot, you may search your deck for up to 2 Basic Water Energy cards, reveal them, and put them
        'Shivery Chill': (AbilityGate('active_only', ''), SearchDeckByCriterionToHand('energy_type:Water', count=2),),
    },
    'sv2-68': {
        # Once during your turn, if this Pokémon is in the Active Spot, you may switch out your opponent's Active Pokémon to the Bench. (Your opponent chooses t
        'Big Roar': (AbilityGate('active_only', ''), ForceOpponentSwitchOpponentChooses(),),
    },
    'sv2-84': {
        # Once during your turn, you may attach a Therapeutic Energy card from your hand to 1 of your Pokémon.
        'Balloon Therapy': (AttachEnergyGeneric(source='hand', energy_name='Therapeutic Energy'),),
    },
    'sv3-217': {
        # Once during your turn, you may search your deck for a card and put it into your hand. Then, shuffle your deck. You can't use more than 1 Quick Search 
        'Quick Search': (AbilityGate('name_not_used', 'Quick Search'), MarkAbilityNameUsed('Quick Search'), SearchDeckAnyCardToHand(1),),
    },
    'sv3-225': {
        # Once during your turn, you may search your deck for a card and put it into your hand. Then, shuffle your deck. You can't use more than 1 Quick Search 
        'Quick Search': (AbilityGate('name_not_used', 'Quick Search'), MarkAbilityNameUsed('Quick Search'), SearchDeckAnyCardToHand(1),),
    },
    'sv3pt5-143': {
        # Once during your turn, you may put up to 2 Leftovers cards from your discard pile into your hand.
        'Voraciousness': (SearchDiscardByCriterionToHand('named:Leftovers', count=2),),
    },
    'sv3pt5-182': {
        # Once during your turn, if this Pokémon is in the Active Spot, you may heal 60 damage from 1 of your Pokémon.
        'Tranquil Flower': (AbilityGate('active_only', ''), HealTarget(60),),
    },
    'sv3pt5-193': {
        # Once during your turn, you may draw cards until you have 3 cards in your hand.
        'Restart': (DrawUpTo(3),),
    },
    'sv3pt5-198': {
        # Once during your turn, if this Pokémon is in the Active Spot, you may heal 60 damage from 1 of your Pokémon.
        'Tranquil Flower': (AbilityGate('active_only', ''), HealTarget(60),),
    },
    'sv3pt5-205': {
        # Once during your turn, you may draw cards until you have 3 cards in your hand.
        'Restart': (DrawUpTo(3),),
    },
    'sv3pt5-3': {
        # Once during your turn, if this Pokémon is in the Active Spot, you may heal 60 damage from 1 of your Pokémon.
        'Tranquil Flower': (AbilityGate('active_only', ''), HealTarget(60),),
    },
    'sv3pt5-41': {
        # Once during your turn, if this Pokémon is in the Active Spot, you may have your opponent reveal their hand.
        'Revealing Echo': (AbilityGate('active_only', ''), RevealOpponentHand(),),
    },
    'sv3pt5-53': {
        # Once during your turn, you may search your deck for a Giovanni's Charisma card, reveal it, and put it into your hand. Then, shuffle your deck.
        'Rocket Call': (SearchDeckByCriterionToHand("named:Giovanni's Charisma", count=1),),
    },
    'sv3pt5-85': {
        # Once during your turn, you may put 1 damage counter on this Pokémon. If you do, draw a card.
        'Zooming Draw': (SelfDamage(10), Draw(1),),
    },
    'sv4-104': {
        # Once during your turn, you may attach a Basic Fighting Energy card from your discard pile to 1 of your Pokémon. If you attached Energy to a Pokémon in
        'Energizing Rock Salt': (AttachEnergyGeneric(source='discard', count=1, basic_only=True, energy_type='Fighting', single_target=True, heal_on_target=30),),
    },
    'sv4-108': {
        # Once during your turn, if your opponent has 4 or fewer Prize cards remaining, you may attach a Basic Fighting Energy card from your discard pile to th
        'Magnetic Absorption': (AbilityGate('g:opp_prizes_at_most', '4'), AttachEnergyGeneric(source='discard', count=1, basic_only=True, energy_type='Fighting', self_only=True),),
    },
    'sv4-140': {
        # Once during your turn, you may heal 20 damage from each of your Pokémon.
        'Humming Heal': (HealAllOwnPokemon(amount=20),),
    },
    'sv4-144': {
        # Once during your turn, you may flip a coin. If heads, attach up to 4 Basic Energy cards from your discard pile to this Pokémon. If tails, discard an E
        'Buggy Turbo': (FlipCoinThen(heads=(AttachEnergyGeneric(source='discard', count=4, basic_only=True, self_only=True, optional=True),), tails=(DiscardOwnEnergy(count=1),)),),
    },
    'sv4-202': {
        # Once during your turn, you may attach a Basic Fighting Energy card from your discard pile to 1 of your Pokémon. If you attached Energy to a Pokémon in
        'Energizing Rock Salt': (AttachEnergyGeneric(source='discard', count=1, basic_only=True, energy_type='Fighting', single_target=True, heal_on_target=30),),
    },
    'sv4-214': {
        # Once during your turn, you may flip a coin. If heads, attach up to 4 Basic Energy cards from your discard pile to this Pokémon. If tails, discard an E
        'Buggy Turbo': (FlipCoinThen(heads=(AttachEnergyGeneric(source='discard', count=4, basic_only=True, self_only=True, optional=True),), tails=(DiscardOwnEnergy(count=1),)),),
    },
    'sv4-228': {
        # Once during your turn, if your opponent has 4 or fewer Prize cards remaining, you may attach a Basic Fighting Energy card from your discard pile to th
        'Magnetic Absorption': (AbilityGate('g:opp_prizes_at_most', '4'), AttachEnergyGeneric(source='discard', count=1, basic_only=True, energy_type='Fighting', self_only=True),),
    },
    'sv4-231': {
        # Once during your turn, you may draw a card. If this Pokémon is in the Active Spot, draw 1 more card.
        'Coin Bonus': (DrawMoreIfSelfActive(base=1, extra=1),),
    },
    'sv4-232': {
        # Once during your turn, you may heal 20 damage from each of your Pokémon.
        'Humming Heal': (HealAllOwnPokemon(amount=20),),
    },
    'sv4-250': {
        # Once during your turn, if your opponent has 4 or fewer Prize cards remaining, you may attach a Basic Fighting Energy card from your discard pile to th
        'Magnetic Absorption': (AbilityGate('g:opp_prizes_at_most', '4'), AttachEnergyGeneric(source='discard', count=1, basic_only=True, energy_type='Fighting', self_only=True),),
    },
    'sv4-252': {
        # Once during your turn, you may draw a card. If this Pokémon is in the Active Spot, draw 1 more card.
        'Coin Bonus': (DrawMoreIfSelfActive(base=1, extra=1),),
    },
    'sv4-253': {
        # Once during your turn, you may heal 20 damage from each of your Pokémon.
        'Humming Heal': (HealAllOwnPokemon(amount=20),),
    },
    'sv4-72': {
        # Once during your turn, you may attach a Basic Psychic Energy card from your hand to 1 of your Benched Pokémon. If you attached Energy to a Pokémon in 
        'Clairvoyant Sense': (AttachEnergyGeneric(source='hand', count=1, basic_only=True, energy_type='Psychic', bench_only=True, single_target=True), IfLastAttachSucceeded((Draw(2),)),),
    },
    'sv4pt5-113': {
        # Once during your turn, you may heal 20 damage from your Active Evolution Pokémon.
        'Ardent Dancing': (PickPokemonThen(side='own', action='heal', amount=20, active_only=True, evolved_only=True),),
    },
    'sv4pt5-115': {
        # As often as you like during your turn, you may move a Fire Energy from 1 of your Benched Pokémon to your Active Pokémon.
        'Fire Off': (MoveEnergyGeneric(owner='own', sources='bench', dests='active', energy_type='Fire'),),
    },
    'sv4pt5-117': {
        # As often as you like during your turn, you may move 1 damage counter from 1 of your other Pokémon to this Pokémon.
        'Strange Behavior': (MoveDamageCounters(count=1, scope='other_own_to_self'),),
    },
    'sv4pt5-130': {
        # As often as you like during your turn, you may attach a Basic Water Energy card from your hand to 1 of your Pokémon.
        'Super Cold': (AttachEnergyGeneric(source='hand', count=1, basic_only=True, energy_type='Water', single_target=True),),
    },
    'sv4pt5-144': {
        # Once during your turn, you may search your deck for a Basic Lightning Energy card and attach it to this Pokémon. Then, shuffle your deck.
        'Electrogenesis': (AttachEnergyGeneric(source='deck', count=1, basic_only=True, energy_type='Lightning', self_only=True),),
    },
    'sv4pt5-147': {
        # Once during your turn, you may attach a Therapeutic Energy card from your hand to 1 of your Pokémon.
        'Balloon Therapy': (AttachEnergyGeneric(source='hand', energy_name='Therapeutic Energy'),),
    },
    'sv4pt5-15': {
        # As often as you like during your turn, you may move a Fire Energy from 1 of your Benched Pokémon to your Active Pokémon.
        'Fire Off': (MoveEnergyGeneric(owner='own', sources='bench', dests='active', energy_type='Fire'),),
    },
    'sv4pt5-152': {
        # Once during your turn, you may attach a Basic Psychic Energy card from your hand to 1 of your Benched Pokémon. If you attached Energy to a Pokémon in 
        'Clairvoyant Sense': (AttachEnergyGeneric(source='hand', count=1, basic_only=True, energy_type='Psychic', bench_only=True, single_target=True), IfLastAttachSucceeded((Draw(2),)),),
    },
    'sv4pt5-167': {
        # You must discard a card from your hand in order to use this Ability. Once during your turn, you may draw 3 cards.
        'Gather Materials': (AbilityGate('hand_matches', 'any:1'), DiscardMatchingFromHand('any', 1), Draw(3),),
    },
    'sv4pt5-188': {
        # Once during your turn, you may switch out your opponent's Active Pokémon to the Bench. (Your opponent chooses the new Active Pokémon.)
        'Intimidating Howl': (ForceOpponentSwitchOpponentChooses(),),
    },
    'sv4pt5-193': {
        # You must discard an Energy card from your hand in order to use this Ability. Once during your turn, you may draw cards until you have 6 cards in your 
        'Rumbling Engine': (AbilityGate('hand_matches', 'any_energy:1'), DiscardMatchingFromHand('any_energy', 1), DrawUpTo(6),),
    },
    'sv4pt5-2': {
        # Once during your turn, you may search your deck for up to 5 Basic Grass Energy cards and attach them to your Pokémon in any way you like. Then, shuffl
        'Exploding Energy': (AttachEnergyGeneric(source='deck', count=5, basic_only=True, energy_type='Grass'), IfLastAttachSucceeded((KnockOutSelfEffect(),)),),
    },
    'sv4pt5-200': {
        # Once during your turn, you may put 1 damage counter on this Pokémon. If you do, draw a card.
        'Zooming Draw': (SelfDamage(10), Draw(1),),
    },
    'sv4pt5-202': {
        # Once during your turn, you may put up to 2 Leftovers cards from your discard pile into your hand.
        'Voraciousness': (SearchDiscardByCriterionToHand('named:Leftovers', count=2),),
    },
    'sv4pt5-205': {
        # Once during your turn, you may shuffle your hand and put it on the bottom of your deck. If you put any cards on the bottom of your deck in this way, d
        'Nest Stash': (ShuffleHandToBottomThenDraw(1),),
    },
    'sv4pt5-212': {
        # Once during your turn, you may search your deck for up to 5 Basic Grass Energy cards and attach them to your Pokémon in any way you like. Then, shuffl
        'Exploding Energy': (AttachEnergyGeneric(source='deck', count=5, basic_only=True, energy_type='Grass'), IfLastAttachSucceeded((KnockOutSelfEffect(),)),),
    },
    'sv4pt5-216': {
        # Once during your turn, you may draw cards until you have 3 cards in your hand.
        'Restart': (DrawUpTo(3),),
    },
    'sv4pt5-217': {
        # As often as you like during your turn, you may attach a Basic Psychic Energy card from your discard pile to 1 of your Psychic Pokémon. If you attached
        'Psychic Embrace': (AttachEnergyGeneric(source='discard', energy_type='Psychic', basic_only=True, target_type='Psychic', counters_on_target=2, no_ko_target=True),),
    },
    'sv4pt5-219': {
        # Once during your turn, if a Stadium is in play, you may make your opponent's Active Pokémon Poisoned.
        'Toxic Wetland': (AbilityGate('g:stadium_in_play', ''), InflictStatusOnDefender('poisoned'),),
    },
    'sv4pt5-221': {
        # Once during your turn, you may search your deck for a card and put it into your hand. Then, shuffle your deck. You can't use more than 1 Quick Search 
        'Quick Search': (AbilityGate('name_not_used', 'Quick Search'), MarkAbilityNameUsed('Quick Search'), SearchDeckAnyCardToHand(1),),
    },
    'sv4pt5-232': {
        # Once during your turn, you may draw cards until you have 3 cards in your hand.
        'Restart': (DrawUpTo(3),),
    },
    'sv4pt5-233': {
        # As often as you like during your turn, you may attach a Basic Psychic Energy card from your discard pile to 1 of your Psychic Pokémon. If you attached
        'Psychic Embrace': (AttachEnergyGeneric(source='discard', energy_type='Psychic', basic_only=True, target_type='Psychic', counters_on_target=2, no_ko_target=True),),
    },
    'sv4pt5-242': {
        # Once during your turn, if this Pokémon is in the Active Spot, you may search your deck for up to 2 Basic Water Energy cards, reveal them, and put them
        'Shivery Chill': (AbilityGate('active_only', ''), SearchDeckByCriterionToHand('energy_type:Water', count=2),),
    },
    'sv4pt5-243': {
        # Once during your turn, you may search your deck for up to 2 Basic Lightning Pokémon and put them onto your Bench. Then, shuffle your deck.
        'Tandem Unit': (SearchDeckForBasicPokemonToBench(count=2, pokemon_type='Lightning'),),
    },
    'sv4pt5-245': {
        # Once during your turn, you may attach up to 2 Basic Fighting Energy cards from your discard pile to your Basic Fighting Pokémon in any way you like. I
        'Dino Cry': (AttachEnergyGeneric(source='discard', count=2, basic_only=True, energy_type='Fighting', target_type='Fighting', target_subtype='Basic'), EndTurnAfterThisAbility(),),
    },
    'sv4pt5-26': {
        # Once during your turn, you may attach a Basic Psychic Energy card from your hand to 1 of your Benched Pokémon. If you attached Energy to a Pokémon in 
        'Clairvoyant Sense': (AttachEnergyGeneric(source='hand', count=1, basic_only=True, energy_type='Psychic', bench_only=True, single_target=True), IfLastAttachSucceeded((Draw(2),)),),
    },
    'sv4pt5-29': {
        # As often as you like during your turn, you may attach a Basic Psychic Energy card from your discard pile to 1 of your Psychic Pokémon. If you attached
        'Psychic Embrace': (AttachEnergyGeneric(source='discard', energy_type='Psychic', basic_only=True, target_type='Psychic', counters_on_target=2, no_ko_target=True),),
    },
    'sv4pt5-57': {
        # Once during your turn, you may switch your Active Pokémon with 1 of your Benched Pokémon.
        'Night Gate': (SwitchActiveWithBench(),),
    },
    'sv4pt5-59': {
        # Once during your turn, if a Stadium is in play, you may make your opponent's Active Pokémon Poisoned.
        'Toxic Wetland': (AbilityGate('g:stadium_in_play', ''), InflictStatusOnDefender('poisoned'),),
    },
    'sv4pt5-63': {
        # Once during your turn, you may switch out your opponent's Active Pokémon to the Bench. (Your opponent chooses the new Active Pokémon.)
        'Intimidating Howl': (ForceOpponentSwitchOpponentChooses(),),
    },
    'sv4pt5-65': {
        # You must discard an Energy card from your hand in order to use this Ability. Once during your turn, you may draw cards until you have 6 cards in your 
        'Rumbling Engine': (AbilityGate('hand_matches', 'any_energy:1'), DiscardMatchingFromHand('any_energy', 1), DrawUpTo(6),),
    },
    'sv5-166': {
        # Once during your turn, you may search your deck for a Stadium card, reveal it, and put it into your hand. Then, shuffle your deck.
        'Changing Seasons': (SearchDeckByCriterionToHand('stadium', count=1),),
    },
    'sv5-17': {
        # Once during your turn, you may search your deck for a Stadium card, reveal it, and put it into your hand. Then, shuffle your deck.
        'Changing Seasons': (SearchDeckByCriterionToHand('stadium', count=1),),
    },
    'sv6-131': {
        # Once during your turn, if this Pokémon is in the Active Spot, you may look at the top 6 cards of your deck, reveal a Supporter card you find there, an
        'Attract Customers': (AbilityGate('active_only', ''), LookTopNTake(n=6, m=1, criterion='supporter', exact=False, rest='shuffle'),),
    },
    'sv6-173': {
        # Once during your turn, you may attach a Basic Fire Energy card, a Basic Fighting Energy card, or 1 of each from your hand to your Pokémon in any way y
        'Pyro Dance': (AttachEnergyGeneric(source='hand', count=2, energy_types_any=('Fire', 'Fighting'), distinct_energy_types=True),),
    },
    'sv6-186': {
        # Once during your turn, if this Pokémon is in the Active Spot, you may look at the top 6 cards of your deck, reveal a Supporter card you find there, an
        'Attract Customers': (AbilityGate('active_only', ''), LookTopNTake(n=6, m=1, criterion='supporter', exact=False, rest='shuffle'),),
    },
    'sv6-190': {
        # Once during your turn, you may attach a Basic Grass Energy card from your hand to this Pokémon. If you attached Energy to a Pokémon in this way, draw 
        'Teal Dance': (AttachEnergyGeneric(source='hand', count=1, basic_only=True, energy_type='Grass', self_only=True), IfLastAttachSucceeded((Draw(1),)),),
    },
    'sv6-211': {
        # Once during your turn, you may attach a Basic Grass Energy card from your hand to this Pokémon. If you attached Energy to a Pokémon in this way, draw 
        'Teal Dance': (AttachEnergyGeneric(source='hand', count=1, basic_only=True, energy_type='Grass', self_only=True), IfLastAttachSucceeded((Draw(1),)),),
    },
    'sv6-221': {
        # Once during your turn, you may attach a Basic Grass Energy card from your hand to this Pokémon. If you attached Energy to a Pokémon in this way, draw 
        'Teal Dance': (AttachEnergyGeneric(source='hand', count=1, basic_only=True, energy_type='Grass', self_only=True), IfLastAttachSucceeded((Draw(1),)),),
    },
    'sv6-33': {
        # Once during your turn, you may attach a Basic Fire Energy card, a Basic Fighting Energy card, or 1 of each from your hand to your Pokémon in any way y
        'Pyro Dance': (AttachEnergyGeneric(source='hand', count=2, energy_types_any=('Fire', 'Fighting'), distinct_energy_types=True),),
    },
    'sv6-38': {
        # Once during your turn, you may have each player draw a card.
        'Alluring Light': (Draw(1), OpponentDraws(1),),
    },
    'sv6-72': {
        # Once during your turn, you may look at the top card of your deck. You may discard that card.
        'Snack Seek': (LookTopCardMayDiscard(),),
    },
    'sv6-80': {
        # Once during your turn, if this Pokémon is in the Active Spot, you may shuffle it and all attached cards into your deck.
        'Teleporter': (AbilityGate('active_only', ''), ShuffleSelfIntoDeck(),),
    },
    'sv6pt5-19': {
        # Once during your turn, you may put 5 damage counters on 1 of your opponent's Pokémon. If you use this Ability, this Pokémon is Knocked Out.
        'Cursed Blast': (PickPokemonThen(side='opp', action='put_counters', amount=5), KnockOutSelfEffect(),),
    },
    'sv6pt5-20': {
        # Once during your turn, you may put 13 damage counters on 1 of your opponent's Pokémon. If you use this Ability, this Pokémon is Knocked Out.
        'Cursed Blast': (PickPokemonThen(side='opp', action='put_counters', amount=13), KnockOutSelfEffect(),),
    },
    'sv6pt5-69': {
        # Once during your turn, you may put 5 damage counters on 1 of your opponent's Pokémon. If you use this Ability, this Pokémon is Knocked Out.
        'Cursed Blast': (PickPokemonThen(side='opp', action='put_counters', amount=5), KnockOutSelfEffect(),),
    },
    'sv6pt5-70': {
        # Once during your turn, you may put 13 damage counters on 1 of your opponent's Pokémon. If you use this Ability, this Pokémon is Knocked Out.
        'Cursed Blast': (PickPokemonThen(side='opp', action='put_counters', amount=13), KnockOutSelfEffect(),),
    },
    'sv6pt5-84': {
        # Once during your turn, if any of your Pokémon were Knocked Out during your opponent's last turn, you may draw 3 cards. You can't use more than 1 Flip 
        'Flip the Script': (AbilityGate('name_not_used', 'Flip the Script'), AbilityGate('g:ko_last_turn', ''), MarkAbilityNameUsed('Flip the Script'), Draw(3),),
    },
    'sv6pt5-92': {
        # Once during your turn, if any of your Pokémon were Knocked Out during your opponent's last turn, you may draw 3 cards. You can't use more than 1 Flip 
        'Flip the Script': (AbilityGate('name_not_used', 'Flip the Script'), AbilityGate('g:ko_last_turn', ''), MarkAbilityNameUsed('Flip the Script'), Draw(3),),
    },
    'sv7-1': {
        # Once during your turn, if this Pokémon is in the Active Spot, you may heal 60 damage from 1 of your Pokémon.
        'Tranquil Flower': (AbilityGate('active_only', ''), HealTarget(60),),
    },
    'sv7-14': {
        # Once during your turn, you may attach a Basic Grass Energy card from your hand to 1 of your Pokémon. If you attached Energy to a Pokémon in this way, 
        'Ripening Charge': (AttachEnergyGeneric(source='hand', count=1, basic_only=True, energy_type='Grass', single_target=True, heal_on_target=30),),
    },
    'sv7-156': {
        # Once during your turn, you may attach a Basic Grass Energy card from your hand to 1 of your Pokémon. If you attached Energy to a Pokémon in this way, 
        'Ripening Charge': (AttachEnergyGeneric(source='hand', count=1, basic_only=True, energy_type='Grass', single_target=True, heal_on_target=30),),
    },
    'sv7-167': {
        # Once during your turn, you may attach a Basic Grass Energy card from your hand to 1 of your Pokémon. If you attached Energy to a Pokémon in this way, 
        'Ripening Charge': (AttachEnergyGeneric(source='hand', count=1, basic_only=True, energy_type='Grass', single_target=True, heal_on_target=30),),
    },
    'sv8-194': {
        # Once during your turn, if this Pokémon is in the Active Spot, you may make your opponent's Active Pokémon Asleep.
        'Calming Light': (AbilityGate('active_only', ''), InflictStatusOnDefender('asleep'),),
    },
    'sv8-59': {
        # Once during your turn, you may attach up to 3 Basic Energy cards from your discard pile to your Lightning Pokémon in any way you like. If you use this
        'Overvolt Discharge': (AttachEnergyGeneric(source='discard', count=3, basic_only=True, target_type='Lightning'), KnockOutSelfEffect(),),
    },
    'sv8-9': {
        # Once during your turn, if this Pokémon is in the Active Spot, you may make your opponent's Active Pokémon Asleep.
        'Calming Light': (AbilityGate('active_only', ''), InflictStatusOnDefender('asleep'),),
    },
    'sv8pt5-12': {
        # Once during your turn, you may attach a Basic Grass Energy card from your hand to this Pokémon. If you attached Energy to a Pokémon in this way, draw 
        'Teal Dance': (AttachEnergyGeneric(source='hand', count=1, basic_only=True, energy_type='Grass', self_only=True), IfLastAttachSucceeded((Draw(1),)),),
    },
    'sv8pt5-145': {
        # Once during your turn, you may attach a Basic Grass Energy card from your hand to this Pokémon. If you attached Energy to a Pokémon in this way, draw 
        'Teal Dance': (AttachEnergyGeneric(source='hand', count=1, basic_only=True, energy_type='Grass', self_only=True), IfLastAttachSucceeded((Draw(1),)),),
    },
    'sv8pt5-159': {
        # Once during your turn, if your opponent has 4 or fewer Prize cards remaining, you may attach a Basic Fighting Energy card from your discard pile to th
        'Magnetic Absorption': (AbilityGate('g:opp_prizes_at_most', '4'), AttachEnergyGeneric(source='discard', count=1, basic_only=True, energy_type='Fighting', self_only=True),),
    },
    'sv8pt5-164': {
        # Once during your turn, you may draw a card. If this Pokémon is in the Active Spot, draw 1 more card.
        'Coin Bonus': (DrawMoreIfSelfActive(base=1, extra=1),),
    },
    'sv8pt5-177': {
        # Once during your turn, you may attach a Basic Grass Energy card from your hand to this Pokémon. If you attached Energy to a Pokémon in this way, draw 
        'Teal Dance': (AttachEnergyGeneric(source='hand', count=1, basic_only=True, energy_type='Grass', self_only=True), IfLastAttachSucceeded((Draw(1),)),),
    },
    'sv8pt5-56': {
        # Once during your turn, if your opponent has 4 or fewer Prize cards remaining, you may attach a Basic Fighting Energy card from your discard pile to th
        'Magnetic Absorption': (AbilityGate('g:opp_prizes_at_most', '4'), AttachEnergyGeneric(source='discard', count=1, basic_only=True, energy_type='Fighting', self_only=True),),
    },
    'sv9-172': {
        # As often as you like during your turn, you may attach a Basic Lightning Energy card from your hand to 1 of your Iono's Pokémon.
        'Electric Streamer': (AttachEnergyGeneric(source='hand', energy_type='Lightning', basic_only=True, target_name_prefix="Iono's"),),
    },
    'sv9-183': {
        # As often as you like during your turn, you may attach a Basic Lightning Energy card from your hand to 1 of your Iono's Pokémon.
        'Electric Streamer': (AttachEnergyGeneric(source='hand', energy_type='Lightning', basic_only=True, target_name_prefix="Iono's"),),
    },
    'sv9-188': {
        # As often as you like during your turn, you may attach a Basic Lightning Energy card from your hand to 1 of your Iono's Pokémon.
        'Electric Streamer': (AttachEnergyGeneric(source='hand', energy_type='Lightning', basic_only=True, target_name_prefix="Iono's"),),
    },
    'sv9-53': {
        # As often as you like during your turn, you may attach a Basic Lightning Energy card from your hand to 1 of your Iono's Pokémon.
        'Electric Streamer': (AttachEnergyGeneric(source='hand', energy_type='Lightning', basic_only=True, target_name_prefix="Iono's"),),
    },
    'sv9-75': {
        # Once during your turn, you may heal 30 damage from 1 of your Pokémon.
        'Confectionary Gift': (HealTarget(30),),
    },
    'svp-116': {
        # Once during your turn, you may attach a Basic Fire Energy card, a Basic Fighting Energy card, or 1 of each from your hand to your Pokémon in any way y
        'Pyro Dance': (AttachEnergyGeneric(source='hand', count=2, energy_types_any=('Fire', 'Fighting'), distinct_energy_types=True),),
    },
    'svp-118': {
        # Once during your turn, if this Pokémon is in the Active Spot, you may look at the top 6 cards of your deck, reveal a Supporter card you find there, an
        'Attract Customers': (AbilityGate('active_only', ''), LookTopNTake(n=6, m=1, criterion='supporter', exact=False, rest='shuffle'),),
    },
    'svp-153': {
        # Once during your turn, you may attach up to 3 Basic Energy cards from your discard pile to your Lightning Pokémon in any way you like. If you use this
        'Overvolt Discharge': (AttachEnergyGeneric(source='discard', count=3, basic_only=True, target_type='Lightning'), KnockOutSelfEffect(),),
    },
    'svp-159': {
        # Once during your turn, you may attach up to 3 Basic Energy cards from your discard pile to your Lightning Pokémon in any way you like. If you use this
        'Overvolt Discharge': (AttachEnergyGeneric(source='discard', count=3, basic_only=True, target_type='Lightning'), KnockOutSelfEffect(),),
    },
    'svp-166': {
        # Once during your turn, you may attach a Basic Grass Energy card from your hand to this Pokémon. If you attached Energy to a Pokémon in this way, draw 
        'Teal Dance': (AttachEnergyGeneric(source='hand', count=1, basic_only=True, energy_type='Grass', self_only=True), IfLastAttachSucceeded((Draw(1),)),),
    },
    'svp-19': {
        # As often as you like during your turn, you may attach a Basic Water Energy card from your hand to 1 of your Pokémon.
        'Super Cold': (AttachEnergyGeneric(source='hand', count=1, basic_only=True, energy_type='Water', single_target=True),),
    },
    'svp-194': {
        # As often as you like during your turn, you may attach a Basic Lightning Energy card from your hand to 1 of your Iono's Pokémon.
        'Electric Streamer': (AttachEnergyGeneric(source='hand', energy_type='Lightning', basic_only=True, target_name_prefix="Iono's"),),
    },
    'svp-20': {
        # You must discard a card from your hand in order to use this Ability. Once during your turn, you may draw 3 cards.
        'Gather Materials': (AbilityGate('hand_matches', 'any:1'), DiscardMatchingFromHand('any', 1), Draw(3),),
    },
    'svp-28': {
        # Once during your turn, you may search your deck for up to 2 Basic Lightning Pokémon and put them onto your Bench. Then, shuffle your deck.
        'Tandem Unit': (SearchDeckForBasicPokemonToBench(count=2, pokemon_type='Lightning'),),
    },
    'svp-29': {
        # Once during your turn, you may attach up to 2 Basic Fighting Energy cards from your discard pile to your Basic Fighting Pokémon in any way you like. I
        'Dino Cry': (AttachEnergyGeneric(source='discard', count=2, basic_only=True, energy_type='Fighting', target_type='Fighting', target_subtype='Basic'), EndTurnAfterThisAbility(),),
    },
    'svp-30': {
        # Once during your turn, if this Pokémon is in the Active Spot, you may search your deck for up to 2 Basic Water Energy cards, reveal them, and put them
        'Shivery Chill': (AbilityGate('active_only', ''), SearchDeckByCriterionToHand('energy_type:Water', count=2),),
    },
    'svp-33': {
        # You must discard a Basic Grass Energy card from your hand in order to use this Ability. Once during your turn, you may put 3 damage counters on 1 of y
        'Bouquet Magic': (AbilityGate('hand_matches', 'energy_type:Grass:1'), DiscardMatchingFromHand('energy_type:Grass', 1), PickPokemonThen(side='opp', action='put_counters', amount=3, bench_only=True),),
    },
    'svp-5': {
        # Once during your turn, you may attach a Basic Energy card from your hand to 1 of your Pokémon.
        'Energy Carnival': (AttachEnergyGeneric(source='hand', count=1, basic_only=True, single_target=True),),
    },
    'svp-51': {
        # Once during your turn, you may put up to 2 Leftovers cards from your discard pile into your hand.
        'Voraciousness': (SearchDiscardByCriterionToHand('named:Leftovers', count=2),),
    },
    'svp-53': {
        # Once during your turn, you may draw cards until you have 3 cards in your hand.
        'Restart': (DrawUpTo(3),),
    },
    'svp-59': {
        # Once during your turn, you may attach a Basic Psychic Energy card from your hand to 1 of your Benched Pokémon. If you attached Energy to a Pokémon in 
        'Clairvoyant Sense': (AttachEnergyGeneric(source='hand', count=1, basic_only=True, energy_type='Psychic', bench_only=True, single_target=True), IfLastAttachSucceeded((Draw(2),)),),
    },
    'svp-6': {
        # Once during your turn, you may search your deck for a Basic Lightning Energy card and attach it to this Pokémon. Then, shuffle your deck.
        'Electrogenesis': (AttachEnergyGeneric(source='deck', count=1, basic_only=True, energy_type='Lightning', self_only=True),),
    },
    'svp-78': {
        # You must discard a Basic Grass Energy card from your hand in order to use this Ability. Once during your turn, you may put 3 damage counters on 1 of y
        'Bouquet Magic': (AbilityGate('hand_matches', 'energy_type:Grass:1'), DiscardMatchingFromHand('energy_type:Grass', 1), PickPokemonThen(side='opp', action='put_counters', amount=3, bench_only=True),),
    },
    'svp-8': {
        # You must discard an Energy card from your hand in order to use this Ability. Once during your turn, you may draw cards until you have 6 cards in your 
        'Rumbling Engine': (AbilityGate('hand_matches', 'any_energy:1'), DiscardMatchingFromHand('any_energy', 1), DrawUpTo(6),),
    },
    'swsh1-14': {
        # Once during your turn, you may search your deck for up to 2 Grass Energy cards and attach them to 1 of your Pokémon. Then, shuffle your deck.
        'Voltage Beat': (AttachEnergyGeneric(source='deck', count=2, basic_only=True, energy_type='Grass', single_target=True, optional=True),),
    },
    'swsh1-147': {
        # You must discard a card from your hand in order to use this Ability. Once during your turn, you may draw 2 cards.
        'Make Do': (AbilityGate('hand_matches', 'any:1'), DiscardMatchingFromHand('any', 1), Draw(2),),
    },
    'swsh1-148': {
        # Once during your turn, you may switch a card from your hand with the top card of your deck.
        'Primate Wisdom': (SwapHandCardWithDeckTop(),),
    },
    'swsh1-19': {
        # Once during your turn, you may look at the top 3 cards of your opponent's deck and put them back in any order.
        "Bug's Radar": (LookOpponentDeckTopReorder(3),),
    },
    'swsh1-192': {
        # Once during your turn, you may heal 20 damage from your Active Pokémon.
        'Watch Over': (HealOwnActiveFixed(20),),
    },
    'swsh1-64': {
        # As often as you like during your turn, you may attach a Water Energy card from your hand to 1 of your Benched Water Pokémon.
        'Ice Dance': (AttachEnergyGeneric(source='hand', count=1, basic_only=True, energy_type='Water', single_target=True, bench_only=True, target_type='Water'),),
    },
    'swsh1-85': {
        # As often as you like during your turn, you may move 1 damage counter from 1 of your Psychic Pokémon to another of your Psychic Pokémon.
        'Life Shaker': (MoveDamageCounters(count=1, scope='own', pokemon_type='Psychic'),),
    },
    'swsh1-91': {
        # Once during your turn, you may heal 20 damage from your Active Pokémon.
        'Watch Over': (HealOwnActiveFixed(20),),
    },
    'swsh10-100': {
        # You must discard a card from your hand in order to use this Ability. Once during your turn, you may draw 3 cards.
        'Wily Stance': (AbilityGate('hand_matches', 'any:1'), DiscardMatchingFromHand('any', 1), Draw(3),),
    },
    'swsh10-102': {
        # During your turn, you may put 4 damage counters on 1 of your opponent's Pokémon. (You can't use more than 1 VSTAR Power in a game.)
        'Moon Cleave Star': (DamageCounterOnChosenOpponentPokemon(count=4),),
    },
    'swsh10-107': {
        # Once during your turn, you may look at the top 6 cards of your deck and attach any number of Metal Energy cards you find there to your Pokémon in any 
        'Giga Magnet': (AttachEnergyGeneric(source='deck', count=99, deck_limit=6, basic_only=True, energy_type='Metal', optional=True),),
    },
    'swsh10-118': {
        # Once during your turn, if this Pokémon is in the Active Spot, you may draw cards until you have 4 cards in your hand. You can't use more than 1 Dragon
        "Dragon's Hoard": (AbilityGate('name_not_used', "Dragon's Hoard"), AbilityGate('active_only', ''), MarkAbilityNameUsed("Dragon's Hoard"), DrawUpTo(4),),
    },
    'swsh10-133': {
        # Once during your turn, if this Pokémon is in the Active Spot, you may search your deck for up to 2 Pokémon Tool cards, reveal them, and put them into 
        'Back Order': (AbilityGate('active_only', ''), SearchDeckByCriterionToHand('pokemon_tool', count=2),),
    },
    'swsh10-179': {
        # Once during your turn, if this Pokémon is in the Active Spot, you may search your deck for up to 2 Pokémon Tool cards, reveal them, and put them into 
        'Back Order': (AbilityGate('active_only', ''), SearchDeckByCriterionToHand('pokemon_tool', count=2),),
    },
    'swsh10-191': {
        # Once during your turn, if you have a Stadium in play, you may heal 50 damage from this Pokémon.
        'Magma Gain': (AbilityGate('has_named_pokemon_in_play', 'a Stadium'), HealSelf(50),),
    },
    'swsh10-192': {
        # During your turn, you may attach up to 3 Water Energy cards from your discard pile to your Water Pokémon in any way you like. (You can't use more than
        'Star Portal': (AttachEnergyGeneric(source='discard', count=3, basic_only=True, energy_type='Water', target_type='Water', optional=True),),
    },
    'swsh10-195': {
        # During your turn, you may draw cards until you have 8 cards in your hand. (You can't use more than 1 VSTAR Power in a game.)
        'Star of Fortune': (DrawUpTo(8),),
    },
    'swsh10-197': {
        # During your turn, you may put 4 damage counters on 1 of your opponent's Pokémon. (You can't use more than 1 VSTAR Power in a game.)
        'Moon Cleave Star': (DamageCounterOnChosenOpponentPokemon(count=4),),
    },
    'swsh10-208': {
        # During your turn, you may attach up to 3 Water Energy cards from your discard pile to your Water Pokémon in any way you like. (You can't use more than
        'Star Portal': (AttachEnergyGeneric(source='discard', count=3, basic_only=True, energy_type='Water', target_type='Water', optional=True),),
    },
    'swsh10-209': {
        # During your turn, you may put 4 damage counters on 1 of your opponent's Pokémon. (You can't use more than 1 VSTAR Power in a game.)
        'Moon Cleave Star': (DamageCounterOnChosenOpponentPokemon(count=4),),
    },
    'swsh10-26': {
        # Once during your turn, if you have a Stadium in play, you may heal 50 damage from this Pokémon.
        'Magma Gain': (AbilityGate('has_named_pokemon_in_play', 'a Stadium'), HealSelf(50),),
    },
    'swsh10-62': {
        # Once during your turn, you may search your deck for a Supporter card, reveal it, and put it into your hand. Then, shuffle your deck.
        'Buddy Catch': (SearchDeckMultiCriteria(('supporter',)),),
    },
    'swsh10-69': {
        # Once during your turn, you may draw a card.
        'Hurried Gait': (Draw(1),),
    },
    'swsh10-99': {
        # During your turn, you may put up to 2 Item cards from your discard pile into your hand. (You can't use more than 1 VSTAR Power in a game.)
        'Star Abyss': (SearchDiscardByCriterionToHand('item', count=2),),
    },
    'swsh10tg-TG02': {
        # Once during your turn, you may put 2 damage counters on 1 of your opponent's Pokémon. If you placed any damage counters in this way, shuffle this Poké
        'Apple Drop': (PickPokemonThen(side='opp', action='put_counters', amount=2, then=(ShuffleSelfIntoDeck(),)),),
    },
    'swsh10tg-TG04': {
        # As often as you like during your turn, you may attach a Water Energy card from your hand to 1 of your Benched Water Pokémon.
        'Ice Dance': (AttachEnergyGeneric(source='hand', count=1, basic_only=True, energy_type='Water', single_target=True, bench_only=True, target_type='Water'),),
    },
    'swsh10tg-TG06': {
        # Once during your turn, you may draw a card.
        'Hurried Gait': (Draw(1),),
    },
    'swsh10tg-TG11': {
        # As often as you like during your turn, you may move a Metal Energy from 1 of your Pokémon to another of your Pokémon.
        'Metal Transfer': (MoveEnergyGeneric(owner='own', sources='any', dests='any', energy_type='Metal', basic_only=False),),
    },
    'swsh10tg-TG16': {
        # You must discard 2 cards from your hand in order to use this Ability. Once during your turn, you may draw a card.
        'Reconstitute': (AbilityGate('hand_matches', 'any:2'), DiscardMatchingFromHand('any', 2), Draw(1),),
    },
    'swsh10tg-TG18': {
        # Once during your turn, you may attach a Psychic Energy card from your hand to 1 of your Benched Psychic Pokémon. If you attached Energy to a Pokémon i
        'Underworld Door': (AttachEnergyGeneric(source='hand', count=1, basic_only=True, energy_type='Psychic', bench_only=True, single_target=True, target_type='Psychic'), IfLastAttachSucceeded((Draw(2),)),),
    },
    'swsh10tg-TG20': {
        # Once during your turn, you may attach a Darkness Energy card from your discard pile to this Pokémon. You can't use more than 1 Direflame Wings Ability
        'Direflame Wings': (AbilityGate('name_not_used', 'Direflame Wings'), MarkAbilityNameUsed('Direflame Wings'), AttachEnergyFromDiscardToSelf(energy_type='Darkness', count=1),),
    },
    'swsh10tg-TG30': {
        # Once during your turn, you may attach a Psychic Energy card from your hand to 1 of your Benched Psychic Pokémon. If you attached Energy to a Pokémon i
        'Underworld Door': (AttachEnergyGeneric(source='hand', count=1, basic_only=True, energy_type='Psychic', bench_only=True, single_target=True, target_type='Psychic'), IfLastAttachSucceeded((Draw(2),)),),
    },
    'swsh11-119': {
        # During your turn, you may make your opponent's Active Pokémon Paralyzed and Poisoned. During Pokémon Checkup, put 3 damage counters on that Pokémon in
        'Hazard Star': (InflictStatusOnDefender('paralyzed'), InflictStatusOnDefender('poisoned'), InflictHeavyPoison(severity=3),),
    },
    'swsh11-137': {
        # Once during your turn, if this Pokémon is on your Bench, you may shuffle it and all attached cards into your deck.
        'Vanishing Wings': (AbilityGate('bench_only', ''), ShuffleSelfIntoDeck(),),
    },
    'swsh11-147': {
        # During your turn, you may discard your hand and draw 7 cards. (You can't use more than 1 VSTAR Power in a game.)
        'Phantom Star': (DiscardHandThenDraw(7),),
    },
    'swsh11-176': {
        # Once during your turn, you may draw 3 cards. If you use this Ability, your turn ends.
        'Instant Charge': (Draw(3), EndTurnAfterThisAbility(),),
    },
    'swsh11-177': {
        # Once during your turn, you may draw 3 cards. If you use this Ability, your turn ends.
        'Instant Charge': (Draw(3), EndTurnAfterThisAbility(),),
    },
    'swsh11-188': {
        # Once during your turn, if this Pokémon is on your Bench, you may shuffle it and all attached cards into your deck.
        'Vanishing Wings': (AbilityGate('bench_only', ''), ShuffleSelfIntoDeck(),),
    },
    'swsh11-197': {
        # Once during your turn, you may discard the top card of your deck. If that card is a Water Energy card, attach it to 1 of your Pokémon.
        'Glaciated World': (MillTopThenAttachEnergy('Water'),),
    },
    'swsh11-200': {
        # During your turn, you may make your opponent's Active Pokémon Paralyzed and Poisoned. During Pokémon Checkup, put 3 damage counters on that Pokémon in
        'Hazard Star': (InflictStatusOnDefender('paralyzed'), InflictStatusOnDefender('poisoned'), InflictHeavyPoison(severity=3),),
    },
    'swsh11-202': {
        # During your turn, you may heal all damage from this Pokémon. (You can't use more than 1 VSTAR Power in a game.)
        'Moisture Star': (HealSelf(9999),),
    },
    'swsh11-203': {
        # During your turn, you may discard your hand and draw 7 cards. (You can't use more than 1 VSTAR Power in a game.)
        'Phantom Star': (DiscardHandThenDraw(7),),
    },
    'swsh11-213': {
        # During your turn, you may discard your hand and draw 7 cards. (You can't use more than 1 VSTAR Power in a game.)
        'Phantom Star': (DiscardHandThenDraw(7),),
    },
    'swsh11-49': {
        # Once during your turn, you may discard the top card of your deck. If that card is a Water Energy card, attach it to 1 of your Pokémon.
        'Glaciated World': (MillTopThenAttachEnergy('Water'),),
    },
    'swsh11-58': {
        # Once during your turn, you may draw 3 cards. If you use this Ability, your turn ends.
        'Instant Charge': (Draw(3), EndTurnAfterThisAbility(),),
    },
    'swsh11-8': {
        # Once during your turn, you may draw cards until you have 6 cards in your hand.
        'Stoked Straw': (DrawUpTo(6),),
    },
    'swsh11tg-TG03': {
        # Once during your turn, you may look at the top 3 cards of your deck and put 1 of them into your hand. Discard the other cards.
        'Battle Sense': (LookTopNKeepMRestToDiscard(n=3, m=1),),
    },
    'swsh11tg-TG13': {
        # Once during your turn, if this Pokémon is in the Active Spot, you may put 1 damage counter on each of your opponent's Pokémon.
        'Eerie Beam': (AbilityGate('active_only', ''), DamageCountersOnEachOpponentPokemon(count=1),),
    },
    'swsh12-147': {
        # Once during your turn, you may search your deck for up to 2 Special Energy cards and attach them to 1 of your Pokémon. Then, shuffle your deck.
        'Primal Turbo': (AttachEnergyGeneric(source='deck', count=2, special_only=True, single_target=True),),
    },
    'swsh12-16': {
        # Once during your turn, you may heal 20 damage from each of your Pokémon.
        'Elegant Heal': (HealAllOwnPokemon(amount=20),),
    },
    'swsh12-179': {
        # As often as you like during your turn, you may move a Fighting Energy from 1 of your other Pokémon to this Pokémon.
        'Irresistible Force': (MoveEnergyGeneric(owner='own', sources='any', dests='self', energy_type='Fighting'),),
    },
    'swsh12-69': {
        # You must discard a card from your hand in order to use this Ability. Once during your turn, you may draw 2 cards.
        'Refinement': (AbilityGate('hand_matches', 'any:1'), DiscardMatchingFromHand('any', 1), Draw(2),),
    },
    'swsh12-90': {
        # As often as you like during your turn, you may move a Fighting Energy from 1 of your other Pokémon to this Pokémon.
        'Irresistible Force': (MoveEnergyGeneric(owner='own', sources='any', dests='self', energy_type='Fighting'),),
    },
    'swsh12pt5-101': {
        # Once during your turn, you may discard your hand and draw 3 cards.
        'Azure Pulse': (DiscardHandThenDraw(3),),
    },
    'swsh12pt5-102': {
        # Once during your turn, you may discard your hand and draw 3 cards.
        'Azure Pulse': (DiscardHandThenDraw(3),),
    },
    'swsh12pt5-14': {
        # During your turn, you may switch 1 of your opponent's Benched Pokémon with their Active Pokémon. (You can't use more than 1 VSTAR Power in a game.)
        'Ivy Star': (ForceOpponentSwitchChosenBench(),),
    },
    'swsh12pt5-45': {
        # Once during your turn, you may draw 3 cards. If you use this Ability, your turn ends.
        'Instant Charge': (Draw(3), EndTurnAfterThisAbility(),),
    },
    'swsh12pt5-66': {
        # Once during your turn, you may move up to 2 damage counters from your Pokémon to your opponent's Active Pokémon.
        "Witch's Domain": (MoveDamageCounters(count=2, scope='own_to_opp_active', up_to=True),),
    },
    'swsh12pt5-69': {
        # Once during your turn, you may attach a Psychic Energy card from your discard pile to 1 of your Lunatone.
        'Sun Energy': (AttachEnergyGeneric(source='discard', count=1, basic_only=True, energy_type='Psychic', single_target=True, target_names=('Lunatone',)),),
    },
    'swsh12pt5-98': {
        # Once during your turn, you may discard your hand and draw 5 cards. If you use this Ability, your turn ends.
        'Regal Stance': (DiscardHandThenDraw(5), EndTurnAfterThisAbility(),),
    },
    'swsh12pt5gg-GG10': {
        # Once during your turn, if this Pokémon is in the Active Spot, you may look at the top 6 cards of your deck, reveal an Item card you find there, and pu
        'Mysterious Tail': (AbilityGate('active_only', ''), LookTopNTake(n=6, m=1, criterion='item', exact=False, rest='shuffle'),),
    },
    'swsh12pt5gg-GG15': {
        # Once during your turn, you may attach a Psychic Energy card from your discard pile to 1 of your Lunatone.
        'Sun Energy': (AttachEnergyGeneric(source='discard', count=1, basic_only=True, energy_type='Psychic', single_target=True, target_names=('Lunatone',)),),
    },
    'swsh12pt5gg-GG18': {
        # Once during your turn, you may look at the top 6 cards of your deck and attach any number of Metal Energy cards you find there to your Pokémon in any 
        'Giga Magnet': (AttachEnergyGeneric(source='deck', count=99, deck_limit=6, basic_only=True, energy_type='Metal', optional=True),),
    },
    'swsh12pt5gg-GG19': {
        # Once during your turn, you may search your deck for a Supporter card, reveal it, shuffle your deck, then put that card on top of it.
        'Tempting Tune': (SearchDeckPutOnTop('supporter'),),
    },
    'swsh12pt5gg-GG20': {
        # Once during your turn, you may attach a Psychic Energy card from your hand to 1 of your Latios.
        'Red Assist': (AttachEnergyGeneric(source='hand', count=1, basic_only=True, energy_type='Psychic', single_target=True, target_names=('Latios',)),),
    },
    'swsh12pt5gg-GG25': {
        # Once during your turn, you may draw cards until you have 5 cards in your hand.
        'Industrious Incisors': (DrawUpTo(5),),
    },
    'swsh12pt5gg-GG35': {
        # During your turn, you may switch 1 of your opponent's Benched Pokémon with their Active Pokémon. (You can't use more than 1 VSTAR Power in a game.)
        'Ivy Star': (ForceOpponentSwitchChosenBench(),),
    },
    'swsh12pt5gg-GG36': {
        # Once during your turn, if this Pokémon is in the Active Spot, you may draw a card.
        'Fleet-Footed': (AbilityGate('active_only', ''), Draw(1),),
    },
    'swsh12pt5gg-GG38': {
        # Once during your turn, if this Pokémon is in the Active Spot, you may draw a card.
        'Fleet-Footed': (AbilityGate('active_only', ''), Draw(1),),
    },
    'swsh12pt5gg-GG41': {
        # Once during your turn, if this Pokémon is in the Active Spot, you may draw a card.
        'Fleet-Footed': (AbilityGate('active_only', ''), Draw(1),),
    },
    'swsh12pt5gg-GG47': {
        # Once during your turn, you may move up to 2 damage counters from your Pokémon to your opponent's Active Pokémon.
        "Witch's Domain": (MoveDamageCounters(count=2, scope='own_to_opp_active', up_to=True),),
    },
    'swsh12pt5gg-GG48': {
        # Once during your turn, you may search your deck for a Psychic Energy card and attach it to 1 of your Pokémon. Then, shuffle your deck. If you use this
        'Roar of the Sword': (AttachEnergyGeneric(source='deck', count=1, basic_only=True, energy_type='Psychic', single_target=True), EndTurnAfterThisAbility(),),
    },
    'swsh12pt5gg-GG50': {
        # During your turn, you may put up to 2 Item cards from your discard pile into your hand. (You can't use more than 1 VSTAR Power in a game.)
        'Star Abyss': (SearchDiscardByCriterionToHand('item', count=2),),
    },
    'swsh12pt5gg-GG52': {
        # During your turn, you may put 4 damage counters on 1 of your opponent's Pokémon. (You can't use more than 1 VSTAR Power in a game.)
        'Moon Cleave Star': (DamageCounterOnChosenOpponentPokemon(count=4),),
    },
    'swsh12pt5gg-GG54': {
        # Once during your turn, you may discard your hand and draw 5 cards. If you use this Ability, your turn ends.
        'Regal Stance': (DiscardHandThenDraw(5), EndTurnAfterThisAbility(),),
    },
    'swsh12pt5gg-GG56': {
        # During your turn, you may discard your hand and draw 7 cards. (You can't use more than 1 VSTAR Power in a game.)
        'Phantom Star': (DiscardHandThenDraw(7),),
    },
    'swsh12pt5gg-GG67': {
        # During your turn, you may attach up to 3 Water Energy cards from your discard pile to your Water Pokémon in any way you like. (You can't use more than
        'Star Portal': (AttachEnergyGeneric(source='discard', count=3, basic_only=True, energy_type='Water', target_type='Water', optional=True),),
    },
    'swsh12pt5gg-GG70': {
        # During your turn, you may search your deck for up to 2 cards and put them into your hand. Then, shuffle your deck. (You can't use more than 1 VSTAR Po
        'Starbirth': (SearchDeckAnyCardToHand(count=2),),
    },
    'swsh12tg-TG03': {
        # Once during your turn (before your attack), you may attach a Lightning Energy card from your discard pile to 1 of your Benched Pokémon.
        'Dynamotor': (AttachEnergyGeneric(source='discard', energy_type='Lightning', bench_only=True),),
    },
    'swsh12tg-TG05': {
        # You must discard a card from your hand in order to use this Ability. Once during your turn, you may draw 2 cards.
        'Refinement': (AbilityGate('hand_matches', 'any:1'), DiscardMatchingFromHand('any', 1), Draw(2),),
    },
    'swsh12tg-TG12': {
        # Once during your turn, you may draw cards until you have 3 cards in your hand. If this Pokémon is in the Active Spot, you may draw cards until you hav
        'Exciting Stage': (AbilityGate('name_not_used', 'Exciting Stage'), MarkAbilityNameUsed('Exciting Stage'), DrawMoreIfSelfActive(base=3, extra=4, mode='until'),),
    },
    'swsh12tg-TG20': {
        # Once during your turn, you may discard your hand and draw 3 cards.
        'Azure Pulse': (DiscardHandThenDraw(3),),
    },
    'swsh12tg-TG29': {
        # Once during your turn, you may discard your hand and draw 3 cards.
        'Azure Pulse': (DiscardHandThenDraw(3),),
    },
    'swsh2-107': {
        # Once during your turn, you may attach a Fire Energy card, a Fighting Energy card, or 1 of each from your discard pile to your Pokémon in any way you l
        'Tar Generator': (AttachEnergyGeneric(source='discard', count=2, energy_types_any=('Fire', 'Fighting'), distinct_energy_types=True),),
    },
    'swsh2-118': {
        # Once during your turn, if a Stadium is in play, you may make your opponent's Active Pokémon Poisoned.
        'Poisonous Puddle': (AbilityGate('g:stadium_in_play', ''), InflictStatusOnDefender('poisoned'),),
    },
    'swsh2-126': {
        # You must discard 2 cards from your hand in order to use this Ability. Once during your turn, you may search your deck for a Galarian Perrserker, revea
        'Evolution Roar': (AbilityGate('hand_matches', 'any:2'), DiscardMatchingFromHand('any', 2), SearchDeckForNamedCardToHand('Galarian Perrserker'),),
    },
    'swsh2-152': {
        # Once during your turn, you may search your deck for a Pokémon Tool card, reveal it, and put it into your hand. Then, shuffle your deck.
        'Greedy Tail': (SearchDeckByCriterionToHand('pokemon_tool', count=1),),
    },
    'swsh2-204': {
        # As often as you like during your turn, you may attach a Water Energy card from your hand to 1 of your Benched Water Pokémon.
        'Ice Dance': (AttachEnergyGeneric(source='hand', count=1, basic_only=True, energy_type='Water', single_target=True, bench_only=True, target_type='Water'),),
    },
    'swsh2-22': {
        # Once during your turn, you may put 2 damage counters on 1 of your opponent's Pokémon. If you placed any damage counters in this way, shuffle this Poké
        'Apple Drop': (PickPokemonThen(side='opp', action='put_counters', amount=2, then=(ShuffleSelfIntoDeck(),)),),
    },
    'swsh2-23': {
        # Once during your turn, you may flip a coin. If heads, switch 1 of your opponent's Benched Basic Pokémon with their Active Pokémon.
        'Delicious Aroma': (FlipCoinThen(heads=(PickPokemonThen(side='opp', action='switch_opp_active', bench_only=True, basic_only=True),), tails=()),),
    },
    'swsh3-110': {
        # As often as you like during your turn, you may attach a Darkness Energy card from your hand to 1 of your Pokémon.
        'Dark Squall': (AttachEnergyGeneric(source='hand', energy_type='Darkness'),),
    },
    'swsh3-197': {
        # Once during your turn, you may search your deck for up to 2 Grass Energy cards and attach them to 1 of your Pokémon. Then, shuffle your deck.
        'Voltage Beat': (AttachEnergyGeneric(source='deck', count=2, basic_only=True, energy_type='Grass', single_target=True, optional=True),),
    },
    'swsh3-198': {
        # Once during your turn, you may attach a Fire Energy card, a Fighting Energy card, or 1 of each from your discard pile to your Pokémon in any way you l
        'Tar Generator': (AttachEnergyGeneric(source='discard', count=2, energy_types_any=('Fire', 'Fighting'), distinct_energy_types=True),),
    },
    'swsh3-39': {
        # Once during your turn, you may heal 20 damage from each of your Pokémon.
        'Bright Heal': (HealAllOwnPokemon(amount=20),),
    },
    'swsh3-47': {
        # Once during your turn, if this Pokémon is in the Active Spot, you may flip a coin. If heads, your opponent's Active Pokémon is now Paralyzed.
        'Bitter Cold': (AbilityGate('active_only', ''), FlipCoinThen(heads=(InflictStatusOnDefender('paralyzed'),), tails=()),),
    },
    'swsh3-99': {
        # Once during your turn, if this Pokémon is in the Active Spot, you may make your opponent's Active Pokémon Poisoned.
        'Rapid-Fire Poison': (AbilityGate('active_only', ''), InflictStatusOnDefender('poisoned'),),
    },
    'swsh4-131': {
        # Once during your turn, if this Pokémon is in the Active Spot, you may draw cards until you have 7 cards in your hand. If you use this Ability, your tu
        'Gormandize': (AbilityGate('active_only', ''), DrawUpTo(7), EndTurnAfterThisAbility(),),
    },
    'swsh4-186': {
        # Once during your turn, if this Pokémon is in the Active Spot, you may put 1 damage counter on each of your opponent's Pokémon.
        'Eerie Beam': (AbilityGate('active_only', ''), DamageCountersOnEachOpponentPokemon(count=1),),
    },
    'swsh4-199': {
        # Once during your turn, you may switch a card from your hand with the top card of your deck.
        'Primate Wisdom': (SwapHandCardWithDeckTop(),),
    },
    'swsh4-21': {
        # Once during your turn, if this Pokémon is in the Active Spot, you may put 1 damage counter on each of your opponent's Pokémon.
        'Eerie Beam': (AbilityGate('active_only', ''), DamageCountersOnEachOpponentPokemon(count=1),),
    },
    'swsh4-25': {
        # Once during your turn, you may look at the top 3 cards of your deck and put 1 of them into your hand. Discard the other cards.
        'Battle Sense': (LookTopNKeepMRestToDiscard(n=3, m=1),),
    },
    'swsh4-46': {
        # Once during your turn, if this Pokémon is on your Bench, you may search your deck for up to 2 Lightning Energy cards and attach them to your Lightning
        'Buzzap Generator': (AbilityGate('bench_only', ''), AttachEnergyGeneric(source='deck', count=2, basic_only=True, energy_type='Lightning', target_type='Lightning'), IfLastAttachSucceeded((KnockOutSelfEffect(),)),),
    },
    'swsh45-13': {
        # Once during your turn, you may search your deck for up to 2 Grass Energy cards and attach them to 1 of your Pokémon. Then, shuffle your deck.
        'Voltage Beat': (AttachEnergyGeneric(source='deck', count=2, basic_only=True, energy_type='Grass', single_target=True, optional=True),),
    },
    'swsh45-30': {
        # As often as you like during your turn, you may attach a Water Energy card from your hand to 1 of your Benched Water Pokémon.
        'Ice Dance': (AttachEnergyGeneric(source='hand', count=1, basic_only=True, energy_type='Water', single_target=True, bench_only=True, target_type='Water'),),
    },
    'swsh45-39': {
        # Once during your turn, you may heal 20 damage from your Active Pokémon.
        'Watch Over': (HealOwnActiveFixed(20),),
    },
    'swsh45sv-SV006': {
        # Once during your turn, you may search your deck for up to 2 Grass Energy cards and attach them to 1 of your Pokémon. Then, shuffle your deck.
        'Voltage Beat': (AttachEnergyGeneric(source='deck', count=2, basic_only=True, energy_type='Grass', single_target=True, optional=True),),
    },
    'swsh45sv-SV009': {
        # Once during your turn, you may look at the top 3 cards of your opponent's deck and put them back in any order.
        "Bug's Radar": (LookOpponentDeckTopReorder(3),),
    },
    'swsh45sv-SV013': {
        # Once during your turn, you may put 2 damage counters on 1 of your opponent's Pokémon. If you placed any damage counters in this way, shuffle this Poké
        'Apple Drop': (PickPokemonThen(side='opp', action='put_counters', amount=2, then=(ShuffleSelfIntoDeck(),)),),
    },
    'swsh45sv-SV014': {
        # Once during your turn, you may flip a coin. If heads, switch 1 of your opponent's Benched Basic Pokémon with their Active Pokémon.
        'Delicious Aroma': (FlipCoinThen(heads=(PickPokemonThen(side='opp', action='switch_opp_active', bench_only=True, basic_only=True),), tails=()),),
    },
    'swsh45sv-SV034': {
        # As often as you like during your turn, you may attach a Water Energy card from your hand to 1 of your Benched Water Pokémon.
        'Ice Dance': (AttachEnergyGeneric(source='hand', count=1, basic_only=True, energy_type='Water', single_target=True, bench_only=True, target_type='Water'),),
    },
    'swsh45sv-SV069': {
        # Once during your turn, you may attach a Fire Energy card, a Fighting Energy card, or 1 of each from your discard pile to your Pokémon in any way you l
        'Tar Generator': (AttachEnergyGeneric(source='discard', count=2, energy_types_any=('Fire', 'Fighting'), distinct_energy_types=True),),
    },
    'swsh45sv-SV086': {
        # You must discard 2 cards from your hand in order to use this Ability. Once during your turn, you may search your deck for a Galarian Perrserker, revea
        'Evolution Roar': (AbilityGate('hand_matches', 'any:2'), DiscardMatchingFromHand('any', 2), SearchDeckForNamedCardToHand('Galarian Perrserker'),),
    },
    'swsh45sv-SV094': {
        # You must discard a card from your hand in order to use this Ability. Once during your turn, you may draw 2 cards.
        'Make Do': (AbilityGate('hand_matches', 'any:1'), DiscardMatchingFromHand('any', 1), Draw(2),),
    },
    'swsh45sv-SV098': {
        # Once during your turn, you may switch a card from your hand with the top card of your deck.
        'Primate Wisdom': (SwapHandCardWithDeckTop(),),
    },
    'swsh45sv-SV100': {
        # Once during your turn, you may search your deck for a Pokémon Tool card, reveal it, and put it into your hand. Then, shuffle your deck.
        'Greedy Tail': (SearchDeckByCriterionToHand('pokemon_tool', count=1),),
    },
    'swsh45sv-SV114': {
        # Once during your turn, you may heal 20 damage from your Active Pokémon.
        'Watch Over': (HealOwnActiveFixed(20),),
    },
    'swsh5-102': {
        # As often as you like during your turn, you may move a Metal Energy from 1 of your Pokémon to another of your Pokémon.
        'Metal Transfer': (MoveEnergyGeneric(owner='own', sources='any', dests='any', energy_type='Metal', basic_only=False),),
    },
    'swsh5-142': {
        # Once during your turn, you may draw cards until you have 3 cards in your hand. If this Pokémon is in the Active Spot, you may draw cards until you hav
        'Exciting Stage': (AbilityGate('name_not_used', 'Exciting Stage'), MarkAbilityNameUsed('Exciting Stage'), DrawMoreIfSelfActive(base=3, extra=4, mode='until'),),
    },
    'swsh5-178': {
        # Once during your turn, you may search your deck for a Rapid Strike card, reveal it, and put it into your hand. Then, shuffle your deck. You can't use 
        'Rapid Strike Search': (AbilityGate('name_not_used', 'Rapid Strike Search'), MarkAbilityNameUsed('Rapid Strike Search'), SearchDeckByCriterionToHand('named:Rapid Strike', count=1),),
    },
    'swsh5-179': {
        # Once during your turn, you may search your deck for a Single Strike Energy card and attach it to 1 of your Single Strike Pokémon. Then, shuffle your d
        'Single Strike Roar': (AttachEnergyGeneric(source='deck', energy_name='Single Strike Energy', target_subtype='Single Strike', counters_on_target=2),),
    },
    'swsh5-37': {
        # Once during your turn, you may search your deck for a Rapid Strike card, reveal it, and put it into your hand. Then, shuffle your deck. You can't use 
        'Rapid Strike Search': (AbilityGate('name_not_used', 'Rapid Strike Search'), MarkAbilityNameUsed('Rapid Strike Search'), SearchDeckByCriterionToHand('named:Rapid Strike', count=1),),
    },
    'swsh5-6': {
        # Once during your turn, you may draw cards until you have 3 cards in your hand. If this Pokémon is in the Active Spot, you may draw cards until you hav
        'Exciting Stage': (AbilityGate('name_not_used', 'Exciting Stage'), MarkAbilityNameUsed('Exciting Stage'), DrawMoreIfSelfActive(base=3, extra=4, mode='until'),),
    },
    'swsh5-61': {
        # Once during your turn, you may move 1 damage counter from 1 of your Pokémon to 1 of your opponent's Pokémon.
        'Ear Moves': (MoveOneDamageCounterFromOwnToOpponent(),),
    },
    'swsh5-8': {
        # As often as you like during your turn, you may attach a Grass Energy card from your hand to 1 of your Pokémon that doesn't have a Rule Box (Pokémon V,
        'Spring Bloom': (AttachEnergyGeneric(source='hand', energy_type='Grass', exclude_subtype='ex,V,VSTAR,VMAX,GX,EX,TAG TEAM,MEGA'),),
    },
    'swsh5-96': {
        # Once during your turn, you may search your deck for a Single Strike Energy card and attach it to 1 of your Single Strike Pokémon. Then, shuffle your d
        'Single Strike Roar': (AttachEnergyGeneric(source='deck', energy_name='Single Strike Energy', target_subtype='Single Strike', counters_on_target=2),),
    },
    'swsh6-169': {
        # You must discard 2 cards from your hand in order to use this Ability. Once during your turn, you may draw a card.
        'Reconstitute': (AbilityGate('hand_matches', 'any:2'), DiscardMatchingFromHand('any', 2), Draw(1),),
    },
    'swsh6-170': {
        # You must discard 2 cards from your hand in order to use this Ability. Once during your turn, you may draw a card.
        'Reconstitute': (AbilityGate('hand_matches', 'any:2'), DiscardMatchingFromHand('any', 2), Draw(1),),
    },
    'swsh6-176': {
        # Once during your turn, you may attach a Darkness Energy card from your discard pile to this Pokémon. You can't use more than 1 Direflame Wings Ability
        'Direflame Wings': (AbilityGate('name_not_used', 'Direflame Wings'), MarkAbilityNameUsed('Direflame Wings'), AttachEnergyFromDiscardToSelf(energy_type='Darkness', count=1),),
    },
    'swsh6-177': {
        # Once during your turn, you may attach a Darkness Energy card from your discard pile to this Pokémon. You can't use more than 1 Direflame Wings Ability
        'Direflame Wings': (AbilityGate('name_not_used', 'Direflame Wings'), MarkAbilityNameUsed('Direflame Wings'), AttachEnergyFromDiscardToSelf(energy_type='Darkness', count=1),),
    },
    'swsh6-199': {
        # Once during your turn, you may heal 20 damage from each of your Grass Pokémon.
        'Curative Forest': (HealAllOwnPokemonOfType(pokemon_type='Grass', amount=20),),
    },
    'swsh6-204': {
        # Once during your turn, you may attach a Psychic Energy card from your hand to 1 of your Benched Psychic Pokémon. If you attached Energy to a Pokémon i
        'Underworld Door': (AttachEnergyGeneric(source='hand', count=1, basic_only=True, energy_type='Psychic', bench_only=True, single_target=True, target_type='Psychic'), IfLastAttachSucceeded((Draw(2),)),),
    },
    'swsh6-205': {
        # Once during your turn, you may attach a Psychic Energy card from your hand to 1 of your Benched Psychic Pokémon. If you attached Energy to a Pokémon i
        'Underworld Door': (AttachEnergyGeneric(source='hand', count=1, basic_only=True, energy_type='Psychic', bench_only=True, single_target=True, target_type='Psychic'), IfLastAttachSucceeded((Draw(2),)),),
    },
    'swsh6-222': {
        # Once during your turn, if this Pokémon is on your Bench, you may search your deck for up to 2 Lightning Energy cards and attach them to your Lightning
        'Buzzap Generator': (AbilityGate('bench_only', ''), AttachEnergyGeneric(source='deck', count=2, basic_only=True, energy_type='Lightning', target_type='Lightning'), IfLastAttachSucceeded((KnockOutSelfEffect(),)),),
    },
    'swsh6-223': {
        # As often as you like during your turn, you may move a Metal Energy from 1 of your Pokémon to another of your Pokémon.
        'Metal Transfer': (MoveEnergyGeneric(owner='own', sources='any', dests='any', energy_type='Metal', basic_only=False),),
    },
    'swsh6-224': {
        # Once during your turn, if this Pokémon is in the Active Spot, you may draw cards until you have 7 cards in your hand. If you use this Ability, your tu
        'Gormandize': (AbilityGate('active_only', ''), DrawUpTo(7), EndTurnAfterThisAbility(),),
    },
    'swsh6-58': {
        # You must discard 2 cards from your hand in order to use this Ability. Once during your turn, you may draw a card.
        'Reconstitute': (AbilityGate('hand_matches', 'any:2'), DiscardMatchingFromHand('any', 2), Draw(1),),
    },
    'swsh6-75': {
        # Once during your turn, you may attach a Psychic Energy card from your hand to 1 of your Benched Psychic Pokémon. If you attached Energy to a Pokémon i
        'Underworld Door': (AttachEnergyGeneric(source='hand', count=1, basic_only=True, energy_type='Psychic', bench_only=True, single_target=True, target_type='Psychic'), IfLastAttachSucceeded((Draw(2),)),),
    },
    'swsh6-8': {
        # Once during your turn, you may heal 20 damage from each of your Grass Pokémon.
        'Curative Forest': (HealAllOwnPokemonOfType(pokemon_type='Grass', amount=20),),
    },
    'swsh7-106': {
        # Once during your turn, you may search your deck for a Supporter card, reveal it, shuffle your deck, then put that card on top of it.
        'Tempting Tune': (SearchDeckPutOnTop('supporter'),),
    },
    'swsh7-109': {
        # Once during your turn, you may have your opponent switch their Active Pokémon with 1 of their Benched Pokémon.
        'Intimidating Roar': (ForceOpponentSwitchOpponentChooses(),),
    },
    'swsh7-111': {
        # Once during your turn, you may discard your hand and draw 3 cards.
        'Azure Pulse': (DiscardHandThenDraw(3),),
    },
    'swsh7-16': {
        # Once during your turn, you may search your deck for up to 2 basic Energy cards, reveal them, and put them into your hand. Then, shuffle your deck.
        'Cotton Lift': (SearchDeckForBasicEnergyToHand(count=2),),
    },
    'swsh7-166': {
        # Once during your turn, you may search your deck for a Grass Energy card and attach it to 1 of your Pokémon. Then, shuffle your deck. If you use this A
        'Greening Cells': (AttachEnergyGeneric(source='deck', count=1, basic_only=True, energy_type='Grass', single_target=True), EndTurnAfterThisAbility(),),
    },
    'swsh7-167': {
        # Once during your turn, you may search your deck for a Grass Energy card and attach it to 1 of your Pokémon. Then, shuffle your deck. If you use this A
        'Greening Cells': (AttachEnergyGeneric(source='deck', count=1, basic_only=True, energy_type='Grass', single_target=True), EndTurnAfterThisAbility(),),
    },
    'swsh7-173': {
        # Once during your turn, if this Pokémon is in the Active Spot, you may draw a card.
        'Fleet-Footed': (AbilityGate('active_only', ''), Draw(1),),
    },
    'swsh7-183': {
        # Once during your turn, you may search your deck for an Item card, reveal it, and put it into your hand. Then, shuffle your deck. If you use this Abili
        'Dream Gift': (SearchDeckMultiCriteria(('item',)), EndTurnAfterThisAbility(),),
    },
    'swsh7-184': {
        # Once during your turn, you may search your deck for an Item card, reveal it, and put it into your hand. Then, shuffle your deck. If you use this Abili
        'Dream Gift': (SearchDeckMultiCriteria(('item',)), EndTurnAfterThisAbility(),),
    },
    'swsh7-217': {
        # Once during your turn, you may discard your hand and draw 3 cards.
        'Azure Pulse': (DiscardHandThenDraw(3),),
    },
    'swsh7-218': {
        # Once during your turn, you may discard your hand and draw 3 cards.
        'Azure Pulse': (DiscardHandThenDraw(3),),
    },
    'swsh7-227': {
        # Once during your turn, you may put 2 damage counters on 1 of your opponent's Pokémon.
        'Quick Shooting': (DamageCounterOnChosenOpponentPokemon(count=2),),
    },
    'swsh7-31': {
        # Once during your turn, if this Pokémon is in the Active Spot, you may draw a card.
        'Fleet-Footed': (AbilityGate('active_only', ''), Draw(1),),
    },
    'swsh7-55': {
        # Once during your turn (before your attack), you may attach a Lightning Energy card from your discard pile to 1 of your Benched Pokémon.
        'Dynamotor': (AttachEnergyGeneric(source='discard', energy_type='Lightning', bench_only=True),),
    },
    'swsh7-7': {
        # Once during your turn, you may search your deck for a Grass Energy card and attach it to 1 of your Pokémon. Then, shuffle your deck. If you use this A
        'Greening Cells': (AttachEnergyGeneric(source='deck', count=1, basic_only=True, energy_type='Grass', single_target=True), EndTurnAfterThisAbility(),),
    },
    'swsh7-74': {
        # Once during your turn, you may search your deck for an Item card, reveal it, and put it into your hand. Then, shuffle your deck. If you use this Abili
        'Dream Gift': (SearchDeckMultiCriteria(('item',)), EndTurnAfterThisAbility(),),
    },
    'swsh8-193': {
        # Once during your turn, you may attach a Psychic Energy card from your hand to 1 of your Latios.
        'Red Assist': (AttachEnergyGeneric(source='hand', count=1, basic_only=True, energy_type='Psychic', single_target=True, target_names=('Latios',)),),
    },
    'swsh8-194': {
        # Once during your turn, you may attach a Psychic Energy card from your hand to 1 of your Latias.
        'Blue Assist': (AttachEnergyGeneric(source='hand', count=1, basic_only=True, energy_type='Psychic', single_target=True, target_names=('Latias',)),),
    },
    'swsh8-254': {
        # Once during your turn, you may draw cards until you have as many cards in your hand as you have Fusion Strike Pokémon in play.
        'Fusion Strike System': (DrawUntilHandEqualsCount('own_subtype_in_play', 'Fusion Strike'),),
    },
    'swsh8-255': {
        # Once during your turn, you may draw cards until you have as many cards in your hand as you have Fusion Strike Pokémon in play.
        'Fusion Strike System': (DrawUntilHandEqualsCount('own_subtype_in_play', 'Fusion Strike'),),
    },
    'swsh8-266': {
        # You must discard a Water Energy card from your hand in order to use this Ability. Once during your turn, you may choose 2 of your opponent's Benched P
        'Double Gunner': (AbilityGate('hand_matches', 'energy_type:Water:1'), DiscardMatchingFromHand('energy_type:Water', 1), DistributeDamageCountersFreely(count=4, bench_only=True, max_per_target=2, exactly=True, target_count=2),),
    },
    'swsh8-280': {
        # Once during your turn (before your attack), you may attach a Lightning Energy card from your discard pile to 1 of your Benched Pokémon.
        'Dynamotor': (AttachEnergyGeneric(source='discard', energy_type='Lightning', bench_only=True),),
    },
    'swsh8-64': {
        # Once during your turn, you may attach a Water Energy card or a Fighting Energy card from your hand to 1 of your Pokémon.
        'Muddy Maker': (AttachEnergyGeneric(source='hand', energy_name='Water Energy card or a Fighting Energy'),),
    },
    'swsh8-79': {
        # You must discard a Water Energy card from your hand in order to use this Ability. Once during your turn, you may choose 2 of your opponent's Benched P
        'Double Gunner': (AbilityGate('hand_matches', 'energy_type:Water:1'), DiscardMatchingFromHand('energy_type:Water', 1), DistributeDamageCountersFreely(count=4, bench_only=True, max_per_target=2, exactly=True, target_count=2),),
    },
    'swsh9-105': {
        # Once during your turn, you may discard your hand and draw 5 cards. If you use this Ability, your turn ends.
        'Regal Stance': (DiscardHandThenDraw(5), EndTurnAfterThisAbility(),),
    },
    'swsh9-163': {
        # Once during your turn, you may discard your hand and draw 5 cards. If you use this Ability, your turn ends.
        'Regal Stance': (DiscardHandThenDraw(5), EndTurnAfterThisAbility(),),
    },
    'swsh9-176': {
        # During your turn, you may search your deck for up to 2 cards and put them into your hand. Then, shuffle your deck. (You can't use more than 1 VSTAR Po
        'Starbirth': (SearchDeckAnyCardToHand(count=2),),
    },
    'swsh9-181': {
        # You must discard 2 cards from your hand in order to use this Ability. Once during your turn, you may draw a card.
        'Reconstitute': (AbilityGate('hand_matches', 'any:2'), DiscardMatchingFromHand('any', 2), Draw(1),),
    },
    'swsh9-183': {
        # Once during your turn, you may attach a Darkness Energy card from your discard pile to this Pokémon. You can't use more than 1 Direflame Wings Ability
        'Direflame Wings': (AbilityGate('name_not_used', 'Direflame Wings'), MarkAbilityNameUsed('Direflame Wings'), AttachEnergyFromDiscardToSelf(energy_type='Darkness', count=1),),
    },
    'swsh9-184': {
        # During your turn, you may search your deck for up to 2 cards and put them into your hand. Then, shuffle your deck. (You can't use more than 1 VSTAR Po
        'Starbirth': (SearchDeckAnyCardToHand(count=2),),
    },
    'swsh9-22': {
        # Once during your turn, if this Pokémon is in the Active Spot, you may draw a card.
        'Fleet-Footed': (AbilityGate('active_only', ''), Draw(1),),
    },
    'swsh9-7': {
        # Once during your turn, you may search your deck for a Grass Pokémon, reveal it, and put it into your hand. Then, shuffle your deck.
        'Sun-Drenched Shell': (SearchDeckForPokemonToHand(count=1, pokemon_type='Grass'),),
    },
    'swsh9-79': {
        # Once during your turn, you may put 2 damage counters on this Pokémon. If you do, search your deck for a Fighting Energy card and attach it to this Pok
        'Roaring Resolve': (SelfDamage(20), SearchDeckAndAttachEnergy('Fighting', count=1, self_only=True),),
    },
    'swsh9-91': {
        # You must discard a card from your hand in order to use this Ability. Once during your turn, you may draw 2 cards.
        'Trade': (AbilityGate('hand_matches', 'any:1'), DiscardMatchingFromHand('any', 1), Draw(2),),
    },
    'swsh9tg-TG03': {
        # Once during your turn, you may search your deck for a Rapid Strike card, reveal it, and put it into your hand. Then, shuffle your deck. You can't use 
        'Rapid Strike Search': (AbilityGate('name_not_used', 'Rapid Strike Search'), MarkAbilityNameUsed('Rapid Strike Search'), SearchDeckByCriterionToHand('named:Rapid Strike', count=1),),
    },
    'swsh9tg-TG10': {
        # Once during your turn, you may search your deck for a Single Strike Energy card and attach it to 1 of your Single Strike Pokémon. Then, shuffle your d
        'Single Strike Roar': (AttachEnergyGeneric(source='deck', energy_name='Single Strike Energy', target_subtype='Single Strike', counters_on_target=2),),
    },
    'swsh9tg-TG12': {
        # Once during your turn, you may switch a card from your hand with the top card of your deck.
        'Primate Wisdom': (SwapHandCardWithDeckTop(),),
    },
    'swsh9tg-TG14': {
        # Once during your turn, you may search your deck for an Item card, reveal it, and put it into your hand. Then, shuffle your deck. If you use this Abili
        'Dream Gift': (SearchDeckMultiCriteria(('item',)), EndTurnAfterThisAbility(),),
    },
    'swshp-SWSH006': {
        # Once during your turn, you may search your deck for up to 2 Grass Energy cards and attach them to 1 of your Pokémon. Then, shuffle your deck.
        'Voltage Beat': (AttachEnergyGeneric(source='deck', count=2, basic_only=True, energy_type='Grass', single_target=True, optional=True),),
    },
    'swshp-SWSH007': {
        # As often as you like during your turn, you may attach a Water Energy card from your hand to 1 of your Benched Water Pokémon.
        'Ice Dance': (AttachEnergyGeneric(source='hand', count=1, basic_only=True, energy_type='Water', single_target=True, bench_only=True, target_type='Water'),),
    },
    'swshp-SWSH009': {
        # You must discard a card from your hand in order to use this Ability. Once during your turn, you may draw 2 cards.
        'Make Do': (AbilityGate('hand_matches', 'any:1'), DiscardMatchingFromHand('any', 1), Draw(2),),
    },
    'swshp-SWSH022': {
        # Once during your turn, you may put 2 damage counters on 1 of your opponent's Pokémon. If you placed any damage counters in this way, shuffle this Poké
        'Apple Drop': (PickPokemonThen(side='opp', action='put_counters', amount=2, then=(ShuffleSelfIntoDeck(),)),),
    },
    'swshp-SWSH024': {
        # Once during your turn, you may attach a Fire Energy card, a Fighting Energy card, or 1 of each from your discard pile to your Pokémon in any way you l
        'Tar Generator': (AttachEnergyGeneric(source='discard', count=2, energy_types_any=('Fire', 'Fighting'), distinct_energy_types=True),),
    },
    'swshp-SWSH025': {
        # Once during your turn, if a Stadium is in play, you may make your opponent's Active Pokémon Poisoned.
        'Poisonous Puddle': (AbilityGate('g:stadium_in_play', ''), InflictStatusOnDefender('poisoned'),),
    },
    'swshp-SWSH037': {
        # As often as you like during your turn, you may attach a Darkness Energy card from your hand to 1 of your Pokémon.
        'Dark Squall': (AttachEnergyGeneric(source='hand', energy_type='Darkness'),),
    },
    'swshp-SWSH052': {
        # As often as you like during your turn, you may move 1 damage counter from 1 of your Psychic Pokémon to another of your Psychic Pokémon.
        'Life Shaker': (MoveDamageCounters(count=1, scope='own', pokemon_type='Psychic'),),
    },
    'swshp-SWSH054': {
        # Once during your turn, you may attach a Fire Energy card, a Fighting Energy card, or 1 of each from your discard pile to your Pokémon in any way you l
        'Tar Generator': (AttachEnergyGeneric(source='discard', count=2, energy_types_any=('Fire', 'Fighting'), distinct_energy_types=True),),
    },
    'swshp-SWSH066': {
        # Once during your turn, you may look at the top 3 cards of your deck and put 1 of them into your hand. Discard the other cards.
        'Battle Sense': (LookTopNKeepMRestToDiscard(n=3, m=1),),
    },
    'swshp-SWSH068': {
        # Once during your turn, if this Pokémon is in the Active Spot, you may draw cards until you have 7 cards in your hand. If you use this Ability, your tu
        'Gormandize': (AbilityGate('active_only', ''), DrawUpTo(7), EndTurnAfterThisAbility(),),
    },
    'swshp-SWSH088': {
        # As often as you like during your turn, you may attach a Grass Energy card from your hand to 1 of your Pokémon that doesn't have a Rule Box (Pokémon V,
        'Spring Bloom': (AttachEnergyGeneric(source='hand', energy_type='Grass', exclude_subtype='ex,V,VSTAR,VMAX,GX,EX,TAG TEAM,MEGA'),),
    },
    'swshp-SWSH089': {
        # Once during your turn, you may search your deck for a Rapid Strike card, reveal it, and put it into your hand. Then, shuffle your deck. You can't use 
        'Rapid Strike Search': (AbilityGate('name_not_used', 'Rapid Strike Search'), MarkAbilityNameUsed('Rapid Strike Search'), SearchDeckByCriterionToHand('named:Rapid Strike', count=1),),
    },
    'swshp-SWSH090': {
        # Once during your turn, you may search your deck for a Single Strike Energy card and attach it to 1 of your Single Strike Pokémon. Then, shuffle your d
        'Single Strike Roar': (AttachEnergyGeneric(source='deck', energy_name='Single Strike Energy', target_subtype='Single Strike', counters_on_target=2),),
    },
    'swshp-SWSH091': {
        # As often as you like during your turn, you may move a Metal Energy from 1 of your Pokémon to another of your Pokémon.
        'Metal Transfer': (MoveEnergyGeneric(owner='own', sources='any', dests='any', energy_type='Metal', basic_only=False),),
    },
    'swshp-SWSH113': {
        # Once during your turn, you may put 2 damage counters on 1 of your opponent's Pokémon.
        'Quick Shooting': (DamageCounterOnChosenOpponentPokemon(count=2),),
    },
    'swshp-SWSH122': {
        # Once during your turn (before your attack), you may attach a Lightning Energy card from your discard pile to 1 of your Benched Pokémon.
        'Dynamotor': (AttachEnergyGeneric(source='discard', energy_type='Lightning', bench_only=True),),
    },
    'swshp-SWSH155': {
        # Once during your turn, you may have your opponent reveal their hand.
        'Feel the Way': (RevealOpponentHand(),),
    },
    'swshp-SWSH156': {
        # Once during your turn, you may have your opponent reveal their hand.
        'Feel the Way': (RevealOpponentHand(),),
    },
    'swshp-SWSH157': {
        # Once during your turn, you may have your opponent reveal their hand.
        'Feel the Way': (RevealOpponentHand(),),
    },
    'swshp-SWSH158': {
        # Once during your turn, you may have your opponent reveal their hand.
        'Feel the Way': (RevealOpponentHand(),),
    },
    'swshp-SWSH171': {
        # Once during your turn, you may attach a Psychic Energy card from your hand to 1 of your Latios.
        'Red Assist': (AttachEnergyGeneric(source='hand', count=1, basic_only=True, energy_type='Psychic', single_target=True, target_names=('Latios',)),),
    },
    'swshp-SWSH186': {
        # Once during your turn, you may put 2 damage counters on this Pokémon. If you do, search your deck for a Fighting Energy card and attach it to this Pok
        'Roaring Resolve': (SelfDamage(20), SearchDeckAndAttachEnergy('Fighting', count=1, self_only=True),),
    },
    'swshp-SWSH187': {
        # You must discard a card from your hand in order to use this Ability. Once during your turn, you may draw 2 cards.
        'Trade': (AbilityGate('hand_matches', 'any:1'), DiscardMatchingFromHand('any', 1), Draw(2),),
    },
    'swshp-SWSH188': {
        # Once during your turn, you may draw cards until you have 5 cards in your hand.
        'Industrious Incisors': (DrawUpTo(5),),
    },
    'swshp-SWSH195': {
        # During your turn, you may switch 1 of your opponent's Benched Pokémon with their Active Pokémon. (You can't use more than 1 VSTAR Power in a game.)
        'Ivy Star': (ForceOpponentSwitchChosenBench(),),
    },
    'swshp-SWSH202': {
        # Once during your turn, you may search your deck for an Item card, reveal it, and put it into your hand. Then, shuffle your deck. If you use this Abili
        'Dream Gift': (SearchDeckMultiCriteria(('item',)), EndTurnAfterThisAbility(),),
    },
    'swshp-SWSH206': {
        # Once during your turn, you may draw a card.
        'Hurried Gait': (Draw(1),),
    },
    'swshp-SWSH207': {
        # You must discard a card from your hand in order to use this Ability. Once during your turn, you may draw 3 cards.
        'Wily Stance': (AbilityGate('hand_matches', 'any:1'), DiscardMatchingFromHand('any', 1), Draw(3),),
    },
    'swshp-SWSH208': {
        # Once during your turn, you may look at the top 6 cards of your deck and attach any number of Metal Energy cards you find there to your Pokémon in any 
        'Giga Magnet': (AttachEnergyGeneric(source='deck', count=99, deck_limit=6, basic_only=True, energy_type='Metal', optional=True),),
    },
    'swshp-SWSH254': {
        # During your turn, you may attach up to 3 Water Energy cards from your discard pile to your Water Pokémon in any way you like. (You can't use more than
        'Star Portal': (AttachEnergyGeneric(source='discard', count=3, basic_only=True, energy_type='Water', target_type='Water', optional=True),),
    },
    'swshp-SWSH271': {
        # You must discard a card from your hand in order to use this Ability. Once during your turn, you may draw 2 cards.
        'Refinement': (AbilityGate('hand_matches', 'any:1'), DiscardMatchingFromHand('any', 1), Draw(2),),
    },
    'swshp-SWSH272': {
        # Once during your turn, you may search your deck for up to 2 Special Energy cards and attach them to 1 of your Pokémon. Then, shuffle your deck.
        'Primal Turbo': (AttachEnergyGeneric(source='deck', count=2, special_only=True, single_target=True),),
    },
    'swshp-SWSH279': {
        # Once during your turn, you may put 2 damage counters on 1 of your opponent's Pokémon.
        'Quick Shooting': (DamageCounterOnChosenOpponentPokemon(count=2),),
    },
    'swshp-SWSH298': {
        # During your turn, you may discard your hand and draw 7 cards. (You can't use more than 1 VSTAR Power in a game.)
        'Phantom Star': (DiscardHandThenDraw(7),),
    },
    'swshp-SWSH307': {
        # During your turn, you may search your deck for up to 2 cards and put them into your hand. Then, shuffle your deck. (You can't use more than 1 VSTAR Po
        'Starbirth': (SearchDeckAnyCardToHand(count=2),),
    },
    'xy1-103': {
        # Once during your turn (before your attack), you may have your opponent switch his or her Active Pokémon with 1 of his or her Benched Pokémon.
        'Drive Off': (ForceOpponentSwitchOpponentChooses(),),
    },
    'xy1-26': {
        # Once during your turn (before your attack), you may draw cards until you have 6 cards in your hand.
        'Mystical Fire': (DrawUpTo(6),),
    },
    'xy1-74': {
        # Once during your turn, (before your attack), if this Pokémon is Confused, you may search your deck for a card that evolves from this Pokémon and put i
        'Upside-Down Evolution': (AbilityGate('self_status', 'confused'), InstantEvolveSelfFromDeck(),),
    },
    'xy10-120': {
        # Once during your turn (before your attack), you may put a Pokémon Tool card attached to this Pokémon into your hand.
        'Drive Change': (ReturnOwnToolToHand(),),
    },
    'xy10-14': {
        # Once during your turn (before your attack), you may search your deck for a Fire Energy card and attach it to 1 of your Pokémon. Shuffle your deck afte
        'Flare Witch': (SearchDeckAndAttachEnergy('Fire', count=1, self_only=False),),
    },
    'xy10-18': {
        # Once during your turn (before your attack), you may search your deck for a Restored Pokémon and put it onto your Bench. Shuffle your deck afterward.
        'Restoring Beam': (SearchDeckPokemonToBench(subtype='Restored', count=1),),
    },
    'xy10-19': {
        # Once during your turn (before your attack), you may switch 1 of your opponent's Benched Pokémon-EX with his or her Active Pokémon.
        'Dangerous Tentacle': (PickPokemonThen(side='opp', action='switch_opp_active', bench_only=True, subtype='EX'),),
    },
    'xy10-4': {
        # As often as you like during your turn (before your attack), you may move 1 damage counter from 1 of your Wormadam to another of your Pokémon.
        'Wormadam First': (PickPokemonThen(side='own', action='take_counters', amount=1, damaged_only=True, name_exact='Wormadam', then=(PickPokemonThen(side='own', action='give_counters', exclude_picked=True),)),),
    },
    'xy11-107': {
        # Once during your turn (before your attack), you may discard a Fire Energy card from your hand. If you do, during this turn, your Basic Fire Pokémon's 
        'Steam Up': (AbilityGate('hand_has_basic_energy', 'Fire'), DiscardFromHandBasicEnergyAsCost('Fire', then=(GrantTypeAttackBonusThisTurn('Fire', 30),)),),
    },
    'xy11-115': {
        # Once during your turn (before your attack), you may discard a Fire Energy card from your hand. If you do, during this turn, your Basic Fire Pokémon's 
        'Steam Up': (AbilityGate('hand_has_basic_energy', 'Fire'), DiscardFromHandBasicEnergyAsCost('Fire', then=(GrantTypeAttackBonusThisTurn('Fire', 30),)),),
    },
    'xy11-26': {
        # Once during your turn (before your attack), you may discard a Fire Energy card from your hand. If you do, during this turn, your Basic Fire Pokémon's 
        'Steam Up': (AbilityGate('hand_has_basic_energy', 'Fire'), DiscardFromHandBasicEnergyAsCost('Fire', then=(GrantTypeAttackBonusThisTurn('Fire', 30),)),),
    },
    'xy11-34': {
        # Once during your turn (before your attack), you may attach a Special Energy card from your hand to 1 of your Mega Evolution Pokémon.
        'Mega Boost': (AttachEnergyGeneric(source='hand', special_only=True, target_subtype='MEGA'),),
    },
    'xy11-40': {
        # Once during your turn (before your attack), you may put 3 damage counters on 1 of your opponent's Pokémon-EX.
        'Shocking Light': (PickPokemonThen(side='opp', action='put_counters', amount=3, subtype='EX'),),
    },
    'xy11-50': {
        # Once during your turn (before your attack), you may look at the top 2 cards of your deck and put 1 of them into your hand. Discard the other card.
        'Sinister Selection': (LookTopNKeepMRestToDiscard(2, 1),),
    },
    'xy11-61': {
        # As often as you like during your turn (before your attack), you may put a Pokémon Tool card attached to 1 of your Pokémon into your hand.
        'Tear Away': (PickPokemonThen(action='tool_to_hand', has_tool=True),),
    },
    'xy12-31': {
        # Once during your turn (before your attack), you may discard a card from your hand. If you do, put 2 basic Energy cards from your discard pile into you
        'Space Beacon': (DiscardHandCostThenRetrieveEnergyExcludingDiscarded(1, 2),),
    },
    'xy2-23': {
        # Once during your turn (before your attack) you may Knock Out this Pokémon. If you do, attach 3 basic Energy from your discard pile to 1 of your Pokémo
        'Energy Grace': (AttachEnergyGeneric(source='discard', count=3, basic_only=True, single_target=True, exclude_subtype='EX'), KnockOutSelfEffect(),),
    },
    'xy2-40': {
        # As often as you like during your turn (before your attack), you may move 1 damage counter from 1 of your Pokémon to this Pokémon.
        'Shadow Void': (MoveDamageCountersFreely(src='own', dest='self', count=1),),
    },
    'xy2-7': {
        # Once during your turn (before your attack), you may discard a Grass Energy card from your hand. If you do, draw 3 cards.
        'Leaf Draw': (DiscardOwnHandBasicEnergyOfChoiceThenDraw(draw_count=3, energy_type='Grass'),),
    },
    'xy2-74': {
        # As often as you like during your turn (before your attack), you may discard an Energy attached to this Pokémon. If you do, heal 60 damage from this Po
        'Gooey Regeneration': (AbilityGate('self_has_energy', 'any'), DiscardOwnEnergy(count=1), HealSelf(60),),
    },
    'xy2-85': {
        # Once during your turn (before your attack), you may return this Pokémon and all cards attached to it to your hand.
        'Big Jump': (ReturnSelfToHandUnconditional(),),
    },
    'xy3-3': {
        # Once during your turn (before your attack), you may discard a Grass Energy attached to this Pokémon. If you do, your opponent's Active Pokémon is now 
        'Wafting Scent': (AbilityGate('self_has_energy', 'Grass'), DiscardOwnEnergy(count=1, energy_type='Grass'), InflictStatusOnDefender('confused'), InflictStatusOnDefender('poisoned'),),
    },
    'xy3-37': {
        # Once during your turn (before your attack), if this Pokémon is on your Bench, you may heal 10 damage from your Active Pokémon.
        'Victory Kiss': (AbilityGate('bench_only', ''), HealOwnActiveFixed(10),),
    },
    'xy3-41': {
        # Once during your turn (before your attack), you may discard any Stadium card in play. If you do, put a Stadium card with a different name from your di
        'Teleport Room': (TeleportRoomEffect(),),
    },
    'xy4-12': {
        # Once during your turn (before your attack), you may discard a Fire Energy attached to this Pokémon. If you do, switch 1 of your opponent's Benched Pok
        'Flare Command': (AbilityGate('self_has_energy', 'Fire'), DiscardOwnEnergy(count=1, energy_type='Fire'), PickPokemonThen(side='opp', action='switch_opp_active', bench_only=True),),
    },
    'xy4-69': {
        # Once during your turn (before your attack), you may draw a card. If this Pokémon is your Active Pokémon, draw 1 more card.
        'Tasting': (DrawBonusIfActive(1, 1),),
    },
    'xy4-74': {
        # Once during your turn (before your attack), you may attach a Darkness Energy card from your discard pile to your Active Pokémon.
        'Dark Impulse': (AttachDiscardCardsToSelf(energy_types=('Darkness',), count=1, to_active=True),),
    },
    'xy5-110': {
        # Once during your turn (before your attack), you may choose either player. That player shuffles his or her hand into his or her deck and draws 4 cards.
        'Sand Flap': (ChooseOneEffectBranch(labels=('自分が手札を山札に戻して4枚引く', '相手が手札を山札に戻して4枚引く'), branches=((ShuffleHandIntoDeckThenDraw(4),), (OpponentShuffleHandThenDrawFixed(4),))),),
    },
    'xy5-12': {
        # Once during your turn (before your attack), you may flip a coin. If heads, switch 1 of your opponent's Benched Pokémon with his or her Active Pokémon.
        'Captivating Rhythm': (FlipCoinThen(heads=(PickPokemonThen(side='opp', action='switch_opp_active', bench_only=True),), tails=()),),
    },
    'xy5-36': {
        # Once during your turn (before your attack), you may search your deck for a card. Shuffle your deck, then put that card on top of it.
        'Diving Search': (SearchDeckToTopOfDeck(count=1),),
    },
    'xy5-65': {
        # As often as you like during your turn (before your attack), you may move a basic Energy attached to 1 of your Benched Pokémon to your Active Pokémon.
        'Energy Connect': (MoveChosenBenchEnergyToActive(max_count=1, exact=True, basic_only=True),),
    },
    'xy5-8': {
        # Once during your turn (before your attack), you may attach a Grass Energy card from your hand to 1 of your Pokémon. If you do, heal 30 damage from tha
        'Nurture and Heal': (AttachEnergyFromHandToChosenOwnPokemon('Grass', heal_on_attach=30),),
    },
    'xy6-10': {
        # Once during your turn (before your attack), if this Pokémon is your Active Pokémon, you may discard a card from your hand. If you do, discard the top 
        'Wing Buzz': (AbilityGate('active_only', ''), AbilityGate('hand_not_empty', ''), DiscardHandCardAsCost(then=(DiscardTopOfOpponentDeck(1),)),),
    },
    'xy6-63': {
        # Once during your turn (before your attack), if this Pokémon is your Active Pokémon, you may attach a Fire Energy card from your hand to 1 of your Drag
        'Turboblaze': (AbilityGate('active_only', ''), AttachEnergyFromHandToChosenOwnPokemon('Fire', target_type='Dragon'),),
    },
    'xy7-49': {
        # Once during your turn (before your attack), you may switch your Active Pokémon with 1 of your Benched Pokémon. If you do, your opponent switches his o
        'Magnetic Warp': (PickPokemonThen(action='switch_own_active', bench_only=True, then=(ForceOpponentSwitchOpponentChooses(),)),),
    },
    'xy7-54': {
        # Once during your turn (before your attack), you may heal 20 damage from each of your Pokémon.
        'Bright Heal': (HealAllOwnPokemon(amount=20),),
    },
    'xy7-6': {
        # Once during your turn (before your attack), you may use this Ability. Both Active Pokémon (except for Grass Pokémon) are now Poisoned.
        'Poisonous Nest': (PoisonBothActiveExceptType('Grass'),),
    },
    'xy8-104': {
        # Once during your turn (before your attack), you may heal 30 damage and remove a Special Condition from your Active Pokémon.
        'Floral Breeze': (HealOwnActiveFixed(30), RemoveOneActiveStatusCondition(),),
    },
    'xy8-15': {
        # Once during your turn (before your attack), you may flip a coin. If heads, search your deck for a basic Energy card and attach it to 1 of your Pokémon
        'Energy Color': (FlipCoinThen(heads=(SearchDeckAndAttachEnergy(None, count=1, self_only=False, any_energy=True),), tails=()),),
    },
    'xy8-54': {
        # As often as you like during your turn (before your attack), you may attach a Lightning Energy card from your hand to 1 of your Pokémon.
        'Magnetic Circuit': (AttachEnergyGeneric(source='hand', energy_type='Lightning'),),
    },
    'xy8-91': {
        # Once during your turn (before your attack), if this Pokémon is on your Bench, you may switch this Pokémon with your Active Pokémon.
        'Stand In': (AbilityGate('bench_only', ''), SwitchSelfFromBenchToActive(),),
    },
    'xy9-121': {
        # Once during your turn (before your attack), if this Pokémon has any basic Fire Energy attached to it, you may heal 50 damage from it.
        'Purifying Fire': (AbilityGate('self_has_energy', 'Fire'), HealSelf(50),),
    },
    'xy9-18': {
        # As often as you like during your turn (before your attack), you may move a basic Energy from 1 of your Pokémon to another of your Pokémon.
        'Hyper Transfer': (ChooseOwnPokemonThenMoveOneBasicEnergyToAnother(),),
    },
    'xy9-21': {
        # Once during your turn (before your attack), you may flip a coin. If heads, move an Energy from your opponent's Active Pokémon to 1 of his or her Bench
        'Royal Flash': (FlipCoinThen(heads=(MoveEnergyOnOpponentSide(),), tails=()),),
    },
    'xy9-51': {
        # Once during your turn (before your attack), you may leave both Active Pokémon Asleep.
        'Goodnight, Babies': (InflictStatusOnDefender('asleep'), InflictStatusOnOwnActive('asleep'),),
    },
    'xy9-92': {
        # Once during your turn (before your attack), if this Pokémon has any basic Fire Energy attached to it, you may heal 50 damage from it.
        'Purifying Fire': (AbilityGate('self_has_energy', 'Fire'), HealSelf(50),),
    },
    'xyp-XY146': {
        # Once during your turn (before your attack), you may attach a Special Energy card from your hand to 1 of your Mega Evolution Pokémon.
        'Mega Boost': (AttachEnergyGeneric(source='hand', special_only=True, target_subtype='MEGA'),),
    },
    'xyp-XY148': {
        # Once during your turn (before your attack), you may heal 20 damage from each of your Benched Basic Pokémon.
        'Aroma of Gratitude': (HealAllOwnPokemon(bench_only=True, amount=20, basic_only=True),),
    },
    'xyp-XY173': {
        # Once during your turn (before your attack), you may discard a Fire Energy card from your hand. If you do, during this turn, your Basic Fire Pokémon's 
        'Steam Up': (AbilityGate('hand_has_basic_energy', 'Fire'), DiscardFromHandBasicEnergyAsCost('Fire', then=(GrantTypeAttackBonusThisTurn('Fire', 30),)),),
    },
    'xyp-XY21': {
        # Once during your turn (before your attack), you may attach a Metal Energy card from your discard pile to 1 of your Benched Pokémon.
        'Metal Links': (AttachEnergyGeneric(source='discard', energy_type='Metal', bench_only=True),),
    },
    'xyp-XY61': {
        # Once during your turn (before your attack), if this Pokémon is your Active Pokémon, you may have your opponent switch his or her Active Pokémon with 1
        'Voice of the Sands': (AbilityGate('active_only', ''), ForceOpponentSwitchOpponentChooses(),),
    },
    'zsv10pt5-100': {
        # You must discard a Basic Fire Energy card from your hand in order to use this Ability. Once during your turn, you may make your opponent's Active Poké
        'Torrid Scales': (AbilityGate('hand_has_basic_energy', 'Fire'), DiscardFromHandBasicEnergyAsCost('Fire', then=(InflictStatusOnDefender('burned'),)),),
    },
    'zsv10pt5-108': {
        # Once during your turn, if this Pokémon is in the Active Spot, you may put a Basic Pokémon with 70 HP or less from your discard pile onto your Bench.
        'Gentle Fin': (AbilityGate('active_only', ''), SearchDiscardPokemonFiltered(count=1, destination='bench', max_hp=70),),
    },
    'zsv10pt5-16': {
        # You must discard a Basic Fire Energy card from your hand in order to use this Ability. Once during your turn, you may make your opponent's Active Poké
        'Torrid Scales': (AbilityGate('hand_has_basic_energy', 'Fire'), DiscardFromHandBasicEnergyAsCost('Fire', then=(InflictStatusOnDefender('burned'),)),),
    },
    'zsv10pt5-24': {
        # Once during your turn, if this Pokémon is in the Active Spot, you may put a Basic Pokémon with 70 HP or less from your discard pile onto your Bench.
        'Gentle Fin': (AbilityGate('active_only', ''), SearchDiscardPokemonFiltered(count=1, destination='bench', max_hp=70),),
    },
}

GENERATED_ENTER_BENCH_TRIGGER_EFFECTS: dict[str, dict] = {
    'bw10-98': {
        # When you play this Pokémon from your hand onto your Bench, you may search your deck for a Supporter card, reveal it, and put it into your hand. Shuffl
        'Stellar Guidance': (SearchDeckMultiCriteria(('supporter',)),),
    },
    'cel25c-60_A': {
        # When you play this Pokémon from your hand onto your Bench during your turn, you may search your deck for a Supporter card, reveal it, and put it into 
        'Wonder Tag': (SearchDeckMultiCriteria(('supporter',)),),
    },
    'sm10-195': {
        # When you play this Pokémon from your hand onto your Bench during your turn, you may discard your hand and draw 6 cards. You can't use more than 1 Dede
        'Dedechange': (AbilityGate('name_not_used', 'Dedechange'), MarkAbilityNameUsed('Dedechange'), DiscardHandThenDraw(6),),
    },
    'sm10-195a': {
        # When you play this Pokémon from your hand onto your Bench during your turn, you may discard your hand and draw 6 cards. You can't use more than 1 Dede
        'Dedechange': (AbilityGate('name_not_used', 'Dedechange'), MarkAbilityNameUsed('Dedechange'), DiscardHandThenDraw(6),),
    },
    'sm10-219': {
        # When you play this Pokémon from your hand onto your Bench during your turn, you may discard your hand and draw 6 cards. You can't use more than 1 Dede
        'Dedechange': (AbilityGate('name_not_used', 'Dedechange'), MarkAbilityNameUsed('Dedechange'), DiscardHandThenDraw(6),),
    },
    'sm10-75': {
        # When you play this Pokémon from your hand onto your Bench during your turn, you may put a Supporter card from your discard pile on top of your deck.
        'Mind Report': (PutDiscardCardOnTopOfDeck('supporter'),),
    },
    'sm11-141': {
        # When you play this Pokémon from your hand onto your Bench during your turn, you may have your opponent reveal their hand and put any number of Basic P
        'Captivating Wink': (PutOpponentHandBasicsOnTheirBench(),),
    },
    'sm11-227': {
        # When you play this Pokémon from your hand onto your Bench during your turn, you may have your opponent reveal their hand and put any number of Basic P
        'Captivating Wink': (PutOpponentHandBasicsOnTheirBench(),),
    },
    'sm11-246': {
        # When you play this Pokémon from your hand onto your Bench during your turn, you may have your opponent reveal their hand and put any number of Basic P
        'Captivating Wink': (PutOpponentHandBasicsOnTheirBench(),),
    },
    'sm2-135': {
        # When you play this Pokémon from your hand onto your Bench during your turn, you may move any number of Lightning Energy from your other Pokémon to thi
        'Aero Trail': (MoveEnergyToSelfFromOthers(energy_type='Lightning', switch_if_moved=True),),
    },
    'sm2-137': {
        # When you play this Pokémon from your hand onto your Bench during your turn, you may search your deck for a Supporter card, reveal it, and put it into 
        'Wonder Tag': (SearchDeckMultiCriteria(('supporter',)),),
    },
    'sm2-153': {
        # When you play this Pokémon from your hand onto your Bench during your turn, you may move any number of Lightning Energy from your other Pokémon to thi
        'Aero Trail': (MoveEnergyToSelfFromOthers(energy_type='Lightning', switch_if_moved=True),),
    },
    'sm2-155': {
        # When you play this Pokémon from your hand onto your Bench during your turn, you may search your deck for a Supporter card, reveal it, and put it into 
        'Wonder Tag': (SearchDeckMultiCriteria(('supporter',)),),
    },
    'sm2-55': {
        # When you play this Pokémon from your hand onto your Bench during your turn, you may search your deck for up to 2 basic Energy cards, reveal them, and 
        'Vital Dance': (SearchDeckForBasicEnergyToHand(count=2),),
    },
    'sm2-60a': {
        # When you play this Pokémon from your hand onto your Bench during your turn, you may search your deck for a Supporter card, reveal it, and put it into 
        'Wonder Tag': (SearchDeckMultiCriteria(('supporter',)),),
    },
    'sm4-103': {
        # When you play this Pokémon from your hand onto your Bench during your turn, you may leave both Active Pokémon Confused and Poisoned.
        'Empty Light': (InflictStatusOnBothActive(('confused', 'poisoned')),),
    },
    'sm4-106': {
        # When you play this Pokémon from your hand onto your Bench during your turn, you may discard a Special Energy from 1 of your opponent's Pokémon.
        'Slice Off': (PickPokemonThen(side='opp', action='discard_special_energy'),),
    },
    'sm4-114': {
        # When you play this Pokémon from your hand onto your Bench during your turn, you may leave both Active Pokémon Confused and Poisoned.
        'Empty Light': (InflictStatusOnBothActive(('confused', 'poisoned')),),
    },
    'sm4-117': {
        # When you play this Pokémon from your hand onto your Bench during your turn, you may discard a Special Energy from 1 of your opponent's Pokémon.
        'Slice Off': (PickPokemonThen(side='opp', action='discard_special_energy'),),
    },
    'sm4-49': {
        # When you play this Pokémon from your hand onto your Bench during your turn, you may leave both Active Pokémon Confused and Poisoned.
        'Empty Light': (InflictStatusOnBothActive(('confused', 'poisoned')),),
    },
    'sm7-154': {
        # When you play this Pokémon from your hand onto your Bench during your turn, you may switch it with your Active Pokémon. If you do, move any number of 
        'Legendary Ascent': (MoveEnergyToSelfFromOthers(energy_type='Water', switch_first=True),),
    },
    'sm7-160': {
        # When you play this Pokémon from your hand onto your Bench during your turn, you may discard the top 3 cards of your deck. If you do, attach a basic En
        'Stormy Winds': (DiscardTopOfOwnDeck(3), AttachEnergyGeneric(source='discard', basic_only=True, self_only=True),),
    },
    'sm7-171': {
        # When you play this Pokémon from your hand onto your Bench during your turn, you may switch it with your Active Pokémon. If you do, move any number of 
        'Legendary Ascent': (MoveEnergyToSelfFromOthers(energy_type='Water', switch_first=True),),
    },
    'sm7-177': {
        # When you play this Pokémon from your hand onto your Bench during your turn, you may discard the top 3 cards of your deck. If you do, attach a basic En
        'Stormy Winds': (DiscardTopOfOwnDeck(3), AttachEnergyGeneric(source='discard', basic_only=True, self_only=True),),
    },
    'sm7-177a': {
        # When you play this Pokémon from your hand onto your Bench during your turn, you may discard the top 3 cards of your deck. If you do, attach a basic En
        'Stormy Winds': (DiscardTopOfOwnDeck(3), AttachEnergyGeneric(source='discard', basic_only=True, self_only=True),),
    },
    'sma-SV54': {
        # When you play this Pokémon from your hand onto your Bench during your turn, you may switch it with your Active Pokémon. If you do, move any number of 
        'Legendary Ascent': (MoveEnergyToSelfFromOthers(energy_type='Water', switch_first=True),),
    },
    'sma-SV62': {
        # When you play this Pokémon from your hand onto your Bench during your turn, you may leave both Active Pokémon Confused and Poisoned.
        'Empty Light': (InflictStatusOnBothActive(('confused', 'poisoned')),),
    },
    'sma-SV73': {
        # When you play this Pokémon from your hand onto your Bench during your turn, you may discard a Special Energy from 1 of your opponent's Pokémon.
        'Slice Off': (PickPokemonThen(side='opp', action='discard_special_energy'),),
    },
    'sma-SV93': {
        # When you play this Pokémon from your hand onto your Bench during your turn, you may move any number of Lightning Energy from your other Pokémon to thi
        'Aero Trail': (MoveEnergyToSelfFromOthers(energy_type='Lightning', switch_if_moved=True),),
    },
    'sma-SV94': {
        # When you play this Pokémon from your hand onto your Bench during your turn, you may search your deck for a Supporter card, reveal it, and put it into 
        'Wonder Tag': (SearchDeckMultiCriteria(('supporter',)),),
    },
    'smp-SM214': {
        # When you play this Pokémon from your hand onto your Bench during your turn, you may put a Supporter card from your discard pile on top of your deck.
        'Mind Report': (PutDiscardCardOnTopOfDeck('supporter'),),
    },
    'smp-SM33': {
        # When you play this Pokémon from your hand onto your Bench during your turn, you may move any number of Lightning Energy from your other Pokémon to thi
        'Aero Trail': (MoveEnergyToSelfFromOthers(energy_type='Lightning', switch_if_moved=True),),
    },
    'smp-SM50': {
        # When you play this Pokémon from your hand onto your Bench during your turn, you may move any number of Lightning Energy from your other Pokémon to thi
        'Aero Trail': (MoveEnergyToSelfFromOthers(energy_type='Lightning', switch_if_moved=True),),
    },
    'sv2-170': {
        # When you play this Pokémon from your hand onto your Bench during your turn, you may search your deck for up to 3 Flamigo, reveal them, and put them in
        'Insta-Flock': (SearchDeckForNamedCardToHand(name='Flamigo', count=3),),
    },
    'sv2-227': {
        # When you play this Pokémon from your hand onto your Bench during your turn, you may search your deck for up to 3 Flamigo, reveal them, and put them in
        'Insta-Flock': (SearchDeckForNamedCardToHand(name='Flamigo', count=3),),
    },
    'sv3-143': {
        # When you play this Pokémon from your hand onto your Bench during your turn, you may discard a Special Energy from your opponent's Active Pokémon.
        'Special Eater': (DiscardOpponentActiveSpecialEnergy(),),
    },
    'sv4pt5-175': {
        # When you play this Pokémon from your hand onto your Bench during your turn, you may choose 2 of your opponent's Benched Pokémon and put 1 damage count
        'Flying Entry': (DistributeDamageCountersFreely(count=2, bench_only=True, max_per_target=1, exactly=True, target_count=2),),
    },
    'sv4pt5-211': {
        # When you play this Pokémon from your hand onto your Bench during your turn, you may search your deck for up to 3 Flamigo, reveal them, and put them in
        'Insta-Flock': (SearchDeckForNamedCardToHand(name='Flamigo', count=3),),
    },
    'sv5-186': {
        # When you play this Pokémon from your hand onto your Bench during your turn, you may switch it with your Active Pokémon. If you do, you may move any am
        'Rapid Vernier': (MoveEnergyToSelfFromOthers(switch_first=True),),
    },
    'sv5-203': {
        # When you play this Pokémon from your hand onto your Bench during your turn, you may switch it with your Active Pokémon. If you do, you may move any am
        'Rapid Vernier': (MoveEnergyToSelfFromOthers(switch_first=True),),
    },
    'sv5-213': {
        # When you play this Pokémon from your hand onto your Bench during your turn, you may switch it with your Active Pokémon. If you do, you may move any am
        'Rapid Vernier': (MoveEnergyToSelfFromOthers(switch_first=True),),
    },
    'sv5-25': {
        # When you play this Pokémon from your hand onto your Bench during your turn, you may switch it with your Active Pokémon. If you do, you may move any am
        'Rapid Vernier': (MoveEnergyToSelfFromOthers(switch_first=True),),
    },
    'sv6pt5-25': {
        # When you play this Pokémon from your hand onto your Bench during your turn, you may attach up to 2 Basic Fighting Energy cards from your hand to this 
        'Battle-Hardened': (AttachEnergyGeneric(source='hand', count=2, basic_only=True, energy_type='Fighting', self_only=True, optional=True),),
    },
    'sv8-215': {
        # When you play this Pokémon from your hand onto your Bench during your turn, you may discard the top card of your opponent's deck.
        'Sudden Shearing': (DiscardTopOfOpponentDeck(1),),
    },
    'sv8-236': {
        # When you play this Pokémon from your hand onto your Bench during your turn, you may discard the top card of your opponent's deck.
        'Sudden Shearing': (DiscardTopOfOpponentDeck(1),),
    },
    'sv8-4': {
        # When you play this Pokémon from your hand onto your Bench during your turn, you may discard the top card of your opponent's deck.
        'Sudden Shearing': (DiscardTopOfOpponentDeck(1),),
    },
    'sv8pt5-176': {
        # When you play this Pokémon from your hand onto your Bench during your turn, you may switch it with your Active Pokémon. If you do, you may move any am
        'Rapid Vernier': (MoveEnergyToSelfFromOthers(switch_first=True),),
    },
    'svp-128': {
        # When you play this Pokémon from your hand onto your Bench during your turn, you may switch it with your Active Pokémon. If you do, you may move any am
        'Rapid Vernier': (MoveEnergyToSelfFromOthers(switch_first=True),),
    },
    'svp-152': {
        # When you play this Pokémon from your hand onto your Bench during your turn, you may discard a Stadium in play.
        'Snow Sink': (DiscardStadiumInPlay(),),
    },
    'svp-39': {
        # When you play this Pokémon from your hand onto your Bench during your turn, you may discard a Special Energy from your opponent's Active Pokémon.
        'Special Eater': (DiscardOpponentActiveSpecialEnergy(),),
    },
    'svp-7': {
        # When you play this Pokémon from your hand onto your Bench during your turn, you may choose 2 of your opponent's Benched Pokémon and put 1 damage count
        'Flying Entry': (DistributeDamageCountersFreely(count=2, bench_only=True, max_per_target=1, exactly=True, target_count=2),),
    },
    'swsh10-55': {
        # When you play this Pokémon from your hand onto your Bench during your turn, you may heal 10 damage from your Active Pokémon.
        'Touch of Happiness': (HealOwnActiveFixed(10),),
    },
    'swsh11tg-TG20': {
        # When you play this Pokémon from your hand onto your Bench during your turn, you may draw cards until you have 6 cards in your hand. You can't use more
        'Dark Asset': (AbilityGate('name_not_used', 'Dark Asset'), MarkAbilityNameUsed('Dark Asset'), DrawUpTo(6),),
    },
    'swsh12pt5-105': {
        # When you play this Pokémon from your hand onto your Bench during your turn, you may search your deck for up to 2 Pokémon VMAX and put them onto your B
        'Climactic Gate': (SearchByCriterionToBench('cardspec:subtype:VMAX', count=2), EndTurnAfterThisAbility(),),
    },
    'swsh12pt5gg-GG39': {
        # When you play this Pokémon from your hand onto your Bench during your turn, you may search your deck for a Supporter card, reveal it, and put it into 
        'Luminous Sign': (SearchDeckMultiCriteria(('supporter',)),),
    },
    'swsh2-142': {
        # When you play this Pokémon from your hand onto your Bench during your turn, you may flip a coin. If heads, put a Supporter card from your discard pile
        'Lucky Match': (FlipCoinThen(heads=(SearchDiscardForSupporterToHand(),), tails=()),),
    },
    'swsh2-176': {
        # When you play this Pokémon from your hand onto your Bench during your turn, you may put a Supporter card from your discard pile into your hand.
        'Happy Match': (SearchDiscardForSupporterToHand(),),
    },
    'swsh2-19': {
        # When you play this Pokémon from your hand onto your Bench during your turn, you may put a Supporter card from your discard pile into your hand.
        'Happy Match': (SearchDiscardForSupporterToHand(),),
    },
    'swsh3-182': {
        # When you play this Pokémon from your hand onto your Bench during your turn, you may draw cards until you have 6 cards in your hand. You can't use more
        'Dark Asset': (AbilityGate('name_not_used', 'Dark Asset'), MarkAbilityNameUsed('Dark Asset'), DrawUpTo(6),),
    },
    'swsh35-5': {
        # When you play this Pokémon from your hand onto your Bench during your turn, you may put a Supporter card from your discard pile into your hand.
        'Happy Match': (SearchDiscardForSupporterToHand(),),
    },
    'swsh45-34': {
        # When you play this Pokémon from your hand onto your Bench during your turn, you may search your deck for up to 2 Item cards that have the word "Rotom"
        'Roto Choice': (SearchDeckByCriterionToHand('item_name_contains:Rotom', count=2),),
    },
    'swsh45-44': {
        # When you play this Pokémon from your hand onto your Bench during your turn, you may draw cards until you have 6 cards in your hand. You can't use more
        'Dark Asset': (AbilityGate('name_not_used', 'Dark Asset'), MarkAbilityNameUsed('Dark Asset'), DrawUpTo(6),),
    },
    'swsh45sv-SV038': {
        # When you play this Pokémon from your hand onto your Bench during your turn, you may search your deck for up to 2 Item cards that have the word "Rotom"
        'Roto Choice': (SearchDeckByCriterionToHand('item_name_contains:Rotom', count=2),),
    },
    'swsh45sv-SV078': {
        # When you play this Pokémon from your hand onto your Bench during your turn, you may put 1 damage counter on 1 of your opponent's Pokémon.
        'Headbutt Tantrum': (DamageCounterOnChosenOpponentPokemon(count=1),),
    },
    'swsh5-148': {
        # When you play this Pokémon from your hand onto your Bench during your turn, you may prevent all damage done to this Mimikyu V by attacks from your opp
        'Dummy Doll': (ApplyScopedDamageImmunityToSelf('all'),),
    },
    'swsh5-62': {
        # When you play this Pokémon from your hand onto your Bench during your turn, you may prevent all damage done to this Mimikyu V by attacks from your opp
        'Dummy Doll': (ApplyScopedDamageImmunityToSelf('all'),),
    },
    'swsh7-63': {
        # When you play this Pokémon from your hand onto your Bench during your turn, you may attach up to 2 Psychic Energy cards from your hand to this Pokémon
        'Cruel Charge': (AttachEnergyGeneric(source='hand', count=2, basic_only=True, energy_type='Psychic', self_only=True, optional=True),),
    },
    'swsh7-82': {
        # When you play this Pokémon from your hand onto your Bench during your turn, you may attach up to 2 Fighting Energy cards from your hand to this Pokémo
        'Strong Legs Charge': (AttachEnergyGeneric(source='hand', count=2, basic_only=True, energy_type='Fighting', self_only=True, optional=True),),
    },
    'swsh7-93': {
        # When you play this Pokémon from your hand onto your Bench during your turn, you may attach up to 2 Darkness Energy cards from your hand to this Pokémo
        'Malevolent Charge': (AttachEnergyGeneric(source='hand', count=2, basic_only=True, energy_type='Darkness', self_only=True, optional=True),),
    },
    'swsh9-126': {
        # When you play this Pokémon from your hand onto your Bench, you may have your opponent switch his or her Active Pokémon with 1 of his or her Benched Po
        'Sudden Cyclone': (ForceOpponentSwitchOpponentChooses(),),
    },
    'swsh9-155': {
        # When you play this Pokémon from your hand onto your Bench during your turn, you may search your deck for a Supporter card, reveal it, and put it into 
        'Luminous Sign': (SearchDeckMultiCriteria(('supporter',)),),
    },
    'swsh9-156': {
        # When you play this Pokémon from your hand onto your Bench during your turn, you may search your deck for a Supporter card, reveal it, and put it into 
        'Luminous Sign': (SearchDeckMultiCriteria(('supporter',)),),
    },
    'swsh9-68': {
        # When you play this Pokémon from your hand onto your Bench during your turn, you may prevent all damage done to this Mimikyu V by attacks from your opp
        'Dummy Doll': (ApplyScopedDamageImmunityToSelf('all'),),
    },
    'swsh9tg-TG16': {
        # When you play this Pokémon from your hand onto your Bench during your turn, you may prevent all damage done to this Mimikyu V by attacks from your opp
        'Dummy Doll': (ApplyScopedDamageImmunityToSelf('all'),),
    },
    'swshp-SWSH084': {
        # When you play this Pokémon from your hand onto your Bench during your turn, you may put a Supporter card from your discard pile into your hand.
        'Happy Match': (SearchDiscardForSupporterToHand(),),
    },
    'swshp-SWSH098': {
        # When you play this Pokémon from your hand onto your Bench during your turn, you may draw cards until you have 6 cards in your hand. You can't use more
        'Dark Asset': (AbilityGate('name_not_used', 'Dark Asset'), MarkAbilityNameUsed('Dark Asset'), DrawUpTo(6),),
    },
    'swshp-SWSH110': {
        # When you play this Pokémon from your hand onto your Bench during your turn, you may draw cards until you have 6 cards in your hand. You can't use more
        'Dark Asset': (AbilityGate('name_not_used', 'Dark Asset'), MarkAbilityNameUsed('Dark Asset'), DrawUpTo(6),),
    },
    'swshp-SWSH123': {
        # When you play this Pokémon from your hand onto your Bench during your turn, you may attach up to 2 Psychic Energy cards from your hand to this Pokémon
        'Cruel Charge': (AttachEnergyGeneric(source='hand', count=2, basic_only=True, energy_type='Psychic', self_only=True, optional=True),),
    },
    'swshp-SWSH124': {
        # When you play this Pokémon from your hand onto your Bench during your turn, you may attach up to 2 Fighting Energy cards from your hand to this Pokémo
        'Strong Legs Charge': (AttachEnergyGeneric(source='hand', count=2, basic_only=True, energy_type='Fighting', self_only=True, optional=True),),
    },
    'swshp-SWSH125': {
        # When you play this Pokémon from your hand onto your Bench during your turn, you may attach up to 2 Darkness Energy cards from your hand to this Pokémo
        'Malevolent Charge': (AttachEnergyGeneric(source='hand', count=2, basic_only=True, energy_type='Darkness', self_only=True, optional=True),),
    },
    'swshp-SWSH144': {
        # When you play this Pokémon from your hand onto your Bench during your turn, you may put 1 damage counter on 1 of your opponent's Pokémon.
        'Shadow Knife': (DamageCounterOnChosenOpponentPokemon(count=1),),
    },
    'swshp-SWSH250': {
        # When you play this Pokémon from your hand onto your Bench during your turn, you may search your deck for a Supporter card, reveal it, and put it into 
        'Luminous Sign': (SearchDeckMultiCriteria(('supporter',)),),
    },
    'swshp-SWSH282': {
        # When you play this Pokémon from your hand onto your Bench during your turn, you may attach up to 2 Psychic Energy cards from your hand to this Pokémon
        'Cruel Charge': (AttachEnergyGeneric(source='hand', count=2, basic_only=True, energy_type='Psychic', self_only=True, optional=True),),
    },
    'swshp-SWSH283': {
        # When you play this Pokémon from your hand onto your Bench during your turn, you may attach up to 2 Fighting Energy cards from your hand to this Pokémo
        'Strong Legs Charge': (AttachEnergyGeneric(source='hand', count=2, basic_only=True, energy_type='Fighting', self_only=True, optional=True),),
    },
    'swshp-SWSH284': {
        # When you play this Pokémon from your hand onto your Bench during your turn, you may attach up to 2 Darkness Energy cards from your hand to this Pokémo
        'Malevolent Charge': (AttachEnergyGeneric(source='hand', count=2, basic_only=True, energy_type='Darkness', self_only=True, optional=True),),
    },
    'xy11-12': {
        # When you play this Pokémon from your hand onto your Bench, you may put 3 Poké Ball cards from your discard pile into your hand.
        'Play Ball': (SearchDiscardForNamedCardsToHand(names=('Poké Ball',), count=3),),
    },
    'xy11-97': {
        # When you play this Pokémon from your hand onto your Bench, you may have your opponent switch his or her Active Pokémon with 1 of his or her Benched Po
        'Sudden Cyclone': (ForceOpponentSwitchOpponentChooses(),),
    },
    'xy12-106': {
        # When you play this Pokémon from your hand onto your Bench, you may put 2 Basic Pokémon (except for Dragonite-EX) from your discard pile into your hand
        'Pull Up': (SearchDiscardPokemonFiltered(count=2, destination='hand', exclude_name='Dragonite-EX'),),
    },
    'xy12-66': {
        # When you play this Pokémon from your hand onto your Bench, you may discard all Pokémon Tool cards attached to your opponent's Active Pokémon.
        'Mischievous Fang': (DiscardOpponentActiveTool(),),
    },
    'xy12-72': {
        # When you play this Pokémon from your hand onto your Bench, you may put 2 Basic Pokémon (except for Dragonite-EX) from your discard pile into your hand
        'Pull Up': (SearchDiscardPokemonFiltered(count=2, destination='hand', exclude_name='Dragonite-EX'),),
    },
    'xy3-108': {
        # When you play this Pokémon from your hand onto your Bench, you may move any number of basic Energy attached to your Pokémon to this Pokémon. If you do
        'Bust In': (MoveEnergyGeneric(owner='own', sources='any', dests='self', basic_only=True, freely=True), IfLastAttachSucceeded(then=(SwitchSelfFromBenchToActive(),)),),
    },
    'xy3-74': {
        # When you play this Pokémon from your hand onto your Bench, you may move any number of basic Energy attached to your Pokémon to this Pokémon. If you do
        'Bust In': (MoveEnergyGeneric(owner='own', sources='any', dests='self', basic_only=True, freely=True), IfLastAttachSucceeded(then=(SwitchSelfFromBenchToActive(),)),),
    },
    'xy6-106': {
        # When you play this Pokémon from your hand onto your Bench, you may draw cards until you have 6 cards in your hand.
        'Set Up': (DrawUpTo(6),),
    },
    'xy6-77a': {
        # When you play this Pokémon from your hand onto your Bench, you may draw cards until you have 6 cards in your hand.
        'Set Up': (DrawUpTo(6),),
    },
    'xy7-89': {
        # When you play this Pokémon from your hand onto your Bench, you may search your deck for up to 3 Pokémon-EX (except for Hoopa-EX), reveal them, and put
        'Scoundrel Ring': (SearchDeckForPokemonToHand(3, required_subtypes=('EX',), exclude_name='Hoopa-EX'),),
    },
    'xyp-XY71': {
        # When you play this Pokémon from your hand onto your Bench, you may search your deck for up to 3 Pokémon-EX (except for Hoopa-EX), reveal them, and put
        'Scoundrel Ring': (SearchDeckForPokemonToHand(3, required_subtypes=('EX',), exclude_name='Hoopa-EX'),),
    },
}

GENERATED_EVOLVE_TRIGGER_EFFECTS: dict[str, dict] = {
    'bw10-64': {
        # When you play this Pokémon from your hand to evolve 1 of your Pokémon, you may discard all Pokémon Tool cards attached to each of your opponent's Poké
        'Breakwing': (DiscardAllOpponentTools(),),
    },
    'bw4-72': {
        # When you play this Pokémon from your hand to evolve 1 of your Pokémon, you may flip a coin. If heads, choose 1 of your opponent's Pokémon. Your oppone
        'Giant Fan': (FlipCoinThen(heads=(PickPokemonThen(side='opp', action='shuffle_into_deck'),), tails=()),),
    },
    'bw4-9': {
        # When you play this Pokémon from your hand to evolve 1 of your Pokémon, you may use this Ability. If you do, your opponent's Active Pokémon is now Conf
        'Sporprise': (InflictStatusOnDefender('confused'), InflictStatusOnDefender('poisoned'),),
    },
    'bw6-11': {
        # When you play this Pokémon from your hand to evolve 1 of your Pokémon, you may search your deck for Shedinja and put it onto your Bench. Shuffle your 
        'Cast-off Shell': (SearchDeckForNamedPokemonToBench(name='Shedinja', count=1),),
    },
    'bw6-15': {
        # When you play this Pokémon from your hand to evolve 1 of your Pokémon, you may search your deck for any card and put it into your hand. Shuffle your d
        'Le Parfum': (SearchDeckAnyCardToHand(count=1),),
    },
    'bw6-19': {
        # When you play this Pokémon from your hand to evolve 1 of your Pokémon, you may switch 1 of your opponent's Benched Pokémon with his or her Active Poké
        'Bright Look': (PickPokemonThen(side='opp', action='switch_opp_active', bench_only=True),),
    },
    'bw6-80': {
        # When you play this Pokémon from your hand to evolve 1 of your Pokémon, you may discard the top 3 cards of your opponent's deck.
        'Toppling Wind': (DiscardTopOfOpponentDeck(3),),
    },
    'bwp-BW66': {
        # When you play this Pokémon from your hand to evolve 1 of your Pokémon, you may switch 1 of your opponent's Benched Pokémon with his or her Active Poké
        'Bright Look': (PickPokemonThen(side='opp', action='switch_opp_active', bench_only=True),),
    },
    'bwp-BW85': {
        # When you play this Pokémon from your hand to evolve 1 of your Pokémon, you may draw 2 cards.
        'Intuition': (Draw(2),),
    },
    'g1-31': {
        # When you play this Pokémon from your hand to evolve 1 of your Pokémon, you may put 2 damage counters on 1 of your opponent's Pokémon.
        'Sneaky Bite': (PickPokemonThen(side='opp', action='put_counters', amount=2),),
    },
    'g1-34': {
        # When you play this Pokémon from your hand to evolve 1 of your Pokémon, you may leave both Active Pokémon Confused.
        'Gothic Fear': (InflictStatusOnDefender('confused'), InflictStatusOnOwnActive('confused'),),
    },
    'me1-137': {
        # Once during your turn, when you play this Pokémon from your hand to evolve 1 of your Pokémon, you may use this Ability. Search your deck for a Shedinj
        'Cast-Off Shell': (SearchDeckForNamedPokemonToBench(name='Shedinja', count=1),),
    },
    'me1-17': {
        # Once during your turn, when you play this Pokémon from your hand to evolve 1 of your Pokémon, you may use this Ability. Search your deck for a Shedinj
        'Cast-Off Shell': (SearchDeckForNamedPokemonToBench(name='Shedinja', count=1),),
    },
    'me1-63': {
        # Once during your turn, when you play this Pokémon from your hand to evolve 1 of your Pokémon, you may use this Ability. Look at the top 4 cards of you
        'Energized Steps': (AttachEnergyGeneric(source='deck', count=99, basic_only=True, optional=True, deck_limit=4),),
    },
    'me1-73': {
        # Once during your turn, when you play this Pokémon from your hand to evolve 1 of your Pokémon, you may use this Ability. Switch in 1 of your opponent's
        'Heave-Ho Catcher': (PickPokemonThen(side='opp', action='switch_opp_active', bench_only=True),),
    },
    'me1-97': {
        # Once during your turn, when you play this Pokémon from your hand to evolve 1 of your Pokémon, you may use this Ability. Flip a coin. If heads, discard
        'Haphazard Hammer': (FlipCoinThen(heads=(DiscardOpponentActiveEnergy(),), tails=()),),
    },
    'me2-47': {
        # Once during your turn, when you play this Pokémon from your hand to evolve 1 of your Pokémon, you may use this Ability. Make your opponent's Active Po
        'Prison Panic': (InflictStatusOnDefender('confused'),),
    },
    'me2pt5-12': {
        # Once during your turn, when you play this Pokémon from your hand to evolve 1 of your Pokémon, you may use this Ability. Search your deck for a Silcoon
        'Multiplying Cocoon': (SearchDeckPokemonToBench(names=('Silcoon', 'Cascoon'), count=1),),
    },
    'me5-20': {
        # Once during your turn, when you play this Pokémon from your hand to evolve 1 of your Pokémon, you may use this Ability. Heal all damage from 1 of your
        'Enriching Melody': (PickPokemonThen(action='heal', full=True, damaged_only=True),),
    },
    'me5-88': {
        # Once during your turn, when you play this Pokémon from your hand to evolve 1 of your Pokémon, you may use this Ability. Heal all damage from 1 of your
        'Enriching Melody': (PickPokemonThen(action='heal', full=True, damaged_only=True),),
    },
    'sm1-104': {
        # When you play this Pokémon from your hand to evolve 1 of your Pokémon during your turn, you may put an Item card from your discard pile into your hand
        'Treasure Hunt': (SearchDiscardForItemToHand(count=1),),
    },
    'sm1-20': {
        # When you play this Pokémon from your hand to evolve 1 of your Pokémon during your turn, you may have your opponent reveal their hand. Then, discard a 
        'Queenly Majesty': (RevealOpponentHandThenDiscardChosen(count=1),),
    },
    'sm10-111': {
        # When you play this Pokémon from your hand to evolve 1 of your Pokémon during your turn, you may look at the top 6 cards of your deck and attach any nu
        'Greedy Evolution': (AttachEnergyGeneric(source='deck', count=99, deck_limit=6, basic_only=True, energy_type='Darkness', self_only=True),),
    },
    'sm10-66': {
        # When you play this Pokémon from your hand to evolve 1 of your Pokémon during your turn, you may prevent all effects of your opponent's attacks, includ
        'Sound Veil': (ApplyShieldToSelf(),),
    },
    'sm11-144': {
        # When you play this Pokémon from your hand to evolve 1 of your Pokémon during your turn, you may search your deck for a card and put it into your hand.
        'Prowl': (SearchDeckAnyCardToHand(1),),
    },
    'sm12-151': {
        # When you play this Pokémon from your hand to evolve 1 of your Pokémon during your turn, you may choose 2 random cards from your opponent's hand. Your 
        'Flower Picking': (RandomOpponentHandCardToDeck(), RandomOpponentHandCardToDeck(),),
    },
    'sm12-152': {
        # When you play this Pokémon from your hand to evolve 1 of your Pokémon during your turn, you may choose 2 random cards from your opponent's hand. Your 
        'Flower Picking': (RandomOpponentHandCardToDeck(), RandomOpponentHandCardToDeck(),),
    },
    'sm2-102': {
        # When you play this Pokémon from your hand to evolve 1 of your Pokémon during your turn, you may heal 80 damage from your Active Pokémon.
        'Fresh Egg': (HealOwnActiveFixed(80),),
    },
    'sm2-113': {
        # When you play this Pokémon from your hand to evolve 1 of your Pokémon during your turn, you may draw 3 cards.
        'Rake It In': (Draw(3),),
    },
    'sm2-138': {
        # When you play this Pokémon from your hand to evolve 1 of your Pokémon during your turn, you may switch 1 of your opponent's Benched Pokémon with their
        'Bloodthirsty Eyes': (ForceOpponentSwitchChosenBench(),),
    },
    'sm2-156': {
        # When you play this Pokémon from your hand to evolve 1 of your Pokémon during your turn, you may switch 1 of your opponent's Benched Pokémon with their
        'Bloodthirsty Eyes': (ForceOpponentSwitchChosenBench(),),
    },
    'sm2-16': {
        # When you play this Pokémon from your hand to evolve 1 of your Pokémon during your turn, you may leave your opponent's Active Pokémon Burned and Poison
        'Hot Poison': (InflictStatusOnDefender('burned'), InflictStatusOnDefender('poisoned'),),
    },
    'sm3-105': {
        # When you play this Pokémon from your hand to evolve 1 of your Pokémon during your turn, you may devolve each of your opponent's evolved Pokémon by put
        'Initialize': (DevolveAllOpponentEvolvedPokemon(),),
    },
    'sm3-105a': {
        # When you play this Pokémon from your hand to evolve 1 of your Pokémon during your turn, you may devolve each of your opponent's evolved Pokémon by put
        'Initialize': (DevolveAllOpponentEvolvedPokemon(),),
    },
    'sm3-41': {
        # When you play this Pokémon from your hand to evolve 1 of your Pokémon during your turn, you may leave your opponent's Active Pokémon Paralyzed.
        'Evoshock': (InflictStatusOnDefender('paralyzed'),),
    },
    'sm3-67': {
        # When you play this Pokémon from your hand to evolve 1 of your Pokémon during your turn, you may discard the top 3 cards of your opponent's deck.
        'Toppling Wind': (DiscardTopOfOpponentDeck(3),),
    },
    'sm3-71': {
        # When you play this Pokémon from your hand to evolve 1 of your Pokémon during your turn, you may prevent all effects of your opponent's attacks, includ
        'Stance': (ApplyShieldToSelf(),),
    },
    'sm5-38': {
        # When you play this Pokémon from your hand to evolve 1 of your Pokémon during your turn, you may attach a Water Energy card from your discard pile to 1
        'Blessings of the Frost': (AttachEnergyGeneric(source='discard', count=1, basic_only=True, energy_type='Water', single_target=True),),
    },
    'sm6-120': {
        # When you play this Pokémon from your hand to evolve 1 of your Pokémon during your turn, you may put 3 damage counters on 1 of your opponent's Pokémon.
        'Shuriken Flurry': (DamageCounterOnChosenOpponentPokemon(count=3),),
    },
    'sm6-133': {
        # When you play this Pokémon from your hand to evolve 1 of your Pokémon during your turn, you may put 3 damage counters on 1 of your opponent's Pokémon.
        'Shuriken Flurry': (DamageCounterOnChosenOpponentPokemon(count=3),),
    },
    'sm6-23': {
        # When you play this Pokémon from your hand to evolve 1 of your Pokémon during your turn, you may put 2 damage counters on 1 of your opponent's Pokémon.
        'Gale Shuriken': (DamageCounterOnChosenOpponentPokemon(count=2),),
    },
    'sm6-24': {
        # When you play this Pokémon from your hand to evolve 1 of your Pokémon during your turn, you may put 3 damage counters on 1 of your opponent's Pokémon.
        'Shuriken Flurry': (DamageCounterOnChosenOpponentPokemon(count=3),),
    },
    'sm6-4': {
        # When you play this Pokémon from your hand to evolve 1 of your Pokémon during your turn, you may attach a Grass Energy card from your discard pile to 1
        'Blessings of the Frost': (AttachEnergyGeneric(source='discard', count=1, basic_only=True, energy_type='Grass', single_target=True),),
    },
    'sm7-121': {
        # When you play this Pokémon from your hand to evolve 1 of your Pokémon during your turn, you may put 2 Supporter cards from your discard pile into your
        'Search for Friends': (SearchDiscardByCriterionToHand('supporter', count=2),),
    },
    'sm75-2': {
        # When you play this Pokémon from your hand to evolve 1 of your Pokémon during your turn, you may discard the top 5 cards of your deck. If any of those 
        'Burning Fighter': (DiscardTopNAttachEnergyFound(5, basic_only=True, self_only=True, energy_type='Fire'),),
    },
    'sm8-132': {
        # When you play this Pokémon from your hand to evolve 1 of your Pokémon during your turn, you may search your deck for up to 2 Item cards, reveal them, 
        'Mysterious Guidance': (SearchDeckByCriterionToHand('item', count=2),),
    },
    'sm8-205': {
        # When you play this Pokémon from your hand to evolve 1 of your Pokémon during your turn, you may search your deck for up to 2 Item cards, reveal them, 
        'Mysterious Guidance': (SearchDeckByCriterionToHand('item', count=2),),
    },
    'sm8-225': {
        # When you play this Pokémon from your hand to evolve 1 of your Pokémon during your turn, you may search your deck for up to 2 Item cards, reveal them, 
        'Mysterious Guidance': (SearchDeckByCriterionToHand('item', count=2),),
    },
    'sm9-82': {
        # When you play this Pokémon from your hand to evolve 1 of your Pokémon during your turn, you may discard an Energy attached to your opponent's Active P
        'Twilight Eyes': (DiscardOpponentActiveEnergy(),),
    },
    'sma-SV12': {
        # When you play this Pokémon from your hand to evolve 1 of your Pokémon during your turn, you may put 2 damage counters on 1 of your opponent's Pokémon.
        'Gale Shuriken': (DamageCounterOnChosenOpponentPokemon(count=2),),
    },
    'sma-SV56': {
        # When you play this Pokémon from your hand to evolve 1 of your Pokémon during your turn, you may put 3 damage counters on 1 of your opponent's Pokémon.
        'Shuriken Flurry': (DamageCounterOnChosenOpponentPokemon(count=3),),
    },
    'sma-SV66': {
        # When you play this Pokémon from your hand to evolve 1 of your Pokémon during your turn, you may switch 1 of your opponent's Benched Pokémon with their
        'Bloodthirsty Eyes': (ForceOpponentSwitchChosenBench(),),
    },
    'sma-SV67': {
        # When you play this Pokémon from your hand to evolve 1 of your Pokémon during your turn, you may discard an Energy attached to your opponent's Active P
        'Twilight Eyes': (DiscardOpponentActiveEnergy(),),
    },
    'sma-SV7': {
        # When you play this Pokémon from your hand to evolve 1 of your Pokémon during your turn, you may discard the top 5 cards of your deck. If any of those 
        'Burning Fighter': (DiscardTopNAttachEnergyFound(5, basic_only=True, self_only=True, energy_type='Fire'),),
    },
    'smp-SM132': {
        # When you play this Pokémon from your hand to evolve 1 of your Pokémon during your turn, you may put 2 Supporter cards from your discard pile into your
        'Search for Friends': (SearchDiscardByCriterionToHand('supporter', count=2),),
    },
    'smp-SM26': {
        # When you play this Pokémon from your hand to evolve 1 of your Pokémon during your turn, you may have your opponent reveal their hand. Then, discard a 
        'Queenly Majesty': (RevealOpponentHandThenDiscardChosen(count=1),),
    },
    'smp-SM54': {
        # When you play this Pokémon from your hand to evolve 1 of your Pokémon during your turn, you may prevent all effects of your opponent's attacks, includ
        'Stance': (ApplyShieldToSelf(),),
    },
    'sv1-23': {
        # When you play this Pokémon from your hand to evolve 1 of your Pokémon during your turn, you may heal all damage from 1 of your Pokémon.
        'Enriching Oil': (PickPokemonThen(side='own', action='heal', full=True, damaged_only=True),),
    },
    'sv10-122': {
        # When you play this Pokémon from your hand to evolve 1 of your Pokémon during your turn, you may choose 2 of your opponent's Pokémon and put 2 damage c
        'Biting Spree': (DistributeDamageCountersFreely(count=4, max_per_target=2, exactly=True, target_count=2),),
    },
    'sv10-159': {
        # When you play this Pokémon from your hand to evolve 1 of your Pokémon during your turn, you may put up to 2 Arven's Sandwich cards from your discard p
        'Greedy Order': (SearchDiscardForNamedCardsToHand(names=("Arven's Sandwich",), count=2),),
    },
    'sv10-205': {
        # When you play this Pokémon from your hand to evolve 1 of your Pokémon during your turn, you may put up to 2 Arven's Sandwich cards from your discard p
        'Greedy Order': (SearchDiscardForNamedCardsToHand(names=("Arven's Sandwich",), count=2),),
    },
    'sv10-217': {
        # When you play this Pokémon from your hand to evolve 1 of your Pokémon during your turn, you may choose 2 of your opponent's Pokémon and put 2 damage c
        'Biting Spree': (DistributeDamageCountersFreely(count=4, max_per_target=2, exactly=True, target_count=2),),
    },
    'sv10-234': {
        # When you play this Pokémon from your hand to evolve 1 of your Pokémon during your turn, you may choose 2 of your opponent's Pokémon and put 2 damage c
        'Biting Spree': (DistributeDamageCountersFreely(count=4, max_per_target=2, exactly=True, target_count=2),),
    },
    'sv10-242': {
        # When you play this Pokémon from your hand to evolve 1 of your Pokémon during your turn, you may choose 2 of your opponent's Pokémon and put 2 damage c
        'Biting Spree': (DistributeDamageCountersFreely(count=4, max_per_target=2, exactly=True, target_count=2),),
    },
    'sv2-159': {
        # When you play this Pokémon from your hand to evolve 1 of your Pokémon during your turn, you may choose 1: put a Supporter card from your discard pile 
        'Hearsay': (ChooseOneEffectBranch(labels=('トラッシュのサポートを手札に加える', '山札のサポートを手札に加える'), branches=((SearchDiscardForSupporterToHand(),), (SearchDeckMultiCriteria(('supporter',)),))),),
    },
    'sv2-212': {
        # When you play this Pokémon from your hand to evolve 1 of your Pokémon during your turn, you may move an Energy from your opponent's Active Pokémon to 
        'Magical Flick': (MoveEnergyOnOpponentSide(),),
    },
    'sv2-88': {
        # When you play this Pokémon from your hand to evolve 1 of your Pokémon during your turn, you may move an Energy from your opponent's Active Pokémon to 
        'Magical Flick': (MoveEnergyOnOpponentSide(),),
    },
    'sv3-215': {
        # When you play this Pokémon from your hand to evolve 1 of your Pokémon during your turn, you may search your deck for up to 3 Basic Fire Energy cards a
        'Infernal Reign': (AttachEnergyGeneric(source='deck', count=3, basic_only=True, energy_type='Fire', optional=True),),
    },
    'sv3-223': {
        # When you play this Pokémon from your hand to evolve 1 of your Pokémon during your turn, you may search your deck for up to 3 Basic Fire Energy cards a
        'Infernal Reign': (AttachEnergyGeneric(source='deck', count=3, basic_only=True, energy_type='Fire', optional=True),),
    },
    'sv3-228': {
        # When you play this Pokémon from your hand to evolve 1 of your Pokémon during your turn, you may search your deck for up to 3 Basic Fire Energy cards a
        'Infernal Reign': (AttachEnergyGeneric(source='deck', count=3, basic_only=True, energy_type='Fire', optional=True),),
    },
    'sv3pt5-44': {
        # When you play this Pokémon from your hand to evolve 1 of your Pokémon during your turn, you may look at the top 3 cards of your deck and attach any nu
        'Semi-Blooming Energy': (AttachEnergyGeneric(source='deck', count=99, deck_limit=3, basic_only=True, optional=True),),
    },
    'sv3pt5-45': {
        # When you play this Pokémon from your hand to evolve 1 of your Pokémon during your turn, you may look at the top 8 cards of your deck and attach any nu
        'Fully Blooming Energy': (AttachEnergyGeneric(source='deck', count=99, deck_limit=8, basic_only=True, optional=True),),
    },
    'sv3pt5-97': {
        # When you play this Pokémon from your hand to evolve 1 of your Pokémon during your turn, you may make your opponent's Active Pokémon Asleep.
        'Here for Hypnosis': (InflictStatusOnDefender('asleep'),),
    },
    'sv4-197': {
        # When you play this Pokémon from your hand to evolve 1 of your Pokémon during your turn, you may prevent all damage from and effects of attacks from yo
        'Stance': (ApplyShieldToSelf(),),
    },
    'sv4-34': {
        # When you play this Pokémon from your hand to evolve 1 of your Pokémon during your turn, you may draw 3 cards.
        'Suction Cup Draw': (Draw(3),),
    },
    'sv4-53': {
        # When you play this Pokémon from your hand to evolve 1 of your Pokémon during your turn, you may search your deck for up to 3 Pokémon Tool cards, revea
        'Suddenly Select': (SearchDeckByCriterionToHand('pokemon_tool', count=3),),
    },
    'sv4-81': {
        # When you play this Pokémon from your hand to evolve 1 of your Pokémon during your turn, you may prevent all damage from and effects of attacks from yo
        'Stance': (ApplyShieldToSelf(),),
    },
    'sv4pt5-104': {
        # When you play this Pokémon from your hand to evolve 1 of your Pokémon during your turn, you may heal all damage from 1 of your Pokémon.
        'Enriching Oil': (PickPokemonThen(side='own', action='heal', full=True, damaged_only=True),),
    },
    'sv4pt5-204': {
        # When you play this Pokémon from your hand to evolve 1 of your Pokémon during your turn, you may choose 1: put a Supporter card from your discard pile 
        'Hearsay': (ChooseOneEffectBranch(labels=('トラッシュのサポートを手札に加える', '山札のサポートを手札に加える'), branches=((SearchDiscardForSupporterToHand(),), (SearchDeckMultiCriteria(('supporter',)),))),),
    },
    'sv4pt5-234': {
        # When you play this Pokémon from your hand to evolve 1 of your Pokémon during your turn, you may search your deck for up to 3 Basic Fire Energy cards a
        'Infernal Reign': (AttachEnergyGeneric(source='deck', count=3, basic_only=True, energy_type='Fire', optional=True),),
    },
    'sv4pt5-54': {
        # When you play this Pokémon from your hand to evolve 1 of your Pokémon during your turn, you may search your deck for up to 3 Basic Fire Energy cards a
        'Infernal Reign': (AttachEnergyGeneric(source='deck', count=3, basic_only=True, energy_type='Fire', optional=True),),
    },
    'sv4pt5-93': {
        # When you play this Pokémon from your hand to evolve 1 of your Pokémon during your turn, you may look at the top 3 cards of your deck and attach any nu
        'Semi-Blooming Energy': (AttachEnergyGeneric(source='deck', count=99, deck_limit=3, basic_only=True, optional=True),),
    },
    'sv4pt5-94': {
        # When you play this Pokémon from your hand to evolve 1 of your Pokémon during your turn, you may look at the top 8 cards of your deck and attach any nu
        'Fully Blooming Energy': (AttachEnergyGeneric(source='deck', count=99, deck_limit=8, basic_only=True, optional=True),),
    },
    'sv7-144': {
        # When you play this Pokémon from your hand to evolve 1 of your Pokémon during your turn, you may switch in 1 of your opponent's Benched Pokémon that ha
        'Glittering Star Pattern': (PickPokemonThen(side='opp', action='switch_opp_active', bench_only=True, remaining_hp_at_most=90),),
    },
    'sv7-160': {
        # When you play this Pokémon from your hand to evolve 1 of your Pokémon during your turn, you may heal all damage from each of your Evolution Pokémon. I
        'Time to Chow Down': (HealAllEvolutionsDiscardEnergy(),),
    },
    'sv7-169': {
        # When you play this Pokémon from your hand to evolve 1 of your Pokémon during your turn, you may heal all damage from each of your Evolution Pokémon. I
        'Time to Chow Down': (HealAllEvolutionsDiscardEnergy(),),
    },
    'sv7-3': {
        # When you play this Pokémon from your hand to evolve 1 of your Pokémon during your turn, you may switch in 1 of your opponent's Benched Pokémon that ha
        'Glittering Star Pattern': (PickPokemonThen(side='opp', action='switch_opp_active', bench_only=True, remaining_hp_at_most=90),),
    },
    'sv7-67': {
        # When you play this Pokémon from your hand to evolve 1 of your Pokémon during your turn, you may heal all damage from each of your Evolution Pokémon. I
        'Time to Chow Down': (HealAllEvolutionsDiscardEnergy(),),
    },
    'sv8-130': {
        # When you play this Pokémon from your hand to evolve 1 of your Pokémon during your turn, you may attach up to 2 Basic Metal Energy cards from your disc
        'Assemble Alloy': (AttachEnergyGeneric(source='discard', count=2, basic_only=True, energy_type='Metal', target_type='Metal', optional=True),),
    },
    'sv8-224': {
        # When you play this Pokémon from your hand to evolve 1 of your Pokémon during your turn, you may attach up to 2 Basic Metal Energy cards from your disc
        'Assemble Alloy': (AttachEnergyGeneric(source='discard', count=2, basic_only=True, energy_type='Metal', target_type='Metal', optional=True),),
    },
    'sv8-241': {
        # When you play this Pokémon from your hand to evolve 1 of your Pokémon during your turn, you may attach up to 2 Basic Metal Energy cards from your disc
        'Assemble Alloy': (AttachEnergyGeneric(source='discard', count=2, basic_only=True, energy_type='Metal', target_type='Metal', optional=True),),
    },
    'sv9-164': {
        # When you play this Pokémon from your hand to evolve 1 of your Pokémon during your turn, you may have your opponent reveal their hand and you put any n
        'Inviting Wink': (PutOpponentHandBasicsOnTheirBench(),),
    },
    'sv9-166': {
        # When you play this Pokémon from your hand to evolve 1 of your Pokémon during your turn, you may attach up to 2 Spiky Energy cards from your discard pi
        'Spike-Clad': (AttachDiscardCardsToSelf(names=('Spiky Energy',), count=2),),
    },
    'sv9-67': {
        # When you play this Pokémon from your hand to evolve 1 of your Pokémon during your turn, you may have your opponent reveal their hand and you put any n
        'Inviting Wink': (PutOpponentHandBasicsOnTheirBench(),),
    },
    'sv9-85': {
        # When you play this Pokémon from your hand to evolve 1 of your Pokémon during your turn, you may attach up to 2 Spiky Energy cards from your discard pi
        'Spike-Clad': (AttachDiscardCardsToSelf(names=('Spiky Energy',), count=2),),
    },
    'svp-133': {
        # When you play this Pokémon from your hand to evolve 1 of your Pokémon during your turn, you may switch in 1 of your opponent's Benched Pokémon that ha
        'Glittering Star Pattern': (PickPokemonThen(side='opp', action='switch_opp_active', bench_only=True, remaining_hp_at_most=90),),
    },
    'svp-183': {
        # When you play this Pokémon from your hand to evolve 1 of your Pokémon during your turn, you may have your opponent reveal their hand and you put any n
        'Inviting Wink': (PutOpponentHandBasicsOnTheirBench(),),
    },
    'svp-196': {
        # When you play this Pokémon from your hand to evolve 1 of your Pokémon during your turn, you may search your deck for up to 3 Basic Fire Energy cards a
        'Infernal Reign': (AttachEnergyGeneric(source='deck', count=3, basic_only=True, energy_type='Fire', optional=True),),
    },
    'svp-22': {
        # When you play this Pokémon from your hand to evolve 1 of your Pokémon during your turn, you may choose 1: put a Supporter card from your discard pile 
        'Hearsay': (ChooseOneEffectBranch(labels=('トラッシュのサポートを手札に加える', '山札のサポートを手札に加える'), branches=((SearchDiscardForSupporterToHand(),), (SearchDeckMultiCriteria(('supporter',)),))),),
    },
    'svp-56': {
        # When you play this Pokémon from your hand to evolve 1 of your Pokémon during your turn, you may search your deck for up to 3 Basic Fire Energy cards a
        'Infernal Reign': (AttachEnergyGeneric(source='deck', count=3, basic_only=True, energy_type='Fire', optional=True),),
    },
    'svp-74': {
        # When you play this Pokémon from your hand to evolve 1 of your Pokémon during your turn, you may search your deck for up to 3 Basic Fire Energy cards a
        'Infernal Reign': (AttachEnergyGeneric(source='deck', count=3, basic_only=True, energy_type='Fire', optional=True),),
    },
    'swsh1-119': {
        # When you play this Pokémon from your hand to evolve 1 of your Pokémon during your turn, you may put 3 damage counters on 1 of your opponent's Pokémon.
        'Untamed Shout': (DamageCounterOnChosenOpponentPokemon(count=3),),
    },
    'swsh10-56': {
        # When you play this Pokémon from your hand to evolve 1 of your Pokémon during your turn, you may heal 30 damage from your Active Pokémon.
        'Voice of Happiness': (HealOwnActiveFixed(30),),
    },
    'swsh10-57': {
        # When you play this Pokémon from your hand to evolve 1 of your Pokémon during your turn, you may heal 90 damage from your Active Pokémon.
        'Shine of Happiness': (HealOwnActiveFixed(90),),
    },
    'swsh10tg-TG10': {
        # When you play this Pokémon from your hand to evolve 1 of your Pokémon during your turn, you may put 3 damage counters on 1 of your opponent's Pokémon.
        'Untamed Shout': (DamageCounterOnChosenOpponentPokemon(count=3),),
    },
    'swsh11-26': {
        # When you play this Pokémon from your hand to evolve 1 of your Pokémon during your turn, you may discard the top 3 cards of your opponent's deck.
        'Mountain Roasting': (DiscardTopOfOpponentDeck(3),),
    },
    'swsh11-5': {
        # When you play this Pokémon from your hand to evolve 1 of your Pokémon during your turn, you may make both Active Pokémon Asleep and Poisoned.
        'Lethargy Spores': (InflictStatusOnBothActive(('asleep', 'poisoned')),),
    },
    'swsh11-60': {
        # When you play this Pokémon from your hand to evolve 1 of your Pokémon during your turn, you may flip a coin. If heads, your opponent's Active Pokémon 
        'Ad Hoc Shock': (FlipCoinThen(heads=(InflictStatusOnDefender('paralyzed'),), tails=()),),
    },
    'swsh11tg-TG01': {
        # When you play this Pokémon from your hand to evolve 1 of your Pokémon during your turn, you may make both Active Pokémon Asleep and Poisoned.
        'Lethargy Spores': (InflictStatusOnBothActive(('asleep', 'poisoned')),),
    },
    'swsh11tg-TG04': {
        # When you play this Pokémon from your hand to evolve 1 of your Pokémon during your turn, you may discard the top 3 cards of your opponent's deck.
        'Mountain Roasting': (DiscardTopOfOpponentDeck(3),),
    },
    'swsh12-125': {
        # When you play this Pokémon from your hand to evolve 1 of your Pokémon during your turn, you may search your deck for up to 3 basic Energy cards and at
        'Triple Gears': (SearchDeckForBasicEnergyAttachFreely(count=3),),
    },
    'swsh12-82': {
        # When you play this Pokémon from your hand to evolve 1 of your Pokémon during your turn, you may search your deck for up to 2 Supporter cards, reveal t
        'Inviting Ears': (SearchDeckByCriterionToHand('supporter', count=2),),
    },
    'swsh12pt5-48': {
        # When you play this Pokémon from your hand to evolve 1 of your Pokémon during your turn, you may flip a coin. If heads, your opponent's Active Pokémon 
        'Ad Hoc Shock': (FlipCoinThen(heads=(InflictStatusOnDefender('paralyzed'),), tails=()),),
    },
    'swsh3-103': {
        # When you play this Pokémon from your hand to evolve 1 of your Pokémon during your turn, you may switch 1 of your opponent's Benched Evolution Pokémon 
        'Spider Net': (PickPokemonThen(side='opp', action='switch_opp_active', bench_only=True, evolved_only=True),),
    },
    'swsh4-14': {
        # When you play this Pokémon from your hand to evolve 1 of your Pokémon, you may search your deck for Shedinja and put it onto your Bench. Shuffle your 
        'Cast-off Shell': (SearchDeckForNamedPokemonToBench(name='Shedinja', count=1),),
    },
    'swsh4-198': {
        # When you play this Pokémon from your hand to evolve 1 of your Pokémon during your turn, you may put 3 damage counters on 1 of your opponent's Pokémon.
        'Untamed Shout': (DamageCounterOnChosenOpponentPokemon(count=3),),
    },
    'swsh4-52': {
        # When you play this Pokémon from your hand to evolve 1 of your Pokémon during your turn, you may draw 3 cards.
        'High Speed': (Draw(3),),
    },
    'swsh4-81': {
        # When you play this Pokémon from your hand to evolve 1 of your Pokémon during your turn, you may have each player draw a card.
        'Sharing Sweets': (Draw(1), OpponentDraws(1),),
    },
    'swsh45sv-SV026': {
        # When you play this Pokémon from your hand to evolve 1 of your Pokémon during your turn, you may search your deck for up to 2 Trainer cards, reveal the
        'Shady Dealings': (SearchDeckByCriterionToHand('trainer', count=2),),
    },
    'swsh45sv-SV027': {
        # When you play this Pokémon from your hand to evolve 1 of your Pokémon during your turn, you may search your deck for up to 2 Trainer cards, reveal the
        'Shady Dealings': (SearchDeckByCriterionToHand('trainer', count=2),),
    },
    'swsh45sv-SV080': {
        # When you play this Pokémon from your hand to evolve 1 of your Pokémon during your turn, you may put 3 damage counters on 1 of your opponent's Pokémon.
        'Untamed Shout': (DamageCounterOnChosenOpponentPokemon(count=3),),
    },
    'swsh5-90': {
        # When you play this Pokémon from your hand to evolve 1 of your Pokémon during your turn, you may draw 2 cards.
        'Discreet Draw': (Draw(2),),
    },
    'swsh5-91': {
        # When you play this Pokémon from your hand to evolve 1 of your Pokémon during your turn, you may draw 3 cards.
        'Drastic Draw': (Draw(3),),
    },
    'swsh6-36': {
        # When you play this Pokémon from your hand to evolve 1 of your Pokémon during your turn, you may attach a Water Energy card from your discard pile to 1
        'Frost Over': (AttachEnergyGeneric(source='discard', count=1, basic_only=True, energy_type='Water', single_target=True),),
    },
    'swsh7-214': {
        # When you play this Pokémon from your hand to evolve 1 of your Pokémon during your turn, you may switch 1 of your opponent's Benched Pokémon with their
        'Dark Signal': (ForceOpponentSwitchChosenBench(),),
    },
    'swsh7-215': {
        # When you play this Pokémon from your hand to evolve 1 of your Pokémon during your turn, you may switch 1 of your opponent's Benched Pokémon with their
        'Dark Signal': (ForceOpponentSwitchChosenBench(),),
    },
    'swsh7-226': {
        # When you play this Pokémon from your hand to evolve 1 of your Pokémon during your turn, you may attach a Water Energy card from your discard pile to 1
        'Frost Over': (AttachEnergyGeneric(source='discard', count=1, basic_only=True, energy_type='Water', single_target=True),),
    },
    'swsh7-95': {
        # When you play this Pokémon from your hand to evolve 1 of your Pokémon during your turn, you may switch 1 of your opponent's Benched Pokémon with their
        'Dark Signal': (ForceOpponentSwitchChosenBench(),),
    },
    'swsh8-116': {
        # When you play this Pokémon from your hand to evolve 1 of your Pokémon during your turn, you may put up to 2 Pokémon Tool cards from your discard pile 
        'Dig Up': (SearchDiscardByCriterionToHand('pokemon_tool', count=2),),
    },
    'swsh9-109': {
        # When you play this Pokémon from your hand to evolve 1 of your Pokémon during your turn, you may prevent all damage from and effects of attacks from yo
        'Sonic Slip': (ApplyShieldToSelf(),),
    },
    'swsh9tg-TG09': {
        # When you play this Pokémon from your hand to evolve 1 of your Pokémon during your turn, you may switch 1 of your opponent's Benched Evolution Pokémon 
        'Spider Net': (PickPokemonThen(side='opp', action='switch_opp_active', bench_only=True, evolved_only=True),),
    },
    'swsh9tg-TG23': {
        # When you play this Pokémon from your hand to evolve 1 of your Pokémon during your turn, you may switch 1 of your opponent's Benched Pokémon with their
        'Dark Signal': (ForceOpponentSwitchChosenBench(),),
    },
    'swshp-SWSH059': {
        # When you play this Pokémon from your hand to evolve 1 of your Pokémon during your turn, you may put 3 damage counters on 1 of your opponent's Pokémon.
        'Untamed Shout': (DamageCounterOnChosenOpponentPokemon(count=3),),
    },
    'swshp-SWSH276': {
        # When you play this Pokémon from your hand to evolve 1 of your Pokémon during your turn, you may heal 30 damage from your Active Pokémon.
        'Voice of Happiness': (HealOwnActiveFixed(30),),
    },
    'xy10-117': {
        # When you play M Alakazam-EX from your hand to evolve this Pokémon, before it evolves, you may put 2 damage counters on your opponent's Active Pokémon 
        'Kinesis': (DamageCounterOnDefender(2), PickPokemonThen(side='opp', action='put_counters', amount=3, bench_only=True),),
    },
    'xy10-125': {
        # When you play M Alakazam-EX from your hand to evolve this Pokémon, before it evolves, you may put 2 damage counters on your opponent's Active Pokémon 
        'Kinesis': (DamageCounterOnDefender(2), PickPokemonThen(side='opp', action='put_counters', amount=3, bench_only=True),),
    },
    'xy10-25': {
        # When you play M Alakazam-EX from your hand to evolve this Pokémon, before it evolves, you may put 2 damage counters on your opponent's Active Pokémon 
        'Kinesis': (DamageCounterOnDefender(2), PickPokemonThen(side='opp', action='put_counters', amount=3, bench_only=True),),
    },
    'xy10-56': {
        # When you play this Pokémon from your hand to evolve 1 of your Pokémon, you may attach 1 Darkness Energy from your discard pile to this Pokémon for eac
        'Raging Roar': (AttachDiscardEnergyToSelfPerOpponentPrizeTaken('Darkness'),),
    },
    'xy10-6': {
        # When you play this Pokémon from your hand to evolve 1 of your Pokémon, you may flip a coin. If heads, your opponent's Active Pokémon is now Paralyzed.
        'Serpentine Strangle': (FlipCoinThen(heads=(InflictStatusOnDefender('paralyzed'),), tails=()),),
    },
    'xy2-60': {
        # When you play this Pokémon from your hand to evolve 1 of your Pokémon, you may put 1 damage counter on each of your opponent's Pokémon.
        'Thorn Tempest': (DamageCountersOnEachOpponentPokemon(1),),
    },
    'xy5-44': {
        # When you play this Pokémon from your hand to evolve 1 of your Pokémon, you may put a card from your discard pile into your hand.
        'Sparkling Ripples': (SearchDiscardAnyCardToHand(count=1),),
    },
    'xy5-92': {
        # When you play this Pokémon from your hand to evolve 1 of your Pokémon, you may discard an Energy attached to your opponent's Active Pokémon.
        'Unruly Claw': (DiscardOpponentActiveEnergy(),),
    },
    'xy6-46': {
        # When you play this Pokémon from your hand to evolve 1 of your Pokémon, you may look at the top 8 cards of your deck. Choose any basic Energy cards you
        'Serene Grace': (AttachEnergyGeneric(source='deck', count=99, basic_only=True, optional=True, deck_limit=8),),
    },
    'xy6-51': {
        # When you play this Pokémon from your hand to evolve 1 of your Pokémon, you may heal all damage from 1 of your Pokémon.
        'Max Wind': (PickPokemonThen(action='heal', full=True, damaged_only=True),),
    },
    'xy8-59': {
        # When you play this Pokémon from your hand to evolve 1 of your Pokémon, you may leave both Active Pokémon Confused.
        'Gothic Fear': (InflictStatusOnDefender('confused'), InflictStatusOnOwnActive('confused'),),
    },
    'xy8-66': {
        # When you play this Pokémon from your hand to evolve 1 of your Pokémon, you may have your opponent shuffle his or her hand into his or her deck and dra
        'Twisted Incantation': (OpponentShuffleHandDrawByPrizes(),),
    },
    'xyp-XY130': {
        # When you play this Pokémon from your hand to evolve 1 of your Pokémon, you may attach 1 Darkness Energy from your discard pile to this Pokémon for eac
        'Raging Roar': (AttachDiscardEnergyToSelfPerOpponentPrizeTaken('Darkness'),),
    },
    'xyp-XY24': {
        # When you play this Pokémon from your hand to evolve 1 of your Pokémon, you may prevent all effects of attacks, including damage, done to this Pokémon 
        'Mist Concealment': (ApplyShieldToSelf(),),
    },
}

GENERATED_ENERGY_ATTACH_TRIGGER_EFFECTS: dict[str, dict] = {
    'bw10-97': {
        # When you attach a Plasma Energy from your hand to this Pokémon, you may switch 1 of your opponent's Benched Pokémon with his or her Active Pokémon.
        'Red Signal': (TriggerGateAttachedEnergyNamed('Plasma Energy'), PickPokemonThen(side='opp', action='switch_opp_active', bench_only=True),),
    },
    'xy3-80': {
        # When you attach a basic Energy card from your hand to this Pokémon, you may search your deck for a card that evolves from this Pokémon that is the sam
        'Energy Evolution': (InstantEvolveSelfFromDeck(allow_just_played=True),),
    },
    'xy4-115': {
        # When you attach an Energy from your hand to this Pokémon, you may use this Ability. Your opponent's Active Pokémon is now Asleep.
        'Hyper Hypnosis': (InflictStatusOnDefender('asleep'),),
    },
    'xy7-58': {
        # Whenever you attach a Water Energy card from your hand to this Pokémon, you may search your deck for Goomy and put it onto your Bench. Shuffle your de
        'Water Down': (TriggerGateAttachedEnergyNamed('Water Energy'), SearchDeckForNamedPokemonToBench(name='Goomy', count=1),),
    },
}

GENERATED_BECOME_ACTIVE_TRIGGER_EFFECTS: dict[str, dict] = {
    'me4-103': {
        # Once during your turn, when this Pokémon moves from your Bench to the Active Spot, you may use this Ability. Move any amount of Metal Energy from your
        'Metal Road': (MoveEnergyGeneric(owner='own', sources='any', dests='self', energy_type='Metal', freely=True),),
    },
    'me4-64': {
        # Once during your turn, when this Pokémon moves from your Bench to the Active Spot, you may use this Ability. Move any amount of Metal Energy from your
        'Metal Road': (MoveEnergyGeneric(owner='own', sources='any', dests='self', energy_type='Metal', freely=True),),
    },
    'xy12-18': {
        # Once during your turn (before your attack), if this Pokémon was on the Bench and became your Active Pokémon this turn, you may move any number of Fire
        'Burning Road': (MoveChosenOwnFireEnergyToSelf(),),
    },
}

GENERATED_MANDATORY_ENERGY_ATTACH_TRIGGER_EFFECTS: dict[str, dict] = {
    'sm75-5': {
        # Whenever you attach an Energy card from your hand to this Pokémon, remove all Special Conditions from it.
        'Natural Cure': (ClearActiveStatusConditions(),),
    },
    'swsh12tg-TG22': {
        # Whenever you attach an Energy card from your hand to this Pokémon, remove all Special Conditions from it.
        'Natural Cure': (ClearActiveStatusConditions(),),
    },
    'swsh4-32': {
        # Whenever you attach an Energy card from your hand to this Pokémon, remove all Special Conditions from it.
        'Water Veil': (ClearOwnStatusConditions(),),
    },
    'swsh6-119': {
        # Whenever you attach an Energy card from your hand to this Pokémon, remove all Special Conditions from it.
        'Natural Cure': (ClearActiveStatusConditions(),),
    },
    'swsh6-182': {
        # Whenever you attach an Energy card from your hand to this Pokémon, remove all Special Conditions from it.
        'Natural Cure': (ClearActiveStatusConditions(),),
    },
    'swsh6-183': {
        # Whenever you attach an Energy card from your hand to this Pokémon, remove all Special Conditions from it.
        'Natural Cure': (ClearActiveStatusConditions(),),
    },
    'xy5-147': {
        # Whenever you attach an Energy card from your hand to this Pokémon, remove all Special Conditions from it.
        'Water Veil': (ClearOwnStatusConditions(),),
    },
}

GENERATED_DISCARD_ABILITY_EFFECTS: dict[str, dict] = {
    'bw10-102': {
        # Once during your turn (before your attack), if this Pokémon is in your discard pile, you may put this Pokémon into your hand.
        'Propagation': (DiscardAbilityDestination('hand'),),
    },
    'bw10-27': {
        # Once during your turn (before your attack), if this Pokémon is in your discard pile, you may put this Pokémon on the bottom of your deck.
        'Prehistoric Call': (DiscardAbilityDestination('deck_bottom'),),
    },
    'bw10-3': {
        # Once during your turn (before your attack), if this Pokémon is in your discard pile, you may put this Pokémon on the bottom of your deck.
        'Prehistoric Call': (DiscardAbilityDestination('deck_bottom'),),
    },
    'bw10-53': {
        # Once during your turn (before your attack), if this Pokémon is in your discard pile, you may put this Pokémon on the bottom of your deck.
        'Prehistoric Call': (DiscardAbilityDestination('deck_bottom'),),
    },
    'bw6-119': {
        # Once during your turn (before your attack), if this Pokémon is in your discard pile, you may flip a coin. If heads, put this Pokémon onto your Bench a
        'Rebirth': (DiscardAbilityDestination('coin_bench'), AttachEnergyGeneric(source='discard', count=3, basic_only=True, self_only=True, distinct_energy_types=True),),
    },
    'bw6-22': {
        # Once during your turn (before your attack), if this Pokémon is in your discard pile, you may flip a coin. If heads, put this Pokémon onto your Bench a
        'Rebirth': (DiscardAbilityDestination('coin_bench'), AttachEnergyGeneric(source='discard', count=3, basic_only=True, self_only=True, distinct_energy_types=True),),
    },
}

GENERATED_UNLIMITED_ABILITY_IDS: frozenset[str] = frozenset({
    'bw1-20',
    'bw1-57',
    'bw1-76',
    'bw10-104',
    'bw10-2',
    'bw10-74',
    'bw11-27',
    'bw11-99',
    'bw4-100',
    'bw6-126',
    'bw6-97',
    'bw7-31',
    'bw7-63',
    'bw8-137',
    'bwp-BW21',
    'bwp-BW84',
    'me2-110',
    'me2-18',
    'me2pt5-279',
    'me2pt5-70',
    'me2pt5-84',
    'me3-19',
    'sm1-141',
    'sm1-153',
    'sm1-66',
    'sm10-157',
    'sm11-132',
    'sm12-72',
    'sm5-172',
    'sm5-83',
    'sm6-36',
    'sm75-26',
    'sma-SV10',
    'sma-SV29',
    'smp-SM17',
    'sv1-203',
    'sv1-228',
    'sv1-245',
    'sv1-41',
    'sv1-43',
    'sv10-198',
    'sv10-89',
    'sv2-210',
    'sv2-60',
    'sv4pt5-115',
    'sv4pt5-117',
    'sv4pt5-130',
    'sv4pt5-15',
    'sv4pt5-217',
    'sv4pt5-233',
    'sv4pt5-29',
    'sv9-172',
    'sv9-183',
    'sv9-188',
    'sv9-53',
    'svp-19',
    'svp-194',
    'swsh1-64',
    'swsh1-85',
    'swsh10tg-TG04',
    'swsh10tg-TG11',
    'swsh12-179',
    'swsh12-90',
    'swsh2-204',
    'swsh3-110',
    'swsh45-30',
    'swsh45sv-SV034',
    'swsh5-102',
    'swsh5-8',
    'swsh6-223',
    'swshp-SWSH007',
    'swshp-SWSH037',
    'swshp-SWSH052',
    'swshp-SWSH088',
    'swshp-SWSH091',
    'xy10-4',
    'xy11-61',
    'xy2-40',
    'xy2-74',
    'xy5-65',
    'xy8-54',
    'xy9-18',
})
