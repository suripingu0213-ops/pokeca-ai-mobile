"""時代ごとのカード取り込み(2026-10-07〜)で追加した効果プリミティブその6(XY4〜XY12のワザ)。

effects/era_primitives*.py と同じ規約(frozen dataclassのEffect、execute(ctx)、ダメージは必ずDealDamageを1回だけ経由する)。
条件は effects.era_primitives.EXTRA_CONDITIONS に登録し、ConditionalBonusDamage/IfCondition/DamageIfConditionから使う。
"""

from __future__ import annotations

from dataclasses import dataclass

from cards.card_db import card_has_subtype
from effects import era_primitives as _ep
from effects.context import EffectContext
from effects.primitives import (
    DealDamage,
    Effect,
    _attacker_player,
    _blocks_damage_counters,
    _defender,
    _defender_blocks_effect,
)
from engine.state import PendingSearchChoice


# ---------------------------------------------------------------------------------------------
# 共通の小さな補助
# ---------------------------------------------------------------------------------------------
def scope_matches_attacker(scope: str, attacker_card) -> bool:
    """「◯◯ポケモンによるワザ」の対象種別に、攻撃してきたポケモンが当てはまるか。"""
    if attacker_card is None:
        return False
    if scope == "ex":
        return "EX" in attacker_card.subtypes
    if scope == "dragon":
        return "Dragon" in attacker_card.types
    if scope == "basic":
        return attacker_card.is_basic
    if scope == "evolution":
        return not attacker_card.is_basic
    return False


def put_counters(ctx: EffectContext, mon, count: int) -> bool:
    """相手のポケモンにダメカンをのせる(ワザの効果を防ぐ・ダメカン付与を防ぐ効果があればのせない)。のせたらTrue。"""
    if _defender_blocks_effect(ctx, mon) or _blocks_damage_counters(mon):
        return False
    mon.damage += 10 * count
    return True


# ---------------------------------------------------------------------------------------------
# 条件
# ---------------------------------------------------------------------------------------------
def _cond_defender_confused(ctx, arg, player, opponent, self_mon, defender) -> bool:
    from engine.status import ExclusiveCondition

    return defender is not None and defender.status.exclusive == ExclusiveCondition.CONFUSED


def _cond_defender_type_any(ctx, arg, player, opponent, self_mon, defender) -> bool:
    card = ctx.card_db.get(defender.card_id) if defender is not None else None
    return card is not None and any(t in card.types for t in arg.split(","))


def _cond_same_bench_count(ctx, arg, player, opponent, self_mon, defender) -> bool:
    return len(player.bench) == len(opponent.bench)


def _cond_self_damage_counters_at_least(ctx, arg, player, opponent, self_mon, defender) -> bool:
    return self_mon is not None and self_mon.damage // 10 >= int(arg)


def _cond_self_healed_this_turn(ctx, arg, player, opponent, self_mon, defender) -> bool:
    return self_mon is not None and bool(self_mon.__dict__.get("healed_this_turn"))


def _cond_own_bench_subtype(ctx, arg, player, opponent, self_mon, defender) -> bool:
    return any((c := ctx.card_db.get(m.card_id)) is not None and (arg in c.subtypes) for m in player.bench)


def _cond_opponent_in_play_subtype(ctx, arg, player, opponent, self_mon, defender) -> bool:
    return any((c := ctx.card_db.get(m.card_id)) is not None and (arg in c.subtypes) for m in opponent.all_pokemon_in_play())


def _cond_self_more_hp(ctx, arg, player, opponent, self_mon, defender) -> bool:
    """相手のバトルポケモンの残りHPが、このポケモンの残りHPより少ない(「ダメージを与える前に」の比較)。"""
    if self_mon is None or defender is None:
        return False
    return _ep._remaining_hp(ctx, defender) < _ep._remaining_hp(ctx, self_mon)


def _cond_self_more_prizes_left(ctx, arg, player, opponent, self_mon, defender) -> bool:
    return len(player.prizes) > len(opponent.prizes)


def _cond_evolved_from_named_this_turn(ctx, arg, player, opponent, self_mon, defender) -> bool:
    return (
        self_mon is not None
        and self_mon.turn_played == player.turns_taken
        and bool(self_mon.evolution_history)
        and (c := ctx.card_db.get(self_mon.evolution_history[-1])) is not None
        and c.name == arg
    )


_ep.EXTRA_CONDITIONS.update({
    "defender_confused": _cond_defender_confused,
    "defender_type_any": _cond_defender_type_any,
    "same_bench_count": _cond_same_bench_count,
    "self_damage_counters_at_least": _cond_self_damage_counters_at_least,
    "self_healed_this_turn": _cond_self_healed_this_turn,
    "own_bench_subtype": _cond_own_bench_subtype,
    "opponent_in_play_subtype": _cond_opponent_in_play_subtype,
    "self_more_hp": _cond_self_more_hp,
    "self_more_prizes_left": _cond_self_more_prizes_left,
    "evolved_from_named_this_turn": _cond_evolved_from_named_this_turn,
})


# ---------------------------------------------------------------------------------------------
# ダメージ
# ---------------------------------------------------------------------------------------------
@dataclass(frozen=True)
class BonusDamagePerOwnPrizesRemaining(Effect):
    """基本ダメージに、自分の残りサイド1枚につきperを加える(Piercing Prizes)。"""

    base: int
    per: int

    def execute(self, ctx: EffectContext) -> None:
        DealDamage(self.base + self.per * len(_attacker_player(ctx).prizes)).execute(ctx)


@dataclass(frozen=True)
class BonusDamagePerOwnHandCount(Effect):
    """基本ダメージに、自分の手札1枚につきperを加える(Machine Gun Stomp)。"""

    base: int
    per: int

    def execute(self, ctx: EffectContext) -> None:
        DealDamage(self.base + self.per * len(_attacker_player(ctx).hand)).execute(ctx)


@dataclass(frozen=True)
class FlipCoinsDiscardDefenderEnergyOrNothing(Effect):
    """コインをcoins枚投げ、オモテ1枚につき相手のバトルポケモンのエネルギーを1枚トラッシュする。全てウラならこのワザは何もしない(Twister)。"""

    base: int
    coins: int

    def execute(self, ctx: EffectContext) -> None:
        heads = sum(1 for _ in range(self.coins) if ctx.rng.random() < 0.5)
        ctx.coin_heads_count = heads
        ctx.log(f"コイン{self.coins}枚: オモテ{heads}枚")
        if heads == 0:
            return
        DealDamage(self.base).execute(ctx)
        _, defender = _defender(ctx)
        if defender is None or _defender_blocks_effect(ctx, defender):
            return
        opponent = ctx.state.player(ctx.opponent)
        for _ in range(heads):
            if not defender.attached_energy:
                break
            opponent.discard.append(defender.attached_energy.pop())  # 種類は選べる実カードだが、ここでは最後についたものから外す
        ctx.log(f"相手のバトルポケモンのエネルギーを最大{heads}枚トラッシュした")


@dataclass(frozen=True)
class DamageCountersOnEachOpponentBenchedPokemon(Effect):
    """相手のベンチポケモン全員にダメカンをcount個ずつのせる(Sinister Fog)。"""

    count: int

    def execute(self, ctx: EffectContext) -> None:
        for mon in ctx.state.player(ctx.opponent).bench:
            put_counters(ctx, mon, self.count)


# ---------------------------------------------------------------------------------------------
# 状態・効果
# ---------------------------------------------------------------------------------------------
@dataclass(frozen=True)
class ApplyScopedShieldToSelf(Effect):
    """相手の次の番、このポケモンは、指定した種類(ポケモンEX/ドラゴン等)のポケモンのワザの効果(ダメージを含む)を受けない
    (Resistance Desert/Moon Barrier)。"""

    scope: str

    def execute(self, ctx: EffectContext) -> None:
        if ctx.source_pokemon is None:
            return
        ctx.source_pokemon.shield_scope = self.scope
        ctx.source_pokemon.shield_scope_until_turn = ctx.state.player(ctx.opponent).turns_taken + 1


@dataclass(frozen=True)
class InflictStatusesOnBothActive(Effect):
    """おたがいのバトルポケモンに、指定した特殊状態をそれぞれ与える(Thick Liquid: こんらんとどく)。"""

    conditions: tuple

    def execute(self, ctx: EffectContext) -> None:
        from effects.primitives import InflictStatusOnDefender, InflictStatusOnSelf

        for condition in self.conditions:
            InflictStatusOnDefender(condition).execute(ctx)
            InflictStatusOnSelf(condition).execute(ctx)


# ---------------------------------------------------------------------------------------------
# 手札・山札
# ---------------------------------------------------------------------------------------------
@dataclass(frozen=True)
class PutHandCardOnBottomOfDeck(Effect):
    """手札のカード1枚を選んで、山札の一番下に置く(Hide a Berry)。"""

    def execute(self, ctx: EffectContext) -> None:
        player = _attacker_player(ctx)
        if not player.hand:
            return
        ctx.state.pending_search_choice = PendingSearchChoice(
            player_index=ctx.acting_player,
            zone="hand",
            source_indices=list(range(len(player.hand))),
            card_ids=list(player.hand),
            min_count=1,
            max_count=1,
            prompt="山札の一番下に置く手札を選ぶ",
            shuffle_after=False,
            all_card_ids=list(player.hand),
            destination="deck_bottom",
            effect_source=ctx.effect_source,
            then_end_turn=False,
        )


# ---------------------------------------------------------------------------------------------
# パート2: ダメージ・場の効果(XY4〜XY12)
# ---------------------------------------------------------------------------------------------
def _opp_slots(opponent):
    return ([(0, opponent.active)] if opponent.active is not None else []) + [(i + 1, m) for i, m in enumerate(opponent.bench)]


def _own_slots(player):
    return ([(0, player.active)] if player.active is not None else []) + [(i + 1, m) for i, m in enumerate(player.bench)]


def _hit(ctx: EffectContext, mon, amount: int, apply_wr: bool) -> int:
    """相手のポケモン1匹に固定ダメージ(シールド・ダメージ軽減・ベンチバリア等を通す。apply_wr=Falseなら弱点・抵抗力は計算しない)。"""
    from effects.primitives import _defender_is_shielded, resolve_attack_damage

    if _defender_is_shielded(ctx, mon):
        return 0
    card = ctx.card_db.get(mon.card_id)
    if card is None:
        return 0
    dmg = resolve_attack_damage(ctx, mon, card, amount, apply_weakness=apply_wr, apply_resistance=apply_wr)
    mon.damage += dmg
    ctx.damage_dealt += dmg
    return dmg


def _basic_energy_of(card_db, card_id: str):
    card = card_db.get(card_id)
    return card.basic_energy_type if card is not None and card.is_energy and not card.is_special_energy else None


@dataclass(frozen=True)
class DealFixedDamageToDamagedOpponentBench(Effect):
    """ダメカンがのっている相手のベンチポケモン全員に固定ダメージ(Boulder Storm)。弱点・抵抗力は計算しない。"""

    amount: int

    def execute(self, ctx: EffectContext) -> None:
        for mon in list(ctx.state.player(ctx.opponent).bench):
            if mon.damage > 0:
                _hit(ctx, mon, self.amount, False)


@dataclass(frozen=True)
class DealFixedDamageToOpponentBenchedWithSubtype(Effect):
    """サブタイプ(EX/Basic等)を持つ相手のベンチポケモン全員に固定ダメージ(Tidal Storm/Tail Swing)。弱点・抵抗力は計算しない。"""

    amount: int
    subtype: str

    def execute(self, ctx: EffectContext) -> None:
        for mon in list(ctx.state.player(ctx.opponent).bench):
            card = ctx.card_db.get(mon.card_id)
            if card_has_subtype(card, self.subtype):
                _hit(ctx, mon, self.amount, False)


@dataclass(frozen=True)
class DealFixedDamageToOpponentPokemonWithSubtype(Effect):
    """サブタイプ(EX/BREAK等)を持つ相手のポケモン(バトル場+ベンチ)全員に固定ダメージ。ベンチには弱点・抵抗力を計算しない
    (Break Star/Thunderclap Shot)。"""

    amount: int
    subtype: str

    def execute(self, ctx: EffectContext) -> None:
        opponent = ctx.state.player(ctx.opponent)
        for slot, mon in _opp_slots(opponent):
            card = ctx.card_db.get(mon.card_id)
            if card_has_subtype(card, self.subtype):
                _hit(ctx, mon, self.amount, slot == 0)


@dataclass(frozen=True)
class DamageCountersOnEachOpponentPokemonWithEnergy(Effect):
    """エネルギーがついている相手のポケモン全員に、ダメカンをcount個ずつのせる(Suppression)。"""

    count: int

    def execute(self, ctx: EffectContext) -> None:
        for _slot, mon in _opp_slots(ctx.state.player(ctx.opponent)):
            if mon.attached_energy:
                put_counters(ctx, mon, self.count)


@dataclass(frozen=True)
class ForceOpponentSwitchChosenBenchThenDamage(Effect):
    """相手のバトルポケモンを、選んだベンチポケモンと入れ替え、新しいバトルポケモンにamountダメージ(Hunt)。"""

    amount: int
    attack_target = "opp_bench"

    def execute(self, ctx: EffectContext) -> None:
        from effects.primitives import ForceOpponentSwitchChosenBench

        opponent = ctx.state.player(ctx.opponent)
        before = opponent.active
        ForceOpponentSwitchChosenBench().execute(ctx)
        if opponent.active is not before or not opponent.bench:
            DealDamage(self.amount).execute(ctx)


@dataclass(frozen=True)
class KnockOutDefenderIfDamageCountersAtLeast(Effect):
    """相手のバトルポケモンにダメカンがcounters個以上のっていれば、そのポケモンをきぜつさせる(Creep Show)。"""

    counters: int

    def execute(self, ctx: EffectContext) -> None:
        _, defender = _defender(ctx)
        if defender is None or defender.damage < 10 * self.counters or _defender_blocks_effect(ctx, defender):
            return
        defender.damage = 9999
        ctx.log("相手のバトルポケモンをきぜつさせた")


@dataclass(frozen=True)
class DamageThenKnockOutIfHpAtMost(Effect):
    """ダメージを与えた結果、相手のバトルポケモンの残りHPがhp以下なら、そのポケモンをきぜつさせる(Ultimate Blade)。"""

    base: int
    hp: int

    def execute(self, ctx: EffectContext) -> None:
        DealDamage(self.base).execute(ctx)
        _, defender = _defender(ctx)
        if defender is None or _defender_blocks_effect(ctx, defender):
            return
        card = ctx.card_db.get(defender.card_id)
        from engine.continuous import effective_max_hp

        max_hp = effective_max_hp(ctx.card_db, defender.card_id, defender.attached_tool, ctx.state.stadium_in_play, defender.attached_energy)
        if card is not None and max_hp - defender.damage <= self.hp:
            defender.damage = 9999
            ctx.log("残りHPが少なくなったので、相手のバトルポケモンはきぜつした")


@dataclass(frozen=True)
class BonusPrizeIfThisAttackKnockedOutOpponentSubtype(Effect):
    """このワザのダメージで、指定サブタイプ(MEGA等)の相手のバトルポケモンをきぜつさせたら、追加でサイドをbonus枚多く取る(Endgame)。"""

    bonus: int
    subtype: str

    def execute(self, ctx: EffectContext) -> None:
        _, defender = _defender(ctx)
        card = ctx.card_db.get(defender.card_id) if defender is not None else None
        if defender is None or not card_has_subtype(card, self.subtype):
            return
        from engine.continuous import effective_max_hp

        max_hp = effective_max_hp(ctx.card_db, defender.card_id, defender.attached_tool, ctx.state.stadium_in_play, defender.attached_energy)
        if defender.damage >= max_hp:
            _attacker_player(ctx).bonus_prize_next_knockout += self.bonus


@dataclass(frozen=True)
class BonusIfSelfSpecialEnergyThenHealAll(Effect):
    """このポケモンに特殊エネルギーがついていれば、追加ダメージを与え、自分の全てのポケモンのダメージをhealぶん回復する(Mist Purge)。"""

    base: int
    bonus: int
    heal: int

    def execute(self, ctx: EffectContext) -> None:
        mon = ctx.source_pokemon
        has = mon is not None and any((c := ctx.card_db.get(e)) is not None and c.is_special_energy for e in mon.attached_energy)
        DealDamage(self.base + (self.bonus if has else 0)).execute(ctx)
        if has:
            for m in _attacker_player(ctx).all_pokemon_in_play():
                m.heal(self.heal)


@dataclass(frozen=True)
class StadiumBonusAndHeal(Effect):
    """自分(このワザを使った側)が出したスタジアムが場にあればbonus追加ダメージ。相手が出したスタジアムなら、このポケモンのダメージをheal回復する(Primordial Boom)。"""

    base: int
    bonus: int
    heal: int

    def execute(self, ctx: EffectContext) -> None:
        state = ctx.state
        mine = state.stadium_in_play is not None and state.stadium_owner == ctx.acting_player
        theirs = state.stadium_in_play is not None and state.stadium_owner == ctx.opponent
        DealDamage(self.base + (self.bonus if mine else 0)).execute(ctx)
        if theirs and ctx.source_pokemon is not None:
            ctx.source_pokemon.heal(self.heal)


@dataclass(frozen=True)
class DamagePerOwnPokemonInPlayOfTypes(Effect):
    """自分の場(バトル場+ベンチ)の、指定タイプのいずれかを持つポケモン1匹につきperダメージ(Bright Garden)。"""

    per: int
    types: tuple

    def execute(self, ctx: EffectContext) -> None:
        n = sum(1 for _s, m in _own_slots(_attacker_player(ctx)) if (c := ctx.card_db.get(m.card_id)) is not None and any(t in c.types for t in self.types))
        DealDamage(self.per * n).execute(ctx)


@dataclass(frozen=True)
class DamagePerOwnBenchedEvolution(Effect):
    """自分のベンチの進化ポケモン1匹につきperを加える(Power Lariat)。"""

    base: int
    per: int

    def execute(self, ctx: EffectContext) -> None:
        n = sum(1 for m in _attacker_player(ctx).bench if (c := ctx.card_db.get(m.card_id)) is not None and c.is_pokemon and not c.is_basic)
        DealDamage(self.base + self.per * n).execute(ctx)


@dataclass(frozen=True)
class DamagePerDistinctTypesOnOwnBench(Effect):
    """自分のベンチにいるポケモンの、異なるタイプ1種類につきperを加える(Rainbow Force)。"""

    base: int
    per: int

    def execute(self, ctx: EffectContext) -> None:
        types = set()
        for m in _attacker_player(ctx).bench:
            c = ctx.card_db.get(m.card_id)
            if c is not None:
                types.update(c.types)
        DealDamage(self.base + self.per * len(types)).execute(ctx)


@dataclass(frozen=True)
class BonusDamagePerPokemonFewerInPlay(Effect):
    """自分の場のポケモンが相手より少なければ、少ない1匹につきperを加える(Fight Alone)。"""

    base: int
    per: int

    def execute(self, ctx: EffectContext) -> None:
        mine = len(_attacker_player(ctx).all_pokemon_in_play())
        theirs = len(ctx.state.player(ctx.opponent).all_pokemon_in_play())
        DealDamage(self.base + self.per * max(0, theirs - mine)).execute(ctx)


@dataclass(frozen=True)
class BonusDamagePerOwnDiscardKind(Effect):
    """自分のトラッシュの、指定の種類(supporter等)のカード1枚につきperを加える(Past Friends)。"""

    base: int
    per: int
    kind: str

    def execute(self, ctx: EffectContext) -> None:
        n = 0
        for cid in _attacker_player(ctx).discard:
            c = ctx.card_db.get(cid)
            if c is not None and ((self.kind == "supporter" and c.is_supporter) or (self.kind == "item" and c.is_item)):
                n += 1
        DealDamage(self.base + self.per * n).execute(ctx)


@dataclass(frozen=True)
class DamagePerItemInBothHands(Effect):
    """おたがいの手札を公開し、公開したグッズ1枚につきperダメージ(High Flight)。"""

    per: int

    def execute(self, ctx: EffectContext) -> None:
        mine = _attacker_player(ctx)
        theirs = ctx.state.player(ctx.opponent)
        mine.known_opponent_hand = list(theirs.hand)
        ctx.reveal("おたがいの手札", list(mine.hand) + list(theirs.hand))
        n = sum(1 for cid in mine.hand + theirs.hand if (c := ctx.card_db.get(cid)) is not None and c.is_item)
        DealDamage(self.per * n).execute(ctx)


@dataclass(frozen=True)
class DamagePerOpponentPokemonOfType(Effect):
    """相手の場の、指定タイプのポケモン1匹につきperダメージ(Shake It Off)。"""

    per: int
    pokemon_type: str

    def execute(self, ctx: EffectContext) -> None:
        n = sum(1 for _s, m in _opp_slots(ctx.state.player(ctx.opponent)) if (c := ctx.card_db.get(m.card_id)) is not None and self.pokemon_type in c.types)
        DealDamage(self.per * n).execute(ctx)


@dataclass(frozen=True)
class BonusDamagePerColorlessRetreatNamed(Effect):
    """自分の場の、指定した名前のポケモンのにげるコストの無色1個につきperを加える(Gathering Footsteps)。"""

    base: int
    per: int
    names: tuple

    def execute(self, ctx: EffectContext) -> None:
        total = 0
        for _s, m in _own_slots(_attacker_player(ctx)):
            c = ctx.card_db.get(m.card_id)
            if c is not None and c.name in self.names:
                total += sum(1 for t in c.retreat_cost if t == "Colorless")
        DealDamage(self.base + self.per * total).execute(ctx)


@dataclass(frozen=True)
class BonusDamageIfNamedOnBenchLadder(Effect):
    """ベンチに指定した名前のポケモンがいれば、それぞれの追加ダメージを足す(Double Link/Link Fusion)。entries=((名前, 追加ダメージ), ...)"""

    base: int
    entries: tuple

    def execute(self, ctx: EffectContext) -> None:
        names = {c.name for m in _attacker_player(ctx).bench if (c := ctx.card_db.get(m.card_id)) is not None}
        DealDamage(self.base + sum(bonus for name, bonus in self.entries if name in names)).execute(ctx)


@dataclass(frozen=True)
class FlipCoinPerOwnSubtypeForDamage(Effect):
    """自分の場の、指定サブタイプ(Team Aqua等)のポケモン1匹につきコインを1回投げ、オモテの数×perダメージ(Teampact)。"""

    per: int
    subtype: str

    def execute(self, ctx: EffectContext) -> None:
        n = sum(1 for _s, m in _own_slots(_attacker_player(ctx)) if (c := ctx.card_db.get(m.card_id)) is not None and self.subtype in c.subtypes)
        heads = sum(1 for _ in range(n) if ctx.rng.random() < 0.5)
        ctx.coin_heads_count = heads
        ctx.log(f"コイン{n}枚: オモテ{heads}枚")
        DealDamage(self.per * heads).execute(ctx)


@dataclass(frozen=True)
class DiscardOwnTopBonusIfEnergy(Effect):
    """自分の山札の上を1枚トラッシュし、それがエネルギーカードなら追加ダメージ(Mini Eruption)。"""

    base: int
    bonus: int

    def execute(self, ctx: EffectContext) -> None:
        player = _attacker_player(ctx)
        extra = 0
        if player.deck:
            cid = player.deck.pop(0)
            player.discard.append(cid)
            c = ctx.card_db.get(cid)
            ctx.log(f"山札の上の{cid}をトラッシュ")
            if c is not None and c.is_energy:
                extra = self.bonus
        DealDamage(self.base + extra).execute(ctx)


@dataclass(frozen=True)
class DiscardOpponentTopBonusIfKind(Effect):
    """相手の山札の上を1枚トラッシュし、それがエネルギーカード(kind="energy")なら追加ダメージ(Furry Chance)。"""

    base: int
    bonus: int
    kind: str = "energy"

    def execute(self, ctx: EffectContext) -> None:
        opponent = ctx.state.player(ctx.opponent)
        extra = 0
        if opponent.deck:
            cid = opponent.deck.pop(0)
            opponent.discard.append(cid)
            c = ctx.card_db.get(cid)
            ctx.log(f"相手の山札の上の{cid}をトラッシュ")
            if c is not None and c.is_energy:
                extra = self.bonus
        DealDamage(self.base + extra).execute(ctx)


@dataclass(frozen=True)
class DiscardTopNDamagePerEnergyCard(Effect):
    """自分の山札の上からn枚をトラッシュし、その中のエネルギーカード1枚につきperダメージ(Massive Eruption)。"""

    n: int
    per: int

    def execute(self, ctx: EffectContext) -> None:
        player = _attacker_player(ctx)
        count = 0
        for _ in range(self.n):
            if not player.deck:
                break
            cid = player.deck.pop(0)
            player.discard.append(cid)
            c = ctx.card_db.get(cid)
            if c is not None and c.is_energy:
                count += 1
        ctx.log(f"山札の上{self.n}枚をトラッシュ: エネルギー{count}枚")
        DealDamage(self.per * count).execute(ctx)


@dataclass(frozen=True)
class BothDiscardTopBonusPerEnergy(Effect):
    """おたがいに山札の上を1枚トラッシュし、そのうちエネルギーカード1枚につきperを加える(Eruption)。"""

    base: int
    per: int

    def execute(self, ctx: EffectContext) -> None:
        count = 0
        for side in (ctx.acting_player, ctx.opponent):
            player = ctx.state.player(side)
            if player.deck:
                cid = player.deck.pop(0)
                player.discard.append(cid)
                c = ctx.card_db.get(cid)
                if c is not None and c.is_energy:
                    count += 1
        DealDamage(self.base + self.per * count).execute(ctx)


@dataclass(frozen=True)
class DiscardTopOwnThenOpponentPerEnergy(Effect):
    """自分の山札の上からn枚をトラッシュし、その中の指定タイプのエネルギー1枚につき相手の山札の上をn枚トラッシュする(Melting Floe)。"""

    n: int
    per: int
    energy_type: str

    def execute(self, ctx: EffectContext) -> None:
        player = _attacker_player(ctx)
        opponent = ctx.state.player(ctx.opponent)
        count = 0
        for _ in range(self.n):
            if not player.deck:
                break
            cid = player.deck.pop(0)
            player.discard.append(cid)
            if _basic_energy_of(ctx.card_db, cid) == self.energy_type:
                count += 1
        for _ in range(self.per * count):
            if not opponent.deck:
                break
            opponent.discard.append(opponent.deck.pop(0))
        ctx.log(f"自分の山札から{self.energy_type}エネルギー{count}枚をトラッシュ。相手の山札を{self.per * count}枚トラッシュ")


@dataclass(frozen=True)
class FlipCoinsDiscardOpponentDeckPerHeads(Effect):
    """コインをcoins枚投げ、オモテ1枚につき相手の山札の上をper枚トラッシュする(Balloon Bomb)。"""

    coins: int
    per: int

    def execute(self, ctx: EffectContext) -> None:
        heads = sum(1 for _ in range(self.coins) if ctx.rng.random() < 0.5)
        ctx.coin_heads_count = heads
        opponent = ctx.state.player(ctx.opponent)
        for _ in range(heads * self.per):
            if not opponent.deck:
                break
            opponent.discard.append(opponent.deck.pop(0))
        ctx.log(f"コイン{self.coins}枚: オモテ{heads}枚。相手の山札を{heads * self.per}枚トラッシュ")


@dataclass(frozen=True)
class DamageIfDiscardHasEnergyThenShuffle(Effect):
    """トラッシュに指定タイプの基本エネルギーがcount枚以上なければ、このワザは何もしない。あれば、その枚数を山札に戻してシャッフルし、ダメージを与える(Flare Up)。"""

    base: int
    energy_type: str
    count: int

    def execute(self, ctx: EffectContext) -> None:
        player = _attacker_player(ctx)
        idx = [i for i, cid in enumerate(player.discard) if _basic_energy_of(ctx.card_db, cid) == self.energy_type]
        if len(idx) < self.count:
            ctx.log("トラッシュにエネルギーが足りないので、このワザは何もしない")
            return
        DealDamage(self.base).execute(ctx)
        for i in sorted(idx[: self.count], reverse=True):
            player.deck.append(player.discard.pop(i))
        ctx.rng.shuffle(player.deck)


@dataclass(frozen=True)
class DiscardAllOwnTypeEnergyThenBonus(Effect):
    """このポケモンの指定タイプのエネルギーを全てトラッシュし、トラッシュしたエネルギー1枚につきper追加ダメージ(Explosive Fireball)。"""

    base: int
    per: int
    energy_type: str

    def execute(self, ctx: EffectContext) -> None:
        mon = ctx.source_pokemon
        player = _attacker_player(ctx)
        n = 0
        if mon is not None:
            kept = []
            for e in mon.attached_energy:
                if _basic_energy_of(ctx.card_db, e) == self.energy_type:
                    player.discard.append(e)
                    n += 1
                else:
                    kept.append(e)
            mon.attached_energy = kept
        DealDamage(self.base + self.per * n).execute(ctx)


@dataclass(frozen=True)
class DiscardAnyOwnBenchedScalingDamage(Effect):
    """自分のベンチポケモンを好きな数選んでトラッシュし、トラッシュした1匹につきper追加ダメージ(Despair Ray)。"""

    base: int
    per: int

    def execute(self, ctx: EffectContext) -> None:
        player = _attacker_player(ctx)
        if not player.bench:
            DealDamage(self.base).execute(ctx)
            return
        slots = [(i + 1, m) for i, m in enumerate(player.bench)]
        ctx.state.pending_search_choice = PendingSearchChoice(
            player_index=ctx.acting_player,
            zone="gen_pokemon_pick",
            source_indices=[s for s, _ in slots],
            card_ids=[m.card_id for _, m in slots],
            min_count=0,
            max_count=len(slots),
            prompt="トラッシュする自分のベンチポケモンを好きなだけ選ぶ(選ばなくてもよい)",
            shuffle_after=False,
            all_card_ids=[m.card_id for _, m in slots],
            custom_data={"op": "discard_benched_damage", "base": self.base, "per": self.per},
            cont_source_pokemon=ctx.source_pokemon,
            cont_source_card_id=ctx.source_card_id,
        )


def _op_discard_benched_damage(state, card_db, choice, selected, action, ctx, custom) -> bool:
    player = state.player(choice.player_index)
    slots = sorted((choice.source_indices[p] for p in selected), reverse=True)
    for slot in slots:
        if 1 <= slot <= len(player.bench):
            mon = player.bench.pop(slot - 1)
            player.discard.extend(mon.evolution_history)
            player.discard.append(mon.card_id)
            player.discard.extend(mon.attached_energy)
            if mon.attached_tool:
                player.discard.append(mon.attached_tool)
    DealDamage(custom["base"] + custom["per"] * len(slots)).execute(ctx)
    return False


@dataclass(frozen=True)
class OptionalVariantScript(Effect):
    """「〜してもよい。そうしたら…」型のワザ。使うかどうかはワザを選ぶときに決める(engine.legal_actionsが「使わない」Attack(i)と
    「使う」Attack(i, 0)を出す)。使わないときはbaseダメージだけ、使うときはusedの効果を順に実行する(ダメージはused側で与える)。"""

    base: int
    used: tuple
    payable: str = ""  # "": 常に使える / "self_has_energy": このポケモンにエネルギーがついている / "own_bench": ベンチに自分のポケモンがいる
    optional_variant = True

    def variant_payable(self, state, player, mon, card_db) -> bool:
        if self.payable == "self_has_energy":
            return bool(mon.attached_energy)
        if self.payable == "own_bench":
            return bool(player.bench)
        if self.payable == "self_has_tool":
            return mon.attached_tool is not None
        if self.payable == "stadium_in_play":
            return state.stadium_in_play is not None
        if self.payable == "opp_active_has_energy":
            active = state.player(1 - (0 if player is state.players[0] else 1)).active
            return active is not None and bool(active.attached_energy)
        if self.payable == "opp_bench":
            return bool(state.player(1 - (0 if player is state.players[0] else 1)).bench)
        if self.payable == "self_has_special_energy":
            return any((c := card_db.get(e)) is not None and c.is_special_energy for e in mon.attached_energy)
        if self.payable.startswith("energy:"):  # "energy:Water:2"=その基本タイプ / "energy:any:2"=どのエネルギーでも、N枚ついている
            _, kind, n = self.payable.split(":")
            return sum(1 for e in mon.attached_energy if kind == "any" or ((c := card_db.get(e)) is not None and c.basic_energy_type == kind)) >= int(n)
        return True

    def execute(self, ctx: EffectContext) -> None:
        from effects.interpreter import run_script

        player = _attacker_player(ctx)
        if ctx.target_bench_index != 0 or ctx.source_pokemon is None or not self.variant_payable(ctx.state, player, ctx.source_pokemon, ctx.card_db):
            DealDamage(self.base).execute(ctx)
            return
        run_script(tuple(self.used), ctx)


@dataclass(frozen=True)
class ConditionalDamageIgnoring(Effect):
    """条件を満たすとき、追加ダメージを与え、さらに抵抗力/相手のバトルポケモンにかかっている効果を無視する(Vanishing Strike)。"""

    base: int
    bonus: int
    condition: str
    arg: str = ""
    ignore_resistance: bool = False
    ignore_effects: bool = False

    def execute(self, ctx: EffectContext) -> None:
        from effects.primitives import DealDamageIgnoringAllDefenderEffects, DealDamageIgnoringResistanceOnly

        if not _ep.condition_met(ctx, self.condition, self.arg):
            DealDamage(self.base).execute(ctx)
        elif self.ignore_effects:
            DealDamageIgnoringAllDefenderEffects(self.base + self.bonus).execute(ctx)
        elif self.ignore_resistance:
            DealDamageIgnoringResistanceOnly(self.base + self.bonus).execute(ctx)
        else:
            DealDamage(self.base + self.bonus).execute(ctx)


@dataclass(frozen=True)
class OptionalFlipBonusOrSelfBenchDamage(Effect):
    """コインを投げてもよい。オモテなら追加ダメージ、ウラなら自分のベンチ全員にbench_damageダメージ(Megaton Slam)。"""

    base: int
    bonus: int
    bench_damage: int
    optional_variant = True

    def execute(self, ctx: EffectContext) -> None:
        if ctx.target_bench_index != 0:
            DealDamage(self.base).execute(ctx)
            return
        if ctx.rng.random() < 0.5:
            ctx.log("コイン: オモテ")
            DealDamage(self.base + self.bonus).execute(ctx)
        else:
            ctx.log("コイン: ウラ")
            DealDamage(self.base).execute(ctx)
            for mon in _attacker_player(ctx).bench:
                mon.damage += self.bench_damage


@dataclass(frozen=True)
class AddPoisonCountersIfPoisoned(Effect):
    """相手のバトルポケモンがどくなら、どくで番の間にのるダメカンをextra個増やす(何度でも重ねられる)(Poison Up)。"""

    extra: int

    def execute(self, ctx: EffectContext) -> None:
        _, defender = _defender(ctx)
        if defender is None or not defender.status.poisoned or _defender_blocks_effect(ctx, defender):
            return
        defender.status.poison_severity += self.extra


@dataclass(frozen=True)
class FlipCoinsRevealThenDiscardOpponentHandPerHeads(Effect):
    """コインをcoins枚投げ、1枚でもオモテなら相手の手札を公開させ、オモテ1枚につき相手の手札を1枚(相手が選ばずランダムに)トラッシュする(Roll Up)。"""

    coins: int

    def execute(self, ctx: EffectContext) -> None:
        heads = sum(1 for _ in range(self.coins) if ctx.rng.random() < 0.5)
        ctx.coin_heads_count = heads
        if heads == 0:
            return
        opponent = ctx.state.player(ctx.opponent)
        _attacker_player(ctx).known_opponent_hand = list(opponent.hand)
        ctx.reveal("相手の手札", list(opponent.hand))
        # 実カードは「相手の手札から」捨てるカードを攻撃側が選ぶのではなく、相手が選ぶ(テキストに指定なし=相手が選ぶ)
        n = min(heads, len(opponent.hand))
        if n <= 0:
            return
        ctx.state.pending_search_choice = PendingSearchChoice(
            player_index=ctx.opponent,
            zone="hand",
            source_indices=list(range(len(opponent.hand))),
            card_ids=list(opponent.hand),
            min_count=n,
            max_count=n,
            prompt=f"手札を{n}枚トラッシュする",
            shuffle_after=False,
            all_card_ids=list(opponent.hand),
            destination="discard",
        )


@dataclass(frozen=True)
class FlipCoinsShuffleRandomOpponentHandCardsPerHeads(Effect):
    """コインをcoins枚投げ、オモテ1枚につき相手の手札からランダムに1枚選び、公開させて山札に戻す(Electric Mischief)。"""

    coins: int

    def execute(self, ctx: EffectContext) -> None:
        heads = sum(1 for _ in range(self.coins) if ctx.rng.random() < 0.5)
        ctx.coin_heads_count = heads
        opponent = ctx.state.player(ctx.opponent)
        returned = []
        for _ in range(heads):
            if not opponent.hand:
                break
            returned.append(opponent.hand.pop(ctx.rng.randrange(len(opponent.hand))))
        if returned:
            ctx.reveal("相手の手札から選んだカード", list(returned))
            opponent.deck.extend(returned)
            ctx.rng.shuffle(opponent.deck)
        ctx.log(f"コイン{self.coins}枚: オモテ{heads}枚。相手の手札{len(returned)}枚を山札に戻した")


@dataclass(frozen=True)
class OpponentPutsHandCardOnBottomOfDeck(Effect):
    """相手は、手札から1枚選んで山札の下に置く(Act Cute)。"""

    def execute(self, ctx: EffectContext) -> None:
        opponent = ctx.state.player(ctx.opponent)
        if not opponent.hand:
            return
        ctx.state.pending_search_choice = PendingSearchChoice(
            player_index=ctx.opponent,
            zone="hand",
            source_indices=list(range(len(opponent.hand))),
            card_ids=list(opponent.hand),
            min_count=1,
            max_count=1,
            prompt="山札の下に置く手札を選ぶ",
            shuffle_after=False,
            all_card_ids=list(opponent.hand),
            destination="deck_bottom",
        )


@dataclass(frozen=True)
class DiscardAllSpecialEnergyFromAllOpponentPokemon(Effect):
    """相手の全てのポケモンについている特殊エネルギーを全てトラッシュする(Cyber Crush)。"""

    def execute(self, ctx: EffectContext) -> None:
        opponent = ctx.state.player(ctx.opponent)
        for _s, mon in _opp_slots(opponent):
            if _defender_blocks_effect(ctx, mon):
                continue
            kept = []
            for e in mon.attached_energy:
                c = ctx.card_db.get(e)
                (opponent.discard if c is not None and c.is_special_energy else kept).append(e)
            mon.attached_energy = kept


@dataclass(frozen=True)
class ShuffleAllAttachedCardsIntoDecks(Effect):
    """おたがいの場のポケモンについているカード(エネルギー・どうぐ)を全て、それぞれの持ち主の山札に戻してシャッフルする(Strong Winds)。"""

    def execute(self, ctx: EffectContext) -> None:
        for side in (ctx.acting_player, ctx.opponent):
            player = ctx.state.player(side)
            moved = 0
            for mon in player.all_pokemon_in_play():
                if side != ctx.acting_player and _defender_blocks_effect(ctx, mon):
                    continue
                player.deck.extend(mon.attached_energy)
                moved += len(mon.attached_energy)
                mon.attached_energy = []
                if mon.attached_tool:
                    player.deck.append(mon.attached_tool)
                    mon.attached_tool = None
                    moved += 1
            if moved:
                ctx.rng.shuffle(player.deck)


@dataclass(frozen=True)
class LookThroughOwnDeckThenShuffle(Effect):
    """自分の山札を見て、シャッフルする(Data Check)。"""

    def execute(self, ctx: EffectContext) -> None:
        player = _attacker_player(ctx)
        ctx.reveal("自分の山札", list(player.deck))
        ctx.rng.shuffle(player.deck)


@dataclass(frozen=True)
class LookOwnTopThenMayShuffle(Effect):
    """自分の山札の一番上を見て、そのあと山札をシャッフルしてもよい(Homing Pidove)。"""

    def execute(self, ctx: EffectContext) -> None:
        player = _attacker_player(ctx)
        if not player.deck:
            return
        ctx.state.pending_search_choice = PendingSearchChoice(
            player_index=ctx.acting_player,
            zone="gen_deck_pick",
            source_indices=[0],
            card_ids=[player.deck[0]],
            min_count=0,
            max_count=1,
            prompt="山札の一番上のカード。選ぶと山札をシャッフルする(選ばなければそのまま)",
            shuffle_after=False,
            all_card_ids=[player.deck[0]],
            custom_data={"op": "shuffle_own_deck_if_picked"},
            reveal_to_opponent=False,
        )


def _op_shuffle_own_deck_if_picked(state, card_db, choice, selected, action, ctx, custom) -> bool:
    if selected:
        state.rng.shuffle(state.player(choice.player_index).deck)
        state.add_log("山札をシャッフルした")
    return False


@dataclass(frozen=True)
class LookTopNTakeOneShuffleRest(Effect):
    """自分の山札の上からn枚を見て、1枚を選んで手札に加える。残りは山札に戻してシャッフルする(Diminutive Desire)。"""

    n: int

    def execute(self, ctx: EffectContext) -> None:
        player = _attacker_player(ctx)
        n = min(self.n, len(player.deck))
        if n <= 0:
            return
        ctx.state.pending_search_choice = PendingSearchChoice(
            player_index=ctx.acting_player,
            zone="deck",
            source_indices=list(range(n)),
            card_ids=list(player.deck[:n]),
            min_count=0,
            max_count=1,
            prompt=f"山札の上{n}枚から手札に加えるカードを選ぶ(残りは山札に戻してシャッフル)",
            shuffle_after=True,
            all_card_ids=list(player.deck[:n]),
            destination="hand",
            reveal_to_opponent=False,
        )


@dataclass(frozen=True)
class RevealUntilKindToHand(Effect):
    """山札の上から、指定の種類(item等)のカードが出るまで公開し、そのカードを手札に加える。残りは山札に戻してシャッフルする(Look for Keys)。"""

    kind: str

    def execute(self, ctx: EffectContext) -> None:
        player = _attacker_player(ctx)
        shown = []
        found = None
        while player.deck:
            cid = player.deck.pop(0)
            shown.append(cid)
            c = ctx.card_db.get(cid)
            if c is not None and ((self.kind == "item" and c.is_item) or (self.kind == "supporter" and c.is_supporter)):
                found = cid
                break
        ctx.reveal("山札の上から公開したカード", list(shown))
        if found is not None:
            player.hand.append(found)
            shown.remove(found)
        player.deck.extend(shown)
        ctx.rng.shuffle(player.deck)
        ctx.log(f"{self.kind}が出るまで公開: " + ("見つかった" if found is not None else "見つからなかった"))


@dataclass(frozen=True)
class LookEitherDeckTopReorder(Effect):
    """どちらかのプレイヤーの山札の上からn枚を見て、好きな順番で山札の上に戻す(Future Sight)。見る山札はまず選ぶ。"""

    n: int

    def execute(self, ctx: EffectContext) -> None:
        decks = [(side, ctx.state.player(side)) for side in (ctx.acting_player, ctx.opponent) if ctx.state.player(side).deck]
        if not decks:
            return
        ctx.state.pending_search_choice = PendingSearchChoice(
            player_index=ctx.acting_player,
            zone="gen_deck_pick",
            source_indices=[side for side, _ in decks],
            card_ids=[p.deck[0] for _, p in decks],
            min_count=1,
            max_count=1,
            prompt="山札の上を見るプレイヤーを選ぶ(自分/相手)",
            shuffle_after=False,
            all_card_ids=[p.deck[0] for _, p in decks],
            custom_data={"op": "either_deck_reorder_pick", "n": self.n},
            reveal_to_opponent=False,
        )


def _op_either_deck_reorder_pick(state, card_db, choice, selected, action, ctx, custom) -> bool:
    if not selected:
        return False
    side = choice.source_indices[selected[0]]
    owner = state.player(side)
    n = min(custom["n"], len(owner.deck))
    if n <= 0:
        return False
    top = list(owner.deck[:n])
    state.pending_search_choice = PendingSearchChoice(
        player_index=choice.player_index,
        zone="gen_deck_pick",
        source_indices=list(range(n)),
        card_ids=top,
        min_count=n,
        max_count=n,
        prompt=f"{'自分' if side == choice.player_index else '相手'}の山札の上{n}枚を、上に戻したい順に選ぶ",
        shuffle_after=False,
        all_card_ids=top,
        custom_data={"op": "either_deck_reorder_apply", "side": side, "n": n},
        reveal_to_opponent=False,
    )
    return False


def _op_either_deck_reorder_apply(state, card_db, choice, selected, action, ctx, custom) -> bool:
    owner = state.player(custom["side"])
    n = custom["n"]
    ordered = list(dict.fromkeys(action.selected_indices))
    top = owner.deck[:n]
    new_top = [top[p] for p in ordered if 0 <= p < len(top)]
    if len(new_top) == len(top):
        owner.deck[:n] = new_top
    state.add_log("山札の上を並べ替えた")
    return False


@dataclass(frozen=True)
class LookTopNAttachTypedEnergyToSelf(Effect):
    """自分の山札の上からn枚を見て、その中の指定タイプの基本エネルギーを好きな枚数、このポケモンにつける。残りは山札に戻してシャッフルする(Thunder Rod)。"""

    n: int
    energy_type: str

    def execute(self, ctx: EffectContext) -> None:
        player = _attacker_player(ctx)
        n = min(self.n, len(player.deck))
        if n <= 0 or ctx.source_pokemon is None:
            return
        top = player.deck[:n]
        idx = [i for i, cid in enumerate(top) if _basic_energy_of(ctx.card_db, cid) == self.energy_type]
        ctx.reveal("山札の上から見たカード", list(top))
        if not idx:
            ctx.rng.shuffle(player.deck)
            return
        ctx.state.pending_search_choice = PendingSearchChoice(
            player_index=ctx.acting_player,
            zone="deck",
            source_indices=idx,
            card_ids=[top[i] for i in idx],
            min_count=0,
            max_count=len(idx),
            prompt=f"このポケモンにつける{self.energy_type}エネルギーを好きな枚数選ぶ(残りは山札に戻してシャッフル)",
            shuffle_after=True,
            all_card_ids=list(top),
            destination="attach_energy",
            attach_target_pokemon=ctx.source_pokemon,
        )


@dataclass(frozen=True)
class SearchDeckToolsAttachToBenched(Effect):
    """どうぐのついていない自分のベンチポケモンを、最大count匹選び、それぞれに山札からどうぐを1枚探してつける(Coordinate)。"""

    count: int

    def execute(self, ctx: EffectContext) -> None:
        player = _attacker_player(ctx)
        slots = [(i + 1, m) for i, m in enumerate(player.bench) if m.attached_tool is None]
        has_tool = any((c := ctx.card_db.get(cid)) is not None and c.is_pokemon_tool for cid in player.deck)
        if not slots or not has_tool:
            ctx.rng.shuffle(player.deck)
            return
        ctx.state.pending_search_choice = PendingSearchChoice(
            player_index=ctx.acting_player,
            zone="gen_pokemon_pick",
            source_indices=[s for s, _ in slots],
            card_ids=[m.card_id for _, m in slots],
            min_count=0,
            max_count=min(self.count, len(slots)),
            prompt=f"どうぐをつけるベンチポケモンを{self.count}匹まで選ぶ",
            shuffle_after=False,
            all_card_ids=[m.card_id for _, m in slots],
            custom_data={"op": "coordinate_attach_tools"},
            cont_source_pokemon=ctx.source_pokemon,
            cont_source_card_id=ctx.source_card_id,
        )


def _op_coordinate_attach_tools(state, card_db, choice, selected, action, ctx, custom) -> bool:
    player = state.player(choice.player_index)
    for pos in selected:
        slot = choice.source_indices[pos]
        if not (1 <= slot <= len(player.bench)):
            continue
        mon = player.bench[slot - 1]
        tools = [i for i, cid in enumerate(player.deck) if (c := card_db.get(cid)) is not None and c.is_pokemon_tool]
        if not tools or mon.attached_tool is not None:
            continue
        # どのどうぐをつけるかも選べる実カードだが、デッキの先頭側から1枚ずつ自動で選ぶ(同名のどうぐが複数あっても結果は同じ)
        mon.attached_tool = player.deck.pop(tools[0])
        state.add_log(f"山札から{mon.attached_tool}を探して{mon.card_id}につけた")
    state.rng.shuffle(player.deck)
    return False


@dataclass(frozen=True)
class SearchDeckBasicToBenchThenAttachEnergy(Effect):
    """山札からたねポケモンを1匹ベンチに出し、そのポケモンに山札から基本エネルギーを最大max_energy枚つける(Solar Birth)。"""

    max_energy: int

    def execute(self, ctx: EffectContext) -> None:
        from effects.primitives import SearchDeckForBasicPokemonToBench

        SearchDeckForBasicPokemonToBench(count=1).execute(ctx)
        pending = ctx.state.pending_search_choice
        if pending is not None:
            pending.remaining_script = (_AttachEnergyToLastBenched(self.max_energy),)
        else:
            _AttachEnergyToLastBenched(self.max_energy).execute(ctx)


@dataclass(frozen=True)
class _AttachEnergyToLastBenched(Effect):
    max_energy: int

    def execute(self, ctx: EffectContext) -> None:
        player = _attacker_player(ctx)
        if not player.bench:
            return
        target = player.bench[-1]
        idx = [i for i, cid in enumerate(player.deck) if _basic_energy_of(ctx.card_db, cid) is not None]
        if not idx:
            ctx.rng.shuffle(player.deck)
            return
        ctx.state.pending_search_choice = PendingSearchChoice(
            player_index=ctx.acting_player,
            zone="deck",
            source_indices=idx,
            card_ids=[player.deck[i] for i in idx],
            min_count=0,
            max_count=min(self.max_energy, len(idx)),
            prompt=f"出したポケモンにつける基本エネルギーを{self.max_energy}枚まで選ぶ",
            shuffle_after=True,
            all_card_ids=list(player.deck),
            destination="attach_energy",
            attach_target_pokemon=target,
        )


@dataclass(frozen=True)
class AttachHandEnergyToBenchThenHeal(Effect):
    """手札の指定タイプの基本エネルギーを最大count枚、自分のベンチポケモンに好きなようにつけてよい。エネルギーをつけたポケモンのダメージを全て回復する(Jagged Saber)。"""

    count: int
    energy_type: str

    def execute(self, ctx: EffectContext) -> None:
        _jag_next(ctx.state, ctx.card_db, ctx.acting_player, self.count, [], self.energy_type)


def _jag_next(state, card_db, player_index: int, remaining: int, healed: list, energy_type: str) -> None:
    player = state.player(player_index)
    hand_idx = [i for i, cid in enumerate(player.hand) if _basic_energy_of(card_db, cid) == energy_type]
    if remaining <= 0 or not hand_idx or not player.bench:
        for mon in healed:
            mon.heal(9999)
        if healed:
            state.add_log("エネルギーをつけたベンチポケモンのダメージを全て回復した")
        return
    state.pending_search_choice = PendingSearchChoice(
        player_index=player_index,
        zone="hand",
        source_indices=hand_idx,
        card_ids=[player.hand[i] for i in hand_idx],
        min_count=0,
        max_count=1,
        prompt=f"ベンチポケモンにつける{energy_type}エネルギーを選ぶ(あと{remaining}枚まで。選ばなければ終わり)",
        shuffle_after=False,
        all_card_ids=list(player.hand),
        destination="hand",
        custom_data={"mode": "gen_continue", "op": "jag_energy_picked", "remaining": remaining, "healed": healed, "type": energy_type},
    )


def _continue_jag_energy_picked(ctx, choice, custom, picked_card_ids) -> None:
    state = ctx.state
    player = state.player(choice.player_index)
    if not picked_card_ids:
        _jag_next(state, ctx.card_db, choice.player_index, 0, custom["healed"], custom["type"])
        return
    slots = [(i + 1, m) for i, m in enumerate(player.bench)]
    state.pending_search_choice = PendingSearchChoice(
        player_index=choice.player_index,
        zone="gen_pokemon_pick",
        source_indices=[s for s, _ in slots],
        card_ids=[m.card_id for _, m in slots],
        min_count=1,
        max_count=1,
        prompt="エネルギーをつけるベンチポケモンを選ぶ",
        shuffle_after=False,
        all_card_ids=[m.card_id for _, m in slots],
        custom_data={"op": "jag_attach_to", "card_id": picked_card_ids[0], "remaining": custom["remaining"], "healed": custom["healed"], "type": custom["type"]},
    )


def _op_jag_attach_to(state, card_db, choice, selected, action, ctx, custom) -> bool:
    player = state.player(choice.player_index)
    slot = choice.source_indices[selected[0]] if selected else None
    mon = player.bench[slot - 1] if slot is not None and 1 <= slot <= len(player.bench) else None
    if mon is not None and custom["card_id"] in player.hand:
        player.hand.remove(custom["card_id"])
        mon.attached_energy.append(custom["card_id"])
        if mon not in custom["healed"]:
            custom["healed"].append(mon)
        state.add_log(f"手札の{custom['card_id']}を{mon.card_id}につけた")
    _jag_next(state, card_db, choice.player_index, custom["remaining"] - 1, custom["healed"], custom["type"])
    return False


@dataclass(frozen=True)
class MoveSelfEnergyToChosenBench(Effect):
    """このポケモンのエネルギー(energy_type指定時はそのタイプ)をcount枚、選んだ自分のベンチポケモン1匹に移す。heal_destが0より大きければ、移したポケモンのダメージをその分回復する
    (Tidal Storm/Precious Ribbon)。"""

    count: int
    energy_type: str | None = None
    heal_dest: int = 0

    def execute(self, ctx: EffectContext) -> None:
        from effects.era_primitives_b import _slot_of

        player = _attacker_player(ctx)
        mon = ctx.source_pokemon
        if mon is None or not player.bench:
            return
        energy_idx = [i for i, e in enumerate(mon.attached_energy) if self.energy_type is None or _basic_energy_of(ctx.card_db, e) == self.energy_type]
        if not energy_idx:
            return
        slots = [(i + 1, m) for i, m in enumerate(player.bench)]
        ctx.state.pending_search_choice = PendingSearchChoice(
            player_index=ctx.acting_player,
            zone="gen_pokemon_pick",
            source_indices=[s for s, _ in slots],
            card_ids=[m.card_id for _, m in slots],
            min_count=1,
            max_count=1,
            prompt="エネルギーを移す先のベンチポケモンを選ぶ",
            shuffle_after=False,
            all_card_ids=[m.card_id for _, m in slots],
            custom_data={
                "op": "move_self_energy_to_bench_pick_dest", "count": self.count, "energy_type": self.energy_type,
                "heal_dest": self.heal_dest, "from_slot": _slot_of(player, mon),
            },
            cont_source_pokemon=mon,
            cont_source_card_id=ctx.source_card_id,
        )


def _op_move_self_energy_pick_dest(state, card_db, choice, selected, action, ctx, custom) -> bool:
    player = state.player(choice.player_index)
    dest_slot = choice.source_indices[selected[0]] if selected else None
    src = choice.cont_source_pokemon
    if dest_slot is None or src is None:
        return False
    idx = [i for i, e in enumerate(src.attached_energy) if custom["energy_type"] is None or _basic_energy_of(card_db, e) == custom["energy_type"]]
    n = min(custom["count"], len(idx))
    dest = player.bench[dest_slot - 1] if 1 <= dest_slot <= len(player.bench) else None
    if dest is None or n <= 0:
        return False
    if len(idx) == n or len({src.attached_energy[i] for i in idx}) == 1:
        moved = [src.attached_energy[i] for i in idx[:n]]
        for i in sorted(idx[:n], reverse=True):
            src.attached_energy.pop(i)
        dest.attached_energy.extend(moved)
        state.add_log(f"エネルギー{len(moved)}枚を{src.card_id}から{dest.card_id}へ移した")
        if custom["heal_dest"] and moved:
            dest.heal(custom["heal_dest"])
        return False
    state.pending_search_choice = PendingSearchChoice(
        player_index=choice.player_index,
        zone="gen_energy_pick",
        source_indices=idx,
        card_ids=[src.attached_energy[i] for i in idx],
        min_count=n,
        max_count=n,
        prompt=f"移すエネルギーを{n}枚選ぶ",
        shuffle_after=False,
        all_card_ids=[src.attached_energy[i] for i in idx],
        custom_data={"op": "move_selected_energy_obj", "src": src, "dest": dest, "heal_dest": custom["heal_dest"]},
    )
    return False


def _op_move_selected_energy_obj(state, card_db, choice, selected, action, ctx, custom) -> bool:
    src, dest = custom["src"], custom["dest"]
    moved = []
    for ei in sorted((choice.source_indices[p] for p in selected), reverse=True):
        if 0 <= ei < len(src.attached_energy):
            moved.append(src.attached_energy.pop(ei))
    dest.attached_energy.extend(moved)
    state.add_log(f"エネルギー{len(moved)}枚を{src.card_id}から{dest.card_id}へ移した")
    if custom.get("heal_dest") and moved:
        dest.heal(custom["heal_dest"])
    return False


@dataclass(frozen=True)
class DiscardAnyHandThenDrawSame(Effect):
    """手札を好きな枚数トラッシュし、トラッシュした枚数だけ引く(Veil of Darkness)。"""

    def execute(self, ctx: EffectContext) -> None:
        player = _attacker_player(ctx)
        if not player.hand:
            return
        ctx.state.pending_search_choice = PendingSearchChoice(
            player_index=ctx.acting_player,
            zone="hand",
            source_indices=list(range(len(player.hand))),
            card_ids=list(player.hand),
            min_count=0,
            max_count=len(player.hand),
            prompt="トラッシュする手札を好きな枚数選ぶ(同じ枚数を引く)",
            shuffle_after=False,
            all_card_ids=list(player.hand),
            destination="discard",
            custom_data={"mode": "gen_continue", "op": "draw_picked_count"},
            effect_source=ctx.effect_source,
        )


@dataclass(frozen=True)
class DiscardAnyHandThenHealSelf(Effect):
    """手札を好きな枚数トラッシュし、トラッシュした1枚につきこのポケモンのダメージをper回復する(Healing Wave)。"""

    per: int

    def execute(self, ctx: EffectContext) -> None:
        player = _attacker_player(ctx)
        if not player.hand or ctx.source_pokemon is None:
            return
        ctx.state.pending_search_choice = PendingSearchChoice(
            player_index=ctx.acting_player,
            zone="hand",
            source_indices=list(range(len(player.hand))),
            card_ids=list(player.hand),
            min_count=0,
            max_count=len(player.hand),
            prompt="トラッシュする手札を好きな枚数選ぶ(1枚につきこのポケモンを回復する)",
            shuffle_after=False,
            all_card_ids=list(player.hand),
            destination="discard",
            custom_data={"mode": "gen_continue", "op": "heal_source_per_picked", "per": self.per},
            cont_source_pokemon=ctx.source_pokemon,
            cont_source_card_id=ctx.source_card_id,
            effect_source=ctx.effect_source,
        )


def _continue_heal_source_per_picked(ctx, choice, custom, picked_card_ids) -> None:
    if picked_card_ids and ctx.source_pokemon is not None:
        ctx.source_pokemon.heal(custom["per"] * len(picked_card_ids))


# ---------------------------------------------------------------------------------------------
# パート3: 対象を選ぶダメージ・特殊な移動
# ---------------------------------------------------------------------------------------------
def _retreat_colorless(card) -> int:
    return sum(1 for t in card.retreat_cost if t == "Colorless") if card is not None else 0


@dataclass(frozen=True)
class DealDamageToChosenOpponentPokemonScaled(Effect):
    """相手の場のポケモンを最大count体選び、それぞれにamountダメージ(ベンチには弱点・抵抗力を計算しない。wr_bench=Trueなら計算する)。
    filter: ""(制限なし) / "ability"(特性を持つポケモン) / "bench_subtype:EX"(そのサブタイプのベンチポケモン)。
    scale: ""(固定) / "energy"(対象についているエネルギー1枚につきamount) / "retreat_colorless"(対象のにげるコストの無色1個につきamount)。
    per_own_named: 自分の場のその名前のポケモン1匹につきamountを増やす(Swarming Sting)。"""

    count: int
    amount: int
    filter: str = ""
    scale: str = ""
    wr_bench: bool = False
    per_own_named: str = ""

    def execute(self, ctx: EffectContext) -> None:
        if ctx.source_pokemon is None:
            return
        opponent = ctx.state.player(ctx.opponent)
        amount = self.amount
        if self.per_own_named:
            n = sum(1 for _s, m in _own_slots(_attacker_player(ctx)) if (c := ctx.card_db.get(m.card_id)) is not None and c.name == self.per_own_named)
            amount = self.amount * n
        candidates = []
        for slot, mon in _opp_slots(opponent):
            card = ctx.card_db.get(mon.card_id)
            if card is None:
                continue
            if self.filter == "ability" and not card.abilities:
                continue
            if self.filter.startswith("bench_subtype:") and (slot == 0 or not card_has_subtype(card, self.filter.split(":", 1)[1])):
                continue
            candidates.append((slot, mon))
        if not candidates or amount <= 0:
            return
        n = min(self.count, len(candidates))
        ctx.state.pending_search_choice = PendingSearchChoice(
            player_index=ctx.acting_player,
            zone="opponent_pokemon_target",
            source_indices=[s for s, _ in candidates],
            card_ids=[m.card_id for _, m in candidates],
            min_count=n,
            max_count=n,
            prompt=f"ダメージを与える相手のポケモンを{n}体選ぶ",
            shuffle_after=False,
            all_card_ids=[m.card_id for _, m in candidates],
            cont_source_pokemon=ctx.source_pokemon,
            cont_source_card_id=ctx.source_card_id,
            custom_data={"mode": "damage_multi", "amount": amount, "scale": self.scale, "wr_bench": self.wr_bench},
        )


@dataclass(frozen=True)
class DealFixedDamageToEachOpponentPokemonPerRetreatColorless(Effect):
    """相手の全てのポケモンに、そのポケモンのにげるコストの無色1個につきperダメージ。ベンチには弱点・抵抗力を計算しない(Spike Lash)。"""

    per: int

    def execute(self, ctx: EffectContext) -> None:
        for slot, mon in _opp_slots(ctx.state.player(ctx.opponent)):
            n = _retreat_colorless(ctx.card_db.get(mon.card_id))
            if n:
                _hit(ctx, mon, self.per * n, slot == 0)


@dataclass(frozen=True)
class MayDiscardOpponentSpecialEnergyOrStadium(Effect):
    """相手のバトルポケモンについている特殊エネルギー1枚、または場のスタジアム1枚を、トラッシュしてもよい(Iron Crusher)。"""

    def execute(self, ctx: EffectContext) -> None:
        from effects.primitives import _field_attachment_candidates

        opponent = ctx.state.player(ctx.opponent)
        source_indices, card_ids = _field_attachment_candidates(
            ctx.state, ctx.card_db, (ctx.opponent,), include_tool=False,
            energy_predicate=lambda c: c.is_special_energy, include_stadium=True, only_pokemon=opponent.active,
        )
        if opponent.active is None:  # only_pokemon=Noneだと全員が対象になってしまうため、バトルポケモンがいなければスタジアムだけにする
            source_indices = [e for e in source_indices if e[0] == "stadium"]
            card_ids = [ctx.state.stadium_in_play] if source_indices else []
        if not source_indices:
            return
        ctx.state.pending_search_choice = PendingSearchChoice(
            player_index=ctx.acting_player,
            zone="field_attachment",
            source_indices=source_indices,
            card_ids=card_ids,
            min_count=0,
            max_count=1,
            prompt="トラッシュしてもよい: 相手のバトルポケモンの特殊エネルギー/場のスタジアム",
            shuffle_after=False,
            all_card_ids=list(card_ids),
        )


@dataclass(frozen=True)
class PutBasicFromOpponentDiscardToBenchWithCounters(Effect):
    """相手のトラッシュのたねポケモンを1匹、相手のベンチに出し、そのポケモンにダメカンをcounters個のせる(Head Walking)。"""

    counters: int

    def execute(self, ctx: EffectContext) -> None:
        from effects.primitives import MoveBasicPokemonFromOpponentDiscardToTheirBench

        opponent = ctx.state.player(ctx.opponent)
        before = len(opponent.bench)
        MoveBasicPokemonFromOpponentDiscardToTheirBench().execute(ctx)
        pending = ctx.state.pending_search_choice
        if pending is not None:
            pending.remaining_script = (_CountersOnLastOpponentBenched(self.counters),)
        elif len(opponent.bench) > before:
            _CountersOnLastOpponentBenched(self.counters).execute(ctx)


@dataclass(frozen=True)
class _CountersOnLastOpponentBenched(Effect):
    counters: int

    def execute(self, ctx: EffectContext) -> None:
        opponent = ctx.state.player(ctx.opponent)
        if opponent.bench:
            put_counters(ctx, opponent.bench[-1], self.counters)


@dataclass(frozen=True)
class MoveOpponentBenchCountersFreely(Effect):
    """相手のベンチポケモンのダメカンを、相手の他のポケモンに好きなように移す(Damage Play)。ダメカンを1個ずつ、移す元と先を選ぶ。"""

    def execute(self, ctx: EffectContext) -> None:
        _move_opp_counter_start(ctx.state, ctx.card_db, ctx.acting_player, ctx.source_pokemon, ctx.source_card_id)


def _move_opp_counter_start(state, card_db, player_index: int, source_pokemon, source_card_id: str) -> None:
    opponent = state.player(1 - player_index)
    sources = [(i + 1, m) for i, m in enumerate(opponent.bench) if m.damage > 0]
    if not sources or len(opponent.all_pokemon_in_play()) < 2:
        return
    state.pending_search_choice = PendingSearchChoice(
        player_index=player_index,
        zone="gen_pokemon_pick",
        source_indices=[s for s, _ in sources],
        card_ids=[m.card_id for _, m in sources],
        min_count=0,
        max_count=1,
        prompt="ダメカンを移す元の相手のベンチポケモンを選ぶ(選ばなければ終了)",
        shuffle_after=False,
        all_card_ids=[m.card_id for _, m in sources],
        custom_data={"op": "opp_counter_pick_source"},
        cont_source_pokemon=source_pokemon,
        cont_source_card_id=source_card_id,
    )


def _op_opp_counter_pick_source(state, card_db, choice, selected, action, ctx, custom) -> bool:
    if not selected:
        return False
    opponent = state.player(1 - choice.player_index)
    slot = choice.source_indices[selected[0]]
    src = opponent.bench[slot - 1] if 1 <= slot <= len(opponent.bench) else None
    if src is None:
        return False
    dests = [(s, m) for s, m in _opp_slots(opponent) if m is not src]
    state.pending_search_choice = PendingSearchChoice(
        player_index=choice.player_index,
        zone="gen_pokemon_pick",
        source_indices=[s for s, _ in dests],
        card_ids=[m.card_id for _, m in dests],
        min_count=1,
        max_count=1,
        prompt="ダメカンを1個移す先の相手のポケモンを選ぶ",
        shuffle_after=False,
        all_card_ids=[m.card_id for _, m in dests],
        custom_data={"op": "opp_counter_pick_dest", "src_slot": slot},
        cont_source_pokemon=choice.cont_source_pokemon,
        cont_source_card_id=choice.cont_source_card_id,
    )
    return False


def _op_opp_counter_pick_dest(state, card_db, choice, selected, action, ctx, custom) -> bool:
    opponent = state.player(1 - choice.player_index)
    src_slot = custom["src_slot"]
    src = opponent.bench[src_slot - 1] if 1 <= src_slot <= len(opponent.bench) else None
    slot = choice.source_indices[selected[0]] if selected else None
    dest = (opponent.active if slot == 0 else opponent.bench[slot - 1]) if slot is not None and 0 <= slot <= len(opponent.bench) else None
    if src is not None and dest is not None and src.damage > 0:
        src.remove_counters(10)
        if not (_defender_blocks_effect(ctx, dest) or _blocks_damage_counters(dest)):
            dest.damage += 10
        state.add_log("ダメカンを1個移した")
    _move_opp_counter_start(state, card_db, choice.player_index, choice.cont_source_pokemon, choice.cont_source_card_id)
    return False


@dataclass(frozen=True)
class DevolveOwnBenchedAsManyAsYouLike(Effect):
    """自分のベンチの進化ポケモンを、好きなだけ何度でも1段階ずつ退化させ、外れた進化カードを手札に加える(Digital Reboot)。"""

    def execute(self, ctx: EffectContext) -> None:
        _devolve_own_bench_next(ctx.state, ctx.acting_player, ctx.source_pokemon, ctx.source_card_id)


def _devolve_own_bench_next(state, player_index: int, source_pokemon, source_card_id: str) -> None:
    player = state.player(player_index)
    slots = [(i + 1, m) for i, m in enumerate(player.bench) if m.evolution_history]
    if not slots:
        return
    state.pending_search_choice = PendingSearchChoice(
        player_index=player_index,
        zone="gen_pokemon_pick",
        source_indices=[s for s, _ in slots],
        card_ids=[m.card_id for _, m in slots],
        min_count=0,
        max_count=1,
        prompt="退化させる自分のベンチポケモンを選ぶ(選ばなければ終了)",
        shuffle_after=False,
        all_card_ids=[m.card_id for _, m in slots],
        custom_data={"op": "devolve_bench_pick"},
        cont_source_pokemon=source_pokemon,
        cont_source_card_id=source_card_id,
    )


def _op_devolve_bench_pick(state, card_db, choice, selected, action, ctx, custom) -> bool:
    if not selected:
        return False
    player = state.player(choice.player_index)
    slot = choice.source_indices[selected[0]]
    mon = player.bench[slot - 1] if 1 <= slot <= len(player.bench) else None
    if mon is not None and mon.evolution_history:
        player.hand.append(mon.card_id)
        mon.card_id = mon.evolution_history.pop()
        state.add_log("ベンチポケモンを1段階退化させ、進化後のカードを手札に加えた")
    _devolve_own_bench_next(state, choice.player_index, choice.cont_source_pokemon, choice.cont_source_card_id)
    return False


@dataclass(frozen=True)
class MoveToolBetweenPokemon(Effect):
    """どちらかのプレイヤーのポケモンについているどうぐ1枚を、そのプレイヤーの、どうぐのついていない別のポケモンに移す。移し先が無ければこのワザは何もしない(Trick)。"""

    def execute(self, ctx: EffectContext) -> None:
        candidates = []
        for side in (ctx.acting_player, ctx.opponent):
            player = ctx.state.player(side)
            slots = _own_slots(player)
            if any(m.attached_tool is None for _s, m in slots):
                for slot, mon in slots:
                    if mon.attached_tool is not None and not (side == ctx.opponent and _defender_blocks_effect(ctx, mon)):
                        candidates.append((side, slot, mon))
        if not candidates:
            return
        ctx.state.pending_search_choice = PendingSearchChoice(
            player_index=ctx.acting_player,
            zone="gen_pokemon_pick",
            source_indices=[(side, slot) for side, slot, _m in candidates],
            card_ids=[m.attached_tool for _s, _sl, m in candidates],
            min_count=1,
            max_count=1,
            prompt="移すどうぐを選ぶ(どうぐのついたポケモンを選ぶ)",
            shuffle_after=False,
            all_card_ids=[m.attached_tool for _s, _sl, m in candidates],
            custom_data={"op": "move_tool_pick_tool"},
        )


def _op_move_tool_pick_tool(state, card_db, choice, selected, action, ctx, custom) -> bool:
    if not selected:
        return False
    side, slot = choice.source_indices[selected[0]]
    owner = state.player(side)
    src = owner.active if slot == 0 else owner.bench[slot - 1]
    dests = [(s, m) for s, m in _own_slots(owner) if m.attached_tool is None and m is not src]
    if src is None or not dests:
        return False
    state.pending_search_choice = PendingSearchChoice(
        player_index=choice.player_index,
        zone="gen_pokemon_pick",
        source_indices=[s for s, _ in dests],
        card_ids=[m.card_id for _, m in dests],
        min_count=1,
        max_count=1,
        prompt="どうぐを移す先のポケモンを選ぶ",
        shuffle_after=False,
        all_card_ids=[m.card_id for _, m in dests],
        custom_data={"op": "move_tool_pick_dest", "side": side, "src_slot": slot},
    )
    return False


def _op_move_tool_pick_dest(state, card_db, choice, selected, action, ctx, custom) -> bool:
    owner = state.player(custom["side"])
    slot = custom["src_slot"]
    src = owner.active if slot == 0 else (owner.bench[slot - 1] if 1 <= slot <= len(owner.bench) else None)
    dslot = choice.source_indices[selected[0]] if selected else None
    dest = (owner.active if dslot == 0 else owner.bench[dslot - 1]) if dslot is not None and 0 <= dslot <= len(owner.bench) else None
    if src is not None and dest is not None and src.attached_tool is not None and dest.attached_tool is None:
        dest.attached_tool = src.attached_tool
        dest.attached_tool_owner = src.attached_tool_owner
        src.attached_tool = None
        src.attached_tool_owner = None
        state.add_log(f"どうぐを{src.card_id}から{dest.card_id}へ移した")
    return False


@dataclass(frozen=True)
class AttachOpponentDiscardEnergyToTheirPokemon(Effect):
    """相手のトラッシュのエネルギーカードを最大count枚、相手のポケモンに好きなようにつける(つけ先はこの効果を使うプレイヤーが決める)(Meddling)。"""

    count: int

    def execute(self, ctx: EffectContext) -> None:
        _opp_attach_next(ctx.state, ctx.card_db, ctx.acting_player, self.count, ctx.source_pokemon, ctx.source_card_id)


def _opp_attach_next(state, card_db, player_index: int, remaining: int, source_pokemon, source_card_id: str) -> None:
    opponent = state.player(1 - player_index)
    idx = [i for i, cid in enumerate(opponent.discard) if (c := card_db.get(cid)) is not None and c.is_energy]
    if remaining <= 0 or not idx or opponent.active is None and not opponent.bench:
        return
    state.pending_search_choice = PendingSearchChoice(
        player_index=player_index,
        zone="gen_energy_pick",
        source_indices=idx,
        card_ids=[opponent.discard[i] for i in idx],
        min_count=1,
        max_count=1,
        prompt=f"相手のトラッシュから、相手のポケモンにつけるエネルギーを選ぶ(あと{remaining}枚)",
        shuffle_after=False,
        all_card_ids=[opponent.discard[i] for i in idx],
        custom_data={"op": "opp_attach_pick_energy", "remaining": remaining},
        cont_source_pokemon=source_pokemon,
        cont_source_card_id=source_card_id,
    )


def _op_opp_attach_pick_energy(state, card_db, choice, selected, action, ctx, custom) -> bool:
    if not selected:
        return False
    opponent = state.player(1 - choice.player_index)
    discard_index = choice.source_indices[selected[0]]
    slots = _opp_slots(opponent)
    state.pending_search_choice = PendingSearchChoice(
        player_index=choice.player_index,
        zone="gen_pokemon_pick",
        source_indices=[s for s, _ in slots],
        card_ids=[m.card_id for _, m in slots],
        min_count=1,
        max_count=1,
        prompt="エネルギーをつける相手のポケモンを選ぶ",
        shuffle_after=False,
        all_card_ids=[m.card_id for _, m in slots],
        custom_data={"op": "opp_attach_pick_target", "discard_index": discard_index, "remaining": custom["remaining"]},
        cont_source_pokemon=choice.cont_source_pokemon,
        cont_source_card_id=choice.cont_source_card_id,
    )
    return False


def _op_opp_attach_pick_target(state, card_db, choice, selected, action, ctx, custom) -> bool:
    opponent = state.player(1 - choice.player_index)
    slot = choice.source_indices[selected[0]] if selected else None
    mon = (opponent.active if slot == 0 else opponent.bench[slot - 1]) if slot is not None and 0 <= slot <= len(opponent.bench) else None
    di = custom["discard_index"]
    if mon is not None and 0 <= di < len(opponent.discard):
        mon.attached_energy.append(opponent.discard.pop(di))
        state.add_log(f"相手のトラッシュのエネルギーを{mon.card_id}につけた")
    _opp_attach_next(state, card_db, choice.player_index, custom["remaining"] - 1, choice.cont_source_pokemon, choice.cont_source_card_id)
    return False


# ---------------------------------------------------------------------------------------------
# 汎用の選択の続きの登録
# ---------------------------------------------------------------------------------------------
def _register() -> None:
    from effects.era_primitives_b import GENERIC_CONTINUE_HANDLERS, GENERIC_OP_HANDLERS

    GENERIC_OP_HANDLERS.update({
        "discard_benched_damage": _op_discard_benched_damage,
        "shuffle_own_deck_if_picked": _op_shuffle_own_deck_if_picked,
        "either_deck_reorder_pick": _op_either_deck_reorder_pick,
        "either_deck_reorder_apply": _op_either_deck_reorder_apply,
        "coordinate_attach_tools": _op_coordinate_attach_tools,
        "move_self_energy_to_bench_pick_dest": _op_move_self_energy_pick_dest,
        "move_selected_energy_obj": _op_move_selected_energy_obj,
        "jag_attach_to": _op_jag_attach_to,
        "opp_counter_pick_source": _op_opp_counter_pick_source,
        "opp_counter_pick_dest": _op_opp_counter_pick_dest,
        "devolve_bench_pick": _op_devolve_bench_pick,
        "move_tool_pick_tool": _op_move_tool_pick_tool,
        "move_tool_pick_dest": _op_move_tool_pick_dest,
        "opp_attach_pick_energy": _op_opp_attach_pick_energy,
        "opp_attach_pick_target": _op_opp_attach_pick_target,
    })
    GENERIC_CONTINUE_HANDLERS.update({
        "heal_source_per_picked": _continue_heal_source_per_picked,
        "jag_energy_picked": _continue_jag_energy_picked,
    })


_register()


# ---------------------------------------------------------------------------------------------
# パート4: 数ターン続く効果・ロック(フラグを立てる効果と、エンジン側のフック)
# ---------------------------------------------------------------------------------------------
@dataclass(frozen=True)
class OpponentCannotPlayCardKindsNextTurn(Effect):
    """相手は次の番、手札から指定の種類のカード(tool/special_energy/stadium)を使えない(Chaos Wheel)。"""

    kinds: tuple

    def execute(self, ctx: EffectContext) -> None:
        opponent = ctx.state.player(ctx.opponent)
        until = opponent.turns_taken + 1
        if "tool" in self.kinds:
            opponent.tools_locked_until_turn = until
        if "special_energy" in self.kinds:
            opponent.special_energy_locked_until_turn = until
        if "stadium" in self.kinds:
            opponent.stadiums_locked_until_turn = until


@dataclass(frozen=True)
class LockBothPlayersSupportersAndStadiumsUntilEndOfNextTurn(Effect):
    """自分の次の番の終わりまで、おたがいに手札からサポートとスタジアムを使えない(Frigid Breath)。"""

    def execute(self, ctx: EffectContext) -> None:
        for side in (ctx.acting_player, ctx.opponent):
            player = ctx.state.player(side)
            until = player.turns_taken + 1
            player.supporters_locked_until_turn = max(player.supporters_locked_until_turn, until)
            player.stadiums_locked_until_turn = max(player.stadiums_locked_until_turn, until)


@dataclass(frozen=True)
class OpponentCannotEvolveNextTurn(Effect):
    """相手は次の番、手札のポケモンを使って自分のポケモンを進化させられない(Evolution Jammer)。"""

    def execute(self, ctx: EffectContext) -> None:
        opponent = ctx.state.player(ctx.opponent)
        opponent.evolve_locked_until_turn = opponent.turns_taken + 1


@dataclass(frozen=True)
class OpponentTrainerCoinFlipNextTurn(Effect):
    """相手が次の番に手札からトレーナーズを使うたび、相手がコインを投げ、ウラならそのカードは効果が無い(トラッシュはされる)(Dizzying Wind)。"""

    def execute(self, ctx: EffectContext) -> None:
        opponent = ctx.state.player(ctx.opponent)
        opponent.trainer_coin_until_turn = opponent.turns_taken + 1


@dataclass(frozen=True)
class DefenderDelayedRemoval(Effect):
    """相手の次の番の終わりに、このワザを受けたポケモンをきぜつさせる(mode="ko": Doom Desire)/ついているカードごとトラッシュする(mode="discard": Cacophony)。"""

    mode: str

    def execute(self, ctx: EffectContext) -> None:
        _, defender = _defender(ctx)
        if defender is None or _defender_blocks_effect(ctx, defender):
            return
        defender.delayed_removal_turn = ctx.state.player(ctx.opponent).turns_taken + 1
        defender.delayed_removal_mode = self.mode


@dataclass(frozen=True)
class DefenderAttackCostMoreNextTurn(Effect):
    """相手の次の番、このワザを受けたポケモンのワザのコストが無色attack個、にげるコストが無色retreat個ふえる(Sticky Shot/Slowing Beam)。"""

    attack: int = 0
    retreat: int = 0

    def execute(self, ctx: EffectContext) -> None:
        _, defender = _defender(ctx)
        if defender is None or _defender_blocks_effect(ctx, defender):
            return
        until = ctx.state.turn_number + 1
        if self.attack:
            defender.attack_cost_extra = self.attack
            defender.attack_cost_extra_until_turn_number = until
        if self.retreat:
            defender.retreat_cost_extra = self.retreat
            defender.retreat_cost_extra_until_turn_number = until


@dataclass(frozen=True)
class SurviveLethalNextTurnWithCoin(Effect):
    """コインを投げ、オモテなら、相手の次の番にこのポケモンがワザのダメージできぜつするとき、きぜつせず残りHPが10になる(Bide)。"""

    def execute(self, ctx: EffectContext) -> None:
        if ctx.source_pokemon is None:
            return
        if ctx.rng.random() < 0.5:
            ctx.log("コイン: オモテ")
            ctx.source_pokemon.bide_until_turn = ctx.state.player(ctx.opponent).turns_taken + 1
        else:
            ctx.log("コイン: ウラ")


@dataclass(frozen=True)
class SetKoRetaliateDiscardEnergyNextTurn(Effect):
    """相手の次の番、このポケモンがワザのダメージできぜつしたとき、攻撃したポケモンのエネルギーを1枚トラッシュする(Little Grudge)。"""

    def execute(self, ctx: EffectContext) -> None:
        if ctx.source_pokemon is not None:
            ctx.source_pokemon.ko_retaliate_discard_until_turn = ctx.state.player(ctx.opponent).turns_taken + 1


@dataclass(frozen=True)
class DefenderKnockedOutIfDamagedNextTurn(Effect):
    """自分の次の番、このワザを受けたポケモンがワザのダメージを受けたら、きぜつする(Allergic Shock)。"""

    def execute(self, ctx: EffectContext) -> None:
        _, defender = _defender(ctx)
        if defender is None or _defender_blocks_effect(ctx, defender):
            return
        defender.ko_if_damaged_until_turn = _attacker_player(ctx).turns_taken + 1


@dataclass(frozen=True)
class StatusImmuneSelfNextTurn(Effect):
    """相手の次の番、このポケモンは特殊状態にならない(Shining Breath)。"""

    def execute(self, ctx: EffectContext) -> None:
        if ctx.source_pokemon is not None:
            ctx.source_pokemon.status_immune_until_turn = ctx.state.player(ctx.opponent).turns_taken + 1


@dataclass(frozen=True)
class ConfuseDefenderWithCounters(Effect):
    """相手のバトルポケモンをこんらんにする。こんらんで自傷するときは、ダメカンをcounters個のせる(Heavy Perfume)。"""

    counters: int

    def execute(self, ctx: EffectContext) -> None:
        from effects.primitives import InflictStatusOnDefender

        _, defender = _defender(ctx)
        InflictStatusOnDefender("confused").execute(ctx)
        if defender is not None and defender.status.is_confused:
            defender.status.confusion_counters = self.counters


@dataclass(frozen=True)
class SetPersistentAttackBonusWhileActive(Effect):
    """このポケモンがバトル場にいる間、このポケモンのワザのダメージがbonus増える(重ねがけは不可)(Dragon Dance)。"""

    bonus: int

    def execute(self, ctx: EffectContext) -> None:
        mon = ctx.source_pokemon
        if mon is not None:
            mon.persistent_attack_bonus = self.bonus
            mon.persistent_bonus_became_active_turn = mon.became_active_turn


@dataclass(frozen=True)
class DefenderSleepsIfEnergyAttachedNextTurn(Effect):
    """相手が次の番に、手札からこのワザを受けたポケモンにエネルギーをつけたら、そのポケモンはねむりになる(Boo-Hoo)。"""

    def execute(self, ctx: EffectContext) -> None:
        _, defender = _defender(ctx)
        if defender is None or _defender_blocks_effect(ctx, defender):
            return
        defender.sleep_on_attach_until_turn = ctx.state.player(ctx.opponent).turns_taken + 1


@dataclass(frozen=True)
class SetDefenderWeaknessType(Effect):
    """自分の次の番の終わりまで、このワザを受けたポケモンの弱点のタイプを指定のタイプにする(弱点の数値は変わらない)(Trick Sticker)。"""

    weakness_type: str

    def execute(self, ctx: EffectContext) -> None:
        _, defender = _defender(ctx)
        if defender is None or _defender_blocks_effect(ctx, defender):
            return
        defender.weakness_override_type = self.weakness_type
        defender.weakness_override_until_turn_number = ctx.state.turn_number + 2


@dataclass(frozen=True)
class ChooseDefenderWeaknessType(Effect):
    """タイプを1つ選び、自分の次の番の終わりまで、このワザを受けたポケモンの弱点をそのタイプにする(Conversion 3)。"""

    TYPE_NAMES = ("Grass", "Fire", "Water", "Lightning", "Psychic", "Fighting", "Darkness", "Metal", "Fairy", "Dragon")

    def execute(self, ctx: EffectContext) -> None:
        ctx.state.pending_search_choice = PendingSearchChoice(
            player_index=ctx.acting_player,
            zone="gen_pokemon_pick",
            source_indices=list(range(len(self.TYPE_NAMES))),
            card_ids=list(self.TYPE_NAMES),
            min_count=1,
            max_count=1,
            prompt="弱点にするタイプを選ぶ",
            shuffle_after=False,
            all_card_ids=list(self.TYPE_NAMES),
            custom_data={"op": "choose_weakness_type", "types": self.TYPE_NAMES},
            cont_source_pokemon=ctx.source_pokemon,
            cont_source_card_id=ctx.source_card_id,
        )


def _op_choose_weakness_type(state, card_db, choice, selected, action, ctx, custom) -> bool:
    if not selected:
        return False
    chosen = custom["types"][choice.source_indices[selected[0]]]
    opponent = state.player(1 - choice.player_index)
    defender = opponent.active
    if defender is not None:
        defender.weakness_override_type = chosen
        defender.weakness_override_until_turn_number = state.turn_number + 2
        state.add_log(f"相手のバトルポケモンの弱点が{chosen}になった")
    return False


@dataclass(frozen=True)
class DrawUsableOnFirstTurnIfFirstPlayer(Effect):
    """先攻のときは、最初の自分の番でも使えるワザ。カードをcount枚引く(Close Encounter)。"""

    count: int
    usable_on_first_turn_if_first_player = True

    def execute(self, ctx: EffectContext) -> None:
        from effects.primitives import Draw

        Draw(self.count).execute(ctx)


@dataclass(frozen=True)
class UsableOnlyOnFirstTurnIfSecond(Effect):
    """後攻のときの、最初の自分の番にしか使えないワザであることを表す印(Stall)。何もしない。"""

    usable_only_first_turn_if_second = True

    def execute(self, ctx: EffectContext) -> None:
        return


# ---------------------------------------------------------------------------------------------
# エンジンから呼ばれるフック
# ---------------------------------------------------------------------------------------------
def era_defender_final_damage(ctx: EffectContext, defender, defender_card, damage: int) -> int:
    """防御側のダメージ軽減などを全て適用した後の最終ダメージに対する、数ターン続く効果(Bide/Allergic Shock)。"""
    if damage <= 0:
        return damage
    turns = ctx.state.player(ctx.acting_player).turns_taken
    if defender.ko_if_damaged_until_turn > 0 and turns <= defender.ko_if_damaged_until_turn:
        ctx.log("「Allergic Shock」の効果で、ダメージを受けたポケモンはきぜつする")
        return max(damage, (defender_card.hp or 0) - defender.damage + 10)
    if defender.extra_damage_taken and defender.extra_damage_taken_turn == turns:
        damage += defender.extra_damage_taken  # 「相手の次の番、このポケモンはワザのダメージをN多く受ける」
    if defender.bide_until_turn > 0 and turns <= defender.bide_until_turn and defender_card.hp:
        if defender.damage + damage >= defender_card.hp and defender.damage < defender_card.hp - 10:
            ctx.log("「Bide」の効果で、きぜつせず残りHPが10になった")
            return max(0, defender_card.hp - 10 - defender.damage)
    return damage


def era_attacker_bonus(ctx: EffectContext, attacker_mon, attacker_owner) -> int:
    """このポケモンがバトル場にいる間続くワザの追加ダメージ(Dragon Dance)。"""
    if (
        attacker_mon.persistent_attack_bonus
        and attacker_mon is attacker_owner.active
        and attacker_mon.persistent_bonus_became_active_turn == attacker_mon.became_active_turn
    ):
        return attacker_mon.persistent_attack_bonus
    return 0


def era_weakness_override(state, defender_card, defender):
    """Conversion 3/Trick Sticker: 弱点のタイプを書き換える(数値はそのまま)。"""
    from dataclasses import replace

    if defender.weakness_override_type and state.turn_number <= defender.weakness_override_until_turn_number and defender_card.weaknesses:
        return replace(
            defender_card,
            weaknesses=tuple(type(w)(type=defender.weakness_override_type, value=w.value) for w in defender_card.weaknesses),
        )
    return defender_card


def era_attack_cost_extra(mon, turn_number: int) -> int:
    return mon.attack_cost_extra if mon.attack_cost_extra and turn_number <= mon.attack_cost_extra_until_turn_number else 0


def era_retreat_cost_extra(mon, turn_number: int) -> int:
    return mon.retreat_cost_extra if mon.retreat_cost_extra and turn_number <= mon.retreat_cost_extra_until_turn_number else 0


def era_status_immune(state, owner_index: int, mon) -> bool:
    """Shining Breath: 相手の次の番、特殊状態にならない。"""
    return mon.status_immune_until_turn > 0 and state.player(1 - owner_index).turns_taken <= mon.status_immune_until_turn


def era_on_energy_attached_to(state, player, target) -> None:
    """Boo-Hoo: 相手が手札からエネルギーをつけたポケモンは、ねむりになる。"""
    from engine.status import ExclusiveCondition

    if target.sleep_on_attach_until_turn > 0 and player.turns_taken <= target.sleep_on_attach_until_turn:
        target.status.apply_exclusive(ExclusiveCondition.ASLEEP)
        state.add_log("「Boo-Hoo」の効果で、エネルギーをつけられたポケモンはねむりになった")


def era_end_of_turn_removals(state, card_db) -> None:
    """ターン終了時: 「相手の次の番の終わりに、きぜつする/トラッシュされる」効果(Doom Desire/Cacophony)。現在のプレイヤーのポケモンを調べる。"""
    player = state.player(state.current_player)
    for mon in player.all_pokemon_in_play():
        if mon.delayed_counters and mon.delayed_counters_turn == player.turns_taken:
            from effects.primitives import _blocks_damage_counters

            n = mon.delayed_counters
            mon.delayed_counters = 0
            mon.delayed_counters_turn = 0
            if not _blocks_damage_counters(mon):
                mon.damage += n * 10
                state.add_log(f"{mon.card_id} にダメカンを{n}個のせた(ワザの効果)")
        if mon.delayed_removal_turn and mon.delayed_removal_turn == player.turns_taken:
            mode = mon.delayed_removal_mode
            mon.delayed_removal_turn = 0
            mon.delayed_removal_mode = ""
            mon.damage = 9999
            if mode == "discard":
                mon.no_prize_on_ko_until_turn = 10**9  # トラッシュされるだけで、きぜつではない(サイドは取られない)
            state.add_log(f"{mon.card_id} はターンの終わりに{'きぜつした' if mode == 'ko' else 'トラッシュされた'}")


def era_trainer_coin_blocks(state, actor: int) -> bool:
    """Dizzying Wind: このプレイヤーが手札からトレーナーズを使うとき、コインがウラならその効果は無い。"""
    player = state.player(actor)
    if player.trainer_coin_until_turn > 0 and player.turns_taken <= player.trainer_coin_until_turn:
        heads = state.rng.random() < 0.5
        state.add_log("「Dizzying Wind」: コイン " + ("オモテ" if heads else "ウラ。そのカードは効果が無い"))
        return not heads
    return False


def era_reset_turn_marks(state) -> None:
    """ターンの始まりに、「このターンの間」の印を消す(回復したか等)。"""
    for side in (0, 1):
        for mon in state.player(side).all_pokemon_in_play():
            mon.__dict__.pop("healed_this_turn", None)


def era_ko_retaliate(state, card_db, actor: int, mon) -> None:
    """Little Grudge: ワザのダメージできぜつしたポケモンが、攻撃したポケモンのエネルギーを1枚トラッシュする。"""
    attacker = state.player(actor).active
    if (
        mon.ko_retaliate_discard_until_turn > 0
        and state.player(actor).turns_taken <= mon.ko_retaliate_discard_until_turn
        and attacker is not None
        and attacker.attached_energy
    ):
        state.player(actor).discard.append(attacker.attached_energy.pop())
        state.add_log("「Little Grudge」の効果で、攻撃したポケモンのエネルギーを1枚トラッシュした")


def _register_flags() -> None:
    from effects.era_primitives_b import GENERIC_OP_HANDLERS

    GENERIC_OP_HANDLERS["choose_weakness_type"] = _op_choose_weakness_type


_register_flags()


# ---------------------------------------------------------------------------------------------
# パート5: 他のカードのワザ・サポートを使う
# ---------------------------------------------------------------------------------------------
@dataclass(frozen=True)
class CopyChosenOpponentPokemonAttack(Effect):
    """相手の場のポケモンが持つワザを1つ選び、このワザとして使う(Phantom Gate)。コストは必要ない(このワザのコストを払っているため)。"""

    chooses_opponent_attack = False

    def execute(self, ctx: EffectContext) -> None:
        from effects.era_primitives_e import _offer_options, _revealed_options_for_card

        opponent = ctx.state.player(ctx.opponent)
        option_cards: list = []
        options: list = []
        seen = set()
        for _slot, mon in _opp_slots(opponent):
            if mon.card_id in seen:
                continue
            seen.add(mon.card_id)
            card = ctx.card_db.get(mon.card_id)
            if card is None or not card.attacks:
                continue
            for opt in _revealed_options_for_card(ctx, mon.card_id, card, reentrant_effect=self):
                options.append(opt)
                option_cards.append(mon.card_id)
        _offer_options(ctx, option_cards, options, "相手のポケモンのワザを1つ選んで使う")


@dataclass(frozen=True)
class CopyPreviousEvolutionAttack(Effect):
    """このポケモンの、進化前のポケモンのワザを1つ選び、このワザとして使う(Recall)。"""

    def execute(self, ctx: EffectContext) -> None:
        from effects.era_primitives_e import _offer_options, _revealed_options_for_card

        mon = ctx.source_pokemon
        if mon is None:
            return
        option_cards: list = []
        options: list = []
        for card_id in dict.fromkeys(mon.evolution_history):
            card = ctx.card_db.get(card_id)
            if card is None or not card.attacks:
                continue
            for opt in _revealed_options_for_card(ctx, card_id, card):
                options.append(opt)
                option_cards.append(card_id)
        _offer_options(ctx, option_cards, options, "進化前のポケモンのワザを1つ選んで使う")


@dataclass(frozen=True)
class CopyOpponentLastAttack(Effect):
    """相手のポケモンが、相手の前の番にワザを使っていれば、そのワザをこのワザとして使う(Watch and Learn)。"""

    def execute(self, ctx: EffectContext) -> None:
        from effects.primitives import run_borrowed_attack_script

        opponent = ctx.state.player(ctx.opponent)
        used = opponent.last_attack_used
        if not used:
            ctx.log("相手の前の番にワザは使われていない")
            return
        card_id, attack_name = used
        run_borrowed_attack_script(ctx, card_id, attack_name)


@dataclass(frozen=True)
class UseEffectOfOpponentDiscardSupporter(Effect):
    """相手のトラッシュにあるサポートを1枚選び、そのカードの効果を、このワザの効果として使う(Bewitching Eyes)。"""

    def execute(self, ctx: EffectContext) -> None:
        opponent = ctx.state.player(ctx.opponent)
        idx = [i for i, cid in enumerate(opponent.discard) if (c := ctx.card_db.get(cid)) is not None and c.is_supporter]
        if not idx:
            return
        ctx.state.pending_search_choice = PendingSearchChoice(
            player_index=ctx.acting_player,
            zone="gen_hand_pick",
            source_indices=idx,
            card_ids=[opponent.discard[i] for i in idx],
            min_count=1,
            max_count=1,
            prompt="相手のトラッシュのサポートを1枚選び、その効果を使う",
            shuffle_after=False,
            all_card_ids=[opponent.discard[i] for i in idx],
            custom_data={"op": "use_opp_discard_supporter"},
            cont_source_pokemon=ctx.source_pokemon,
            cont_source_card_id=ctx.source_card_id,
        )


def _op_use_opp_discard_supporter(state, card_db, choice, selected, action, ctx, custom) -> bool:
    from effects.interpreter import run_script
    from effects.registry import get_trainer_script

    if not selected:
        return False
    opponent = state.player(1 - choice.player_index)
    card_id = choice.card_ids[selected[0]]
    sub_ctx = EffectContext(
        state=state, card_db=card_db, acting_player=choice.player_index, source_pokemon=None,
        source_card_id=card_id, target_bench_index=None, rng=state.rng,
    )
    state.add_log(f"相手のトラッシュのサポート「{card_id}」の効果を使った")
    run_script(get_trainer_script(card_id), sub_ctx)
    _ = opponent
    return False


def _register_part5() -> None:
    from effects.era_primitives_b import GENERIC_OP_HANDLERS

    GENERIC_OP_HANDLERS["use_opp_discard_supporter"] = _op_use_opp_discard_supporter


_register_part5()


# ---------------------------------------------------------------------------------------------
# パート6: トレーナーズ(XY4〜XY12・ダブルクライシス・Generations)
# ---------------------------------------------------------------------------------------------
@dataclass(frozen=True)
class DiscardCardThenLookTopTakeOne(Effect):
    """手札を1枚トラッシュして(できなければ使えない)、山札の上からn枚を見て、1枚を手札に加える。残りは山札に戻してシャッフルする(カスミの決意)。"""

    n: int

    def execute(self, ctx: EffectContext) -> None:
        player = _attacker_player(ctx)
        if not player.hand:
            return
        ctx.state.pending_search_choice = PendingSearchChoice(
            player_index=ctx.acting_player,
            zone="hand",
            source_indices=list(range(len(player.hand))),
            card_ids=list(player.hand),
            min_count=1,
            max_count=1,
            prompt="トラッシュする手札を1枚選ぶ",
            shuffle_after=False,
            all_card_ids=list(player.hand),
            destination="discard",
            remaining_script=(LookTopNTakeOneShuffleRest(self.n),),
            effect_source=ctx.effect_source,
        )


@dataclass(frozen=True)
class DiscardCardThenDrawBonusIfSubtype(Effect):
    """手札を1枚トラッシュして(できなければ使えない)draw枚引く。トラッシュしたのが指定サブタイプのポケモンならbonus枚多く引く(チームアクア団/マグマ団のしたっぱ)。"""

    draw: int
    bonus: int
    subtype: str

    def execute(self, ctx: EffectContext) -> None:
        player = _attacker_player(ctx)
        if not player.hand:
            return
        ctx.state.pending_search_choice = PendingSearchChoice(
            player_index=ctx.acting_player,
            zone="hand",
            source_indices=list(range(len(player.hand))),
            card_ids=list(player.hand),
            min_count=1,
            max_count=1,
            prompt="トラッシュする手札を1枚選ぶ",
            shuffle_after=False,
            all_card_ids=list(player.hand),
            destination="discard",
            custom_data={"mode": "gen_continue", "op": "draw_with_subtype_bonus", "draw": self.draw, "bonus": self.bonus, "subtype": self.subtype},
            effect_source=ctx.effect_source,
        )


def _continue_draw_with_subtype_bonus(ctx, choice, custom, picked_card_ids) -> None:
    from effects.primitives import Draw

    if not picked_card_ids:
        return
    card = ctx.card_db.get(picked_card_ids[0])
    extra = custom["bonus"] if card is not None and card.is_pokemon and card_has_subtype(card, custom["subtype"]) else 0
    Draw(custom["draw"] + extra).execute(ctx)


@dataclass(frozen=True)
class EachPlayerShufflesDiscardIntoDeck(Effect):
    """おたがいに、トラッシュのカードを全て山札に戻してシャッフルする(使ったこのカードは含まない=まだトラッシュに無い)(Lysandre's Trump Card)。"""

    def execute(self, ctx: EffectContext) -> None:
        for side in (ctx.acting_player, ctx.opponent):
            player = ctx.state.player(side)
            if player.discard:
                player.deck.extend(player.discard)
                player.discard = []
                ctx.rng.shuffle(player.deck)


@dataclass(frozen=True)
class AttachBasicEnergyFromDiscardToActiveSubtype(Effect):
    """トラッシュの基本エネルギー1枚を、自分のバトルポケモン(指定サブタイプのもの)につける(チームアクア団のアクア)。"""

    subtype: str

    def execute(self, ctx: EffectContext) -> None:
        player = _attacker_player(ctx)
        active = player.active
        card = ctx.card_db.get(active.card_id) if active is not None else None
        if active is None or not card_has_subtype(card, self.subtype):
            return
        from effects.primitives import _trigger_search_choice

        _trigger_search_choice(
            ctx, player, "discard", lambda c: c is not None and c.is_energy and not c.is_special_energy, 1,
            "トラッシュから基本エネルギーを選んでバトルポケモンにつける", shuffle_after=False, destination="attach_energy",
        )
        pending = ctx.state.pending_search_choice
        if pending is not None:
            pending.attach_target_pokemon = active


@dataclass(frozen=True)
class SearchDiscardForNamedCardsToHand(Effect):
    """トラッシュから、指定した名前のカードを合計最大count枚、手札に加える(化石発掘キット)。"""

    names: tuple
    count: int

    def execute(self, ctx: EffectContext) -> None:
        from effects.primitives import _trigger_search_choice

        _trigger_search_choice(
            ctx, _attacker_player(ctx), "discard", lambda c: c is not None and c.name in self.names, self.count,
            "トラッシュからカードを選んで手札に加える", shuffle_after=False,
        )


@dataclass(frozen=True)
class ShuffleKindFromDiscardIntoDeck(Effect):
    """トラッシュから、指定の種類(pokemon_tool/basic_energy)のカードを、ちょうどcount枚(足りなければあるだけ)選んで山札に戻してシャッフルする(エコアーム)。"""

    kind: str
    count: int
    up_to: bool = False  # True: 「最大count枚」(0枚でもよい)

    def execute(self, ctx: EffectContext) -> None:
        from effects.primitives import _trigger_search_choice

        def ok(c):
            if c is None:
                return False
            if self.kind == "pokemon_tool":
                return c.is_pokemon_tool
            if self.kind == "water_pokemon":
                return c.is_pokemon and "Water" in c.types
            if self.kind == "basic_water_energy":
                return c.is_energy and not c.is_special_energy and c.basic_energy_type == "Water"
            return c.is_energy and not c.is_special_energy

        _trigger_search_choice(
            ctx, _attacker_player(ctx), "discard", ok, self.count, "トラッシュから山札に戻すカードを選ぶ",
            shuffle_after=True, destination="deck", min_count=0 if self.up_to else self.count,
        )


@dataclass(frozen=True)
class ReturnAnyOwnEnergyToHand(Effect):
    """自分のポケモンについているエネルギーを、好きな枚数、手札に戻す(エナジーリセット)。"""

    def execute(self, ctx: EffectContext) -> None:
        player = _attacker_player(ctx)
        entries = []
        ids = []
        for slot, mon in _own_slots(player):
            for ei, e in enumerate(mon.attached_energy):
                entries.append((slot, ei))
                ids.append(e)
        if not entries:
            return
        ctx.state.pending_search_choice = PendingSearchChoice(
            player_index=ctx.acting_player,
            zone="gen_energy_pick",
            source_indices=list(range(len(entries))),
            card_ids=ids,
            min_count=0,
            max_count=len(entries),
            prompt="手札に戻すエネルギーを好きな枚数選ぶ",
            shuffle_after=False,
            all_card_ids=list(ids),
            custom_data={"op": "return_own_energy_to_hand", "entries": entries},
        )


def _op_return_own_energy_to_hand(state, card_db, choice, selected, action, ctx, custom) -> bool:
    from effects.era_primitives_b import _mon_at

    player = state.player(choice.player_index)
    picked = sorted((custom["entries"][choice.source_indices[p]] for p in selected), key=lambda t: (t[0], t[1]), reverse=True)
    for slot, ei in picked:
        mon = _mon_at(player, slot)
        if mon is not None and 0 <= ei < len(mon.attached_energy):
            player.hand.append(mon.attached_energy.pop(ei))
    return False


@dataclass(frozen=True)
class PutOpponentHandBasicsOnTheirBench(Effect):
    """相手の手札を公開させ、その中のたねポケモンを好きな数、相手のベンチに出す(キュートなポフレ)。
    max_hp指定時はHPがその値以下のたねポケモンだけ、limit指定時は最大その匹数まで(Look for Prey: HP70以下を1匹)。"""

    max_hp: int | None = None
    limit: int | None = None

    def execute(self, ctx: EffectContext) -> None:
        from engine.continuous import effective_bench_limit

        opponent = ctx.state.player(ctx.opponent)
        _attacker_player(ctx).known_opponent_hand = list(opponent.hand)
        ctx.reveal("相手の手札", list(opponent.hand))
        space = effective_bench_limit(ctx.state, opponent, ctx.card_db) - len(opponent.bench)
        idx = [
            i for i, cid in enumerate(opponent.hand)
            if (c := ctx.card_db.get(cid)) is not None and c.is_basic and (self.max_hp is None or (c.hp or 0) <= self.max_hp)
        ]
        if space <= 0 or not idx:
            return
        ctx.state.pending_search_choice = PendingSearchChoice(
            player_index=ctx.acting_player,
            zone="gen_hand_pick",
            source_indices=idx,
            card_ids=[opponent.hand[i] for i in idx],
            min_count=0,
            max_count=min(space, len(idx), self.limit or len(idx)),
            prompt="相手のベンチに出す、相手の手札のたねポケモンを好きな数選ぶ",
            shuffle_after=False,
            all_card_ids=list(opponent.hand),
            custom_data={"op": "put_opp_basics_on_bench"},
        )


def _op_put_opp_basics_on_bench(state, card_db, choice, selected, action, ctx, custom) -> bool:
    from engine.state import PokemonInPlay

    opponent = state.player(1 - choice.player_index)
    for i in sorted((choice.source_indices[p] for p in selected), reverse=True):
        if 0 <= i < len(opponent.hand):
            cid = opponent.hand.pop(i)
            opponent.bench.append(PokemonInPlay(card_id=cid, turn_played=opponent.turns_taken))
            state.add_log(f"相手の手札の{cid}を相手のベンチに出した")
    return False


@dataclass(frozen=True)
class EachPlayerPutsPokemonFromDiscardToHand(Effect):
    """おたがいに、自分のトラッシュのポケモンを1匹選んで手札に加える(相手が先に選ぶ)(なかよしレスキュー)。"""

    opponent_done: bool = False

    def execute(self, ctx: EffectContext) -> None:
        if self.opponent_done:
            # 相手の選択の続き: 続き(remaining_script)は元の効果を使った側(ctx.acting_player)として実行される
            self._pick_for(ctx, ctx.acting_player, ())
            return
        self._pick_for(ctx, ctx.opponent, (EachPlayerPutsPokemonFromDiscardToHand(True),))
        if ctx.state.pending_search_choice is None:
            self._pick_for(ctx, ctx.acting_player, ())

    def _pick_for(self, ctx: EffectContext, side: int, rest) -> None:
        player = ctx.state.player(side)
        idx = [i for i, cid in enumerate(player.discard) if (c := ctx.card_db.get(cid)) is not None and c.is_pokemon]
        if not idx:
            return
        ctx.state.pending_search_choice = PendingSearchChoice(
            player_index=side,
            zone="discard",
            source_indices=idx,
            card_ids=[player.discard[i] for i in idx],
            min_count=1,
            max_count=1,
            prompt="トラッシュのポケモンを1匹選んで手札に加える",
            shuffle_after=False,
            all_card_ids=list(player.discard),
            destination="hand",
            remaining_script=tuple(rest),
        )


@dataclass(frozen=True)
class TurnAllPrizesFaceUpBothPlayers(Effect):
    """おたがいのサイドを全て表向きにする(以後ずっと表向き)(ロケット団参上!)。"""

    def execute(self, ctx: EffectContext) -> None:
        from effects.primitives import TurnPrizesFaceUp

        for side in (ctx.acting_player, ctx.opponent):
            sub = EffectContext(
                state=ctx.state, card_db=ctx.card_db, acting_player=side, source_pokemon=None, source_card_id=ctx.source_card_id, rng=ctx.rng,
            )
            TurnPrizesFaceUp().execute(sub)


@dataclass(frozen=True)
class DrawPerOpponentBenchedBasic(Effect):
    """相手のベンチのたねポケモン1匹につき1枚引く(ミモザの特技)。"""

    def execute(self, ctx: EffectContext) -> None:
        from effects.primitives import Draw

        n = sum(1 for m in ctx.state.player(ctx.opponent).bench if (c := ctx.card_db.get(m.card_id)) is not None and c.is_basic)
        if n:
            Draw(n).execute(ctx)


@dataclass(frozen=True)
class RemoveSleepAndHealActive(Effect):
    """自分のバトルポケモンがねむりなら、ねむりを治して、そのポケモンのダメージをhealぶん回復する(オールナイトパーティ)。"""

    heal: int

    def execute(self, ctx: EffectContext) -> None:
        from engine.status import ExclusiveCondition

        active = _attacker_player(ctx).active
        if active is not None and active.status.exclusive == ExclusiveCondition.ASLEEP:
            active.status.exclusive = ExclusiveCondition.NONE
            active.heal(self.heal)


@dataclass(frozen=True)
class ChooseOneEffectBranch(Effect):
    """いくつかの効果から1つを選んで行う(ジオヴァンニのたくらみ: "Choose 1")。labelsは選択肢の表示名、branchesは各選択肢の効果。"""

    labels: tuple
    branches: tuple

    def execute(self, ctx: EffectContext) -> None:
        ctx.state.pending_search_choice = PendingSearchChoice(
            player_index=ctx.acting_player,
            zone="gen_pokemon_pick",
            source_indices=list(range(len(self.labels))),
            card_ids=list(self.labels),
            min_count=1,
            max_count=1,
            prompt="行う効果を1つ選ぶ",
            shuffle_after=False,
            all_card_ids=list(self.labels),
            custom_data={"op": "choose_one_branch", "branches": self.branches},
            effect_source=ctx.effect_source,
        )


def _op_choose_one_branch(state, card_db, choice, selected, action, ctx, custom) -> bool:
    from effects.interpreter import run_script

    if selected:
        run_script(tuple(custom["branches"][choice.source_indices[selected[0]]]), ctx)
    return False


def _register_part6() -> None:
    from effects.era_primitives_b import GENERIC_CONTINUE_HANDLERS, GENERIC_OP_HANDLERS

    GENERIC_OP_HANDLERS.update({
        "return_own_energy_to_hand": _op_return_own_energy_to_hand,
        "put_opp_basics_on_bench": _op_put_opp_basics_on_bench,
        "choose_one_branch": _op_choose_one_branch,
    })
    GENERIC_CONTINUE_HANDLERS["draw_with_subtype_bonus"] = _continue_draw_with_subtype_bonus


_register_part6()
