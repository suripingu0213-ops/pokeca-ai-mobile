"""メガ時代(ME・SV10〜)と一部SM/XYのトレーナーズ(グッズ・サポート・スタジアム・どうぐ)・特殊エネルギーの実装(2026-10-07)。

effects/era_trainer_specs.py のキーとカードIDの対応(effects/generated_era_trainer_ids.py)を使い、install()が
effects.registry の各テーブルと、エンジンのフック(effects/era_trainers.py経由)に登録する。
"""

from __future__ import annotations

from dataclasses import dataclass

from effects.context import EffectContext
from effects.generated_era_trainer_ids import IDS
from effects.primitives import Effect, _attacker_player, _trigger_search_choice
from engine.state import PendingSearchChoice


def _ids(key: str) -> tuple:
    return tuple(card_id for card_id, _tag in IDS.get(key, ()))


MYSTERY_GARDEN_IDS = frozenset(_ids("mystery_garden"))
SURFING_BEACH_IDS = frozenset(_ids("surfing_beach"))
LUMIOSE_CITY_IDS = frozenset(_ids("lumiose_city"))
FOSSIL_QUARRY_IDS = frozenset(_ids("fossil_quarry"))
DIZZYING_VALLEY_IDS = frozenset(_ids("dizzying_valley"))
NIGHTTIME_MINE_IDS = frozenset(_ids("nighttime_mine"))
GRANITE_CAVE_IDS = frozenset(_ids("granite_cave"))
POSTWICK_IDS = frozenset(_ids("postwick"))
THUNDER_MOUNTAIN_IDS = frozenset(_ids("thunder_mountain"))
ANGE_FLOETTE_IDS = frozenset(_ids("ange_floette"))
PRISM_TOWER_IDS = frozenset(("me4-80", "me4-111"))  # Prism Tower(Ange Floetteを出す条件)


# ---------------------------------------------------------------------------------------------
# サポート・グッズの効果
# ---------------------------------------------------------------------------------------------
@dataclass(frozen=True)
class LtSurgesBargain(Effect):
    """マチスのとりひき: 相手が「おたがいにサイドを1枚とる」か「使った人が山札を4枚引く」かを選ぶ(Lt. Surge's Bargain)。"""

    def execute(self, ctx: EffectContext) -> None:
        labels = ("はい: おたがいにサイドを1枚とる", "いいえ: 相手(カードを使った人)が山札を4枚引く")
        ctx.state.pending_search_choice = PendingSearchChoice(
            player_index=ctx.opponent,
            zone="gen_pokemon_pick",
            source_indices=[0, 1],
            card_ids=list(labels),
            min_count=1,
            max_count=1,
            prompt="マチスのとりひき: おたがいにサイドを1枚とってよいか選ぶ",
            shuffle_after=False,
            all_card_ids=list(labels),
            custom_data={"op": "lt_surge_bargain", "user": ctx.acting_player},
            effect_source=ctx.effect_source,
        )


def _op_lt_surge_bargain(state, card_db, choice, selected, action, ctx, custom) -> bool:
    user = custom["user"]
    if selected and choice.source_indices[selected[0]] == 0:
        for index in (user, 1 - user):
            player = state.player(index)
            if player.prizes:
                player.hand.append(player.take_prize())
        state.add_log("マチスのとりひき: おたがいにサイドを1枚とった")
    else:
        from effects.primitives import Draw

        Draw(4).execute(EffectContext(state=state, card_db=card_db, acting_player=user, source_pokemon=None, source_card_id="", rng=state.rng))
        state.add_log("マチスのとりひき: カードを使った人が山札を4枚引いた")
    return False


@dataclass(frozen=True)
class LookTopNBenchThenRestToBottom(Effect):
    """山札の上からn枚を見て、(たねの)指定タイプのポケモンを1匹ベンチに出し、残りをシャッフルして山札の下に置く(Grimsley's Move)。"""

    n: int
    ptype: str

    def execute(self, ctx: EffectContext) -> None:
        from engine.continuous import effective_bench_limit

        player = _attacker_player(ctx)
        seen = player.deck[: self.n]
        del player.deck[: self.n]
        eligible = [cid for cid in seen if (c := ctx.card_db.get(cid)) is not None and c.is_pokemon and c.is_basic and self.ptype in c.types]
        others = list(seen)
        space = effective_bench_limit(ctx.state, player, ctx.card_db) - len(player.bench)
        if not eligible or space <= 0:
            ctx.rng.shuffle(others)
            player.deck.extend(others)
            ctx.log("山札の上から見たカードをシャッフルして山札の下に置いた")
            return
        for cid in eligible:
            others.remove(cid)
        ctx.rng.shuffle(others)
        player.deck[0:0] = eligible  # 候補は山札の先頭に戻して選ばせる(選ばなかった候補は山札の下に送られる)
        player.deck.extend(others)
        ctx.state.pending_search_choice = PendingSearchChoice(
            player_index=ctx.acting_player,
            zone="deck",
            source_indices=list(range(len(eligible))),
            card_ids=list(eligible),
            min_count=1,
            max_count=1,
            prompt=f"山札の上から見た{self.ptype}ポケモンを1匹、ベンチに出す",
            shuffle_after=False,
            all_card_ids=list(eligible),
            destination="bench",
            remaining_to_bottom=True,
            effect_source=ctx.effect_source,
            source_card_id=ctx.source_card_id,
        )


@dataclass(frozen=True)
class DiscardChosenOpponentToolOrSpecialEnergy(Effect):
    """相手の場のポケモン1匹についている、どうぐまたは特殊エネルギーを1枚選んでトラッシュする(Blowtorch)。"""

    def execute(self, ctx: EffectContext) -> None:
        from effects.primitives import _field_attachment_candidates

        source_indices, card_ids = _field_attachment_candidates(
            ctx.state, ctx.card_db, (ctx.opponent,), include_tool=True, energy_predicate=lambda c: c.is_special_energy
        )
        if not card_ids:
            ctx.log("相手の場にトラッシュできるどうぐ/特殊エネルギーが無い")
            return
        ctx.state.pending_search_choice = PendingSearchChoice(
            player_index=ctx.acting_player,
            zone="field_attachment",
            source_indices=source_indices,
            card_ids=card_ids,
            min_count=1,
            max_count=1,
            prompt="トラッシュする相手のどうぐ/特殊エネルギーを選ぶ",
            shuffle_after=False,
            all_card_ids=list(card_ids),
            destination="discard",
        )


@dataclass(frozen=True)
class RevealOpponentHandChosenEnergyToBottom(Effect):
    """相手の手札を公開させ、その中のエネルギー1枚を選んで相手の山札の下に置く(Energy Swatter)。"""

    def execute(self, ctx: EffectContext) -> None:
        opponent = ctx.state.player(ctx.opponent)
        if not opponent.hand:
            return
        _attacker_player(ctx).known_opponent_hand = list(opponent.hand)
        ctx.reveal("相手の手札", list(opponent.hand))
        positions = [i for i, cid in enumerate(opponent.hand) if (c := ctx.card_db.get(cid)) is not None and c.is_energy]
        if not positions:
            return
        ctx.state.pending_search_choice = PendingSearchChoice(
            player_index=ctx.acting_player,
            zone="opponent_hand_to_bottom_of_deck",
            source_indices=positions,
            card_ids=[opponent.hand[i] for i in positions],
            min_count=1,
            max_count=1,
            prompt="相手の手札のエネルギーを選び、山札の下に置く",
            shuffle_after=False,
            all_card_ids=list(opponent.hand),
        )


@dataclass(frozen=True)
class SetDamageReductionNextTurn(Effect):
    """相手の次の番、自分の(指定タイプ/サブタイプの)ポケモンが受けるワザのダメージをamount減らす(amount=Noneなら全て受けない)(Iron Defender/Lusamine)。"""

    ptype: str | None = None
    subtype: str | None = None
    amount: int | None = None

    def execute(self, ctx: EffectContext) -> None:
        opponent = ctx.state.player(ctx.opponent)
        _attacker_player(ctx).damage_reductions.append(
            {"type": self.ptype, "subtype": self.subtype, "amount": self.amount, "until": opponent.turns_taken + 1}
        )


@dataclass(frozen=True)
class SetBonusPrizeByNamePrefix(Effect):
    """この番、指定の名前(接頭辞)のポケモンのワザで相手のバトルポケモンをきぜつさせたら、サイドをさらにamount枚とる(Anthea & Concordia)。"""

    prefix: str
    amount: int

    def execute(self, ctx: EffectContext) -> None:
        _attacker_player(ctx).bonus_prize_name_prefix_this_turn = (self.prefix, self.amount)


@dataclass(frozen=True)
class AllowSupportersThisTurn(Effect):
    """この番、サポートを合計count枚まで使える(このカードも含む)(Lt. Surge's Strategy)。"""

    count: int

    def execute(self, ctx: EffectContext) -> None:
        player = _attacker_player(ctx)
        player.supporters_allowed_this_turn = max(player.supporters_allowed_this_turn, self.count)


@dataclass(frozen=True)
class ChipChipIceAxe(Effect):
    """相手の山札の上から3枚を見て1枚を選び、他は相手の山札に戻してシャッフルする。そのあと選んだカードを相手の山札の上に置く(Chip-Chip Ice Axe)。"""

    n: int = 3

    def execute(self, ctx: EffectContext) -> None:
        opponent = ctx.state.player(ctx.opponent)
        seen = opponent.deck[: self.n]
        if not seen:
            return
        ctx.state.pending_search_choice = PendingSearchChoice(
            player_index=ctx.acting_player,
            zone="gen_deck_pick",
            source_indices=list(range(len(seen))),
            card_ids=list(seen),
            min_count=1,
            max_count=1,
            prompt="相手の山札の上から見たカードのうち、山札の上に置く1枚を選ぶ(他は山札に戻してシャッフルする)",
            shuffle_after=False,
            all_card_ids=list(seen),
            custom_data={"op": "ice_axe_pick", "n": len(seen)},
            effect_source=ctx.effect_source,
        )


def _op_ice_axe_pick(state, card_db, choice, selected, action, ctx, custom) -> bool:
    opponent = state.player(1 - choice.player_index)
    n = custom["n"]
    seen = opponent.deck[:n]
    if not selected or not seen:
        return False
    picked = seen[choice.source_indices[selected[0]]]
    rest = list(seen)
    rest.remove(picked)
    del opponent.deck[:n]
    opponent.deck.extend(rest)
    state.rng.shuffle(opponent.deck)
    opponent.deck.insert(0, picked)
    state.add_log("相手の山札の上から見て、選んだ1枚を山札の上に置いた")
    return False


# ---------------------------------------------------------------------------------------------
# 登録
# ---------------------------------------------------------------------------------------------
_INSTALLED = False


def _register_ops() -> None:
    from effects.era_primitives_b import GENERIC_OP_HANDLERS

    GENERIC_OP_HANDLERS.update({"lt_surge_bargain": _op_lt_surge_bargain, "ice_axe_pick": _op_ice_axe_pick})


_register_ops()


@dataclass(frozen=True)
class DrawUntilHandEqualsOwnPsychicCount(Effect):
    """自分の場のエスパーポケモンの数と同じ枚数になるまで、山札を引く(Mystery Garden)。"""

    def execute(self, ctx: EffectContext) -> None:
        from effects.primitives import Draw

        player = _attacker_player(ctx)
        count = sum(1 for m in player.all_pokemon_in_play() if (c := ctx.card_db.get(m.card_id)) is not None and "Psychic" in c.types)
        if count > len(player.hand):
            Draw(count - len(player.hand)).execute(ctx)


@dataclass(frozen=True)
class SearchDeckAntiqueItemsToBench(Effect):
    """山札から、名前に「Antique」を含むグッズ(化石)を最大count枚、ベンチに出す(Fossil Quarry)。"""

    count: int = 2

    def execute(self, ctx: EffectContext) -> None:
        player = _attacker_player(ctx)
        _trigger_search_choice(
            ctx, player, "deck", lambda c: c is not None and c.is_item and "Antique" in c.name, self.count, "山札からAntiqueのグッズをベンチに出す",
            destination="bench",
        )


def stadium_ability_gate_g(state, player, card_db):
    """メガ時代のスタジアムの「各プレイヤーの番に1回」の効果を、いま使えるか(該当するスタジアムでなければNone)。"""
    stadium = state.stadium_in_play
    if stadium in MYSTERY_GARDEN_IDS:
        return any((c := card_db.get(cid)) is not None and c.is_energy for cid in player.hand)
    if stadium in SURFING_BEACH_IDS:
        active = player.active
        ac = card_db.get(active.card_id) if active is not None else None
        return ac is not None and "Water" in ac.types and any(
            (c := card_db.get(m.card_id)) is not None and "Water" in c.types for m in player.bench
        )
    if stadium in LUMIOSE_CITY_IDS:
        return bool(player.deck)
    if stadium in FOSSIL_QUARRY_IDS:
        return any((c := card_db.get(cid)) is not None and c.is_item and "Antique" in c.name for cid in player.deck)
    from effects import era_sm_hooks as H

    if stadium in H.MT_CORONET_IDS:
        return any((c := card_db.get(cid)) is not None and c.basic_energy_type == "Metal" for cid in player.discard)
    if stadium in H.RESEARCH_LAB_IDS:
        from engine.continuous import effective_bench_limit

        return len(player.bench) < effective_bench_limit(state, player, card_db) and any(
            (c := card_db.get(cid)) is not None and c.is_pokemon and c.evolves_from == "Unidentified Fossil" for cid in player.deck
        )
    if stadium in H.LIFE_FOREST_IDS:
        return any((c := card_db.get(m.card_id)) is not None and "Grass" in c.types and (m.damage > 0 or m.status.is_any) for m in player.all_pokemon_in_play())
    if stadium in H.LAVENDER_TOWN_IDS:
        return bool(state.player(1 - (0 if player is state.players[0] else 1)).hand)
    return None


def keep_confusion_on_evolve(state, old, evolved) -> None:
    """Dizzying Valley: こんらんのポケモンは、進化してもこんらんが治らない。"""
    if state.stadium_in_play in DIZZYING_VALLEY_IDS and old.status.exclusive.name == "CONFUSED":
        evolved.status.exclusive = old.status.exclusive
        evolved.status.confusion_counters = old.status.confusion_counters


def thunder_mountain_shields(state, script) -> bool:
    """Thunder Mountain: プレイヤーが手札から使ったグッズ/サポートの、このスタジアムへの効果は無効(スタジアムをトラッシュする効果)。"""
    from effects.era_sm_hooks import ITEM_SUPPORTER_IMMUNE_STADIUMS

    return state.stadium_in_play in ITEM_SUPPORTER_IMMUNE_STADIUMS and any("Stadium" in type(e).__name__ for e in script)


# ---------------------------------------------------------------------------------------------
# 使えるかどうかの条件
# ---------------------------------------------------------------------------------------------
def _opponent_prizes_at_most_2(state, player, player_index, card_db) -> bool:
    return len(state.player(1 - player_index).prizes) <= 2 and bool(player.all_pokemon_in_play())


def _opponent_prizes_exactly_3(state, player, player_index, card_db) -> bool:
    return len(state.player(1 - player_index).prizes) == 3


def _more_prizes_than_opponent(state, player, player_index, card_db) -> bool:
    return len(player.prizes) > len(state.player(1 - player_index).prizes)


def _last_card_in_hand(state, player, player_index, card_db) -> bool:
    return len(player.hand) == 1


def _hand_has_basic_fire_energy(state, player, player_index, card_db) -> bool:
    return any((c := card_db.get(cid)) is not None and c.is_energy and not c.is_special_energy and c.basic_energy_type == "Fire" for cid in player.hand)


def _not_first_turn(state, player, player_index, card_db) -> bool:
    return player.turns_taken > 1


def _deck_nonempty(state, player, player_index, card_db) -> bool:
    return bool(player.deck)


def _active_water_or_metal(state, player, player_index, card_db) -> bool:
    active = player.active
    c = card_db.get(active.card_id) if active is not None else None
    return c is not None and ("Water" in c.types or "Metal" in c.types)


def _anthea_ok(state, player, player_index, card_db) -> bool:
    needed = ("N's Darmanitan", "N's Zoroark ex", "N's Vanilluxe", "N's Klinklang", "N's Reshiram", "N's Zekrom")
    in_play = {c.name for m in player.all_pokemon_in_play() if (c := card_db.get(m.card_id)) is not None}
    return all(n in in_play for n in needed)


def _has_tag_team_with_energy(state, player, player_index, card_db) -> bool:
    mons = player.all_pokemon_in_play()
    return len(mons) > 1 and any(m.attached_energy and (c := card_db.get(m.card_id)) is not None and "TAG TEAM" in c.subtypes for m in mons)


def _can_devolve_psychic(state, player, player_index, card_db) -> bool:
    from effects.era_trainers_h import DevolveOwnPokemonAnyNumber

    return bool(DevolveOwnPokemonAnyNumber("Psychic").candidates(player, card_db))


def _discard_has_water_stuff(state, player, player_index, card_db) -> bool:
    return any((c := card_db.get(cid)) is not None and ((c.is_pokemon and "Water" in c.types) or (c.is_energy and not c.is_special_energy and c.basic_energy_type == "Water")) for cid in player.discard)


# ---------------------------------------------------------------------------------------------
# 登録
# ---------------------------------------------------------------------------------------------
def install(reg) -> None:
    """era_trainers.install() から呼ばれる。reg(キー, スクリプト, ゲート)はグッズ/サポートの登録関数。"""
    global _INSTALLED
    if _INSTALLED:
        return
    _INSTALLED = True
    from effects import era_trainers_h as H
    from effects import registry as R
    from effects.era_abilities import GrantTypeAttackBonusThisTurn, DiscardFromHandBasicEnergyAsCost, PickPokemonThen
    from effects.era_primitives_b import AttachEnergyGeneric
    from effects.era_primitives_f import ChooseOneEffectBranch, ShuffleKindFromDiscardIntoDeck
    from effects.primitives import (
        DiscardAnyHandCardsOptional, DiscardStadiumInPlay, Draw, DrawUpTo, EndTurnAfterThisAbility, FlipCoinThen,
        SearchDeckByCriterionToHand, ShuffleHandIntoDeckThenDraw, SwitchActiveWithBench,
    )

    reg("premium_power_pro", (GrantTypeAttackBonusThisTurn("Fighting", 30, basic_only=False),))
    reg("electropower", (GrantTypeAttackBonusThisTurn("Lightning", 30, basic_only=False),))
    reg("gladion_final_battle", (GrantTypeAttackBonusThisTurn("NoRuleBox", 80, basic_only=False),), _last_card_in_hand)
    reg("iron_defender", (SetDamageReductionNextTurn(ptype="Metal", amount=30),))
    reg("lusamine_prism", (SetDamageReductionNextTurn(subtype="Ultra Beast", amount=None),), _opponent_prizes_exactly_3)
    reg("lt_surge_bargain", (LtSurgesBargain(),))
    reg("lt_surge_strategy", (AllowSupportersThisTurn(3),), _more_prizes_than_opponent)
    reg("acerolas_mischief", (PickPokemonThen(action="shield_vs_ex"),), _opponent_prizes_at_most_2)
    reg("grimsley_move", (LookTopNBenchThenRestToBottom(7, "Darkness"),), _not_first_turn)
    reg("waitress", (AttachEnergyGeneric(source="deck", count=1, basic_only=True, deck_limit=6),), _deck_nonempty)
    reg("naveen", (DiscardAnyHandCardsOptional(), DrawUpTo(5)), _deck_nonempty)
    reg(
        "blowtorch",
        (DiscardFromHandBasicEnergyAsCost("Fire", then=(ChooseOneEffectBranch(
            labels=("相手のポケモンのどうぐ/特殊エネルギーをトラッシュする", "場のスタジアムをトラッシュする"),
            branches=((DiscardChosenOpponentToolOrSpecialEnergy(),), (DiscardStadiumInPlay(),)),
        ),)),),
        _hand_has_basic_fire_energy,
    )
    reg("energy_swatter", (RevealOpponentHandChosenEnergyToBottom(),))
    reg(
        "great_haul_net",
        (ChooseOneEffectBranch(
            labels=("水ポケモンを最大3枚山札に戻す", "基本水エネルギーを最大3枚山札に戻す", "両方行う"),
            branches=(
                (ShuffleKindFromDiscardIntoDeck("water_pokemon", 3, up_to=True),),
                (ShuffleKindFromDiscardIntoDeck("basic_water_energy", 3, up_to=True),),
                (ShuffleKindFromDiscardIntoDeck("water_pokemon", 3, up_to=True), ShuffleKindFromDiscardIntoDeck("basic_water_energy", 3, up_to=True)),
            ),
        ),),
        _discard_has_water_stuff,
    )
    reg(
        "misty_vitality",
        (AttachEnergyGeneric(source="deck", count=4, basic_only=True, energy_type="Water", single_target=True), EndTurnAfterThisAbility()),
        _deck_nonempty,
    )
    reg("anthea_concordia", (SetBonusPrizeByNamePrefix("N's", 3),), _anthea_ok)
    reg("ethans_adventure", (SearchDeckByCriterionToHand("or:name_prefix_pokemon:Ethan's|energy_type:Fire", 3),))
    reg("bother_bot", (H.BotherBotEffect(),))
    reg("chip_chip_ice_axe", (ChipChipIceAxe(),))
    reg(
        "stadium_nav",
        (FlipCoinThen(heads=(SearchDeckByCriterionToHand("stadium", 1),)), FlipCoinThen(heads=(SearchDeckByCriterionToHand("stadium", 1),))),
    )
    reg("tag_switch", (H.TagSwitchEffect(),), _has_tag_team_with_energy)
    reg("cyrus_prism", (H.CyrusEffect(),), _active_water_or_metal)
    reg(
        "tate_liza",
        (ChooseOneEffectBranch(
            labels=("手札を山札に戻して5枚引く", "バトルポケモンをベンチポケモンと入れ替える"),
            branches=((ShuffleHandIntoDeckThenDraw(5),), (SwitchActiveWithBench(),)),
        ),),
    )
    reg("strange_timepiece", (H.DevolveOwnPokemonAnyNumber("Psychic"),), _can_devolve_psychic)
    for card_id in _ids("transformation_tome"):
        R.TRAINER_PAIRED_EFFECTS.setdefault(card_id, (H.TransformationTomeEffect(),))  # 2枚同時使用が必須(1枚だけでは使えない)
    _ = Draw

    # ---- スタジアム(各プレイヤーの番に1回の効果) ----
    from effects.era_primitives_g import DiscardHandCardAsCost, SearchDiscardPokemonFiltered  # noqa: F401
    from effects.primitives import SearchDeckForBasicPokemonToBench

    stadiums = R.STADIUM_ABILITY_EFFECTS
    for card_id in MYSTERY_GARDEN_IDS:
        stadiums.setdefault(card_id, (DiscardHandCardAsCost(then=(DrawUntilHandEqualsOwnPsychicCount(),), energy_only=True),))
    for card_id in SURFING_BEACH_IDS:
        stadiums.setdefault(card_id, (PickPokemonThen(action="switch_own_active", bench_only=True, ptype="Water"),))
    for card_id in LUMIOSE_CITY_IDS:
        stadiums.setdefault(card_id, (SearchDeckForBasicPokemonToBench(1), EndTurnAfterThisAbility()))
    for card_id in FOSSIL_QUARRY_IDS:
        stadiums.setdefault(card_id, (SearchDeckAntiqueItemsToBench(2),))

    # ---- どうぐ: Core Memory(ついているMega Zygarde exがどうぐ自体のワザを使える) ----
    from engine import legal_actions as L
    from effects.primitives import DealDamage, DiscardAllOwnEnergy

    for card_id in _ids("core_memory"):
        L.TOOL_GRANTED_ATTACK_IDS.add(card_id)
        L._TOOL_GRANTED_ATTACK_RESTRICTED_TO[card_id] = "Mega Zygarde ex"
        R.ATTACK_EFFECTS.setdefault(card_id, {}).setdefault("Geobuster", (DealDamage(350), DiscardAllOwnEnergy()))

    # ---- 特殊エネルギー: Spiky Energy(別絵柄) ----
    from effects import primitives as P

    for card_id in _ids("spiky_energy"):
        P._ON_DAMAGED_WHILE_ACTIVE_RETALIATE_ENERGY.setdefault(card_id, 2)
