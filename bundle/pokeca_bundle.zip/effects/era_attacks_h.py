"""SM期(サン&ムーン)のワザ用プリミティブその2(2026-10-07)。scripts/generate_effects_batch15.py のパターンが使う。

effects/era_attacks_g.py と同じ規約(frozen dataclassのEffect、execute(ctx)、ダメージは必ずDealDamageを1回だけ経由する)。
条件は effects.era_primitives.EXTRA_CONDITIONS に登録し、IfCondition/ConditionalBonusDamage/UsableIfから使う。
「このワザは、〜のときだけ使える」は usable_check(state, player, mon, card_db, attack)を持つEffectで表し、
engine.legal_actions がワザの合法手を出すときに見る。
"""

from __future__ import annotations

from dataclasses import dataclass

from effects import era_primitives as _ep
from effects.context import EffectContext
from effects.primitives import DealDamage, Effect, _attacker_player, _defender, _defender_blocks_effect
from engine.state import PendingSearchChoice


def _opp_slots(ctx: EffectContext) -> list[tuple[int, object]]:
    from effects.era_primitives_b import _slots

    return _slots(ctx.state.player(ctx.opponent))


# ---------------------------------------------------------------------------------------------
# 使える条件(usable_check)
# ---------------------------------------------------------------------------------------------
@dataclass(frozen=True)
class UsableIf(Effect):
    """「このワザは、〜のときだけ使える」。conditionはEXTRA_CONDITIONS/condition_metの条件名(arg付き)。何も実行しない。"""

    condition: str
    arg: str = ""

    def usable_check(self, state, player, mon, card_db, attack) -> bool:
        player_index = 0 if player is state.players[0] else 1
        ctx = EffectContext(state=state, card_db=card_db, acting_player=player_index, source_pokemon=mon, source_card_id=mon.card_id)
        return bool(_ep.condition_met(ctx, self.condition, self.arg))

    def execute(self, ctx: EffectContext) -> None:
        return


# ---------------------------------------------------------------------------------------------
# 手番・サイド
# ---------------------------------------------------------------------------------------------
@dataclass(frozen=True)
class TakeAnotherTurn(Effect):
    """この番のあと、もう1回自分の番を行う(ポケモンチェックは行わない)(スプリーム パフGX等)。"""

    def execute(self, ctx: EffectContext) -> None:
        ctx.state.extra_turn_pending = True
        ctx.log("この番のあと、もう1回自分の番を行う")


@dataclass(frozen=True)
class AddOpponentDeckTopToTheirPrizes(Effect):
    """相手の山札の上からcount枚を、相手のサイド(裏向き)に加える(シンバイオントGX等)。"""

    count: int

    def execute(self, ctx: EffectContext) -> None:
        opponent = ctx.state.player(ctx.opponent)
        n = min(self.count, len(opponent.deck))
        opponent.add_prizes([opponent.deck.pop(0) for _ in range(n)])
        ctx.log(f"相手の山札の上から{n}枚を相手のサイドに加えた")


@dataclass(frozen=True)
class ReplaceOwnPrizesWithDeckTop(Effect):
    """自分のサイドを全て手札に加え、同じ枚数を山札の上から取って新しいサイド(裏向き)にする。山札が足りなければ何もしない(ディスカバリーGX)。"""

    def execute(self, ctx: EffectContext) -> None:
        player = _attacker_player(ctx)
        n = len(player.prizes)
        if n <= 0 or len(player.deck) < n:
            ctx.log("山札が足りないので何もしない")
            return
        player.hand.extend(player.prizes)
        player.prizes = []
        player.reset_prize_marks()
        player.add_prizes([player.deck.pop(0) for _ in range(n)])
        ctx.log(f"サイド{n}枚を手札に加え、山札の上から{n}枚を新しいサイドにした")


# ---------------------------------------------------------------------------------------------
# 相手のエネルギーを外す
# ---------------------------------------------------------------------------------------------
def _opp_energy_entries(ctx: EffectContext, only_slot: int | None = None) -> tuple[list[tuple], list[str]]:
    """相手の場のポケモンについているエネルギーの候補(ワザの効果を受けないポケモンのぶんは除く)。
    source_indicesは("energy", 側, "active"|ベンチindex, エネルギーindex)。"""
    opponent = ctx.state.player(ctx.opponent)
    source_indices: list[tuple] = []
    card_ids: list[str] = []
    for slot, mon in _opp_slots(ctx):
        if only_slot is not None and slot != only_slot:
            continue
        if _defender_blocks_effect(ctx, mon):
            continue
        key = "active" if slot == 0 else slot - 1
        for ei, energy_id in enumerate(mon.attached_energy):
            source_indices.append(("energy", ctx.opponent, key, ei))
            card_ids.append(energy_id)
    _ = opponent
    return source_indices, card_ids


@dataclass(frozen=True)
class DiscardChosenOpponentEnergyCount(Effect):
    """相手の場のポケモンについているエネルギーを、どのポケモンのものでもよいのでcount枚選んでトラッシュする(足りなければある分だけ)。"""

    count: int

    def execute(self, ctx: EffectContext) -> None:
        source_indices, card_ids = _opp_energy_entries(ctx)
        n = min(self.count, len(card_ids))
        if n <= 0:
            ctx.log("相手の場にトラッシュできるエネルギーが無い")
            return
        ctx.state.pending_search_choice = PendingSearchChoice(
            player_index=ctx.acting_player,
            zone="field_attachment",
            source_indices=source_indices,
            card_ids=card_ids,
            min_count=n,
            max_count=n,
            prompt=f"トラッシュする相手のエネルギーを{n}枚選ぶ",
            shuffle_after=False,
            all_card_ids=list(card_ids),
            destination="discard",
            effect_source=ctx.effect_source,
        )


@dataclass(frozen=True)
class DiscardOneEnergyFromEachOpponentPokemon(Effect):
    """相手の場の各ポケモンから、エネルギーを1枚ずつトラッシュする(同じカードしかついていなければ選ばず、違う種類がついているポケモンは1匹ずつ選ぶ)。
    start_slotは、選択を挟んで続きを処理するときの再開位置(スロット番号。0=バトル場)。"""

    start_slot: int = 0

    def execute(self, ctx: EffectContext) -> None:
        opponent = ctx.state.player(ctx.opponent)
        for slot, mon in _opp_slots(ctx):
            if slot < self.start_slot or not mon.attached_energy or _defender_blocks_effect(ctx, mon):
                continue
            if len(set(mon.attached_energy)) == 1:
                opponent.discard.append(mon.attached_energy.pop())
                continue
            source_indices, card_ids = _opp_energy_entries(ctx, only_slot=slot)
            ctx.state.pending_search_choice = PendingSearchChoice(
                player_index=ctx.acting_player,
                zone="field_attachment",
                source_indices=source_indices,
                card_ids=card_ids,
                min_count=1,
                max_count=1,
                prompt="トラッシュするエネルギーを選ぶ(相手のポケモン1匹ぶん)",
                shuffle_after=False,
                all_card_ids=list(card_ids),
                destination="discard",
                effect_source=ctx.effect_source,
                remaining_script=(DiscardOneEnergyFromEachOpponentPokemon(start_slot=slot + 1),),
                cont_source_pokemon=ctx.source_pokemon,
                cont_source_card_id=ctx.source_card_id,
                cont_target_bench_index=ctx.target_bench_index,
            )
            return
        ctx.log("相手の各ポケモンのエネルギーを1枚ずつトラッシュした")


@dataclass(frozen=True)
class ShuffleAllOpponentEnergyIntoDeck(Effect):
    """相手の場の全てのポケモンについているエネルギーを全て、相手の山札に戻してシャッフルする(ゼロバニッシュGX等)。"""

    def execute(self, ctx: EffectContext) -> None:
        opponent = ctx.state.player(ctx.opponent)
        moved = 0
        for _slot, mon in _opp_slots(ctx):
            if _defender_blocks_effect(ctx, mon):
                continue
            moved += len(mon.attached_energy)
            opponent.deck.extend(mon.attached_energy)
            mon.attached_energy = []
        if moved:
            ctx.rng.shuffle(opponent.deck)
        ctx.log(f"相手の場のエネルギー{moved}枚を相手の山札に戻してシャッフルした")


@dataclass(frozen=True)
class HealBlockDefenderNextTurn(Effect):
    """相手の次の番、このワザを受けたポケモンはダメージを回復できない。"""

    def execute(self, ctx: EffectContext) -> None:
        opponent, defender = _defender(ctx)
        if defender is None or _defender_blocks_effect(ctx, defender):
            return
        defender.heal_blocked_turn = opponent.turns_taken + 1


# ---------------------------------------------------------------------------------------------
# ダメージ
# ---------------------------------------------------------------------------------------------
@dataclass(frozen=True)
class DamageMinusPerSelfDamageCounter(Effect):
    """このポケモンにのっているダメカン1個につき、ダメージがper減る(最低0)(メガブルーム等)。"""

    base: int
    per: int

    def execute(self, ctx: EffectContext) -> None:
        counters = ctx.source_pokemon.damage // 10 if ctx.source_pokemon is not None else 0
        DealDamage(max(0, self.base - self.per * counters)).execute(ctx)


@dataclass(frozen=True)
class DamageCountersOnDefenderPerOpponentHandCard(Effect):
    """相手の手札1枚につき、相手のバトルポケモンにダメカンをper個のせる(ブレイクダウン)。"""

    per: int = 1

    def execute(self, ctx: EffectContext) -> None:
        from effects.era_primitives_f import put_counters

        opponent, defender = _defender(ctx)
        if defender is None:
            return
        n = len(opponent.hand) * self.per
        if n > 0:
            put_counters(ctx, defender, n)


@dataclass(frozen=True)
class DiscardRandomOpponentHandUntil(Effect):
    """相手の手札がcount枚になるまで、ランダムに手札をトラッシュする。"""

    count: int

    def execute(self, ctx: EffectContext) -> None:
        opponent = ctx.state.player(ctx.opponent)
        while len(opponent.hand) > self.count:
            opponent.discard.append(opponent.hand.pop(ctx.rng.randrange(len(opponent.hand))))
        ctx.log(f"相手の手札がちょうど{self.count}枚になるまで、ランダムにトラッシュした")


# ---------------------------------------------------------------------------------------------
# 条件
# ---------------------------------------------------------------------------------------------
def _cond_opponent_bench_at_least(ctx, arg, player, opponent, self_mon, defender) -> bool:
    return len(opponent.bench) >= int(arg)


def _cond_total_prizes_at_most(ctx, arg, player, opponent, self_mon, defender) -> bool:
    return len(player.prizes) + len(opponent.prizes) <= int(arg)


def _cond_total_prizes_exactly(ctx, arg, player, opponent, self_mon, defender) -> bool:
    return len(player.prizes) + len(opponent.prizes) == int(arg)


def _cond_own_prizes_exactly(ctx, arg, player, opponent, self_mon, defender) -> bool:
    return len(player.prizes) in {int(x) for x in str(arg).split(",")}


def _cond_both_prizes_exactly(ctx, arg, player, opponent, self_mon, defender) -> bool:
    return len(player.prizes) == int(arg) and len(opponent.prizes) == int(arg)


def _cond_own_prizes_at_most(ctx, arg, player, opponent, self_mon, defender) -> bool:
    return len(player.prizes) <= int(arg)


def _cond_deck_at_most(ctx, arg, player, opponent, self_mon, defender) -> bool:
    return len(player.deck) <= int(arg)


def _cond_hand_exactly(ctx, arg, player, opponent, self_mon, defender) -> bool:
    return len(player.hand) == int(arg)


def _cond_used_gx_attack(ctx, arg, player, opponent, self_mon, defender) -> bool:
    return bool(player.used_gx_attack_this_game)


def _cond_defender_has_ability(ctx, arg, player, opponent, self_mon, defender) -> bool:
    card = ctx.card_db.get(defender.card_id) if defender is not None else None
    return card is not None and bool(card.abilities)


def _cond_defender_no_damage(ctx, arg, player, opponent, self_mon, defender) -> bool:
    return defender is not None and defender.damage <= 0


def _cond_became_active_this_turn(ctx, arg, player, opponent, self_mon, defender) -> bool:
    return self_mon is not None and self_mon.became_active_turn == player.turns_taken


def _cond_own_bench_all_damaged(ctx, arg, player, opponent, self_mon, defender) -> bool:
    return bool(player.bench) and all(m.damage // 10 >= int(arg) for m in player.bench)


def _cond_own_discard_has_supporter(ctx, arg, player, opponent, self_mon, defender) -> bool:
    return any((c := ctx.card_db.get(cid)) is not None and c.is_supporter for cid in player.discard)


def _cond_defender_energy_type(ctx, arg, player, opponent, self_mon, defender) -> bool:
    return defender is not None and any(
        (c := ctx.card_db.get(e)) is not None and c.basic_energy_type == arg for e in defender.attached_energy
    )


def _cond_opponent_in_play_type(ctx, arg, player, opponent, self_mon, defender) -> bool:
    return any((c := ctx.card_db.get(m.card_id)) is not None and arg in c.types for m in opponent.all_pokemon_in_play())


def _cond_self_has_tool_named(ctx, arg, player, opponent, self_mon, defender) -> bool:
    tool = ctx.card_db.get(self_mon.attached_tool) if self_mon is not None and self_mon.attached_tool else None
    return tool is not None and tool.name == arg


def _cond_own_in_play_name_contains(ctx, arg, player, opponent, self_mon, defender) -> bool:
    return any((c := ctx.card_db.get(m.card_id)) is not None and arg in c.name for m in player.all_pokemon_in_play())


def _cond_own_discard_named(ctx, arg, player, opponent, self_mon, defender) -> bool:
    return any((c := ctx.card_db.get(cid)) is not None and c.name == arg for cid in player.discard)


def _cond_own_discard_has_lost_energy_type(ctx, arg, player, opponent, self_mon, defender) -> bool:
    return any((c := ctx.card_db.get(cid)) is not None and c.basic_energy_type == arg for cid in player.lost_zone)


def register_conditions() -> None:
    _ep.EXTRA_CONDITIONS.update({
        "opponent_bench_at_least": _cond_opponent_bench_at_least,
        "total_prizes_at_most": _cond_total_prizes_at_most,
        "total_prizes_exactly": _cond_total_prizes_exactly,
        "own_prizes_exactly": _cond_own_prizes_exactly,
        "both_prizes_exactly": _cond_both_prizes_exactly,
        "own_prizes_at_most": _cond_own_prizes_at_most,
        "deck_at_most": _cond_deck_at_most,
        "hand_exactly": _cond_hand_exactly,
        "used_gx_attack": _cond_used_gx_attack,
        "defender_has_ability": _cond_defender_has_ability,
        "defender_no_damage": _cond_defender_no_damage,
        "became_active_this_turn": _cond_became_active_this_turn,
        "own_bench_all_damaged": _cond_own_bench_all_damaged,
        "own_discard_has_supporter": _cond_own_discard_has_supporter,
        "defender_energy_type": _cond_defender_energy_type,
        "opponent_in_play_type": _cond_opponent_in_play_type,
        "self_has_tool_named": _cond_self_has_tool_named,
        "own_in_play_name_contains": _cond_own_in_play_name_contains,
        "own_discard_named": _cond_own_discard_named,
        "own_lost_zone_energy_type": _cond_own_discard_has_lost_energy_type,
    })


register_conditions()
from effects import era_attacks_i as _era_attacks_i  # noqa: E402,F401  (SWSH/SV期の汎用の条件・数える物。条件の登録のためにimportする)


# ---------------------------------------------------------------------------------------------
# 自分のエネルギー・手札を使うダメージ(トラッシュした/戻した枚数に応じて)
# ---------------------------------------------------------------------------------------------
def _own_energy_entries(ctx: EffectContext, scope: str, energy_type: str | None, basic_only: bool, special_only: bool = False):
    from effects.primitives import _field_attachment_candidates

    def pred(card) -> bool:
        if special_only:
            return card.is_special_energy
        if energy_type is not None:
            return card.basic_energy_type == energy_type
        if basic_only:
            return card.is_energy and not card.is_special_energy
        return True

    only = ctx.source_pokemon if scope == "self" else None
    return _field_attachment_candidates(ctx.state, ctx.card_db, (ctx.acting_player,), energy_predicate=pred, only_pokemon=only)


def _send_own_energy(ctx: EffectContext, indices: list[tuple], destination: str) -> int:
    """own_energy_entriesの候補のうち、選ばれたものを移動先("discard"|"hand"|"deck"|"lost_zone")へ送る。送った枚数を返す。"""
    player = _attacker_player(ctx)
    by_mon: dict[object, list[int]] = {}
    for entry in indices:
        _kind, _side, slot, ei = entry
        mon = player.active if slot == "active" else (player.bench[slot] if 0 <= slot < len(player.bench) else None)
        if mon is not None:
            by_mon.setdefault(id(mon), [mon]).append(ei)
    moved = 0
    for group in by_mon.values():
        mon, eis = group[0], sorted(group[1:], reverse=True)
        for ei in eis:
            if 0 <= ei < len(mon.attached_energy):
                card_id = mon.attached_energy.pop(ei)
                {"hand": player.hand, "deck": player.deck, "lost_zone": player.lost_zone}.get(destination, player.discard).append(card_id)
                moved += 1
    if destination == "deck" and moved:
        ctx.rng.shuffle(player.deck)
    return moved


@dataclass(frozen=True)
class DiscardOwnEnergyThenDamage(Effect):
    """このポケモン(scope="self")または自分の場の全てのポケモン(scope="all")についているエネルギーを、トラッシュ(destination="hand"なら手札に戻し、
    "deck"なら山札に戻してシャッフルし、"lost_zone"ならロストゾーンに置き)、その枚数に応じてダメージを与える。
    amount: "all"=条件に合うものを全部 / "any"=好きな枚数を選ぶ(0枚でもよい) / 数字=ちょうどその枚数(足りなければある分)。
    base=Noneならダメージは与えない。ダメージ = base + per × 枚数。energy_type/basic_only: 対象にするエネルギーの条件。"""

    base: int | None = None
    per: int = 0
    scope: str = "self"
    amount: object = "all"
    energy_type: str | None = None
    basic_only: bool = False
    destination: str = "discard"
    special_only: bool = False

    def _finish(self, ctx: EffectContext, moved: int) -> None:
        if self.base is not None:
            DealDamage(self.base + self.per * moved).execute(ctx)

    def execute(self, ctx: EffectContext) -> None:
        source_indices, card_ids = _own_energy_entries(ctx, self.scope, self.energy_type, self.basic_only, self.special_only)
        if self.amount == "all" or (isinstance(self.amount, int) and self.amount >= len(card_ids)):
            self._finish(ctx, _send_own_energy(ctx, source_indices, self.destination))
            return
        if isinstance(self.amount, int) and len(set(card_ids)) == 1:
            self._finish(ctx, _send_own_energy(ctx, source_indices[: self.amount], self.destination))
            return
        if not card_ids:
            self._finish(ctx, 0)
            return
        exact = self.amount if isinstance(self.amount, int) else None
        ctx.state.pending_search_choice = PendingSearchChoice(
            player_index=ctx.acting_player,
            zone="field_attachment",
            source_indices=source_indices,
            card_ids=card_ids,
            min_count=exact if exact is not None else 0,
            max_count=exact if exact is not None else len(card_ids),
            prompt="エネルギーを選ぶ" + ("(好きな枚数)" if exact is None else f"({exact}枚)"),
            shuffle_after=self.destination == "deck",
            all_card_ids=list(card_ids),
            destination=self.destination,
            custom_data={"mode": "bellowing_thunder", "base": self.base or 0, "damage_per": self.per} if self.base is not None else None,
            effect_source=ctx.effect_source,
            cont_source_pokemon=ctx.source_pokemon,
            cont_source_card_id=ctx.source_card_id,
        )


@dataclass(frozen=True)
class DiscardHandCardsScalingDamage(Effect):
    """自分の手札から条件に合うカード(criterion。SearchDeckMultiCriteriaと同じ条件文字列。"any"=何でも)を最大max_count枚選んでトラッシュし、
    トラッシュした1枚につきperダメージ(+base)を与える。min_countが0なら0枚でもよい。"""

    criterion: str = "any"
    per: int = 0
    base: int = 0
    max_count: int = 99
    min_count: int = 0

    def execute(self, ctx: EffectContext) -> None:
        from effects.primitives import SearchDeckMultiCriteria

        player = _attacker_player(ctx)
        eligible = [
            (i, cid) for i, cid in enumerate(player.hand)
            if self.criterion == "any" or ((c := ctx.card_db.get(cid)) is not None and SearchDeckMultiCriteria._matches(c, self.criterion))
        ]
        if not eligible:
            DealDamage(self.base).execute(ctx)
            return
        ctx.state.pending_search_choice = PendingSearchChoice(
            player_index=ctx.acting_player,
            zone="gen_hand_pick",
            source_indices=[i for i, _ in eligible],
            card_ids=[c for _, c in eligible],
            min_count=min(self.min_count, len(eligible)),
            max_count=min(self.max_count, len(eligible)),
            prompt="トラッシュする手札を選ぶ",
            shuffle_after=False,
            all_card_ids=[c for _, c in eligible],
            custom_data={"op": "hand_discard_damage", "base": self.base, "per": self.per},
            effect_source=ctx.effect_source,
            cont_source_pokemon=ctx.source_pokemon,
            cont_source_card_id=ctx.source_card_id,
        )


def _op_hand_discard_damage(state, card_db, choice, selected, action, ctx, custom) -> bool:
    player = state.player(choice.player_index)
    n = 0
    for pos in sorted((choice.source_indices[p] for p in selected), reverse=True):
        if 0 <= pos < len(player.hand):
            player.discard.append(player.hand.pop(pos))
            n += 1
    DealDamage(custom["base"] + custom["per"] * n).execute(ctx)
    return False


# ---------------------------------------------------------------------------------------------
# 相手のポケモン1匹を選ぶダメージ(対象の絞り込み・弱点抵抗力/効果を無視)
# ---------------------------------------------------------------------------------------------
from effects.primitives import DealDamageToChosenOpponentPokemon, resolve_attack_damage  # noqa: E402


@dataclass(frozen=True)
class DealDamageToChosenOpponentPokemonX(DealDamageToChosenOpponentPokemon):
    """相手の場のポケモン1匹を選んでamountダメージ。subtypesを指定すると、そのサブタイプのいずれかを持つポケモンだけが対象。
    bench_only=Trueならベンチのポケモンだけ。ignore_wr=Trueなら(バトルポケモンでも)弱点・抵抗力を計算しない。ignore_effects=Trueなら相手にかかっている効果も無視。
    条件に合う対象がいなければ何もしない。"""

    ignore_wr: bool = False
    ignore_effects: bool = False
    subtypes: tuple = ()
    bench_only: bool = False

    def target_ok(self, card_db, mon, slot: int) -> bool:
        if self.bench_only and slot == 0:
            return False
        if self.subtypes:
            card = card_db.get(mon.card_id)
            return card is not None and any(s in card.subtypes for s in self.subtypes)
        return True

    def execute(self, ctx: EffectContext) -> None:
        if ctx.source_pokemon is None:
            return
        opponent = ctx.state.player(ctx.opponent)
        slot = 0 if ctx.target_bench_index is None else ctx.target_bench_index + 1
        target = opponent.active if slot == 0 else (opponent.bench[slot - 1] if 0 < slot <= len(opponent.bench) else None)
        if target is None or not self.target_ok(ctx.card_db, target, slot):
            return
        _damage_one(ctx, target, self.amount, apply_wr=(slot == 0 and not self.ignore_wr), ignore_effects=self.ignore_effects)


def _damage_one(ctx: EffectContext, target, amount: int, apply_wr: bool, ignore_effects: bool = False) -> int:
    from effects.primitives import _defender_is_shielded

    if _defender_is_shielded(ctx, target):
        return 0
    card = ctx.card_db.get(target.card_id)
    if card is None:
        return 0
    dmg = resolve_attack_damage(
        ctx, target, card, amount, apply_weakness=apply_wr, apply_resistance=apply_wr, apply_defender_side_effects=not ignore_effects
    )
    target.damage += dmg
    ctx.damage_dealt += dmg
    ctx.log(f"{ctx.source_card_id} が {target.card_id} に {dmg} ダメージ")
    return dmg


@dataclass(frozen=True)
class DealDamageToEachOpponentPokemonMatching(Effect):
    """相手の場の、条件(subtypes=サブタイプのいずれか。空なら全員)に合う各ポケモンにamountダメージ。
    ベンチは弱点・抵抗力を計算しない。バトルポケモンも計算しないのはignore_wr=True。ignore_effects=Trueなら相手にかかっている効果も無視。"""

    amount: int
    subtypes: tuple = ()
    ignore_wr: bool = False
    ignore_effects: bool = False

    def execute(self, ctx: EffectContext) -> None:
        for slot, mon in _opp_slots(ctx):
            card = ctx.card_db.get(mon.card_id)
            if self.subtypes and (card is None or not any(s in card.subtypes for s in self.subtypes)):
                continue
            _damage_one(ctx, mon, self.amount, apply_wr=(slot == 0 and not self.ignore_wr), ignore_effects=self.ignore_effects)


# ---------------------------------------------------------------------------------------------
# トラッシュからベンチへ
# ---------------------------------------------------------------------------------------------
@dataclass(frozen=True)
class PutFromDiscardOntoBench(Effect):
    """自分のトラッシュから、条件(criterion)に合うポケモンを好きな組み合わせでcount匹までベンチに出す。"""

    count: int
    criterion: str

    def execute(self, ctx: EffectContext) -> None:
        from effects.primitives import SearchDeckMultiCriteria, _trigger_search_choice

        player = _attacker_player(ctx)
        _trigger_search_choice(
            ctx, player, "discard", lambda c: c is not None and SearchDeckMultiCriteria._matches(c, self.criterion), self.count,
            f"トラッシュからベンチに出すポケモンを最大{self.count}匹選ぶ", shuffle_after=False, destination="bench",
        )


def register_ops_b() -> None:
    from effects.era_primitives_b import GENERIC_OP_HANDLERS

    GENERIC_OP_HANDLERS.update({"hand_discard_damage": _op_hand_discard_damage})


register_ops_b()


# ---------------------------------------------------------------------------------------------
# 数えるダメージ
# ---------------------------------------------------------------------------------------------
@dataclass(frozen=True)
class _MatchFilter:
    """場のポケモンを数える効果の共通条件(全ての条件に合うものだけ数える)。
    side="own"=自分 / "opp"=相手。where="bench"ならベンチのみ。ptype=タイプ / subtype=サブタイプ / subtypes=サブタイプのいずれか /
    stage="Basic"|"Evolution" / name_contains=名前に含む語 / name_exact=名前 / names=名前のいずれか / damaged=ダメカンがのっている /
    has_energy_type=そのタイプのエネルギーがついている / retreat_exactly=にげるコストの数 / has_attack=そのワザ名を持つ。"""

    side: str = "own"
    where: str = "all"
    ptype: str | None = None
    subtype: str | None = None
    subtypes: tuple = ()
    stage: str | None = None
    name_contains: str | None = None
    name_exact: str | None = None
    names: tuple = ()
    damaged: bool = False
    has_energy_type: str | None = None
    retreat_exactly: int | None = None
    has_attack: str | None = None
    exclude_subtype: str | None = None

    def count(self, ctx: EffectContext) -> int:
        owner = ctx.state.player(ctx.acting_player if self.side == "own" else ctx.opponent)
        mons = owner.bench if self.where == "bench" else owner.all_pokemon_in_play()
        n = 0
        for mon in mons:
            card = ctx.card_db.get(mon.card_id)
            if card is None:
                continue
            if self.ptype and self.ptype not in card.types:
                continue
            if self.subtype and self.subtype not in card.subtypes:
                continue
            if self.exclude_subtype and self.exclude_subtype in card.subtypes:
                continue
            if self.subtypes and not any(s in card.subtypes for s in self.subtypes):
                continue
            if self.stage == "Basic" and not card.is_basic:
                continue
            if self.stage == "Evolution" and card.is_basic:
                continue
            if self.name_contains and self.name_contains not in card.name:
                continue
            if self.name_exact and card.name != self.name_exact:
                continue
            if self.names and card.name not in self.names:
                continue
            if self.damaged and mon.damage <= 0:
                continue
            if self.has_energy_type and not any(
                (c := ctx.card_db.get(e)) is not None and c.basic_energy_type == self.has_energy_type for e in mon.attached_energy
            ):
                continue
            if self.retreat_exactly is not None and card.retreat_cost_count != self.retreat_exactly:
                continue
            if self.has_attack and not any(a.name == self.has_attack for a in card.attacks):
                continue
            n += 1
        return n


@dataclass(frozen=True)
class DamagePerOwnPokemonMatching(_MatchFilter, Effect):
    """場のポケモン(条件は_MatchFilter)の数×perを、baseに足したダメージ。"""

    base: int = 0
    per: int = 0

    def execute(self, ctx: EffectContext) -> None:
        DealDamage(self.base + self.per * self.count(ctx)).execute(ctx)


@dataclass(frozen=True)
class DrawPerOwnPokemonMatching(_MatchFilter, Effect):
    """場のポケモン(条件は_MatchFilter)1匹につきper枚引く。"""

    per: int = 1

    def execute(self, ctx: EffectContext) -> None:
        player = _attacker_player(ctx)
        for _ in range(self.per * self.count(ctx)):
            if not player.deck:
                break
            player.hand.append(player.deck.pop(0))


@dataclass(frozen=True)
class DamagePerOwnLostZonePokemon(Effect):
    """自分のロストゾーンにあるポケモン1枚につきperダメージ(exclude_subtypeのポケモンは数えない)(ロストマーチ)。"""

    per: int
    exclude_subtype: str | None = None

    def execute(self, ctx: EffectContext) -> None:
        n = sum(
            1 for cid in _attacker_player(ctx).lost_zone
            if (c := ctx.card_db.get(cid)) is not None and c.is_pokemon and not (self.exclude_subtype and self.exclude_subtype in c.subtypes)
        )
        DealDamage(self.per * n).execute(ctx)


def _count_kind(ctx: EffectContext, pile: list[str], criterion: str) -> int:
    from effects.primitives import SearchDeckMultiCriteria

    return sum(1 for cid in pile if (c := ctx.card_db.get(cid)) is not None and SearchDeckMultiCriteria._matches(c, criterion))


@dataclass(frozen=True)
class DamagePerOwnDiscardKind(Effect):
    """自分のトラッシュにある、条件(criterion)に合うカード1枚につきperダメージ(+base)。capを指定すると、足すぶんの上限。"""

    base: int = 0
    per: int = 0
    criterion: str = "pokemon"
    cap: int | None = None

    def execute(self, ctx: EffectContext) -> None:
        add = self.per * _count_kind(ctx, _attacker_player(ctx).discard, self.criterion)
        DealDamage(self.base + (min(add, self.cap) if self.cap is not None else add)).execute(ctx)


@dataclass(frozen=True)
class DamagePerOpponentDiscardKind(Effect):
    """相手のトラッシュにある、条件(criterion)に合うカード1枚につきperダメージ(+base)。"""

    base: int = 0
    per: int = 0
    criterion: str = "any_energy"

    def execute(self, ctx: EffectContext) -> None:
        DealDamage(self.base + self.per * _count_kind(ctx, ctx.state.player(ctx.opponent).discard, self.criterion)).execute(ctx)


@dataclass(frozen=True)
class DamagePerOwnDiscardEnergyTypes(Effect):
    """自分のトラッシュにある基本エネルギーの、種類の数1つにつきperダメージ(+base)。足すぶんの上限はcap。"""

    base: int = 0
    per: int = 0
    cap: int | None = None

    def execute(self, ctx: EffectContext) -> None:
        kinds = {c.basic_energy_type for cid in _attacker_player(ctx).discard if (c := ctx.card_db.get(cid)) is not None and c.basic_energy_type}
        add = self.per * len(kinds)
        DealDamage(self.base + (min(add, self.cap) if self.cap is not None else add)).execute(ctx)


@dataclass(frozen=True)
class DamagePerOpponentTotalDamageCounters(Effect):
    """相手の場の全てのポケモンにのっているダメカンの合計1個につきperダメージ(+base)。"""

    base: int = 0
    per: int = 0

    def execute(self, ctx: EffectContext) -> None:
        n = sum(m.damage // 10 for m in ctx.state.player(ctx.opponent).all_pokemon_in_play())
        DealDamage(self.base + self.per * n).execute(ctx)


@dataclass(frozen=True)
class DamagePlusPerEnergy(Effect):
    """エネルギー1枚につきperダメージをbaseに足す。whose="self"=このポケモンについているもの / "own_all"=自分の場の全て / "opp_all"=相手の場の全て。
    basic_only=Trueなら基本エネルギーだけ数える。"""

    base: int = 0
    per: int = 0
    whose: str = "self"
    basic_only: bool = False

    def execute(self, ctx: EffectContext) -> None:
        if self.whose == "self":
            mons = [ctx.source_pokemon] if ctx.source_pokemon is not None else []
        elif self.whose == "own_all":
            mons = _attacker_player(ctx).all_pokemon_in_play()
        else:
            mons = ctx.state.player(ctx.opponent).all_pokemon_in_play()
        n = 0
        for mon in mons:
            for e in mon.attached_energy:
                c = ctx.card_db.get(e)
                if not self.basic_only or (c is not None and c.is_energy and not c.is_special_energy):
                    n += 1
        DealDamage(self.base + self.per * n).execute(ctx)


@dataclass(frozen=True)
class BonusDamageIgnoringWeaknessIf(Effect):
    """条件を満たすとき追加ダメージを与え、そのダメージは弱点を計算しない(Thunderous Assault等)。"""

    base: int
    bonus: int
    condition: str
    arg: str = ""

    def execute(self, ctx: EffectContext) -> None:
        from effects.primitives import DealDamageIgnoringWeaknessOnly

        if _ep.condition_met(ctx, self.condition, self.arg):
            DealDamageIgnoringWeaknessOnly(self.base + self.bonus).execute(ctx)
        else:
            DealDamage(self.base).execute(ctx)


@dataclass(frozen=True)
class BonusPrizeIfKnockedOutSubtypes(Effect):
    """このワザのダメージで、指定のサブタイプ(のいずれか)を持つ相手のポケモンがきぜつしたら、追加でサイドをbonus枚多く取る(Greedy Crush等)。"""

    bonus: int
    subtypes: tuple

    def execute(self, ctx: EffectContext) -> None:
        from engine.continuous import effective_max_hp

        opponent = ctx.state.player(ctx.opponent)
        for mon in opponent.all_pokemon_in_play():
            card = ctx.card_db.get(mon.card_id)
            if card is None or (self.subtypes and not any(s in card.subtypes for s in self.subtypes)):  # subtypesが空なら、どのポケモンでもよい
                continue
            max_hp = effective_max_hp(ctx.card_db, mon.card_id, mon.attached_tool, ctx.state.stadium_in_play, mon.attached_energy)
            if max_hp and mon.is_knocked_out(max_hp):
                _attacker_player(ctx).bonus_prize_next_knockout = self.bonus
                return


@dataclass(frozen=True)
class HealAllOwnPokemonWithEnergyType(Effect):
    """自分の場の、指定タイプの基本エネルギーがついているポケモン全員のダメージを回復する(amount=Noneなら全て)。"""

    energy_type: str
    amount: int | None = None

    def execute(self, ctx: EffectContext) -> None:
        for mon in _attacker_player(ctx).all_pokemon_in_play():
            if any((c := ctx.card_db.get(e)) is not None and c.basic_energy_type == self.energy_type for e in mon.attached_energy):
                mon.damage = 0 if self.amount is None else max(0, mon.damage - self.amount)


@dataclass(frozen=True)
class DiscardOwnTool(Effect):
    """このポケモンについているポケモンのどうぐをトラッシュする。"""

    def execute(self, ctx: EffectContext) -> None:
        from engine.state import discard_attached_tool

        if ctx.source_pokemon is not None:
            discard_attached_tool(ctx.state, _attacker_player(ctx), ctx.source_pokemon)


def _cond_supporter_named_played(ctx, arg, player, opponent, self_mon, defender) -> bool:
    return arg in player.supporter_names_this_turn


def _cond_own_prizes_more_by(ctx, arg, player, opponent, self_mon, defender) -> bool:
    return len(player.prizes) - len(opponent.prizes) >= int(arg)


def register_conditions_c() -> None:
    _ep.EXTRA_CONDITIONS.update({
        "supporter_named_played": _cond_supporter_named_played,
        "own_prizes_more_by": _cond_own_prizes_more_by,
    })


register_conditions_c()


# ---------------------------------------------------------------------------------------------
# 手札・トラッシュ・場のカードをまとめて捨てる
# ---------------------------------------------------------------------------------------------
@dataclass(frozen=True)
class DiscardAllSpecialEnergyFromAllPokemon(Effect):
    """場の全てのポケモン(自分・相手とも)についている特殊エネルギーを全てトラッシュする(メタリックサウンド)。"""

    def execute(self, ctx: EffectContext) -> None:
        for side in (ctx.acting_player, ctx.opponent):
            owner = ctx.state.player(side)
            for mon in owner.all_pokemon_in_play():
                if side == ctx.opponent and _defender_blocks_effect(ctx, mon):
                    continue
                keep, gone = [], []
                for e in mon.attached_energy:
                    c = ctx.card_db.get(e)
                    (gone if c is not None and c.is_special_energy else keep).append(e)
                mon.attached_energy = keep
                owner.discard.extend(gone)


@dataclass(frozen=True)
class RevealOpponentHandDiscardAllKind(Effect):
    """相手の手札を公開させ、その中の指定の種類(kind="supporter"|"item"|"trainer"|"pokemon"|"energy")のカードを全てトラッシュする。"""

    kind: str

    def execute(self, ctx: EffectContext) -> None:
        from effects.primitives import SearchDeckMultiCriteria

        opponent = ctx.state.player(ctx.opponent)
        if not opponent.hand:
            return
        ctx.state.player(ctx.acting_player).known_opponent_hand = list(opponent.hand)
        ctx.reveal("相手の手札", list(opponent.hand))
        keep, gone = [], []
        for cid in opponent.hand:
            c = ctx.card_db.get(cid)
            (gone if c is not None and SearchDeckMultiCriteria._matches(c, self.kind) else keep).append(cid)
        opponent.hand = keep
        opponent.discard.extend(gone)
        ctx.log(f"相手の手札の{self.kind}を{len(gone)}枚トラッシュした")


@dataclass(frozen=True)
class MayDiscardHandDownTo(Effect):
    """手札が(keep)枚になるまで、好きなだけ手札をトラッシュしてもよい(0枚でもよい。keep枚より少なくはできない)(マッハデリバリーGX)。
    続けてDrawUpToを並べると「そのあと、手札がN枚になるまで引く」になる。"""

    keep: int

    def execute(self, ctx: EffectContext) -> None:
        from effects.primitives import _trigger_search_choice

        player = _attacker_player(ctx)
        n = len(player.hand) - self.keep
        if n <= 0:
            return
        _trigger_search_choice(
            ctx, player, "hand", lambda card: True, n, f"手札を{self.keep}枚になるまで好きなだけトラッシュする(選ばなくてもよい)",
            shuffle_after=False, destination="discard", min_count=0,
        )


@dataclass(frozen=True)
class DiscardAllCardsFromBothActive(Effect):
    """おたがいのバトルポケモンについているカード(エネルギー・どうぐ)を全てトラッシュする(ダストストーム)。"""

    def execute(self, ctx: EffectContext) -> None:
        from engine.state import discard_attached_tool

        for side in (ctx.acting_player, ctx.opponent):
            owner = ctx.state.player(side)
            mon = owner.active
            if mon is None or (side == ctx.opponent and _defender_blocks_effect(ctx, mon)):
                continue
            owner.discard.extend(mon.attached_energy)
            mon.attached_energy = []
            discard_attached_tool(ctx.state, owner, mon)


# ---------------------------------------------------------------------------------------------
# 引く・トラッシュから戻す・山札を落とす
# ---------------------------------------------------------------------------------------------
@dataclass(frozen=True)
class SearchDiscardByCriterionToHand(Effect):
    """自分のトラッシュから、条件(criterion。SearchDeckMultiCriteriaと同じ条件文字列)に合うカードを最大count枚選んで手札に加える。"""

    criterion: str
    count: int = 1

    def execute(self, ctx: EffectContext) -> None:
        from effects.primitives import SearchDeckMultiCriteria, _trigger_search_choice

        _trigger_search_choice(
            ctx, _attacker_player(ctx), "discard", lambda c: c is not None and SearchDeckMultiCriteria._matches(c, self.criterion), self.count,
            f"トラッシュから手札に加えるカードを最大{self.count}枚選ぶ", shuffle_after=False, destination="hand",
        )


@dataclass(frozen=True)
class EachPlayerDraws(Effect):
    """おたがいに、山札からcount枚引く(ワザを使った側が先)。"""

    count: int = 1

    def execute(self, ctx: EffectContext) -> None:
        for side in (ctx.acting_player, ctx.opponent):
            player = ctx.state.player(side)
            for _ in range(self.count):
                if not player.deck:
                    break
                player.hand.append(player.deck.pop(0))


@dataclass(frozen=True)
class EachPlayerDrawsUpTo(Effect):
    """おたがいに、手札がcount枚になるまで山札を引く。"""

    count: int

    def execute(self, ctx: EffectContext) -> None:
        for side in (ctx.acting_player, ctx.opponent):
            player = ctx.state.player(side)
            while len(player.hand) < self.count and player.deck:
                player.hand.append(player.deck.pop(0))


@dataclass(frozen=True)
class FlipUntilTailsDrawPerHeads(Effect):
    """ウラが出るまでコインを投げ、オモテ1枚につき山札を1枚引く。"""

    def execute(self, ctx: EffectContext) -> None:
        player = _attacker_player(ctx)
        heads = 0
        while ctx.rng.random() < 0.5:
            heads += 1
        ctx.log(f"コイン: オモテ{heads}回")
        for _ in range(heads):
            if not player.deck:
                break
            player.hand.append(player.deck.pop(0))


@dataclass(frozen=True)
class DiscardOwnEnergyThenOpponentDeckTop(Effect):
    """このポケモンについている指定タイプのエネルギーを全てトラッシュし、トラッシュした1枚につき相手の山札の上を1枚トラッシュする(トップバーナー)。"""

    energy_type: str

    def execute(self, ctx: EffectContext) -> None:
        mon = ctx.source_pokemon
        if mon is None:
            return
        player = _attacker_player(ctx)
        keep, gone = [], []
        for e in mon.attached_energy:
            c = ctx.card_db.get(e)
            (gone if c is not None and c.basic_energy_type == self.energy_type else keep).append(e)
        mon.attached_energy = keep
        player.discard.extend(gone)
        opponent = ctx.state.player(ctx.opponent)
        for _ in range(len(gone)):
            if not opponent.deck:
                break
            opponent.discard.append(opponent.deck.pop(0))
        ctx.log(f"エネルギー{len(gone)}枚をトラッシュし、相手の山札の上を{len(gone)}枚トラッシュした")


@dataclass(frozen=True)
class ShuffleFromDiscardByCriterionIntoDeck(Effect):
    """自分のトラッシュから、条件(criterion。"any"=何でも)に合うカードをちょうどcount枚(足りなければある分)選んで山札に戻してシャッフルする。"""

    criterion: str
    count: int

    def execute(self, ctx: EffectContext) -> None:
        from effects.primitives import SearchDeckMultiCriteria, _trigger_search_choice

        def ok(c):
            return c is not None and (self.criterion == "any" or SearchDeckMultiCriteria._matches(c, self.criterion))

        _trigger_search_choice(
            ctx, _attacker_player(ctx), "discard", ok, self.count, f"トラッシュから山札に戻すカードを{self.count}枚選ぶ",
            shuffle_after=True, destination="deck", min_count=self.count,
        )


# ---------------------------------------------------------------------------------------------
# 追加エネルギー(複数タイプ)・自分/相手のポケモンをまとめて動かす・ダメカン
# ---------------------------------------------------------------------------------------------
def extra_energy_satisfied(ctx: EffectContext, cost: tuple, needs: tuple) -> bool:
    """このワザのコストを(なるべく不要なエネルギーで)払ったあとに、needs=((タイプ, 枚数), ...)の追加エネルギーが残っているか。
    コストの無色には、needsに無いタイプ・特殊エネルギーを先に使い、足りなければneedsのタイプを使う。"""
    mon = ctx.source_pokemon
    if mon is None:
        return False
    avail: dict = {}
    for e in mon.attached_energy:
        c = ctx.card_db.get(e)
        kind = c.basic_energy_type if c is not None and c.basic_energy_type else None
        avail[kind] = avail.get(kind, 0) + 1
    for t in cost:
        if t != "Colorless" and avail.get(t, 0) > 0:
            avail[t] -= 1
    colorless = sum(1 for t in cost if t == "Colorless")
    needed = {t for t, _ in needs}
    for t in [k for k in list(avail) if k not in needed] + [k for k in list(avail) if k in needed]:
        take = min(avail[t], colorless)
        avail[t] -= take
        colorless -= take
    return all(avail.get(t, 0) >= n for t, n in needs)


@dataclass(frozen=True)
class IfExtraEnergyMulti(Effect):
    """「このポケモンに、(このワザのコストに加えて)Fire、Water、Lightningのエネルギーが追加でそれぞれN個以上ついていれば」: 複数タイプの追加エネルギーの条件。
    costはこのワザのコスト(タイプの並び)、needsは((タイプ, 枚数), ...)。条件を満たすときだけthenを実行する。"""

    cost: tuple
    needs: tuple
    then: tuple

    def execute(self, ctx: EffectContext) -> None:
        if extra_energy_satisfied(ctx, self.cost, self.needs):
            from effects.interpreter import run_script

            run_script(tuple(self.then), ctx)


@dataclass(frozen=True)
class SelfToLostZone(Effect):
    """このポケモンとついているカードを全てロストゾーンに置く(バトル場にいるなら、ベンチがあれば新しいバトルポケモンを選ぶ)(ロストブラスト等)。"""

    def execute(self, ctx: EffectContext) -> None:
        player = _attacker_player(ctx)
        mon = ctx.source_pokemon
        if mon is None:
            return
        if player.active is mon:
            player.active = None
            if player.bench:
                ctx.state.pending_active_choice = [ctx.acting_player]
                ctx.state.then_after_choice = "continue"
        elif mon in player.bench:
            player.bench.remove(mon)
        else:
            return
        player.lost_zone.extend(mon.evolution_history)
        player.lost_zone.append(mon.card_id)
        player.lost_zone.extend(mon.attached_energy)
        if mon.attached_tool:
            player.lost_zone.append(mon.attached_tool)
        ctx.log(f"{mon.card_id} とついているカードを全てロストゾーンに置いた")


@dataclass(frozen=True)
class DamageCountersOnEveryPokemon(Effect):
    """場の全てのポケモン(自分・相手とも)にダメカンをcount個ずつのせる(ナイトローム)。"""

    count: int

    def execute(self, ctx: EffectContext) -> None:
        from effects.primitives import _blocks_damage_counters

        for side in (ctx.acting_player, ctx.opponent):
            for mon in ctx.state.player(side).all_pokemon_in_play():
                if side == ctx.opponent and _defender_blocks_effect(ctx, mon):
                    continue
                if not _blocks_damage_counters(mon):
                    mon.damage += 10 * self.count


@dataclass(frozen=True)
class DamageCountersOnEachOpponentPokemonWhere(Effect):
    """相手の場の、条件に合うポケモン全員にダメカンをcount個ずつのせる。has_tool=Trueならポケモンのどうぐがついているポケモンだけ。"""

    count: int
    has_tool: bool = False

    def execute(self, ctx: EffectContext) -> None:
        from effects.era_primitives_f import put_counters

        for _slot, mon in _opp_slots(ctx):
            if self.has_tool and mon.attached_tool is None:
                continue
            put_counters(ctx, mon, self.count)


@dataclass(frozen=True)
class MoveOpponentEnergyCountToLostZone(Effect):
    """相手のバトルポケモンについているエネルギーを、count枚(足りなければある分)選んでロストゾーンに置く(ロストフレイム)。"""

    count: int

    def execute(self, ctx: EffectContext) -> None:
        opponent, defender = _defender(ctx)
        if defender is None or _defender_blocks_effect(ctx, defender):
            return
        source_indices, card_ids = _opp_energy_entries(ctx, only_slot=0)
        n = min(self.count, len(card_ids))
        if n <= 0:
            return
        if n >= len(card_ids) or len(set(card_ids)) == 1:
            for _ in range(n):
                opponent.lost_zone.append(defender.attached_energy.pop())
            return
        ctx.state.pending_search_choice = PendingSearchChoice(
            player_index=ctx.acting_player,
            zone="field_attachment",
            source_indices=source_indices,
            card_ids=card_ids,
            min_count=n,
            max_count=n,
            prompt=f"ロストゾーンに置く相手のバトルポケモンのエネルギーを{n}枚選ぶ",
            shuffle_after=False,
            all_card_ids=list(card_ids),
            destination="lost_zone",
            effect_source=ctx.effect_source,
        )
