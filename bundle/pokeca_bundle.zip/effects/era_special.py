"""時代ごとのカード取り込み(2026-10-07〜)で追加した、既存の仕組みに収まらない特性。

- Final Wish(マナフィ): きぜつ時に山札から好きなカードを手札に加える(きぜつ時の効果の待ち行列 state.ko_followups を使う)
- Leap Through Time(セレビィ): きぜつ時にコイン。オモテなら山札に戻り、相手はサイドを取れない
- Bright Veil(トゲキッス): バトル場にいる間、相手が使うグッズの、自分のポケモンへの効果を無効にする
- Stance Change(ギルガルド)/Transform(メタモン): 手札のポケモンと入れ替わる/重ねてそのポケモンになる
- Busybody(タブンネ): 手札にいるとき、公開してバトルポケモンのダメージ回復・特殊状態回復をしてトラッシュする(手札発動型の特性)

対象のカードIDは、カードデータベースの特性名から scripts/build_era_trainer_ids.py の仕組みと同じ方法で生成した
effects/generated_era_trainer_ids.py(SPECSに特性持ちポケモンも登録している)から引く。
"""

from __future__ import annotations

from dataclasses import dataclass

from effects.context import EffectContext
from effects.era_trainers import _ids
from effects.primitives import Effect, HealTarget, RemoveOneActiveStatusCondition, _attacker_player
from engine.state import PendingSearchChoice


# ---------------------------------------------------------------------------------------------
# 手札の別のポケモンと入れ替わる(Stance Change)/重なってそのポケモンになる(Transform)
# ---------------------------------------------------------------------------------------------
@dataclass(frozen=True)
class SwapWithPokemonInHand(Effect):
    """このポケモンを、手札のポケモンと入れ替える。kind="stance": 同名のポケモン1枚と入れ替える(自分は手札に戻る)。
    kind="transform": 手札のたねポケモン1枚を上に重ね、そのポケモンになる(自分は下に残る)。
    ついているカード・ダメカン・特殊状態・場に出てからの経過ターン等はそのまま引き継ぐ(進化でも場に出すでもない)。"""

    kind: str
    name: str = ""

    def _candidates(self, player, card_db, mon) -> list[int]:
        out = []
        for i, cid in enumerate(player.hand):
            card = card_db.get(cid)
            if card is None or not card.is_pokemon:
                continue
            if self.kind == "stance" and card.name == self.name:
                out.append(i)
            elif self.kind == "transform" and card.is_basic:
                out.append(i)
        return out

    def ability_gate(self, state, player, mon, zone, card_db) -> bool:
        return bool(self._candidates(player, card_db, mon))

    def execute(self, ctx: EffectContext) -> None:
        player = _attacker_player(ctx)
        mon = ctx.source_pokemon
        if mon is None:
            return
        idx = self._candidates(player, ctx.card_db, mon)
        if not idx:
            return
        ctx.state.pending_search_choice = PendingSearchChoice(
            player_index=ctx.acting_player,
            zone="hand",
            source_indices=idx,
            card_ids=[player.hand[i] for i in idx],
            min_count=1,
            max_count=1,
            prompt="入れ替える手札のポケモンを選ぶ" if self.kind == "stance" else "上に重ねる手札のたねポケモンを選ぶ",
            shuffle_after=False,
            all_card_ids=list(player.hand),
            destination="swap_hand_identity",
            attach_target_pokemon=mon,
            custom_data={"swap_kind": self.kind},
            effect_source="ability",
        )


def resolve_swap_hand_identity(player, target, picked_card_ids: list[str], swap_kind: str) -> str:
    """rules_engineの選択解決から呼ばれる。targetのcard_idを、選んだ手札のカードに変える。ログ用の文を返す。"""
    if target is None or not picked_card_ids:
        return ""
    new_id = picked_card_ids[0]
    if swap_kind == "transform":
        target.evolution_history.append(target.card_id)  # メタモン自身は下に残る(きぜつ時は一緒にトラッシュされる)
    else:
        player.hand.append(target.card_id)  # 入れ替わった元のカードは手札に戻る
    target.card_id = new_id
    return "と入れ替わった" if swap_kind == "stance" else "を重ねてそのポケモンになった"


# ---------------------------------------------------------------------------------------------
# 手札発動型の特性(Busybody)
# ---------------------------------------------------------------------------------------------
HAND_ABILITY_SCRIPTS: dict[str, tuple] = {}


def has_hand_ability(card_id: str) -> bool:
    return card_id in HAND_ABILITY_SCRIPTS


def hand_ability_usable(state, player, card_db, card_id: str) -> bool:
    """手札にいるポケモンの特性を、いま使う意味があるか(Busybody: バトルポケモンが回復/特殊状態の回復ができる)。"""
    if card_id in BUSYBODY_IDS:
        active = player.active
        from effects.primitives import _present_status_labels

        return active is not None and (active.damage > 0 or bool(_present_status_labels(active.status)))
    return True


# ---------------------------------------------------------------------------------------------
# きぜつ時の特性・Bright Veil
# ---------------------------------------------------------------------------------------------
FINAL_WISH_IDS = frozenset(_ids("final_wish"))
LEAP_THROUGH_TIME_IDS = frozenset(_ids("leap_through_time"))
BRIGHT_VEIL_IDS = frozenset(_ids("bright_veil"))
BUSYBODY_IDS = frozenset(_ids("busybody"))


def collect_ko_ability_followups(state, card_db, owner_index: int, pokemon, by_attack: bool, was_active: bool = True) -> None:
    """きぜつしたポケモン(トラッシュする前)の、きぜつ時に発動する特性(Final Wish/Final Chain/Photon Cord)を待ち行列に積む。"""
    from effects.passives_ext import collect_ko_followups_ext

    collect_ko_followups_ext(state, card_db, owner_index, pokemon, by_attack, was_active)
    if pokemon.card_id in FINAL_WISH_IDS and by_attack:
        from engine.continuous import ability_suppressed

        if not ability_suppressed(state, card_db, owner_index, pokemon):
            state.ko_followups.append({"kind": "search_deck_any", "owner": owner_index, "label": "Final Wish"})


def leap_through_time_applies(state, card_db, owner_index: int, pokemon) -> bool:
    """セレビィがきぜつしたとき、コインを投げてオモテなら山札に戻り、相手はサイドを取れない(1回のきぜつにつきコイン1回)。"""
    if pokemon.card_id not in LEAP_THROUGH_TIME_IDS:
        return False
    from engine.continuous import ability_suppressed

    if ability_suppressed(state, card_db, owner_index, pokemon):
        return False
    heads = state.rng.random() < 0.5
    state.add_log("セレビィの「Leap Through Time」: コイン " + ("オモテ。山札に戻り、相手はサイドを取れない" if heads else "ウラ"))
    return heads


def item_effects_shielded(state, card_db, item_owner: int, script, kind: str = "item", target_bench_index=None) -> bool:
    """トゲキッスの「Bright Veil」: item_ownerが使うグッズの、相手のポケモンへの効果を無効にするか。
    グッズの効果(スクリプト)が相手の場のポケモンに作用するもの(入れ替え・エネルギーのトラッシュ等)のときだけ、無効にする。
    Snow Camouflage/Protective Sail(そのポケモン自身だけを守る特性)は、対象のポケモンがそれを持つときに無効にする。"""
    from effects.passives_ext import card_effect_shielded

    if card_effect_shielded(state, card_db, item_owner, kind, target_bench_index, script):
        return True
    if kind != "item":
        return False
    defender_index = 1 - item_owner
    defender = state.player(defender_index)
    active = defender.active
    if active is None or active.card_id not in BRIGHT_VEIL_IDS:
        return False
    from engine.continuous import ability_suppressed

    if ability_suppressed(state, card_db, defender_index, active):
        return False
    return _script_affects_opponent_pokemon(script)


def _script_affects_opponent_pokemon(script) -> bool:
    from dataclasses import fields, is_dataclass

    for effect in script:
        name = type(effect).__name__
        if ("Opponent" in name or "Defender" in name) and not any(k in name for k in ("Hand", "Deck", "Prize")):
            return True
        if is_dataclass(effect):
            for f in fields(effect):
                value = getattr(effect, f.name)
                if isinstance(value, tuple) and value and all(isinstance(v, Effect) for v in value):
                    if _script_affects_opponent_pokemon(value):
                        return True
    return False


HEAL_BLOCK_IDS = frozenset(_ids("heal_block"))


def heal_block_active(state, card_db) -> bool:
    """ドータクンの「Heal Block」: 場(両プレイヤー)に、特性が有効なドータクンがいる間、どのポケモンもダメージを回復できない。"""
    from effects.era_tools_j import has_reaction

    if has_reaction(state.stadium_in_play, "react_no_heal"):
        return True  # ダイナツリーヒル: おたがいのポケモンはダメージを回復できない
    if not HEAL_BLOCK_IDS:
        return False
    from engine.continuous import ability_suppressed

    for side in (0, 1):
        for mon in state.player(side).all_pokemon_in_play():
            if mon.card_id in HEAL_BLOCK_IDS and not ability_suppressed(state, card_db, side, mon):
                return True
    return False


# ---------------------------------------------------------------------------------------------
# 登録
# ---------------------------------------------------------------------------------------------
_INSTALLED = False


def install() -> None:
    global _INSTALLED
    if _INSTALLED:
        return
    _INSTALLED = True
    from effects import registry as R

    for card_id in _ids("busybody"):
        HAND_ABILITY_SCRIPTS.setdefault(card_id, (HealTarget(10), RemoveOneActiveStatusCondition()))
    for card_id in _ids("stance_change"):
        R.ABILITY_EFFECTS.setdefault(card_id, {}).setdefault("Stance Change", (SwapWithPokemonInHand("stance", "Aegislash"),))
    for card_id in _ids("transform_bw7"):
        R.ABILITY_EFFECTS.setdefault(card_id, {}).setdefault("Transform", (SwapWithPokemonInHand("transform"),))
