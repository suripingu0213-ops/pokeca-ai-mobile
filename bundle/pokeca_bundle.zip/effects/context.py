"""効果プリミティブの実行に必要な情報をまとめたコンテキスト。"""

from __future__ import annotations

import random
from dataclasses import dataclass, field

from cards.card_db import CardDatabase
from engine.state import GameState, PokemonInPlay


class _FirstCoinForcedRng:
    """「この番、最初に投げるコインの結果を選ぶ」(ウィル)が有効なプレイヤーのEffectContext用の乱数源。最初のrandom()だけ決めた結果を返し、印を消す。"""

    def __init__(self, rng: random.Random, player):
        self._rng = rng
        self._player = player

    def random(self) -> float:
        forced = self._player.coin_first_forced
        if forced >= 0:
            self._player.coin_first_forced = -1
            self._rng.random()
            return 0.0 if forced == 0 else 0.99
        return self._rng.random()

    def __getattr__(self, name):
        return getattr(self._rng, name)


class _AlwaysTailsRng:
    """「相手の次の番、コインを投げるたびウラとして扱う」効果(Slap of Misfortune等)が有効なプレイヤーの
    EffectContext用の乱数源。random()だけ常にウラ(>=0.5)を返し、シャッフル等の他の操作は元の乱数源に委譲する。"""

    def __init__(self, rng: random.Random):
        self._rng = rng

    def random(self) -> float:
        self._rng.random()  # 乱数列の消費量を揃える
        return 0.99

    def __getattr__(self, name):
        return getattr(self._rng, name)


@dataclass
class EffectContext:
    state: GameState
    card_db: CardDatabase
    acting_player: int
    source_pokemon: PokemonInPlay | None  # ワザ/特性を使っているポケモン(トレーナーズならNone)
    source_card_id: str
    target_bench_index: int | None = None  # アクションで指定された追加ターゲット
    rng: random.Random = field(default_factory=random.Random)
    effect_source: str = "attack"  # "attack" | "ability": 現在実行中の効果がワザ由来か特性由来か
    # (ENTER_BENCH_TRIGGER_EFFECTS/ABILITY_EFFECTS/DISCARD_ABILITY_EFFECTSに登録される特性はこちらを
    # "ability"にする)。ミストエネルギー等の「ワザ限定」免疫(実カードテキストが「ワザ」限定と
    # 明記されているもの)を、同じEffectクラスがワザ/特性両方に登録されている場合(InflictStatusOnDefender、
    # DamageCounterOnChosenOpponentPokemon、DistributeDamageCountersFreely等)に正しく出し分けるための
    # フラグ。ばけがくれ等の「ワザ/特性共通」免疫はこのフラグに関わらず常に適用される
    # (effects.primitives._defender_blocks_effect参照、2026-09-04)。

    damage_dealt: int = 0  # このワザで防御側に実際に与えたダメージ(直近のDealDamage結果)
    last_coin_result: bool | None = None
    coin_heads_count: int = 0
    last_attach_succeeded: bool = False  # 直近のエネルギー添付系Effectが実際に何かをつけたか(カイの「Raihan」等、後続の条件付き効果用)
    last_discard_succeeded: bool = False  # 直近の手札コスト捨て系Effectが実際に何か捨てられたか(レントラーGLの「Trash Bolt」等)
    last_picked_card_ids: tuple[str, ...] = ()  # 直前のremaining_script起動元の検索選択で実際に選ばれたcard_id一覧(Crispin等の連鎖用)
    triggering_energy_id: str = ""  # エネルギー添付トリガーの場合、実際についたカードID(イーブイの「Energy Evolution」等)
    events: list[str] = field(default_factory=list)

    def __post_init__(self) -> None:
        player = self.state.player(self.acting_player)
        if player.coins_tails_until_turn > 0 and player.turns_taken <= player.coins_tails_until_turn:
            self.rng = _AlwaysTailsRng(self.rng)
        elif player.coin_first_forced >= 0:
            self.rng = _FirstCoinForcedRng(self.rng, player)
        elif self.state.setup_complete:
            from effects.passives import opponent_coins_are_tails

            if opponent_coins_are_tails(self.state, self.card_db, self.acting_player):
                self.rng = _AlwaysTailsRng(self.rng)  # Contrary: 相手のバトルポケモンの特性で、コインはウラ扱い

    @property
    def opponent(self) -> int:
        return self.state.opponent_index(self.acting_player)

    def log(self, message: str) -> None:
        self.events.append(message)
        self.state.add_log(message)

    def reveal(self, title: str, card_ids: list[str]) -> None:
        """選択の余地なく機械的に解決する「山札の中身を見る」系の効果(ポケストップ等)で、
        実際に見えたカードをWeb UIに一度表示するための非ブロッキングな通知。ゲーム進行(合法手・
        状態遷移)には一切影響しない、純粋な表示用の情報。呼ぶたびにlast_reveal_seqを進め、
        Web UI側が「新しい通知か」を判定できるようにする(state.last_reveal_seqのコメント参照)。"""
        self.state.last_reveal = {"title": title, "card_ids": list(card_ids)}
        self.state.last_reveal_seq += 1
