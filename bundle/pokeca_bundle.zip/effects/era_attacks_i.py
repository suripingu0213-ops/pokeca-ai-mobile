"""SWSH/SV期のワザ用の汎用プリミティブ(2026-10-07)。scripts/generate_effects_batch19.py のパターンが使う。

新しいカードの文面は「〜1枚につき」「〜なら追加ダメージ」の「数える物」「条件」が非常に多様なので、専用クラスを1つずつ作らず、
数える物(COUNTERS)と条件(effects.era_primitives.EXTRA_CONDITIONS)を名前+引数で登録する汎用形にする。
ポケモンの絞り込みは「型:値|型:値」の文字列(pokemon_matches)で表す: type/subtype/name/name_part/ability/attack/energy/damaged/evolution/basic/ex_rule。
ダメージは必ずDealDamageを1回だけ経由する(弱点・抵抗力・防御側の効果の計算を共通にするため)。
"""

from __future__ import annotations

from dataclasses import dataclass

from effects import era_primitives as _ep
from effects.context import EffectContext
from effects.primitives import DealDamage, Effect, _attacker_player

RULE_BOX_SUBTYPES = ("ex", "V", "VSTAR", "VMAX", "GX", "EX", "TAG TEAM", "MEGA")


# ---------------------------------------------------------------------------------------------
# ポケモン・カードの絞り込み
# ---------------------------------------------------------------------------------------------
def card_matches(card, spec: str) -> bool:
    """カードが絞り込み(spec)に合うか。specは「型:値|型:値」(全て満たす)。型: type/subtype/name/name_part/ability/attack/evolution/basic/no_rule_box/stage。"""
    if card is None:
        return False
    for token in filter(None, spec.split("|")):
        kind, _, value = token.partition(":")
        if kind == "type":
            ok = any(t in card.types for t in value.split(","))
        elif kind == "subtype":
            ok = any(s in card.subtypes for s in value.split(","))
        elif kind == "name":
            ok = card.name == value
        elif kind == "name_part":
            ok = value in card.name
        elif kind == "ability":
            ok = bool(card.abilities)
        elif kind == "attack":
            ok = any(a.name == value for a in card.attacks)
        elif kind == "evolution":
            ok = card.is_pokemon and not card.is_basic
        elif kind == "basic":
            ok = card.is_basic
        elif kind == "no_rule_box":
            ok = not any(s in card.subtypes for s in RULE_BOX_SUBTYPES)
        elif kind == "stage":
            ok = value in card.subtypes
        elif kind == "hp_at_most":
            ok = card.hp is not None and card.hp <= int(value)
        elif kind == "name_any":
            ok = any(part in card.name for part in value.split(","))  # いずれかの語を名前に含む
        elif kind == "no_ability":
            ok = not card.abilities
        elif kind == "retreat_exactly":
            ok = card.retreat_cost_count == int(value)
        elif kind == "not_subtype":
            ok = not any(s in card.subtypes for s in value.split(","))
        else:
            ok = False
        if not ok:
            return False
    return True


def pokemon_matches(ctx: EffectContext, mon, spec: str) -> bool:
    """場のポケモンが絞り込みに合うか(「energy:タイプ」「damaged」も使える)。"""
    card = ctx.card_db.get(mon.card_id)
    plain = []
    for token in filter(None, spec.split("|")):
        kind, _, value = token.partition(":")
        if kind == "damaged":
            if mon.damage <= 0:
                return False
        elif kind == "energy":
            if not any((c := ctx.card_db.get(e)) is not None and (c.basic_energy_type == value or (value == "any" and c.is_energy)) for e in mon.attached_energy):
                return False
        elif kind == "has_tool":
            if mon.attached_tool is None:
                return False
        else:
            plain.append(token)
    return card_matches(card, "|".join(plain))


def _mons(ctx: EffectContext, scope: str) -> list:
    me = _attacker_player(ctx)
    opp = ctx.state.player(ctx.opponent)
    if scope == "own_in_play":
        return me.all_pokemon_in_play()
    if scope == "own_bench":
        return list(me.bench)
    if scope == "opp_in_play":
        return opp.all_pokemon_in_play()
    if scope == "opp_bench":
        return list(opp.bench)
    if scope == "both_bench":
        return list(me.bench) + list(opp.bench)
    if scope == "both_in_play":
        return me.all_pokemon_in_play() + opp.all_pokemon_in_play()
    return []


def _energy_count(ctx: EffectContext, mons, arg: str) -> int:
    """mons についているエネルギーの数。arg: ""=全て / "basic"=基本エネルギーだけ / タイプ名=そのタイプの基本エネルギー / "special"=特殊エネルギー。"""
    n = 0
    for mon in mons:
        for e in mon.attached_energy:
            c = ctx.card_db.get(e)
            if c is None:
                continue
            if arg == "" or (arg == "basic" and c.is_energy and not c.is_special_energy) or (arg == "special" and c.is_special_energy) or c.basic_energy_type == arg:
                n += 1
    return n


# ---------------------------------------------------------------------------------------------
# 数える物(COUNTERS)。fn(ctx, arg) -> int
# ---------------------------------------------------------------------------------------------
def _c_self_energy(ctx, arg):
    return _energy_count(ctx, [ctx.source_pokemon] if ctx.source_pokemon is not None else [], arg)


def _c_opp_active_energy(ctx, arg):
    active = ctx.state.player(ctx.opponent).active
    return _energy_count(ctx, [active] if active is not None else [], arg)


def _c_opp_all_energy(ctx, arg):
    return _energy_count(ctx, ctx.state.player(ctx.opponent).all_pokemon_in_play(), arg)


def _c_both_active_energy(ctx, arg):
    mons = [m for m in (ctx.source_pokemon, ctx.state.player(ctx.opponent).active) if m is not None]
    return _energy_count(ctx, mons, arg)


def _c_own_all_energy(ctx, arg):
    return _energy_count(ctx, _attacker_player(ctx).all_pokemon_in_play(), arg)


def _c_own_hand(ctx, arg):
    return len(_attacker_player(ctx).hand)


def _c_opp_hand(ctx, arg):
    return len(ctx.state.player(ctx.opponent).hand)


def _c_pokemon(scope):
    def fn(ctx, arg):
        return sum(1 for m in _mons(ctx, scope) if pokemon_matches(ctx, m, arg))

    return fn


def _c_own_discard(ctx, arg):
    return sum(1 for cid in _attacker_player(ctx).discard if (c := ctx.card_db.get(cid)) is not None and card_matches(c, arg))


def _c_own_discard_kind(ctx, arg):
    from effects.primitives import SearchDeckMultiCriteria

    return sum(
        1 for cid in _attacker_player(ctx).discard
        if (c := ctx.card_db.get(cid)) is not None and SearchDeckMultiCriteria._matches(c, arg)
    )


def _c_defender_status(ctx, arg):
    active = ctx.state.player(ctx.opponent).active
    if active is None:
        return 0
    return int(active.status.poisoned) + int(active.status.burned) + int(active.status.exclusive.name != "NONE")


def _c_opp_prizes_taken(ctx, arg):
    return 6 - len(ctx.state.player(ctx.opponent).prizes)


def _c_own_prizes_taken(ctx, arg):
    return 6 - len(_attacker_player(ctx).prizes)


def _c_self_damage_counters(ctx, arg):
    return ctx.source_pokemon.damage // 10 if ctx.source_pokemon is not None else 0


def _c_defender_damage_counters(ctx, arg):
    active = ctx.state.player(ctx.opponent).active
    return active.damage // 10 if active is not None else 0


def _c_opp_active_retreat(ctx, arg):
    active = ctx.state.player(ctx.opponent).active
    card = ctx.card_db.get(active.card_id) if active is not None else None
    return card.retreat_cost_count if card is not None else 0


def _c_own_lost_zone(ctx, arg):
    return len(_attacker_player(ctx).lost_zone)


def _c_own_deck_discarded(ctx, arg):
    return 0


def _c_opp_pokemon_with_ability(ctx, arg):
    return sum(1 for m in ctx.state.player(ctx.opponent).all_pokemon_in_play() if (c := ctx.card_db.get(m.card_id)) is not None and c.abilities)


def _c_own_subtype_in_play(ctx, arg):
    return sum(1 for m in _attacker_player(ctx).all_pokemon_in_play() if (c := ctx.card_db.get(m.card_id)) is not None and arg in c.subtypes)


COUNTERS = {
    "own_subtype_in_play": _c_own_subtype_in_play,
    "opp_pokemon_with_ability": _c_opp_pokemon_with_ability,
    "self_energy": _c_self_energy,
    "opp_active_energy": _c_opp_active_energy,
    "opp_all_energy": _c_opp_all_energy,
    "both_active_energy": _c_both_active_energy,
    "own_all_energy": _c_own_all_energy,
    "own_hand": _c_own_hand,
    "opp_hand": _c_opp_hand,
    "own_in_play": _c_pokemon("own_in_play"),
    "own_bench": _c_pokemon("own_bench"),
    "opp_in_play": _c_pokemon("opp_in_play"),
    "opp_bench": _c_pokemon("opp_bench"),
    "both_bench": _c_pokemon("both_bench"),
    "both_in_play": _c_pokemon("both_in_play"),
    "own_discard": _c_own_discard,
    "own_discard_kind": _c_own_discard_kind,
    "defender_status": _c_defender_status,
    "opp_prizes_taken": _c_opp_prizes_taken,
    "own_prizes_taken": _c_own_prizes_taken,
    "self_damage_counters": _c_self_damage_counters,
    "defender_damage_counters": _c_defender_damage_counters,
    "opp_active_retreat": _c_opp_active_retreat,
    "own_lost_zone": _c_own_lost_zone,
}


def count_of(ctx: EffectContext, counter: str, arg: str = "") -> int:
    return int(COUNTERS[counter](ctx, arg))


@dataclass(frozen=True)
class DamageForEach(Effect):
    """base + per × (数える物の数) のダメージ(上限capがあれば数をcapで切る)。「N damage for each X」(base=0)/「N more damage for each X」(base=基本ダメージ)。
    plus_minus=-1なら「N less damage for each X」。"""

    base: int
    per: int
    counter: str
    arg: str = ""
    cap: int | None = None
    sign: int = 1

    def execute(self, ctx: EffectContext) -> None:
        n = count_of(ctx, self.counter, self.arg)
        if self.cap is not None:
            n = min(n, self.cap)
        DealDamage(max(0, self.base + self.sign * self.per * n)).execute(ctx)


# ---------------------------------------------------------------------------------------------
# 条件(EXTRA_CONDITIONS)
# ---------------------------------------------------------------------------------------------
def _cond_self_has_tool(ctx, arg, player, opponent, self_mon, defender) -> bool:
    return self_mon is not None and self_mon.attached_tool is not None


def _cond_opp_hand_at_most(ctx, arg, player, opponent, self_mon, defender) -> bool:
    return len(opponent.hand) <= int(arg)


def _cond_opp_prizes_at_most(ctx, arg, player, opponent, self_mon, defender) -> bool:
    return len(opponent.prizes) <= int(arg)


def _cond_own_ko_last_turn(ctx, arg, player, opponent, self_mon, defender) -> bool:
    if arg:
        return arg in player.ko_types_last_turn
    return bool(player.pokemon_ko_last_turn)


def _cond_self_poisoned(ctx, arg, player, opponent, self_mon, defender) -> bool:
    return self_mon is not None and self_mon.status.poisoned


def _cond_same_energy_count(ctx, arg, player, opponent, self_mon, defender) -> bool:
    return self_mon is not None and defender is not None and len(self_mon.attached_energy) == len(defender.attached_energy)


def _cond_defender_is_evolution(ctx, arg, player, opponent, self_mon, defender) -> bool:
    card = ctx.card_db.get(defender.card_id) if defender is not None else None
    return card is not None and card.is_pokemon and not card.is_basic


def _cond_defender_has_tool(ctx, arg, player, opponent, self_mon, defender) -> bool:
    return defender is not None and defender.attached_tool is not None


def _cond_self_evolved_this_turn(ctx, arg, player, opponent, self_mon, defender) -> bool:
    return self_mon is not None and self_mon.turn_played == player.turns_taken and bool(getattr(self_mon, "evolution_history", ()))


def register_conditions() -> None:
    _ep.EXTRA_CONDITIONS.update({
        "self_has_tool": _cond_self_has_tool,
        "opp_hand_at_most": _cond_opp_hand_at_most,
        "opp_prizes_at_most": _cond_opp_prizes_at_most,
        "own_ko_last_turn": _cond_own_ko_last_turn,
        "self_poisoned": _cond_self_poisoned,
        "same_energy_count": _cond_same_energy_count,
        "defender_is_evolution": _cond_defender_is_evolution,
        "defender_has_tool_attached": _cond_defender_has_tool,
        "self_evolved_this_turn": _cond_self_evolved_this_turn,
    })


register_conditions()


# ---------------------------------------------------------------------------------------------
# 引く(条件つきの枚数・数に応じた枚数)/ ベンチに出す検索(グッズ/サポート/特性で共通)
# ---------------------------------------------------------------------------------------------
def _draw(player, n: int) -> int:
    drawn = 0
    for _ in range(max(0, n)):
        if not player.deck:
            break
        player.hand.append(player.deck.pop(0))
        drawn += 1
    return drawn


@dataclass(frozen=True)
class ConditionalDraw(Effect):
    """条件によって引く枚数が変わる。mode: "draw"=N枚引く / "until"=手札がN枚になるまで引く / "shuffle_draw"=手札を山札に戻してN枚引く。
    cond(+arg)はeffects/era_trainer_gates.GATE_FUNCSの条件名。条件を満たしたら、instead=Falseなら追加でextra枚(until/shuffle_drawは不可)、
    instead=Trueなら基本の枚数のかわりにextra枚(untilは「手札がextra枚になるまで」)。"""

    mode: str
    base: int
    extra: int
    cond: str
    arg: str = ""
    instead: bool = True

    def execute(self, ctx: EffectContext) -> None:
        from effects.era_trainer_gates import GATE_FUNCS

        state = ctx.state
        player = _attacker_player(ctx)
        index = ctx.acting_player
        met = GATE_FUNCS[self.cond](state, player, index, ctx.card_db, self.arg)
        if self.mode == "shuffle_draw":
            player.deck.extend(player.hand)
            player.hand = []
            ctx.rng.shuffle(player.deck)
        if self.mode == "until":
            target = self.extra if (met and self.instead) else self.base
            _draw(player, target - len(player.hand))
            return
        n = self.base
        if met:
            n = self.extra if self.instead else self.base + self.extra
        _draw(player, n)


@dataclass(frozen=True)
class DrawForEach(Effect):
    """数える物(COUNTERS)1つにつき per 枚引く。"""

    per: int
    counter: str
    arg: str = ""

    def execute(self, ctx: EffectContext) -> None:
        _draw(_attacker_player(ctx), self.per * count_of(ctx, self.counter, self.arg))


@dataclass(frozen=True)
class SearchByCriterionToBench(Effect):
    """山札(zone="deck")かトラッシュ(zone="discard")から、条件(SearchDeckMultiCriteriaの条件名)に合うポケモンを最大count匹選んでベンチに出す。
    山札から出したときはシャッフルする。"""

    criterion: str
    count: int = 1
    zone: str = "deck"

    def execute(self, ctx: EffectContext) -> None:
        from effects.primitives import SearchDeckMultiCriteria, _trigger_search_choice

        player = _attacker_player(ctx)
        _trigger_search_choice(
            ctx, player, self.zone,
            lambda c: c is not None and c.is_pokemon and SearchDeckMultiCriteria._matches(c, self.criterion), self.count,
            f"{'山札' if self.zone == 'deck' else 'トラッシュ'}から{self.criterion}を最大{self.count}匹ベンチに出す",
            shuffle_after=self.zone == "deck", destination="bench",
        )
