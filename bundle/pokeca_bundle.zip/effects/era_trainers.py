"""時代ごとのカード取り込み(2026-10-06〜)で実装した、トレーナーズ(グッズ/サポート/どうぐ/スタジアム)の効果と、
どうぐ/スタジアムの常時効果を既存のテーブル・フックに登録する処理。

- 効果のスクリプト(Effectのタプル)は effects.registry.TRAINER_EFFECTS / STADIUM_ABILITY_EFFECTS に登録する(install())。
- どうぐ/スタジアムの常時効果は、このモジュールの関数(era_tool_attack_bonus等)を、ダメージ計算・最大HP・弱点・特殊状態・
  きぜつ処理・合法手生成の各フックから呼ぶ。
- 対象のカードIDは effects/generated_era_trainer_ids.py(scripts/build_era_trainer_ids.py が、effects/era_trainer_specs.py の
  条件でカードデータベースを検索して生成)から引く。
- 同名・同文面の再録は effects/card_aliases.py が代表のIDに結びつける。
"""

from __future__ import annotations

from dataclasses import dataclass, replace

from cards.card_db import card_has_subtype
from effects.context import EffectContext
from effects.generated_era_trainer_ids import IDS
from effects.primitives import (
    Draw,
    Effect,
    FlipCoinThen,
    ForceOpponentSwitchChosenBench,
    HealTarget,
    SearchDeckForPokemonToHand,
    SearchDeckMultiCriteria,
    SearchDiscardForPokemonOfTypeToBench,
    _attacker_player,
    _field_attachment_candidates,
)
from engine.state import PendingSearchChoice


def _ids(key: str) -> tuple[str, ...]:
    return tuple(card_id for card_id, _ in IDS[key])


def _pairs(key: str) -> tuple[tuple[str, str], ...]:
    return IDS[key]


def _basic_energy(card) -> bool:
    return card is not None and card.is_energy and not card.is_special_energy


# ---------------------------------------------------------------------------------------------
# グッズ・サポートの効果
# ---------------------------------------------------------------------------------------------
@dataclass(frozen=True)
class AttackBonusThisTurn(Effect):
    """この番の間、自分のポケモンのワザは相手のバトルポケモンに+flat(+相手がとったサイド1枚につきper_prize)
    ダメージ(弱点・抵抗力適用前)。プラスパワー/アイリス。"""

    flat: int = 0
    per_prize: int = 0

    def execute(self, ctx: EffectContext) -> None:
        player = _attacker_player(ctx)
        player.damage_bonus_flat_this_turn += self.flat
        player.damage_bonus_per_prize_this_turn += self.per_prize


@dataclass(frozen=True)
class LookBottomNPutNamedOnBench(Effect):
    """山札の下からn枚を見て、指定した名前のポケモンがいれば公開してベンチに出してよい。残りは山札に戻してシャッフルする
    (カバーフォッシル等の化石グッズ)。"""

    n: int
    pokemon_name: str

    def execute(self, ctx: EffectContext) -> None:
        from engine.continuous import effective_bench_limit

        player = _attacker_player(ctx)
        count = min(self.n, len(player.deck))
        start = len(player.deck) - count
        seen = player.deck[start:]
        ctx.reveal("山札の下から見たカード", list(seen))
        eligible = [start + i for i, cid in enumerate(seen) if (c := ctx.card_db.get(cid)) is not None and c.name == self.pokemon_name]
        has_space = len(player.bench) < effective_bench_limit(ctx.state, player, ctx.card_db)
        if not eligible or not has_space:
            ctx.log(f"山札の下{count}枚に{self.pokemon_name}は{'いなかった' if not eligible else 'いたがベンチに空きがない'}")
            ctx.rng.shuffle(player.deck)
            return
        ctx.state.pending_search_choice = PendingSearchChoice(
            player_index=ctx.acting_player,
            zone="deck",
            source_indices=eligible,
            card_ids=[player.deck[i] for i in eligible],
            min_count=0,
            max_count=1,
            prompt=f"山札の下{count}枚から{self.pokemon_name}をベンチに出す(出さなくてもよい)",
            shuffle_after=True,
            all_card_ids=list(seen),
            destination="bench",
            effect_source=ctx.effect_source,
            source_card_id=ctx.source_card_id,
        )


@dataclass(frozen=True)
class PutHandCardsOnBottomThenDraw(Effect):
    """手札を好きな枚数、好きな順番で山札の下に置き、置いた枚数だけ引く(カトレア)。"""

    def execute(self, ctx: EffectContext) -> None:
        player = _attacker_player(ctx)
        if not player.hand:
            return
        ctx.state.pending_search_choice = PendingSearchChoice(
            player_index=ctx.acting_player,
            zone="hand",
            source_indices=list(range(len(player.hand))),
            card_ids=list(player.hand),
            min_count=0,
            max_count=len(player.hand),
            prompt="山札の下に置く手札を選ぶ(選んだ順に下へ置き、同じ枚数を引く)",
            shuffle_after=False,
            all_card_ids=list(player.hand),
            destination="deck_bottom",
            custom_data={"mode": "gen_continue", "op": "draw_picked_count"},
            effect_source=ctx.effect_source,
        )


@dataclass(frozen=True)
class RevealTopAttachIfBasicEnergy(Effect):
    """山札の一番上を公開し、基本エネルギーなら自分のポケモン1匹につける。そうでなければ山札の上に戻す(エーテル)。"""

    def execute(self, ctx: EffectContext) -> None:
        player = _attacker_player(ctx)
        if not player.deck:
            return
        top = player.deck[0]
        card = ctx.card_db.get(top)
        ctx.reveal("山札の一番上", [top])
        if not _basic_energy(card):
            ctx.log("山札の一番上は基本エネルギーではなかったので、山札の上に戻した")
            return
        player.deck.pop(0)
        from effects.era_primitives_b import _slots

        slots = _slots(player)
        pending = PendingSearchChoice(
            player_index=ctx.acting_player,
            zone="gen_pokemon_pick",
            source_indices=[s for s, _ in slots],
            card_ids=[m.card_id for _, m in slots],
            min_count=1,
            max_count=1,
            prompt="公開した基本エネルギーをつけるポケモンを選ぶ",
            shuffle_after=False,
            all_card_ids=[m.card_id for _, m in slots],
            custom_data={"op": "attach_card_to_target", "card_id": top},
            effect_source=ctx.effect_source,
        )
        ctx.state.pending_search_choice = pending


@dataclass(frozen=True)
class MoveAnyEnergyFromLastBenchToActive(Effect):
    """直前の入れ替えで控えに下がったポケモン(ベンチの最後尾)についているエネルギーを、好きな枚数、バトルポケモンに移してよい
    (スクランブルスイッチの2段階目)。"""

    def execute(self, ctx: EffectContext) -> None:
        player = _attacker_player(ctx)
        if not player.bench or player.active is None:
            return
        old_slot = len(player.bench)  # スロット番号: ベンチi = i+1
        old = player.bench[-1]
        if not old.attached_energy:
            return
        ctx.state.pending_search_choice = PendingSearchChoice(
            player_index=ctx.acting_player,
            zone="gen_energy_pick",
            source_indices=list(range(len(old.attached_energy))),
            card_ids=list(old.attached_energy),
            min_count=0,
            max_count=len(old.attached_energy),
            prompt="新しいバトルポケモンに移すエネルギーを選ぶ(移さなくてもよい)",
            shuffle_after=False,
            all_card_ids=list(old.attached_energy),
            custom_data={"op": "move_selected_energy", "from_slot": old_slot, "to_slot": 0},
            effect_source=ctx.effect_source,
        )


@dataclass(frozen=True)
class PutDiscardPokemonOnTopOfDeck(Effect):
    """トラッシュのポケモン1匹を選んで、山札の一番上に置く(ふっかつそう Max Revive)。"""

    def execute(self, ctx: EffectContext) -> None:
        player = _attacker_player(ctx)
        idx = [i for i, cid in enumerate(player.discard) if (c := ctx.card_db.get(cid)) is not None and c.is_pokemon]
        if not idx:
            return
        ctx.state.pending_search_choice = PendingSearchChoice(
            player_index=ctx.acting_player,
            zone="discard",
            source_indices=idx,
            card_ids=[player.discard[i] for i in idx],
            min_count=1,
            max_count=1,
            prompt="山札の一番上に置くポケモンをトラッシュから選ぶ",
            shuffle_after=False,
            all_card_ids=list(player.discard),
            destination="deck_top_no_shuffle",
            effect_source=ctx.effect_source,
        )


@dataclass(frozen=True)
class DiscardHandEnergyThenDraw(Effect):
    """手札から指定タイプの基本エネルギーを1枚トラッシュして(できなければ使えない)、count枚引く(ほのおのたいまつ)。"""

    energy_type: str
    count: int

    def execute(self, ctx: EffectContext) -> None:
        player = _attacker_player(ctx)
        idx = [i for i, cid in enumerate(player.hand) if (c := ctx.card_db.get(cid)) is not None and _basic_energy(c) and c.basic_energy_type == self.energy_type]
        if not idx:
            return
        ctx.state.pending_search_choice = PendingSearchChoice(
            player_index=ctx.acting_player,
            zone="hand",
            source_indices=idx,
            card_ids=[player.hand[i] for i in idx],
            min_count=1,
            max_count=1,
            prompt=f"トラッシュする{self.energy_type}エネルギーを手札から選ぶ",
            shuffle_after=False,
            all_card_ids=list(player.hand),
            destination="discard",
            custom_data={"mode": "gen_continue", "op": "draw_n", "n": self.count},
            effect_source=ctx.effect_source,
        )


@dataclass(frozen=True)
class TrickShovelEffect(Effect):
    """どちらかのプレイヤーの山札の一番上を見て、トラッシュしてもよい(トリックショベル)。見るデッキをまず選ぶ。"""

    def execute(self, ctx: EffectContext) -> None:
        owners = [ctx.acting_player, ctx.opponent]
        candidates = [(o, ctx.state.player(o)) for o in owners if ctx.state.player(o).deck]
        if not candidates:
            return
        pending = PendingSearchChoice(
            player_index=ctx.acting_player,
            zone="gen_deck_pick",
            source_indices=[o for o, _ in candidates],
            card_ids=[p.deck[0] for _, p in candidates],
            min_count=1,
            max_count=1,
            prompt="一番上を見る山札を選ぶ(自分の山札/相手の山札)",
            shuffle_after=False,
            all_card_ids=[p.deck[0] for _, p in candidates],
            custom_data={"op": "trick_shovel_pick_deck"},
            effect_source=ctx.effect_source,
        )
        if len(candidates) == 1:
            pending.custom_data["only_owner"] = candidates[0][0]
        ctx.state.pending_search_choice = pending


@dataclass(frozen=True)
class FlipUntilTailsDrawPerHeads(Effect):
    """ウラが出るまでコインを投げ、オモテ1回につき1枚引く(ジムバッジ)。"""

    def execute(self, ctx: EffectContext) -> None:
        heads = 0
        while ctx.rng.random() < 0.5 and heads < 50:
            heads += 1
        ctx.log(f"コインをウラが出るまで投げた: オモテ{heads}回")
        if heads > 0:
            Draw(heads).execute(ctx)


@dataclass(frozen=True)
class ShuffleTwoHandCardsThenDraw(Effect):
    """手札を2枚山札に戻してシャッフルし(戻せなければ使えない)、1枚引く(メンテナンス)。"""

    def execute(self, ctx: EffectContext) -> None:
        player = _attacker_player(ctx)
        if len(player.hand) < 2:
            return
        ctx.state.pending_search_choice = PendingSearchChoice(
            player_index=ctx.acting_player,
            zone="hand",
            source_indices=list(range(len(player.hand))),
            card_ids=list(player.hand),
            min_count=2,
            max_count=2,
            prompt="山札に戻す手札を2枚選ぶ",
            shuffle_after=True,
            all_card_ids=list(player.hand),
            destination="deck",
            custom_data={"mode": "gen_continue", "op": "draw_n", "n": 1},
            effect_source=ctx.effect_source,
        )


@dataclass(frozen=True)
class ReturnChosenOwnToolsToHand(Effect):
    """自分のポケモンについているどうぐを、2枚まで選んで手札に戻す(ツールリトリーバー)。"""

    count: int = 2

    def execute(self, ctx: EffectContext) -> None:
        source_indices, card_ids = _field_attachment_candidates(ctx.state, ctx.card_db, (ctx.acting_player,), include_tool=True)
        if not source_indices:
            return
        ctx.state.pending_search_choice = PendingSearchChoice(
            player_index=ctx.acting_player,
            zone="field_attachment",
            source_indices=source_indices,
            card_ids=card_ids,
            min_count=0,
            max_count=min(self.count, len(card_ids)),
            prompt=f"手札に戻すどうぐを{self.count}枚まで選ぶ",
            shuffle_after=False,
            all_card_ids=list(card_ids),
            destination="hand",
            effect_source=ctx.effect_source,
        )


@dataclass(frozen=True)
class RandomOpponentHandCardsToDeck(Effect):
    """相手の手札からランダムにcount枚選び、公開させて山札に戻してシャッフルする(ジムトレーナーのジムとカス)。"""

    count: int

    def execute(self, ctx: EffectContext) -> None:
        opponent = ctx.state.player(ctx.opponent)
        n = min(self.count, len(opponent.hand))
        if n <= 0:
            return
        picked = []
        for _ in range(n):
            picked.append(opponent.hand.pop(ctx.rng.randrange(len(opponent.hand))))
        ctx.reveal("相手の手札から選んだカード", list(picked))
        opponent.deck.extend(picked)
        ctx.rng.shuffle(opponent.deck)
        ctx.log(f"相手の手札からランダムに{n}枚を山札に戻した")
        ctx.state.player(ctx.acting_player).known_opponent_hand = []


@dataclass(frozen=True)
class EachPlayerHandTo(Effect):
    """おたがいに、手札が指定の枚数になるまで引くか手札をトラッシュする(相手が先)(ヒュウ)。
    手札が多い側は、残すカードを自分で選んでトラッシュする。"""

    count: int
    _continuation: bool = False

    def execute(self, ctx: EffectContext) -> None:
        if self._continuation:
            # 相手の選択の続き: 選択待ちの続き(remaining_script)は元の効果を使った側(ctx.acting_player)として実行される
            self._do_side(ctx, ctx.acting_player, [])
            return
        opponent = ctx.state.player(ctx.opponent)
        rest = (EachPlayerHandTo(self.count, True),)
        self._do_side(ctx, ctx.opponent, rest)
        if ctx.state.pending_search_choice is None:
            self._do_side(ctx, ctx.acting_player, [])

    def _do_side(self, ctx: EffectContext, side: int, rest) -> None:
        player = ctx.state.player(side)
        if len(player.hand) < self.count:
            for _ in range(self.count - len(player.hand)):
                if not player.deck:
                    break
                player.hand.append(player.deck.pop(0))
            ctx.log(f"player{side} は手札が{self.count}枚になるまで引いた")
            return
        extra = len(player.hand) - self.count
        if extra <= 0:
            return
        ctx.state.pending_search_choice = PendingSearchChoice(
            player_index=side,
            zone="hand",
            source_indices=list(range(len(player.hand))),
            card_ids=list(player.hand),
            min_count=extra,
            max_count=extra,
            prompt=f"手札が{self.count}枚になるまでトラッシュする",
            shuffle_after=False,
            all_card_ids=list(player.hand),
            destination="discard",
            remaining_script=tuple(rest),
            effect_source=ctx.effect_source,
        )


@dataclass(frozen=True)
class DiscardTeamPlasmaCardFromHandThenDraw(Effect):
    """手札からチームプラズマのカードを1枚トラッシュして(できなければ使えない)、count枚引く(プラズマ団のしたっぱ)。"""

    count: int

    def execute(self, ctx: EffectContext) -> None:
        player = _attacker_player(ctx)
        idx = [i for i, cid in enumerate(player.hand) if is_team_plasma_card(ctx.card_db.get(cid))]
        if not idx:
            return
        ctx.state.pending_search_choice = PendingSearchChoice(
            player_index=ctx.acting_player,
            zone="hand",
            source_indices=idx,
            card_ids=[player.hand[i] for i in idx],
            min_count=1,
            max_count=1,
            prompt="トラッシュするチームプラズマのカードを手札から選ぶ",
            shuffle_after=False,
            all_card_ids=list(player.hand),
            destination="discard",
            custom_data={"mode": "gen_continue", "op": "draw_n", "n": self.count},
            effect_source=ctx.effect_source,
        )


@dataclass(frozen=True)
class OpponentRevealHandShuffleItemsAndDraw(Effect):
    """相手の手札を公開させ、その中のグッズを全て山札に戻してシャッフルする。そのあと、戻した枚数だけ引く(ゲーチス)。"""

    def execute(self, ctx: EffectContext) -> None:
        opponent = ctx.state.player(ctx.opponent)
        player = _attacker_player(ctx)
        player.known_opponent_hand = list(opponent.hand)
        ctx.reveal("相手の手札", list(opponent.hand))
        kept, items = [], []
        for cid in opponent.hand:
            card = ctx.card_db.get(cid)
            (items if card is not None and card.is_item else kept).append(cid)
        opponent.hand = kept
        opponent.deck.extend(items)
        if items:
            ctx.rng.shuffle(opponent.deck)
        ctx.log(f"相手の手札のグッズ{len(items)}枚を山札に戻した")
        if items:
            Draw(len(items)).execute(ctx)


@dataclass(frozen=True)
class DiscardEnergyFromOpponentActive(Effect):
    """相手のバトルポケモンについているエネルギーを1枚トラッシュする(攻撃側が選ぶ)(フレア団のしたっぱ)。"""

    def execute(self, ctx: EffectContext) -> None:
        from effects.primitives import _defender_blocks_effect

        opponent = ctx.state.player(ctx.opponent)
        mon = opponent.active
        if mon is None or not mon.attached_energy:
            return
        if len(set(mon.attached_energy)) == 1:
            opponent.discard.append(mon.attached_energy.pop())
            ctx.log("相手のバトルポケモンのエネルギーを1枚トラッシュした")
            return
        entries = list(range(len(mon.attached_energy)))
        ctx.state.pending_search_choice = PendingSearchChoice(
            player_index=ctx.acting_player,
            zone="gen_energy_pick",
            source_indices=entries,
            card_ids=list(mon.attached_energy),
            min_count=1,
            max_count=1,
            prompt="相手のバトルポケモンからトラッシュするエネルギーを選ぶ",
            shuffle_after=False,
            all_card_ids=list(mon.attached_energy),
            custom_data={"op": "discard_opp_active_energy"},
            effect_source=ctx.effect_source,
        )
        _ = _defender_blocks_effect


@dataclass(frozen=True)
class AttachFireEnergyFromDiscardToFirePokemon(Effect):
    """トラッシュからほのおエネルギーを2枚、自分のほのおポケモン1匹につける(カヒリ→ブラックスミス)。"""

    count: int = 2

    def execute(self, ctx: EffectContext) -> None:
        from effects.era_primitives_b import AttachEnergyGeneric

        AttachEnergyGeneric(
            source="discard", count=self.count, basic_only=True, energy_type="Fire", target_type="Fire", single_target=True
        ).execute(ctx)


@dataclass(frozen=True)
class DrawUntilHandMatchesOpponent(Effect):
    """相手の手札と同じ枚数になるまで引く(バトルレポーター)。"""

    def execute(self, ctx: EffectContext) -> None:
        player = _attacker_player(ctx)
        target = len(ctx.state.player(ctx.opponent).hand)
        while len(player.hand) < target and player.deck:
            player.hand.append(player.deck.pop(0))


@dataclass(frozen=True)
class SearchDeckForFossilPokemonToBench(Effect):
    """山札から、アマルスとチゴラスのいずれかの組み合わせで最大2匹までベンチに出す(化石研究者)。"""

    names: tuple = ("Amaura", "Tyrunt")
    count: int = 2

    def execute(self, ctx: EffectContext) -> None:
        from effects.primitives import _trigger_search_choice

        player = _attacker_player(ctx)
        _trigger_search_choice(
            ctx, player, "deck", lambda c: c is not None and c.name in self.names, self.count,
            "山札からアマルス/チゴラスをベンチに出す", destination="bench",
        )


@dataclass(frozen=True)
class EachPlayerShufflesDiscardPokemonIntoDeck(Effect):
    """おたがいに、トラッシュのポケモンを全て山札に戻してシャッフルする(カレン)。"""

    def execute(self, ctx: EffectContext) -> None:
        for side in (ctx.acting_player, ctx.opponent):
            player = ctx.state.player(side)
            pokemon = [cid for cid in player.discard if (c := ctx.card_db.get(cid)) is not None and c.is_pokemon]
            if not pokemon:
                continue
            player.discard = [cid for cid in player.discard if not ((c := ctx.card_db.get(cid)) is not None and c.is_pokemon)]
            player.deck.extend(pokemon)
            ctx.rng.shuffle(player.deck)
            ctx.log(f"player{side} がトラッシュのポケモン{len(pokemon)}枚を山札に戻した")


# ---------------------------------------------------------------------------------------------
# チームプラズマ判定(どうぐ「チームプラズマバッジ」でチームプラズマのポケモンとして扱う)
# ---------------------------------------------------------------------------------------------
def is_team_plasma_card(card) -> bool:
    """「チームプラズマのカード」(サブタイプにTeam Plasmaを持つポケモン・トレーナーズ・エネルギー)。"""
    return card is not None and "Team Plasma" in card.subtypes


def is_team_plasma_mon(card_db, mon) -> bool:
    """チームプラズマのポケモンか(どうぐ「チームプラズマバッジ」がついていれば、そのポケモンもチームプラズマのポケモンとして扱う)。"""
    card = card_db.get(mon.card_id)
    if card is None:
        return False
    return "Team Plasma" in card.subtypes or mon.attached_tool in TEAM_PLASMA_BADGE_IDS


@dataclass(frozen=True)
class PlayRestoredPokemonFromHandToBench(Effect):
    """手札の復元ポケモン(化石から復元するポケモン)を1匹、ベンチに出してよい(ツイストマウンテン)。"""

    def execute(self, ctx: EffectContext) -> None:
        from engine.continuous import effective_bench_limit

        player = _attacker_player(ctx)
        if len(player.bench) >= effective_bench_limit(ctx.state, player, ctx.card_db):
            return
        idx = [i for i, cid in enumerate(player.hand) if (c := ctx.card_db.get(cid)) is not None and "Restored" in c.subtypes]
        if not idx:
            return
        ctx.state.pending_search_choice = PendingSearchChoice(
            player_index=ctx.acting_player,
            zone="hand",
            source_indices=idx,
            card_ids=[player.hand[i] for i in idx],
            min_count=0,
            max_count=1,
            prompt="ベンチに出す復元ポケモンを手札から選ぶ(出さなくてもよい)",
            shuffle_after=False,
            all_card_ids=list(player.hand),
            destination="bench",
            effect_source=ctx.effect_source,
        )


# ---------------------------------------------------------------------------------------------
# どうぐ・スタジアムの対象ID
# ---------------------------------------------------------------------------------------------
FIRST_TICKET_IDS = frozenset(_ids("first_ticket"))
TEAM_PLASMA_BADGE_IDS = frozenset(_ids("team_plasma_badge"))
DARK_CLAW_IDS = frozenset(_ids("dark_claw"))
CRYSTAL_EDGE_IDS = frozenset(_ids("crystal_edge"))
CRYSTAL_WALL_IDS = frozenset(_ids("crystal_wall"))
VICTORY_PIECE_IDS = frozenset(_ids("victory_piece"))
EVIOLITE_IDS = frozenset(_ids("eviolite"))
GIANT_CAPE_IDS = frozenset(_ids("giant_cape"))
RESCUE_SCARF_IDS = frozenset(_ids("rescue_scarf"))
EXP_SHARE_IDS = frozenset(_ids("exp_share"))
REVERSAL_TRIGGER_IDS = frozenset(_ids("reversal_trigger"))
SILVER_MIRROR_IDS = frozenset(_ids("silver_mirror"))
LIFE_DEW_IDS = frozenset(_ids("life_dew"))
PROTECTION_CUBE_IDS = frozenset(_ids("protection_cube"))
SPARKLING_ROBE_IDS = frozenset(_ids("sparkling_robe"))
ASPERTIA_CITY_GYM_IDS = frozenset(_ids("aspertia_city_gym"))
TRAINING_CENTER_IDS = frozenset(_ids("training_center"))
PLASMA_FRIGATE_IDS = frozenset(_ids("plasma_frigate"))
SHADOW_CIRCLE_IDS = frozenset(_ids("shadow_circle"))
MAGNETIC_STORM_IDS = frozenset(_ids("magnetic_storm"))
FROZEN_CITY_IDS = frozenset(_ids("frozen_city"))
MOUNTAIN_RING_IDS = frozenset(_ids("mountain_ring"))
POKEMON_CENTER_IDS = frozenset(_ids("pokemon_center"))
TWIST_MOUNTAIN_IDS = frozenset(_ids("twist_mountain"))
BATTLE_CITY_IDS = frozenset(_ids("battle_city"))
CHAMPIONS_FESTIVAL_IDS = frozenset(_ids("champions_festival"))
TROPICAL_BEACH_IDS = frozenset(_ids("tropical_beach"))


def _tools_active(state) -> bool:
    from engine.continuous import tools_disabled

    return not tools_disabled(state.stadium_in_play)


# ---------------------------------------------------------------------------------------------
# ダメージ・最大HP・弱点・特殊状態・きぜつ時のフック(各エンジンの関数から呼ばれる)
# ---------------------------------------------------------------------------------------------
def era_tool_attack_bonus(ctx: EffectContext, tool_id: str | None, attacker_card, defender_card) -> int:
    """攻撃側のどうぐによる、相手のバトルポケモンへの追加ダメージ(あくのツメ/クリスタルエッジ)。"""
    if tool_id is None or not _tools_active(ctx.state):
        return 0
    if tool_id in DARK_CLAW_IDS and "Darkness" in attacker_card.types:
        return 20
    if tool_id in CRYSTAL_EDGE_IDS and attacker_card.name == "White Kyurem-EX":
        return 50
    from effects.era_energy_g import LIGHT_BALL_IDS

    if tool_id in LIGHT_BALL_IDS and attacker_card.name.startswith("Pikachu ex") and defender_card is not None and "ex" in defender_card.subtypes:
        return 50  # ライトボール: ついているピカチュウexのワザは、相手のバトルポケモンexに+50
    from effects.era_sm_hooks import tool_attack_bonus

    return tool_attack_bonus(ctx, tool_id, attacker_card)  # ハッスルベルト/ビーストライト


def era_defender_tool_reduction(state, tool_id: str | None, defender_card, attacker_mon=None, card_db=None) -> int:
    """防御側のどうぐによるダメージ軽減(進化のきせき Eviolite: たねポケモンは-20 / アサルトベスト: 特殊エネルギーのついたポケモンからのダメージ-40)。"""
    if tool_id is None or not _tools_active(state):
        return 0
    if tool_id in EVIOLITE_IDS and "Basic" in defender_card.subtypes:
        return 20
    if (
        tool_id in ASSAULT_VEST_IDS
        and attacker_mon is not None
        and card_db is not None
        and any((c := card_db.get(e)) is not None and c.is_special_energy for e in attacker_mon.attached_energy)
    ):
        return 40
    from effects.era_sm_hooks import tool_reduction

    return tool_reduction(tool_id, defender_card)  # メタルフライパン/メタルコアバリア/エンシェントクリスタル


def era_hp_adjust(card, tool_id: str | None, stadium_id: str | None, base: int) -> int:
    """どうぐ・スタジアムによる最大HPの増減(ジャイアントマント/クリスタルウォール/アスペルチアシティジム/トレーニングセンター)。"""
    from engine.continuous import tools_disabled

    if card is None:
        return base
    if not tools_disabled(stadium_id):
        if tool_id in GIANT_CAPE_IDS:
            base += 20
        elif tool_id in CRYSTAL_WALL_IDS and card.name == "Black Kyurem-EX":
            base = 300
        elif tool_id in HEAVY_BOOTS_IDS and card.retreat_cost_count >= 3:
            base += 20  # ヘビーブーツ: にげるコストが3以上のポケモンは+20HP
        from effects.era_sm_hooks import hp_adjust

        base = hp_adjust(card, tool_id, base)  # ボディビルダンベル/アイランドチャレンジアミュレット/バフパッド
    from effects.era_trainers_g import ANGE_FLOETTE_IDS

    if stadium_id in ANGE_FLOETTE_IDS and card.name == "Mega Floette ex":
        base += 150  # Ange Floette: おたがいのメガフライージェex(Mega Floette ex)は+150HP
    if stadium_id in ASPERTIA_CITY_GYM_IDS and "Colorless" in card.types:
        base += 20
    elif stadium_id in TRAINING_CENTER_IDS and ("Stage 1" in card.subtypes or "Stage 2" in card.subtypes):
        base += 30
    return base


def era_field_weakness(state, card_db, defender, defender_card):
    """場にいるだけで発動するスタジアムによる、弱点・抵抗力の上書き(プラズマフリゲート/シャドーサークル/マグネットストーム)。"""
    from dataclasses import replace

    if defender.attached_tool in WEAKNESS_POLICY_IDS and defender_card.weaknesses and _tools_active(state):
        defender_card = replace(defender_card, weaknesses=())  # ウィークネスポリシー: 弱点を持たない
    from effects.era_sm_hooks import METAL_FRYING_PAN_IDS, stadium_field_weakness

    if defender.attached_tool in METAL_FRYING_PAN_IDS and "Metal" in defender_card.types and defender_card.weaknesses and _tools_active(state):
        defender_card = replace(defender_card, weaknesses=())  # メタルフライパン: 鋼ポケモンは弱点を持たない
    defender_card = stadium_field_weakness(state, defender_card)  # 太陽の祭壇(Altar of the Sunne)
    stadium = state.stadium_in_play
    if stadium is None:
        return defender_card
    if stadium in MAGNETIC_STORM_IDS and defender_card.resistances:
        defender_card = replace(defender_card, resistances=())
    if stadium in PLASMA_FRIGATE_IDS and any(
        (e := card_db.get(eid)) is not None and e.name == "Plasma Energy" for eid in defender.attached_energy
    ):
        defender_card = replace(defender_card, weaknesses=())
    if stadium in SHADOW_CIRCLE_IDS and any(
        (e := card_db.get(eid)) is not None and e.name == "Darkness Energy" for eid in defender.attached_energy
    ):
        defender_card = replace(defender_card, weaknesses=())
    return defender_card


def era_bench_damage_prevented(state) -> bool:
    """マウンテンリング: ベンチのポケモンは、おたがいにワザのダメージを受けない。"""
    from effects.era_sm_hooks import bench_effects_prevented

    return state.stadium_in_play in MOUNTAIN_RING_IDS or bench_effects_prevented(state)  # マウンテンリング/スカイピラー


def era_on_energy_attached_from_hand(state, card_db, actor: int, target) -> None:
    """フローズンシティ: 手札からエネルギーをつけたポケモン(チームプラズマのポケモンを除く)に、ダメカンを2個のせる。
    (ハーブエネルギー: 手札からくさポケモンにつけたとき、そのポケモンのダメージを30回復する。)"""
    from effects.era_tools_j import on_energy_attached_from_hand, on_special_energy_attached_from_hand

    on_energy_attached_from_hand(state, card_db, actor, target)  # ふるびた墓地/ふぶきの山
    on_special_energy_attached_from_hand(state, card_db, actor, target)  # メディカル/スピード/オーロラエネルギー
    if target.attached_tool in HEALING_SCARF_IDS and _tools_active(state):
        target.heal(20)  # ヒーリングスカーフ: 手札からエネルギーをつけるたび、ダメージを20回復
    if target.attached_energy and target.attached_energy[-1] in HERBAL_ENERGY_IDS:
        card = card_db.get(target.card_id)
        if card is not None and "Grass" in card.types:
            target.heal(30)
    if state.stadium_in_play not in FROZEN_CITY_IDS or is_team_plasma_mon(card_db, target):
        return
    from effects.primitives import _blocks_damage_counters

    if _blocks_damage_counters(target):
        return
    target.damage += 20
    state.add_log("フローズンシティの効果で、エネルギーをつけたポケモンにダメカンを2個のせた")


def era_on_tool_attached(state, card_db, actor: int, mon) -> None:
    """どうぐをつけたとき(スパークリングローブ: ついたポケモンの特殊状態を全て回復する)。"""
    if mon.attached_tool in SPARKLING_ROBE_IDS and _tools_active(state):
        mon.status.clear_all()


def era_status_blocked(state, mon, card_db=None) -> bool:
    """スパークリングローブ: ついているポケモンは、特殊状態にならない。/ スチールシェルター: はがねポケモンは特殊状態にならない。"""
    if mon.attached_tool in SPARKLING_ROBE_IDS and _tools_active(state):
        return True
    if state.stadium_in_play in STEEL_SHELTER_IDS and card_db is not None:
        card = card_db.get(mon.card_id)
        return card is not None and "Metal" in card.types
    return False


def era_silver_mirror_blocks(ctx: EffectContext, defender) -> bool:
    """シルバーミラー: ついているポケモン(EXを除く)は、相手のチームプラズマのポケモンのワザの効果(ダメージを含む)を受けない。"""
    if defender.attached_tool not in SILVER_MIRROR_IDS or ctx.source_pokemon is None or not _tools_active(ctx.state):
        return False
    defender_card = ctx.card_db.get(defender.card_id)
    if defender_card is None or "EX" in defender_card.subtypes:
        return False
    return is_team_plasma_mon(ctx.card_db, ctx.source_pokemon)


def era_attack_cost_ignored(state, card_db, mon) -> bool:
    """ビクティニEXのワザは、エネルギーの数・種類に関わらず使える(ビクトリーピース)。"""
    if mon is None or mon.attached_tool not in VICTORY_PIECE_IDS or not _tools_active(state):
        return False
    card = card_db.get(mon.card_id)
    return card is not None and card.name == "Victini-EX"


def era_prize_denial(state, mon, tool: str | None = None, card_db=None, by_attack: bool = False, was_active: bool = False) -> int:
    """ライフデュー: ついているポケモンがきぜつしたとき、相手がとるサイドが1枚少ない。toolはきぜつ時点のどうぐ。
    (アイランドチャレンジアミュレット/ブラックマーケット◇はワザのダメージできぜつしたときだけ=by_attack。)"""
    tool = tool if tool is not None else mon.attached_tool
    if tool in LIFE_DEW_IDS and _tools_active(state):
        return 1
    from effects.era_sm_hooks import prize_denial

    star_order = 0
    if by_attack and was_active and card_db is not None:
        from effects.era_tools_j import star_order_extra

        star_order = star_order_extra(state, card_db, mon)  # スカイシールストーンの「スターオーダー」
    if tool in (None, "") and state.stadium_in_play is None:
        return -star_order
    denial = prize_denial(state, mon, card_db, tool if _tools_active(state) else None, by_attack) - star_order
    if tool and card_db is not None and _tools_active(state):
        from effects.era_tools_j import ko_prize_delta

        denial -= ko_prize_delta(state, card_db, mon, tool, by_attack)  # ラグジュアリーマント(+1枚)/ヒーローのメダル・リボンバッジ(-1枚)
    return denial


def era_self_damage_prevented(state, mon) -> bool:
    """プロテクションキューブ: ついているポケモンが自分のワザで自分自身に受けるダメージを全て防ぐ。"""
    return mon is not None and mon.attached_tool in PROTECTION_CUBE_IDS and _tools_active(state)


def on_mon_ko_by_attack(state, card_db, mon) -> None:
    """ワザのダメージできぜつしたポケモンについている、きぜつ時のどうぐの効果(レスキュースカーフ: 手札に戻る)。"""
    if mon.attached_tool in RESCUE_SCARF_IDS and _tools_active(state):
        mon.rescued_to_hand_pending = True
    if mon.attached_tool in ENERGY_POUCH_IDS and _tools_active(state):
        mon.energy_to_hand_pending = True  # エナジーポーチ: ついていた基本エネルギーを手札に加える


# ---------------------------------------------------------------------------------------------
# きぜつ時に発動する効果(エキスパートシェア/リバーサルトリガー)を、きぜつ処理の後に選ばせる
# ---------------------------------------------------------------------------------------------
def collect_ko_followups(state, card_db, owner_index: int, pokemon, was_active: bool) -> None:
    """きぜつしたポケモン(トラッシュする前)について、きぜつ時に発動するどうぐの効果を state.ko_followups に積む。"""
    by_attack = pokemon.hit_by_calculated_attack_damage and owner_index != state.current_player
    from effects.era_special import collect_ko_ability_followups

    collect_ko_ability_followups(state, card_db, owner_index, pokemon, by_attack, was_active)  # Final Wish等(特性なのでどうぐ無効の影響を受けない)
    if by_attack:
        from effects.era_tools_j import collect_ko_followups_energy

        collect_ko_followups_energy(state, card_db, owner_index, pokemon, was_active)  # ギフトエネルギー(どうぐ無効の影響は受けない)
    if not _tools_active(state):
        return
    tool = pokemon.attached_tool
    from effects.era_sm_hooks import collect_ko_followups_sm

    collect_ko_followups_sm(state, card_db, owner_index, pokemon, was_active, by_attack)  # ねがいのバトン/スペルタグ
    if was_active and by_attack:
        basic_energy = [e for e in pokemon.attached_energy if _basic_energy(card_db.get(e))]
        if basic_energy:
            state.ko_followups.append({"kind": "exp_share", "owner": owner_index, "energy_ids": basic_energy})
    if tool in REVERSAL_TRIGGER_IDS and by_attack and is_team_plasma_mon(card_db, pokemon):
        state.ko_followups.append({"kind": "search_deck_any", "owner": owner_index})


def start_ko_followup(state, card_db, entry: dict, cont: dict) -> bool:
    """積まれたきぜつ時の効果を1つ始める。選択待ちを立てたらTrue。cont(きぜつ後の続き)は選択待ちに持たせる。"""
    owner_index = entry["owner"]
    owner = state.player(owner_index)
    if entry["kind"] == "j_baton":
        from effects.era_tools_j import start_baton

        return start_baton(state, card_db, entry, cont)
    if entry["kind"] == "search_deck_any":
        if not owner.deck:
            return False
        state.pending_search_choice = PendingSearchChoice(
            player_index=owner_index,
            zone="deck",
            source_indices=list(range(len(owner.deck))),
            card_ids=list(owner.deck),
            min_count=0,
            max_count=entry.get("count", 1),
            prompt=f"{entry.get('label', 'リバーサルトリガー')}: 山札から好きなカードを{'最大' if entry.get('count', 1) > 1 else ''}{entry.get('count', 1)}枚手札に加える",
            shuffle_after=True,
            all_card_ids=list(owner.deck),
            destination="hand",
            custom_data={"ko_cont": cont},
        )
        return True
    if entry["kind"] == "spell_tag":
        from effects.era_trainers_i import start_spell_tag_counters

        return start_spell_tag_counters(state, card_db, entry, cont)
    if entry["kind"] == "energy_move_bench":
        holders = list(owner.bench)
        discard_indices = _recent_discard_indices(owner, entry["energy_ids"])
        if not holders or not discard_indices:
            return False
        label = entry.get("label", "")
        if len(holders) == 1:
            _start_exp_share_energy_pick(state, owner_index, holders[0], discard_indices, cont, max_count=entry["max"], label=label)
            return True
        from effects.era_primitives_b import _slot_of

        state.pending_search_choice = PendingSearchChoice(
            player_index=owner_index,
            zone="gen_pokemon_pick",
            source_indices=[_slot_of(owner, m) for m in holders],
            card_ids=[m.card_id for m in holders],
            min_count=1,
            max_count=1,
            prompt=f"{label}: エネルギーを受け取るベンチのポケモンを選ぶ",
            shuffle_after=False,
            all_card_ids=[m.card_id for m in holders],
            custom_data={"op": "exp_share_holder", "energy_ids": entry["energy_ids"], "ko_cont": cont, "max": entry["max"], "label": label},
        )
        return True
    if entry["kind"] == "exp_share":
        holders = [m for m in owner.all_pokemon_in_play() if m.attached_tool in EXP_SHARE_IDS]
        discard_indices = _recent_discard_indices(owner, entry["energy_ids"])
        if not holders or not discard_indices:
            return False
        if len(holders) == 1:
            _start_exp_share_energy_pick(state, owner_index, holders[0], discard_indices, cont)
            return True
        from effects.era_primitives_b import _slot_of

        state.pending_search_choice = PendingSearchChoice(
            player_index=owner_index,
            zone="gen_pokemon_pick",
            source_indices=[_slot_of(owner, m) for m in holders],
            card_ids=[m.card_id for m in holders],
            min_count=1,
            max_count=1,
            prompt="エキスパートシェア: エネルギーを受け取るポケモンを選ぶ",
            shuffle_after=False,
            all_card_ids=[m.card_id for m in holders],
            custom_data={"op": "exp_share_holder", "energy_ids": entry["energy_ids"], "ko_cont": cont},
        )
        return True
    return False


def _recent_discard_indices(owner, energy_ids) -> list[int]:
    """トラッシュの後ろから、energy_ids(重複あり)に当たるカードの位置を探す(きぜつしたポケモンについていたエネルギー)。"""
    remaining = list(energy_ids)
    out = []
    for i in range(len(owner.discard) - 1, -1, -1):
        if owner.discard[i] in remaining:
            remaining.remove(owner.discard[i])
            out.append(i)
    return sorted(out)


def _start_exp_share_energy_pick(
    state, owner_index: int, holder, discard_indices: list[int], cont: dict, max_count: int = 1, label: str = ""
) -> None:
    owner = state.player(owner_index)
    state.pending_search_choice = PendingSearchChoice(
        player_index=owner_index,
        zone="discard",
        source_indices=discard_indices,
        card_ids=[owner.discard[i] for i in discard_indices],
        min_count=0,
        max_count=min(max_count, len(discard_indices)),
        prompt=(
            "エキスパートシェア: きぜつしたポケモンについていた基本エネルギーを1枚、どうぐをつけたポケモンに移す(移さなくてもよい)"
            if not label else f"{label}: きぜつしたポケモンについていたエネルギーを最大{max_count}枚、ベンチのポケモンに移す(移さなくてもよい)"
        ),
        shuffle_after=False,
        all_card_ids=list(owner.discard),
        destination="attach_energy",
        attach_target_pokemon=holder,
        custom_data={"ko_cont": cont},
    )


# ---------------------------------------------------------------------------------------------
# 汎用の選択の続き(effects/era_primitives_b.py の GENERIC_OP_HANDLERS / GENERIC_CONTINUE_HANDLERS)
# ---------------------------------------------------------------------------------------------
def _op_move_selected_energy(state, card_db, choice, selected, action, ctx, custom) -> bool:
    from effects.era_primitives_b import _mon_at

    player = state.player(choice.player_index)
    src = _mon_at(player, custom["from_slot"])
    dst = _mon_at(player, custom["to_slot"])
    if src is None or dst is None or not selected:
        return False
    positions = sorted((choice.source_indices[pos] for pos in selected), reverse=True)
    moved = 0
    for ei in positions:
        if 0 <= ei < len(src.attached_energy):
            dst.attached_energy.append(src.attached_energy.pop(ei))
            moved += 1
    if moved:
        state.add_log(f"エネルギーを{moved}枚、{src.card_id}から{dst.card_id}へ移した")
    return False


def _op_discard_opp_active_energy(state, card_db, choice, selected, action, ctx, custom) -> bool:
    opponent = state.player(state.opponent_index(choice.player_index))
    mon = opponent.active
    if mon is None or not selected:
        return False
    ei = choice.source_indices[selected[0]]
    if 0 <= ei < len(mon.attached_energy):
        opponent.discard.append(mon.attached_energy.pop(ei))
        state.add_log("相手のバトルポケモンのエネルギーを1枚トラッシュした")
    return False


def _op_trick_shovel_pick_deck(state, card_db, choice, selected, action, ctx, custom) -> bool:
    if not selected:
        return False
    owner_index = choice.source_indices[selected[0]]
    owner = state.player(owner_index)
    if not owner.deck:
        return False
    ctx.reveal("山札の一番上", [owner.deck[0]])
    state.pending_search_choice = PendingSearchChoice(
        player_index=choice.player_index,
        zone="gen_deck_pick",
        source_indices=[owner_index],
        card_ids=[owner.deck[0]],
        min_count=0,
        max_count=1,
        prompt="このカードをトラッシュしてもよい(選ばなければ山札の一番上に戻す)",
        shuffle_after=False,
        all_card_ids=[owner.deck[0]],
        custom_data={"op": "trick_shovel_discard"},
    )
    return False


def _op_trick_shovel_discard(state, card_db, choice, selected, action, ctx, custom) -> bool:
    if not selected:
        return False
    owner = state.player(choice.source_indices[selected[0]])
    if owner.deck:
        owner.discard.append(owner.deck.pop(0))
        state.add_log("山札の一番上のカードをトラッシュした")
    return False


def _op_exp_share_holder(state, card_db, choice, selected, action, ctx, custom) -> bool:
    from effects.era_primitives_b import _mon_at

    owner = state.player(choice.player_index)
    holder = _mon_at(owner, choice.source_indices[selected[0]]) if selected else None
    indices = _recent_discard_indices(owner, custom["energy_ids"])
    if holder is None or not indices:
        return False
    _start_exp_share_energy_pick(
        state, choice.player_index, holder, indices, custom["ko_cont"], max_count=custom.get("max", 1), label=custom.get("label", "")
    )
    return False


def _continue_draw_picked_count(ctx, choice, custom, picked_card_ids) -> None:
    if picked_card_ids:
        Draw(len(picked_card_ids)).execute(ctx)


def _continue_draw_n(ctx, choice, custom, picked_card_ids) -> None:
    if picked_card_ids:
        Draw(custom.get("n", 1)).execute(ctx)


# ---------------------------------------------------------------------------------------------
# 合法手のゲート(使っても何も起きない/場がおかしくなるものを、選択肢から外す)
# ---------------------------------------------------------------------------------------------
def trainer_playable(state, player, player_index: int, card_id: str, card_db) -> bool:
    gate = _TRAINER_GATES.get(card_id)
    if gate is not None and not gate(state, player, player_index, card_db):
        return False
    generated = _generated_gates().get(card_id)  # 自動生成したグッズ/サポートの「使える条件」(effects/era_trainer_gates.py)
    if generated:
        from effects.era_trainer_gates import generated_gate_ok

        return generated_gate_ok(generated, state, player, player_index, card_db)
    return True


def _generated_gates() -> dict:
    from effects import registry as R

    return R.GENERATED_TRAINER_GATES


def _has_bench(state, player, player_index, card_db) -> bool:
    return bool(player.bench)


def _has_evolved(state, player, player_index, card_db) -> bool:
    return any(m.evolution_history for m in player.all_pokemon_in_play())


def _discard_nonempty(state, player, player_index, card_db) -> bool:
    return bool(player.discard)


def _discard_has_pokemon(state, player, player_index, card_db) -> bool:
    return any((c := card_db.get(cid)) is not None and c.is_pokemon for cid in player.discard)


def _deck_nonempty(state, player, player_index, card_db) -> bool:
    return bool(player.deck)


def _has_own_tool(state, player, player_index, card_db) -> bool:
    return any(m.attached_tool is not None for m in player.all_pokemon_in_play())


def _hand_has_fire_energy(state, player, player_index, card_db) -> bool:
    return any((c := card_db.get(cid)) is not None and _basic_energy(c) and c.basic_energy_type == "Fire" for cid in player.hand)


def _hand_has_team_plasma_other_than(card_id: str):
    """手札に、使うカード自身以外のチームプラズマのカードがあるか(自身はチームプラズマのカードだが、トラッシュできない)。"""

    def gate(state, player, player_index, card_db) -> bool:
        hand = list(player.hand)
        if card_id in hand:
            hand.remove(card_id)
        return any(is_team_plasma_card(card_db.get(cid)) for cid in hand)

    return gate


def _hand_has_two(state, player, player_index, card_db) -> bool:
    return len(player.hand) >= 3  # このカード自身を含めた手札(使う前)が3枚以上=他に2枚以上ある


def _opponent_active_has_energy(state, player, player_index, card_db) -> bool:
    opp = state.player(1 - player_index).active
    return opp is not None and bool(opp.attached_energy)


def _blacksmith_ok(state, player, player_index, card_db) -> bool:
    fire_in_discard = any((c := card_db.get(cid)) is not None and _basic_energy(c) and c.basic_energy_type == "Fire" for cid in player.discard)
    has_fire_pokemon = any((c := card_db.get(m.card_id)) is not None and "Fire" in c.types for m in player.all_pokemon_in_play())
    return fire_in_discard and has_fire_pokemon


def _fossil_ok(state, player, player_index, card_db) -> bool:
    from engine.continuous import effective_bench_limit

    return bool(player.deck) and len(player.bench) < effective_bench_limit(state, player, card_db)


def _opponent_hand_nonempty(state, player, player_index, card_db) -> bool:
    return bool(state.player(1 - player_index).hand)


def _any_pokemon_in_any_discard(state, player, player_index, card_db) -> bool:
    return any((c := card_db.get(cid)) is not None and c.is_pokemon for p in state.players for cid in p.discard)


def _any_deck(state, player, player_index, card_db) -> bool:
    return any(p.deck for p in state.players)


_TRAINER_GATES: dict = {}


def _last_card_in_hand_gate(card_id: str):
    """手札の最後の1枚のときだけ使える(アオギリの切り札/マツブサの切り札等)。"""

    def gate(state, player, player_index, card_db) -> bool:
        return len(player.hand) == 1

    return gate


def stadium_ability_playable(state, player, card_db) -> bool:
    """スタジアムの「各プレイヤーの番に1回」の効果を、いま使えるか。"""
    stadium = state.stadium_in_play
    from effects.era_tools_j import stadium_gate

    gate_j = stadium_gate(state, player, card_db)
    if gate_j is not None:
        return gate_j
    if stadium in POKEMON_CENTER_IDS:
        return any(m.damage > 0 for m in player.bench)
    if stadium in TWIST_MOUNTAIN_IDS:
        from engine.continuous import effective_bench_limit

        return len(player.bench) < effective_bench_limit(state, player, card_db) and any(
            (c := card_db.get(cid)) is not None and "Restored" in c.subtypes for cid in player.hand
        )
    if stadium in BATTLE_CITY_IDS:
        return bool(player.deck)
    if stadium in CHAMPIONS_FESTIVAL_IDS:
        return len(player.all_pokemon_in_play()) == 6 and any(m.damage > 0 for m in player.all_pokemon_in_play())
    if stadium in TROPICAL_BEACH_IDS:
        return len(player.hand) < 7 and bool(player.deck)
    if stadium in ALL_NIGHT_PARTY_IDS:
        from engine.status import ExclusiveCondition

        return player.active is not None and player.active.status.exclusive == ExclusiveCondition.ASLEEP
    from effects.era_trainers_g import stadium_ability_gate_g

    gate = stadium_ability_gate_g(state, player, card_db)
    return True if gate is None else gate


def apply_first_ticket(players, first_player: int, log: list) -> int:
    """ファーストチケット: コイントスの前に使ってよい。使ったプレイヤーが先攻になる(両者が使えば通常どおりコイントス)。
    使えるのは初期手札にあるときだけ(使ったらトラッシュする)。先攻を選べる効果なので、持っていれば必ず使う。"""
    holders = [i for i, p in enumerate(players) if any(cid in FIRST_TICKET_IDS for cid in p.hand)]
    for i in holders:
        ticket = next(cid for cid in players[i].hand if cid in FIRST_TICKET_IDS)
        players[i].hand.remove(ticket)
        players[i].discard.append(ticket)
        log.append(f"player{i} がファーストチケットを使った")
    if len(holders) == 1:
        log.append(f"ファーストチケットにより、player{holders[0]} が先攻になった")
        return holders[0]
    return first_player


# ---------------------------------------------------------------------------------------------
# XY4〜XY12・ダブルクライシス・Generationsのどうぐ・スタジアム
# ---------------------------------------------------------------------------------------------
BENT_SPOON_IDS = frozenset(_ids("bent_spoon"))
ENERGY_POUCH_IDS = frozenset(_ids("energy_pouch"))
FLORAL_CROWN_IDS = frozenset(_ids("floral_crown"))
WEAKNESS_POLICY_IDS = frozenset(_ids("weakness_policy"))
HEALING_SCARF_IDS = frozenset(_ids("healing_scarf"))
WIDE_LENS_IDS = frozenset(_ids("wide_lens"))
HEAVY_BOOTS_IDS = frozenset(_ids("heavy_boots"))
ASSAULT_VEST_IDS = frozenset(_ids("assault_vest"))
ALL_NIGHT_PARTY_IDS = frozenset(_ids("all_night_party"))
CHAOS_TOWER_IDS = frozenset(_ids("chaos_tower"))
REVERSE_VALLEY_IDS = frozenset(_ids("reverse_valley"))
FADED_TOWN_IDS = frozenset(_ids("faded_town"))
SHRINE_OF_MEMORIES_IDS = frozenset(_ids("shrine_of_memories"))
STEEL_SHELTER_IDS = frozenset(_ids("steel_shelter"))
TEAM_AQUA_BASE_IDS = frozenset(_ids("team_aqua_base"))
TEAM_MAGMA_BASE_IDS = frozenset(_ids("team_magma_base"))
FAIRY_DROP_IDS = frozenset(_ids("fairy_drop"))
MEGA_CATCHER_IDS = frozenset(_ids("mega_catcher"))


def era_tool_blocks_attack_effects(ctx: EffectContext, defender) -> bool:
    """ベントスプーン: ついているポケモンは、相手のワザの(ダメージ以外の)効果を受けない。"""
    return defender.attached_tool in BENT_SPOON_IDS and _tools_active(ctx.state)


def era_tool_wide_lens(ctx: EffectContext) -> bool:
    """ワイドレンズ: ついているポケモンのワザのダメージは、相手のベンチポケモンにも弱点・抵抗力を計算する。"""
    mon = ctx.source_pokemon
    return mon is not None and mon.attached_tool in WIDE_LENS_IDS and _tools_active(ctx.state)


def era_stadium_damage_reduction(state, defender_owner_index: int, defender_card) -> int:
    """リバースバレー: ↓側のプレイヤーのはがねポケモンが受けるワザのダメージを10減らす。"""
    if state.stadium_in_play in REVERSE_VALLEY_IDS and state.stadium_orientation_target == defender_owner_index and "Metal" in defender_card.types:
        return 10
    from effects.era_trainers_g import GRANITE_CAVE_IDS

    if state.stadium_in_play in GRANITE_CAVE_IDS and defender_card.name.startswith("Steven's"):
        return 30  # Granite Cave: Steven'sポケモン(おたがい)が受けるワザのダメージを30減らす
    from effects.era_sm_hooks import stadium_damage_reduction

    return stadium_damage_reduction(state, defender_card)  # エーテルパラダイス保護区/ニビジム(イワークGX)


def era_stadium_attack_bonus(state, attacker_owner_index: int, attacker_card) -> int:
    """リバースバレー: ↑側(↓でない側)のプレイヤーのあくポケモンのワザは、相手のバトルポケモンに+10ダメージ。"""
    if (
        state.stadium_in_play in REVERSE_VALLEY_IDS
        and state.stadium_orientation_target is not None
        and state.stadium_orientation_target != attacker_owner_index
        and "Darkness" in attacker_card.types
    ):
        return 10
    from effects.era_sm_hooks import stadium_attack_bonus

    return stadium_attack_bonus(state, attacker_card)  # 侵食された野原/ハナダジム(スターミーGX)
    # (Postwickのダメージ+30はeffects/primitives.pyで処理済み)


def era_blocked_statuses(state, card_db, owner_index: int, mon) -> set:
    """部分的に特殊状態にならない効果(ヘビーブーツ: こんらん / カオスタワー: ↓側はどく・こんらん、↑側はねむり・マヒ)。"""
    out: set = set()
    card = card_db.get(mon.card_id)
    if mon.attached_tool in HEAVY_BOOTS_IDS and _tools_active(state) and card is not None and card.retreat_cost_count >= 3:
        out.add("confused")
    if state.stadium_in_play in CHAOS_TOWER_IDS and state.stadium_orientation_target is not None:
        if state.stadium_orientation_target == owner_index:
            out.update({"confused", "poisoned"})
        else:
            out.update({"asleep", "paralyzed"})
    return out


def era_stadium_retreat_extra(state, card_db, mon) -> int:
    """チームアクア団のひみつきち: アクア団以外のポケモンのにげるコストが無色1個ふえる。"""
    if state.stadium_in_play in TEAM_AQUA_BASE_IDS:
        card = card_db.get(mon.card_id)
        if card is not None and not card_has_subtype(card, "Team Aqua"):
            return 1
    from effects.era_sm_hooks import stadium_retreat_extra

    return stadium_retreat_extra(state, card_db, mon)  # ラナキラマウンテン(+1)/月の祭壇(-2)


def era_on_basic_benched_from_hand(state, card_db, actor: int, mon) -> None:
    """チームマグマ団のひみつきち: 手札からたねポケモン(マグマ団を除く)をベンチに出したら、そのポケモンにダメカンを2個のせる。"""
    from effects.era_tools_j import on_basic_benched_from_hand

    on_basic_benched_from_hand(state, card_db, actor, mon)  # アギトの沼地
    if state.stadium_in_play not in TEAM_MAGMA_BASE_IDS:
        return
    card = card_db.get(mon.card_id)
    if card is None or not card.is_basic or card_has_subtype(card, "Team Magma"):
        return
    from effects.primitives import _blocks_damage_counters

    if not _blocks_damage_counters(mon):
        mon.damage += 20
        state.add_log("チームマグマ団のひみつきちの効果で、ベンチに出したポケモンにダメカンを2個のせた")


def era_between_turns(state, card_db) -> None:
    """番の合間に発動するスタジアム(ふるびたまち: メガシンカポケモンにダメカンを2個ずつのせる)。"""
    if state.stadium_in_play not in FADED_TOWN_IDS:
        return
    from effects.primitives import _blocks_damage_counters

    for player in state.players:
        for mon in player.all_pokemon_in_play():
            card = card_db.get(mon.card_id)
            if card is not None and ("MEGA" in card.subtypes or "Mega" in card.subtypes) and not _blocks_damage_counters(mon):
                mon.damage += 20
    state.add_log("ふるびたまちの効果で、メガシンカポケモンにダメカンを2個のせた")


def era_end_of_turn_tools(state, card_db) -> None:
    from effects.era_energy_g import end_of_turn_energy

    end_of_turn_energy(state, card_db)  # ダブルアクア/ダブルマグマ: つけた番の終わりにトラッシュ
    """ターン終了時に、相手の番の終わりに発動するどうぐ(フローラルクラウン: ついているたねポケモンのダメージを20回復)。現在のプレイヤー=終わる番の側。"""
    if not _tools_active(state):
        return
    from effects.era_tools_j import end_of_turn_heal

    end_of_turn_heal(state, card_db)  # たべのこし
    owner = state.player(1 - state.current_player)
    for mon in owner.all_pokemon_in_play():
        if mon.attached_tool in FLORAL_CROWN_IDS:
            card = card_db.get(mon.card_id)
            if card is not None and card.is_basic:
                mon.heal(20)


def era_shrine_of_memories_active(state) -> bool:
    return state.stadium_in_play in SHRINE_OF_MEMORIES_IDS


def era_item_targets(card_id: str, state, player, opponent, card_db):
    """対象を選ぶグッズの、選べる対象一覧(Noneならこの関数の対象外)。None=バトルポケモン、整数=ベンチの位置。"""
    if card_id in FAIRY_DROP_IDS:
        targets = []
        if player.active is not None and _has_fairy_energy(card_db, player.active):
            targets.append(None)
        targets += [bi for bi, m in enumerate(player.bench) if _has_fairy_energy(card_db, m)]
        return targets
    if card_id in MEGA_CATCHER_IDS:
        return [bi for bi, m in enumerate(opponent.bench) if (c := card_db.get(m.card_id)) is not None and ("MEGA" in c.subtypes or "Mega" in c.subtypes)]
    return None


def _has_fairy_energy(card_db, mon) -> bool:
    return any(
        (c := card_db.get(e)) is not None and (c.basic_energy_type == "Fairy" or "Fairy" in (c.name or ""))
        for e in mon.attached_energy
    )


# ---------------------------------------------------------------------------------------------
# 登録
# ---------------------------------------------------------------------------------------------
_INSTALLED = False


def install() -> None:
    """トレーナーズの効果を effects.registry の各テーブルに登録し、どうぐ/スタジアムの表を既存のテーブルに足す。
    何度呼んでも結果は同じ(既に登録済みのIDは上書きしない)。"""
    global _INSTALLED
    if _INSTALLED:
        return
    _INSTALLED = True
    from effects import registry as R
    from effects.era_abilities import PickPokemonThen
    from effects.era_primitives_b import GENERIC_CONTINUE_HANDLERS, GENERIC_OP_HANDLERS
    from effects.era_primitives_c import PutDiscardCardOnTopOfDeck
    from effects.era_primitives_f import RemoveSleepAndHealActive
    from effects.primitives import DrawUpTo, EndTurnAfterThisAbility, HealAllOwnPokemon, OpponentShuffleHandThenDrawFixed

    GENERIC_OP_HANDLERS.update({
        "move_selected_energy": _op_move_selected_energy,
        "discard_opp_active_energy": _op_discard_opp_active_energy,
        "trick_shovel_pick_deck": _op_trick_shovel_pick_deck,
        "trick_shovel_discard": _op_trick_shovel_discard,
        "exp_share_holder": _op_exp_share_holder,
    })
    GENERIC_CONTINUE_HANDLERS.update({"draw_picked_count": _continue_draw_picked_count, "draw_n": _continue_draw_n})

    scripts = R.TRAINER_EFFECTS

    def reg(key: str, script: tuple, gate=None, per_card_gate=None) -> None:
        for card_id in _ids(key):
            scripts.setdefault(card_id, script)
            if gate is not None:
                _TRAINER_GATES.setdefault(card_id, gate)
            if per_card_gate is not None:
                _TRAINER_GATES.setdefault(card_id, per_card_gate(card_id))

    reg("plus_power", (AttackBonusThisTurn(flat=10),))
    reg("iris", (AttackBonusThisTurn(per_prize=10),))
    reg("master_ball", (SearchDeckForPokemonToHand(count=1),))
    reg("scoop_up_cyclone", (PickPokemonThen(action="return_all_to_hand"),), _has_bench)
    reg("recycle", (FlipCoinThen(heads=(PutDiscardCardOnTopOfDeck(),)),), _discard_nonempty)
    reg("xtransceiver", (FlipCoinThen(heads=(SearchDeckMultiCriteria(("supporter",)),)),))
    reg("devolution_spray", (PickPokemonThen(action="devolve", evolved_only=True),), _has_evolved)
    reg("gold_potion", (HealTarget(90),))
    reg("ether", (RevealTopAttachIfBasicEnergy(),), _deck_nonempty)
    reg("scramble_switch", (PickPokemonThen(action="switch_own_active", bench_only=True, then=(MoveAnyEnergyFromLastBenchToActive(),)),), _has_bench)
    reg("max_revive", (PutDiscardPokemonOnTopOfDeck(),), _discard_has_pokemon)
    reg("red_card", (OpponentShuffleHandThenDrawFixed(4),))
    reg("fiery_torch", (DiscardHandEnergyThenDraw("Fire", 2),), _hand_has_fire_energy)
    reg("trick_shovel", (TrickShovelEffect(),), _any_deck)
    reg("tool_retriever", (ReturnChosenOwnToolsToHand(2),), _has_own_tool)
    reg("maintenance", (ShuffleTwoHandCardsThenDraw(),), _hand_has_two)
    reg("gym_badge", (FlipUntilTailsDrawPerHeads(),))
    reg("bw_pokemon_catcher", (ForceOpponentSwitchChosenBench(),))
    for key, name in (
        ("fossil_cover", "Tirtouga"), ("fossil_plume", "Archen"), ("fossil_root", "Lileep"),
        ("fossil_old_amber", "Aerodactyl"), ("fossil_jaw", "Tyrunt"), ("fossil_sail", "Amaura"),
    ):
        reg(key, (LookBottomNPutNamedOnBench(7, name),), _fossil_ok)
    reg("caitlin", (PutHandCardsOnBottomThenDraw(),))
    reg("elesa", (SearchDeckMultiCriteria(("pokemon_tool", "pokemon_tool", "pokemon_tool")),))
    reg("hooligans_jim_cas", (FlipCoinThen(heads=(RandomOpponentHandCardsToDeck(3),)),), _opponent_hand_nonempty)
    reg("hugh", (EachPlayerHandTo(5),))
    reg("team_plasma_grunt", (DiscardTeamPlasmaCardFromHandThenDraw(4),), per_card_gate=_hand_has_team_plasma_other_than)
    reg("ghetsis", (OpponentRevealHandShuffleItemsAndDraw(),))
    reg("cassius", (PickPokemonThen(action="shuffle_into_deck"),), _has_bench)
    reg("team_flare_grunt", (DiscardEnergyFromOpponentActive(),), _opponent_active_has_energy)
    reg("blacksmith", (AttachFireEnergyFromDiscardToFirePokemon(2),), _blacksmith_ok)
    reg("battle_reporter", (DrawUntilHandMatchesOpponent(),))
    reg("fossil_researcher", (SearchDeckForFossilPokemonToBench(),))
    reg("karen_shuffle_pokemon", (EachPlayerShufflesDiscardPokemonIntoDeck(),), _any_pokemon_in_any_discard)

    stadiums = R.STADIUM_ABILITY_EFFECTS
    for card_id in _ids("pokemon_center"):
        stadiums.setdefault(card_id, (PickPokemonThen(action="heal", amount=20, bench_only=True, damaged_only=True),))
    for card_id in _ids("twist_mountain"):
        stadiums.setdefault(card_id, (FlipCoinThen(heads=(PlayRestoredPokemonFromHandToBench(),)),))
    for card_id in _ids("battle_city"):
        stadiums.setdefault(card_id, (FlipCoinThen(heads=(Draw(1),)),))
    for card_id in _ids("champions_festival"):
        stadiums.setdefault(card_id, (HealAllOwnPokemon(amount=10),))
    for card_id in _ids("tropical_beach"):
        stadiums.setdefault(card_id, (DrawUpTo(7), EndTurnAfterThisAbility()))

    # どうぐの表(既存のテーブルに足す)
    from effects import primitives as P
    from engine import legal_actions as L
    from engine import rules_engine as RE

    for card_id in _ids("lucky_helmet"):
        P._ON_DAMAGED_WHILE_ACTIVE_DRAW_TOOLS.setdefault(card_id, 2)
    for card_id in _ids("all_night_party"):
        stadiums.setdefault(card_id, (RemoveSleepAndHealActive(30),))
    L._ORIENTED_STADIUM_IDS.update(_ids("chaos_tower") + _ids("reverse_valley"))
    L._SUPPORTER_TARGETS_OWN_BENCH.update(_ids("olympia"))
    from effects.registry import TRAINER_EFFECTS as _TE

    for card_id in _ids("fairy_drop"):
        _TE.setdefault(card_id, (HealTarget(50),))
    for card_id in _ids("mega_catcher"):
        _TE.setdefault(card_id, (ForceOpponentSwitchChosenBench(),))
    for key, name in (("fossil_helix", "Omanyte"), ("fossil_dome", "Kabuto"), ("fossil_claw", "Anorith"), ("fossil_armor", "Shieldon")):
        reg(key, (LookBottomNPutNamedOnBench(7, name),), _fossil_ok)
    reg("maxie_trick", (SearchDiscardForPokemonOfTypeToBench("Fighting"), Draw(5)), per_card_gate=_last_card_in_hand_gate)
    for card_id in _ids("rocky_helmet"):
        P._ON_DAMAGED_WHILE_ACTIVE_RETALIATE_TOOLS.setdefault(card_id, 2)
    for card_id in _ids("rock_guard"):
        P._ON_DAMAGED_WHILE_ACTIVE_RETALIATE_TOOLS.setdefault(card_id, 6)
    for card_id, mega in _pairs("spirit_link"):
        RE._MEGA_SPIRIT_LINK_TOOLS.setdefault(card_id, mega)
    L._ITEM_TARGETS_OPPONENT_BENCH.update(_ids("bw_pokemon_catcher"))
    from effects import era_trainers_g

    era_trainers_g.install(reg)
    from effects import era_trainers_i

    era_trainers_i.install(reg)


# ---------------------------------------------------------------------------------------------
# 特殊エネルギー(ブレンド/ハーブ/旧あく)
# ---------------------------------------------------------------------------------------------
BLEND_GFPD_IDS = frozenset(_ids("blend_gfpd"))
BLEND_WLFM_IDS = frozenset(_ids("blend_wlfm"))
HERBAL_ENERGY_IDS = frozenset(_ids("herbal_energy"))
DARKNESS_ENERGY_HS_IDS = frozenset(_ids("darkness_energy_hs"))


def era_energy_tokens(card_db, energy_card_id: str, host_card_id):
    """この時代の特殊エネルギーが提供するタイプトークン(該当しなければNone)。"""
    if energy_card_id in BLEND_GFPD_IDS:
        return ["BlendGFPD"]
    if energy_card_id in BLEND_WLFM_IDS:
        return ["BlendWLFM"]
    if energy_card_id in HERBAL_ENERGY_IDS:
        host = card_db.get(host_card_id) if host_card_id else None
        return ["Grass"] if host is not None and "Grass" in host.types else ["Colorless"]
    if energy_card_id in DARKNESS_ENERGY_HS_IDS:
        return ["Darkness"]
    from effects.era_energy_g import energy_tokens_g

    return energy_tokens_g(card_db, energy_card_id, host_card_id)  # ダブルアクア/シールド/フラッシュ等


def era_energy_attach_allowed(energy_card_id: str, target_card) -> bool:
    if energy_card_id in HERBAL_ENERGY_IDS:
        return "Grass" in target_card.types
    from effects.era_energy_g import attach_allowed_g

    if not attach_allowed_g(energy_card_id, target_card):
        return False
    from engine.energy import current_card_db

    db = current_card_db()
    if db is None:
        return True
    from effects.era_energy_j import attach_allowed_j

    return attach_allowed_j(db, energy_card_id, target_card)  # Single Strike/Impact/Spiralエネルギー: 指定のサブタイプのポケモンだけ


def era_energy_attack_bonus(ctx: EffectContext, attacker_mon, attacker_card) -> int:
    """(旧)あくエネルギー: ついているポケモンがあくタイプなら、そのワザは相手のバトルポケモンに+10ダメージ。"""
    if attacker_mon is None or "Darkness" not in attacker_card.types:
        return 0
    from engine.energy import energy_effect_present

    if DARKNESS_ENERGY_HS_IDS and any(e in DARKNESS_ENERGY_HS_IDS for e in attacker_mon.attached_energy):
        return 10
    _ = energy_effect_present
    return 0


def discard_invalid_special_energy(state, card_db) -> None:
    """ハーブエネルギーが、くさポケモン以外についていたらトラッシュする。"""
    from effects.era_energy_g import discard_invalid_restricted_energy

    discard_invalid_restricted_energy(state, card_db)
    for side in (0, 1):
        player = state.players[side]
        for mon in player.all_pokemon_in_play():
            if not any(e in HERBAL_ENERGY_IDS for e in mon.attached_energy):
                continue
            card = card_db.get(mon.card_id)
            if card is not None and "Grass" not in card.types:
                kept = []
                for e in mon.attached_energy:
                    (player.discard if e in HERBAL_ENERGY_IDS else kept).append(e)
                mon.attached_energy = kept
                state.add_log("ハーブエネルギーは、くさポケモン以外についていたのでトラッシュされた")
