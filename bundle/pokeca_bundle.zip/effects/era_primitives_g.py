"""時代ごとのカード取り込み(2026-10-07〜)で追加した、特性用のプリミティブ(その2)。

XY4〜XY12・SV〜メガ時代の特性(scripts/generate_abilities_patterns_b.py)が使う。選択待ちは既存のPendingSearchChoice
(トラッシュ/山札/手札からの選択、destination="attach_energy"/"bench"/"hand")の枠組みに乗せる。
"""

from __future__ import annotations

from dataclasses import dataclass

from cards.card_db import card_has_subtype
from effects.context import EffectContext
from effects.primitives import Effect, _attacker_player, _defender_blocks_effect, _trigger_search_choice


@dataclass(frozen=True)
class AttachDiscardCardsToSelf(Effect):
    """トラッシュから、(名前が names のいずれか)または(基本エネルギーのタイプが energy_types のいずれか)のエネルギーを
    最大count枚選び、自分自身(to_active=Trueならバトルポケモン)につける(Spike-Clad/Burning Draft/Dark Impulse)。"""

    names: tuple = ()
    energy_types: tuple = ()
    count: int = 1
    to_active: bool = False

    def execute(self, ctx: EffectContext) -> None:
        player = _attacker_player(ctx)
        target = player.active if self.to_active else ctx.source_pokemon
        if target is None:
            return

        def matches(card):
            if card is None or not card.is_energy:
                return False
            if card.name in self.names:
                return True
            return not card.is_special_energy and card.basic_energy_type in self.energy_types

        _trigger_search_choice(ctx, player, "discard", matches, self.count, "トラッシュからエネルギーをつける", shuffle_after=False, destination="attach_energy")
        if ctx.state.pending_search_choice is not None:
            ctx.state.pending_search_choice.attach_target_pokemon = target


@dataclass(frozen=True)
class SearchDiscardPokemonFiltered(Effect):
    """トラッシュからポケモンを最大count枚選び、手札に加える/ベンチに出す(destination)。only_basic=Trueならたねポケモンのみ、
    exclude_nameの名前のポケモンは除く、max_hp以下のHPのポケモンのみ(Pull Up/Gentle Fin)。"""

    count: int = 1
    destination: str = "hand"
    only_basic: bool = True
    exclude_name: str | None = None
    max_hp: int | None = None

    def execute(self, ctx: EffectContext) -> None:
        player = _attacker_player(ctx)

        def matches(card):
            return (
                card is not None
                and card.is_pokemon
                and (not self.only_basic or card.is_basic)
                and card.name != self.exclude_name
                and (self.max_hp is None or (card.hp or 0) <= self.max_hp)
            )

        _trigger_search_choice(
            ctx, player, "discard", matches, self.count, "トラッシュからポケモンを選ぶ", shuffle_after=False, destination=self.destination
        )


@dataclass(frozen=True)
class SearchDeckPokemonToBench(Effect):
    """山札から、サブタイプが subtype(例: Restored)または名前が names のいずれかのポケモンを最大count匹、ベンチに出す。"""

    subtype: str | None = None
    names: tuple = ()
    count: int = 1

    def execute(self, ctx: EffectContext) -> None:
        player = _attacker_player(ctx)

        def matches(card):
            if card is None or not card.is_pokemon or not (card.is_basic or "Restored" in card.subtypes):
                return False  # 復元ポケモン(Restored)は「たねポケモン」として扱う
            return (self.subtype is not None and card_has_subtype(card, self.subtype)) or card.name in self.names

        _trigger_search_choice(ctx, player, "deck", matches, self.count, "山札からポケモンをベンチに出す", destination="bench")


@dataclass(frozen=True)
class PoisonBothActiveExceptType(Effect):
    """両プレイヤーのバトルポケモンのうち、指定タイプでない方をどくにする(Poisonous Nest)。"""

    ptype: str

    def execute(self, ctx: EffectContext) -> None:
        from effects.primitives import _apply_condition

        for idx in (ctx.acting_player, ctx.opponent):
            mon = ctx.state.player(idx).active
            card = ctx.card_db.get(mon.card_id) if mon is not None else None
            if mon is None or card is None or self.ptype in card.types:
                continue
            if idx == ctx.opponent and _defender_blocks_effect(ctx, mon):
                continue
            _apply_condition(mon, "poisoned")


@dataclass(frozen=True)
class DiscardHandCardAsCost(Effect):
    """手札から好きなカードを1枚トラッシュしてから、thenを実行する(特性のコスト。Wing Buzz)。手札が無ければ何も起きない。"""

    then: tuple = ()
    energy_only: bool = False  # True: エネルギーカード(基本/特殊問わず)だけが対象(Mystery Garden)

    def execute(self, ctx: EffectContext) -> None:
        player = _attacker_player(ctx)
        _trigger_search_choice(
            ctx, player, "hand", lambda c: c is not None and (not self.energy_only or c.is_energy), 1, "トラッシュするカードを選ぶ",
            shuffle_after=False, destination="discard", min_count=1,
        )
        pending = ctx.state.pending_search_choice
        if pending is not None:
            pending.remaining_script = tuple(self.then)
            pending.cont_source_pokemon = ctx.source_pokemon
            pending.cont_source_card_id = ctx.source_card_id
            pending.effect_source = ctx.effect_source


@dataclass(frozen=True)
class EvolveSelfFromHand(Effect):
    """手札のカード1枚を選び、自分自身に重ねて進化させる(Spiteful Evolution/Almighty Evolution)。
    any_stage1=Trueなら進化元の名前に関係なく、手札の1進化ポケモンなら何でもよい。counters>0なら、進化させたポケモンにダメカンをのせる。
    自分の最初の番・この番に出したポケモンは使えない。"""

    any_stage1: bool = False
    counters: int = 0

    def _candidates(self, player, mon, card_db):
        mon_card = card_db.get(mon.card_id)
        if mon_card is None:
            return []
        out = []
        for i, cid in enumerate(player.hand):
            card = card_db.get(cid)
            if card is None or not card.is_pokemon:
                continue
            if self.any_stage1:
                ok = "Stage 1" in card.subtypes
            else:
                ok = card.evolves_from == mon_card.name
            if ok:
                out.append((i, cid))
        return out

    def ability_gate(self, state, player, mon, zone, card_db) -> bool:
        if player.turns_taken <= 1 or mon.turn_played == player.turns_taken:
            return False
        return bool(self._candidates(player, mon, card_db))

    def execute(self, ctx: EffectContext) -> None:
        player = _attacker_player(ctx)
        mon = ctx.source_pokemon
        if mon is None or player.turns_taken <= 1 or mon.turn_played == player.turns_taken:
            return
        candidates = self._candidates(player, mon, ctx.card_db)
        if not candidates:
            return
        from engine.state import PendingSearchChoice

        ctx.state.pending_search_choice = PendingSearchChoice(
            player_index=ctx.acting_player,
            zone="hand",
            source_indices=[i for i, _ in candidates],
            card_ids=[cid for _, cid in candidates],
            min_count=1,
            max_count=1,
            prompt=f"{mon.card_id}を進化させる手札のカードを選ぶ",
            shuffle_after=False,
            all_card_ids=list(player.hand),
            destination="evolve_target",
            attach_target_pokemon=mon,
            custom_data={"counters_on_evolved": self.counters},
            effect_source=ctx.effect_source,
            source_card_id=ctx.source_card_id,
        )
