"""サン&ムーン期(SM)のどうぐ・スタジアム・特殊エネルギーの継続効果のフック(2026-10-07)。

effects/era_trainer_specs.py のキーとカードID(effects/generated_era_trainer_ids.py)を使う。各関数は、effects/era_trainers.py・
effects/primitives.py・engine/*.py の既存のフック(era_defender_tool_reduction/era_hp_adjust/era_stadium_damage_reduction等)から呼ばれる。
"""

from __future__ import annotations

from dataclasses import replace

from effects.generated_era_trainer_ids import IDS


def _ids(key: str) -> frozenset:
    return frozenset(card_id for card_id, _tag in IDS.get(key, ()))


# ---- どうぐ ----
METAL_FRYING_PAN_IDS = _ids("metal_frying_pan")
METAL_CORE_BARRIER_IDS = _ids("metal_core_barrier")
ANCIENT_CRYSTAL_IDS = _ids("ancient_crystal")
GIANT_BOMB_IDS = _ids("giant_bomb")
DRAGON_TALON_IDS = _ids("dragon_talon")
POISON_BARB_IDS = _ids("poison_barb")
EAR_RINGING_BELL_IDS = _ids("ear_ringing_bell")
BODYBUILDING_DUMBBELLS_IDS = _ids("bodybuilding_dumbbells")
ISLAND_CHALLENGE_AMULET_IDS = _ids("island_challenge_amulet")
BUFF_PADDING_IDS = _ids("buff_padding")
HUSTLE_BELT_IDS = _ids("hustle_belt")
BEASTITE_IDS = _ids("beastite")
BEAST_BRINGER_IDS = _ids("beast_bringer")
COUNTER_GAIN_IDS = _ids("counter_gain")
U_TURN_BOARD_IDS = _ids("u_turn_board")
DASHING_POUCH_IDS = _ids("dashing_pouch")
SPELL_TAG_IDS = _ids("spell_tag")
WISHFUL_BATON_IDS = _ids("wishful_baton")
STEALTHY_HOOD_IDS = _ids("stealthy_hood")

# フェアリーチャーム: 「フェアリーポケモンについていて、相手の(タイプの)ポケモンGX/ポケモンEXのワザのダメージを防ぐ」。(攻撃側のタイプ, 攻撃側に必要なサブタイプ, 特性を持つ攻撃側のみ)
FAIRY_CHARM_TOOL_SPECS: dict[str, tuple[str | None, str | None, bool]] = {}
for _key, _spec in {
    "fairy_charm_grass": ("Grass", None, False),
    "fairy_charm_psychic": ("Psychic", None, False),
    "fairy_charm_fighting": ("Fighting", None, False),
    "fairy_charm_dragon": ("Dragon", None, False),
    "fairy_charm_lightning": ("Lightning", None, False),
    "fairy_charm_ub": (None, "Ultra Beast", False),
    "fairy_charm_ability": (None, None, True),
}.items():
    for _cid in _ids(_key):
        FAIRY_CHARM_TOOL_SPECS[_cid] = _spec

# シルヴァディGX用メモリ: ついているシルヴァディGXのタイプ
MEMORY_TOOL_TYPES: dict[str, str] = {}
for _key, _type in {
    "memory_fighting": "Fighting", "memory_psychic": "Psychic", "memory_electric": "Lightning",
    "memory_fire": "Fire", "memory_grass": "Grass", "memory_water": "Water",
}.items():
    for _cid in _ids(_key):
        MEMORY_TOOL_TYPES[_cid] = _type

# ---- スタジアム ----
AETHER_PARADISE_IDS = _ids("aether_paradise")
ALTAR_MOONE_IDS = _ids("altar_moone")
ALTAR_SUNNE_IDS = _ids("altar_sunne")
MOUNT_LANAKILA_IDS = _ids("mount_lanakila")
PO_TOWN_IDS = _ids("po_town")
DEVOURED_FIELD_IDS = _ids("devoured_field")
SEA_OF_NOTHINGNESS_IDS = _ids("sea_of_nothingness")
MT_CORONET_IDS = _ids("mt_coronet")
SKY_PILLAR_IDS = _ids("sky_pillar")
WELA_VOLCANO_PARK_IDS = _ids("wela_volcano_park")
LIFE_FOREST_IDS = _ids("life_forest")
BLACK_MARKET_IDS = _ids("black_market")
LAVENDER_TOWN_IDS = _ids("lavender_town")
WONDROUS_LABYRINTH_IDS = _ids("wondrous_labyrinth")
DUST_ISLAND_IDS = _ids("dust_island")
BLIZZARD_TOWN_IDS = _ids("blizzard_town")
DARK_CITY_IDS = _ids("dark_city")
RESEARCH_LAB_IDS = _ids("pokemon_research_lab")
SLUMBERING_FOREST_IDS = _ids("slumbering_forest")
BROCKS_GYM_IDS = _ids("brocks_gym")
MISTYS_GYM_IDS = _ids("mistys_gym")
CHAOTIC_SWELL_IDS = _ids("chaotic_swell")
# 手札から使ったグッズ/サポートの効果を、このスタジアムカードは受けない(トラッシュされない)
ITEM_SUPPORTER_IMMUNE_STADIUMS = (
    _ids("thunder_mountain") | frozenset({"sm8-178"}) | LIFE_FOREST_IDS | BLACK_MARKET_IDS | WONDROUS_LABYRINTH_IDS
)

# ---- 特殊エネルギー ----
TRIPLE_ACCELERATION_IDS = _ids("triple_acceleration")
WEAKNESS_GUARD_IDS = _ids("weakness_guard_energy")
DRAW_ENERGY_IDS = _ids("draw_energy")
WARP_ENERGY_SM_IDS = _ids("warp_energy_sm")
COUNTER_ENERGY_IDS = _ids("counter_energy")
SUPER_BOOST_IDS = _ids("super_boost_energy")
UNIT_GFW_IDS = _ids("unit_energy_gfw")
UNIT_FDF_IDS = _ids("unit_energy_fdf")
MEMORY_ENERGY_IDS = _ids("memory_energy")


def _remaining_hp(card_db, mon, state) -> int:
    from engine.continuous import effective_max_hp

    return effective_max_hp(card_db, mon.card_id, mon.attached_tool, state.stadium_in_play, mon.attached_energy) - mon.damage


# ---------------------------------------------------------------------------------------------
# どうぐ
# ---------------------------------------------------------------------------------------------
def tool_reduction(tool_id: str | None, defender_card) -> int:
    """防御側のどうぐによるワザのダメージ軽減(メタルフライパン/メタルコアバリア/エンシェントクリスタル)。"""
    if tool_id is None or defender_card is None:
        return 0
    if tool_id in METAL_FRYING_PAN_IDS and "Metal" in defender_card.types:
        return 30
    if tool_id in METAL_CORE_BARRIER_IDS and "Metal" in defender_card.types:
        return 70
    if tool_id in ANCIENT_CRYSTAL_IDS and defender_card.name in ("Regirock", "Regice", "Registeel", "Regigigas"):
        return 30
    return 0


def hp_adjust(card, tool_id: str | None, base: int) -> int:
    """どうぐによる最大HPの増減(ボディビルダンベル/アイランドチャレンジアミュレット/バフパッド)。"""
    if card is None or tool_id is None:
        return base
    if tool_id in BODYBUILDING_DUMBBELLS_IDS and "Stage 1" in card.subtypes:
        return base + 40
    if tool_id in ISLAND_CHALLENGE_AMULET_IDS and ("GX" in card.subtypes or "EX" in card.subtypes):
        return max(10, base - 100)
    if tool_id in BUFF_PADDING_IDS and card.retreat_cost_count == 4:
        return base + 50
    return base


def tool_attack_bonus(ctx, tool_id: str | None, attacker_card) -> int:
    """攻撃側のどうぐによる追加ダメージ(ハッスルベルト/ビーストライト)。"""
    if tool_id is None:
        return 0
    mon = ctx.source_pokemon
    if tool_id in HUSTLE_BELT_IDS and mon is not None and mon.damage > 0 and _remaining_hp(ctx.card_db, mon, ctx.state) <= 30:
        return 60
    if tool_id in BEASTITE_IDS and "Ultra Beast" in attacker_card.subtypes:
        return 10 * (6 - len(ctx.state.player(ctx.acting_player).prizes))
    return 0


def tool_prevents_damage(ctx, defender, defender_card, attacker_card) -> bool:
    """フェアリーチャーム: フェアリーポケモンについていて、相手の(条件に合う)ポケモンGX/ポケモンEXのワザのダメージを受けない。"""
    spec = FAIRY_CHARM_TOOL_SPECS.get(defender.attached_tool)
    if spec is None or "Fairy" not in defender_card.types or not ("GX" in attacker_card.subtypes or "EX" in attacker_card.subtypes):
        return False
    attacker_type, attacker_subtype, needs_ability = spec
    if attacker_type is not None:
        from engine.continuous import effective_attacker_types

        if attacker_type not in effective_attacker_types(ctx.state, ctx.card_db, ctx.acting_player, attacker_card):
            return False
    if attacker_subtype is not None and attacker_subtype not in attacker_card.subtypes:
        return False
    if needs_ability and not attacker_card.abilities:
        return False
    return True


def tool_blocks_ability_effects(tool_id: str | None) -> bool:
    """ステルスフード: 相手の特性の効果を受けない。"""
    return tool_id in STEALTHY_HOOD_IDS


def memory_type(card, tool_id: str | None) -> str | None:
    """シルヴァディGXについているメモリが決めるタイプ。"""
    if tool_id in MEMORY_TOOL_TYPES and card is not None and card.name == "Silvally-GX":
        return MEMORY_TOOL_TYPES[tool_id]
    return None


def counter_gain_reduces(tool_id: str | None) -> bool:
    return tool_id in COUNTER_GAIN_IDS


def kos_bonus_prize_after_attack(state, card_db, attacker_mon, attacker_owner_index: int) -> int:
    """ビーストブリンガー: サイドが6枚のとき、このウルトラビーストのワザで相手のポケモンGX/EXをきぜつさせたら、サイドをさらに1枚取る(ワザのあとに呼ぶ)。"""
    if attacker_mon is None or attacker_mon.attached_tool not in BEAST_BRINGER_IDS:
        return 0
    from engine.continuous import effective_max_hp

    player = state.player(attacker_owner_index)
    card = card_db.get(attacker_mon.card_id)
    if len(player.prizes) != 6 or card is None or "Ultra Beast" not in card.subtypes:
        return 0
    defender = state.player(1 - attacker_owner_index).active
    dcard = card_db.get(defender.card_id) if defender is not None else None
    if defender is None or dcard is None or not ("GX" in dcard.subtypes or "EX" in dcard.subtypes):
        return 0
    max_hp = effective_max_hp(card_db, defender.card_id, defender.attached_tool, state.stadium_in_play, defender.attached_energy)
    return 1 if max_hp and defender.damage >= max_hp else 0


def prize_denial(state, mon, card_db, tool: str | None, by_attack: bool) -> int:
    """きぜつしたポケモンについて、相手がとるサイドが少なくなる効果(アイランドチャレンジアミュレット/ブラックマーケット◇)。"""
    if not by_attack or card_db is None:
        return 0
    card = card_db.get(mon.card_id)
    if card is None:
        return 0
    if tool in ISLAND_CHALLENGE_AMULET_IDS and ("GX" in card.subtypes or "EX" in card.subtypes):
        return 1
    if (
        state.stadium_in_play in BLACK_MARKET_IDS
        and "Darkness" in card.types
        and any((e := card_db.get(eid)) is not None and e.basic_energy_type == "Darkness" for eid in mon.attached_energy)
    ):
        return 1
    return 0


# ---------------------------------------------------------------------------------------------
# スタジアム
# ---------------------------------------------------------------------------------------------
def stadium_damage_reduction(state, defender_card) -> int:
    stadium = state.stadium_in_play
    if stadium in AETHER_PARADISE_IDS and defender_card.is_basic and ("Grass" in defender_card.types or "Lightning" in defender_card.types):
        return 30
    if stadium in BROCKS_GYM_IDS and defender_card.name == "Onix-GX":
        return 40
    return 0


def stadium_attack_bonus(state, attacker_card) -> int:
    stadium = state.stadium_in_play
    if stadium in DEVOURED_FIELD_IDS and ("Darkness" in attacker_card.types or "Dragon" in attacker_card.types):
        return 10
    if stadium in MISTYS_GYM_IDS and attacker_card.name == "Starmie-GX":
        return 40
    return 0


def stadium_field_weakness(state, defender_card):
    if state.stadium_in_play in ALTAR_SUNNE_IDS and defender_card.weaknesses and ("Fire" in defender_card.types or "Metal" in defender_card.types):
        return replace(defender_card, weaknesses=())
    return defender_card


def stadium_retreat_extra(state, card_db, mon) -> int:
    stadium = state.stadium_in_play
    card = card_db.get(mon.card_id)
    if card is None:
        return 0
    if stadium in MOUNT_LANAKILA_IDS and card.is_basic:
        return 1
    if stadium in ALTAR_MOONE_IDS and any(
        (e := card_db.get(eid)) is not None and e.basic_energy_type in ("Psychic", "Darkness") for eid in mon.attached_energy
    ):
        return -2
    return 0


def dark_city_zeroes_retreat(stadium_in_play, card) -> bool:
    return stadium_in_play in DARK_CITY_IDS and card is not None and card.is_basic and "Darkness" in card.types


def checkup_options(state) -> tuple[int | None, bool]:
    """ポケモンチェックの変更: (ねむりで投げるコインの枚数(おやすみの森=2)、やけどが治らない(ウェラ火山公園))。"""
    return (2 if state.stadium_in_play in SLUMBERING_FOREST_IDS else None), state.stadium_in_play in WELA_VOLCANO_PARK_IDS


def attack_blocked_by_stadium(state, card_db, mon) -> bool:
    """ブリザードタウン: 残りHPが40以下のポケモンはワザを使えない(両プレイヤー)。"""
    return state.stadium_in_play in BLIZZARD_TOWN_IDS and _remaining_hp(card_db, mon, state) <= 40


def attack_cost_extra(stadium_in_play, card) -> int:
    """ふしぎなラビリンス◇: フェアリー以外のポケモンのワザのコストが無色1個ふえる(両プレイヤー)。"""
    return 1 if stadium_in_play in WONDROUS_LABYRINTH_IDS and card is not None and "Fairy" not in card.types else 0


def bench_effects_prevented(state) -> bool:
    """スカイピラー: 相手のワザの(ダメージを含む)効果を、ベンチのポケモン(おたがい)は受けない。"""
    return state.stadium_in_play in SKY_PILLAR_IDS


def on_evolved_from_hand(state, card_db, evolved) -> None:
    """ポ・タウン: 手札からポケモンを出して進化させたら、そのポケモンにダメカンを3個のせる。"""
    from effects.era_tools_j import on_evolved_from_hand as _wyndon, on_evolved_from_hand_energy

    _wyndon(state, card_db, evolved)  # ウィンドスタジアム
    on_evolved_from_hand_energy(state, card_db, evolved)  # リジェネエネルギー
    if state.stadium_in_play not in PO_TOWN_IDS:
        return
    from effects.primitives import _blocks_damage_counters

    if not _blocks_damage_counters(evolved):
        evolved.damage += 30
        state.add_log("ポ・タウンの効果で、進化したポケモンにダメカンを3個のせた")


def keeps_status_on_evolve(state) -> bool:
    return state.stadium_in_play in SEA_OF_NOTHINGNESS_IDS


# ---------------------------------------------------------------------------------------------
# 特殊エネルギー
# ---------------------------------------------------------------------------------------------
def energy_tokens_sm(card_db, energy_card_id: str, host_card_id, ahead_on_prizes: bool = False):
    """SM期の特殊エネルギーが提供するタイプトークン(該当しなければNone)。"""
    from engine.energy import WILDCARD_TOKEN

    host = card_db.get(host_card_id) if host_card_id else None
    if energy_card_id in TRIPLE_ACCELERATION_IDS:
        return ["Colorless"] * 3 if host is not None and not host.is_basic else ["Colorless"]
    if energy_card_id in WEAKNESS_GUARD_IDS or energy_card_id in DRAW_ENERGY_IDS or energy_card_id in WARP_ENERGY_SM_IDS or energy_card_id in MEMORY_ENERGY_IDS:
        return ["Colorless"]
    if energy_card_id in COUNTER_ENERGY_IDS:
        if ahead_on_prizes and host is not None and not ("GX" in host.subtypes or "EX" in host.subtypes):
            return [WILDCARD_TOKEN, WILDCARD_TOKEN]
        return ["Colorless"]
    if energy_card_id in SUPER_BOOST_IDS:
        if host is not None and "Stage 2" in host.subtypes:
            return [WILDCARD_TOKEN]  # 場にステージ2が3匹以上いるときの4個ぶんはenergy_tokens_sm_boostで足す
        return ["Colorless"]
    if energy_card_id in UNIT_GFW_IDS:
        return ["UnitGFW"]
    if energy_card_id in UNIT_FDF_IDS:
        return ["UnitFDF"]
    return None


def super_boost_extra_tokens(state, card_db, energy_card_id: str, host_card_id) -> int:
    """スーパーブーストエネルギー◇: 自分の場にステージ2が3匹以上いれば、エネルギー4個ぶん(+3個ぶんを足す)。"""
    if energy_card_id not in SUPER_BOOST_IDS or state is None:
        return 0
    for player in state.players:
        for mon in player.all_pokemon_in_play():
            if mon.card_id == host_card_id and energy_card_id in mon.attached_energy:
                host = card_db.get(host_card_id)
                if host is None or "Stage 2" not in host.subtypes:
                    return 0
                stage2 = sum(1 for m in player.all_pokemon_in_play() if (c := card_db.get(m.card_id)) is not None and "Stage 2" in c.subtypes)
                return 3 if stage2 >= 3 else 0
    return 0


# ---------------------------------------------------------------------------------------------
# バトル場でワザのダメージを受けたとき / きぜつしたとき
# ---------------------------------------------------------------------------------------------
def on_active_damaged_sm(ctx, defender, defender_owner, dmg: int) -> None:
    """バトル場でワザのダメージを受けたとき(きぜつしても)発動するどうぐ: ドクバリ/耳鳴りのベル(攻撃したポケモンをどく/こんらん)・ドラゴンのツメ(ダメカン3個)・
    ジャイアントボム(180以上のダメージを受けたらダメカン10個)。呼び出し元はどうぐが有効なときだけ呼ぶ。"""
    from effects.primitives import _apply_condition, _blocks_damage_counters

    attacker = ctx.source_pokemon
    tool = defender.attached_tool
    if attacker is None or tool is None:
        return
    from effects import era_tools_j

    era_tools_j.on_active_damaged(ctx, defender, defender_owner, dmg)  # バーニングスカーフ/ラギッドヘルメット/スピリットマスク等
    if tool in POISON_BARB_IDS:
        _apply_condition(attacker, "poisoned")
        ctx.log("ドクバリの効果で、攻撃したポケモンがどくになった")
    if tool in EAR_RINGING_BELL_IDS:
        _apply_condition(attacker, "confused")
        ctx.log("耳鳴りのベルの効果で、攻撃したポケモンがこんらんになった")
    defender_card = ctx.card_db.get(defender.card_id)
    if tool in DRAGON_TALON_IDS and defender_card is not None and "Dragon" in defender_card.types and not _blocks_damage_counters(attacker):
        attacker.damage += 30
        ctx.log("ドラゴンのツメの効果で、攻撃したポケモンにダメカンを3個のせた")
    if tool in GIANT_BOMB_IDS and dmg >= 180 and not _blocks_damage_counters(attacker):
        attacker.damage += 100
        ctx.log("ジャイアントボムの効果で、攻撃したポケモンにダメカンを10個のせた")


def collect_ko_followups_sm(state, card_db, owner_index: int, pokemon, was_active: bool, by_attack: bool) -> None:
    """きぜつ時に発動するどうぐ: ねがいのバトン(バトルポケモンがワザできぜつしたら、基本エネルギーを最大3枚ベンチへ)・スペルタグ(超ポケモンがワザできぜつしたら、相手にダメカン4個)。"""
    if not by_attack:
        return
    from effects import era_tools_j

    era_tools_j.collect_ko_followups(state, card_db, owner_index, pokemon, was_active)  # ラッキーエッグ/のろいのおふだ等
    tool = pokemon.attached_tool
    card = card_db.get(pokemon.card_id)
    if tool in WISHFUL_BATON_IDS and was_active:
        basic = [e for e in pokemon.attached_energy if (c := card_db.get(e)) is not None and c.is_energy and not c.is_special_energy]
        if basic:
            state.ko_followups.append({"kind": "energy_move_bench", "owner": owner_index, "energy_ids": basic, "max": 3, "label": "ねがいのバトン"})
    if tool in SPELL_TAG_IDS and card is not None and "Psychic" in card.types:
        state.ko_followups.append({"kind": "spell_tag", "owner": owner_index, "count": 4})


# ---------------------------------------------------------------------------------------------
# ◇(プリズムスター)のルール / ダストアイランド
# ---------------------------------------------------------------------------------------------
_PRISM_CACHE: dict[int, frozenset] = {}


def prism_star_ids(card_db) -> frozenset:
    key = id(card_db)
    if key not in _PRISM_CACHE:
        _PRISM_CACHE[key] = frozenset(c.id for c in card_db.all() if "Prism Star" in c.subtypes)
    return _PRISM_CACHE[key]


def prism_star_to_lost_zone(state, card_db) -> None:
    """◇(Prism Star)のルール: 「◇のカードがトラッシュに行くなら、かわりにロストゾーンに置く」。
    行動のあとに、両プレイヤーのトラッシュにある◇のカードをロストゾーンへ移す(ポケモンがきぜつしたとき・グッズ/サポート/スタジアムが場を離れたとき等、
    トラッシュに置かれる経路が多いため、置かれたあとにまとめて直す)。"""
    ids = prism_star_ids(card_db)
    if not ids:
        return
    for player in state.players:
        if any(cid in ids for cid in player.discard):
            player.lost_zone.extend(cid for cid in player.discard if cid in ids)
            player.discard = [cid for cid in player.discard if cid not in ids]


def dust_island_snapshot(state):
    """ダストアイランドが場にあるとき、グッズ/サポートを使う前の両プレイヤーのバトルポケモンと、どく状態かを控える(なければNone)。"""
    if state.stadium_in_play not in DUST_ISLAND_IDS:
        return None
    return [(p.active, bool(p.active is not None and p.active.status.poisoned)) for p in state.players]


def dust_island_apply(state, snapshot) -> None:
    """ダストアイランド: トレーナーズの効果でどくのバトルポケモンを入れ替えたら、新しいバトルポケモンもどくになる。"""
    if snapshot is None:
        return
    for player, (old_active, was_poisoned) in zip(state.players, snapshot):
        if was_poisoned and player.active is not None and player.active is not old_active:
            player.active.status.poisoned = True
            state.add_log("ダストアイランドの効果で、新しいバトルポケモンもどくになった")
