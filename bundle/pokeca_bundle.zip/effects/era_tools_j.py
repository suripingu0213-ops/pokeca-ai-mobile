"""SWSH/SV期のどうぐのうち、常時効果(effects/passives_cond.py)で表せない反応・番の終わりの効果(2026-10-07)。

宣言は scripts/generate_tool_passives.py が TOOL_REACTIONS[どうぐのカードID] = ((種別, パラメータ), ...) として生成する。種別:
  react_damaged_*     バトル場でワザのダメージを受けたとき(きぜつしても): status/counters/energy_to_hand/opp_discard/move_energy_bench (+ discard_if_placed)
  react_ko_*          ワザのダメージできぜつしたとき: draw_to/mill/counters/discard_random/search/baton、サイド枚数の増減(prize_delta)・サイドをトラッシュ(prizes_discarded)
  react_eot_*         番の終わり(自分の番: heal/powerglass)・ポケモンチェックのあと(両者: heal/cure)
  react_survive_full_hp / react_attach_restriction
どうぐが無効(ジャミングタワー等)なときは、呼び出し側(effects/era_sm_hooks.py・effects/era_trainers.py・engine/)が呼ばない。
"""

from __future__ import annotations

import os

try:  # scripts/generate_tool_passives.py 自身は環境変数で無視して冪等にする
    if os.environ.get("POKECA_IGNORE_GENERATED_TOOLS"):
        raise ImportError
    from effects.generated_tool_passives import TOOL_REACTIONS
except ImportError:  # pragma: no cover
    TOOL_REACTIONS: dict = {}

from engine.state import PendingSearchChoice


def reactions(tool_id, prefix: str) -> list:
    if not tool_id:
        return []
    return [(k, p) for k, p in TOOL_REACTIONS.get(tool_id, ()) if k.startswith(prefix)]


def energy_reactions(mon, prefix: str) -> list:
    """monについている特殊エネルギーの反応(SWSH/SV: ギフトエネルギー/ラッキーエネルギー等)。(エネルギーID, 種別, パラメータ)の一覧。"""
    from engine.energy import special_energy_effects_suppressed

    if not mon.attached_energy or special_energy_effects_suppressed():
        return []
    return [(eid, k, p) for eid in mon.attached_energy for k, p in TOOL_REACTIONS.get(eid, ()) if k.startswith(prefix)]


def has_reaction(tool_id, kind: str) -> bool:
    return bool(tool_id) and any(k == kind for k, _ in TOOL_REACTIONS.get(tool_id, ()))


def _when_ok(state, card_db, idx: int, holder, when, was_active=None) -> bool:
    """発動条件(when)を満たすか。was_activeを渡すと、"active"は「きぜつした時点でバトル場にいたか」で判定する(きぜつ時の効果用)。"""
    from effects.passives_cond import holder_ok

    conds = list(when or [])
    if was_active is not None and "active" in conds:
        if not was_active:
            return False
        conds.remove("active")
    return holder_ok(state, card_db, idx, holder, conds)


def _holder_spec_ok(card_db, mon, when) -> bool:
    """holder:<絞り込み>の条件だけで判定する(ベンチのポケモンがきぜつして場から外れたあとでも使える)。"""
    from effects.era_attacks_i import card_matches

    card = card_db.get(mon.card_id)
    for cond in when or []:
        name, _, arg = cond.partition(":")
        if name == "holder" and not card_matches(card, arg):
            return False
    return True


def _name(card_db, card_id: str) -> str:
    c = card_db.get(card_id)
    return c.name if c is not None else card_id


# ---------------------------------------------------------------------------------------------
# バトル場でワザのダメージを受けたとき
# ---------------------------------------------------------------------------------------------
def on_active_damaged(ctx, defender, defender_owner, dmg: int) -> None:
    from effects.primitives import _apply_condition, _blocks_damage_counters, discard_attached_tool

    tool = defender.attached_tool
    reacts = reactions(tool, "react_damaged")
    attacker = ctx.source_pokemon
    if not reacts or attacker is None:
        return
    state, card_db = ctx.state, ctx.card_db
    d_idx = ctx.opponent
    a_idx = ctx.acting_player
    placed = False
    for kind, p in reacts:
        if kind == "react_damaged_discard_if_placed" or not _when_ok(state, card_db, d_idx, defender, p.get("when")):
            continue
        if kind == "react_damaged_status":
            _apply_condition(attacker, p["status"])
            ctx.log(f"{_name(card_db, tool)}の効果で、攻撃したポケモンが{p['status']}になった")
        elif kind == "react_damaged_counters":
            if not _blocks_damage_counters(attacker):
                attacker.damage += p["n"] * 10
                placed = True
                ctx.log(f"{_name(card_db, tool)}の効果で、攻撃したポケモンにダメカンを{p['n']}個のせた")
        elif kind == "react_damaged_energy_to_hand":
            _energy_pick_then(ctx, attacker, a_idx, d_idx, "j_energy_to_hand")
        elif kind == "react_damaged_move_energy_bench":
            _energy_pick_then(ctx, attacker, a_idx, d_idx, "j_fan_energy")
        elif kind == "react_damaged_opp_discard":
            _opp_discard_from_hand(ctx, a_idx, p.get("n", 1))
    if placed and has_reaction(tool, "react_damaged_discard_if_placed") and defender.attached_tool == tool:
        discard_attached_tool(state, defender_owner, defender)


def _auto_or_choice(ctx, chooser: int, ids_labels: list, op: str, prompt: str, **custom) -> bool:
    """選択肢が1つ、または別の選択待ちがもう立っているときは、先頭を自動で選ぶ(Trueを返す)。それ以外は選択待ちを立てて、Falseを返す。"""
    state = ctx.state
    if len(ids_labels) <= 1 or state.pending_search_choice is not None:
        return True
    state.pending_search_choice = PendingSearchChoice(
        player_index=chooser,
        zone="gen_pokemon_pick",
        source_indices=list(range(len(ids_labels))),
        card_ids=list(ids_labels),
        min_count=1,
        max_count=1,
        prompt=prompt,
        shuffle_after=False,
        all_card_ids=list(ids_labels),
        custom_data={"op": op, **custom},
        effect_source=ctx.effect_source,
        cont_acting_player=ctx.acting_player,
        cont_source_pokemon=ctx.source_pokemon,
        cont_source_card_id=ctx.source_card_id,
    )
    return False


def _energy_pick_then(ctx, attacker, a_idx: int, chooser: int, op: str) -> None:
    ids = list(attacker.attached_energy)
    if not ids:
        return
    labels = [_name(ctx.card_db, e) for e in ids]
    if _auto_or_choice(ctx, chooser, labels, op, "攻撃したポケモンについているエネルギーを1枚選ぶ", ids=ids, a_idx=a_idx, pick_by=chooser):
        _finish_energy_pick(ctx.state, ctx.card_db, ctx, attacker, a_idx, chooser, op, ids[0])


def _finish_energy_pick(state, card_db, ctx, attacker, a_idx: int, chooser: int, op: str, energy_id: str) -> bool:
    if energy_id not in attacker.attached_energy:
        return False
    if op == "j_energy_to_hand":
        attacker.attached_energy.remove(energy_id)
        state.player(a_idx).hand.append(energy_id)
        state.add_log(f"ラギッドヘルメットの効果で、{_name(card_db, energy_id)}が相手の手札に戻った")
        return False
    dests = list(state.player(a_idx).bench)
    if not dests:
        return False
    labels = [_name(card_db, m.card_id) for m in dests]
    if len(dests) == 1 or state.pending_search_choice is not None:
        _move_energy_to(state, attacker, dests[0], energy_id)
        return False
    state.pending_search_choice = PendingSearchChoice(
        player_index=chooser, zone="gen_pokemon_pick", source_indices=list(range(len(dests))), card_ids=labels, min_count=1, max_count=1,
        prompt="エネルギーを移す、相手のベンチのポケモンを選ぶ", shuffle_after=False, all_card_ids=labels,
        custom_data={"op": "j_fan_dst", "energy_id": energy_id, "a_idx": a_idx},
        effect_source=getattr(ctx, "effect_source", None), cont_acting_player=a_idx, cont_source_pokemon=attacker,
    )
    return True


def _move_energy_to(state, src, dst, energy_id: str) -> None:
    if energy_id in src.attached_energy:
        src.attached_energy.remove(energy_id)
        dst.attached_energy.append(energy_id)
        state.add_log("エネルギーを相手のベンチのポケモンに移した")


def _opp_discard_from_hand(ctx, a_idx: int, n: int) -> None:
    """攻撃した側(a_idx)が、手札からn枚トラッシュする(選ぶのは攻撃した側)。"""
    state = ctx.state
    player = state.player(a_idx)
    for _ in range(n):
        if not player.hand:
            return
        labels = [_name(ctx.card_db, c) for c in player.hand]
        if _auto_or_choice(ctx, a_idx, labels, "j_discard_hand_pick", "手札から、トラッシュするカードを1枚選ぶ", a_idx=a_idx):
            player.discard.append(player.hand.pop())
            state.add_log("どうぐの効果で、手札を1枚トラッシュした")
        else:
            return  # 1回の効果は1枚(複数枚は未使用)


# ---------------------------------------------------------------------------------------------
# ワザのダメージできぜつしたとき
# ---------------------------------------------------------------------------------------------
def collect_ko_followups(state, card_db, owner_index: int, pokemon, was_active: bool) -> None:
    """ワザのダメージできぜつしたポケモン(owner_index側)のどうぐの、きぜつ時の効果。即座に済むものはここで行い、選択が要るものはstate.ko_followupsに積む。"""
    from effects.primitives import _blocks_damage_counters

    tool = pokemon.attached_tool
    opp_idx = 1 - owner_index
    owner, opp = state.player(owner_index), state.player(opp_idx)
    for kind, p in reactions(tool, "react_ko"):
        if kind in ("react_ko_prize_delta", "react_ko_prizes_discarded"):
            continue
        if not _when_ok(state, card_db, owner_index, pokemon, p.get("when"), was_active=was_active):
            continue
        label = _name(card_db, tool)
        if kind == "react_ko_draw_to":
            while len(owner.hand) < p["n"] and owner.deck:
                owner.hand.append(owner.deck.pop(0))
            state.add_log(f"{label}の効果で、手札が{len(owner.hand)}枚になるまで山札を引いた")
        elif kind == "react_ko_mill":
            for _ in range(p["n"]):
                if opp.deck:
                    opp.discard.append(opp.deck.pop(0))
            state.add_log(f"{label}の効果で、相手の山札の上から{p['n']}枚をトラッシュした")
        elif kind == "react_ko_counters":
            attacker = opp.active
            if attacker is not None and not _blocks_damage_counters(attacker):
                attacker.damage += p["n"] * 10
                state.add_log(f"{label}の効果で、攻撃したポケモンにダメカンを{p['n']}個のせた")
        elif kind == "react_ko_discard_random":
            if opp.hand:
                card = opp.hand.pop(state.rng.randrange(len(opp.hand)))
                opp.discard.append(card)
                state.add_log(f"{label}の効果で、相手の手札をランダムに1枚トラッシュした")
        elif kind == "react_ko_search":
            state.ko_followups.append({"kind": "search_deck_any", "owner": owner_index, "count": p["n"], "label": label})
        elif kind == "react_ko_baton":
            basic = [e for e in pokemon.attached_energy if (c := card_db.get(e)) is not None and c.is_energy and not c.is_special_energy]
            if basic:
                state.ko_followups.append({"kind": "j_baton", "owner": owner_index, "energy_ids": basic, "max": p["n"], "label": label})


def ko_prize_delta(state, card_db, mon, tool, by_attack: bool) -> int:
    """きぜつしたポケモンについて、相手が取るサイドの増減(+1=多く取る/-1=少なく取る)。"""
    if not by_attack or not tool:
        return 0
    return sum(p["delta"] for _k, p in reactions(tool, "react_ko_prize_delta") if _holder_spec_ok(card_db, mon, p.get("when")))


def prizes_discarded(state, tool, by_attack: bool) -> bool:
    """ビリビリスモッグ等: そのきぜつで取るサイドは、手札に加えずトラッシュする。"""
    return bool(by_attack) and has_reaction(tool, "react_ko_prizes_discarded")


def survives_lethal_at_full_hp(tool) -> bool:
    return has_reaction(tool, "react_survive_full_hp")


# ---------------------------------------------------------------------------------------------
# 番の終わり・ポケモンチェックのあと
# ---------------------------------------------------------------------------------------------
def end_of_turn_heal(state, card_db) -> None:
    """自分の番の終わり(あなたの番の終わり): どうぐがついた現在のプレイヤーのポケモンが回復する(おたからのたべのこし等)。"""
    idx = state.current_player
    for mon in state.player(idx).all_pokemon_in_play():
        for kind, p in reactions(mon.attached_tool, "react_eot_heal"):
            if p.get("own_turn") and _when_ok(state, card_db, idx, mon, p.get("when")):
                mon.heal(p["n"])
                state.add_log(f"{_name(card_db, mon.attached_tool)}の効果で、ダメージを{p['n']}回復した")


def between_turns(state, card_db) -> None:
    """各ターンの終わり(ポケモンチェックのあと): きのみ/ジェリー/ラムのみ。両プレイヤーのポケモンが対象。"""
    from effects.primitives import discard_attached_tool
    from engine.continuous import effective_max_hp

    for idx in (0, 1):
        player = state.player(idx)
        for mon in player.all_pokemon_in_play():
            tool = mon.attached_tool
            if not tool or tool not in TOOL_REACTIONS:
                continue
            for kind, p in reactions(tool, "react_eot"):
                if kind == "react_eot_heal" and not p.get("own_turn"):
                    if not _when_ok(state, card_db, idx, mon, p.get("when")):
                        continue
                    if p.get("min_counters") and mon.damage < p["min_counters"] * 10:
                        continue
                    if p.get("needs_damage") and mon.damage <= 0:
                        continue
                    if "remaining_at_most" in p:
                        max_hp = effective_max_hp(card_db, mon.card_id, mon.attached_tool, state.stadium_in_play, mon.attached_energy)
                        if max_hp - mon.damage > p["remaining_at_most"]:
                            continue
                    before = mon.damage
                    mon.heal(p["n"])
                    healed = before - mon.damage
                    state.add_log(f"{_name(card_db, tool)}の効果で、ダメージを{healed}回復した")
                    if healed > 0 and (p.get("discard_after") or has_reaction(tool, "react_eot_discard_if_healed")):
                        discard_attached_tool(state, player, mon)
                elif kind == "react_eot_cure" and mon.status.is_any:
                    mon.status.clear_all()
                    state.add_log(f"{_name(card_db, tool)}の効果で、特殊状態が全て治った")
                    if p.get("discard_after"):
                        discard_attached_tool(state, player, mon)


def start_powerglass(state, card_db) -> bool:
    """パワフルグラス: 自分の番の終わり(ワザのあと)、バトル場のポケモンに、トラッシュの基本エネルギーを1枚つけてもよい。選択待ちを立てたらTrue。"""
    idx = state.current_player
    player = state.player(idx)
    if player.eot_tool_done_turn == player.turns_taken:
        return False
    holder = player.active
    if holder is None or not any(k == "react_eot_powerglass" for k, _ in reactions(holder.attached_tool, "react_eot")):
        return False
    player.eot_tool_done_turn = player.turns_taken
    indices = [i for i, cid in enumerate(player.discard) if (c := card_db.get(cid)) is not None and c.is_energy and not c.is_special_energy]
    if not indices:
        return False
    labels = [_name(card_db, player.discard[i]) for i in indices]
    state.pending_search_choice = PendingSearchChoice(
        player_index=idx, zone="gen_pokemon_pick", source_indices=indices, card_ids=labels, min_count=0, max_count=1,
        prompt="パワフルグラス: トラッシュの基本エネルギーを1枚、バトルポケモンにつける(つけなくてもよい)", shuffle_after=False, all_card_ids=labels,
        custom_data={"op": "j_powerglass"}, cont_acting_player=idx, cont_source_pokemon=holder, then_end_turn=True,
    )
    return True


# ---------------------------------------------------------------------------------------------
# きぜつ時のエネルギー移動(ヘビーバトン): 最大N枚を、ベンチのポケモンに好きなように移す
# ---------------------------------------------------------------------------------------------
def start_baton(state, card_db, entry: dict, cont: dict) -> bool:
    return _baton_step(state, card_db, entry["owner"], list(entry["energy_ids"]), entry["max"], cont, entry.get("label", ""))


def _baton_step(state, card_db, owner_idx: int, pool: list, remaining: int, cont: dict, label: str) -> bool:
    from effects.era_trainers import _recent_discard_indices

    owner = state.player(owner_idx)
    if remaining <= 0 or not pool or not owner.bench:
        return False
    indices = _recent_discard_indices(owner, pool)
    if not indices:
        return False
    labels = [_name(card_db, owner.discard[i]) for i in indices]
    state.pending_search_choice = PendingSearchChoice(
        player_index=owner_idx, zone="gen_pokemon_pick", source_indices=indices, card_ids=labels, min_count=0, max_count=1,
        prompt=f"{label}: ベンチに移すエネルギーを1枚選ぶ(あと{remaining}枚まで。やめてもよい)", shuffle_after=False, all_card_ids=labels,
        custom_data={"op": "j_baton_energy", "pool": pool, "remaining": remaining, "ko_cont": cont, "label": label},
    )
    return True


def _op_baton_energy(state, card_db, choice, selected, action, ctx, custom) -> bool:
    if not selected:
        return False
    owner_idx = choice.player_index
    owner = state.player(owner_idx)
    discard_index = choice.source_indices[selected[0]]
    benched = list(owner.bench)
    if not benched:
        return False
    labels = [_name(card_db, m.card_id) for m in benched]
    cd = {"op": "j_baton_dst", "discard_index": discard_index, "energy_id": owner.discard[discard_index], "pool": custom["pool"],
          "remaining": custom["remaining"], "ko_cont": custom["ko_cont"], "label": custom["label"]}
    if len(benched) == 1:
        return _baton_finish(state, card_db, owner_idx, cd, 0)
    state.pending_search_choice = PendingSearchChoice(
        player_index=owner_idx, zone="gen_pokemon_pick", source_indices=list(range(len(benched))), card_ids=labels, min_count=1, max_count=1,
        prompt="エネルギーを受け取るベンチのポケモンを選ぶ", shuffle_after=False, all_card_ids=labels, custom_data=cd,
    )
    return True


def _op_baton_dst(state, card_db, choice, selected, action, ctx, custom) -> bool:
    return _baton_finish(state, card_db, choice.player_index, custom, selected[0] if selected else 0)


def _baton_finish(state, card_db, owner_idx: int, custom: dict, bench_index: int) -> bool:
    owner = state.player(owner_idx)
    i = custom["discard_index"]
    if i < len(owner.discard) and owner.discard[i] == custom["energy_id"] and bench_index < len(owner.bench):
        owner.bench[bench_index].attached_energy.append(owner.discard.pop(i))
        pool = list(custom["pool"])
        if custom["energy_id"] in pool:
            pool.remove(custom["energy_id"])
        return _baton_step(state, card_db, owner_idx, pool, custom["remaining"] - 1, custom["ko_cont"], custom["label"])
    return False


# ---------------------------------------------------------------------------------------------
# 選択待ちの続き(GENERIC_OP_HANDLERS)
# ---------------------------------------------------------------------------------------------
def _op_energy_pick(op):
    def handler(state, card_db, choice, selected, action, ctx, custom) -> bool:
        attacker = choice.cont_source_pokemon
        if attacker is None or not selected:
            return False
        energy_id = custom["ids"][selected[0]]
        return _finish_energy_pick(state, card_db, ctx, attacker, custom["a_idx"], custom["pick_by"], op, energy_id)

    return handler


def _op_fan_dst(state, card_db, choice, selected, action, ctx, custom) -> bool:
    attacker = choice.cont_source_pokemon
    bench = state.player(custom["a_idx"]).bench
    if attacker is None or not selected or selected[0] >= len(bench):
        return False
    _move_energy_to(state, attacker, bench[selected[0]], custom["energy_id"])
    return False


def _op_discard_hand_pick(state, card_db, choice, selected, action, ctx, custom) -> bool:
    player = state.player(custom["a_idx"])
    if selected and selected[0] < len(player.hand):
        player.discard.append(player.hand.pop(selected[0]))
        state.add_log("どうぐの効果で、手札を1枚トラッシュした")
    return False


def _op_powerglass(state, card_db, choice, selected, action, ctx, custom) -> bool:
    player = state.player(choice.player_index)
    holder = choice.cont_source_pokemon
    if not selected or holder is None:
        return False
    i = choice.source_indices[selected[0]]
    if i < len(player.discard):
        holder.attached_energy.append(player.discard.pop(i))
        state.add_log("パワフルグラスの効果で、トラッシュの基本エネルギーをバトルポケモンにつけた")
    return False


def register_ops() -> None:
    from effects.era_primitives_b import GENERIC_OP_HANDLERS

    GENERIC_OP_HANDLERS.update({
        "k_draw_offer": _op_draw_offer,
        "j_energy_to_hand": _op_energy_pick("j_energy_to_hand"),
        "j_fan_energy": _op_energy_pick("j_fan_energy"),
        "j_fan_dst": _op_fan_dst,
        "j_discard_hand_pick": _op_discard_hand_pick,
        "j_powerglass": _op_powerglass,
        "j_baton_energy": _op_baton_energy,
        "j_baton_dst": _op_baton_dst,
    })




# ---------------------------------------------------------------------------------------------
# 弱点の倍率(ばつぐんメガネ)・スターオーダー
# ---------------------------------------------------------------------------------------------
def weakness_multiplier_override(ctx, defender, defender_card):
    """ワザを使うポケモンのどうぐが弱点の倍率を変える(×3)。相手のバトルポケモンへのダメージにだけ効く。"""
    attacker = ctx.source_pokemon
    if attacker is None or not attacker.attached_tool or not defender_card.weaknesses:
        return defender_card
    if defender is not ctx.state.player(ctx.opponent).active:
        return defender_card
    from engine.continuous import tools_disabled

    if tools_disabled(ctx.state.stadium_in_play):
        return defender_card
    for kind, p in reactions(attacker.attached_tool, "react_weakness_multiplier"):
        from dataclasses import replace

        from cards.models import WeaknessResistance

        weaknesses = tuple(
            WeaknessResistance(type=w.type, value=f"×{p['mult']}") if w.value.strip().startswith(("×", "x", "X")) else w
            for w in defender_card.weaknesses
        )
        return replace(defender_card, weaknesses=weaknesses)
    return defender_card


def star_order_extra(state, card_db, mon) -> int:
    """スカイシールストーンの「スターオーダー」: この番に使っていて、相手のバトルポケモンVSTAR/VMAXを、自分のたねポケモンVのワザのダメージできぜつさせたら、サイドをもう1枚取る。"""
    attacker_owner = state.player(state.current_player)
    if attacker_owner.star_order_turn != attacker_owner.turns_taken:
        return 0
    mon_card = card_db.get(mon.card_id)
    attacker_card = card_db.get(mon.ko_attacker_card_id) if mon.ko_attacker_card_id else None
    if mon_card is None or attacker_card is None:
        return 0
    if ("VSTAR" in mon_card.subtypes or "VMAX" in mon_card.subtypes) and "V" in attacker_card.subtypes and attacker_card.is_basic:
        return 1
    return 0


# ---------------------------------------------------------------------------------------------
# どうぐ自体のワザ/特性(わざマシン・シールストーン)
# ---------------------------------------------------------------------------------------------
from dataclasses import dataclass  # noqa: E402

from effects.context import EffectContext  # noqa: E402
from effects.primitives import Effect  # noqa: E402


@dataclass(frozen=True)
class HealAllOwnMatching(Effect):
    """自分の場の、絞り込み(spec)に合うポケモン全員のダメージを全て回復する(わざマシン フローライト: テラスタルポケモン)。"""

    spec: str = ""

    def execute(self, ctx: EffectContext) -> None:
        from effects.era_attacks_i import card_matches

        player = ctx.state.player(ctx.acting_player)
        for mon in player.all_pokemon_in_play():
            if mon.damage > 0 and card_matches(ctx.card_db.get(mon.card_id), self.spec):
                mon.heal(mon.damage)
        ctx.log("自分のテラスタルポケモンのダメージを全て回復した")


@dataclass(frozen=True)
class StarGravityEffect(Effect):
    """相手のポケモンVそれぞれに、残りHPが100になるまでダメカンをのせる(アースシールストーン)。"""

    def execute(self, ctx: EffectContext) -> None:
        from effects.primitives import _blocks_damage_counters
        from engine.continuous import effective_max_hp

        opp = ctx.state.player(ctx.opponent)
        for mon in opp.all_pokemon_in_play():
            card = ctx.card_db.get(mon.card_id)
            if card is None or "V" not in card.subtypes or _blocks_damage_counters(mon):
                continue
            max_hp = effective_max_hp(ctx.card_db, mon.card_id, mon.attached_tool, ctx.state.stadium_in_play, mon.attached_energy)
            if max_hp - mon.damage > 100:
                mon.damage = max_hp - 100
        ctx.log("相手のポケモンVの残りHPが100になるまでダメカンをのせた")


@dataclass(frozen=True)
class StarOrderEffect(Effect):
    """この番、相手のバトルポケモンVSTAR/VMAXを自分のたねポケモンVのワザのダメージできぜつさせたら、サイドをもう1枚取る(スカイシールストーン)。"""

    def execute(self, ctx: EffectContext) -> None:
        player = ctx.state.player(ctx.acting_player)
        player.star_order_turn = player.turns_taken
        ctx.log("この番、相手のVSTAR/VMAXをきぜつさせたら、サイドをもう1枚取る")


def _crisis_punch_ok(state, player, opponent, mon, card_db) -> bool:
    return len(opponent.prizes) == 1


def _host_is_v(state, player, opponent, mon, card_db) -> bool:
    c = card_db.get(mon.card_id)
    return c is not None and "V" in c.subtypes


_installed_granted = False


def install_granted() -> None:
    """わざマシン(クライシスパンチ/フローライト)・シールストーン(アース/スカイ)を、どうぐ自体のワザ/特性の仕組みに登録する(何度呼んでも同じ)。"""
    global _installed_granted
    if _installed_granted:
        return
    _installed_granted = True
    from effects import registry as R
    from effects.generated_era_trainer_ids import IDS
    from effects.primitives import DealDamage, DiscardAllOwnEnergy
    from engine import legal_actions as L

    def ids(key):
        return tuple(cid for cid, _tag in IDS.get(key, ()))

    for cid in ids("tm_crisis_punch"):
        L.TOOL_GRANTED_ATTACK_IDS.add(cid)
        L.END_OF_TURN_DISCARD_TOOL_IDS.add(cid)
        L._TOOL_GRANTED_ATTACK_CONDITIONS[cid] = _crisis_punch_ok
        R.ATTACK_EFFECTS.setdefault(cid, {}).setdefault("Crisis Punch", (DealDamage(280),))
    for cid in ids("tm_fluorite"):
        L.TOOL_GRANTED_ATTACK_IDS.add(cid)
        L.END_OF_TURN_DISCARD_TOOL_IDS.add(cid)
        R.ATTACK_EFFECTS.setdefault(cid, {}).setdefault("Fluorite", (DiscardAllOwnEnergy(), HealAllOwnMatching("subtype:Tera")))
    for cid in ids("earthen_seal_stone"):
        L.TOOL_GRANTED_ATTACK_IDS.add(cid)
        L._TOOL_GRANTED_ATTACK_CONDITIONS[cid] = _host_is_v
        R.ATTACK_EFFECTS.setdefault(cid, {}).setdefault("Star Gravity", (StarGravityEffect(),))
    for cid in ids("sky_seal_stone"):
        L.TOOL_GRANTED_ABILITY_HOST_SUBTYPE[cid] = "V"
        R.ABILITY_EFFECTS.setdefault(cid, {}).setdefault("Star Order", (StarOrderEffect(),))


# ---------------------------------------------------------------------------------------------
# スタジアムの反応(場に出た・エネルギーをつけた・入れ替わった・進化した・にげたとき)
# ---------------------------------------------------------------------------------------------
def _place_counters(state, mon, n: int, label: str) -> None:
    from effects.primitives import _blocks_damage_counters

    if mon is not None and not _blocks_damage_counters(mon):
        mon.damage += n * 10
        state.add_log(f"{label}の効果で、ダメカンを{n}個のせた")


def on_basic_benched_from_hand(state, card_db, actor: int, mon) -> None:
    """アギトの沼地: 手札からたねポケモンをベンチに出したら、そのポケモンにダメカンをのせる(おたがい)。"""
    for _k, p in reactions(state.stadium_in_play, "react_bench_counters"):
        _place_counters(state, mon, p["n"], _name(card_db, state.stadium_in_play))


def on_energy_attached_from_hand(state, card_db, actor: int, target) -> None:
    """ふるびた墓地/ふぶきの山: 手札からエネルギーをつけたポケモン(条件に合うもの)にダメカンをのせる(おたがい)。
    相手の特性「Whenever your opponent attaches an Energy card from their hand ..., put N damage counters」(cond_attach_counters)もここで処理する。"""
    from effects.passives_cond import cond_sources, holder_ok, match

    for holder, params in cond_sources(state, card_db, 1 - actor, "cond_attach_counters"):
        if holder_ok(state, card_db, 1 - actor, holder, params.get("when")):
            _place_counters(state, target, params["n"], _name(card_db, holder.card_id))
    for _k, p in reactions(state.stadium_in_play, "react_attach_counters"):
        if match(state, card_db, target, p.get("target"), actor):
            _place_counters(state, target, p["n"], _name(card_db, state.stadium_in_play))


def on_active_moved_to_bench(state, card_db, actor: int, old_active) -> None:
    """スパイクタウン: 自分の番に、バトルポケモンがベンチに下がったら、そのポケモンにダメカンをのせる(にげる/入れ替え)。"""
    if actor != state.current_player:
        return
    for _k, p in reactions(state.stadium_in_play, "react_active_to_bench_counters"):
        _place_counters(state, old_active, p["n"], _name(card_db, state.stadium_in_play))


def on_evolved_from_hand(state, card_db, evolved) -> None:
    """ウィンドスタジアム: 手札のポケモンVMAXでポケモンVを進化させたら、そのポケモンのダメージを回復する(おたがい)。"""
    for _k, p in reactions(state.stadium_in_play, "react_vmax_evolve_heal"):
        card = card_db.get(evolved.card_id)
        prev = card_db.get(evolved.evolution_history[-1]) if evolved.evolution_history else None
        if card is not None and prev is not None and "VMAX" in card.subtypes and "V" in prev.subtypes:
            evolved.heal(p["n"])
            state.add_log(f"{_name(card_db, state.stadium_in_play)}の効果で、進化したポケモンのダメージを{p['n']}回復した")


def retreat_discards_to_hand(state, card_db, tool, energy_id: str) -> bool:
    """にげるために捨てるエネルギーが、トラッシュではなく手札に入るか(ダッシュポーチ/スケーターズパーク)。"""
    from effects.era_sm_hooks import DASHING_POUCH_IDS
    from engine.continuous import tools_disabled

    if tool in DASHING_POUCH_IDS and not tools_disabled(state.stadium_in_play):
        return True
    if has_reaction(state.stadium_in_play, "react_retreat_energy_to_hand"):
        c = card_db.get(energy_id)
        return c is not None and c.is_energy and not c.is_special_energy
    return False


# ---------------------------------------------------------------------------------------------
# スタジアムの「各プレイヤーの番に1回」の効果(STADIUM_ABILITY_EFFECTS)
# ---------------------------------------------------------------------------------------------
def _hand_pred(card, kind: str) -> bool:
    if card is None:
        return False
    if kind == "basic_energy":
        return card.is_energy and not card.is_special_energy
    if kind.startswith("basic_energy:"):
        return card.is_energy and not card.is_special_energy and card.basic_energy_type == kind.split(":", 1)[1]
    if kind.startswith("subtype:"):
        return kind.split(":", 1)[1] in card.subtypes
    return False


@dataclass(frozen=True)
class DiscardFromHandThen(Effect):
    """手札から、条件(kind)に合うカードを1枚トラッシュして(コスト)、thenを実行する(サイクリングロード/ムーンライトヒル/ダークタワー)。"""

    kind: str = "basic_energy"
    then: tuple = ()

    def execute(self, ctx: EffectContext) -> None:
        from effects.primitives import _attacker_player, _trigger_search_choice

        player = _attacker_player(ctx)
        _trigger_search_choice(
            ctx, player, "hand", lambda c: _hand_pred(c, self.kind), 1, "トラッシュするカードを選ぶ",
            shuffle_after=False, destination="discard", min_count=1,
        )
        pending = ctx.state.pending_search_choice
        if pending is not None:
            pending.remaining_script = tuple(self.then)
            pending.cont_source_pokemon = ctx.source_pokemon
            pending.cont_source_card_id = ctx.source_card_id
            pending.effect_source = ctx.effect_source


@dataclass(frozen=True)
class LookTopMayDiscardEffect(Effect):
    """自分の山札の上を1枚見て、トラッシュしてもよい(ふるびた祭壇)。"""

    def execute(self, ctx: EffectContext) -> None:
        player = ctx.state.player(ctx.acting_player)
        if not player.deck:
            return
        top = player.deck[0]
        label = _name(ctx.card_db, top)
        ctx.state.pending_search_choice = PendingSearchChoice(
            player_index=ctx.acting_player, zone="gen_pokemon_pick", source_indices=[0], card_ids=[label], min_count=0, max_count=1,
            prompt="山札の一番上のカードを見た。トラッシュするなら選ぶ(選ばなければ山札の上に残る)", shuffle_after=False, all_card_ids=[label],
            custom_data={"op": "j_altar_discard"}, effect_source=ctx.effect_source, cont_acting_player=ctx.acting_player,
        )


def _op_altar_discard(state, card_db, choice, selected, action, ctx, custom) -> bool:
    player = state.player(choice.player_index)
    if selected and player.deck:
        player.discard.append(player.deck.pop(0))
        state.add_log("山札の一番上のカードをトラッシュした")
    return False


@dataclass(frozen=True)
class MagmaBasinEffect(Effect):
    """トラッシュの炎エネルギーを1枚、ベンチの炎ポケモン1匹につける。そうしたら、そのポケモンにダメカンを2個のせる(マグマだまり)。"""

    def _targets(self, player, card_db):
        return [(i, m) for i, m in enumerate(player.bench) if (c := card_db.get(m.card_id)) is not None and "Fire" in c.types]

    def execute(self, ctx: EffectContext) -> None:
        player = ctx.state.player(ctx.acting_player)
        targets = self._targets(player, ctx.card_db)
        if not targets or not any((c := ctx.card_db.get(cid)) is not None and c.basic_energy_type == "Fire" for cid in player.discard):
            return
        labels = [_name(ctx.card_db, m.card_id) for _i, m in targets]
        ctx.state.pending_search_choice = PendingSearchChoice(
            player_index=ctx.acting_player, zone="gen_pokemon_pick", source_indices=[i for i, _m in targets], card_ids=labels, min_count=1, max_count=1,
            prompt="トラッシュの炎エネルギーをつける、ベンチの炎ポケモンを選ぶ", shuffle_after=False, all_card_ids=labels,
            custom_data={"op": "j_magma_basin"}, effect_source=ctx.effect_source, cont_acting_player=ctx.acting_player,
        )


def _op_magma_basin(state, card_db, choice, selected, action, ctx, custom) -> bool:
    player = state.player(choice.player_index)
    if not selected:
        return False
    slot = choice.source_indices[selected[0]]
    idx = next((i for i, cid in enumerate(player.discard) if (c := card_db.get(cid)) is not None and c.basic_energy_type == "Fire"), None)
    if idx is None or slot >= len(player.bench):
        return False
    target = player.bench[slot]
    target.attached_energy.append(player.discard.pop(idx))
    _place_counters(state, target, 2, "マグマだまり")
    return False


def _hand_has(card_db, player, kind: str) -> bool:
    return any(_hand_pred(card_db.get(cid), kind) for cid in player.hand)


def _any_damaged(player) -> bool:
    return any(m.damage > 0 for m in player.all_pokemon_in_play())


def _deck_has(card_db, player, spec: str) -> bool:
    from effects.era_attacks_i import card_matches

    return any(card_matches(card_db.get(cid), spec) for cid in player.deck)


def _bench_room(state, player, card_db) -> bool:
    from engine.continuous import effective_bench_limit

    return len(player.bench) < effective_bench_limit(state, player, card_db)


STADIUM_GATES: dict = {}


def stadium_gate(state, player, card_db):
    """この効果を今使えるか(effects.era_trainers.stadium_ability_playableから呼ぶ)。登録がなければNone。"""
    gate = STADIUM_GATES.get(state.stadium_in_play)
    return None if gate is None else bool(gate(state, player, card_db))


_installed_stadiums = False


def install_stadiums() -> None:
    global _installed_stadiums
    if _installed_stadiums:
        return
    _installed_stadiums = True
    from effects import registry as R
    from effects.era_attacks_i import SearchByCriterionToBench
    from effects.era_primitives_b import GENERIC_OP_HANDLERS
    from effects.era_trainers_j import ReturnChosenOwnToolToHand
    from effects.generated_era_trainer_ids import IDS
    from effects.primitives import Draw, DrawUpTo, EndTurnAfterThisAbility, HealAllOwnPokemon, SearchDeckByCriterionToHand, ShuffleHandIntoDeckThenDraw

    GENERIC_OP_HANDLERS.update({"j_altar_discard": _op_altar_discard, "j_magma_basin": _op_magma_basin})

    def ids(key):
        return tuple(cid for cid, _tag in IDS.get(key, ()))

    def reg(key, script, gate):
        for cid in ids(key):
            R.STADIUM_ABILITY_EFFECTS.setdefault(cid, script)
            STADIUM_GATES[cid] = gate

    reg("j_st_cycling_road", (DiscardFromHandThen("basic_energy", then=(Draw(1),)),), lambda s, p, db: _hand_has(db, p, "basic_energy"))
    reg("j_st_moonlit_hill", (DiscardFromHandThen("basic_energy:Psychic", then=(HealAllOwnPokemon(amount=30),)),), lambda s, p, db: _hand_has(db, p, "basic_energy:Psychic") and _any_damaged(p))
    reg("j_st_community_center", (HealAllOwnPokemon(amount=10),), lambda s, p, db: bool(p.supporter_names_this_turn) and _any_damaged(p))
    reg("j_st_jubilife_village", (ShuffleHandIntoDeckThenDraw(5), EndTurnAfterThisAbility()), lambda s, p, db: True)
    reg("j_st_primordial_altar", (LookTopMayDiscardEffect(),), lambda s, p, db: bool(p.deck))
    reg("j_st_rose_tower", (DrawUpTo(3),), lambda s, p, db: len(p.hand) < 3 and bool(p.deck))
    reg("j_st_shopping_center", (ReturnChosenOwnToolToHand(),), lambda s, p, db: any(m.attached_tool for m in p.all_pokemon_in_play()))
    reg("j_st_stormy_mountains", (SearchByCriterionToBench("cardspec:basic|type:Lightning,Dragon", 1),), lambda s, p, db: _bench_room(s, p, db) and _deck_has(db, p, "basic|type:Lightning,Dragon"))
    reg("j_st_tower_of_darkness", (DiscardFromHandThen("subtype:Single Strike", then=(Draw(2),)),), lambda s, p, db: _hand_has(db, p, "subtype:Single Strike") and bool(p.deck))
    reg("j_st_turffield", (SearchDeckByCriterionToHand("cardspec:evolution|type:Grass", count=1),), lambda s, p, db: _deck_has(db, p, "evolution|type:Grass"))
    reg("j_st_magma_basin", (MagmaBasinEffect(),), lambda s, p, db: bool(MagmaBasinEffect()._targets(p, db)) and any((c := db.get(cid)) is not None and c.basic_energy_type == "Fire" for cid in p.discard))


# ---------------------------------------------------------------------------------------------
# 4枚同時使用のグッズ(ミッシングクローバー/カルテットストーン)
# ---------------------------------------------------------------------------------------------
@dataclass(frozen=True)
class LookOwnTopCardEffect(Effect):
    """自分の山札の一番上のカードを見る(ミッシングクローバー1枚使用)。見るだけで山札は変わらない。"""

    def execute(self, ctx: EffectContext) -> None:
        player = ctx.state.player(ctx.acting_player)
        if player.deck:
            ctx.log(f"自分の山札の一番上は {_name(ctx.card_db, player.deck[0])}")


@dataclass(frozen=True)
class TakeOwnPrizesEffect(Effect):
    """自分のサイドを、自分で選んでcount枚取る(残りがcount枚以下なら全部)。ミッシングクローバー4枚使用。"""

    count: int = 1

    def execute(self, ctx: EffectContext) -> None:
        from engine.win_conditions import _take_prizes, check_win_conditions

        player = ctx.state.player(ctx.acting_player)
        n = min(self.count, len(player.prizes))
        if n <= 0:
            return
        if _take_prizes(player, n):
            ctx.log(f"サイドを{n}枚取った")
            check_win_conditions(ctx.state)
            return
        from engine.rules_engine import _start_prize_choice

        _start_prize_choice(ctx.state, [(ctx.acting_player, n)], [], "continue")


_installed_quads = False


def install_quads() -> None:
    global _installed_quads
    if _installed_quads:
        return
    _installed_quads = True
    from effects import registry as R
    from effects.generated_era_trainer_ids import IDS
    from effects.primitives import HealAllOwnPokemon

    DRAW_OFFER_ITEM_IDS.update(cid for cid, _tag in IDS.get("j_nugget", ()))
    for cid, _tag in IDS.get("j_missing_clover", ()):
        R.TRAINER_QUAD_EFFECTS[cid] = (TakeOwnPrizesEffect(1),)
    for cid, _tag in IDS.get("j_quad_stone", ()):
        R.TRAINER_QUAD_EFFECTS[cid] = (HealAllOwnPokemon(),)


def attach_allowed(state, card_db, tool_id: str, mon) -> bool:
    """どうぐをmonにつけてよいか(ヒーローのメダル: 残りHPが一定以下のポケモンVMAXにはつけられない)。"""
    for kind, p in reactions(tool_id, "react_attach_restriction"):
        card = card_db.get(mon.card_id)
        if card is None or "VMAX" not in card.subtypes or state is None:
            continue
        from engine.continuous import effective_max_hp

        remaining = effective_max_hp(card_db, mon.card_id, mon.attached_tool, state.stadium_in_play, mon.attached_energy) - mon.damage
        if remaining <= p["vmax_remaining_over"]:
            return False
    return True


# ---------------------------------------------------------------------------------------------
# 特殊エネルギーの反応(SWSH/SV): ホラーエネルギー/ラッキーエネルギー/ギフトエネルギー/リジェネエネルギー/メディカルエネルギー/スピードエネルギー
# ---------------------------------------------------------------------------------------------
def on_active_damaged_energy(ctx, defender, defender_owner, dmg: int) -> None:
    """バトル場でワザのダメージを受けたとき(きぜつしても)の、ついている特殊エネルギーの効果。どうぐ無効の影響は受けない。"""
    from effects.primitives import _blocks_damage_counters

    attacker = ctx.source_pokemon
    if attacker is None:
        return
    state, card_db = ctx.state, ctx.card_db
    for eid, kind, p in energy_reactions(defender, "react_damaged"):
        if not _when_ok(state, card_db, ctx.opponent, defender, p.get("when")):
            continue
        if kind == "react_damaged_counters" and not _blocks_damage_counters(attacker):
            attacker.damage += p["n"] * 10
            ctx.log(f"{_name(card_db, eid)}の効果で、攻撃したポケモンにダメカンを{p['n']}個のせた")
        elif kind == "react_damaged_draw":
            for _ in range(p["n"]):
                if defender_owner.deck:
                    defender_owner.hand.append(defender_owner.deck.pop(0))
            ctx.log(f"{_name(card_db, eid)}の効果で、{p['n']}枚引いた")


def collect_ko_followups_energy(state, card_db, owner_index: int, pokemon, was_active: bool) -> None:
    """ワザのダメージできぜつしたポケモンについていた特殊エネルギーの効果(ギフトエネルギー: 手札が7枚になるまで引く)。"""
    owner = state.player(owner_index)
    for eid, kind, p in energy_reactions(pokemon, "react_ko"):
        if not _when_ok(state, card_db, owner_index, pokemon, p.get("when"), was_active=was_active):
            continue
        if kind == "react_ko_draw_to":
            while len(owner.hand) < p["n"] and owner.deck:
                owner.hand.append(owner.deck.pop(0))
            state.add_log(f"{_name(card_db, eid)}の効果で、手札が{len(owner.hand)}枚になるまで山札を引いた")


def on_special_energy_attached_from_hand(state, card_db, actor: int, target) -> None:
    """手札から特殊エネルギーをつけたとき: メディカルエネルギー(回復)/スピードエネルギー(ドロー)/オーロラエネルギー(手札を1枚トラッシュ)。"""
    if not target.attached_energy:
        return
    from effects.era_energy_j import attach_needs_other_hand_card
    from engine.energy import special_energy_effects_suppressed

    eid = target.attached_energy[-1]
    if special_energy_effects_suppressed():
        return
    player = state.player(actor)
    for kind, p in TOOL_REACTIONS.get(eid, ()):
        if kind == "react_attach_heal":
            target.heal(p["n"])
            state.add_log(f"{_name(card_db, eid)}の効果で、ダメージを{p['n']}回復した")
        elif kind == "react_attach_draw" and _when_ok(state, card_db, actor, target, p.get("when")):
            for _ in range(p["n"]):
                if player.deck:
                    player.hand.append(player.deck.pop(0))
            state.add_log(f"{_name(card_db, eid)}の効果で、{p['n']}枚引いた")
    if attach_needs_other_hand_card(card_db, eid) and player.hand and state.pending_search_choice is None:
        labels = [_name(card_db, c) for c in player.hand]
        state.pending_search_choice = PendingSearchChoice(
            player_index=actor, zone="hand", source_indices=list(range(len(player.hand))), card_ids=list(player.hand), min_count=1, max_count=1,
            prompt=f"{_name(card_db, eid)}をつけるために、手札のほかのカードを1枚トラッシュする", shuffle_after=False, all_card_ids=list(player.hand), destination="discard",
        )
        _ = labels


def on_evolved_from_hand_energy(state, card_db, evolved) -> None:
    """リジェネエネルギー: ついているポケモンVを手札から進化させたら、そのポケモンのダメージを回復する。"""
    prev = card_db.get(evolved.evolution_history[-1]) if evolved.evolution_history else None
    if prev is None:
        return
    for eid, _k, p in [(e, k, p) for e, k, p in energy_reactions(evolved, "react_evolve")]:
        if _k == "react_evolve_heal" and p.get("from_subtype") in prev.subtypes:
            evolved.heal(p["n"])
            state.add_log(f"{_name(card_db, eid)}の効果で、進化したポケモンのダメージを{p['n']}回復した")


# ---------------------------------------------------------------------------------------------
# 番のはじめに山札から引いたとき、手札に加える前に使える/出せるカード(ナゲット/トップエントリー)
# ---------------------------------------------------------------------------------------------
TOP_ENTRY_ABILITY_IDS = ("swsh45-32", "swsh2-8", "swsh2-32", "swsh2-61")  # ルクシオ/ハスボー…(「Top Entry」: 引いたとき、ベンチが空いていればベンチに出してもよい)
DRAW_OFFER_ITEM_IDS: set = set()  # ナゲット(引いたとき、手札に加える前に使える: 3枚引く)。install_quadsが登録する


def offer_on_draw(state, card_db, player_index: int, card_id: str) -> bool:
    """番のはじめに引いたcard_idが「引いたとき使える/出せる」カードなら、手札に加えずに使うかどうかを選ばせる(Trueを返す)。"""
    card = card_db.get(card_id)
    if card is None or state.pending_search_choice is not None:
        return False
    player = state.player(player_index)
    kind = None
    if card_id in DRAW_OFFER_ITEM_IDS:
        kind = "nugget"
    elif card.is_pokemon and any(a.name == "Top Entry" for a in card.abilities):
        from engine.continuous import ability_suppressed, effective_bench_limit

        if len(player.bench) < effective_bench_limit(state, player, card_db):
            kind = "top_entry"
    if kind is None:
        return False
    labels = ["使う" if kind == "nugget" else "ベンチに出す", "手札に加える"]
    state.pending_search_choice = PendingSearchChoice(
        player_index=player_index, zone="gen_pokemon_pick", source_indices=[0, 1], card_ids=labels, min_count=1, max_count=1,
        prompt=f"番のはじめに引いた{_name(card_db, card_id)}を、手札に加える前に使う/ベンチに出すか選ぶ", shuffle_after=False, all_card_ids=labels,
        custom_data={"op": "k_draw_offer", "card_id": card_id, "kind": kind}, cont_acting_player=player_index, cont_source_card_id=card_id,
    )
    return True


def _op_draw_offer(state, card_db, choice, selected, action, ctx, custom) -> bool:
    from effects.primitives import Draw
    from engine.state import PokemonInPlay

    player = state.player(choice.player_index)
    card_id = custom["card_id"]
    use = bool(selected) and choice.source_indices[selected[0]] == 0
    if not use:
        player.hand.append(card_id)
        return False
    if custom["kind"] == "nugget":
        player.discard.append(card_id)
        state.add_log(f"{_name(card_db, card_id)}を使った")
        Draw(3).execute(ctx)
    else:
        player.bench.append(PokemonInPlay(card_id=card_id, turn_played=player.turns_taken))
        state.add_log(f"{_name(card_db, card_id)}を山札から引いて、ベンチに出した")
    return False


register_ops()
