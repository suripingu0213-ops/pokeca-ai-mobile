"""時代ごとのカード取り込み(2026-10-06〜)で追加した効果プリミティブその3(単純〜中程度の個別効果)。

effects/era_primitives.py / era_primitives_b.py と同じ規約。ダメージを与えるものは必ずDealDamageを1回だけ経由する。
"""

from __future__ import annotations

from dataclasses import dataclass

from effects.context import EffectContext
from effects.primitives import (
    DealDamage,
    Effect,
    _attacker_player,
    _defender,
    _defender_is_shielded,
    _trigger_search_choice,
    resolve_attack_damage,
)
from engine.state import PendingSearchChoice


def _basic_energy_type_of(card_db, card_id: str) -> str | None:
    card = card_db.get(card_id)
    return card.basic_energy_type if card is not None else None


# ---------------------------------------------------------------------------------------------
# 山札・トラッシュ・手札
# ---------------------------------------------------------------------------------------------
@dataclass(frozen=True)
class PutDiscardCardOnTopOfDeck(Effect):
    """トラッシュのカード1枚を選んで、山札の一番上に置く(Garbage Collection/Pull Out/Recycle)。criterionを指定すると、その条件(SearchDeckMultiCriteriaの条件名。例: "supporter")のカードだけ選べる。"""

    criterion: str = "any"

    def execute(self, ctx: EffectContext) -> None:
        from effects.primitives import SearchDeckMultiCriteria

        player = _attacker_player(ctx)
        indices = [
            i for i, cid in enumerate(player.discard)
            if self.criterion == "any" or ((c := ctx.card_db.get(cid)) is not None and SearchDeckMultiCriteria._matches(c, self.criterion))
        ]
        if not indices:
            return
        ctx.state.pending_search_choice = PendingSearchChoice(
            player_index=ctx.acting_player,
            zone="discard",
            source_indices=indices,
            card_ids=[player.discard[i] for i in indices],
            min_count=1,
            max_count=1,
            prompt="山札の一番上に置くカードをトラッシュから選ぶ",
            shuffle_after=False,
            all_card_ids=list(player.discard),
            destination="deck_top_no_shuffle",
        )


@dataclass(frozen=True)
class DiscardOpponentDeckPerOwnNamedInPlay(Effect):
    """自分の場にいる指定名のポケモン1匹につき、相手の山札の上を1枚トラッシュする(Devour)。"""

    name: str

    def execute(self, ctx: EffectContext) -> None:
        player = _attacker_player(ctx)
        n = sum(1 for m in player.all_pokemon_in_play() if (c := ctx.card_db.get(m.card_id)) is not None and c.name == self.name)
        opponent = ctx.state.player(ctx.opponent)
        for _ in range(n):
            if not opponent.deck:
                break
            opponent.discard.append(opponent.deck.pop(0))


@dataclass(frozen=True)
class DiscardOpponentDeckPerSelfEnergy(Effect):
    """このポケモンについている指定のエネルギー1枚につき、相手の山札の上を1枚トラッシュする(Jet Woofer/Fast Forward)。
    energy_type: 基本エネルギーのタイプ。energy_name: カード名(特殊エネルギー)。"""

    energy_type: str | None = None
    energy_name: str | None = None

    def execute(self, ctx: EffectContext) -> None:
        if ctx.source_pokemon is None:
            return
        n = 0
        for e in ctx.source_pokemon.attached_energy:
            c = ctx.card_db.get(e)
            if c is None:
                continue
            if self.energy_type is not None and c.basic_energy_type == self.energy_type:
                n += 1
            elif self.energy_name is not None and c.name == self.energy_name:
                n += 1
        opponent = ctx.state.player(ctx.opponent)
        for _ in range(n):
            if not opponent.deck:
                break
            opponent.discard.append(opponent.deck.pop(0))


@dataclass(frozen=True)
class DiscardOpponentTopBonusIfTrainer(Effect):
    """相手の山札の上を1枚トラッシュし、それがトレーナーズならbase+bonus、そうでなければbaseのダメージ(Disaster Wing)。"""

    base: int
    bonus: int

    def execute(self, ctx: EffectContext) -> None:
        opponent = ctx.state.player(ctx.opponent)
        extra = 0
        if opponent.deck:
            card_id = opponent.deck.pop(0)
            opponent.discard.append(card_id)
            card = ctx.card_db.get(card_id)
            ctx.log(f"相手の山札の上の{card_id}をトラッシュした")
            if card is not None and card.is_trainer:
                extra = self.bonus
        DealDamage(self.base + extra).execute(ctx)


@dataclass(frozen=True)
class RevealTopNBonusPerEnergyType(Effect):
    """自分の山札の上からn枚を公開し、その中の指定タイプの基本エネルギー1枚につきper追加ダメージ。公開したカードは山札に戻して
    シャッフルする(Mud Flood)。"""

    n: int
    base: int
    per: int
    energy_type: str

    def execute(self, ctx: EffectContext) -> None:
        player = _attacker_player(ctx)
        top = list(player.deck[: self.n])
        ctx.reveal("山札の上を公開", top)
        count = sum(1 for cid in top if _basic_energy_type_of(ctx.card_db, cid) == self.energy_type)
        ctx.rng.shuffle(player.deck)
        DealDamage(self.base + self.per * count).execute(ctx)


@dataclass(frozen=True)
class OptionalDiscardTopBonusIfEnergyType(Effect):
    """「自分の山札の上を1枚トラッシュしてもよい。それが指定タイプのエネルギーなら追加ダメージ」(Magma Mantle)。
    使うかどうかはワザ選択時(Attack(i)=使わない/Attack(i, 0)=使う)に決める。"""

    base: int
    bonus: int
    energy_type: str
    optional_variant = True

    def execute(self, ctx: EffectContext) -> None:
        player = _attacker_player(ctx)
        extra = 0
        if ctx.target_bench_index == 0 and player.deck:
            card_id = player.deck.pop(0)
            player.discard.append(card_id)
            ctx.log(f"山札の上の{card_id}をトラッシュした")
            c = ctx.card_db.get(card_id)
            if c is not None and c.is_energy and c.basic_energy_type == self.energy_type:
                extra = self.bonus
        DealDamage(self.base + extra).execute(ctx)


@dataclass(frozen=True)
class OptionalDiscardTopBothDecksBonusPerEnergy(Effect):
    """「おたがいの山札の上をn枚ずつトラッシュしてもよい。そうしたら、トラッシュしたエネルギー1枚につきper追加ダメージ」(Magma Eruption)。"""

    base: int
    per: int
    n: int
    optional_variant = True

    def execute(self, ctx: EffectContext) -> None:
        extra = 0
        if ctx.target_bench_index == 0:
            for idx in (ctx.acting_player, ctx.opponent):
                p = ctx.state.player(idx)
                for _ in range(self.n):
                    if not p.deck:
                        break
                    cid = p.deck.pop(0)
                    p.discard.append(cid)
                    c = ctx.card_db.get(cid)
                    if c is not None and c.is_energy:
                        extra += self.per
        DealDamage(self.base + extra).execute(ctx)


@dataclass(frozen=True)
class OptionalFlipForBonusOrNothing(Effect):
    """「ダメージを与える前に、コインを投げてもよい。オモテなら追加ダメージ。ウラならこのワザは何もしない」(Quick Tail Smash)。"""

    base: int
    bonus: int
    optional_variant = True

    def execute(self, ctx: EffectContext) -> None:
        if ctx.target_bench_index != 0:
            DealDamage(self.base).execute(ctx)
            return
        heads = ctx.rng.random() < 0.5
        ctx.last_coin_result = heads
        ctx.log("コイン: オモテ" if heads else "コイン: ウラ")
        if heads:
            DealDamage(self.base + self.bonus).execute(ctx)
        else:
            ctx.log("ウラなので、このワザは何もしなかった")


@dataclass(frozen=True)
class DiscardAnyHandCardsScalingDamage(Effect):
    """手札の指定した種類のカード(criteria: "tool"|"pokemon")を好きな枚数トラッシュし、トラッシュした枚数×perダメージ
    (Chuck/Vilify)。"""

    criteria: str
    per: int

    def execute(self, ctx: EffectContext) -> None:
        player = _attacker_player(ctx)

        def matches(card):
            if card is None:
                return False
            return card.is_pokemon_tool if self.criteria == "tool" else card.is_pokemon

        eligible = [i for i, cid in enumerate(player.hand) if matches(ctx.card_db.get(cid))]
        if not eligible:
            DealDamage(0).execute(ctx)
            return
        ctx.state.pending_search_choice = PendingSearchChoice(
            player_index=ctx.acting_player,
            zone="hand",
            source_indices=eligible,
            card_ids=[player.hand[i] for i in eligible],
            min_count=0,
            max_count=len(eligible),
            prompt="トラッシュする手札のカードを好きな枚数選ぶ(選ばなくてもよい)",
            shuffle_after=False,
            all_card_ids=[player.hand[i] for i in eligible],
            destination="discard",
            cont_source_pokemon=ctx.source_pokemon,
            cont_source_card_id=ctx.source_card_id,
            custom_data={"mode": "discard_hand_energy_scaling_damage", "base": 0, "damage_per": self.per},
        )


@dataclass(frozen=True)
class DiscardAnyOwnBoardEnergyScalingDamage(Effect):
    """自分のポケモン(self_only=Trueならこのポケモンだけ)についているエネルギー(energy_type指定時はそのタイプの基本エネルギーだけ)を
    好きな枚数選んでトラッシュし、base + トラッシュした枚数×perダメージ(Crush and Burn/Savage Wing)。"""

    per: int
    base: int = 0
    self_only: bool = False
    energy_type: str | None = None

    def execute(self, ctx: EffectContext) -> None:
        player = _attacker_player(ctx)
        entries = []
        ids = []
        slots = ([(0, player.active)] if player.active is not None else []) + [(i + 1, m) for i, m in enumerate(player.bench)]
        for slot, mon in slots:
            if self.self_only and mon is not ctx.source_pokemon:
                continue
            for ei, e in enumerate(mon.attached_energy):
                if self.energy_type is not None and _basic_energy_type_of(ctx.card_db, e) != self.energy_type:
                    continue
                entries.append((slot, ei))
                ids.append(e)
        if not entries:
            DealDamage(self.base).execute(ctx)
            return
        pending = PendingSearchChoice(
            player_index=ctx.acting_player,
            zone="gen_energy_pick",
            source_indices=list(range(len(entries))),
            card_ids=ids,
            min_count=0,
            max_count=len(entries),
            prompt="トラッシュする自分のポケモンのエネルギーを好きな枚数選ぶ(選ばなくてもよい)",
            shuffle_after=False,
            all_card_ids=list(ids),
            custom_data={"op": "discard_board_energy_damage", "entries": entries, "per": self.per, "base": self.base},
        )
        pending.cont_source_pokemon = ctx.source_pokemon
        pending.cont_source_card_id = ctx.source_card_id
        ctx.state.pending_search_choice = pending


@dataclass(frozen=True)
class DiscardTopCardAttachIfBasicEnergy(Effect):
    """自分の山札の上を1枚トラッシュし、それが基本エネルギーなら自分のポケモン1匹につける(Dig Out)。
    つける先は、トラッシュしたカードを見てから選ぶ。"""

    def execute(self, ctx: EffectContext) -> None:
        player = _attacker_player(ctx)
        if not player.deck:
            return
        card_id = player.deck.pop(0)
        card = ctx.card_db.get(card_id)
        ctx.log(f"山札の上の{card_id}をトラッシュ")
        if card is None or not card.is_energy or card.is_special_energy:
            player.discard.append(card_id)
            return
        slots = ([(0, player.active)] if player.active is not None else []) + [(i + 1, m) for i, m in enumerate(player.bench)]
        pending = PendingSearchChoice(
            player_index=ctx.acting_player,
            zone="gen_pokemon_pick",
            source_indices=[s for s, _ in slots],
            card_ids=[m.card_id for _, m in slots],
            min_count=1,
            max_count=1,
            prompt=f"トラッシュした{card_id}をつける自分のポケモンを選ぶ",
            shuffle_after=False,
            all_card_ids=[m.card_id for _, m in slots],
            custom_data={"op": "attach_card_to_target", "card_id": card_id},
        )
        pending.cont_source_pokemon = ctx.source_pokemon
        pending.cont_source_card_id = ctx.source_card_id
        ctx.state.pending_search_choice = pending


@dataclass(frozen=True)
class DrawPerSelfEnergy(Effect):
    """このポケモンについている指定タイプのエネルギー1枚につき1枚引く(Tiptoe Step)。"""

    energy_type: str

    def execute(self, ctx: EffectContext) -> None:
        from effects.primitives import Draw

        if ctx.source_pokemon is None:
            return
        n = sum(1 for e in ctx.source_pokemon.attached_energy if _basic_energy_type_of(ctx.card_db, e) == self.energy_type)
        if n > 0:
            Draw(n).execute(ctx)


@dataclass(frozen=True)
class SearchDeckForNamedCardToHand(Effect):
    """山札から指定名のカードを最大count枚探して手札に加える(Signs of Evolution/Strong Bond等)。"""

    name: str
    count: int = 1

    def execute(self, ctx: EffectContext) -> None:
        player = _attacker_player(ctx)
        _trigger_search_choice(
            ctx, player, "deck", lambda c: c is not None and c.name == self.name, self.count, f"山札から{self.name}を探す"
        )


@dataclass(frozen=True)
class SearchDeckForResistanceToHand(Effect):
    """山札から、指定タイプの抵抗力を持つポケモンを最大count枚探して手札に加える(Chirp)。"""

    resist_type: str
    count: int

    def execute(self, ctx: EffectContext) -> None:
        player = _attacker_player(ctx)

        def matches(card):
            return card is not None and card.is_pokemon and any(r.type == self.resist_type for r in card.resistances)

        _trigger_search_choice(ctx, player, "deck", matches, self.count, f"{self.resist_type}に抵抗力を持つポケモンを探す")


@dataclass(frozen=True)
class SearchDiscardForItemNameContainsToHand(Effect):
    """トラッシュから、名前に指定の語を含むグッズを最大count枚、手札に加える(Fossil Hunt)。"""

    name_part: str
    count: int

    def execute(self, ctx: EffectContext) -> None:
        player = _attacker_player(ctx)
        _trigger_search_choice(
            ctx, player, "discard",
            lambda c: c is not None and c.is_item and self.name_part in c.name, self.count,
            f"トラッシュから名前に{self.name_part}を含むグッズを探す", shuffle_after=False,
        )


@dataclass(frozen=True)
class SearchDiscardForTeamPlasmaCategoryToHand(Effect):
    """トラッシュから「プラズマ団」のカード(category: "pokemon"|"trainer"|"energy")を1枚、手札に加える(Transfer Junk。
    3種類を順に1枚ずつ選ぶスクリプトとして並べて使う)。"""

    category: str

    def execute(self, ctx: EffectContext) -> None:
        player = _attacker_player(ctx)

        def matches(card):
            if card is None or "Team Plasma" not in card.subtypes and "Plasma" not in card.name:
                return False
            if self.category == "pokemon":
                return card.is_pokemon
            if self.category == "trainer":
                return card.is_trainer
            return card.is_energy

        _trigger_search_choice(
            ctx, player, "discard", matches, 1, f"トラッシュからプラズマ団の{self.category}を探す", shuffle_after=False
        )


@dataclass(frozen=True)
class RevealTopNTakeTeamPlasmaDiscardRest(Effect):
    """自分の山札の上からn枚を公開し、その中のプラズマ団のカードを全て手札に加え、残りをトラッシュする(Solar Transporter)。"""

    n: int

    def execute(self, ctx: EffectContext) -> None:
        player = _attacker_player(ctx)
        top = player.deck[: self.n]
        player.deck = player.deck[self.n :]
        ctx.reveal("山札の上を公開", list(top))
        for cid in top:
            card = ctx.card_db.get(cid)
            if card is not None and ("Team Plasma" in card.subtypes or card.name == "Plasma Energy"):
                player.hand.append(cid)
            else:
                player.discard.append(cid)


@dataclass(frozen=True)
class MayDiscardTeamPlasmaCardFromHandThenDraw(Effect):
    """手札のプラズマ団のカードを1枚トラッシュする。そうしたらcount枚引く(Cargo Jet)。トラッシュするカードは選ぶ。"""

    draw_count: int

    def execute(self, ctx: EffectContext) -> None:
        from effects.primitives import Draw

        player = _attacker_player(ctx)

        def matches(card):
            return card is not None and ("Team Plasma" in card.subtypes or card.name == "Plasma Energy")

        _trigger_search_choice(
            ctx, player, "hand", matches, 1, "トラッシュするプラズマ団のカードを選ぶ", shuffle_after=False,
            destination="discard", min_count=0,
        )
        pending = ctx.state.pending_search_choice
        if pending is not None:
            pending.allowed_counts = (0, 1)
            pending.custom_data = {"mode": "draw_if_discarded", "draw": self.draw_count}
            pending.remaining_script = (_DrawIfPickedAny(self.draw_count),)
            pending.cont_source_pokemon = ctx.source_pokemon
            pending.cont_source_card_id = ctx.source_card_id


@dataclass(frozen=True)
class _DrawIfPickedAny(Effect):
    count: int

    def execute(self, ctx: EffectContext) -> None:
        from effects.primitives import Draw

        if ctx.last_picked_card_ids:
            Draw(self.count).execute(ctx)


@dataclass(frozen=True)
class SearchDeckForSubtypePokemonToBenchPerEnergy(Effect):
    """このポケモンについているエネルギー1枚につき、山札から指定サブタイプ(Stage 2)のポケモンを1匹探してベンチに出す(Lifesplosion)。"""

    subtype: str

    def execute(self, ctx: EffectContext) -> None:
        if ctx.source_pokemon is None:
            return
        n = len(ctx.source_pokemon.attached_energy)
        if n <= 0:
            return
        player = _attacker_player(ctx)
        _trigger_search_choice(
            ctx, player, "deck", lambda c: c is not None and c.is_pokemon and self.subtype in c.subtypes, n,
            f"山札から{self.subtype}のポケモンを探してベンチに出す", destination="bench",
        )


@dataclass(frozen=True)
class SearchDeckEvolutionsOfDistinctTypesToHand(Effect):
    """山札から、指定のポケモンから進化する、タイプのちがうポケモンを最大count枚探して手札に加える(Eevee: Signs of Evolution)。
    1枚ずつ選び、すでに選んだタイプは次の候補から外す。"""

    evolves_from: str
    count: int

    def execute(self, ctx: EffectContext) -> None:
        distinct_evolution_search_step(ctx, self.evolves_from, self.count, ())


def distinct_evolution_search_step(ctx: EffectContext, evolves_from: str, remaining: int, picked_types: tuple) -> None:
    player = _attacker_player(ctx)
    if remaining <= 0:
        ctx.state.rng.shuffle(player.deck)
        return

    def matches(card):
        return (
            card is not None
            and card.evolves_from == evolves_from
            and not (set(card.types) & set(picked_types))
        )

    eligible = [i for i, cid in enumerate(player.deck) if matches(ctx.card_db.get(cid))]
    if not eligible:
        ctx.state.rng.shuffle(player.deck)
        return
    pending = PendingSearchChoice(
        player_index=ctx.acting_player,
        zone="deck",
        source_indices=eligible,
        card_ids=[player.deck[i] for i in eligible],
        min_count=0,
        max_count=1,
        prompt=f"{evolves_from}から進化するポケモンを探す(あと{remaining}枚まで、タイプはすべてちがうもの)",
        shuffle_after=False,
        all_card_ids=list(player.deck),
        destination="hand",
        custom_data={
            "mode": "gen_continue", "op": "distinct_evolution_next", "evolves_from": evolves_from,
            "remaining": remaining - 1, "picked_types": list(picked_types),
        },
    )
    pending.cont_source_pokemon = ctx.source_pokemon
    pending.cont_source_card_id = ctx.source_card_id
    ctx.state.pending_search_choice = pending


# ---------------------------------------------------------------------------------------------
# ダメージ
# ---------------------------------------------------------------------------------------------
@dataclass(frozen=True)
class DamagePerOpponentHandCardsOfKind(Effect):
    """相手の手札を公開させ、指定の種類("trainer"|"energy")のカード1枚につきper(+base)ダメージ。"""

    base: int
    per: int
    kind: str

    def execute(self, ctx: EffectContext) -> None:
        opponent = ctx.state.player(ctx.opponent)
        ctx.state.player(ctx.acting_player).known_opponent_hand = list(opponent.hand)
        n = 0
        for cid in opponent.hand:
            c = ctx.card_db.get(cid)
            if c is None:
                continue
            if (self.kind == "trainer" and c.is_trainer) or (self.kind == "energy" and c.is_energy):
                n += 1
        DealDamage(self.base + self.per * n).execute(ctx)


@dataclass(frozen=True)
class DamageEachOpponentBenchedPerColorlessRetreat(Effect):
    """相手のベンチポケモン全員に、そのポケモンのにげるエネルギーの無色1個につきperダメージ(弱点・抵抗力は計算しない)(Torpedo Dive)。"""

    per: int

    def execute(self, ctx: EffectContext) -> None:
        for mon in list(ctx.state.player(ctx.opponent).bench):
            if _defender_is_shielded(ctx, mon):
                continue
            card = ctx.card_db.get(mon.card_id)
            if card is None:
                continue
            n = sum(1 for t in (card.retreat_cost or ()) if t == "Colorless") if isinstance(card.retreat_cost, (list, tuple)) else 0
            if n <= 0:
                continue
            dmg = resolve_attack_damage(ctx, mon, card, self.per * n, apply_weakness=False, apply_resistance=False)
            mon.damage += dmg
            ctx.log(f"相手のベンチ{mon.card_id}に{dmg}ダメージ")


@dataclass(frozen=True)
class DamageEqualToDamageTakenLastTurn(Effect):
    """このポケモンが相手の前の番にワザのダメージを受けていたなら、それと同じ量のダメージを相手のバトルポケモンに与える(Vengeful Wish)。"""

    def execute(self, ctx: EffectContext) -> None:
        mon = ctx.source_pokemon
        if mon is None:
            return
        if mon.last_attack_damage_turn == ctx.state.turn_number - 1 and mon.last_attack_damage_taken > 0:
            DealDamage(mon.last_attack_damage_taken).execute(ctx)
        else:
            ctx.log("前の相手の番にダメージを受けていないので、このワザは何もしなかった")


@dataclass(frozen=True)
class DamageToChosenOwnBenchMulti(Effect):
    """自分のベンチポケモンをcount匹選び、それぞれにamountダメージ(弱点・抵抗力は計算しない)(Grenade Hammer)。
    ベンチがcount匹以下なら全員。"""

    count: int
    amount: int

    def execute(self, ctx: EffectContext) -> None:
        player = _attacker_player(ctx)
        n = min(self.count, len(player.bench))
        if n <= 0:
            return
        if n == len(player.bench):
            for mon in player.bench:
                mon.damage += self.amount
            ctx.log(f"自分のベンチ全員に{self.amount}ダメージ")
            return
        pending = PendingSearchChoice(
            player_index=ctx.acting_player,
            zone="gen_pokemon_pick",
            source_indices=[i + 1 for i in range(len(player.bench))],
            card_ids=[m.card_id for m in player.bench],
            min_count=n,
            max_count=n,
            prompt=f"ダメージを受ける自分のベンチポケモンを{n}匹選ぶ",
            shuffle_after=False,
            all_card_ids=[m.card_id for m in player.bench],
            custom_data={"op": "damage_own_bench", "amount": self.amount},
        )
        pending.cont_source_pokemon = ctx.source_pokemon
        pending.cont_source_card_id = ctx.source_card_id
        ctx.state.pending_search_choice = pending


# ---------------------------------------------------------------------------------------------
# 状態・フラグ
# ---------------------------------------------------------------------------------------------
@dataclass(frozen=True)
class SetDefenderSleepFlipCount(Effect):
    """相手のバトルポケモンがねむりのとき、ポケモンチェックでコインをn枚投げる(全部オモテで回復)(Abyssal Sleep)。"""

    flip_count: int

    def execute(self, ctx: EffectContext) -> None:
        _, defender = _defender(ctx)
        if defender is not None and defender.status.exclusive.name == "ASLEEP":
            defender.status.sleep_flip_count = self.flip_count


@dataclass(frozen=True)
class OpponentCoinsAreTailsNextTurn(Effect):
    """相手の次の番、相手がコインを投げるたびウラとして扱う(Slap of Misfortune/Sinister Suggestion)。"""

    def execute(self, ctx: EffectContext) -> None:
        opponent = ctx.state.player(ctx.opponent)
        opponent.coins_tails_until_turn = opponent.turns_taken + 1


@dataclass(frozen=True)
class OpponentNoTurnDrawNextTurn(Effect):
    """相手は次の番のはじめに山札を引けない(Heart Wink)。"""

    def execute(self, ctx: EffectContext) -> None:
        opponent = ctx.state.player(ctx.opponent)
        opponent.no_turn_draw_on_turn = opponent.turns_taken + 1


@dataclass(frozen=True)
class ApplyEffectShieldToSelf(Effect):
    """相手の次の番、このポケモンはワザの効果(ダメージを除く)を受けない(Light Pulse)。"""

    def execute(self, ctx: EffectContext) -> None:
        if ctx.source_pokemon is None:
            return
        ctx.source_pokemon.effect_shield_until_turn = ctx.state.player(ctx.opponent).turns_taken + 1


@dataclass(frozen=True)
class ApplyTeamExDamageImmunity(Effect):
    """相手の次の番、自分のポケモン全員が、相手のポケモンEXから受けるダメージを受けない。このポケモンがバトル場を離れたら効果は
    終わる(Diamond Force)。"""

    def execute(self, ctx: EffectContext) -> None:
        if ctx.source_pokemon is None:
            return
        player = _attacker_player(ctx)
        player.ex_damage_immunity_until_turn = ctx.state.player(ctx.opponent).turns_taken + 1
        player.ex_damage_immunity_source = ctx.source_pokemon


@dataclass(frozen=True)
class SetSelfRetaliateEqualDamageNextTurn(Effect):
    """相手の次の番、このポケモンがワザのダメージを受けたら(きぜつしても)、攻撃したポケモンに受けたダメージと同じ数のダメカンを
    のせる(Right Back at You)。"""

    def execute(self, ctx: EffectContext) -> None:
        if ctx.source_pokemon is None:
            return
        ctx.source_pokemon.retaliate_on_damaged_until_turn = ctx.state.player(ctx.opponent).turns_taken + 1
        ctx.source_pokemon.retaliate_on_damaged_counters = 0
        ctx.source_pokemon.retaliate_equal_damage = True


@dataclass(frozen=True)
class IfAllCoinsHeads(Effect):
    """直前のコインフリップ系効果でcount枚すべてがオモテだったなら、thenを実行する(Flash Needle)。"""

    count: int
    then: tuple = ()

    def execute(self, ctx: EffectContext) -> None:
        if ctx.coin_heads_count >= self.count:
            for e in self.then:
                e.execute(ctx)


@dataclass(frozen=True)
class DiscardOpponentActiveSpecialEnergyThenShield(Effect):
    """相手のバトルポケモンの特殊エネルギーを1枚トラッシュする。そうしたら、相手の次の番、このポケモンはワザの効果(ダメージ含む)を
    受けない(Stardust)。"""

    def execute(self, ctx: EffectContext) -> None:
        opponent = ctx.state.player(ctx.opponent)
        active = opponent.active
        if active is None:
            return
        specials = [e for e in active.attached_energy if (c := ctx.card_db.get(e)) is not None and c.is_special_energy]
        if not specials:
            return
        from effects.primitives import DiscardOpponentActiveSpecialEnergy

        DiscardOpponentActiveSpecialEnergy().execute(ctx)
        if ctx.source_pokemon is not None and ctx.state.pending_search_choice is None:
            ctx.source_pokemon.shielded_until_turn = opponent.turns_taken + 1
        elif ctx.state.pending_search_choice is not None:
            ctx.state.pending_search_choice.remaining_script = ctx.state.pending_search_choice.remaining_script + (
                _ShieldSelfIfPossible(),
            )


@dataclass(frozen=True)
class _ShieldSelfIfPossible(Effect):
    def execute(self, ctx: EffectContext) -> None:
        if ctx.source_pokemon is not None:
            ctx.source_pokemon.shielded_until_turn = ctx.state.player(ctx.opponent).turns_taken + 1


@dataclass(frozen=True)
class SwitchWithChosenBenchThenNewActiveBonusNextTurn(Effect):
    """このポケモンをベンチのポケモン1匹と入れ替える。次の自分の番、入れ替わったポケモンのワザは相手のバトルポケモンに
    amount追加ダメージ(弱点・抵抗力の前)(Fluffy Tag)。入れ替える先は攻撃時に選ぶ(attack_target)。"""

    amount: int
    attack_target = "own_bench"

    def execute(self, ctx: EffectContext) -> None:
        player = _attacker_player(ctx)
        if ctx.target_bench_index is None or ctx.target_bench_index >= len(player.bench):
            return
        new_active = player.bench.pop(ctx.target_bench_index)
        if player.active is not None:
            player.active.status.clear_all()
            player.bench.append(player.active)
        new_active.status.clear_all()
        new_active.became_active_turn = player.turns_taken
        player.active = new_active
        new_active.attack_bonus_until_turn = player.turns_taken + 1
        new_active.attack_bonus_amount = self.amount
        new_active.attack_bonus_attack_name = ""


@dataclass(frozen=True)
class SwitchSelfWithChosenBenchIfAttached(Effect):
    """直前にエネルギーをつけられたなら、このポケモンをベンチのポケモン1匹と入れ替える(Energy Glide)。入れ替える先は攻撃時に選ぶ。"""

    attack_target = "own_bench"

    def execute(self, ctx: EffectContext) -> None:
        if not ctx.last_attach_succeeded:
            return
        player = _attacker_player(ctx)
        if ctx.target_bench_index is None or ctx.target_bench_index >= len(player.bench):
            return
        new_active = player.bench.pop(ctx.target_bench_index)
        if player.active is not None:
            player.active.status.clear_all()
            player.bench.append(player.active)
        new_active.status.clear_all()
        new_active.became_active_turn = player.turns_taken
        player.active = new_active


@dataclass(frozen=True)
class AttachEnergyToLastBenchedFromDiscard(Effect):
    """直前にベンチに出したポケモンに、トラッシュのエネルギーを1枚つける(Picnic Weather)。"""

    def execute(self, ctx: EffectContext) -> None:
        from effects.era_primitives_b import attach_generic_start

        player = _attacker_player(ctx)
        if not ctx.last_picked_card_ids or not player.bench:
            return
        spec = {"source": "discard", "basic_only": False, "energy_type": None, "self_only": False, "bench_only": True,
                "target_type": None, "target_subtype": None, "single_target": True, "distinct_targets": False, "optional": False}
        attach_generic_start(ctx, spec, 1, locked_slot=len(player.bench))


@dataclass(frozen=True)
class SearchDiscardForNamedPokemonToBenchThen(Effect):
    """トラッシュから指定名のポケモンを1匹ベンチに出し、そのあとthenを実行する(ctx.last_picked_card_idsに出したカード)(Picnic Weather)。"""

    name: str
    then: tuple = ()

    def execute(self, ctx: EffectContext) -> None:
        player = _attacker_player(ctx)
        from effects.primitives import _trigger_search_choice as tsc

        tsc(
            ctx, player, "discard", lambda c: c is not None and c.is_pokemon and c.name == self.name, 1,
            f"トラッシュから{self.name}をベンチに出す", shuffle_after=False, destination="bench",
        )
        pending = ctx.state.pending_search_choice
        if pending is not None:
            pending.remaining_script = tuple(self.then)
            pending.cont_source_pokemon = ctx.source_pokemon
            pending.cont_source_card_id = ctx.source_card_id


# ---------------------------------------------------------------------------------------------
# ダメカンの移動
# ---------------------------------------------------------------------------------------------
@dataclass(frozen=True)
class MoveAllDamageCountersToDefender(Effect):
    """ダメカンを全て、相手のバトルポケモンに移す。source: "self"(このポケモン)|"chosen_bench"(自分のベンチ1匹を選ぶ)(Eternal Radiance/Damagriiigus)。"""

    source: str = "self"

    def execute(self, ctx: EffectContext) -> None:
        _, defender = _defender(ctx)
        if defender is None:
            return
        player = _attacker_player(ctx)
        if self.source == "self":
            self._move(ctx, ctx.source_pokemon, defender)
            return
        candidates = [(i + 1, m) for i, m in enumerate(player.bench) if m.damage > 0]
        if not candidates:
            return
        if len(candidates) == 1:
            self._move(ctx, candidates[0][1], defender)
            return
        pending = PendingSearchChoice(
            player_index=ctx.acting_player,
            zone="gen_pokemon_pick",
            source_indices=[s for s, _ in candidates],
            card_ids=[m.card_id for _, m in candidates],
            min_count=1,
            max_count=1,
            prompt="ダメカンを全て移す自分のベンチポケモンを選ぶ",
            shuffle_after=False,
            all_card_ids=[m.card_id for _, m in candidates],
            custom_data={"op": "move_all_counters_to_defender"},
        )
        pending.cont_source_pokemon = ctx.source_pokemon
        pending.cont_source_card_id = ctx.source_card_id
        ctx.state.pending_search_choice = pending

    @staticmethod
    def _move(ctx, source, defender) -> None:
        if source is None or source.damage <= 0 or _defender_is_shielded(ctx, defender):
            return
        defender.damage += source.damage
        ctx.log(f"ダメカン{source.damage // 10}個を相手のバトルポケモンに移した")
        source.remove_counters(source.damage)


@dataclass(frozen=True)
class PutDamageCountersOnChosenOpponentEqualToSelf(Effect):
    """このポケモンについているダメカンと同じ数のダメカンを、相手のポケモン1匹にのせる(Pain Pellets)。"""

    attack_target = "opp_any"

    def execute(self, ctx: EffectContext) -> None:
        from effects.primitives import _resolve_opponent_target, _defender_blocks_effect

        if ctx.source_pokemon is None:
            return
        opponent = ctx.state.player(ctx.opponent)
        target = _resolve_opponent_target(ctx, opponent)
        if target is None or _defender_blocks_effect(ctx, target):
            return
        n = ctx.source_pokemon.damage // 10
        target.damage += n * 10
        ctx.log(f"相手のポケモンにダメカンを{n}個のせた")


@dataclass(frozen=True)
class MoveOneDamageCounterFromOwnToOpponent(Effect):
    """自分のポケモン1匹からダメカンを1個、相手のポケモン1匹に移す(Transfer Pain)。相手の対象は攻撃時に選ぶ。"""

    attack_target = "opp_any"

    def execute(self, ctx: EffectContext) -> None:
        from effects.primitives import _resolve_opponent_target

        player = _attacker_player(ctx)
        opponent = ctx.state.player(ctx.opponent)
        target = _resolve_opponent_target(ctx, opponent)
        if target is None:
            return
        candidates = [(s, m) for s, m in ([(0, player.active)] if player.active else []) + [(i + 1, b) for i, b in enumerate(player.bench)] if m.damage > 0]
        if not candidates:
            return
        slot_of_target = 0 if target is opponent.active else 1 + opponent.bench.index(target)
        if len(candidates) == 1:
            candidates[0][1].remove_counters(10)
            target.damage += 10
            ctx.log("ダメカン1個を相手のポケモンに移した")
            return
        pending = PendingSearchChoice(
            player_index=ctx.acting_player,
            zone="gen_pokemon_pick",
            source_indices=[s for s, _ in candidates],
            card_ids=[m.card_id for _, m in candidates],
            min_count=1,
            max_count=1,
            prompt="ダメカンを1個移す元の自分のポケモンを選ぶ",
            shuffle_after=False,
            all_card_ids=[m.card_id for _, m in candidates],
            custom_data={"op": "move_one_counter_to_opponent", "target_slot": slot_of_target},
        )
        pending.cont_source_pokemon = ctx.source_pokemon
        pending.cont_source_card_id = ctx.source_card_id
        ctx.state.pending_search_choice = pending
