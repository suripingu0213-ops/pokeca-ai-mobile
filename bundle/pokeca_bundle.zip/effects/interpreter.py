"""効果スクリプト(プリミティブのリスト)をコンテキストに対して実行する。"""

from __future__ import annotations

from collections.abc import Sequence

from effects.context import EffectContext
from effects.primitives import Effect


def run_script(script: Sequence[Effect], ctx: EffectContext) -> None:
    for i, effect in enumerate(script):
        effect.execute(ctx)
        if ctx.state.pending_search_choice is not None:
            # 検索の選択待ちになったら、それ以降の効果は選択確定後(ResolveSearchChoice)まで実行しない。
            # 残りの効果は選択待ちオブジェクトに保存しておき、確定処理側(rules_engine)で再開する。
            # 効果自身が既にremaining_scriptに続きを積んでいる場合(SearchDeckMultiCriteriaの
            # 複数条件チェイン等)は、それを維持したまま外側スクリプトの残りを後ろに追加する。
            choice = ctx.state.pending_search_choice
            choice.remaining_script = choice.remaining_script + tuple(script[i + 1 :])
            choice.cont_source_pokemon = ctx.source_pokemon
            choice.cont_acting_player = ctx.acting_player
            choice.cont_source_card_id = ctx.source_card_id
            choice.cont_target_bench_index = ctx.target_bench_index
            return
        if ctx.state.pending_damage_distribution is not None:
            # ダメカン自由配分の選択待ちになったら、それ以降の効果は確定後(ResolveDamageDistribution)まで
            # 実行しない。現状このプリミティブをスクリプトの途中に置くカードは無いため、継続効果の保存は
            # 行わない(必要になった場合はpending_search_choiceと同様にremaining_scriptを持たせて拡張する)。
            return
