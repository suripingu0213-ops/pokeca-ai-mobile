"""メガ時代のトレーナーズの効果(その2): エネルギー移動・ベンチ整理・サイドの入れ替え・進化カードを戻す・たねポケモンの入れ替え。

effects/era_trainers_g.py から import される(選択の続きは effects.era_primitives_b.GENERIC_OP_HANDLERS に登録する)。
"""

from __future__ import annotations

from dataclasses import dataclass

from effects.context import EffectContext
from effects.primitives import Effect, _attacker_player
from engine.state import PendingSearchChoice


# ---------------------------------------------------------------------------------------------
# Tag Switch
# ---------------------------------------------------------------------------------------------
@dataclass(frozen=True)
class TagSwitchEffect(Effect):
    """自分のTAG TEAMポケモン1匹から、エネルギーを最大2枚、自分の別のポケモンに移す(Tag Switch)。"""

    count: int = 2

    def execute(self, ctx: EffectContext) -> None:
        from effects.era_primitives_b import _slots

        player = _attacker_player(ctx)
        slots = _slots(player)
        candidates = [
            (slot, mon) for slot, mon in slots
            if mon.attached_energy and (c := ctx.card_db.get(mon.card_id)) is not None and "TAG TEAM" in c.subtypes and len(slots) > 1
        ]
        if not candidates:
            return
        ctx.state.pending_search_choice = PendingSearchChoice(
            player_index=ctx.acting_player,
            zone="gen_pokemon_pick",
            source_indices=[slot for slot, _ in candidates],
            card_ids=[m.card_id for _, m in candidates],
            min_count=1,
            max_count=1,
            prompt="エネルギーを移す元のTAG TEAMポケモンを選ぶ",
            shuffle_after=False,
            all_card_ids=[m.card_id for _, m in candidates],
            custom_data={"op": "tag_switch_src", "count": self.count},
            effect_source=ctx.effect_source,
        )


def _op_tag_switch_src(state, card_db, choice, selected, action, ctx, custom) -> bool:
    from effects.era_primitives_b import _slots

    if not selected:
        return False
    player = state.player(choice.player_index)
    src_slot = choice.source_indices[selected[0]]
    dests = [(slot, m) for slot, m in _slots(player) if slot != src_slot]
    if not dests:
        return False
    if len(dests) == 1:
        _start_tag_switch_energy(state, choice.player_index, src_slot, dests[0][0], custom["count"])
        return False
    state.pending_search_choice = PendingSearchChoice(
        player_index=choice.player_index,
        zone="gen_pokemon_pick",
        source_indices=[slot for slot, _ in dests],
        card_ids=[m.card_id for _, m in dests],
        min_count=1,
        max_count=1,
        prompt="エネルギーを受け取るポケモンを選ぶ",
        shuffle_after=False,
        all_card_ids=[m.card_id for _, m in dests],
        custom_data={"op": "tag_switch_dst", "src_slot": src_slot, "count": custom["count"]},
        effect_source=choice.effect_source,
    )
    return False


def _op_tag_switch_dst(state, card_db, choice, selected, action, ctx, custom) -> bool:
    if selected:
        _start_tag_switch_energy(state, choice.player_index, custom["src_slot"], choice.source_indices[selected[0]], custom["count"])
    return False


def _start_tag_switch_energy(state, player_index: int, src_slot: int, dst_slot: int, count: int) -> None:
    from effects.era_primitives_b import _mon_at

    src = _mon_at(state.player(player_index), src_slot)
    if src is None or not src.attached_energy:
        return
    state.pending_search_choice = PendingSearchChoice(
        player_index=player_index,
        zone="gen_energy_pick",
        source_indices=list(range(len(src.attached_energy))),
        card_ids=list(src.attached_energy),
        min_count=0,
        max_count=min(count, len(src.attached_energy)),
        prompt=f"移すエネルギーを最大{count}枚選ぶ",
        shuffle_after=False,
        all_card_ids=list(src.attached_energy),
        custom_data={"op": "move_selected_energy", "from_slot": src_slot, "to_slot": dst_slot},
    )


# ---------------------------------------------------------------------------------------------
# Cyrus
# ---------------------------------------------------------------------------------------------
@dataclass(frozen=True)
class CyrusEffect(Effect):
    """相手が自分のベンチポケモンを2匹選び、それ以外のベンチポケモンとついているカードを全て山札に戻してシャッフルする(Cyrus ◇)。"""

    keep: int = 2

    def execute(self, ctx: EffectContext) -> None:
        opponent = ctx.state.player(ctx.opponent)
        if len(opponent.bench) <= self.keep:
            return
        ctx.state.pending_search_choice = PendingSearchChoice(
            player_index=ctx.opponent,
            zone="gen_pokemon_pick",
            source_indices=[i + 1 for i in range(len(opponent.bench))],
            card_ids=[m.card_id for m in opponent.bench],
            min_count=self.keep,
            max_count=self.keep,
            prompt=f"ベンチに残すポケモンを{self.keep}匹選ぶ(残りはついているカードごと山札に戻る)",
            shuffle_after=False,
            all_card_ids=[m.card_id for m in opponent.bench],
            custom_data={"op": "cyrus_keep"},
            effect_source=ctx.effect_source,
        )


def _op_cyrus_keep(state, card_db, choice, selected, action, ctx, custom) -> bool:
    owner = state.player(choice.player_index)
    keep_slots = {choice.source_indices[p] for p in selected}
    kept = []
    for slot, mon in enumerate(list(owner.bench), start=1):
        if slot in keep_slots:
            kept.append(mon)
            continue
        owner.deck.extend(mon.evolution_history)
        owner.deck.append(mon.card_id)
        owner.deck.extend(mon.attached_energy)
        if mon.attached_tool:
            owner.deck.append(mon.attached_tool)
    owner.bench = kept
    state.rng.shuffle(owner.deck)
    state.add_log("ベンチの残りのポケモンを、ついているカードごと山札に戻してシャッフルした")
    return False


# ---------------------------------------------------------------------------------------------
# Team Rocket's Bother-Bot
# ---------------------------------------------------------------------------------------------
@dataclass(frozen=True)
class BotherBotEffect(Effect):
    """相手のサイドの裏向きの1枚を表向きにし、相手の手札からランダムに1枚を選んで公開させる。その2枚を入れ替えさせてもよい(Team Rocket's Bother-Bot)。"""

    def execute(self, ctx: EffectContext) -> None:
        opponent = ctx.state.player(ctx.opponent)
        face_down = [i for i in range(len(opponent.prizes)) if opponent.prize_mark(i) == 0]
        if not face_down or not opponent.hand:
            return
        prize_index = ctx.rng.choice(face_down)
        hand_index = ctx.rng.randrange(len(opponent.hand))
        if len(opponent.prize_marks) != len(opponent.prizes):
            opponent.prize_marks = [0] * len(opponent.prizes)
        opponent.prize_marks[prize_index] = 2  # 表向きのまま(ゲーム中ずっと)
        prize_card, hand_card = opponent.prizes[prize_index], opponent.hand[hand_index]
        ctx.reveal("相手のサイド(表向きにした1枚)と、手札から選んだ1枚", [prize_card, hand_card])
        labels = (f"入れ替えさせる: サイド {prize_card} と 手札 {hand_card}", "入れ替えさせない")
        ctx.state.pending_search_choice = PendingSearchChoice(
            player_index=ctx.acting_player,
            zone="gen_pokemon_pick",
            source_indices=[0, 1],
            card_ids=list(labels),
            min_count=1,
            max_count=1,
            prompt="この2枚を入れ替えさせるか選ぶ",
            shuffle_after=False,
            all_card_ids=list(labels),
            custom_data={"op": "bother_bot_swap", "prize_index": prize_index, "hand_card": hand_card, "prize_card": prize_card},
            effect_source=ctx.effect_source,
        )


def _op_bother_bot_swap(state, card_db, choice, selected, action, ctx, custom) -> bool:
    if not selected or choice.source_indices[selected[0]] != 0:
        return False
    opponent = state.player(1 - choice.player_index)
    idx = custom["prize_index"]
    hand_card = custom["hand_card"]
    if idx >= len(opponent.prizes) or hand_card not in opponent.hand:
        return False
    prize_card = opponent.prizes[idx]
    opponent.hand.remove(hand_card)
    opponent.prizes[idx] = hand_card
    opponent.hand.append(prize_card)
    state.add_log("相手のサイドの表向きのカードと、手札のカードを入れ替えさせた")
    return False


# ---------------------------------------------------------------------------------------------
# Strange Timepiece
# ---------------------------------------------------------------------------------------------
@dataclass(frozen=True)
class DevolveOwnPokemonAnyNumber(Effect):
    """自分の進化したポケモン(指定タイプ)1匹から、進化カードを好きな枚数、上から手札に戻す。そのポケモンはこの番、進化できない(Strange Timepiece)。"""

    ptype: str | None = None

    def candidates(self, player, card_db):
        from effects.era_primitives_b import _slots

        out = []
        for slot, mon in _slots(player):
            c = card_db.get(mon.card_id)
            if mon.evolution_history and c is not None and (self.ptype is None or self.ptype in c.types):
                out.append((slot, mon))
        return out

    def execute(self, ctx: EffectContext) -> None:
        candidates = self.candidates(_attacker_player(ctx), ctx.card_db)
        if not candidates:
            return
        ctx.state.pending_search_choice = PendingSearchChoice(
            player_index=ctx.acting_player,
            zone="gen_pokemon_pick",
            source_indices=[slot for slot, _ in candidates],
            card_ids=[m.card_id for _, m in candidates],
            min_count=1,
            max_count=1,
            prompt="進化カードを手札に戻すポケモンを選ぶ",
            shuffle_after=False,
            all_card_ids=[m.card_id for _, m in candidates],
            custom_data={"op": "devolve_pick"},
            effect_source=ctx.effect_source,
        )


def _op_devolve_pick(state, card_db, choice, selected, action, ctx, custom) -> bool:
    from effects.era_primitives_b import _mon_at

    if not selected:
        return False
    slot = choice.source_indices[selected[0]]
    mon = _mon_at(state.player(choice.player_index), slot)
    if mon is None or not mon.evolution_history:
        return False
    labels = [f"{k}枚戻す" for k in range(1, len(mon.evolution_history) + 1)]
    if len(labels) == 1:
        _devolve(state, choice.player_index, slot, 1)
        return False
    state.pending_search_choice = PendingSearchChoice(
        player_index=choice.player_index,
        zone="gen_pokemon_pick",
        source_indices=list(range(1, len(labels) + 1)),
        card_ids=labels,
        min_count=1,
        max_count=1,
        prompt="手札に戻す進化カードの枚数を選ぶ",
        shuffle_after=False,
        all_card_ids=labels,
        custom_data={"op": "devolve_count", "slot": slot},
        effect_source=choice.effect_source,
    )
    return False


def _op_devolve_count(state, card_db, choice, selected, action, ctx, custom) -> bool:
    if selected:
        _devolve(state, choice.player_index, custom["slot"], choice.source_indices[selected[0]])
    return False


def _devolve(state, player_index: int, slot: int, count: int) -> None:
    from effects.era_primitives_b import _mon_at

    owner = state.player(player_index)
    mon = _mon_at(owner, slot)
    if mon is None:
        return
    for _ in range(min(count, len(mon.evolution_history))):
        owner.hand.append(mon.card_id)
        mon.card_id = mon.evolution_history.pop()
    mon.no_evolve_until_turn = owner.turns_taken
    state.add_log("進化カードを手札に戻した")


# ---------------------------------------------------------------------------------------------
# Transformation Tome
# ---------------------------------------------------------------------------------------------
@dataclass(frozen=True)
class TransformationTomeEffect(Effect):
    """トラッシュのたねポケモン1匹を選び、自分の場のたねポケモン1匹と入れ替える。ついているカード・ダメカン・特殊状態・場に出ていた番数などはそのまま引き継ぐ(Transformation Tome。2枚同時使用)。"""

    def execute(self, ctx: EffectContext) -> None:
        from effects.era_primitives_b import _slots

        player = _attacker_player(ctx)
        discard_basics = [i for i, cid in enumerate(player.discard) if (c := ctx.card_db.get(cid)) is not None and c.is_pokemon and c.is_basic]
        targets = [(slot, m) for slot, m in _slots(player) if (c := ctx.card_db.get(m.card_id)) is not None and c.is_basic and not m.evolution_history]
        if not discard_basics or not targets:
            return
        ctx.state.pending_search_choice = PendingSearchChoice(
            player_index=ctx.acting_player,
            zone="gen_pokemon_pick",
            source_indices=discard_basics,
            card_ids=[player.discard[i] for i in discard_basics],
            min_count=1,
            max_count=1,
            prompt="場のたねポケモンと入れ替える、トラッシュのたねポケモンを選ぶ",
            shuffle_after=False,
            all_card_ids=[player.discard[i] for i in discard_basics],
            custom_data={"op": "tome_pick_discard"},
            effect_source=ctx.effect_source,
        )


def _op_tome_pick_discard(state, card_db, choice, selected, action, ctx, custom) -> bool:
    from effects.era_primitives_b import _slots

    if not selected:
        return False
    player = state.player(choice.player_index)
    discard_index = choice.source_indices[selected[0]]
    targets = [(slot, m) for slot, m in _slots(player) if (c := card_db.get(m.card_id)) is not None and c.is_basic and not m.evolution_history]
    if not targets:
        return False
    if len(targets) == 1:
        _tome_swap(state, choice.player_index, discard_index, targets[0][0])
        return False
    state.pending_search_choice = PendingSearchChoice(
        player_index=choice.player_index,
        zone="gen_pokemon_pick",
        source_indices=[slot for slot, _ in targets],
        card_ids=[m.card_id for _, m in targets],
        min_count=1,
        max_count=1,
        prompt="トラッシュのポケモンと入れ替える、場のたねポケモンを選ぶ",
        shuffle_after=False,
        all_card_ids=[m.card_id for _, m in targets],
        custom_data={"op": "tome_pick_target", "discard_index": discard_index},
        effect_source=choice.effect_source,
    )
    return False


def _op_tome_pick_target(state, card_db, choice, selected, action, ctx, custom) -> bool:
    if selected:
        _tome_swap(state, choice.player_index, custom["discard_index"], choice.source_indices[selected[0]])
    return False


def _tome_swap(state, player_index: int, discard_index: int, slot: int) -> None:
    from effects.era_primitives_b import _mon_at

    owner = state.player(player_index)
    mon = _mon_at(owner, slot)
    if mon is None or discard_index >= len(owner.discard):
        return
    new_id = owner.discard[discard_index]
    owner.discard[discard_index] = mon.card_id  # 入れ替わった元のポケモンはトラッシュへ
    mon.card_id = new_id
    state.add_log(f"トラッシュの{new_id}と入れ替えた(ついているカード・ダメカンなどはそのまま)")


def register_ops() -> None:
    from effects.era_primitives_b import GENERIC_OP_HANDLERS

    GENERIC_OP_HANDLERS.update({
        "tag_switch_src": _op_tag_switch_src,
        "tag_switch_dst": _op_tag_switch_dst,
        "cyrus_keep": _op_cyrus_keep,
        "bother_bot_swap": _op_bother_bot_swap,
        "devolve_pick": _op_devolve_pick,
        "devolve_count": _op_devolve_count,
        "tome_pick_discard": _op_tome_pick_discard,
        "tome_pick_target": _op_tome_pick_target,
    })


register_ops()
