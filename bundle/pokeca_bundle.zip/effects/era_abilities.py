"""時代ごとのカード取り込み(2026-10-06〜)で追加した、起動型/トリガー型の特性用のプリミティブ。

AbilityGateは、起動型の特性スクリプトの先頭に置く「使える条件」の印(engine.legal_actions._ability_actionsが読む)。
対象を選ぶ特性は、攻撃時の対象指定(UseAbilityのtarget_bench_index)ではなく、効果の中でPickPokemonThenが
選択待ち(zone="gen_pokemon_pick")を立てて選ばせる(era_primitives_b.resolve_generic_zone参照)。
"""

from __future__ import annotations

from dataclasses import dataclass

from effects.context import EffectContext
from effects.primitives import Effect, _attacker_player, _trigger_search_choice
from engine.state import PendingSearchChoice


@dataclass(frozen=True)
class AbilityGate(Effect):
    """起動型の特性を「使える」条件。executeは何もしない(合法手の判定専用)。"""

    kind: str
    arg: str = ""

    def ability_gate(self, state, player, mon, zone, card_db) -> bool:
        from engine.actions import Zone

        if self.kind == "active_only":
            return zone == Zone.ACTIVE
        if self.kind == "bench_only":
            return zone == Zone.BENCH
        if self.kind == "hand_empty":
            return not player.hand
        if self.kind == "self_has_energy":
            if self.arg in ("", "any"):
                return bool(mon.attached_energy)
            return any((c := card_db.get(e)) is not None and c.basic_energy_type == self.arg for e in mon.attached_energy)
        if self.kind == "hand_has_basic_energy":
            return any(
                (c := card_db.get(cid)) is not None and c.is_energy and not c.is_special_energy and c.basic_energy_type == self.arg
                for cid in player.hand
            )
        if self.kind == "mega_ex_in_play":
            return any(
                (c := card_db.get(m.card_id)) is not None and "MEGA" in c.subtypes and (not self.arg or self.arg in c.types)
                for m in player.all_pokemon_in_play()
            )
        if self.kind == "hand_not_empty":
            return bool(player.hand)
        if self.kind == "played_supporter_named":
            return self.arg in player.supporter_names_this_turn
        if self.kind == "has_named_pokemon_in_play":
            return any((c := card_db.get(m.card_id)) is not None and c.name == self.arg for m in player.all_pokemon_in_play())
        if self.kind == "hand_has_basic_energy_named":
            return any((c := card_db.get(cid)) is not None and c.is_energy and c.name == self.arg for cid in player.hand)
        if self.kind == "name_not_used":
            return self.arg not in player.used_ability_names_this_turn
        if self.kind == "self_status":
            return mon.status.exclusive.name == self.arg.upper() or (self.arg == "poisoned" and mon.status.poisoned)
        if self.kind == "has_damaged_pokemon":
            return any(m.damage > 0 for m in player.all_pokemon_in_play())
        if self.kind.startswith("g:"):
            # 自動生成したグッズ/サポートの「使える条件」(effects/era_trainer_gates.py)と同じ名前の条件を、特性の使える条件にも使う
            from effects.era_trainer_gates import GATE_FUNCS

            return GATE_FUNCS[self.kind[2:]](state, player, 0 if player is state.players[0] else 1, card_db, self.arg)
        if self.kind == "hand_matches":
            # 手札に条件(SearchDeckMultiCriteriaの条件名)に合うカードがN枚以上ある("条件:枚数")。コストとして手札を捨てる特性の使える条件
            from effects.primitives import SearchDeckMultiCriteria

            criterion, _, count = self.arg.rpartition(":")
            return sum(
                1 for cid in player.hand
                if (c := card_db.get(cid)) is not None and (criterion == "any" or SearchDeckMultiCriteria._matches(c, criterion))
            ) >= int(count)
        return True

    def execute(self, ctx: EffectContext) -> None:
        return


@dataclass(frozen=True)
class MarkAbilityNameUsed(Effect):
    """この番に、この名前の特性を使ったことを記録する(「同じ名前の特性は1つしか使えない」特性用)。"""

    name: str

    def execute(self, ctx: EffectContext) -> None:
        _attacker_player(ctx).used_ability_names_this_turn.append(self.name)


@dataclass(frozen=True)
class KnockOutSelfEffect(Effect):
    """このポケモン自身をきぜつさせる(特性のコストとして)。"""

    def execute(self, ctx: EffectContext) -> None:
        if ctx.source_pokemon is not None:
            ctx.source_pokemon.damage = 9999


@dataclass(frozen=True)
class PickPokemonThen(Effect):
    """ポケモンを1匹選び(自分/相手の場)、そのポケモンにaction("heal"|"put_counters"|"switch_opp_active"|"shuffle_into_deck")を行う。
    候補が1匹だけなら選択なしで実行する。optional=Trueなら選ばずにやめてもよい。"""

    side: str = "own"
    action: str = "heal"
    amount: int = 0  # heal: 回復量(fullなら全部) / put_counters: ダメカンの個数
    full: bool = False
    bench_only: bool = False
    basic_only: bool = False
    ptype: str | None = None
    subtype: str | None = None
    name_prefix: str | None = None
    require_energy_type: str | None = None
    damaged_only: bool = False
    exclude_self: bool = False
    optional: bool = False
    has_tool: bool = False
    evolved_only: bool = False
    active_only: bool = False  # バトルポケモンだけが対象
    exclude_subtype: str | None = None  # このサブタイプのポケモンは対象にできない
    undamaged_only: bool = False  # ダメカンがのっていないポケモンだけが対象
    coins: int = 0  # healのとき、コインをこの枚数投げて、オモテ1枚につきamountずつ回復する(モーモーミルク)
    remaining_hp_at_most: int | None = None  # 残りHPがこの値以下のポケモンだけが対象
    exclude_picked: bool = False  # take_countersで1段階目に選んだポケモンを除く(ダメカンを別のポケモンに移す特性用)
    has_energy: bool = False  # エネルギーがついているポケモンだけが対象
    name_exact: str | None = None
    then: tuple = ()  # 選んだ対象に行ったあと続けて実行する効果

    def _candidates(self, ctx: EffectContext):
        from effects.era_primitives_b import _slots

        owner = ctx.state.player(ctx.acting_player if self.side == "own" else ctx.opponent)
        out = []
        if self.action == "give_counters" and ctx.state.picked_counter_count <= 0:
            return out  # 1段階目でダメカンを取り除けなかった(移せない/0個)ときは、移し先を選ばない
        for slot, mon in _slots(owner):
            if self.bench_only and slot == 0:
                continue
            if self.active_only and slot != 0:
                continue
            if self.exclude_self and mon is ctx.source_pokemon:
                continue
            if self.damaged_only and mon.damage <= 0:
                continue
            if self.undamaged_only and mon.damage > 0:
                continue
            if self.remaining_hp_at_most is not None:
                from engine.continuous import effective_max_hp

                if effective_max_hp(ctx.card_db, mon.card_id, mon.attached_tool, ctx.state.stadium_in_play, mon.attached_energy) - mon.damage > self.remaining_hp_at_most:
                    continue
            if self.has_tool and mon.attached_tool is None:
                continue
            if self.has_energy and not mon.attached_energy:
                continue
            if self.evolved_only and not mon.evolution_history:
                continue
            if self.exclude_picked and mon is ctx.state.picked_counter_source:
                continue
            card = ctx.card_db.get(mon.card_id)
            if card is None:
                continue
            if self.name_exact and card.name != self.name_exact:
                continue
            if self.basic_only and not card.is_basic:
                continue
            if self.ptype and self.ptype not in card.types:
                continue
            if self.subtype and self.subtype not in card.subtypes:
                continue
            if self.exclude_subtype and self.exclude_subtype in card.subtypes:
                continue
            if self.name_prefix and not card.name.startswith(self.name_prefix):
                continue
            if self.require_energy_type and not any(
                (c := ctx.card_db.get(e)) is not None and c.basic_energy_type == self.require_energy_type for e in mon.attached_energy
            ):
                continue
            out.append((slot, mon))
        return out

    def ability_gate(self, state, player, mon, zone, card_db) -> bool:
        """特性として使うとき、対象にできるポケモンがいるか。"""
        player_index = 0 if player is state.players[0] else 1
        ctx = EffectContext(state=state, card_db=card_db, acting_player=player_index, source_pokemon=mon, source_card_id=mon.card_id)
        return bool(self._candidates(ctx))

    def execute(self, ctx: EffectContext) -> None:
        candidates = self._candidates(ctx)
        if not candidates:
            return
        if len(candidates) == 1 and not self.optional:
            self.apply(ctx, candidates[0][0])
            self._run_then(ctx)
            return
        pending = PendingSearchChoice(
            player_index=ctx.acting_player,
            zone="gen_pokemon_pick",
            source_indices=[s for s, _ in candidates],
            card_ids=[m.card_id for _, m in candidates],
            min_count=0 if self.optional else 1,
            max_count=1,
            prompt="対象のポケモンを選ぶ",
            shuffle_after=False,
            all_card_ids=[m.card_id for _, m in candidates],
            custom_data={"op": "pick_then", "effect": self},
        )
        pending.cont_source_pokemon = ctx.source_pokemon
        pending.cont_source_card_id = ctx.source_card_id
        pending.effect_source = ctx.effect_source
        ctx.state.pending_search_choice = pending

    def _run_then(self, ctx: EffectContext) -> None:
        if self.then:
            from effects.interpreter import run_script

            run_script(tuple(self.then), ctx)

    def apply(self, ctx: EffectContext, slot: int) -> None:
        from effects.era_primitives_b import _mon_at
        from effects.primitives import _blocks_damage_counters, _defender_blocks_effect, discard_attached_tool

        owner_index = ctx.acting_player if self.side == "own" else ctx.opponent
        owner = ctx.state.player(owner_index)
        mon = _mon_at(owner, slot)
        if mon is None:
            return
        if self.side == "opp" and _defender_blocks_effect(ctx, mon):
            return
        if self.action == "heal":
            if self.coins:
                heads = sum(1 for _ in range(self.coins) if ctx.rng.random() < 0.5)
                ctx.log(f"コイン{self.coins}枚: オモテ{heads}枚")
                mon.damage = max(0, mon.damage - self.amount * heads)
            else:
                mon.damage = 0 if self.full else max(0, mon.damage - self.amount)
        elif self.action == "heal_clear":
            mon.damage = max(0, mon.damage - self.amount)
            mon.status.clear_all()  # ライフフォレスト◇: ダメージを回復し、特殊状態を全て治す
        elif self.action == "put_counters":
            if not _blocks_damage_counters(mon):
                mon.damage += self.amount * 10
        elif self.action == "set_remaining_hp":
            if not _blocks_damage_counters(mon):
                from engine.continuous import effective_max_hp

                max_hp = effective_max_hp(ctx.card_db, mon.card_id, mon.attached_tool, ctx.state.stadium_in_play, mon.attached_energy)
                if max_hp - mon.damage > self.amount:
                    mon.damage = max_hp - self.amount  # 残りHPがamountになるまでダメカンをのせる
        elif self.action == "discard_special_energy":
            specials = [e for e in mon.attached_energy if (c := ctx.card_db.get(e)) is not None and c.is_special_energy]
            if specials:
                mon.attached_energy.remove(specials[0])
                owner.discard.append(specials[0])
                ctx.log("相手のポケモンの特殊エネルギーをトラッシュした")
        elif self.action == "discard_tool":
            if mon.attached_tool is not None:
                discard_attached_tool(ctx.state, owner, mon)
                ctx.log("相手のポケモンのどうぐをトラッシュした")
        elif self.action == "knock_out":
            mon.damage += 10000  # きぜつさせる(ワザの効果。きぜつ処理はワザのあとにまとめて行われる)
            ctx.log(f"{mon.card_id} をきぜつさせた")
        elif self.action == "shield_vs_ex":
            mon.ex_attack_shield_until = ctx.state.player(ctx.opponent).turns_taken + 1  # Acerola's Mischief
            ctx.log(f"{mon.card_id} は相手の次の番、相手のポケモンexのワザのダメージも効果も受けない")
        elif self.action == "take_counters":
            from effects.primitives import _damage_counter_relocation_blocked

            if _damage_counter_relocation_blocked(ctx):
                return  # Watchful Eye等: ダメカンを他のポケモンに移せない
            n = min(self.amount, mon.damage // 10)
            mon.damage -= n * 10
            ctx.state.picked_counter_source = mon
            ctx.state.picked_counter_count = n
        elif self.action == "give_counters":
            n = ctx.state.picked_counter_count
            if n > 0 and not _blocks_damage_counters(mon):
                mon.damage += n * 10
            ctx.state.picked_counter_source = None
            ctx.state.picked_counter_count = 0
        elif self.action == "tool_to_hand":
            if mon.attached_tool is not None:
                tool_id = mon.attached_tool
                mon.attached_tool = None
                owner.hand.append(tool_id)
        elif self.action == "switch_own_active":
            if slot == 0 or owner.active is None:
                return
            new_active = owner.bench.pop(slot - 1)
            owner.active.status.clear_all()
            owner.bench.append(owner.active)
            new_active.status.clear_all()
            new_active.became_active_turn = owner.turns_taken
            owner.active = new_active
        elif self.action == "switch_opp_active":
            if slot == 0 or owner.active is None:
                return
            new_active = owner.bench.pop(slot - 1)
            owner.active.status.clear_all()
            owner.bench.append(owner.active)
            new_active.status.clear_all()
            owner.active = new_active
        elif self.action == "return_all_to_hand":
            if slot == 0:
                if not owner.bench:
                    return
                owner.active = None
                ctx.state.pending_active_choice = [owner_index]
                ctx.state.then_after_choice = "continue"
            else:
                owner.bench.remove(mon)
            owner.hand.extend(mon.evolution_history)
            owner.hand.append(mon.card_id)
            owner.hand.extend(mon.attached_energy)
            if mon.attached_tool:
                owner.hand.append(mon.attached_tool)
            ctx.log(f"{mon.card_id} とついているカードを全て手札に戻した")
        elif self.action == "devolve":
            if not mon.evolution_history:
                return
            owner.hand.append(mon.card_id)
            mon.card_id = mon.evolution_history.pop()
            mon.no_evolve_until_turn = owner.turns_taken  # そのポケモンは、この番はもう進化できない
            ctx.log("進化を1段階戻して、進化後のカードを手札に加えた")
        elif self.action in ("discard_all", "lost_zone_all"):
            # ポケモンとついているカードを全てトラッシュ(ロストゾーン)へ送る(GGエンドGX/ロストパージGX)。バトルポケモンなら、ベンチがあれば新しいバトルポケモンを選ばせる
            if slot == 0:
                owner.active = None
                if owner.bench:
                    ctx.state.pending_active_choice = [owner_index]
                    ctx.state.then_after_choice = "continue"
            else:
                owner.bench.remove(mon)
            pile = owner.lost_zone if self.action == "lost_zone_all" else owner.discard
            pile.extend(mon.evolution_history)
            pile.append(mon.card_id)
            pile.extend(mon.attached_energy)
            if mon.attached_tool:
                pile.append(mon.attached_tool)
            ctx.log(f"{mon.card_id} とついているカードを全て{'ロストゾーン' if self.action == 'lost_zone_all' else 'トラッシュ'}に送った")
        elif self.action == "shuffle_into_deck":
            if slot == 0:
                if not owner.bench:
                    return
                owner.active = None
                ctx.state.pending_active_choice = [owner_index]
                ctx.state.then_after_choice = "continue"
            else:
                owner.bench.remove(mon)
            owner.deck.extend(mon.evolution_history)
            owner.deck.append(mon.card_id)
            owner.deck.extend(mon.attached_energy)
            if mon.attached_tool:
                owner.deck.append(mon.attached_tool)
            ctx.rng.shuffle(owner.deck)
        _ = discard_attached_tool


@dataclass(frozen=True)
class LookTopNTakeOneRestOnTop(Effect):
    """自分の山札の上からn枚を見て、1枚を選んで手札に加える。残りは山札の上に戻す(Forewarn)。"""

    n: int

    def execute(self, ctx: EffectContext) -> None:
        player = _attacker_player(ctx)
        n = min(self.n, len(player.deck))
        if n <= 0:
            return
        ctx.state.pending_search_choice = PendingSearchChoice(
            player_index=ctx.acting_player,
            zone="deck",
            source_indices=list(range(n)),
            card_ids=list(player.deck[:n]),
            min_count=1,
            max_count=1,
            prompt=f"山札の上{n}枚から手札に加えるカードを選ぶ(残りは山札の上に戻る)",
            shuffle_after=False,
            all_card_ids=list(player.deck[:n]),
            destination="hand",
            reveal_to_opponent=False,
            effect_source=ctx.effect_source,
        )


@dataclass(frozen=True)
class SwapHandCardWithDeckTop(Effect):
    """手札のカード1枚を選び、山札の一番上のカードと入れ替える(Evidence Gathering)。"""

    def execute(self, ctx: EffectContext) -> None:
        player = _attacker_player(ctx)
        if not player.hand or not player.deck:
            return
        top = player.deck.pop(0)
        pending = PendingSearchChoice(
            player_index=ctx.acting_player,
            zone="hand",
            source_indices=list(range(len(player.hand))),
            card_ids=list(player.hand),
            min_count=1,
            max_count=1,
            prompt="山札の一番上と入れ替える手札のカードを選ぶ",
            shuffle_after=False,
            all_card_ids=list(player.hand),
            destination="deck_top_no_shuffle",
            remaining_script=(_TakeHeldCardToHand(top),),
            effect_source=ctx.effect_source,
        )
        pending.cont_source_pokemon = ctx.source_pokemon
        pending.cont_source_card_id = ctx.source_card_id
        ctx.state.pending_search_choice = pending


@dataclass(frozen=True)
class _TakeHeldCardToHand(Effect):
    card_id: str

    def execute(self, ctx: EffectContext) -> None:
        _attacker_player(ctx).hand.append(self.card_id)


@dataclass(frozen=True)
class InflictStatusOnOwnActive(Effect):
    """自分のバトルポケモンを特殊状態にする(Long-Distance Hypnosis)。"""

    condition: str

    def execute(self, ctx: EffectContext) -> None:
        from effects.primitives import _apply_condition

        active = _attacker_player(ctx).active
        if active is not None:
            _apply_condition(active, self.condition)


@dataclass(frozen=True)
class SearchDeckForTeamPlasmaCardToHand(Effect):
    """山札からプラズマ団のカード(サブタイプTeam Plasma、またはプラズマエネルギー)を1枚探して手札に加える(Plasma Search)。"""

    def execute(self, ctx: EffectContext) -> None:
        player = _attacker_player(ctx)
        _trigger_search_choice(
            ctx, player, "deck",
            lambda c: c is not None and ("Team Plasma" in c.subtypes or c.name == "Plasma Energy"), 1,
            "山札からプラズマ団のカードを探す",
        )


@dataclass(frozen=True)
class DiscardFromHandBasicEnergyAsCost(Effect):
    """手札の基本エネルギー(energy_type)を1枚トラッシュしてから、thenを実行する(特性のコスト)。"""

    energy_type: str
    then: tuple = ()

    def execute(self, ctx: EffectContext) -> None:
        player = _attacker_player(ctx)
        _trigger_search_choice(
            ctx, player, "hand",
            lambda c: c is not None and c.is_energy and not c.is_special_energy and c.basic_energy_type == self.energy_type, 1,
            f"トラッシュする基本{self.energy_type}エネルギーを選ぶ", shuffle_after=False, destination="discard", min_count=1,
        )
        pending = ctx.state.pending_search_choice
        if pending is not None:
            pending.remaining_script = tuple(self.then)
            pending.cont_source_pokemon = ctx.source_pokemon
            pending.cont_source_card_id = ctx.source_card_id
            pending.effect_source = ctx.effect_source
        else:
            ctx.log("手札にトラッシュできるエネルギーが無い")


@dataclass(frozen=True)
class TriggerGateAttachedEnergyNamed(Effect):
    """エネルギー添付トリガー(「手札から〜エネルギーをつけたとき」)の発動条件: つけたエネルギーが指定の名前のとき(Red Signal)。"""

    name: str

    def trigger_gate(self, attached_energy_id: str, card_db) -> bool:
        card = card_db.get(attached_energy_id)
        return card is not None and card.name == self.name

    def execute(self, ctx: EffectContext) -> None:
        return


@dataclass(frozen=True)
class GrantTypeAttackBonusThisTurn(Effect):
    """この番の間、自分の(たねの)指定タイプのポケモンのワザは、相手のバトルポケモンへのダメージがamount増える(弱点・抵抗力の前)(Steam Up)。"""

    energy_type: str
    amount: int
    basic_only: bool = True

    def execute(self, ctx: EffectContext) -> None:
        _attacker_player(ctx).attack_bonuses_this_turn.append((self.energy_type, self.amount, self.basic_only))


@dataclass(frozen=True)
class DiscardAbilityDestination(Effect):
    """トラッシュにいる状態で発動する特性(UseDiscardAbility)で、そのポケモン自身がどこへ行くか: "hand"(手札)/"deck_bottom"(山札の下)/
    "coin_bench"(コインを投げ、オモテならベンチに出る。ウラならトラッシュのまま)。マーカーで、executeは何もしない。"""

    kind: str
    discard_dest = True

    def execute(self, ctx: EffectContext) -> None:
        return


@dataclass(frozen=True)
class AttachDiscardEnergyToSelfPerOpponentPrizeTaken(Effect):
    """相手が取ったサイド1枚につき、トラッシュから指定タイプのエネルギーを1枚、このポケモンにつける(Raging Roar)。"""

    energy_type: str

    def execute(self, ctx: EffectContext) -> None:
        from effects.era_primitives_b import attach_generic_start

        n = 6 - len(ctx.state.player(ctx.opponent).prizes)
        if n <= 0:
            return
        spec = {
            "source": "discard", "basic_only": False, "energy_type": self.energy_type, "self_only": True, "bench_only": False,
            "target_type": None, "target_subtype": None, "single_target": True, "distinct_targets": False, "optional": False,
            "special_only": False, "target_name_prefix": None, "exclude_subtype": None, "counters_on_target": 0,
        }
        attach_generic_start(ctx, spec, n)


@dataclass(frozen=True)
class TeleportRoomEffect(Effect):
    """場のスタジアムをトラッシュする。そうしたら、トラッシュから(トラッシュしたものとは名前の違う)スタジアムを1枚選んで場に出す(Teleport Room)。"""

    def execute(self, ctx: EffectContext) -> None:
        state = ctx.state
        if state.stadium_in_play is None:
            return
        old = ctx.card_db.get(state.stadium_in_play)
        old_name = old.name if old is not None else ""
        from effects.primitives import DiscardStadiumInPlay

        DiscardStadiumInPlay().execute(ctx)
        player = _attacker_player(ctx)
        _trigger_search_choice(
            ctx, player, "discard", lambda c: c is not None and c.is_stadium and c.name != old_name, 1,
            "トラッシュから場に出すスタジアムを選ぶ", shuffle_after=False, min_count=0,
        )
        pending = ctx.state.pending_search_choice
        if pending is not None:
            pending.remaining_script = (_PutPickedStadiumInPlay(),)
            pending.cont_source_pokemon = ctx.source_pokemon
            pending.cont_source_card_id = ctx.source_card_id
            pending.effect_source = ctx.effect_source


@dataclass(frozen=True)
class _PutPickedStadiumInPlay(Effect):
    def execute(self, ctx: EffectContext) -> None:
        player = _attacker_player(ctx)
        if not ctx.last_picked_card_ids:
            return
        card_id = ctx.last_picked_card_ids[0]
        if card_id in player.hand:
            player.hand.remove(card_id)
            ctx.state.stadium_in_play = card_id
            ctx.state.stadium_owner = ctx.acting_player
            ctx.log(f"トラッシュのスタジアム{card_id}を場に出した")
