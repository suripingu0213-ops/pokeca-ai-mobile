"""SWSH/SV期のワザ(長い尾): 既存の仕組みに乗らなかった言い回しのための小さな効果(2026-10-07)。

scripts/generate_effects_batch20.py が生成するスクリプトから使われる。選択を伴うものは PendingSearchChoice(zone="gen_*") と
GENERIC_OP_HANDLERS["k_..."] で解決する(ops はファイル末尾で登録)。
"""

from __future__ import annotations

from dataclasses import dataclass

from effects.context import EffectContext
from effects.primitives import DealDamage, Effect, _attacker_player, _defender_blocks_effect, _defender
from engine.state import PendingSearchChoice


@dataclass(frozen=True)
class LockOpponentSpecialEnergyAndStadiumsNextTurn(Effect):
    """相手の次の番、相手は手札から特殊エネルギーもスタジアムも使えない。"""

    def execute(self, ctx: EffectContext) -> None:
        opponent = ctx.state.player(ctx.opponent)
        until = opponent.turns_taken + 1
        opponent.special_energy_attach_locked_until_turn = until
        opponent.stadiums_locked_until_turn = until


@dataclass(frozen=True)
class NotUsableOnFirstTurnIfSecond(Effect):
    """後攻のとき、最初の自分の番には使えないワザであることを表す印(usable_checkで判定する)。"""

    def usable_check(self, state, player, mon, card_db, attack) -> bool:
        index = 0 if player is state.players[0] else 1
        return not (player.turns_taken == 1 and index != state.first_player)

    def execute(self, ctx: EffectContext) -> None:
        return


@dataclass(frozen=True)
class MillThenDamagePerEnergy(Effect):
    """自分の山札の上からn枚をトラッシュする。そのうちのエネルギーカード1枚につきperダメージ(トラッシュしたエネルギーのみ数える)。"""

    n: int
    per: int

    def execute(self, ctx: EffectContext) -> None:
        player = _attacker_player(ctx)
        energies = 0
        for _ in range(self.n):
            if not player.deck:
                break
            card_id = player.deck.pop(0)
            player.discard.append(card_id)
            c = ctx.card_db.get(card_id)
            if c is not None and c.is_energy:
                energies += 1
        ctx.log(f"山札の上から{self.n}枚をトラッシュ(エネルギー{energies}枚)")
        if energies:
            DealDamage(self.per * energies).execute(ctx)


@dataclass(frozen=True)
class PutOwnCountersThenDamagePerCounter(Effect):
    """このポケモンにダメカンを0〜max個(選ぶ)のせる。のせたダメカン1個につきperダメージ。"""

    max_counters: int
    per: int

    def execute(self, ctx: EffectContext) -> None:
        if ctx.source_pokemon is None:
            return
        labels = [str(i) for i in range(self.max_counters + 1)]
        ctx.state.pending_search_choice = PendingSearchChoice(
            player_index=ctx.acting_player, zone="gen_pokemon_pick", source_indices=list(range(len(labels))), card_ids=labels, min_count=1, max_count=1,
            prompt=f"このポケモンにのせるダメカンの数を選ぶ(最大{self.max_counters}個)", shuffle_after=False, all_card_ids=labels,
            custom_data={"op": "k_self_counters", "per": self.per, "user": ctx.acting_player}, effect_source=ctx.effect_source,
            cont_acting_player=ctx.acting_player, cont_source_pokemon=ctx.source_pokemon, cont_source_card_id=ctx.source_card_id,
        )


def _op_self_counters(state, card_db, choice, selected, action, ctx, custom) -> bool:
    from effects.primitives import _blocks_damage_counters

    mon = choice.cont_source_pokemon
    n = choice.source_indices[selected[0]] if selected else 0
    if mon is None:
        return False
    if n and not _blocks_damage_counters(mon):
        mon.damage += n * 10
    if n:
        DealDamage(custom["per"] * n).execute(ctx)
    return False


from effects.primitives import DealBonusDamageToChosenOpponentBench, resolve_attack_damage, _defender_is_shielded  # noqa: E402


@dataclass(frozen=True)
class DealBonusDamageToChosenOpponentBenchSpec(DealBonusDamageToChosenOpponentBench):
    """バトルポケモンへの通常ダメージに加えて、選んだ相手のベンチのポケモン(subtypesのいずれかを持つもの)1匹にamountダメージ(弱点・抵抗力は計算しない)。
    対象の候補はengine.legal_actionsがsubtypesで絞り込む。"""

    subtypes: tuple = ()

    def execute(self, ctx: EffectContext) -> None:
        if ctx.target_bench_index is None:
            return
        opponent = ctx.state.player(ctx.opponent)
        if not (0 <= ctx.target_bench_index < len(opponent.bench)):
            return
        target = opponent.bench[ctx.target_bench_index]
        card = ctx.card_db.get(target.card_id)
        if card is None or _defender_is_shielded(ctx, target):
            return
        if self.subtypes and not any(s in card.subtypes for s in self.subtypes):
            return
        dmg = resolve_attack_damage(ctx, target, card, self.amount, apply_weakness=False, apply_resistance=False)
        target.damage += dmg
        ctx.log(f"{ctx.source_card_id} が相手ベンチに追加で {dmg} ダメージ")




@dataclass(frozen=True)
class MillBothThenDamagePerEnergy(Effect):
    """おたがいの山札の上から1枚ずつトラッシュする。そのうちのエネルギーカード1枚につきperダメージを、基本ダメージ(base)に足す。"""

    base: int
    per: int

    def execute(self, ctx: EffectContext) -> None:
        energies = 0
        for idx in (ctx.acting_player, ctx.opponent):
            player = ctx.state.player(idx)
            if player.deck:
                card_id = player.deck.pop(0)
                player.discard.append(card_id)
                c = ctx.card_db.get(card_id)
                if c is not None and c.is_energy:
                    energies += 1
        ctx.log(f"おたがいの山札の上を1枚ずつトラッシュ(エネルギー{energies}枚)")
        DealDamage(self.base + self.per * energies).execute(ctx)


@dataclass(frozen=True)
class SelfTakesMoreDamageNextTurn(Effect):
    """相手の次の番、このポケモンは、ワザのダメージを(弱点・抵抗力のあとで)amountだけ多く受ける。"""

    amount: int

    def execute(self, ctx: EffectContext) -> None:
        mon = ctx.source_pokemon
        if mon is None:
            return
        mon.extra_damage_taken = self.amount
        mon.extra_damage_taken_turn = ctx.state.player(ctx.opponent).turns_taken + 1


@dataclass(frozen=True)
class LockOwnAttackUntilLeavesActive(Effect):
    """このポケモンは、バトル場を離れるまで、このワザ(attack_name)をもう使えない(ブレイズキック/メテオアサルト等)。
    バトル場に出た番(became_active_turn)の記録で、いったんベンチに下がって戻ったかを判定する。"""

    attack_name: str

    def usable_check(self, state, player, mon, card_db, attack) -> bool:
        if attack.name != self.attack_name:
            return True
        return not (mon.attack_lock_name == self.attack_name and mon.attack_lock_marker == mon.became_active_turn)

    def execute(self, ctx: EffectContext) -> None:
        mon = ctx.source_pokemon
        if mon is None:
            return
        mon.attack_lock_name = self.attack_name
        mon.attack_lock_marker = mon.became_active_turn


@dataclass(frozen=True)
class PutDefenderCountersForEach(Effect):
    """相手のバトルポケモンに、数える物(COUNTERSの名前+引数)1つにつきper個のダメカンをのせる。"""

    per: int
    counter: str
    arg: str = ""

    def execute(self, ctx: EffectContext) -> None:
        from effects.era_attacks_i import count_of
        from effects.primitives import _blocks_damage_counters

        _, defender = _defender(ctx)
        if defender is None or _defender_blocks_effect(ctx, defender) or _blocks_damage_counters(defender):
            return
        n = self.per * count_of(ctx, self.counter, self.arg)
        defender.damage += n * 10
        ctx.log(f"相手のバトルポケモンにダメカンを{n}個のせた")


@dataclass(frozen=True)
class DefenderTakesMoreDamageNextTurn(Effect):
    """自分の次の番、相手のバトルポケモン(このワザを受けたポケモン)は、ワザのダメージを(弱点・抵抗力のあとで)amountだけ多く受ける。"""

    amount: int

    def execute(self, ctx: EffectContext) -> None:
        _, defender = _defender(ctx)
        if defender is None or _defender_blocks_effect(ctx, defender):
            return
        defender.extra_damage_taken = self.amount
        defender.extra_damage_taken_turn = ctx.state.player(ctx.acting_player).turns_taken + 1


@dataclass(frozen=True)
class DefenderDelayedCounters(Effect):
    """相手の次の番の終わりに、このワザを受けたポケモンにダメカンをn個のせる。"""

    n: int

    def execute(self, ctx: EffectContext) -> None:
        _, defender = _defender(ctx)
        if defender is None or _defender_blocks_effect(ctx, defender):
            return
        defender.delayed_counters = self.n
        defender.delayed_counters_turn = ctx.state.player(ctx.opponent).turns_taken + 1


@dataclass(frozen=True)
class DefenderCountersPerOpponentPrizesTaken(Effect):
    """相手のバトルポケモンに、相手が取ったサイド1枚につきper個のダメカンをのせる。"""

    per: int

    def execute(self, ctx: EffectContext) -> None:
        from effects.primitives import _blocks_damage_counters

        _, defender = _defender(ctx)
        if defender is None or _defender_blocks_effect(ctx, defender) or _blocks_damage_counters(defender):
            return
        taken = 6 - len(ctx.state.player(ctx.opponent).prizes)  # 相手が取ったサイド
        defender.damage += self.per * taken * 10
        ctx.log(f"相手のバトルポケモンにダメカンを{self.per * taken}個のせた")


@dataclass(frozen=True)
class MoveAllOwnEnergyToBenchedAnyWay(Effect):
    """このポケモンについているエネルギーを全て、自分のベンチのポケモンに好きなように(1枚ずつ移す先を選ぶ)移す。"""

    def execute(self, ctx: EffectContext) -> None:
        mon = ctx.source_pokemon
        if mon is None or not mon.attached_energy:
            return
        _distribute_next(ctx.state, ctx.card_db, ctx.acting_player, mon, list(mon.attached_energy), ctx.effect_source)


def _distribute_next(state, card_db, player_index: int, source, pool: list, effect_source) -> bool:
    player = state.player(player_index)
    if not pool or not player.bench:
        return False
    if len(player.bench) == 1:
        for eid in pool:
            if eid in source.attached_energy:
                source.attached_energy.remove(eid)
                player.bench[0].attached_energy.append(eid)
        return False
    eid = pool[0]
    labels = [(card_db.get(m.card_id).name if card_db.get(m.card_id) else m.card_id) for m in player.bench]
    state.pending_search_choice = PendingSearchChoice(
        player_index=player_index, zone="gen_pokemon_pick", source_indices=list(range(len(labels))), card_ids=labels, min_count=1, max_count=1,
        prompt=f"{card_db.get(eid).name if card_db.get(eid) else eid}を移す、ベンチのポケモンを選ぶ(残り{len(pool)}枚)", shuffle_after=False, all_card_ids=labels,
        custom_data={"op": "k_distribute_energy", "pool": pool, "user": player_index}, effect_source=effect_source,
        cont_acting_player=player_index, cont_source_pokemon=source,
    )
    return True


def _op_distribute_energy(state, card_db, choice, selected, action, ctx, custom) -> bool:
    player = state.player(custom["user"])
    source = choice.cont_source_pokemon
    pool = list(custom["pool"])
    if source is None or not selected or not pool:
        return False
    eid = pool.pop(0)
    idx = choice.source_indices[selected[0]]
    if eid in source.attached_energy and idx < len(player.bench):
        source.attached_energy.remove(eid)
        player.bench[idx].attached_energy.append(eid)
    return _distribute_next(state, card_db, custom["user"], source, pool, choice.effect_source)




@dataclass(frozen=True)
class ShuffleHandToBottomThenDraw(Effect):
    """自分の手札をシャッフルして山札の下に置く。そうしたら、n枚引く(手札が0枚なら何も置けないので引かない)。"""

    n: int = 1

    def execute(self, ctx: EffectContext) -> None:
        player = _attacker_player(ctx)
        if not player.hand:
            return
        returned = list(player.hand)
        player.hand = []
        ctx.rng.shuffle(returned)
        player.deck.extend(returned)
        for _ in range(self.n):
            if player.deck:
                player.hand.append(player.deck.pop(0))
        ctx.log("手札を山札の下に置いて、引いた")


@dataclass(frozen=True)
class DrawMoreIfSelfActive(Effect):
    """base枚引く。このポケモンがバトル場にいるなら、さらにextra枚引く(mode="until"なら、手札がbase枚(バトル場ならextra枚)になるまで引く)。"""

    base: int
    extra: int
    mode: str = "draw"

    def execute(self, ctx: EffectContext) -> None:
        player = _attacker_player(ctx)
        active = ctx.source_pokemon is not None and ctx.source_pokemon is player.active
        if self.mode == "until":
            target = self.extra if active else self.base
            while len(player.hand) < target and player.deck:
                player.hand.append(player.deck.pop(0))
            return
        for _ in range(self.base + (self.extra if active else 0)):
            if player.deck:
                player.hand.append(player.deck.pop(0))


@dataclass(frozen=True)
class InflictStatusOnBothActive(Effect):
    """おたがいのバトルポケモンを、statuses(のすべて)にする。"""

    statuses: tuple

    def execute(self, ctx: EffectContext) -> None:
        from effects.primitives import _apply_condition

        for idx in (ctx.acting_player, ctx.opponent):
            active = ctx.state.player(idx).active
            if active is None:
                continue
            if idx == ctx.opponent and _defender_blocks_effect(ctx, active):
                continue
            for s in self.statuses:
                _apply_condition(active, s)


@dataclass(frozen=True)
class HealAllEvolutionsDiscardEnergy(Effect):
    """自分の進化ポケモン全員のダメージを全て回復する。回復したポケモンについているエネルギーは全てトラッシュする。"""

    def execute(self, ctx: EffectContext) -> None:
        player = _attacker_player(ctx)
        for mon in player.all_pokemon_in_play():
            card = ctx.card_db.get(mon.card_id)
            if card is None or card.is_basic or mon.damage <= 0:
                continue
            mon.heal(mon.damage)
            player.discard.extend(mon.attached_energy)
            mon.attached_energy = []
        ctx.log("自分の進化ポケモンのダメージを全て回復し、エネルギーをトラッシュした")


@dataclass(frozen=True)
class MillTopThenAttachEnergy(Effect):
    """自分の山札の上を1枚トラッシュする。それが条件(kind: "basic_energy"/"Water"等の基本エネルギーのタイプ)に合うエネルギーなら、自分のポケモン1匹につける。"""

    kind: str = "basic_energy"

    def execute(self, ctx: EffectContext) -> None:
        player = _attacker_player(ctx)
        if not player.deck:
            return
        card_id = player.deck.pop(0)
        card = ctx.card_db.get(card_id)
        ok = card is not None and card.is_energy and not card.is_special_energy and (self.kind == "basic_energy" or card.basic_energy_type == self.kind)
        if not ok:
            player.discard.append(card_id)
            return
        slots = [(0, player.active)] if player.active is not None else []
        slots += [(i + 1, m) for i, m in enumerate(player.bench)]
        if len(slots) == 1:
            slots[0][1].attached_energy.append(card_id)
            return
        labels = [(ctx.card_db.get(m.card_id).name if ctx.card_db.get(m.card_id) else m.card_id) for _s, m in slots]
        ctx.state.pending_search_choice = PendingSearchChoice(
            player_index=ctx.acting_player, zone="gen_pokemon_pick", source_indices=[s for s, _m in slots], card_ids=labels, min_count=1, max_count=1,
            prompt="山札からトラッシュしたエネルギーをつける自分のポケモンを選ぶ", shuffle_after=False, all_card_ids=labels,
            custom_data={"op": "k_attach_milled", "card_id": card_id, "user": ctx.acting_player}, effect_source=ctx.effect_source, cont_acting_player=ctx.acting_player,
        )


def _op_attach_milled(state, card_db, choice, selected, action, ctx, custom) -> bool:
    from effects.era_primitives_b import _mon_at

    player = state.player(custom["user"])
    target = _mon_at(player, choice.source_indices[selected[0]]) if selected else None
    if target is not None:
        target.attached_energy.append(custom["card_id"])
    else:
        player.discard.append(custom["card_id"])
    return False


@dataclass(frozen=True)
class SearchDeckPutOnTop(Effect):
    """山札から条件(SearchDeckMultiCriteriaの条件名)に合うカードを1枚探し、山札をシャッフルして、そのカードを山札の一番上に置く。"""

    criterion: str = "any"

    def execute(self, ctx: EffectContext) -> None:
        from effects.primitives import SearchDeckMultiCriteria

        player = _attacker_player(ctx)
        eligible = [i for i, cid in enumerate(player.deck) if (c := ctx.card_db.get(cid)) is not None and (self.criterion == "any" or SearchDeckMultiCriteria._matches(c, self.criterion))]
        if not eligible:
            ctx.rng.shuffle(player.deck)
            return
        ctx.state.pending_search_choice = PendingSearchChoice(
            player_index=ctx.acting_player, zone="gen_deck_pick", source_indices=eligible, card_ids=[player.deck[i] for i in eligible], min_count=1, max_count=1,
            prompt="山札から1枚選んで、シャッフルしたあと山札の一番上に置く", shuffle_after=False, all_card_ids=list(player.deck),
            custom_data={"op": "k_search_to_top"}, effect_source=ctx.effect_source, cont_acting_player=ctx.acting_player,
        )


def _op_search_to_top(state, card_db, choice, selected, action, ctx, custom) -> bool:
    player = state.player(choice.player_index)
    if not selected:
        state.rng.shuffle(player.deck)
        return False
    card_id = player.deck.pop(choice.source_indices[selected[0]])
    state.rng.shuffle(player.deck)
    player.deck.insert(0, card_id)
    return False




@dataclass(frozen=True)
class MoveEnergyToSelfFromOthers(Effect):
    """自分の他のポケモンについているエネルギー(energy_typeを指定するとそのタイプの基本エネルギーだけ)を、好きなだけ(選んで)このポケモンに移す。
    switch_first=Trueなら先にこのポケモンをバトルポケモンと入れ替え(ベンチにいるとき)、switch_if_moved=Trueなら1枚でも移したときだけ、あとで入れ替える。"""

    energy_type: str | None = None
    switch_first: bool = False
    switch_if_moved: bool = False

    def execute(self, ctx: EffectContext) -> None:
        player = _attacker_player(ctx)
        mon = ctx.source_pokemon
        if mon is None:
            return
        if self.switch_first:
            _switch_self_to_active(player, mon)
        self._offer(ctx, player, mon)

    def _offer(self, ctx, player, mon) -> None:
        cands = []
        for slot, other in _slots_of(player):
            if other is mon:
                continue
            for i, eid in enumerate(other.attached_energy):
                c = ctx.card_db.get(eid)
                if c is not None and (self.energy_type is None or c.basic_energy_type == self.energy_type):
                    cands.append((slot, i, eid))
        if not cands:
            return
        labels = [(ctx.card_db.get(eid).name if ctx.card_db.get(eid) else eid) for _s, _i, eid in cands]
        ctx.state.pending_search_choice = PendingSearchChoice(
            player_index=ctx.acting_player, zone="gen_pokemon_pick", source_indices=list(range(len(cands))), card_ids=labels, min_count=0, max_count=len(cands),
            prompt="このポケモンに移すエネルギーを選ぶ(選ばなくてもよい)", shuffle_after=False, all_card_ids=labels,
            custom_data={"op": "k_move_energy_to_self", "cands": cands, "switch_if_moved": self.switch_if_moved, "user": ctx.acting_player},
            effect_source=ctx.effect_source, cont_acting_player=ctx.acting_player, cont_source_pokemon=mon,
        )


def _slots_of(player):
    out = []
    if player.active is not None:
        out.append((0, player.active))
    out += [(i + 1, m) for i, m in enumerate(player.bench)]
    return out


def _switch_self_to_active(player, mon) -> bool:
    if mon is player.active or mon not in player.bench or player.active is None:
        return False
    old = player.active
    player.bench.remove(mon)
    old.status.clear_all()
    player.bench.append(old)
    mon.status.clear_all()
    mon.became_active_turn = player.turns_taken
    player.active = mon
    return True


def _op_move_energy_to_self(state, card_db, choice, selected, action, ctx, custom) -> bool:
    player = state.player(custom["user"])
    mon = choice.cont_source_pokemon
    if mon is None:
        return False
    moved = 0
    by_slot = {}
    for sel in selected:
        slot, _i, eid = custom["cands"][sel]
        by_slot.setdefault(slot, []).append(eid)
    for slot, eids in by_slot.items():
        holder = player.active if slot == 0 else (player.bench[slot - 1] if 0 < slot <= len(player.bench) else None)
        if holder is None or holder is mon:
            continue
        for eid in eids:
            if eid in holder.attached_energy:
                holder.attached_energy.remove(eid)
                mon.attached_energy.append(eid)
                moved += 1
    if custom.get("switch_if_moved") and moved:
        _switch_self_to_active(player, mon)
    return False


@dataclass(frozen=True)
class DrawUntilHandEqualsCount(Effect):
    """手札が、数える物(COUNTERSの名前+引数)の数になるまで引く。"""

    counter: str
    arg: str = ""

    def execute(self, ctx: EffectContext) -> None:
        from effects.era_attacks_i import count_of

        player = _attacker_player(ctx)
        target = count_of(ctx, self.counter, self.arg)
        while len(player.hand) < target and player.deck:
            player.hand.append(player.deck.pop(0))


def register_ops() -> None:
    from effects.era_primitives_b import GENERIC_OP_HANDLERS

    GENERIC_OP_HANDLERS.update({
        "k_move_energy_to_self": _op_move_energy_to_self,
        "k_self_counters": _op_self_counters, "k_distribute_energy": _op_distribute_energy,
        "k_attach_milled": _op_attach_milled, "k_search_to_top": _op_search_to_top,
    })


register_ops()
_ = (_defender, _defender_blocks_effect)
