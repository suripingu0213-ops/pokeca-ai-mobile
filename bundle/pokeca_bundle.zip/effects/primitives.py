"""カード効果を組み立てるための汎用プリミティブ。

各プリミティブは `execute(ctx)` を持ち、GameStateを直接書き換える。
カードごとの効果は `effects/registry.py` でこれらを組み合わせて表現する。
"""

from __future__ import annotations

from dataclasses import dataclass, field, replace

from cards.card_db import TEAM_ROCKETS_NAME_PREFIX, card_has_subtype, is_team_rockets_pokemon
from effects.context import EffectContext
from engine.continuous import (
    ability_holders_in_play,
    ability_suppressed,
    attack_effects_blocked_by_mystic_heart,
    effective_attacker_types,
    lesson_in_zeal_reduction,
    lightning_symbol_bonus_damage,
    psychic_weakness_ignored,
    status_conditions_blocked,
    adrena_power_bonus_damage,
    basic_only_bonus_damage,
    effective_max_hp,
    ex_attacker_no_rule_box_bonus_damage,
    ex_exclusive_bonus_damage,
    fighting_pokemon_flat_bonus_damage,
    fighting_stadium_ex_bonus_damage,
    flat_bonus_damage,
    black_belt_training_bonus_damage,
    future_bonus_damage,
    fusion_strike_damage_bonus,
    gx_ex_attacker_damage_reduction,
    kieran_ex_v_bonus_damage,
    team_plasma_power_connect_bonus_damage,
    gx_ex_bonus_damage,
    modern_ex_bonus_damage,
    poisoned_self_bonus_damage,
    prize_lead_bonus_damage,
    tools_disabled,
    v_bonus_damage,
    wild_growth_active,
)
from engine.damage import calculate_damage
from engine.energy import BEAST_ENERGY_ID, DOUBLE_TURBO_ENERGY_ID, energy_effect_present, total_points
from engine.state import MAX_BENCH_SIZE, discard_attached_tool, PendingDamageDistribution, PendingSearchChoice, PlayerState, PokemonInPlay
from engine.status import ExclusiveCondition


class Effect:
    def execute(self, ctx: EffectContext) -> None:  # pragma: no cover - interface
        raise NotImplementedError


def _defender(ctx: EffectContext) -> tuple[PlayerState, PokemonInPlay | None]:
    player = ctx.state.player(ctx.opponent)
    return player, player.active


def _attacker_player(ctx: EffectContext) -> PlayerState:
    return ctx.state.player(ctx.acting_player)


def _is_second_players_first_turn(ctx: EffectContext) -> bool:
    """「後攻1ターン目」判定(ボルケニオンの「かえんスタート」、エネルギースピナー等)。"""
    return (
        ctx.acting_player == 1 - ctx.state.first_player
        and ctx.state.player(ctx.acting_player).turns_taken == 1
    )


def _is_acting_players_first_turn(ctx: EffectContext) -> bool:
    """「自分の最初の番」判定(リーリエの「6枚まで引く、自分の最初の番なら8枚まで」等)。
    先攻/後攻を問わず、そのプレイヤー自身の1ターン目かどうかで判定する。"""
    return ctx.state.player(ctx.acting_player).turns_taken == 1


# ---- 常時効果によるダメージ増減(どうぐ・相性免疫・スタジアム) ----

# 被ダメージを軽減するどうぐ(タイプ限定あり、Noneならタイプ問わず)
_FLAT_DAMAGE_REDUCTION_TOOLS: dict[str, tuple[int, str | None]] = {
    "sm9-148": (30, "Metal"),  # メタルゴーグル: 鋼ポケモン限定で-30(かつダメカンをのせる非ダメージ効果も防ぐ)
}

# ダメカン付与を防ぐ効果を持たない、ワザダメージのみを軽減するどうぐ(かたいおまもり等)。
_ATTACK_DAMAGE_ONLY_REDUCTION_TOOLS: dict[str, tuple[int, str | None]] = {
    "xy1-119": (20, None),  # かたいおまもり(Hard Charm): タイプ問わず-20
}

# 攻撃してきたポケモンが特性を持っていれば軽減するどうぐ(Sacred Charm実カードテキスト: "The
# Pokémon this card is attached to takes 30 less damage from attacks from your opponent's Pokémon
# that have an Ability (after applying Weakness and Resistance)."用)。
_ATTACKER_HAS_ABILITY_DAMAGE_REDUCTION_TOOLS: dict[str, int] = {
    "me2-122": 30,  # 女神のお守り(Sacred Charm)
    "me2-93": 30,  # 女神のお守り 別絵柄
}

# 防御側の指定タイプ限定・攻撃側の指定タイプ群限定で軽減するどうぐ(Thick Scale実カードテキスト:
# "The Dragon Pokémon this card is attached to takes 50 less damage from attacks from your
# opponent's Grass, Fire, Water, or Lightning Pokémon (after applying Weakness and Resistance)."用)。
_DEFENDER_TYPE_VS_ATTACKER_TYPES_DAMAGE_REDUCTION_TOOLS: dict[str, tuple[int, str, frozenset[str]]] = {
    "me2pt5-211": (50, "Dragon", frozenset({"Grass", "Fire", "Water", "Lightning"})),  # 厚いウロコ(Thick Scale)
}

# 満タンHPからワザのダメージできぜつする一撃を、残りHP10で耐えるどうぐ(対象タイプ限定あり)。
# 効果を使ったら、どうぐ自身はトラッシュされる。
def era_tools_j_survives(tool) -> bool:
    from effects.era_tools_j import survives_lethal_at_full_hp

    return survives_lethal_at_full_hp(tool)


_SURVIVE_LETHAL_HIT_TOOLS: dict[str, str] = {
    "xy3-91": "Fighting",  # きあいのタスキ(Focus Sash): 闘ポケモン限定
}

# ワザのダメージを1回だけ軽減し、そのあとどうぐ自身がトラッシュされる使い切りのどうぐ(ウタンのみ等)。
_ONE_SHOT_FLAT_DAMAGE_REDUCTION_TOOLS: dict[str, int] = {
    "sv-stellarmiracle-92": 60,  # ウタンのみ(Utan's Berry)
}
# 上記のうち、特定のタイプの攻撃側ポケモンからのダメージだけを軽減するもの。ウタンのみは公式サイトの生HTMLで
# 「相手の{超}ポケモンからワザのダメージを受けるとき-60」と判明(タイプはicon-psychicのspanで、テキスト抽出では
# 「相手のワザのダメージを受けるとき」としか見えず、超ポケモン限定が抜け落ちていた、2026-10-06訂正)。
_ONE_SHOT_FLAT_DAMAGE_REDUCTION_ATTACKER_TYPE: dict[str, str] = {
    "sv-stellarmiracle-92": "Psychic",
}

# どうぐではなく、そのポケモン自身が持つ常時発動の特性による固定ダメージ軽減(発動条件なし、
# 場に出ているだけでずっと有効。メガディアンシーex「Diamond Coat」実カードテキスト: "This
# Pokémon takes 30 less damage from attacks (after applying Weakness and Resistance)."用)。
_INNATE_DAMAGE_REDUCTION_ABILITY_IDS: dict[str, int] = {
    "me2pt5-267": 30,  # メガディアンシーex
    "me2pt5-282": 30,  # メガディアンシーex 別絵柄
    "rsv10pt5-162": 30,  # バッフロンex(Bouffalant ex)「Bouffer」
    "rsv10pt5-170": 30,  # バッフロンex 別絵柄
    "rsv10pt5-77": 30,  # バッフロンex 別絵柄
    "sv10-108": 30,  # バリコオル(Mudsdale)「Mud Coat」
}

# エネルギーが1枚でもついていれば発動する固定ダメージ軽減(レジロック(Regirock)特性「Rock Armor」
# 実カードテキスト: "If this Pokémon has any Energy attached, it takes 30 less damage from attacks
# (after applying Weakness and Resistance)."用)。
_SELF_ENERGY_CONDITIONAL_DAMAGE_REDUCTION_IDS: dict[str, int] = {
    "sv9-82": 30,
}

# 満タンHPからワザのダメージできぜつする一撃を、残りHP10で耐えるポケモン自身の特性(道具ではない、
# コイン判定なし、消費もされない常時効果)。
_SURVIVE_LETHAL_HIT_AT_FULL_HP_ABILITY_IDS: set[str] = {
    "zsv10pt5-52",  # イワパレス(Crustle)「Sturdy」
    "zsv10pt5-130",  # イワパレス(Crustle)「Sturdy」別絵柄(zsv10pt5-52と完全同一テキスト)
}

# きぜつする一撃をコイン判定(表)で残りHP10まで耐える特性。Sturdyと異なり満タンHP限定ではなく
# (現在のダメカン量に関わらず適用)、コインが必要(メガウォーグルex「Tenacious Body」実カード
# テキスト: "If this Pokémon would be Knocked Out by damage from an attack, flip a coin. If heads,
# this Pokémon is not Knocked Out, and its remaining HP becomes 10."用)。
_COINFLIP_SURVIVE_LETHAL_HIT_ABILITY_IDS: set[str] = {
    "me2pt5-116",  # メガウォーグルex(Mega Hawlucha ex)「Tenacious Body」
}

# 満タンHPのVポケモンについていて、相手のワザによってきぜつさせられたとき、攻撃したポケモンに
# ダメカンをのせる反撃どうぐ(値はダメカンの個数)。
_RETALIATE_ON_FULL_HP_KO_TOOLS: dict[str, int] = {
    "swsh11-154": 8,  # 災いの箱(Box of Disaster)
}

# 特定タイプ/サブタイプの攻撃側からのダメージを完全無効化するポケモン
_FULL_DAMAGE_IMMUNITY_VS_TYPE: dict[str, str] = {
    "sm9-101": "Fire",  # ドータクン「Heatproof」
    "sm3-63": "Colorless",  # ネクロズマGX「Light's End」
}
_FULL_DAMAGE_IMMUNITY_VS_SUBTYPE: dict[str, str] = {
    "swsh1-139": "VMAX",  # ザマゼンタV「Dauntless Shield」
    "bw10-20": "EX",  # スイクン「Safeguard」
    "sv9a-67": "ex",  # イワパレス(Crustle、SV9a067/063)「しんぴのいしやど」: 相手のポケモンexからのワザダメージを受けない
    "sv10-12": "ex",  # イワパレス(Crustle)「Mysterious Rock Inn」別絵柄
    "sv10-186": "ex",  # イワパレス(Crustle)「Mysterious Rock Inn」別絵柄
}
# 「特殊エネルギーがついている相手のポケモンからのワザによるダメージを受けない」ポケモン
_FULL_DAMAGE_IMMUNITY_VS_ATTACKER_SPECIAL_ENERGY: set[str] = {
    "smp-SM68",  # デンジュモクGX「Flashing Head」
    "xy4-65",  # Aegislash-EX「Mighty Shield」
}

_MARTIAL_ARTS_DOJO_ID = "sm10-179"  # 格闘道場
_PARALLEL_CITY_ID = "xy8-145"  # パラレルシティ
_TOOL_JAMMER_ID = "swsh5-136"  # ツールジャマー(Tool Jammer): 自分がバトル場にいる間、相手のバトル場の
# ポケモンについているどうぐ(ツールジャマー自身を除く)を無効化する


def _apply_attacker_side_damage_modifiers(ctx: EffectContext, defender: PokemonInPlay, defender_card, damage: int) -> int:
    """公式ルール上のダメージ計算手順「2. ダメージを与えるポケモンが受けている効果」: 弱点・抵抗力を
    計算する前に、攻撃側にかかっている常時効果(げんきのハチマキ等の固定ダメージ増加、道場系スタジアム等)
    を適用する。以前はこれらを弱点・抵抗力の後に適用していたため、弱点が乗る組み合わせで実際より
    ボーナス分が小さくなるバグがあった(上級プレイヤー用ルールガイドB-04で明記されている順序に合わせて修正)。"""
    if ctx.source_pokemon is None or damage <= 0:
        return damage
    attacker_card = ctx.card_db.get(ctx.source_pokemon.card_id)
    if attacker_card is None:
        return damage

    stadium_in_play = ctx.state.stadium_in_play
    attacker_owner = ctx.state.player(ctx.acting_player)
    defender_owner = ctx.state.player(ctx.opponent)

    # ツールジャマー: 自分のバトル場のポケモンにツールジャマーがついていれば、相手のバトル場の
    # ポケモンのどうぐ(ツールジャマー自身を除く)は効果を持たない。
    attacker_tool = ctx.source_pokemon.attached_tool
    if (
        attacker_tool is not None
        and attacker_tool != _TOOL_JAMMER_ID
        and ctx.source_pokemon is attacker_owner.active
        and defender_owner.active is not None
        and defender_owner.active.attached_tool == _TOOL_JAMMER_ID
    ):
        attacker_tool = None

    if defender is defender_owner.active:  # つよいちからのハチマキ等: 相手のバトル場のGX/EXにのみ追加ダメージ
        bonus_until = ctx.source_pokemon.attack_bonus_until_turn
        if (
            bonus_until > 0
            and attacker_owner.turns_taken == bonus_until
            and (
                not ctx.source_pokemon.attack_bonus_attack_name
                or ctx.source_pokemon.attack_bonus_attack_name == ctx.source_pokemon.current_attack_name
            )
        ):
            damage += ctx.source_pokemon.attack_bonus_amount  # 「自分の次の番、このポケモンのワザは+N」(Echoed Voice等)
        damage += gx_ex_bonus_damage(attacker_tool, defender_card)
        damage += fighting_pokemon_flat_bonus_damage(ctx.state, ctx.acting_player, ctx.source_pokemon, attacker_card)
        damage += team_plasma_power_connect_bonus_damage(attacker_owner, ctx.source_pokemon, attacker_card)
        damage += lightning_symbol_bonus_damage(ctx.state, ctx.card_db, ctx.acting_player, attacker_card)
        damage += fusion_strike_damage_bonus(attacker_owner, attacker_card)
        damage += flat_bonus_damage(attacker_tool)
        damage += basic_only_bonus_damage(attacker_tool, attacker_card)
        damage += ex_exclusive_bonus_damage(attacker_tool, attacker_card, defender_card)
        damage += modern_ex_bonus_damage(attacker_tool, defender_card)
        damage += v_bonus_damage(attacker_tool, defender_card)
        damage += kieran_ex_v_bonus_damage(attacker_owner, defender_card, True)
        damage += black_belt_training_bonus_damage(attacker_owner, defender_card, True)
        damage += attacker_owner.damage_bonus_flat_this_turn  # プラスパワー
        damage += attacker_owner.damage_bonus_per_prize_this_turn * max(0, 6 - len(defender_owner.prizes))  # アイリス
        from effects.era_trainers import era_tool_attack_bonus

        damage += era_tool_attack_bonus(ctx, attacker_tool, attacker_card, defender_card)  # あくのツメ/クリスタルエッジ
        from effects.era_trainers import era_energy_attack_bonus

        damage += era_energy_attack_bonus(ctx, ctx.source_pokemon, attacker_card)  # (旧)あくエネルギー
        from effects.era_primitives_f import era_attacker_bonus
        from effects.era_trainers import era_stadium_attack_bonus

        damage += era_attacker_bonus(ctx, ctx.source_pokemon, attacker_owner)  # Dragon Dance
        damage += era_stadium_attack_bonus(ctx.state, ctx.acting_player, attacker_card)  # リバースバレー
        damage += prize_lead_bonus_damage(attacker_tool, attacker_owner, defender_owner)
        damage += poisoned_self_bonus_damage(attacker_tool, ctx.source_pokemon.status.poisoned)
        damage += fighting_stadium_ex_bonus_damage(stadium_in_play, attacker_card, defender_card)
        damage += adrena_power_bonus_damage(ctx.card_db, ctx.source_pokemon, attacker_card)
        damage += future_bonus_damage(attacker_tool, attacker_card)
        damage += ex_attacker_no_rule_box_bonus_damage(attacker_tool, attacker_card, defender_card)
        if energy_effect_present(ctx.source_pokemon.attached_energy, BEAST_ENERGY_ID) and "Ultra Beast" in attacker_card.subtypes:
            # ビーストエネルギー◇: ついているウルトラビーストのワザは相手のバトルポケモンに+30ダメージ
            damage += 30
        from engine.energy import VOLTAIC_LIGHTNING_ENERGY_ID

        if energy_effect_present(ctx.source_pokemon.attached_energy, VOLTAIC_LIGHTNING_ENERGY_ID) and "Lightning" in attacker_card.types:
            # Voltaic Lightning Energy実カードテキスト: "Attacks used by the Lightning Pokémon this
            # card is attached to do 20 more damage to your opponent's Active Pokémon."
            damage += 20
        damage += _named_prefix_team_ability_bonus_damage(attacker_owner, attacker_card)
        damage += _name_prefix_tool_bonus_damage(attacker_tool, attacker_card)
        damage += _team_wide_attack_bonus_damage(attacker_owner)
        from effects.passives import attacker_passive_bonus

        damage += attacker_passive_bonus(ctx, defender, defender_card, attacker_card)
        self_damaged_bonus = _SELF_DAMAGED_BONUS_DAMAGE_ABILITY_IDS.get(ctx.source_pokemon.card_id)
        if self_damaged_bonus is not None:
            min_damage, bonus = self_damaged_bonus
            if ctx.source_pokemon.damage >= min_damage:
                damage += bonus
        if stadium_in_play == "sv9-154" and attacker_card.name.startswith("Hop's"):
            # ポストタウン(Postwick)実カードテキスト: "Attacks used by Hop's Pokémon (both yours and
            # your opponent's) do 30 more damage to the opponent's Active Pokémon..."
            damage += 30

    if stadium_in_play == _MARTIAL_ARTS_DOJO_ID and "Ultra Beast" not in attacker_card.subtypes:
        has_fighting_energy = any(
            (e_card := ctx.card_db.get(e)) is not None and e_card.basic_energy_type == "Fighting"
            for e in ctx.source_pokemon.attached_energy
        )
        if has_fighting_energy:
            bonus = 40 if len(attacker_owner.prizes) > len(defender_owner.prizes) else 10
            damage += bonus

    if (
        stadium_in_play == _PARALLEL_CITY_ID
        and ctx.state.stadium_orientation_target == ctx.acting_player
        and {"Grass", "Fire", "Water"} & set(attacker_card.types)
    ):
        # パラレルシティ: 出すときに選んだ「↓」側のプレイヤーの、くさ/ほのお/みずポケモンのワザ
        # ダメージが-20される(選んだ側が自分でも相手でもよい)。
        damage = max(0, damage - 20)

    if energy_effect_present(ctx.source_pokemon.attached_energy, DOUBLE_TURBO_ENERGY_ID):
        # ダブルターボエネルギー: ついているポケモンのワザは相手のポケモンに与えるダメージが20少なくなる。
        damage = max(0, damage - 20)

    if (
        ctx.source_pokemon.outgoing_damage_debuff_until_turn > 0
        and attacker_owner.turns_taken <= ctx.source_pokemon.outgoing_damage_debuff_until_turn
    ):
        # チコリータの「Growl」等: 相手の次の番の間、このポケモンが使うワザのダメージが少なくなる。
        damage = max(0, damage - ctx.source_pokemon.outgoing_damage_debuff_amount)
    from effects.passives import attack_damage_reduction_from_opponent

    if defender is defender_owner.active:
        damage = max(0, damage - attack_damage_reduction_from_opponent(ctx, attacker_card))  # Intimidating Fang等
    from effects.era_energy_g import shield_energy_reduction

    damage = max(0, damage - shield_energy_reduction(defender, defender_card))  # シールドエネルギー

    return max(0, damage)


def _bench_pokemon_damage_immune(defender_card, owner: PlayerState, ctx: "EffectContext | None" = None) -> bool:
    """ベンチにいるポケモンへのワザダメージを完全に防ぐ常時効果(テラスタルのルール箱、バリヤード
    「Bench Barrier」、シェイミ「はなのカーテン」)。通常のDealDamage系(resolve_attack_damage経由)と、
    DealFixedDamageToAllOpponentBenchedPokemon等の「弱点・抵抗力を計算しないスプレッドダメージ」系の
    両方から呼ばれる共通判定(以前は前者からしか呼ばれておらず、後者がこれらのバリアを無視してしまう
    バグがあった)。"""
    from effects.era_trainers import era_bench_damage_prevented

    if ctx is not None:
        bound_state = ctx.state
    else:
        from engine.energy import current_state

        bound_state = current_state()
    if bound_state is not None and era_bench_damage_prevented(bound_state):
        return True  # マウンテンリング
    if "Tera" in defender_card.subtypes:
        # テラスタルポケモンのルール箱(全Teraカード共通の印刷済みルールテキスト、カード固有の
        # 特性ではない): "As long as this Pokemon is on your Bench, prevent all damage done to
        # this Pokemon by attacks (both yours and your opponent's)."(2026-08-22訂正: 以前は
        # みずまとうのおめん オーガポンexだけのカード固有特性として_SELF_BENCH_DAMAGE_IMMUNITY_IDS
        # にハードコードしており、いしずえのおめん オーガポンex/テラパゴスex等の他のTeraカードに
        # 適用されない誤りがあった。全Teraポケモン共通のルールとして扱うよう修正)。
        return True
    def holder_active(mon) -> bool:
        # ctxがあれば、持ち主のポケモン自身の特性が封じられていないことも確認する
        if ctx is None:
            return True
        owner_index = 0 if owner is ctx.state.players[0] else 1
        return not ability_suppressed(ctx.state, ctx.card_db, owner_index, mon)

    if any(mon.card_id in _BENCH_BARRIER_IDS and holder_active(mon) for mon in owner.all_pokemon_in_play()):
        # バリヤード「Bench Barrier」実カードテキスト: "Prevent all damage done to your Benched
        # Pokémon by attacks."(ワザによるダメージのみが対象)。DistributeDamageCountersFreely等の
        # 「ダメカンを直接のせる」効果(ワザ以外の効果として発生するもの)は元々このバリア判定を
        # 経由しないため対象外で正しい(ここが未対応というのは誤ったコメントだったため訂正)。
        return True
    if not (_RULE_BOX_SUBTYPES & set(defender_card.subtypes)) and any(
        mon.card_id in _BENCH_BARRIER_EXCLUDING_RULE_BOX_IDS and holder_active(mon) for mon in owner.all_pokemon_in_play()
    ):
        # シェイミ「はなのカーテン」: バリヤードと違い、ルール箱を持つポケモン(ex/V等)は対象外。
        return True
    return False


def _self_bench_full_immunity(defender: PokemonInPlay) -> bool:
    return defender.card_id in _SELF_BENCH_FULL_IMMUNITY_IDS


def _apply_defender_side_damage_modifiers(ctx: EffectContext, defender: PokemonInPlay, defender_card, damage: int) -> int:
    """公式ルール上のダメージ計算手順「5. ダメージを受けるポケモンが受けている効果」+ 完全免疫判定:
    弱点・抵抗力を計算した後に、防御側にかかっている常時効果(どうぐによる軽減・シールド・
    完全無効等)を適用する。免疫判定はダメージ量に関わらず先に行う。"""
    if ctx.source_pokemon is None:
        return damage
    attacker_card = ctx.card_db.get(ctx.source_pokemon.card_id)
    if attacker_card is None:
        return damage

    # 防御側ポケモンの特性による免疫・軽減は、その特性が封じられている間(ダストダスの「Garbotoxin」・ひっそりした
    # 山小屋・ヘックスマニアック・キャンセリングコロン等)は働かない(2026-10-06、以前はここで封印を一切見ていなかった)
    defender_abilities_off = ability_suppressed(ctx.state, ctx.card_db, ctx.opponent, defender)
    immune_type = None if defender_abilities_off else _FULL_DAMAGE_IMMUNITY_VS_TYPE.get(defender.card_id)
    if immune_type and immune_type in effective_attacker_types(ctx.state, ctx.card_db, ctx.acting_player, attacker_card):
        return 0
    immune_subtype = None if defender_abilities_off else _FULL_DAMAGE_IMMUNITY_VS_SUBTYPE.get(defender.card_id)
    if immune_subtype and immune_subtype in attacker_card.subtypes:
        return 0
    if (
        not defender_abilities_off
        and defender.card_id in _FULL_DAMAGE_IMMUNITY_VS_ATTACKER_SPECIAL_ENERGY
        and any(
            (e_card := ctx.card_db.get(e)) is not None and e_card.is_special_energy
            for e in ctx.source_pokemon.attached_energy
        )
    ):
        return 0
    if (
        not defender_abilities_off
        and defender.card_id in (_CORNERSTONE_OGERPON_ID, _CORNERSTONE_OGERPON_REPRINT_ID)
        and attacker_card.abilities
    ):
        # いしずえのおめん オーガポンex「Cornerstone Stance」: 特性を持つ相手ポケモンからのワザダメージを
        # 一切受けない(ダストダス「Garbotoxin」等で特性が封じられていても、印刷されたカード自体が
        # 特性を持っていれば対象。実際の判定は「特性が使用可能か」ではなく「カードが特性を持つか」)。
        return 0

    from effects.passives import apply_defender_passives, defender_is_immune

    if defender_is_immune(ctx, defender, attacker_card):
        return 0  # Intimidating Mane/Bright Down/Plasma Steel等(生成されたパッシブ特性、effects/passives.py)
    from effects.era_sm_hooks import tool_prevents_damage

    if not tools_disabled(ctx.state.stadium_in_play) and tool_prevents_damage(ctx, defender, defender_card, attacker_card):
        return 0  # フェアリーチャーム(各種): フェアリーポケモンは、相手の(条件に合う)ポケモンGX/EXのワザのダメージを受けない

    if damage <= 0:
        return damage

    stadium_in_play = ctx.state.stadium_in_play
    defender_owner = ctx.state.player(ctx.opponent)
    attacker_owner = ctx.state.player(ctx.acting_player)

    attacker_tool = ctx.source_pokemon.attached_tool
    if (
        attacker_tool is not None
        and attacker_tool != _TOOL_JAMMER_ID
        and ctx.source_pokemon is attacker_owner.active
        and defender_owner.active is not None
        and defender_owner.active.attached_tool == _TOOL_JAMMER_ID
    ):
        attacker_tool = None
    defender_tool = defender.attached_tool
    if (
        defender_tool is not None
        and defender_tool != _TOOL_JAMMER_ID
        and defender is defender_owner.active
        and attacker_owner.active is not None
        and attacker_owner.active.attached_tool == _TOOL_JAMMER_ID
    ):
        defender_tool = None

    if not tools_disabled(stadium_in_play) and defender_tool in _FLAT_DAMAGE_REDUCTION_TOOLS:
        amount, required_type = _FLAT_DAMAGE_REDUCTION_TOOLS[defender_tool]
        if required_type is None or required_type in defender_card.types:
            damage = max(0, damage - amount)
    from effects.era_trainers import era_defender_tool_reduction

    damage = max(0, damage - era_defender_tool_reduction(ctx.state, defender_tool, defender_card, ctx.source_pokemon, ctx.card_db))  # しんかのきせき/アサルトベスト
    from effects.era_trainers import era_stadium_damage_reduction

    damage = max(0, damage - era_stadium_damage_reduction(ctx.state, ctx.opponent, defender_card))  # リバースバレー
    if not tools_disabled(stadium_in_play) and defender_tool in _ATTACK_DAMAGE_ONLY_REDUCTION_TOOLS:
        amount, required_type = _ATTACK_DAMAGE_ONLY_REDUCTION_TOOLS[defender_tool]
        if required_type is None or required_type in defender_card.types:
            damage = max(0, damage - amount)
    if (
        not tools_disabled(stadium_in_play)
        and defender_tool in _ATTACKER_HAS_ABILITY_DAMAGE_REDUCTION_TOOLS
        and attacker_card.abilities
    ):
        damage = max(0, damage - _ATTACKER_HAS_ABILITY_DAMAGE_REDUCTION_TOOLS[defender_tool])
    if not tools_disabled(stadium_in_play) and defender_tool in _DEFENDER_TYPE_VS_ATTACKER_TYPES_DAMAGE_REDUCTION_TOOLS:
        amount, required_defender_type, allowed_attacker_types = _DEFENDER_TYPE_VS_ATTACKER_TYPES_DAMAGE_REDUCTION_TOOLS[defender_tool]
        if required_defender_type in defender_card.types and allowed_attacker_types & set(attacker_card.types):
            damage = max(0, damage - amount)
    if not tools_disabled(stadium_in_play):
        damage = max(0, damage - gx_ex_attacker_damage_reduction(defender_tool, attacker_card))

    if (
        not tools_disabled(stadium_in_play)
        and defender_tool in _ONE_SHOT_FLAT_DAMAGE_REDUCTION_TOOLS
        and _ONE_SHOT_FLAT_DAMAGE_REDUCTION_ATTACKER_TYPE.get(defender_tool, None) in (
            None, *effective_attacker_types(ctx.state, ctx.card_db, ctx.acting_player, attacker_card)
        )
    ):
        # ウタンのみ等: ダメージを軽減したら、どうぐ自身はトラッシュされる(使い切り)。
        damage = max(0, damage - _ONE_SHOT_FLAT_DAMAGE_REDUCTION_TOOLS[defender_tool])
        discard_attached_tool(ctx.state, defender_owner, defender)
        ctx.log(f"{defender.card_id} はどうぐの効果でダメージを軽減し、どうぐがトラッシュされた")

    if defender_owner.metal_damage_reduction_active and "Metal" in defender_card.types:
        # フルメタルウォールGX: 今後ずっと自分の鋼ポケモンが受けるダメージ-30(ターン限定のダメージ軽減とは別枠の永続効果)
        damage = max(0, damage - 30)

    innate_reduction = None if defender_abilities_off else _INNATE_DAMAGE_REDUCTION_ABILITY_IDS.get(defender.card_id)
    if innate_reduction:
        damage = max(0, damage - innate_reduction)

    energy_conditional_reduction = (
        None if defender_abilities_off else _SELF_ENERGY_CONDITIONAL_DAMAGE_REDUCTION_IDS.get(defender.card_id)
    )
    if energy_conditional_reduction and defender.attached_energy:
        damage = max(0, damage - energy_conditional_reduction)

    if defender is not defender_owner.active and (
        _bench_pokemon_damage_immune(defender_card, defender_owner, ctx)
        or (not defender_abilities_off and _self_bench_full_immunity(defender))
    ):
        return 0

    required_energy_type = None if defender_abilities_off else _COINFLIP_DAMAGE_PREVENTION_IF_ENERGY_TYPE.get(defender.card_id)
    if required_energy_type and any(
        (e := ctx.card_db.get(cid)) is not None and e.basic_energy_type == required_energy_type
        for cid in defender.attached_energy
    ):
        if ctx.rng.random() < 0.5:
            ctx.log(f"{defender.card_id} は特性「Adrena-Pheromone」のコインが表で出てダメージを防いだ")
            return 0

    reduction = _defender_damage_reduction(ctx, defender)
    if reduction:
        damage = max(0, damage - reduction)
    name_prefix_reduction = _named_prefix_team_defense_reduction(defender_owner, defender_card)
    if name_prefix_reduction:
        damage = max(0, damage - name_prefix_reduction)
    zeal_reduction = lesson_in_zeal_reduction(ctx.state, ctx.card_db, ctx.opponent, defender_card)
    if zeal_reduction:
        damage = max(0, damage - zeal_reduction)
    energy_type_reduction = _energy_type_conditional_team_defense_reduction(ctx, defender, defender_owner)
    if energy_type_reduction:
        damage = max(0, damage - energy_type_reduction)
    damage = apply_defender_passives(ctx, defender, defender_card, attacker_card, damage)
    if damage <= 0:
        return damage

    if (
        not tools_disabled(stadium_in_play)
        and defender.damage == 0
        and defender_card.hp
        and damage >= defender_card.hp
        and era_tools_j_survives(defender_tool)
    ):
        discard_attached_tool(ctx.state, defender_owner, defender)  # しぶとさのバンド(Survival Brace)
        ctx.log(f"{defender.card_id} はどうぐの効果で残りHP10まで耐えた")
        return max(0, defender_card.hp - 10)

    if (
        not tools_disabled(stadium_in_play)
        and defender_tool in _SURVIVE_LETHAL_HIT_TOOLS
        and defender.damage == 0
        and defender_card.hp
        and _SURVIVE_LETHAL_HIT_TOOLS[defender_tool] in defender_card.types
        and damage >= defender_card.hp
    ):
        discard_attached_tool(ctx.state, defender_owner, defender)
        ctx.log(f"{defender.card_id} はどうぐの効果で残りHP10まで耐えた")
        return max(0, defender_card.hp - 10)

    if (
        not defender_abilities_off
        and defender.card_id in _SURVIVE_LETHAL_HIT_AT_FULL_HP_ABILITY_IDS
        and defender.damage == 0
        and defender_card.hp
        and damage >= defender_card.hp
    ):
        ctx.log(f"{defender.card_id} は特性「Sturdy」で残りHP10まで耐えた")
        return max(0, defender_card.hp - 10)

    if (
        not defender_abilities_off
        and defender.card_id in _COINFLIP_SURVIVE_LETHAL_HIT_ABILITY_IDS
        and defender_card.hp
        and defender.damage + damage >= defender_card.hp
    ):
        if ctx.rng.random() < 0.5:
            ctx.log(f"{defender.card_id} は特性「Tenacious Body」のコインが表で出て残りHP10まで耐えた")
            return max(0, defender_card.hp - 10 - defender.damage)
        ctx.log(f"{defender.card_id} は特性「Tenacious Body」のコインが裏で出てきぜつした")

    if (
        not tools_disabled(stadium_in_play)
        and defender_tool in _RETALIATE_ON_FULL_HP_KO_TOOLS
        and defender.damage == 0
        and defender_card.hp
        and "V" in defender_card.subtypes
        and damage >= defender_card.hp
        and not _blocks_damage_counters(ctx.source_pokemon)
    ):
        counters = _RETALIATE_ON_FULL_HP_KO_TOOLS[defender_tool]
        ctx.source_pokemon.damage += counters * 10
        ctx.log(f"{defender.card_id} のどうぐの効果で、攻撃したポケモンにダメカンを{counters}個のせた")

    from effects.era_primitives_f import era_defender_final_damage

    return era_defender_final_damage(ctx, defender, defender_card, damage)  # Bide/Allergic Shock


LILLIE_CLEFAIRY_EX_ID = "sv9-56"  # リーリエのピッピex「Fairy Zone」: 相手のドラゴンポケモンの弱点がすべてエスパーになる(場にいるだけで常時発動、バトル場限定ではない)
LILLIE_CLEFAIRY_EX_REPRINT_IDS = frozenset(
    {"me2pt5-280", "me2pt5-76", "sv9-173", "sv9-184", "svp-195"}
)  # 同カードの別絵柄


def _defender_card_with_field_weakness_overrides(ctx: EffectContext, defender_card, defender=None):
    """はばたくかみ系ではなく、リーリエのピッピexの「Fairy Zone」のように場にいるだけで発動する
    弱点上書き効果を反映したdefender_cardを返す(該当しなければそのまま)。"""
    if defender is not None:
        from effects.era_trainers import era_field_weakness

        defender_card = era_field_weakness(ctx.state, ctx.card_db, defender, defender_card)  # プラズマフリゲート/シャドーサークル/マグネットストーム
        from effects.era_primitives_f import era_weakness_override

        defender_card = era_weakness_override(ctx.state, defender_card, defender)  # Conversion 3/Trick Sticker
    if ability_holders_in_play(ctx.state, ctx.card_db, "Shining Mane", owner_index=ctx.opponent, card_name="Solgaleo-GX"):
        # ソルガレオGX(smp-104)の特性「Shining Mane」(自分のポケモン全員が弱点を持たない)
        return replace(defender_card, weaknesses=())
    if psychic_weakness_ignored(ctx.state, ctx.card_db):
        # ジラーチGX(sm11-79)の特性「Psychic Zone」: おたがいのポケモンは、ワザのダメージを受けるとき
        # エスパーの弱点を計算しない(自分・相手どちらのジラーチGXでも有効)
        defender_card = replace(defender_card, weaknesses=tuple(w for w in defender_card.weaknesses if w.type != "Psychic"))
    from effects.passives import apply_weakness_passives, dragon_weakness_is_psychic

    if defender is not None:
        defender_card = apply_weakness_passives(ctx, defender, defender_card)
        from effects.era_tools_j import weakness_multiplier_override

        defender_card = weakness_multiplier_override(ctx, defender, defender_card)  # ばつぐんメガネ(弱点×3)
    if ctx.source_pokemon is None or "Dragon" not in defender_card.types:
        return defender_card
    attacker_player = ctx.state.player(ctx.acting_player)
    if dragon_weakness_is_psychic(ctx) or any(
        m.card_id == LILLIE_CLEFAIRY_EX_ID or m.card_id in LILLIE_CLEFAIRY_EX_REPRINT_IDS
        for m in attacker_player.all_pokemon_in_play()
    ):
        from cards.models import WeaknessResistance

        return replace(defender_card, weaknesses=(WeaknessResistance(type="Psychic", value="×2"),))
    return defender_card


def _attacker_types_with_override(ctx: EffectContext, types: tuple) -> tuple:
    """Type Switch等で一時的にタイプが変わっているポケモンのタイプ(次の自分の番の終わりまで)。"""
    mon = ctx.source_pokemon
    if mon is not None and mon.type_override and ctx.state.player(ctx.acting_player).turns_taken <= mon.type_override_until_turn:
        return (mon.type_override,)
    if mon is not None:
        from effects.passives import mon_types

        passive_types = mon_types(ctx.state, ctx.card_db, ctx.acting_player, mon)  # Double Type/Dual Armor/Color Change
        base_card = ctx.card_db.get(mon.card_id)
        base_types = tuple(base_card.types) if base_card is not None else ()
        if passive_types and passive_types != base_types:
            # パッシブ特性がタイプを変えている。他の効果(Flare Effect等)が足したタイプはそのまま残す
            return passive_types + tuple(t for t in types if t not in base_types and t not in passive_types)
    return types


def resolve_attack_damage(
    ctx: EffectContext,
    defender: PokemonInPlay,
    defender_card,
    base_amount: int,
    apply_weakness: bool = True,
    apply_resistance: bool = True,
    apply_defender_side_effects: bool = True,
) -> int:
    """公式ルールのダメージ計算手順(1.基本ダメージ→2.攻撃側の効果→3.弱点→4.抵抗力→5.防御側の効果→
    6.最終ダメージ)通りの順番で最終ダメージを算出する共通ヘルパー。ダメージを与えるすべてのEffectは
    calculate_damage/_apply_*_damage_modifiersを個別に呼ぶのではなく、これを経由すること。
    apply_defender_side_effects=Falseにすると手順5(相手のバトルポケモンにかかっている効果による
    軽減・シールド等)を丸ごとスキップする(ミュウツーGXの「Psystrike-GX」実カードテキスト:
    "This attack's damage isn't affected by any effects on your opponent's Active Pokémon."用。
    弱点・抵抗力は「効果」ではなく手順3・4のまま適用される)。"""
    from effects.passives import attacker_passive_flags

    passive_flags = attacker_passive_flags(ctx)
    if passive_flags["ignore_weakness"]:
        apply_weakness = False
    if passive_flags["ignore_resistance"]:
        apply_resistance = False
    if passive_flags["ignore_defender_effects"]:
        apply_defender_side_effects = False
    flagged = ctx.state.player(ctx.acting_player).ignore_defender_effects_subtype_this_turn
    if flagged and ctx.source_pokemon is not None:
        source_card = ctx.card_db.get(ctx.source_pokemon.card_id)
        if source_card is not None and flagged in source_card.subtypes:
            apply_defender_side_effects = False  # ウルトラフォレスト カートボーイ
    from effects.era_trainers import era_tool_wide_lens

    if defender is not ctx.state.player(ctx.opponent).active and era_tool_wide_lens(ctx):
        apply_weakness = apply_resistance = True  # ワイドレンズ: ベンチにも弱点・抵抗力を計算する
    dmg = base_amount
    dmg = _apply_attacker_side_damage_modifiers(ctx, defender, defender_card, dmg)
    if dmg > 0 and ctx.source_pokemon is not None:
        attacker_card = ctx.card_db.get(ctx.source_pokemon.card_id)
        if attacker_card is not None:
            defender_card = _defender_card_with_field_weakness_overrides(ctx, defender_card, defender)
            if (
                defender.no_weakness_until_turn > 0
                and ctx.state.player(ctx.acting_player).turns_taken <= defender.no_weakness_until_turn
            ):
                defender_card = replace(defender_card, weaknesses=())  # 「相手の次の番、このポケモンは弱点を持たない」
            resist_card = defender_card if apply_resistance else replace(defender_card, resistances=())
            dmg = calculate_damage(
                dmg,
                _attacker_types_with_override(ctx, effective_attacker_types(ctx.state, ctx.card_db, ctx.acting_player, attacker_card)),
                resist_card,
                apply_weakness=apply_weakness,
            )
    if apply_defender_side_effects:
        dmg = _apply_defender_side_damage_modifiers(ctx, defender, defender_card, dmg)
        if (
            dmg > 0
            and defender.damage_prevent_threshold_until_turn > 0
            and ctx.state.player(ctx.acting_player).turns_taken <= defender.damage_prevent_threshold_until_turn
            and dmg <= defender.damage_prevent_threshold
        ):
            dmg = 0  # 「そのダメージがN以下なら防ぐ」(Harden)
        elif (
            dmg > 0
            and defender.damage_coin_shield_until_turn > 0
            and ctx.state.player(ctx.acting_player).turns_taken <= defender.damage_coin_shield_until_turn
            and ctx.rng.random() < 0.5
        ):
            dmg = 0  # Afterimage Strike: コインがオモテならそのダメージを防ぐ
            ctx.log("コイン: オモテ。ダメージを防いだ")
        elif (
            dmg > 0
            and defender.incoming_damage_bonus_until_turn > 0
            and ctx.state.player(ctx.acting_player).turns_taken <= defender.incoming_damage_bonus_until_turn
        ):
            dmg += defender.incoming_damage_bonus_amount  # 「次の相手の番、このポケモンが受けるダメージ+N」(Pivot Throw等)
    if dmg > 0:
        defender.hit_by_calculated_attack_damage = True
        if defender.last_attack_damage_turn == ctx.state.turn_number:
            defender.last_attack_damage_taken += dmg
        else:
            defender.last_attack_damage_taken = dmg
            defender.last_attack_damage_turn = ctx.state.turn_number
    _trigger_on_active_damaged_by_attack(ctx, defender, dmg)
    return dmg


_ON_DAMAGED_WHILE_ACTIVE_DRAW_TOOLS: dict[str, int] = {
    "sv6-158": 2,  # ラッキーメット(Lucky Helmet): バトル場でワザのダメージを受けたら(きぜつしても)2枚引く
}
_ON_DAMAGED_WHILE_ACTIVE_RETALIATE_TOOLS: dict[str, int] = {
    "xy9-97": 6,  # 炸裂バルーン(Bursting Balloon): バトル場でワザのダメージを受けたら(きぜつしても)攻撃したポケモンにダメカンを6個
}
_ON_DAMAGED_WHILE_ACTIVE_RETALIATE_ENERGY: dict[str, int] = {
    "sv9-159": 2,  # とげとげエネルギー(Spiky Energy): バトル場でワザのダメージを受けたら(きぜつしても)
    # 攻撃したポケモンにダメカンを2個(どうぐと違いtools_disabledの影響を受けない)
}
_ON_DAMAGED_WHILE_ACTIVE_RETALIATE_STATUS_ABILITY_IDS: dict[str, str] = {
    "zsv10pt5-134": "poisoned",  # ドクロッグ改めダストダス……ではなくグライガンモス(Scolipede)特性
    # 「Poison Point」実カードテキスト: "If this Pokémon is in the Active Spot and is damaged by an
    # attack from your opponent's Pokémon (even if this Pokémon is Knocked Out), the Attacking
    # Pokémon is now Poisoned."
}
# 防御側の指定タイプ限定でダメカンを反撃するどうぐ(Punk Helmet実カードテキスト: "If the Darkness
# Pokémon this card is attached to is in the Active Spot and is damaged by an attack from your
# opponent's Pokémon (even if this Pokémon is Knocked Out), place 4 damage counters on the
# Attacking Pokémon."用)。
_ON_DAMAGED_WHILE_ACTIVE_RETALIATE_TYPE_RESTRICTED_TOOLS: dict[str, tuple[int, str]] = {
    "me2-121": (4, "Darkness"),  # パンクヘルム(Punk Helmet)
    "me2-92": (4, "Darkness"),  # パンクヘルム 別絵柄
}
# 防御側のカード名の接頭辞限定で特殊状態を反撃するどうぐ(Team Rocket's Hypnotizer実カードテキスト:
# "If the Team Rocket's Pokémon this card is attached to is in the Active Spot and is damaged by
# an attack from your opponent's Pokémon (even if this Team Rocket's Pokémon is Knocked Out), the
# Attacking Pokémon is now Asleep."用)。
_ON_DAMAGED_WHILE_ACTIVE_RETALIATE_STATUS_TOOLS_NAME_PREFIX: dict[str, tuple[str, str]] = {
    "me2pt5-206": ("Team Rocket's", "asleep"),  # ロケット団の眠り薬(Team Rocket's Hypnotizer)
}
# 防御側が相手のバトルポケモンのタイプに弱点を持つ場合限定でカードを引くどうぐ(Adversity Policy
# 実カードテキスト: "If the Pokémon this card is attached to has Weakness to your opponent's
# Active Pokémon's type, is in the Active Spot, and is damaged by an attack from your opponent's
# Pokémon (even if this Pokémon is Knocked Out), draw 3 cards."用)。
_ON_DAMAGED_WHILE_ACTIVE_DRAW_IF_WEAK_TOOLS: dict[str, int] = {
    "me4-74": 3,  # 逆境のポリシー(Adversity Policy)
}


def _trigger_on_active_damaged_by_attack(ctx: EffectContext, defender: PokemonInPlay, dmg: int) -> None:
    """「バトル場にいる間、ワザのダメージを受けたら(きぜつしても)〜」系のどうぐ/特性のトリガー
    (ラッキーメット/炸裂バルーン/テツノイサハexの「Repulsor Axe」等)。resolve_attack_damageの末尾から
    毎回呼ばれ、実際にダメージが発生し、かつ対象がその持ち主のバトルポケモンだったときのみ発動する。"""
    if dmg <= 0 or ctx.source_pokemon is None:
        return
    defender_owner = ctx.state.player(ctx.opponent)
    if defender is not defender_owner.active:
        return
    if not tools_disabled(ctx.state.stadium_in_play):
        from effects.era_sm_hooks import on_active_damaged_sm

        on_active_damaged_sm(ctx, defender, defender_owner, dmg)  # ドクバリ/耳鳴りのベル/ドラゴンのツメ/ジャイアントボム
        draw_count = _ON_DAMAGED_WHILE_ACTIVE_DRAW_TOOLS.get(defender.attached_tool)
        if draw_count:
            for _ in range(draw_count):
                if not defender_owner.deck:
                    break
                defender_owner.hand.append(defender_owner.deck.pop(0))
            ctx.log(f"{defender.card_id} がワザのダメージを受け、どうぐの効果で{draw_count}枚引いた")
        retaliate_count = _ON_DAMAGED_WHILE_ACTIVE_RETALIATE_TOOLS.get(defender.attached_tool)
        if retaliate_count:
            ctx.source_pokemon.damage += retaliate_count * 10
            ctx.log(f"{defender.card_id} がワザのダメージを受け、どうぐの効果で攻撃したポケモンにダメカンを{retaliate_count}個のせた")
        type_restricted_retaliate = _ON_DAMAGED_WHILE_ACTIVE_RETALIATE_TYPE_RESTRICTED_TOOLS.get(defender.attached_tool)
        if type_restricted_retaliate is not None:
            count, required_type = type_restricted_retaliate
            defender_card = ctx.card_db.get(defender.card_id)
            if defender_card is not None and required_type in defender_card.types:
                ctx.source_pokemon.damage += count * 10
                ctx.log(f"{defender.card_id} がワザのダメージを受け、どうぐの効果で攻撃したポケモンにダメカンを{count}個のせた")
        status_prefix_tool = _ON_DAMAGED_WHILE_ACTIVE_RETALIATE_STATUS_TOOLS_NAME_PREFIX.get(defender.attached_tool)
        if status_prefix_tool is not None:
            required_prefix, condition = status_prefix_tool
            defender_card = ctx.card_db.get(defender.card_id)
            if defender_card is not None and defender_card.name.startswith(required_prefix):
                _apply_condition(ctx.source_pokemon, condition)
                ctx.log(f"{defender.card_id} がワザのダメージを受け、どうぐの効果で攻撃したポケモンが{condition}になった")
        draw_if_weak = _ON_DAMAGED_WHILE_ACTIVE_DRAW_IF_WEAK_TOOLS.get(defender.attached_tool)
        if draw_if_weak:
            defender_card = ctx.card_db.get(defender.card_id)
            attacker_card = ctx.card_db.get(ctx.source_pokemon.card_id)
            if (
                defender_card is not None
                and attacker_card is not None
                and any(w.type in attacker_card.types for w in defender_card.weaknesses)
            ):
                for _ in range(draw_if_weak):
                    if not defender_owner.deck:
                        break
                    defender_owner.hand.append(defender_owner.deck.pop(0))
                ctx.log(f"{defender.card_id} がワザのダメージを受け、どうぐの効果で{draw_if_weak}枚引いた")
    energy_retaliate_count = next(
        (v for eid, v in ((e, _ON_DAMAGED_WHILE_ACTIVE_RETALIATE_ENERGY.get(e)) for e in defender.attached_energy) if v),
        None,
    )
    if energy_retaliate_count:
        ctx.source_pokemon.damage += energy_retaliate_count * 10
        ctx.log(f"{defender.card_id} がワザのダメージを受け、特殊エネルギーの効果で攻撃したポケモンにダメカンを{energy_retaliate_count}個のせた")
    from effects.era_energy_g import on_active_damaged

    on_active_damaged(ctx, defender, defender_owner, dmg)  # ダンジャラスエネルギー/Tremendous Bomb
    from effects.era_tools_j import on_active_damaged_energy

    on_active_damaged_energy(ctx, defender, defender_owner, dmg)  # ホラーエネルギー/ラッキーエネルギー
    from effects.passives import retaliation_on_damaged

    retaliation_on_damaged(ctx, defender, dmg)
    retaliate_status = _ON_DAMAGED_WHILE_ACTIVE_RETALIATE_STATUS_ABILITY_IDS.get(defender.card_id)
    if retaliate_status:
        _apply_condition(ctx.source_pokemon, retaliate_status)
        ctx.log(f"{defender.card_id} がワザのダメージを受け、特性の効果で攻撃したポケモンが{retaliate_status}になった")
    if (
        defender.retaliate_on_damaged_until_turn > 0
        and _attacker_player(ctx).turns_taken <= defender.retaliate_on_damaged_until_turn
    ):
        retaliate_counters = dmg // 10 if defender.retaliate_equal_damage else defender.retaliate_on_damaged_counters
        ctx.source_pokemon.damage += retaliate_counters * 10
        ctx.log(
            f"{defender.card_id} がワザのダメージを受け、反撃の効果で攻撃したポケモンに"
            f"ダメカンを{retaliate_counters}個のせた"
        )


def _blocks_damage_counters(defender: PokemonInPlay) -> bool:
    """特性・ワザによるダメカン付与(ダメージ計算を経由しないもの)を防ぐどうぐを持っているか。"""
    tool = defender.attached_tool
    if tool in _FLAT_DAMAGE_REDUCTION_TOOLS:
        return True  # メタルゴーグル: ダメカンを直接のせる効果も防ぐ
    from engine.energy import current_card_db, current_state

    state, card_db = current_state(), current_card_db()
    if state is None or card_db is None:
        return False
    from effects.passives_cond import counters_shielded

    return counters_shielded(state, card_db, defender)  # Daunting Pose: ベンチのポケモンにはダメカンをのせられない


@dataclass(frozen=True)
class DealDamage(Effect):
    amount: int

    def execute(self, ctx: EffectContext) -> None:
        if ctx.source_pokemon is None:
            return
        _, defender = _defender(ctx)
        if defender is None or _defender_is_shielded(ctx, defender):
            return
        attacker_card = ctx.card_db.get(ctx.source_pokemon.card_id)
        defender_card = ctx.card_db.get(defender.card_id)
        if attacker_card is None or defender_card is None:
            return
        dmg = resolve_attack_damage(ctx, defender, defender_card, self.amount)
        defender.damage += dmg
        ctx.damage_dealt += dmg
        ctx.log(f"{ctx.source_card_id} が {dmg} ダメージ")


@dataclass(frozen=True)
class SelfDamage(Effect):
    amount: int

    def execute(self, ctx: EffectContext) -> None:
        if ctx.source_pokemon is None:
            return
        from effects.era_trainers import era_self_damage_prevented

        if era_self_damage_prevented(ctx.state, ctx.source_pokemon):
            ctx.log(f"{ctx.source_card_id} はプロテクションキューブで自身へのダメージを受けない")
            return
        ctx.source_pokemon.damage += self.amount
        ctx.log(f"{ctx.source_card_id} は自身に {self.amount} ダメージ")


@dataclass(frozen=True)
class DamageToChosenOwnPokemonIgnoringWeaknessResistance(Effect):
    """自分の場のポケモン1匹(選択、バトル/ベンチどちらでも可)に、弱点・抵抗力を計算せずダメージ
    (レントラーGL LV.Xの「Flash Impact」等)。"""

    amount: int

    def execute(self, ctx: EffectContext) -> None:
        player = _attacker_player(ctx)
        target = _resolve_own_target(ctx, player)
        if target is None:
            return
        target.damage += self.amount


@dataclass(frozen=True)
class DamageCounterOnChosenOwnPokemon(Effect):
    """自分の場のポケモン1匹(選択、バトル/ベンチどちらでも可)にダメカンをのせる
    (ギラティナの「Shadow Impact」等)。"""

    count: int = 1

    def execute(self, ctx: EffectContext) -> None:
        player = _attacker_player(ctx)
        target = _resolve_own_target(ctx, player)
        if target is None:
            return
        target.damage += self.count * 10


@dataclass(frozen=True)
class HealSelf(Effect):
    amount: int

    def execute(self, ctx: EffectContext) -> None:
        if ctx.source_pokemon is None:
            return
        ctx.source_pokemon.heal(self.amount)


@dataclass(frozen=True)
class HealSelfPerAttachedEnergyId(Effect):
    """自分についている指定IDのエネルギーの枚数×heal_perぶん自分を回復する
    (パルキアEXの「Dimension Heal」: プラズマエネルギーの枚数ぶん回復、等)。"""

    energy_id: str
    heal_per: int

    def execute(self, ctx: EffectContext) -> None:
        if ctx.source_pokemon is None:
            return
        count = ctx.source_pokemon.attached_energy.count(self.energy_id)
        HealSelf(self.heal_per * count).execute(ctx)


@dataclass(frozen=True)
class HealTarget(Effect):
    """自分のポケモン1匹(対象指定)のダメージをamountぶん回復する。bench_only=Trueならベンチのみが対象
    (メロエッタの「Soothing Melody」実カードテキスト: "Heal 120 damage from 1 of your Benched Psychic
    Pokémon."用)。target_type指定時はそのタイプのポケモンのみが対象。"""

    amount: int
    bench_only: bool = False
    target_type: str | None = None

    def execute(self, ctx: EffectContext) -> None:
        player = _attacker_player(ctx)
        target = _resolve_own_target(ctx, player)
        if target is not None:
            target.heal(self.amount)


@dataclass(frozen=True)
class HealOwnActiveIfEnergyCountAtLeast(Effect):
    """自分のバトルポケモンについているエネルギーがmin_energy個以上なら、そのHPをamount回復する
    (ジャンボアイス実カードテキスト: "エネルギーが3個以上ついている自分のバトルポケモンのHPを
    『80』回復する。"、対象はバトルポケモン固定で選択の余地は無い)。"""

    amount: int
    min_energy: int

    def execute(self, ctx: EffectContext) -> None:
        player = _attacker_player(ctx)
        if player.active is None or len(player.active.attached_energy) < self.min_energy:
            return
        player.active.heal(self.amount)


@dataclass(frozen=True)
class HealTargetThenReturnAttachedEnergyToHandIfHealed(Effect):
    """選んだ自分のポケモン1匹のダメージを全て回復する。実際にダメージを回復できた場合、その
    ポケモンについているエネルギーを全て手札に戻す(ミツルの思いやり実カードテキスト: "Heal all
    damage from 1 of your Mega Evolution Pokémon ex. If you healed any damage in this way, put all
    Energy attached to that Pokémon into your hand."。対象の絞り込み(MEGA ex限定)はlegal_actions側で
    行う)。"""

    def execute(self, ctx: EffectContext) -> None:
        player = _attacker_player(ctx)
        target = _resolve_own_target(ctx, player)
        if target is None:
            return
        had_damage = target.damage > 0
        target.heal(9999)
        if had_damage and target.attached_energy:
            player.hand.extend(target.attached_energy)
            target.attached_energy = []


@dataclass(frozen=True)
class HealTargetThenDiscardAllEnergy(Effect):
    """選んだ自分のポケモン1匹のダメージを全て回復し、そのポケモンについているエネルギーを
    全てトラッシュする(マックスポーション実カードテキスト: "Heal all damage from 1 of your
    Pokémon. If you do, discard all Energy from that Pokémon."用)。"""

    def execute(self, ctx: EffectContext) -> None:
        player = _attacker_player(ctx)
        target = _resolve_own_target(ctx, player)
        if target is None:
            return
        target.heal(9999)
        if target.attached_energy:
            player.discard.extend(target.attached_energy)
            target.attached_energy = []


# 相手の"ワザ"由来の効果(ダメージを除く)のみを防ぐ特性を持つカードID(特性由来の効果は防がない)。
# 2026-09-04、公式カードテキストを個別に確認して分類(各カードの実テキストは下記コメント参照)。
_ATTACK_ONLY_NON_DAMAGE_EFFECT_IMMUNE_CARD_IDS: set[str] = {
    "swsh11-143",  # カビゴン(Snorlax、LOR/143)「Unfazed Fat」実カードテキスト: "Prevent all effects
    # of attacks from your opponent's Pokémon done to this Pokémon. (Damage is not an effect.)"
    "sv4pt5-8",  # リザード(Charmeleon、PAF/8)「Flare Veil」実カードテキスト: "Prevent all effects of
    # attacks used by your opponent's Pokémon done to this Pokémon. (Damage is not an effect.)"
    "me2-114",  # エンペルトex(Empoleon ex、PFL/114)「Emperor's Stance」実カードテキスト: 同上(ワザ限定)
}
# 相手の"ワザ""特性"どちらの由来の効果(ダメージを除く)も防ぐ特性を持つカードID
_ATTACK_AND_ABILITY_NON_DAMAGE_EFFECT_IMMUNE_CARD_IDS: set[str] = {
    "me5-33",  # カゲボウズ(Shuppet)「Hide 'n' Sneak」実カードテキスト: "Prevent all effects of your
    # opponent's Pokémon's attacks and Abilities done to this Pokémon. (Damage is not an effect.)"
    "me5-34",  # ジュペッタ(Banette)「Hide 'n' Sneak」: 同上(ワザ・特性両方)
    "me5-5",  # チャデス(Poltchageist)「Hide 'n' Sneak」: 同上(ワザ・特性両方)
    "me5-6",  # ヤバソチャ(Sinistcha)「Hide 'n' Sneak」: 同上(ワザ・特性両方)
}
# 「ワザの効果を受けない(ダメージを除く)」特性を持つカードID全体(スコープを問わない存在確認用。
# scripts/dump_card_implementation_status.py等の実装状況チェックで使用。該当カードが無くなった
# 場合に備え空集合も許容)。実際の免疫判定には↑の2つのスコープ別集合を使うこと。
NON_DAMAGE_EFFECT_IMMUNE_CARD_IDS: set[str] = (
    _ATTACK_ONLY_NON_DAMAGE_EFFECT_IMMUNE_CARD_IDS | _ATTACK_AND_ABILITY_NON_DAMAGE_EFFECT_IMMUNE_CARD_IDS
)


_RULE_BOX_SUBTYPES = {"ex", "EX", "GX", "V", "VMAX", "VSTAR", "Radiant", "BREAK", "MEGA", "Tera", "Level-Up"}  # 「ルール箱」を持つサブタイプ(アルタイル市(Artazon)等)

_VIRIZION_EX_VERDANT_WIND_ID = "bw10-9"  # ビリジオンEX「Verdant Wind」: くさエネルギーがついていれば特殊状態にならない
_BENCH_BARRIER_IDS = {"bw9-47", "sm10-76", "swsh9-41"}  # バリヤード/ミュウ「Bench Barrier」・マナフィ「Wave Veil」(同文): 自分のベンチポケモンはワザのダメージを受けない
_BENCH_BARRIER_EXCLUDING_RULE_BOX_IDS = {"m2a-012", "sv10-10", "sv10-185"}  # シェイミ「はなのカーテン」(sv10-10/sv10-185は別絵柄): ルール箱を持つポケモンを除く自分のベンチポケモンはワザのダメージを受けない
_BATTLE_COLOSSEUM_STADIUM_ID = "m2-79"  # バトルコロシアム: おたがいのベンチポケモンは、相手のワザ/特性の効果でダメカンがのらない(ワザのダメージそのものは受ける)
_COINFLIP_DAMAGE_PREVENTION_IF_ENERGY_TYPE: dict[str, str] = {"sv8pt5-45": "Darkness"}  # キチキギスの特性「Adrena-Pheromone」: このポケモンに指定タイプの基本エネルギーがついていて、ワザのダメージを受けるとき、コインを1回投げ、表なら防ぐ
_REPELLING_VEIL_HOLDER_IDS = {"sv10-51"}  # ロケット団のフリーザーの特性「Repelling Veil」
_SENTRY_DUTY_HOLDER_IDS = {"m4-yungoos"}  # ミネズミの特性「かんしのめ」: どちらかの場にいる間、既についているダメカンを別のポケモンにのせ替える効果を封じる
_SELF_BENCH_FULL_IMMUNITY_IDS = {"sv10-48"}  # ミストのコイキング(Misty's Magikarp)特性「So Submerged」:
# ベンチにいる間、自分自身は相手のワザによるダメージ・効果を一切受けない(バリヤードと違い自分自身のみが対象)
_NAMED_PREFIX_TEAM_ATTACK_BONUS_ABILITY_IDS: dict[str, tuple[str, int]] = {
    "sv10-184": ("Cynthia's", 30),  # シンジタチのロズレイド(Cynthia's Roserade)特性「Cheer On to Glory」:
    # "Attacks used by your Cynthia's Pokémon do 30 more damage to your opponent's Active Pokémon
    # (before applying Weakness and Resistance)."
    "sv9-117": ("Hop's", 30),  # ダンデのカビゴン(Hop's Snorlax)特性「Extra Helpings」: 同文言
}
_SELF_DAMAGED_BONUS_DAMAGE_ABILITY_IDS: dict[str, tuple[int, int]] = {
    "sv10-92": (20, 120),  # ケケンカニ改めコノヨザル(Annihilape)特性「Lose Cool」実カードテキスト:
    # "If this Pokémon has 2 or more damage counters on it, attacks used by this Pokémon do 120 more
    # damage to your opponent's Active Pokémon (before applying Weakness and Resistance)."
}
_NAMED_PREFIX_TEAM_DEFENSE_REDUCTION_ABILITY_IDS: dict[str, tuple[str, int]] = {
    "sv10-86": ("Steven's", 30),  # ダイヤ改めイシヘンジン(Steven's Carbink)特性「Stone Palace」:
    # "As long as this Pokémon is on your Bench, all of your Steven's Pokémon take 30 less damage
    # from attacks from your opponent's Pokémon (after applying Weakness and Resistance)."
}
_TEAM_WIDE_ATTACK_BONUS_ABILITY_IDS: dict[str, int] = {
    "zsv10pt5-156": 20,  # サーナイトex改めジャローダex(Serperior ex)特性「Regal Cheer」実カードテキスト:
    # "Attacks used by your Pokémon do 20 more damage to your opponent's Active Pokémon (before
    # applying Weakness and Resistance)."(名前接頭辞の制限が無く、自分の場の全ポケモンが対象)
}
_ENERGY_TYPE_CONDITIONAL_TEAM_DEFENSE_REDUCTION_ABILITY_IDS: dict[str, tuple[str, int]] = {
    "zsv10pt5-141": ("Metal", 20),  # ギギギアル(Klinklang)特性「Gear Coating」実カードテキスト: "All
    # of your Pokémon that have any Metal Energy attached take 20 less damage from attacks from your
    # opponent's Pokémon (after applying Weakness and Resistance)."
}


def _team_wide_attack_bonus_damage(player: PlayerState) -> int:
    for holder_id, bonus in _TEAM_WIDE_ATTACK_BONUS_ABILITY_IDS.items():
        if any(mon.card_id == holder_id for mon in player.all_pokemon_in_play()):
            return bonus
    return 0


def _energy_type_conditional_team_defense_reduction(ctx: EffectContext, defender: PokemonInPlay, defender_owner: PlayerState) -> int:
    for holder_id, (energy_type, reduction) in _ENERGY_TYPE_CONDITIONAL_TEAM_DEFENSE_REDUCTION_ABILITY_IDS.items():
        if not any(mon.card_id == holder_id for mon in defender_owner.all_pokemon_in_play()):
            continue
        has_energy_type = any(
            (e := ctx.card_db.get(eid)) is not None and e.basic_energy_type == energy_type
            for eid in defender.attached_energy
        )
        if has_energy_type:
            return reduction
    return 0


def _named_prefix_team_defense_reduction(defender_owner: PlayerState, defender_card) -> int:
    for holder_id, (prefix, reduction) in _NAMED_PREFIX_TEAM_DEFENSE_REDUCTION_ABILITY_IDS.items():
        if defender_card.name.startswith(prefix) and any(mon.card_id == holder_id for mon in defender_owner.bench):
            return reduction
    return 0


def _named_prefix_team_ability_bonus_damage(player: PlayerState, attacker_card) -> int:
    for holder_id, (prefix, bonus) in _NAMED_PREFIX_TEAM_ATTACK_BONUS_ABILITY_IDS.items():
        if attacker_card.name.startswith(prefix) and any(mon.card_id == holder_id for mon in player.all_pokemon_in_play()):
            return bonus
    return 0


_NAME_PREFIX_TOOL_BONUS_DAMAGE: dict[str, tuple[str, int]] = {
    "sv9-148": ("Hop's", 30),  # ダンデのグッドチョイス(Hop's Choice Band)実カードテキスト: "Attacks
    # used by the Hop's Pokémon this card is attached to... do 30 more damage..."(コスト-1コロレスの
    # 部分は新規のコスト軽減機構が必要なため未対応)
}


def _name_prefix_tool_bonus_damage(tool_id: str | None, attacker_card) -> int:
    if tool_id is None or tool_id not in _NAME_PREFIX_TOOL_BONUS_DAMAGE:
        return 0
    prefix, bonus = _NAME_PREFIX_TOOL_BONUS_DAMAGE[tool_id]
    return bonus if attacker_card.name.startswith(prefix) else 0


def _damage_counter_relocation_blocked(ctx: EffectContext) -> bool:
    from effects.passives import global_passives

    return any(mon.card_id in _SENTRY_DUTY_HOLDER_IDS for player in ctx.state.players for mon in player.all_pokemon_in_play()) or bool(
        global_passives(ctx.state, ctx.card_db, "global_counter_move_lock")
    )  # Sentry Duty/Watchful Eye
_CORNERSTONE_OGERPON_ID = "sv6-112"  # いしずえのおめん オーガポンex「Cornerstone Stance」
_CORNERSTONE_OGERPON_REPRINT_ID = "sv8pt5-58"  # オーガポン いしずえのめんex(Prismatic Evolutions再録)


def _defender_blocks_attack_only_non_damage_effects(
    ctx: EffectContext, defender: PokemonInPlay, include_damage_only_immunity: bool = True
) -> bool:
    """相手の"ワザ"由来の効果(ダメージを除く)のみを防ぐ免疫(実カードテキストが「ワザ」限定と
    明記されているもの)。特性由来の効果(サマヨール/ヨノワールの「Cursed Blast」等)にはこの免疫は
    及ばない — ここに含まれる免疫を、特性由来の効果をブロックする判定に使わないこと。
    include_damage_only_immunity: Falseなら_FULL_DAMAGE_IMMUNITY_VS_SUBTYPE(「ダメージのみ」を
    防ぐ免疫)を無視する。ダメージを与えず状態異常も付与しない効果(Terminal Period等)向け。"""
    if defender.effect_shield_until_turn > 0 and ctx.state.player(ctx.acting_player).turns_taken <= defender.effect_shield_until_turn:
        return True  # Light Pulse: 相手の次の番、ワザの効果(ダメージを除く)を受けない
    from effects.era_sm_hooks import bench_effects_prevented

    if bench_effects_prevented(ctx.state) and defender is not ctx.state.player(ctx.opponent).active:
        return True  # スカイピラー: ベンチのポケモンは、相手のワザの効果を受けない
    from effects.passives import attack_effects_immune

    if attack_effects_immune(ctx, defender):
        return True  # Bright Down/Safeguard/Mighty Shell/Solar Revelation等: 生成されたパッシブ特性による、ワザの効果の無効
    if defender.card_id in _ATTACK_ONLY_NON_DAMAGE_EFFECT_IMMUNE_CARD_IDS and not ability_suppressed(
        ctx.state, ctx.card_db, ctx.opponent, defender
    ):
        return True
    if defender.card_id in _SELF_BENCH_FULL_IMMUNITY_IDS and defender is not ctx.state.player(ctx.opponent).active:
        return True
    # _FULL_DAMAGE_IMMUNITY_VS_SUBTYPE(イワパレスの「Mysterious Rock Inn」等、「ダメージのみ」を
    # 防ぐ免疫)をここに含めているのは、どく等の状態異常の「付与」を相手の効果として防ぐため
    # (実際の計算済みダメージ免疫は_apply_defender_side_damage_modifiers側で別途担保済み)。
    # ただしダメカンちょうどN個で即きぜつさせる系の効果(メガアブソルexの「Terminal Period」等、
    # ダメージを与えず・状態異常も付与しない)まで一律で防いでしまうのは誤り(2026-09-14ユーザー
    # 報告の実バグ)。そのため、この「ダメージのみ」免疫を無視すべき呼び出し元は
    # include_damage_only_immunity=Falseを指定する(KnockOutDefenderIfExactDamageCounters参照)。
    if include_damage_only_immunity:
        immune_subtype = _FULL_DAMAGE_IMMUNITY_VS_SUBTYPE.get(defender.card_id)
        if immune_subtype and ctx.source_pokemon is not None:
            attacker_card = ctx.card_db.get(ctx.source_pokemon.card_id)
            if attacker_card is not None and immune_subtype in attacker_card.subtypes:
                return True
    defender_owner = ctx.state.player(ctx.opponent)
    # (ビリジオンEXの「Verdant Wind」は特殊状態のみを防ぐ特性で、ダメージ以外の効果すべてを防ぐわけではない。
    # 以前はここで全効果を防いでいた誤りを訂正し、特殊状態の免疫はstatus_conditions_blockedで扱う、2026-10-06)
    if attack_effects_blocked_by_mystic_heart(ctx.state, ctx.card_db, ctx.opponent, defender):
        # マギアナEXの特性「Mystic Heart」: はがねエネルギーがついている自分のポケモンは、相手のワザの
        # ダメージ以外の効果を受けない
        return True
    defender_card = ctx.card_db.get(defender.card_id)
    if (
        defender_card is not None
        and defender_card.is_basic
        and is_team_rockets_pokemon(defender_card)
        and any(mon.card_id in _REPELLING_VEIL_HOLDER_IDS for mon in defender_owner.all_pokemon_in_play())
    ):
        # ロケット団のフリーザーの特性「Repelling Veil」実カードテキスト: "Prevent all effects of
        # attacks used by your opponent's Pokémon done to your Basic Team Rocket's Pokémon in play."
        # (ワザ限定、特性由来には及ばない)
        return True
    from engine.energy import MIST_ENERGY_ID, ROCKY_FIGHTING_ENERGY_ID, WONDER_ENERGY_ID

    if energy_effect_present(defender.attached_energy, WONDER_ENERGY_ID):
        # ワンダーエネルギー実カードテキスト: "Prevent all effects of your opponent's attacks, except
        # damage, done to the Fairy Pokémon that this card is attached to."(ワザ限定)
        return True
    if energy_effect_present(defender.attached_energy, MIST_ENERGY_ID, ROCKY_FIGHTING_ENERGY_ID):
        # ミストエネルギー/Rocky Fighting Energy実カードテキスト: "Prevent all effects of attacks used
        # by your opponent's Pokémon done to the Pokémon this card is attached to."(ダメージ自体は
        # 防がない。両者同文、型のみ異なる。ワザ限定であり、特性由来の効果には及ばない — 2026-09-02、
        # ユーザー指摘・公式FAQで裏取り)
        return True
    return False


def _defender_blocks_attack_and_ability_non_damage_effects(ctx: EffectContext, defender: PokemonInPlay) -> bool:
    """相手の"ワザ""特性"どちらの由来の効果(ダメージを除く)も防ぐ免疫。ばけがくれ実カードテキスト:
    "Prevent all effects of your opponent's Pokémon's attacks and Abilities done to this Pokémon.
    (Damage is not an effect.)" — ワザ限定免疫(ミストエネルギー等)と異なり、特性由来の効果
    (サマヨール/ヨノワールの「Cursed Blast」等)にもこちらは適用される。"""
    return defender.card_id in _ATTACK_AND_ABILITY_NON_DAMAGE_EFFECT_IMMUNE_CARD_IDS and not ability_suppressed(
        ctx.state, ctx.card_db, ctx.opponent, defender
    )


def _defender_blocks_non_damage_effects(
    ctx: EffectContext, defender: PokemonInPlay, include_damage_only_immunity: bool = True
) -> bool:
    """ワザ由来の効果(ダメージを除く)に対する免疫チェック。ワザ限定免疫(ミストエネルギー等)と
    ワザ/特性共通免疫(ばけがくれ等)のどちらか一方でも該当すればワザ由来の効果は防がれるため、
    両方を見る(ワザはどちらのスコープの免疫の対象にもなりうる)。ワザ由来の効果を処理する呼び出し元は
    こちらを使う。特性由来の効果(ワザ限定免疫の対象外)を処理する場合は
    _defender_blocks_attack_and_ability_non_damage_effects() を直接使うこと。
    include_damage_only_immunity: _defender_blocks_attack_only_non_damage_effects参照。"""
    return _defender_blocks_attack_only_non_damage_effects(
        ctx, defender, include_damage_only_immunity
    ) or _defender_blocks_attack_and_ability_non_damage_effects(ctx, defender)


def _defender_blocks_effect(ctx: EffectContext, defender: PokemonInPlay) -> bool:
    """呼び出し元のEffectクラスがワザ/特性どちらにも登録されている場合(InflictStatusOnDefender、
    DamageCounterOnChosenOpponentPokemon、DistributeDamageCountersFreely等)向けの、ctx.effect_source
    を見て免疫スコープを出し分ける判定。ctx.effect_source=="ability"ならワザ限定免疫
    (_defender_blocks_attack_only_non_damage_effects、ミストエネルギー等)は適用せず、ワザ/特性共通免疫
    (_defender_blocks_attack_and_ability_non_damage_effects、ばけがくれ等)のみ見る。それ以外
    (既定"attack")は従来通り両方の免疫を見る(_defender_blocks_non_damage_effects)。"""
    if ctx.effect_source == "ability":
        from effects.passives import active_passives
        from engine.energy import FUSION_STRIKE_ENERGY_ID

        if active_passives(ctx.state, ctx.card_db, ctx.opponent, defender, "ability_effect_immune"):
            return True  # Luminous Wing: 相手のポケモンの特性の効果を受けない
        from effects.era_sm_hooks import tool_blocks_ability_effects

        if tool_blocks_ability_effects(defender.attached_tool) and not tools_disabled(ctx.state.stadium_in_play):
            return True  # ステルスフード: 相手の特性の効果を受けない

        # フュージョンエネルギー: 相手のポケモンの特性による効果(ダメージ以外)を受けない
        return _defender_blocks_attack_and_ability_non_damage_effects(ctx, defender) or energy_effect_present(
            defender.attached_energy, FUSION_STRIKE_ENERGY_ID
        )
    return _defender_blocks_non_damage_effects(ctx, defender)


def clear_status_if_verdant_wind_protects(player: PlayerState, mon: PokemonInPlay, card_db: CardDatabase) -> None:
    """ビリジオンEXの「Verdant Wind」実カードテキスト:
    "Each of your Pokémon that has any Grass Energy attached to it can't be affected by any Special
    Conditions. (Remove any Special Conditions affecting those Pokémon.)" — くさエネルギーを後から
    つけた場合も、その瞬間に既にかかっている特殊状態を解除する必要がある。エネルギーを場のポケモンに
    つける処理(手札から/効果経由どちらも)の直後に呼ぶ。"""
    if not mon.status.is_any:
        return
    has_verdant_wind = any(m.card_id == _VIRIZION_EX_VERDANT_WIND_ID for m in player.all_pokemon_in_play())
    if not has_verdant_wind:
        return
    has_grass_energy = any(
        (e_card := card_db.get(eid)) is not None and e_card.basic_energy_type == "Grass" for eid in mon.attached_energy
    )
    if has_grass_energy:
        mon.status.clear_all()


FESTIVAL_GROUNDS_STADIUM_ID = "sv6-149"  # お祭り会場


def clear_status_if_festival_grounds_protects(state, mon: PokemonInPlay) -> None:
    """お祭り会場(sv6-149)実カードテキスト: "Each Pokémon that has any Energy attached (both yours
    and your opponent's) recovers from all Special Conditions and can't be affected by any Special
    Conditions." Verdant Windと同じ考え方で、エネルギーを後からつけた場合もその瞬間に既にかかっている
    特殊状態を解除する。Verdant Windと違い自分・相手どちらのポケモンも対象、エネルギーはタイプ問わない。"""
    if not mon.status.is_any:
        return
    if state.stadium_in_play != FESTIVAL_GROUNDS_STADIUM_ID:
        return
    if mon.attached_energy:
        mon.status.clear_all()


def _defender_status_immune_via_festival_grounds(ctx: EffectContext, defender: PokemonInPlay) -> bool:
    """特殊状態を受けないポケモンか(お祭り会場・ビリジオンEXの「Verdant Wind」・コバルオンGXの
    「Metal Symbol」)。関数名は歴史的経緯でそのまま(呼び出し元が多いため)。"""
    return status_conditions_blocked(ctx.state, ctx.card_db, ctx.opponent, defender)


def _defender_is_shielded(ctx: EffectContext, defender: PokemonInPlay) -> bool:
    """「相手の次の番、ワザの効果を受けない」(ジラーチGXの「スターシールドGX」等)、または
    「相手の次の番、特定の種類のポケモンのワザによるダメージを受けない」(ジョルテオンEXの
    「Flash Ray」等、ダメージのみが対象でスコープが攻撃側のポケモン種別に限定される)のいずれかが
    有効かどうか。"""
    if defender.shielded_until_turn > 0 and _attacker_player(ctx).turns_taken <= defender.shielded_until_turn:
        return True
    if defender.shield_scope_until_turn > 0 and _attacker_player(ctx).turns_taken <= defender.shield_scope_until_turn and ctx.source_pokemon is not None:
        from effects.era_primitives_f import scope_matches_attacker

        if scope_matches_attacker(defender.shield_scope, ctx.card_db.get(ctx.source_pokemon.card_id)):
            return True  # 「◯◯ポケモンによるワザの効果(ダメージを含む)を受けない」
    if ctx.source_pokemon is not None:
        from effects.passives import defender_is_immune

        attacker_card = ctx.card_db.get(ctx.source_pokemon.card_id)
        if defender_is_immune(ctx, defender, attacker_card):
            return True
    return _defender_damage_immune(ctx, defender)


def _defender_damage_immune(ctx: EffectContext, defender: PokemonInPlay) -> bool:
    team_owner = ctx.state.player(ctx.opponent)
    if (
        team_owner.ex_damage_immunity_until_turn > 0
        and _attacker_player(ctx).turns_taken <= team_owner.ex_damage_immunity_until_turn
        and team_owner.ex_damage_immunity_source is not None
        and team_owner.ex_damage_immunity_source is team_owner.active
        and ctx.source_pokemon is not None
        and (a_card := ctx.card_db.get(ctx.source_pokemon.card_id)) is not None
        and "EX" in a_card.subtypes
    ):
        return True  # Diamond Force: 自分のポケモン全員が、相手のポケモンEXから受けるダメージを防ぐ(源のポケモンがバトル場にいる間)
    if defender.damage_immunity_until_turn <= 0:
        return False
    if _attacker_player(ctx).turns_taken > defender.damage_immunity_until_turn:
        return False
    if ctx.source_pokemon is None:
        return False
    attacker_card = ctx.card_db.get(ctx.source_pokemon.card_id)
    if attacker_card is None:
        return False
    scope = defender.damage_immunity_scope
    if scope == "basic":
        return attacker_card.is_basic
    if scope == "evolution":
        return not attacker_card.is_basic
    if scope == "gx_ex":
        return bool({"GX", "EX"} & set(attacker_card.subtypes))
    if scope == "EX":  # Steel Slash等: 「ポケモンEXからのダメージを防ぐ」
        return "EX" in attacker_card.subtypes
    if scope == "tag_team":
        return "TAG TEAM" in attacker_card.subtypes
    if scope == "basic_non_colorless":
        return attacker_card.is_basic and "Colorless" not in attacker_card.types
    if scope.startswith("subtype:"):  # 「ポケモンVMAXからのダメージを防ぐ」等(カンマ区切りで複数)
        return any(s in attacker_card.subtypes for s in scope.split(":", 1)[1].split(","))
    if scope == "all":  # カラナクシ(Shelmet)「Shell Smack」実カードテキスト: "prevent all damage done
        # to this Pokémon by attacks."(効果は防がない、ApplyShieldToSelfより狭いダメージのみの無効化)
        return True
    return False


def _defender_damage_reduction(ctx: EffectContext, defender: PokemonInPlay) -> int:
    """「相手の次の番、受けるダメージ-N」(ヒスイヌメルゴンVSTARの「ローリングアイアン」等)の軽減量。"""
    if defender.damage_reduction_until_turn <= 0:
        return 0
    if _attacker_player(ctx).turns_taken <= defender.damage_reduction_until_turn:
        return defender.damage_reduction_amount
    return 0


@dataclass(frozen=True)
class InflictStatusOnDefender(Effect):
    condition: str  # "poisoned" | "burned" | "asleep" | "paralyzed" | "confused"

    def execute(self, ctx: EffectContext) -> None:
        _, defender = _defender(ctx)
        if (
            defender is None
            or _defender_blocks_effect(ctx, defender)
            or _defender_is_shielded(ctx, defender)
            or _defender_status_immune_via_festival_grounds(ctx, defender)
        ):
            return
        _apply_condition(defender, self.condition)
        ctx.log(f"相手の場のポケモンが{self.condition}になった")


def _apply_condition(pokemon: PokemonInPlay, condition: str) -> None:
    if condition == "poisoned":
        pokemon.status.poisoned = True
    elif condition == "burned":
        pokemon.status.burned = True
    elif condition == "asleep":
        pokemon.status.apply_exclusive(ExclusiveCondition.ASLEEP)
    elif condition == "paralyzed":
        pokemon.status.apply_exclusive(ExclusiveCondition.PARALYZED)
    elif condition == "confused":
        pokemon.status.apply_exclusive(ExclusiveCondition.CONFUSED)


@dataclass(frozen=True)
class FlipCoinThen(Effect):
    heads: tuple[Effect, ...] = ()
    tails: tuple[Effect, ...] = ()

    def execute(self, ctx: EffectContext) -> None:
        heads_result = ctx.rng.random() < 0.5
        ctx.last_coin_result = heads_result
        ctx.log("コイン: オモテ" if heads_result else "コイン: ウラ")
        for effect in (self.heads if heads_result else self.tails):
            effect.execute(ctx)


@dataclass(frozen=True)
class DealDamagePerHeads(Effect):
    coin_count: int
    damage_per_heads: int
    base: int = 0  # パラセクト(Parasect)「Scissor Swing」実カードテキスト: "Flip 2 coins. This attack
    # does 30 more damage for each heads."(base=60)用に基本ダメージを追加できるようにした

    def execute(self, ctx: EffectContext) -> None:
        coin_count = self.coin_count
        mon = ctx.source_pokemon
        if (
            mon is not None
            and mon.coin_count_override_until_turn > 0
            and _attacker_player(ctx).turns_taken <= mon.coin_count_override_until_turn
            and mon.coin_count_override_attack == mon.current_attack_name
        ):
            coin_count = mon.coin_count_override_amount  # Exciting Shake: 次の番、このワザで投げるコインの数が変わる
        heads_count = sum(1 for _ in range(coin_count) if ctx.rng.random() < 0.5)
        ctx.coin_heads_count = heads_count
        DealDamage(self.base + heads_count * self.damage_per_heads).execute(ctx)


@dataclass(frozen=True)
class DamagePerDefenderDamageCounters(Effect):
    base: int
    per_counter: int

    def execute(self, ctx: EffectContext) -> None:
        _, defender = _defender(ctx)
        counters = (defender.damage // 10) if defender else 0
        DealDamage(self.base + self.per_counter * counters).execute(ctx)


@dataclass(frozen=True)
class DamagePerSelfDamageCounters(Effect):
    per_counter: int
    base: int = 0  # ドドゲザン(Dondozo ex)「Avenging Billow」実カードテキスト: "This attack does 10 more
    # damage for each damage counter on this Pokémon."(base=30)用に基本ダメージを追加できるようにした

    def execute(self, ctx: EffectContext) -> None:
        if ctx.source_pokemon is None:
            return
        counters = ctx.source_pokemon.damage // 10
        DealDamage(self.base + self.per_counter * counters).execute(ctx)


@dataclass(frozen=True)
class DamagePerOpponentPrizesTaken(Effect):
    """実カードテキスト"...for each Prize card your opponent has taken"通り、相手(防御側)が
    既に取ったサイドの枚数(=相手の残りサイドの少なさ)を参照する(リザードンexの「Burning
    Darkness」/シェイミEXの「Revenge Blast」/ペチャルンgexの「Irritated Outburst」等。
    以前は自分自身の残りサイドを参照しており、常に0扱いになりがちだった)。"""

    base: int
    per_prize: int

    def execute(self, ctx: EffectContext) -> None:
        opponent = ctx.state.player(ctx.opponent)
        prizes_taken = 6 - len(opponent.prizes)
        DealDamage(self.base + self.per_prize * prizes_taken).execute(ctx)


@dataclass(frozen=True)
class DamageIfOwnPrizesRemainingExactly(Effect):
    """自分の残りサイドがちょうどexact_count枚のとき、追加ダメージ(アーゴヨンの「Turning Point」等)。"""

    base: int
    bonus: int
    exact_count: int

    def execute(self, ctx: EffectContext) -> None:
        acting_player = _attacker_player(ctx)
        bonus = self.bonus if len(acting_player.prizes) == self.exact_count else 0
        DealDamage(self.base + bonus).execute(ctx)


@dataclass(frozen=True)
class DiscardOwnEnergy(Effect):
    """このポケモンについているエネルギーをちょうどcount枚(energy_type指定時はその基本タイプのみ)
    トラッシュする。「N枚」は常にカード枚数であり、無色3個ぶんとして働くイグニッションエネルギー
    のような特殊エネルギーが混ざっていても、それを1枚のカードとして数える(公式ルール上、
    「エネルギーを1枚捨てる」等の指定は常に物理的なカード枚数であり、コスト計算上の「N個ぶん」とは
    無関係)。候補が要求枚数以下しかない、または全て同じ印刷のカードで選ぶ意味が無い場合は
    選択を挟まず自動でトラッシュする。異なる種類のエネルギーが要求枚数より多く付いている場合は、
    どれを捨てるかプレイヤー自身に選ばせる(以前は常にattached_energyの先頭から機械的に選んでおり、
    例えば無色3個ぶんのイグニッションエネルギーを残して基本水エネルギーだけを選んで捨てる、
    といった選択ができなかった不具合。ゲッコウガexの「ぶんしんれんだ」でユーザー報告、2026-09-01)。"""

    count: int
    energy_type: str | None = None  # None = 種類を問わず

    def execute(self, ctx: EffectContext) -> None:
        if ctx.source_pokemon is None:
            return
        eligible_indices = [
            i for i, eid in enumerate(ctx.source_pokemon.attached_energy) if self._matches(ctx, eid)
        ]
        if not eligible_indices:
            return
        distinct_ids = {ctx.source_pokemon.attached_energy[i] for i in eligible_indices}
        if len(eligible_indices) <= self.count or len(distinct_ids) == 1:
            discard_positions = set(eligible_indices[: self.count])
            player = _attacker_player(ctx)
            remaining: list[str] = []
            for i, eid in enumerate(ctx.source_pokemon.attached_energy):
                if i in discard_positions:
                    player.discard.append(eid)
                else:
                    remaining.append(eid)
            ctx.source_pokemon.attached_energy = remaining
            return
        source_indices, card_ids = _field_attachment_candidates(
            ctx.state,
            ctx.card_db,
            (ctx.acting_player,),
            include_tool=False,
            energy_predicate=lambda c: self.energy_type is None or c.basic_energy_type == self.energy_type,
            only_pokemon=ctx.source_pokemon,
        )
        ctx.state.pending_search_choice = PendingSearchChoice(
            player_index=ctx.acting_player,
            zone="field_attachment",
            source_indices=source_indices,
            card_ids=card_ids,
            min_count=self.count,
            max_count=self.count,
            prompt="トラッシュするエネルギーを選ぶ",
            shuffle_after=False,
            all_card_ids=list(card_ids),
            destination="discard",
            cont_source_pokemon=ctx.source_pokemon,
            cont_source_card_id=ctx.source_card_id,
        )

    def _matches(self, ctx: EffectContext, energy_id: str) -> bool:
        if self.energy_type is None:
            return True
        card = ctx.card_db.get(energy_id)
        return card is not None and card.basic_energy_type == self.energy_type


@dataclass(frozen=True)
class DiscardAllOwnEnergy(Effect):
    """このポケモンについているエネルギーを全てトラッシュする。energy_type指定時は、そのタイプの基本エネルギーだけを
    全てトラッシュする("Discard all Fire Energy attached to this Pokémon.")。"""

    energy_type: str | None = None

    def execute(self, ctx: EffectContext) -> None:
        if ctx.source_pokemon is None:
            return
        player = _attacker_player(ctx)
        if self.energy_type is None:
            player.discard.extend(ctx.source_pokemon.attached_energy)
            ctx.source_pokemon.attached_energy = []
            return
        kept = []
        for energy_id in ctx.source_pokemon.attached_energy:
            card = ctx.card_db.get(energy_id)
            if card is not None and card.basic_energy_type == self.energy_type:
                player.discard.append(energy_id)
            else:
                kept.append(energy_id)
        ctx.source_pokemon.attached_energy = kept


@dataclass(frozen=True)
class SearchDeckAndAttachEnergy(Effect):
    """energy_type=Noneならタイプを問わず基本エネルギーを検索する(ソルガレオGXの「ソルバーストGX」等)。
    self_only=True(既定、ラッキー&メルメタルGXの「Steel Fist」等「このポケモンにつける」テキスト向け)なら
    対象はこのポケモン自身固定。Falseなら自分の場から対象を選べる(シェイミEXの「Synthesis」等)。
    見つかった分は全て同じ対象1体にまとめてつける(実カードでは複数体に分けてつけられる場合もあるが、
    v1では1体にまとめる簡略版とする)。"""

    energy_type: str | None
    count: int = 1
    self_only: bool = True
    bench_only: bool = False
    target_type: str | None = None
    any_energy: bool = False

    def execute(self, ctx: EffectContext) -> None:
        if ctx.source_pokemon is None:
            return
        player = _attacker_player(ctx)
        target = ctx.source_pokemon if self.self_only else _resolve_own_target(ctx, player)
        if target is None:
            return
        found = 0
        remaining_deck: list[str] = []
        for card_id in player.deck:
            card = ctx.card_db.get(card_id)
            if self.any_energy:
                matches = card is not None and card.is_energy
            else:
                matches = card is not None and card.is_energy and (self.energy_type is None or card.basic_energy_type == self.energy_type)
            if found < self.count and matches:
                found += 1
                target.attached_energy.append(card_id)
            else:
                remaining_deck.append(card_id)
        player.deck = remaining_deck
        ctx.rng.shuffle(player.deck)


def _zone_list(player: PlayerState, zone: str) -> list[str]:
    if zone == "deck":
        return player.deck
    if zone == "hand":
        return player.hand
    return player.discard


def _discard_to_hand_blocked_for(ctx: EffectContext, discard_owner: PlayerState) -> bool:
    """リククラゲの「Slime Mold Colony」: 特性またはトレーナーズ(=ポケモン自身の効果ではない、ワザ以外)の
    効果でトラッシュのカードを手札に加えようとしているか、かつ相手の場にリククラゲがいるか。"""
    from engine.continuous import discard_to_hand_blocked

    if ctx.effect_source != "ability" and ctx.source_pokemon is not None:
        return False  # ワザ由来(ワザを使っているポケモンがいる)
    owner_index = 0 if discard_owner is ctx.state.players[0] else 1
    return discard_to_hand_blocked(ctx.state, ctx.card_db, owner_index)


def _trigger_search_choice(
    ctx: EffectContext,
    player: PlayerState,
    zone: str,
    predicate,
    count: int,
    prompt: str,
    shuffle_after: bool = True,
    destination: str = "hand",
    min_count: int = 0,
) -> None:
    """山札/トラッシュ/手札から条件に合うカードを検索し、プレイヤーの選択待ちにする。

    候補が無ければ即座にログだけ残して終わる(選択UIを出す必要がないため)。
    destination="bench" のときは自分のベンチの空き数でも上限が絞られる(バディバディ系の効果用)。
    min_count>0 を指定すると、コストとしての「カードを選んで捨てる」等、必ず選ばせたい場合に使える
    (候補数がmin_countに満たない場合はmin_countを候補数に切り下げる)。
    """
    if zone == "discard" and destination == "hand" and _discard_to_hand_blocked_for(ctx, player):
        ctx.log(f"{prompt}: (リククラゲの特性「Slime Mold Colony」でトラッシュから手札に加えられない)")
        return
    source = _zone_list(player, zone)
    eligible = [(i, cid) for i, cid in enumerate(source) if predicate(ctx.card_db.get(cid))]

    def rank(card_id: str) -> int:
        card = ctx.card_db.get(card_id)
        return card.display_category_rank if card else 99

    eligible.sort(key=lambda pair: rank(pair[1]))
    if not eligible:
        ctx.log(f"{prompt}: (該当なし)")
        return
    max_count = min(count, len(eligible))
    min_count = min(min_count, max_count)
    if destination == "bench":
        from engine.continuous import effective_bench_limit

        max_count = min(max_count, effective_bench_limit(ctx.state, player, ctx.card_db) - len(player.bench))
        if max_count <= 0:
            ctx.log(f"{prompt}: (ベンチに空きがない)")
            return
    ctx.state.pending_search_choice = PendingSearchChoice(
        player_index=ctx.acting_player,
        zone=zone,
        source_indices=[i for i, _ in eligible],
        card_ids=[cid for _, cid in eligible],
        min_count=min_count,
        max_count=max_count,
        prompt=prompt,
        shuffle_after=shuffle_after,
        all_card_ids=sorted(source, key=rank),
        destination=destination,
        effect_source=ctx.effect_source,
        source_card_id=ctx.source_card_id,
    )


@dataclass(frozen=True)
class SearchDeckForPokemonToHand(Effect):
    count: int = 1
    only_basic: bool = False
    only_sp: bool = False
    exclude_level_up: bool = False
    pokemon_type: str | None = None
    pokemon_types_any: tuple[str, ...] | None = None  # ミステリートレジャー等: 複数タイプのいずれかでよい場合(OR条件)
    max_hp: int | None = None
    only_gx: bool = False
    only_gx_or_ex: bool = False  # 電磁レーダー等: "any combination of Pokémon-GX and Pokémon-EX" のような場合
    min_retreat_cost: int | None = None  # ヘビーボール等: にげるコストがN以上のポケモン限定
    max_retreat_cost: int | None = None  # とりのはね等: にげるコストがN以下(0指定で「にげるコスト0」)のポケモン限定
    no_rule_box: bool = False  # ポケパッド等: ルール箱を持つポケモン(ex/V/VMAX/VSTAR/MEGA等)は対象外
    required_subtypes: tuple[str, ...] = ()  # 指定時は全て(AND条件)を満たすポケモンのみ(メガシグナル
    # 実カードテキスト: "a Mega Evolution Pokémon ex" = ("MEGA", "ex")両方を持つポケモン限定)
    name_prefix: str | None = None  # 指定時はカード名がその接頭辞で始まるポケモンのみ(シンジのガバイト
    # 「Champion's Call」実カードテキスト: "search your deck for a Cynthia's Pokémon"用)
    exclude_basic: bool = False  # 指定時はたねポケモンを除外(進化ポケモン限定、ロケット団のモンスターボール
    # 実カードテキスト: "search your deck for an Evolution Team Rocket's Pokémon"用)
    exclude_name: str | None = None  # 指定時はそのカード名のポケモンを除外(フーパEXの「Scoundrel Ring」: "except for Hoopa-EX")

    def execute(self, ctx: EffectContext) -> None:
        player = _attacker_player(ctx)

        def matches(card):
            return (
                card is not None
                and card.is_pokemon
                and (self.exclude_name is None or card.name != self.exclude_name)
                and (not self.only_basic or card.is_basic)
                and (not self.exclude_basic or not card.is_basic)
                and (not self.only_sp or card.is_sp_pokemon)
                and (not self.exclude_level_up or not card.is_level_up)
                and (self.pokemon_type is None or self.pokemon_type in card.types)
                and (self.pokemon_types_any is None or any(t in card.types for t in self.pokemon_types_any))
                and (self.max_hp is None or (card.hp is not None and card.hp <= self.max_hp))
                and (not self.only_gx or "GX" in card.subtypes)
                and (not self.only_gx_or_ex or bool({"GX", "EX", "ex"} & set(card.subtypes)))
                and (self.min_retreat_cost is None or card.retreat_cost_count >= self.min_retreat_cost)
                and (self.max_retreat_cost is None or card.retreat_cost_count <= self.max_retreat_cost)
                and (not self.no_rule_box or not (_RULE_BOX_SUBTYPES & set(card.subtypes)))
                and all(st in card.subtypes for st in self.required_subtypes)
                and (self.name_prefix is None or card.name.startswith(self.name_prefix))
            )

        _trigger_search_choice(ctx, player, "deck", matches, self.count, "山札からポケモンを探す")


@dataclass(frozen=True)
class SearchDeckForBasicPokemonToBench(Effect):
    """山札からたねポケモン(HP上限つき)を選んで、手札を経由せず直接ベンチに出す(バディバディ系)。
    required_subtype指定時はそのサブタイプ限定(ソブルの「Keep Calling」の「Rapid Strike」タグ限定等)。"""

    count: int
    max_hp: int | None = None
    pokemon_type: str | None = None
    pokemon_types_any: tuple[str, ...] | None = None  # ブルクリンヒルズ等: 複数タイプのいずれかでよい場合(OR条件)
    required_subtype: str | None = None
    no_rule_box: bool = False  # アルタイル市(Artazon)等: ルール箱を持つポケモン(ex/V/VMAX/VSTAR等)は対象外

    def execute(self, ctx: EffectContext) -> None:
        player = _attacker_player(ctx)

        def matches(card):
            return (
                card is not None
                and card.is_basic
                and (self.max_hp is None or (card.hp is not None and card.hp <= self.max_hp))
                and (self.pokemon_type is None or self.pokemon_type in card.types)
                and (self.pokemon_types_any is None or any(t in card.types for t in self.pokemon_types_any))
                and (self.required_subtype is None or self.required_subtype in card.subtypes)
                and (not self.no_rule_box or not (_RULE_BOX_SUBTYPES & set(card.subtypes)))
            )

        _trigger_search_choice(
            ctx, player, "deck", matches, self.count, "山札からたねポケモンを探してベンチに出す", destination="bench"
        )


@dataclass(frozen=True)
class SearchDeckForBasicExOrThreeBasicToBench(Effect):
    """山札から、たねポケモンEXを1枚、または、たねポケモン(EXを除く)を3枚まで選んで、ベンチに出す(プラターヌ博士の
    贈り物(Brigette)実カードテキスト: "Search your deck for 1 Basic Pokémon-EX or 3 Basic Pokémon (except for
    Pokémon-EX) and put them onto your Bench.")。以前はEX1匹のオプションが無かった(2026-10-06訂正)。"""

    def execute(self, ctx: EffectContext) -> None:
        player = _attacker_player(ctx)
        _trigger_search_choice(
            ctx, player, "deck", lambda card: card is not None and card.is_basic, 3,
            "山札からたねポケモンEXを1枚、またはたねポケモン(EX以外)を3枚まで探してベンチに出す", destination="bench",
        )
        if ctx.state.pending_search_choice is not None:
            ctx.state.pending_search_choice.exclusive_subtype = "EX"


@dataclass(frozen=True)
class DiscardHandThenDraw(Effect):
    draw_count: int

    def execute(self, ctx: EffectContext) -> None:
        player = _attacker_player(ctx)
        player.discard.extend(player.hand)
        player.hand = []
        Draw(self.draw_count).execute(ctx)


@dataclass(frozen=True)
class RandomOpponentHandCardToDeck(Effect):
    """相手の手札からランダムに1枚選び、公開してから山札に戻してシャッフルする
    (ボクレーの「Astonish」/ソーナノの「Whiny Voice」等)。"""

    def execute(self, ctx: EffectContext) -> None:
        opponent = ctx.state.player(ctx.opponent)
        if not opponent.hand:
            return
        idx = ctx.rng.randrange(len(opponent.hand))
        card_id = opponent.hand.pop(idx)
        opponent.deck.append(card_id)
        ctx.rng.shuffle(opponent.deck)
        name = ctx.card_db.get(card_id).name if ctx.card_db.get(card_id) else card_id
        ctx.log(f"相手の手札からランダムに{name}を公開し、山札に戻した")


@dataclass(frozen=True)
class DiscardRandomFromOpponentHand(Effect):
    """相手の手札からランダムに1枚選び、トラッシュする(ギラティナ(xyp-184)の「Shadow Claw」
    実カードテキスト: "Discard a random card from your opponent's hand."用)。"""

    def execute(self, ctx: EffectContext) -> None:
        opponent = ctx.state.player(ctx.opponent)
        if not opponent.hand:
            return
        idx = ctx.rng.randrange(len(opponent.hand))
        card_id = opponent.hand.pop(idx)
        opponent.discard.append(card_id)
        name = ctx.card_db.get(card_id).name if ctx.card_db.get(card_id) else card_id
        ctx.log(f"相手の手札からランダムに{name}をトラッシュした")


@dataclass(frozen=True)
class Draw(Effect):
    count: int

    def execute(self, ctx: EffectContext) -> None:
        player = _attacker_player(ctx)
        for _ in range(self.count):
            if not player.deck:
                break
            player.hand.append(player.deck.pop(0))


@dataclass(frozen=True)
class DrawPerOpponentBenchCount(Effect):
    """相手のベンチポケモンの数ぶんカードを引く(マツバの確信等)。"""

    def execute(self, ctx: EffectContext) -> None:
        player = _attacker_player(ctx)
        opponent = ctx.state.player(ctx.opponent)
        for _ in range(len(opponent.bench)):
            if not player.deck:
                break
            player.hand.append(player.deck.pop(0))


@dataclass(frozen=True)
class DrawBonusIfActive(Effect):
    """baseの枚数を引き、このポケモン自身がバトル場にいればさらにbonus_if_active枚多く引く
    (サーフゴーexの特性「コインボーナス」)。"""

    base: int
    bonus_if_active: int

    def execute(self, ctx: EffectContext) -> None:
        player = _attacker_player(ctx)
        count = self.base + (self.bonus_if_active if ctx.source_pokemon is player.active else 0)
        Draw(count).execute(ctx)


@dataclass(frozen=True)
class DiscardCardsFromHand(Effect):
    """手札からカードを指定枚数、プレイヤーに選ばせてトラッシュする(コストとしての使用、必ず上限枚数まで選ばせる)。

    only_item=True のときは「もう1枚のグッズを選んでトラッシュ」(ウッウロボ等)のように、
    捨てられるカードの候補をグッズカードのみに絞る。only_energy_type指定時はその基本エネルギー限定
    (ヒートファクトリー◇の「炎エネルギーを1枚捨てて」等)。候補が無ければ何も起きない(選択UIも出ない)。
    """

    count: int
    only_item: bool = False
    only_energy_type: str | None = None
    only_energy_types_any: tuple[str, ...] | None = None  # スコーチドアース等: 複数タイプのいずれかでよい場合(OR条件)

    def execute(self, ctx: EffectContext) -> None:
        player = _attacker_player(ctx)
        n = min(self.count, len(player.hand))
        if n <= 0:
            return

        def matches(card):
            if self.only_item:
                return card is not None and card.is_item
            if self.only_energy_type:
                return card is not None and card.basic_energy_type == self.only_energy_type
            if self.only_energy_types_any:
                return card is not None and card.basic_energy_type in self.only_energy_types_any
            return True

        _trigger_search_choice(
            ctx,
            player,
            "hand",
            matches,
            n,
            "トラッシュするカードを選ぶ",
            shuffle_after=False,
            destination="discard",
            min_count=n,
        )


@dataclass(frozen=True)
class MayDiscardHandCardThenDraw(Effect):
    """手札からカードを1枚選んで捨ててもよく、そうしたなら指定枚数引く(シンジ&カトレア等)。
    custom_data={"mode": "may_discard_then_draw", ...}をengine.rules_engine側が見て、
    実際に捨てられたかどうかで後続のドローを条件付ける。card_criterion指定時は、その条件に
    合うカードのみが選択候補になる(アーゴヨンGXの「Ultra Conversion」実カードテキスト:
    "discard an Ultra Beast card from your hand"等、SearchDeckMultiCriteria._matchesの
    criterion文字列をそのまま流用する)。"""

    draw_count: int
    card_criterion: str | None = None

    def execute(self, ctx: EffectContext) -> None:
        player = _attacker_player(ctx)
        if not player.hand:
            return

        def matches(card):
            if card is None:
                return False
            if self.card_criterion is None:
                return True
            return SearchDeckMultiCriteria._matches(card, self.card_criterion)

        _trigger_search_choice(
            ctx,
            player,
            "hand",
            matches,
            1,
            "捨てるカードを選ぶ(選ばなくてもよい)",
            shuffle_after=False,
            destination="discard",
            min_count=0,
        )
        if ctx.state.pending_search_choice is not None:
            ctx.state.pending_search_choice.custom_data = {"mode": "may_discard_then_draw", "draw_count": self.draw_count}


@dataclass(frozen=True)
class DiscardChosenNonRuleBoxPokemonThenDrawPerCount(Effect):
    """手札からルール箱を持たないポケモンを最大max_count枚まで選んでトラッシュし、
    捨てた枚数ぶんそれぞれdraw_per_count枚ずつ引く(ムク(Gwynn))。"""

    max_count: int
    draw_per_count: int

    def execute(self, ctx: EffectContext) -> None:
        player = _attacker_player(ctx)

        def matches(card):
            return card is not None and card.is_pokemon and not (_RULE_BOX_SUBTYPES & set(card.subtypes))

        _trigger_search_choice(
            ctx, player, "hand", matches, self.max_count, f"ルール箱を持たないポケモンを最大{self.max_count}枚選んでトラッシュする(選ばなくてもよい)",
            shuffle_after=False, destination="discard", min_count=0,
        )
        if ctx.state.pending_search_choice is not None:
            ctx.state.pending_search_choice.custom_data = {"mode": "discard_then_draw_per_count", "draw_per_count": self.draw_per_count}


@dataclass(frozen=True)
class DiscardAnyHandCardsOptional(Effect):
    """手札から好きな枚数(0枚でもよい)を選んでトラッシュする(ピュール等、後続のDrawUpTo等と
    組み合わせて「捨ててから引く」を表現する。run_scriptの自動継続の仕組みにより、この効果の
    次にタプルへ並べた効果は選択確定後に自動的に実行される)。"""

    def execute(self, ctx: EffectContext) -> None:
        player = _attacker_player(ctx)
        _trigger_search_choice(
            ctx, player, "hand", lambda card: True, len(player.hand), "手札を好きな枚数トラッシュする(選ばなくてもよい)",
            shuffle_after=False, destination="discard", min_count=0,
        )


@dataclass(frozen=True)
class DiscardHandCostThenRetrieveEnergyExcludingDiscarded(Effect):
    """手札からdiscard_count枚を選んでトラッシュすることをコストとし、その後トラッシュから基本
    エネルギーを最大energy_count枚選んで手札に加える(このコストで今捨てた分は対象外)
    (スーパーエネルギー回収)。custom_data={"mode": "superior_energy_retrieval", ...}を
    engine.rules_engine側が見て、捨てた分を除外しつつ後続のエネルギー回収を解決する。"""

    discard_count: int
    energy_count: int

    def execute(self, ctx: EffectContext) -> None:
        player = _attacker_player(ctx)
        n = min(self.discard_count, len(player.hand))
        if n <= 0:
            return
        _trigger_search_choice(
            ctx,
            player,
            "hand",
            lambda card: True,
            n,
            "トラッシュするカードを2枚選ぶ",
            shuffle_after=False,
            destination="discard",
            min_count=n,
        )
        if ctx.state.pending_search_choice is not None:
            ctx.state.pending_search_choice.custom_data = {
                "mode": "superior_energy_retrieval",
                "energy_count": self.energy_count,
            }


@dataclass(frozen=True)
class SwitchActiveWithBench(Effect):
    def execute(self, ctx: EffectContext) -> None:
        player = _attacker_player(ctx)
        if ctx.target_bench_index is None or ctx.target_bench_index >= len(player.bench):
            return
        new_active = player.bench.pop(ctx.target_bench_index)
        old_active = player.active
        if player.active is not None:
            player.active.status.clear_all()
            player.bench.append(player.active)
        new_active.status.clear_all()
        new_active.became_active_turn = player.turns_taken
        player.active = new_active
        if old_active is not None:
            from effects.era_tools_j import on_active_moved_to_bench

            on_active_moved_to_bench(ctx.state, ctx.card_db, ctx.acting_player, old_active)  # スパイクタウン


@dataclass(frozen=True)
class SwitchActiveWithBenchThenHealBenched(Effect):
    """選んだベンチポケモンとバトルポケモンを入れ替え、ベンチに下がった側のダメカンをheal_amountぶん
    回復する(のりかえチケット、Switch Cart)。"""

    heal_amount: int

    def execute(self, ctx: EffectContext) -> None:
        player = _attacker_player(ctx)
        if ctx.target_bench_index is None or ctx.target_bench_index >= len(player.bench):
            return
        new_active = player.bench.pop(ctx.target_bench_index)
        old_active = player.active
        if old_active is not None:
            old_active.status.clear_all()
            old_active.heal(self.heal_amount)
            player.bench.append(old_active)
        new_active.status.clear_all()
        player.active = new_active


@dataclass(frozen=True)
class MoveEnergyBetweenOwnPokemon(Effect):
    """move_all=Trueなら条件に合うエネルギーを全て移動する(マラマラの「Energy Slosh」等)、
    Falseなら1枚だけ(既定の挙動)。"""

    energy_type: str | None = None
    move_all: bool = False
    count: int | None = None  # ヤンメガex「Jet Cyclone」実カードテキスト: "Move 3 Energy from this
    # Pokémon to 1 of your Benched Pokémon."用、指定時はmove_all/1枚固定より優先してちょうどcount枚
    # (足りなければあるだけ)移動する
    basic_only: bool = False  # "Move a basic Energy ..." 基本エネルギーだけが対象

    def execute(self, ctx: EffectContext) -> None:
        if ctx.source_pokemon is None:
            return
        player = _attacker_player(ctx)
        target = _resolve_own_target(ctx, player, exclude=ctx.source_pokemon)
        if target is None:
            return
        matching = [
            energy_id
            for energy_id in ctx.source_pokemon.attached_energy
            if (card := ctx.card_db.get(energy_id)) is not None
            and (self.energy_type is None or card.basic_energy_type == self.energy_type)
            and (not self.basic_only or card.basic_energy_type is not None)
        ]
        if not matching:
            return
        if self.count is not None:
            amount = min(self.count, len(matching))
        else:
            amount = len(matching) if self.move_all else 1
        if amount < len(matching) and len(set(matching)) > 1:
            # 種類の違うエネルギーがあるときは、どれを移すかを自分で選ぶ(以前は先頭から機械的に選んでいた、2026-10-06訂正)
            source_indices, card_ids = _field_attachment_candidates(
                ctx.state, ctx.card_db, (ctx.acting_player,), include_tool=False,
                energy_predicate=lambda c: (self.energy_type is None or c.basic_energy_type == self.energy_type)
                and (not self.basic_only or c.basic_energy_type is not None),
                only_pokemon=ctx.source_pokemon,
            )
            ctx.state.pending_search_choice = PendingSearchChoice(
                player_index=ctx.acting_player,
                zone="field_attachment",
                source_indices=source_indices,
                card_ids=card_ids,
                min_count=amount,
                max_count=amount,
                prompt="移すエネルギーを選ぶ",
                shuffle_after=False,
                all_card_ids=list(card_ids),
                destination="attach_energy",
                attach_target_pokemon=target,
                cont_source_pokemon=ctx.source_pokemon,
                cont_source_card_id=ctx.source_card_id,
            )
            return
        for energy_id in matching[:amount]:
            ctx.source_pokemon.attached_energy.remove(energy_id)
            target.attached_energy.append(energy_id)


def _resolve_own_target(
    ctx: EffectContext, player: PlayerState, exclude: PokemonInPlay | None = None
) -> PokemonInPlay | None:
    if ctx.target_bench_index is not None:
        if 0 <= ctx.target_bench_index < len(player.bench):
            candidate = player.bench[ctx.target_bench_index]
            if candidate is not exclude:
                return candidate
        return None
    if player.active is not None and player.active is not exclude:
        return player.active
    return None


@dataclass(frozen=True)
class NotImplementedEffect(Effect):
    """v1では未実装のカード効果(将来Phase 5で拡張)。実行しても何も起きない。"""

    note: str = ""

    def execute(self, ctx: EffectContext) -> None:
        ctx.log(f"[未実装の効果: {self.note}]")


# ---- WCS2010(がブレンミラー)向けに追加したプリミティブ ----


@dataclass(frozen=True)
class DiscardEnergyFromHand(Effect):
    """手札からエネルギーを捨てる(攻撃側についているエネルギーではなく手札のコスト)。"""

    count: int

    def execute(self, ctx: EffectContext) -> None:
        player = _attacker_player(ctx)
        removed = 0
        remaining: list[str] = []
        for card_id in player.hand:
            card = ctx.card_db.get(card_id)
            if removed < self.count and card is not None and card.is_energy:
                removed += 1
                player.discard.append(card_id)
            else:
                remaining.append(card_id)
        player.hand = remaining
        ctx.last_discard_succeeded = removed > 0


@dataclass(frozen=True)
class BenchDamageAll(Effect):
    """自分または相手のベンチ全員にダメージ(弱点・抵抗力は計算しない)。"""

    amount: int
    side: str  # "own" | "opponent"
    only_if_damaged: bool = False

    def execute(self, ctx: EffectContext) -> None:
        player = ctx.state.player(ctx.acting_player if self.side == "own" else ctx.opponent)
        for mon in player.bench:
            if self.only_if_damaged and mon.damage <= 0:
                continue
            mon.damage += self.amount
        ctx.log(f"ベンチ全員に{self.amount}ダメージ({self.side})")


@dataclass(frozen=True)
class DamageIfDefenderPoisoned(Effect):
    base: int
    bonus: int

    def execute(self, ctx: EffectContext) -> None:
        _, defender = _defender(ctx)
        bonus = self.bonus if (defender is not None and defender.status.poisoned) else 0
        DealDamage(self.base + bonus).execute(ctx)


@dataclass(frozen=True)
class DamageIfDefenderIsSP(Effect):
    if_sp: int
    if_not_sp: int

    def execute(self, ctx: EffectContext) -> None:
        _, defender = _defender(ctx)
        defender_card = ctx.card_db.get(defender.card_id) if defender else None
        amount = self.if_sp if (defender_card and defender_card.is_sp_pokemon) else self.if_not_sp
        DealDamage(amount).execute(ctx)


@dataclass(frozen=True)
class DamageIfDefenderHasEnergy(Effect):
    if_has_energy: int
    if_no_energy: int

    def execute(self, ctx: EffectContext) -> None:
        _, defender = _defender(ctx)
        has_energy = bool(defender and defender.attached_energy)
        DealDamage(self.if_has_energy if has_energy else self.if_no_energy).execute(ctx)


@dataclass(frozen=True)
class DealDamageToChosenOpponentPokemon(Effect):
    """アクティブに限らず相手の場のポケモンを選んでダメージ(ベンチ対象は弱点・抵抗力を計算しない)。"""

    amount: int

    def execute(self, ctx: EffectContext) -> None:
        if ctx.source_pokemon is None:
            return
        opponent = ctx.state.player(ctx.opponent)
        target = _resolve_opponent_target(ctx, opponent)
        if target is None or _defender_is_shielded(ctx, target):
            return
        attacker_card = ctx.card_db.get(ctx.source_pokemon.card_id)
        if attacker_card is None:
            return
        defender_card = ctx.card_db.get(target.card_id)
        if defender_card is None:
            return
        apply_wr = ctx.target_bench_index is None  # ベンチは弱点・抵抗力を計算しない
        dmg = resolve_attack_damage(ctx, target, defender_card, self.amount, apply_weakness=apply_wr, apply_resistance=apply_wr)
        target.damage += dmg
        ctx.damage_dealt += dmg
        ctx.log(f"{ctx.source_card_id} が相手の場のポケモンに {dmg} ダメージ")


@dataclass(frozen=True)
class DealDamageToChosenOpponentPokemonMulti(Effect):
    """相手の場のポケモンを複数体(最大count体、相手の場にいる数がそれより少なければその数だけ)選び、
    それぞれに同じ量のダメージ(ベンチ対象は弱点・抵抗力を計算しない、ラディアントゲッコウガの
    「Moonlight Shuriken」/キュレムの「Trifrost」/れんげきウーラオスVMAXの「G-Max Rapid Flow」等)。
    対象選択はzone="opponent_pokemon_target"をengine.rules_engine側が解決する。"""

    count: int
    amount: int

    def execute(self, ctx: EffectContext) -> None:
        if ctx.source_pokemon is None:
            return
        opponent = ctx.state.player(ctx.opponent)
        candidates = []
        if opponent.active is not None:
            candidates.append((0, opponent.active))
        for i, mon in enumerate(opponent.bench):
            candidates.append((i + 1, mon))
        if not candidates:
            return
        n = min(self.count, len(candidates))
        ctx.state.pending_search_choice = PendingSearchChoice(
            player_index=ctx.acting_player,
            zone="opponent_pokemon_target",
            source_indices=[slot for slot, _ in candidates],
            card_ids=[mon.card_id for _, mon in candidates],
            min_count=n,
            max_count=n,
            prompt=f"ダメージを与える相手のポケモンを{n}体選ぶ",
            shuffle_after=False,
            all_card_ids=[mon.card_id for _, mon in candidates],
            cont_source_pokemon=ctx.source_pokemon,
            cont_source_card_id=ctx.source_card_id,
            custom_data={"mode": "damage_multi", "amount": self.amount},
        )


@dataclass(frozen=True)
class DealBonusDamageToChosenOpponentBench(Effect):
    """メインの攻撃対象(バトルポケモン)への通常ダメージに加えて、選んだ相手のベンチポケモン1匹に
    追加ダメージ(弱点・抵抗力は計算しない)。target_bench_indexが指定されていなければ何もしない
    (インテレオンの「アクアバレット」、レジドラゴVの「ドラゴンレーザー」等)。"""

    amount: int
    ex_only: bool = False  # ゼラオラ(Zeraora)「Thunder Raid」実カードテキスト: "does 210 damage to 1 of
    # your opponent's Benched Pokémon ex."用、対象はexポケモンのみ(engine.legal_actions側で候補を絞り込む)
    damaged_only: bool = False  # ドリルライナーex(Excadrill ex)「Piercing Drill」実カードテキスト:
    # "does 60 damage to 1 of your opponent's Benched Pokémon that has any damage counters on it."用、
    # 対象はダメカンが乗っているベンチポケモンのみ(engine.legal_actions側で候補を絞り込む)

    def execute(self, ctx: EffectContext) -> None:
        if ctx.target_bench_index is None:
            return
        opponent = ctx.state.player(ctx.opponent)
        if not (0 <= ctx.target_bench_index < len(opponent.bench)):
            return
        target = opponent.bench[ctx.target_bench_index]
        if _defender_is_shielded(ctx, target):
            return
        target_card = ctx.card_db.get(target.card_id)
        if target_card is None:
            return
        if self.ex_only and "ex" not in target_card.subtypes:
            return
        if self.damaged_only and target.damage <= 0:
            return
        dmg = resolve_attack_damage(ctx, target, target_card, self.amount, apply_weakness=False, apply_resistance=False)
        target.damage += dmg
        ctx.log(f"{ctx.source_card_id} が相手ベンチに追加で {dmg} ダメージ")


@dataclass(frozen=True)
class ChooseOwnAttachedEnergyThenShuffleForBonusBenchDamage(Effect):
    """自分についているエネルギーが指定枚数以上あれば、そのうちenergy_count枚を自分で選んで
    山札に戻してシャッフルし、相手のベンチ1匹に追加ダメージ(オーガポン いどのめんex
    (Wellspring Mask Ogerpon ex)の「Torrential Pump」実カードテキスト: "You may shuffle 3
    Energy attached to this Pokemon into your deck. If you do, this attack also does 120
    damage to 1 of your opponent's Benched Pokemon."用)。
    ちょうどenergy_count枚しかついていなければ選ぶ余地は無いが、それより多くついている場合は
    「どの3枚を山札に戻すか」をプレイヤーが選べる(以前は先頭からenergy_count枚を機械的に
    選んでいたが、実カードは対象選択を制限していないため誤りだった、2026-08-22ユーザー報告で発覚)。
    「してもよい」効果なので、engine.legal_actions._attack_actionsがtarget_bench_index=Noneの
    「しない」選択肢も合法手に含める(このメソッドはNoneが渡ってきたらそのまま何もせず返る)。"""

    energy_count: int
    bonus_amount: int

    def execute(self, ctx: EffectContext) -> None:
        if ctx.source_pokemon is None or len(ctx.source_pokemon.attached_energy) < self.energy_count:
            return
        if ctx.target_bench_index is None:
            return
        opponent = ctx.state.player(ctx.opponent)
        if not (0 <= ctx.target_bench_index < len(opponent.bench)):
            return
        source_indices, card_ids = _field_attachment_candidates(
            ctx.state, ctx.card_db, (ctx.acting_player,), only_pokemon=ctx.source_pokemon,
            energy_predicate=lambda c: c.is_energy,
        )
        ctx.state.pending_search_choice = PendingSearchChoice(
            player_index=ctx.acting_player,
            zone="field_attachment",
            source_indices=source_indices,
            card_ids=card_ids,
            min_count=self.energy_count,
            max_count=self.energy_count,
            prompt="山札に戻すエネルギーを選ぶ",
            shuffle_after=True,
            all_card_ids=list(card_ids),
            destination="deck",
            cont_source_pokemon=ctx.source_pokemon,
            cont_source_card_id=ctx.source_card_id,
            custom_data={
                "mode": "shuffle_self_energy_bonus_bench_damage",
                "bonus_amount": self.bonus_amount,
                "target_bench_index": ctx.target_bench_index,
            },
        )


def _resolve_opponent_target(ctx: EffectContext, opponent: PlayerState) -> PokemonInPlay | None:
    if ctx.target_bench_index is not None:
        if 0 <= ctx.target_bench_index < len(opponent.bench):
            return opponent.bench[ctx.target_bench_index]
        return None
    return opponent.active


_HIDE_N_SNEAK_CARD_IDS = frozenset({"me5-33", "me5-34", "me5-5", "me5-6"})  # 「Hide 'n' Sneak」持ちの4体(カゲボウズ/ジュペッタ/チャデス/ヤバソチャ)


@dataclass(frozen=True)
class DamageCountersOnAllOpponentPokemonIfOwnHideNSneakDiscardThreshold(Effect):
    """自分のトラッシュに「Hide 'n' Sneak」を持つポケモンがthreshold体以上いれば、
    相手の場の全ポケモンにダメカンをcounters個ずつのせる(ヤバソチャの「Matcha Spin」)。"""

    threshold: int
    counters: int

    def execute(self, ctx: EffectContext) -> None:
        player = _attacker_player(ctx)
        count = sum(1 for cid in player.discard if cid in _HIDE_N_SNEAK_CARD_IDS)
        if count < self.threshold:
            return
        opponent = ctx.state.player(ctx.opponent)
        for mon in opponent.all_pokemon_in_play():
            if _blocks_damage_counters(mon) or _defender_is_shielded(ctx, mon) or _defender_blocks_non_damage_effects(ctx, mon):
                continue  # ダメカンを直接のせる=「効果」のため、ばけがくれ等でブロックされうる
            if ctx.state.stadium_in_play == _BATTLE_COLOSSEUM_STADIUM_ID and mon is not opponent.active:
                continue
            mon.damage += self.counters * 10
        ctx.log(f"相手の場の全ポケモンにダメカンを{self.counters}個ずつのせた")


@dataclass(frozen=True)
class DealDamageBonusIfOwnHideNSneakDiscardThreshold(Effect):
    """自分のトラッシュに「Hide 'n' Sneak」を持つポケモンがthreshold体以上いれば、
    baseに追加でbonusダメージ(ダダリンの「Vengeful Anchor」)。"""

    base: int
    bonus: int
    threshold: int

    def execute(self, ctx: EffectContext) -> None:
        player = _attacker_player(ctx)
        count = sum(1 for cid in player.discard if cid in _HIDE_N_SNEAK_CARD_IDS)
        amount = self.base + self.bonus if count >= self.threshold else self.base
        DealDamage(amount).execute(ctx)


@dataclass(frozen=True)
class DamageCounterOnDefender(Effect):
    """相手のバトルポケモン(固定、選択不可)にダメカンをのせる(弱点・抵抗力は計算しない)。
    チャデスの「Furtive Drop」("Place 1 damage counter on your opponent's Active Pokemon.")等、
    ベンチを選ぶ余地が無いカード用(DamageCounterOnChosenOpponentPokemonと違い対象選択させない)。"""

    count: int = 1

    def execute(self, ctx: EffectContext) -> None:
        _, target = _defender(ctx)
        if target is None or _defender_is_shielded(ctx, target) or _defender_blocks_non_damage_effects(ctx, target):
            return  # ダメカンを直接のせる=ワザ自体のダメージではなく「効果」のため、ばけがくれ等の対象になる
        if not tools_disabled(ctx.state.stadium_in_play) and _blocks_damage_counters(target):
            return
        target.damage += self.count * 10
        ctx.log(f"相手のバトルポケモンにダメカンを{self.count}個のせた")


@dataclass(frozen=True)
class DamageCounterOnChosenOpponentPokemon(Effect):
    """相手の場のポケモン1匹(バトル/ベンチどちらでも指定可)にダメカンをのせる(弱点・抵抗力は計算しない)。"""

    count: int = 1

    def execute(self, ctx: EffectContext) -> None:
        opponent = ctx.state.player(ctx.opponent)
        target = _resolve_opponent_target(ctx, opponent)
        if target is None or _defender_is_shielded(ctx, target) or _defender_blocks_effect(ctx, target):
            return  # ダメカンを直接のせる=ワザ自体のダメージではなく「効果」のため、ばけがくれ等の対象になる
        if not tools_disabled(ctx.state.stadium_in_play) and _blocks_damage_counters(target):
            return
        if (
            ctx.state.stadium_in_play == _BATTLE_COLOSSEUM_STADIUM_ID
            and ctx.target_bench_index is not None
        ):
            return
        target.damage += self.count * 10
        ctx.log(f"相手の場のポケモンにダメカンを{self.count}個のせた")


@dataclass(frozen=True)
class InflictHeavyPoison(Effect):
    """通常のseverity倍(既定2倍=20ダメージ)のどく。severityを上げれば「毎回のチェックアップで
    ダメカンN個」のような強化どくも表現できる(メガドラミドロex「Pernicious Poison」実カード
    テキスト: "During Pokémon Checkup, place 16 damage counters on that Pokémon instead of 1"は
    severity=16で表現)。"""

    severity: int = 2

    def execute(self, ctx: EffectContext) -> None:
        _, defender = _defender(ctx)
        if (
            defender is None
            or _defender_blocks_non_damage_effects(ctx, defender)
            or _defender_status_immune_via_festival_grounds(ctx, defender)
        ):
            return
        defender.status.poisoned = True
        defender.status.poison_severity = self.severity
        ctx.log("相手の場のポケモンが(強い)どくになった")


@dataclass(frozen=True)
class LockOwnAttackNextTurn(Effect):
    """次の自分の番、このポケモンはワザが使えなくなる。lock_all_attacks=False(既定)なら
    attack_nameで指定したワザだけがロックされる(「○○は次の自分の番、使えない」等、
    他のワザは使用可能なまま)。lock_all_attacks=Trueなら「次の自分の番、このポケモンは
    ワザが使えない」(全ワザロック)を表す。locked_attack_name=Noneをall-attacksの目印として使う
    (engine.legal_actions._attack_actionsのゲート判定側もこれを前提にしている)。"""

    attack_name: str
    lock_all_attacks: bool = False

    def execute(self, ctx: EffectContext) -> None:
        if ctx.source_pokemon is None:
            return
        player = _attacker_player(ctx)
        ctx.source_pokemon.locked_attack_name = None if self.lock_all_attacks else self.attack_name
        ctx.source_pokemon.locked_attack_until_turn = player.turns_taken + 1


@dataclass(frozen=True)
class HealAllOwnSPPokemon(Effect):
    def execute(self, ctx: EffectContext) -> None:
        player = _attacker_player(ctx)
        for mon in player.all_pokemon_in_play():
            card = ctx.card_db.get(mon.card_id)
            if card is not None and card.is_sp_pokemon:
                mon.damage = 0


@dataclass(frozen=True)
class ForceOpponentSwitchChosenBench(Effect):
    """相手のバトルポケモンを、プレイヤーが選んだ相手のベンチポケモンと入れ替える。"""

    def execute(self, ctx: EffectContext) -> None:
        opponent = ctx.state.player(ctx.opponent)
        if ctx.target_bench_index is None or not (0 <= ctx.target_bench_index < len(opponent.bench)):
            return
        new_active = opponent.bench.pop(ctx.target_bench_index)
        if opponent.active is not None:
            opponent.active.status.clear_all()
            opponent.bench.append(opponent.active)
        new_active.status.clear_all()
        opponent.active = new_active
        ctx.log("相手のバトルポケモンを強制的に入れ替えた")


def _opponent_pokemon_slots(opponent: PlayerState) -> list[tuple[int, PokemonInPlay]]:
    """相手の場のポケモンを(スロット番号, ポケモン)で返す。スロット0=バトル場、i+1=ベンチi
    (zone="opponent_pokemon_target"の選択でsource_indicesとして使う番号と同じ)。"""
    slots: list[tuple[int, PokemonInPlay]] = []
    if opponent.active is not None:
        slots.append((0, opponent.active))
    slots.extend((i + 1, mon) for i, mon in enumerate(opponent.bench))
    return slots


@dataclass(frozen=True)
class DiscardOwnSpecificEnergyThenDealDamage(Effect):
    """このポケモンについている特定の特殊エネルギー(energy_idのカード)を1枚トラッシュしてから、amountダメージを
    与える。ついていなければこのワザは何も起こらない(ルギアEX(bw11-102)の「Plasma Gale」実カードテキスト:
    "Discard a Plasma Energy attached to this Pokémon. If you can't discard a Plasma Energy, this attack does
    nothing.")。"""

    amount: int
    energy_id: str

    def execute(self, ctx: EffectContext) -> None:
        if ctx.source_pokemon is None or self.energy_id not in ctx.source_pokemon.attached_energy:
            ctx.log("トラッシュできるエネルギーがないため、このワザは何も起こらなかった")
            return
        ctx.source_pokemon.attached_energy.remove(self.energy_id)
        _attacker_player(ctx).discard.append(self.energy_id)
        DealDamage(self.amount).execute(ctx)


@dataclass(frozen=True)
class MoveDamageCountersBetweenOpponentPokemon(Effect):
    """相手のポケモン1匹からダメカンをcount個、別の相手のポケモンに移す(アブソル(xy6-40)の特性
    「Cursed Eyes」実カードテキスト: "you may move 3 damage counters from 1 of your opponent's Pokémon to
    another of his or her Pokémon.")。移動元(ダメカンがのっているポケモン)→移動先(別のポケモン)の
    順に2回選ぶ。移動元のダメカンがcount個に満たなければ、あるぶんだけ移す。ミネズミの「かんしのめ」で
    封じられる。移動先にダメカンをのせられない場合(バトルコロシアム等)は、移動元からの除去だけが起きる。"""

    count: int

    def execute(self, ctx: EffectContext) -> None:
        if _damage_counter_relocation_blocked(ctx):
            return
        opponent = ctx.state.player(ctx.opponent)
        slots = _opponent_pokemon_slots(opponent)
        sources = [(slot, mon) for slot, mon in slots if mon.damage > 0]
        if len(slots) < 2 or not sources:
            return
        ctx.state.pending_search_choice = PendingSearchChoice(
            player_index=ctx.acting_player,
            zone="opponent_pokemon_target",
            source_indices=[slot for slot, _ in sources],
            card_ids=[mon.card_id for _, mon in sources],
            min_count=1,
            max_count=1,
            prompt="ダメカンを取り除く相手のポケモンを選ぶ",
            shuffle_after=False,
            all_card_ids=[mon.card_id for _, mon in sources],
            cont_source_pokemon=ctx.source_pokemon,
            cont_source_card_id=ctx.source_card_id,
            effect_source=ctx.effect_source,
            custom_data={"mode": "move_counters_pick_source", "count": self.count},
        )


@dataclass(frozen=True)
class LookTopNReorderOnTop(Effect):
    """自分の山札の上からN枚を見て、好きな順番で山札の上に戻す(エルレイド(xy8-84)の特性「Premonition」
    実カードテキスト: "you may look at the top 5 cards of your deck and put them back on top of your deck in any
    order.")。選んだ順(1枚目が一番上)に戻す。山札がN枚に満たなければあるぶんだけ。"""

    count: int

    def execute(self, ctx: EffectContext) -> None:
        player = _attacker_player(ctx)
        n = min(self.count, len(player.deck))
        if n <= 0:
            return
        top = list(player.deck[:n])
        ctx.state.pending_search_choice = PendingSearchChoice(
            player_index=ctx.acting_player,
            zone="deck",
            source_indices=list(range(n)),
            card_ids=top,
            min_count=n,
            max_count=n,
            prompt=f"山札の上{n}枚を見て、戻す順番に選ぶ(最初に選んだカードが一番上)",
            shuffle_after=False,
            all_card_ids=list(top),
            destination="deck_top_no_shuffle",
            reveal_to_opponent=False,
            effect_source=ctx.effect_source,
            source_card_id=ctx.source_card_id,
        )


@dataclass(frozen=True)
class MoveOpponentDiscardCardToTheirPrizes(Effect):
    """相手のトラッシュから自分が選んだ1枚を、相手のサイド(裏向き)に加える(アーゴヨンGXの「Injection-GX」
    実カードテキスト: "Add a card from your opponent's discard pile to their Prize cards face down.")。
    カードを選ぶのは自分側。相手のトラッシュが空なら何も起きない。"""

    def execute(self, ctx: EffectContext) -> None:
        opponent = ctx.state.player(ctx.opponent)
        if not opponent.discard:
            return
        ctx.state.pending_search_choice = PendingSearchChoice(
            player_index=ctx.acting_player,
            zone="opponent_discard_to_their_prizes",
            source_indices=list(range(len(opponent.discard))),
            card_ids=list(opponent.discard),
            min_count=1,
            max_count=1,
            prompt="相手のトラッシュから、相手のサイドに加える1枚を選ぶ",
            shuffle_after=False,
            all_card_ids=list(opponent.discard),
        )


@dataclass(frozen=True)
class TurnPrizesFaceUp(Effect):
    """自分のサイドをすべて表向きにする(タウンマップ実カードテキスト: "Turn all of your Prize cards face up.
    (Those Prize cards remain face up for the rest of the game.)")。表向きにしたカードはゲーム中ずっと
    表向きのまま(両プレイヤーに公開)。使った後にサイドに加わるカードは裏向き。"""

    def execute(self, ctx: EffectContext) -> None:
        player = _attacker_player(ctx)
        if not player.prizes:
            return
        player.mark_all_prizes(2)
        ctx.log("自分のサイドをすべて表向きにした")


@dataclass(frozen=True)
class PeekOwnPrizes(Effect):
    """自分の裏向きのサイドを見る(ベベノムの「Eye Opener」実カードテキスト: "Look at your face-down Prize
    cards.")。見たのは本人だけ(相手には公開されない)。"""

    def execute(self, ctx: EffectContext) -> None:
        player = _attacker_player(ctx)
        if not player.prizes:
            return
        player.mark_all_prizes(1)
        ctx.log("自分のサイドを見た")


@dataclass(frozen=True)
class DamageBonusAndIgnoreEffectsIfExtraEnergy(Effect):
    """このワザ自身のコストに加えてextra_needed個以上(energy_type指定時はそのタイプ)のエネルギーがついていれば、
    ダメージがbonus増え、さらに相手のバトルポケモンにかかっている効果の影響を受けない(レシラム&リザードン
    GXの「Double Blaze-GX」実カードテキスト: "If this Pokémon has at least 3 extra Fire Energy attached to it (in
    addition to this attack's cost), this attack does 100 more damage, and this attack's damage isn't affected by any
    effects on your opponent's Active Pokémon.")。基本ダメージと追加ダメージを別々のDealDamageにすると、
    攻撃側ボーナス・防御側の軽減が2回ずつ適用されてしまうため、合計で1回の計算にする。"""

    base: int
    bonus: int
    own_cost_count: int
    extra_needed: int
    energy_type: str | None = None

    def execute(self, ctx: EffectContext) -> None:
        if ctx.source_pokemon is None:
            return
        if self.energy_type:
            count = sum(
                1 for e in ctx.source_pokemon.attached_energy
                if ctx.card_db.get(e) and ctx.card_db.get(e).basic_energy_type == self.energy_type
            )
        else:
            count = len(ctx.source_pokemon.attached_energy)
        if max(0, count - self.own_cost_count) >= self.extra_needed:
            DealDamageIgnoringDefenderShieldAndReduction(self.base + self.bonus).execute(ctx)
        else:
            DealDamage(self.base).execute(ctx)


@dataclass(frozen=True)
class HealGivenPokemonIfPicked(Effect):
    """直前の選択でちょうどrequired_picks枚が選ばれていれば、指定のポケモン(targetへの参照)のダメージをamount回復する
    (マオ&スイレンの「2枚捨てたなら、ベンチに移したポケモンの120ダメージを回復」用、remaining_scriptとして使う)。"""

    target: object
    amount: int
    required_picks: int

    def execute(self, ctx: EffectContext) -> None:
        if len(ctx.last_picked_card_ids) != self.required_picks:
            return
        player = _attacker_player(ctx)
        if self.target in player.all_pokemon_in_play():
            self.target.heal(self.amount)
            ctx.log(f"手札を{self.required_picks}枚トラッシュして、入れ替えたポケモンのダメージを{self.amount}回復した")


@dataclass(frozen=True)
class SwitchActiveWithBenchThenMayDiscardToHealOld(Effect):
    """自分のバトルポケモンを選んだベンチポケモンと入れ替える。そのとき、手札を他にdiscard_count枚トラッシュしてもよく、
    そうしたら、ベンチに移したポケモン(元のバトルポケモン)のダメージをheal_amount回復する(マオ&スイレン(sm12-198)
    実カードテキスト: "Switch your Active Pokémon with 1 of your Benched Pokémon. When you play this card, you may
    discard 2 other cards from your hand. If you do, heal 120 damage from the Pokémon you moved to your Bench.")。
    トラッシュは0枚かdiscard_count枚のどちらかだけが選べる。"""

    discard_count: int
    heal_amount: int

    def execute(self, ctx: EffectContext) -> None:
        player = _attacker_player(ctx)
        old_active = player.active
        if ctx.target_bench_index is None or ctx.target_bench_index >= len(player.bench) or old_active is None:
            return
        SwitchActiveWithBench().execute(ctx)
        if len(player.hand) < self.discard_count:
            return
        _trigger_search_choice(
            ctx, player, "hand", lambda card: True, self.discard_count,
            f"手札を{self.discard_count}枚トラッシュしてベンチに移したポケモンを回復する(トラッシュしない場合は何も選ばない)",
            shuffle_after=False, destination="discard", min_count=0,
        )
        pending = ctx.state.pending_search_choice
        if pending is not None:
            pending.allowed_counts = (0, self.discard_count)
            pending.remaining_script = (HealGivenPokemonIfPicked(old_active, self.heal_amount, self.discard_count),)
            pending.cont_source_pokemon = ctx.source_pokemon
            pending.cont_source_card_id = ctx.source_card_id


@dataclass(frozen=True)
class DiscardHandEnergyThenSwitchOpponentBench(Effect):
    """手札から指定タイプの基本エネルギーをcount枚トラッシュする。そうしたら、相手のバトルポケモンを
    プレイヤーが選んだ相手のベンチポケモンと入れ替える(キュウコン(sm9-16)の特性「Nine Temptations」実カード
    テキスト: "you may discard 2 Fire Energy cards from your hand. If you do, switch 1 of your opponent's
    Benched Pokémon with their Active Pokémon.")。手札に足りない/対象が選べない場合は何も起きない。"""

    count: int
    energy_type: str

    def execute(self, ctx: EffectContext) -> None:
        player = _attacker_player(ctx)
        opponent = ctx.state.player(ctx.opponent)
        if ctx.target_bench_index is None or not (0 <= ctx.target_bench_index < len(opponent.bench)):
            return
        matches = [
            i for i, cid in enumerate(player.hand)
            if (c := ctx.card_db.get(cid)) is not None and c.is_energy and c.basic_energy_type == self.energy_type
            and not c.is_special_energy
        ]
        if len(matches) < self.count:
            return
        for i in sorted(matches[: self.count], reverse=True):
            player.discard.append(player.hand.pop(i))
        ctx.log(f"手札の{self.energy_type}エネルギーを{self.count}枚トラッシュした")
        ForceOpponentSwitchChosenBench().execute(ctx)


@dataclass(frozen=True)
class BothPlayersSwitchActiveEachChoosesOwn(Effect):
    """おたがいのバトルポケモンを、それぞれ自分のベンチポケモン1匹(それぞれ自分で選ぶ)と入れ替える。
    相手が先に入れ替え、その後に自分が入れ替える(エスケープロープ実カードテキスト: "Each player switches
    his or her Active Pokémon with 1 of his or her Benched Pokémon. (Your opponent switches first. If a
    player does not have a Benched Pokémon, he or she doesn't switch Pokémon.)")。以前は相手の入れ替え先も
    自分が選ぶ(ポケモンキャッチャー型)実装になっていた誤りを訂正(2026-10-06)。"""

    def execute(self, ctx: EffectContext) -> None:
        opponent = ctx.state.player(ctx.opponent)
        if opponent.bench:
            ctx.state.pending_search_choice = PendingSearchChoice(
                player_index=ctx.opponent,
                zone="own_pokemon_target",
                source_indices=[i + 1 for i in range(len(opponent.bench))],
                card_ids=[mon.card_id for mon in opponent.bench],
                min_count=1,
                max_count=1,
                prompt="バトル場に出す自分のポケモンを選ぶ(エスケープロープ)",
                shuffle_after=False,
                all_card_ids=[mon.card_id for mon in opponent.bench],
                custom_data={"mode": "escape_rope_opponent_first", "acting_player": ctx.acting_player},
            )
            return
        _start_own_switch_choice(ctx)


def _start_own_switch_choice(ctx: EffectContext) -> None:
    """自分のバトルポケモンを入れ替える先を、自分のベンチから選ぶ保留を立てる(ベンチが無ければ何もしない)。"""
    player = _attacker_player(ctx)
    if not player.bench:
        return
    ctx.state.pending_search_choice = PendingSearchChoice(
        player_index=ctx.acting_player,
        zone="own_pokemon_target",
        source_indices=[i + 1 for i in range(len(player.bench))],
        card_ids=[mon.card_id for mon in player.bench],
        min_count=1,
        max_count=1,
        prompt="入れ替える自分のベンチポケモンを選ぶ",
        shuffle_after=False,
        all_card_ids=[mon.card_id for mon in player.bench],
        custom_data={"mode": "prime_catcher_own_switch"},
    )


@dataclass(frozen=True)
class RevealUntilSupporterToHand(Effect):
    """山札の上から、サポートが出るまで1枚ずつ公開する。見つけたサポート1枚を手札に加え、残りの公開したカードは
    山札に戻してシャッフルする(ランダムレシーバー実カードテキスト: "Reveal cards from the top of your deck
    until you reveal a Supporter card. Put it into your hand. Shuffle the other cards back into your deck.")。
    自分で選べる検索ではなく、山札の上から最初に出たサポートになる(以前は好きなサポートを選べる検索になっており
    実際より強かった、2026-10-06訂正)。山札にサポートが無ければ山札をシャッフルするだけ。"""

    def execute(self, ctx: EffectContext) -> None:
        player = _attacker_player(ctx)
        revealed: list[str] = []
        found: str | None = None
        while player.deck:
            card_id = player.deck.pop(0)
            revealed.append(card_id)
            card = ctx.card_db.get(card_id)
            if card is not None and card.is_supporter:
                found = card_id
                break
        if found is not None:
            player.hand.append(found)
            revealed.remove(found)
            ctx.log("山札の上から公開してサポートを見つけ、手札に加えた")
            ctx.state.player(ctx.opponent).known_opponent_hand.append(found)
        else:
            ctx.log("山札にサポートが無かった")
        player.deck.extend(revealed)
        ctx.rng.shuffle(player.deck)
        if revealed or found:
            ctx.reveal("山札の上から公開したカード", ([found] if found else []) + revealed)


@dataclass(frozen=True)
class ForceOpponentSwitchOpponentChooses(Effect):
    """相手のバトルポケモンをベンチポケモンと入れ替える。バトル場に出すポケモンは相手が選ぶ
    (ベイリーフの「つきとばす」等、attacker側ではなくdefender側が選択する強制入れ替え)。"""

    def execute(self, ctx: EffectContext) -> None:
        opponent = ctx.state.player(ctx.opponent)
        if not opponent.bench:
            return
        ctx.state.pending_search_choice = PendingSearchChoice(
            player_index=ctx.opponent,
            zone="own_pokemon_target",
            source_indices=[i + 1 for i in range(len(opponent.bench))],
            card_ids=[mon.card_id for mon in opponent.bench],
            min_count=1,
            max_count=1,
            prompt="バトル場に出すポケモンを選ぶ",
            shuffle_after=False,
            all_card_ids=[mon.card_id for mon in opponent.bench],
            custom_data={"mode": "prime_catcher_own_switch"},
        )


@dataclass(frozen=True)
class ForceOpponentSwitchChosenBenchThenSwitchOwnActive(Effect):
    """相手のバトルポケモンを、プレイヤーが選んだ相手のベンチポケモンと入れ替える。それができたら、
    続けて自分のバトルポケモンも自分のベンチポケモン1体と入れ替える(プライムキャッチャー)。"""

    def execute(self, ctx: EffectContext) -> None:
        opponent = ctx.state.player(ctx.opponent)
        if ctx.target_bench_index is None or not (0 <= ctx.target_bench_index < len(opponent.bench)):
            return
        new_active = opponent.bench.pop(ctx.target_bench_index)
        if opponent.active is not None:
            opponent.active.status.clear_all()
            opponent.bench.append(opponent.active)
        new_active.status.clear_all()
        opponent.active = new_active
        ctx.log("相手のバトルポケモンを強制的に入れ替えた")

        player = _attacker_player(ctx)
        if not player.bench:
            return
        ctx.state.pending_search_choice = PendingSearchChoice(
            player_index=ctx.acting_player,
            zone="own_pokemon_target",
            source_indices=[i + 1 for i in range(len(player.bench))],
            card_ids=[mon.card_id for mon in player.bench],
            min_count=1,
            max_count=1,
            prompt="入れ替える自分のベンチポケモンを選ぶ",
            shuffle_after=False,
            all_card_ids=[mon.card_id for mon in player.bench],
            custom_data={"mode": "prime_catcher_own_switch"},
        )


@dataclass(frozen=True)
class ExDamageBonus40ThisTurn(Effect):
    """この番の間、自分のワザは相手のバトル場のexポケモンに+40ダメージ(からておうの稽古実カード
    テキスト: "During this turn, attacks used by your Pokémon do 40 more damage to your opponent's
    Active Pokémon ex (before applying Weakness and Resistance)."。適用はengine.continuous.
    black_belt_training_bonus_damage経由)。"""

    def execute(self, ctx: EffectContext) -> None:
        player = _attacker_player(ctx)
        player.ex_bonus_damage_40_until_turn = player.turns_taken


@dataclass(frozen=True)
class SwitchActiveWithBenchOrExVDamageBonusThisTurn(Effect):
    """次の2つから1つを選ぶ: (1)自分のバトルポケモンを選んだベンチポケモンと入れ替える、
    (2)この番の間、自分のワザは相手のバトル場のex/Vポケモンに+30ダメージ(スグリ(Kieran))。
    target_bench_indexが指定されていれば(1)、Noneなら(2)を実行する。"""

    def execute(self, ctx: EffectContext) -> None:
        if ctx.target_bench_index is not None:
            SwitchActiveWithBench().execute(ctx)
        else:
            player = _attacker_player(ctx)
            player.ex_v_bonus_damage_until_turn = player.turns_taken


@dataclass(frozen=True)
class SwitchOwnActiveWithBenchThenForceOpponentSwitch(Effect):
    """自分のバトルポケモンを選んだベンチポケモンと入れ替え、そうしたら相手のバトルポケモンも
    選んだ相手のベンチポケモンと強制的に入れ替える(ロケット団のサカキ(Team Rocket's Giovanni))。"""

    def execute(self, ctx: EffectContext) -> None:
        player = _attacker_player(ctx)
        if ctx.target_bench_index is None or not (0 <= ctx.target_bench_index < len(player.bench)):
            return
        new_active = player.bench.pop(ctx.target_bench_index)
        if player.active is not None:
            player.active.status.clear_all()
            player.bench.append(player.active)
        new_active.status.clear_all()
        new_active.became_active_turn = player.turns_taken
        player.active = new_active

        opponent = ctx.state.player(ctx.opponent)
        if not opponent.bench:
            return
        ctx.state.pending_search_choice = PendingSearchChoice(
            player_index=ctx.acting_player,
            zone="own_pokemon_target",
            source_indices=[i + 1 for i in range(len(opponent.bench))],
            card_ids=[mon.card_id for mon in opponent.bench],
            min_count=1,
            max_count=1,
            prompt="バトル場に呼び出す相手のベンチポケモンを選ぶ",
            shuffle_after=False,
            all_card_ids=[mon.card_id for mon in opponent.bench],
            custom_data={"mode": "giovanni_opponent_switch"},
        )


@dataclass(frozen=True)
class DrawUpTo(Effect):
    """手札がN枚になるまで引く。bonus_count_if_own_first_turn指定時、自分の最初の番なら
    その枚数を使う(リーリエの「自分の最初の番なら8枚まで」等)。"""

    count: int
    bonus_count_if_own_first_turn: int | None = None

    def execute(self, ctx: EffectContext) -> None:
        player = _attacker_player(ctx)
        count = self.count
        if self.bonus_count_if_own_first_turn is not None and _is_acting_players_first_turn(ctx):
            count = self.bonus_count_if_own_first_turn
        while len(player.hand) < count and player.deck:
            player.hand.append(player.deck.pop(0))


@dataclass(frozen=True)
class DiscardOwnHandBasicEnergyThenDraw(Effect):
    """手札から指定タイプの基本エネルギーを1枚トラッシュし、そうしたらN枚引く
    (ルナトーンの「Lunar Cycle」等)。手札に対象エネルギーが無ければ何もしない。"""

    energy_type: str
    draw_count: int

    def execute(self, ctx: EffectContext) -> None:
        player = _attacker_player(ctx)
        for i, cid in enumerate(player.hand):
            card = ctx.card_db.get(cid)
            if card is not None and card.basic_energy_type == self.energy_type:
                player.discard.append(player.hand.pop(i))
                Draw(self.draw_count).execute(ctx)
                return


@dataclass(frozen=True)
class DrawUpToBonusIfAllOwnPokemonNamePrefix(Effect):
    """手札がbase枚になるまで引く。自分の場の全ポケモンがカード名の接頭辞条件を満たす場合、
    代わりにbonus枚になるまで引く(ロケット団のアテナ実カードテキスト:
    "If all of your Pokémon in play are Team Rocket's Pokémon, draw until you have 8 instead"等)。"""

    base: int
    bonus: int
    name_prefix: str

    def execute(self, ctx: EffectContext) -> None:
        player = _attacker_player(ctx)
        mons = player.all_pokemon_in_play()
        if self.name_prefix == TEAM_ROCKETS_NAME_PREFIX:
            # ロケット団のワナイダー(sv10a-9、card.nameが日本語未翻訳)を漏れなく「ロケット団の
            # ポケモン」として数えるため、共通ヘルパーを使う(2026-08-22発覚)。
            all_match = bool(mons) and all(is_team_rockets_pokemon(ctx.card_db.get(mon.card_id)) for mon in mons)
        else:
            all_match = bool(mons) and all(
                (card := ctx.card_db.get(mon.card_id)) is not None and card.name.startswith(self.name_prefix)
                for mon in mons
            )
        count = self.bonus if all_match else self.base
        while len(player.hand) < count and player.deck:
            player.hand.append(player.deck.pop(0))


@dataclass(frozen=True)
class RevealTopNChooseOneToHandOtherToBottom(Effect):
    """山札の上からN枚を見て1枚をプレイヤーが選んで手札に加え、残りは山札の一番下に戻す(トレードオフ等)。
    reveal: 実カードのテキストに"reveal"の指定が無ければFalse(既定)。この場合、共有ログには
    具体的なカード名を出さない(トレードオフ/エアメール/ていさつしれいは全て実テキストに
    revealの指定が無い私的な閲覧効果)。"""

    n: int
    reveal: bool = False

    def execute(self, ctx: EffectContext) -> None:
        player = _attacker_player(ctx)
        seen = player.deck[: self.n]
        if not seen:
            return
        ctx.state.pending_search_choice = PendingSearchChoice(
            player_index=ctx.acting_player,
            zone="deck",
            source_indices=list(range(len(seen))),
            card_ids=list(seen),
            min_count=1,
            max_count=1,
            prompt="山札の上から見たカードの中から1枚を選ぶ",
            shuffle_after=False,
            all_card_ids=list(seen),
            remaining_to_bottom=True,
            reveal_to_opponent=self.reveal,
        )


@dataclass(frozen=True)
class MoveEnergyOnOpponentSide(Effect):
    """相手のバトルポケモンについているエネルギーを、相手の別のポケモンに移す。"""

    def execute(self, ctx: EffectContext) -> None:
        opponent = ctx.state.player(ctx.opponent)
        source = opponent.active
        if source is None or not source.attached_energy:
            return
        others = [m for m in opponent.bench if m is not source]
        if not others:
            return
        energy_id = source.attached_energy.pop(0)
        others[0].attached_energy.append(energy_id)
        ctx.log("相手の場でエネルギーを移動させた")


@dataclass(frozen=True)
class SearchDeckMultiCriteria(Effect):
    """条件ごとに山札から1枚、プレイヤーに選ばせて手札に加える(全条件を満たす分だけ)。
    複数条件のときは1条件ずつ順番に選択させる(1回の選択が終わるとremaining_script経由で
    次の条件の選択に続く)。"""

    criteria: tuple[str, ...]  # "supporter" | "basic_energy" | "team_galactic_item"

    def execute(self, ctx: EffectContext) -> None:
        if not self.criteria:
            return
        player = _attacker_player(ctx)
        criterion = self.criteria[0]
        rest = self.criteria[1:]

        def matches(card):
            return card is not None and self._matches(card, criterion)

        _trigger_search_choice(ctx, player, "deck", matches, 1, f"山札から{criterion}を探す")
        if not rest:
            return
        if ctx.state.pending_search_choice is not None:
            # この選択が終わったら続けて残りの条件も選ばせる(interpreter.run_scriptが
            # このあとに外側スクリプトの残りを追加で連結する)。
            ctx.state.pending_search_choice.remaining_script = (SearchDeckMultiCriteria(rest),)
        else:
            # 今回の条件に該当するカードが山札に1枚も無かった(選択UIが出なかった)場合でも、
            # 残りの条件はそこで打ち切らず続けて探す(シークレットボックス: どうぐが山札に
            # 無いだけでサポート/スタジアムまで探せなくなっていたバグ)。
            SearchDeckMultiCriteria(rest).execute(ctx)

    @staticmethod
    def _matches(card, criterion: str) -> bool:
        if criterion == "supporter":
            return card.is_supporter
        if criterion == "pokemon":
            return card.is_pokemon
        if criterion == "basic_energy":
            return card.is_energy and not card.is_special_energy
        if criterion == "team_galactic_item":
            return "Team Galactic's Invention" in card.name
        if criterion == "item":
            return card.is_item
        if criterion == "pokemon_tool":
            return card.is_pokemon_tool
        if criterion == "stadium":
            return card.is_stadium
        if criterion == "evolution_pokemon":
            return card.is_pokemon and not card.is_basic
        if criterion == "metal_evolution_pokemon":
            return card.is_pokemon and not card.is_basic and "Metal" in card.types
        if criterion == "any_energy":
            return card.is_energy
        if criterion == "special_energy":
            return card.is_special_energy
        if criterion == "future_pokemon":
            return card.is_pokemon and "Future" in card.subtypes
        if criterion == "pokemon_v":
            return card.is_pokemon and "V" in card.subtypes
        if criterion == "water_pokemon":
            return card.is_pokemon and "Water" in card.types
        if criterion == "fighting_pokemon":
            return card.is_pokemon and "Fighting" in card.types
        if criterion == "trainer":
            return card.is_item or card.is_supporter or card.is_stadium
        if criterion == "tag_team":
            return "TAG TEAM" in card.subtypes
        if criterion == "ultra_beast":
            return card.is_pokemon and "Ultra Beast" in card.subtypes
        if criterion == "psychic_energy_or_basic_psychic_pokemon":
            if card.is_energy and not card.is_special_energy:
                return card.basic_energy_type == "Psychic"
            return card.is_pokemon and card.is_basic and "Psychic" in card.types
        if criterion == "grass_pokemon_or_basic_grass_energy":
            if card.is_energy and not card.is_special_energy:
                return card.basic_energy_type == "Grass"
            return card.is_pokemon and "Grass" in card.types
        if criterion == "grass_pokemon_or_stadium":
            if card.is_stadium:
                return True
            return card.is_pokemon and "Grass" in card.types
        if criterion == "team_rocket_supporter":
            return card.is_supporter and card.name.startswith("Team Rocket's")
        if criterion == "fighting_pokemon_or_basic_fighting_energy":
            # 実カードテキスト(ファイトゴング/Fighting Gong): "Search your deck for a Basic
            # Fighting Energy card or a Basic Fighting Pokémon" ―― ポケモン側もたね(Basic)限定
            # (2026-09-01修正: 以前はis_basicを見ておらず進化済みの闘ポケモンまで探せてしまっていた)。
            if card.is_energy and not card.is_special_energy:
                return card.basic_energy_type == "Fighting"
            return card.is_pokemon and card.is_basic and "Fighting" in card.types
        if criterion == "any":
            return True
        if criterion == "any_pokemon":
            return card.is_pokemon
        if criterion == "team_rocket_basic_pokemon":
            return card.is_pokemon and card.is_basic and is_team_rockets_pokemon(card)
        if criterion == "basic_pokemon":
            return card.is_basic
        if criterion == "stage_1_pokemon":
            return card.is_pokemon and "Stage 1" in card.subtypes
        if criterion == "stage_2_pokemon":
            return card.is_pokemon and "Stage 2" in card.subtypes
        if criterion == "basic_pokemon":
            return card.is_pokemon and card.is_basic
        if criterion == "stage1_pokemon":
            return card.is_pokemon and "Stage 1" in card.subtypes
        if criterion == "stage2_pokemon":
            return card.is_pokemon and "Stage 2" in card.subtypes
        if criterion == "basic_lightning_energy":
            return card.is_energy and not card.is_special_energy and card.basic_energy_type == "Lightning"
        if criterion == "marnies_pokemon":
            return card.is_pokemon and card.name.startswith("Marnie's")
        if criterion == "ethans_adventure":
            return card.is_supporter and card.name == "Ethan's Adventure"
        if ":" in criterion:
            # 「種類:引数」形式の汎用条件(2026-10-07)
            kind, arg = criterion.split(":", 1)
            if kind == "type_pokemon":
                return card.is_pokemon and arg in card.types
            if kind == "basic_subtype_pokemon":
                return card.is_pokemon and card.is_basic and card_has_subtype(card, arg)
            if kind == "energy_type":
                return card.is_energy and not card.is_special_energy and card.basic_energy_type == arg
            if kind == "cardspec":
                from effects.era_attacks_i import card_matches

                return card.is_pokemon and card_matches(card, arg)  # 「Evolution Pokémon that don't have a Rule Box」等のポケモンの絞り込み
            if kind == "name_part":
                return arg in card.name
            if kind == "and":
                return all(SearchDeckMultiCriteria._matches(card, c) for c in arg.split("&&"))  # 全ての条件に合う
            if kind == "trainer_not_named":
                return (card.is_item or card.is_supporter or card.is_stadium) and card.name != arg
            if kind == "named":
                return card.name == arg
            if kind == "resists":
                return card.is_pokemon and any(r.type == arg for r in card.resistances)
            if kind == "name_prefix_pokemon":
                return card.is_pokemon and card.name.startswith(arg)
            if kind == "or":
                return any(SearchDeckMultiCriteria._matches(card, c) for c in arg.split("|"))  # いずれかの条件に合う(Ethan's Adventure)
            if kind == "basic_type_pokemon":
                return card.is_pokemon and card.is_basic and arg in card.types
            if kind == "subtype_card":
                return any(card_has_subtype(card, sub) for sub in arg.split("|"))  # 「TAG TEAMのカード」等(サブタイプのいずれか)
            if kind == "basic_type_subtype_pokemon":  # 「TYPEのたねのポケモンGXかポケモンEX」: "Fire:GX|EX"
                type_name, subtypes = arg.split(":", 1)
                return (
                    card.is_pokemon and card.is_basic and type_name in card.types
                    and any(card_has_subtype(card, sub) for sub in subtypes.split("|"))
                )
            if kind == "pokemon_retreat_exactly":
                return card.is_pokemon and card.retreat_cost_count == int(arg)
            if kind == "item_name_contains":
                return card.is_item and arg in card.name
            if kind == "pokemon_name_contains":
                return card.is_pokemon and arg in card.name
            if kind == "pokemon_not_subtype":  # 「ポケモンGX・ポケモンEXではないポケモン」: "GX|EX"
                return card.is_pokemon and not any(card_has_subtype(card, sub) for sub in arg.split("|"))
            if kind == "supporter_named_prefix":
                return card.is_supporter and card.name.startswith(arg)
            if kind == "energy_name_contains":
                return card.is_energy and arg in card.name
        return False


@dataclass(frozen=True)
class LookTopNChooseByCriteriaToHand(Effect):
    """山札の上からN枚を見て、条件に合うカードを最大M枚まで選んで手札に加える(マサキの解析、ポケギア3.0、
    ジラーチの「スターウィッシュ」、テクノレーダー等)。残りは山札に戻ってシャッフルされる。"""

    n: int
    m: int
    criteria: str

    def execute(self, ctx: EffectContext) -> None:
        player = _attacker_player(ctx)
        seen = player.deck[: self.n]
        if not seen:
            return
        eligible_positions = [
            i
            for i, cid in enumerate(seen)
            if (c := ctx.card_db.get(cid)) is not None and SearchDeckMultiCriteria._matches(c, self.criteria)
        ]
        if not eligible_positions:
            ctx.log("山札の上から見たカードの中から探す: (該当なし)")
            # 実カードテキスト通り、見つからなくても見た分は必ずシャッフルして山札に戻す
            # (何も取らなかったからといって山札の並びをそのまま維持してよいわけではない。
            # 何も取っていないのでseenの中身自体はまだ山札の先頭に残っている)。
            ctx.rng.shuffle(player.deck)
            return
        max_count = min(self.m, len(eligible_positions))
        ctx.state.pending_search_choice = PendingSearchChoice(
            player_index=ctx.acting_player,
            zone="deck",
            source_indices=eligible_positions,
            card_ids=[seen[i] for i in eligible_positions],
            min_count=0,
            max_count=max_count,
            prompt="山札の上から見たカードの中から探す",
            shuffle_after=True,
            all_card_ids=seen,
            remaining_to_bottom=True,
        )


@dataclass(frozen=True)
class ShuffleHandIntoDeckThenDraw(Effect):
    count: int

    def execute(self, ctx: EffectContext) -> None:
        player = _attacker_player(ctx)
        player.deck.extend(player.hand)
        player.hand = []
        ctx.rng.shuffle(player.deck)
        Draw(self.count).execute(ctx)


@dataclass(frozen=True)
class SearchDeckBasicPokemonAndEnergy(Effect):
    """たねポケモンと基本エネルギーを合わせてN枚まで(組み合わせ自由)探して手札に加える。"""

    count: int

    def execute(self, ctx: EffectContext) -> None:
        player = _attacker_player(ctx)

        def matches(card):
            return card is not None and (card.is_basic or (card.is_energy and not card.is_special_energy))

        _trigger_search_choice(ctx, player, "deck", matches, self.count, "山札からたねポケモン/基本エネルギーを探す")


@dataclass(frozen=True)
class TopDeckThenSearchPokemon(Effect):
    """手札のカードを1枚山札の上に戻し(コスト)、その後山札からポケモンを1枚探して手札に加える。"""

    only_sp: bool = False

    def execute(self, ctx: EffectContext) -> None:
        player = _attacker_player(ctx)
        if player.hand:
            player.deck.insert(0, player.hand.pop(0))
        SearchDeckForPokemonToHand(1, only_sp=self.only_sp).execute(ctx)


@dataclass(frozen=True)
class SwapHandPokemonForDeckSearch(Effect):
    """手札のポケモンを1枚選んで山札の上に戻し、山札からポケモンを1枚探して手札に加える。"""

    def execute(self, ctx: EffectContext) -> None:
        player = _attacker_player(ctx)
        for i, card_id in enumerate(player.hand):
            card = ctx.card_db.get(card_id)
            if card is not None and card.is_pokemon:
                player.deck.insert(0, player.hand.pop(i))
                break
        SearchDeckForPokemonToHand(1).execute(ctx)


@dataclass(frozen=True)
class ReturnOwnBenchedPokemonToHand(Effect):
    """自分の場のポケモン(SP限定可)1匹を、ついているカードごと手札に戻す(ポケターン: "Return 1 of your
    Pokémon SP and all cards attached to it to your hand.")。ctx.target_bench_indexがNoneならバトルポケモン、
    指定があればそのベンチポケモン。バトルポケモンを戻してバトル場が空になった場合の新アクティブ選択は、
    呼び出し元(rules_engine._handle_play_item)が行う。以前はバトルポケモンを対象にしないv1簡略化だった
    (2026-10-06訂正)。"""

    only_sp: bool = False

    def execute(self, ctx: EffectContext) -> None:
        player = _attacker_player(ctx)
        if ctx.target_bench_index is None:
            target = player.active
        elif 0 <= ctx.target_bench_index < len(player.bench):
            target = player.bench[ctx.target_bench_index]
        else:
            return
        if target is None:
            return
        if self.only_sp:
            card = ctx.card_db.get(target.card_id)
            if card is None or not card.is_sp_pokemon:
                return
        if target is player.active:
            player.active = None
        else:
            player.bench.remove(target)
        player.hand.extend(target.evolution_history)
        player.hand.append(target.card_id)
        player.hand.extend(target.attached_energy)
        if target.attached_tool:
            player.hand.append(target.attached_tool)


@dataclass(frozen=True)
class SearchDiscardForSPAndEnergy(Effect):
    """トラッシュからSPポケモンと基本エネルギーを合計N枚まで(組み合わせ自由)回収する。"""

    count: int

    def execute(self, ctx: EffectContext) -> None:
        player = _attacker_player(ctx)

        def matches(card):
            return card is not None and (card.is_sp_pokemon or (card.is_energy and not card.is_special_energy))

        _trigger_search_choice(
            ctx, player, "discard", matches, self.count, "トラッシュからSPポケモン/基本エネルギーを探す", shuffle_after=False
        )


@dataclass(frozen=True)
class SearchDiscardForPokemonOrEnergy(Effect):
    """トラッシュからポケモンか基本エネルギーを選んで手札に戻す(ナイトストレッチャー、
    スイレンのお世話、タラゴン等で共有)。

    optional: 実カードテキストに"up to"/"まで"の指定があるカード(スイレンのお世話「Put up to 3
    in any combination...」、タラゴン「合計4枚まで選び」)はTrue(既定、0枚選んでもよい)。
    ナイトストレッチャー(実カードテキスト: "Put a Pokémon or a Basic Energy card from your
    discard pile into your hand."、"may"も"up to"も無い)はFalseにする ―― 英語ルールテキストの
    慣例上、"Search"を伴わない直接の"Put"指定は("may"が無ければ)候補が存在する限り必須
    (2026-09-16ユーザー指摘)。"""

    count: int = 1
    optional: bool = True
    no_rule_box: bool = False  # True: ルールを持つポケモン(ex/V等)は対象外(スイレンのお世話: "Pokémon that don't have a Rule Box")
    card_type: str | None = None  # 指定時は、そのタイプのポケモンと、そのタイプの基本エネルギーに限定する(タラゴン(m3-73)は
    # 公式サイトの生HTMLで「{闘}ポケモンと「基本{闘}エネルギー」」と判明: 属性がicon-fightingのspanで、テキスト抽出では
    # 「ポケモンと『基本エネルギー』」と見えて、闘タイプ限定が抜け落ちていた、2026-10-06訂正)

    def execute(self, ctx: EffectContext) -> None:
        player = _attacker_player(ctx)

        def matches(card):
            if card is None:
                return False
            if card.is_pokemon:
                if self.no_rule_box and (_RULE_BOX_SUBTYPES & set(card.subtypes)):
                    return False
                return self.card_type is None or self.card_type in card.types
            if card.is_energy and not card.is_special_energy:
                return self.card_type is None or card.basic_energy_type == self.card_type
            return False

        _trigger_search_choice(
            ctx, player, "discard", matches, self.count, "トラッシュからポケモン/基本エネルギーを探す",
            shuffle_after=False, min_count=0 if self.optional else self.count,
        )


@dataclass(frozen=True)
class SearchDiscardForPokemonToHand(Effect):
    """トラッシュからポケモンを最大count枚選んで手札に戻す(レスキュータンカ等。実カードでは
    「トラッシュのポケモン3匹を山札に戻す」という代替の選択肢もあるが、v1では手札に戻す方のみ対応)。"""

    count: int = 1

    def execute(self, ctx: EffectContext) -> None:
        player = _attacker_player(ctx)

        def matches(card):
            return card is not None and card.is_pokemon

        _trigger_search_choice(ctx, player, "discard", matches, self.count, "トラッシュからポケモンを探す", shuffle_after=False)


@dataclass(frozen=True)
class SearchDeckAnyCardToHand(Effect):
    """山札から好きなカードを最大N枚まで選んで手札に加える(ポッポサンダーexの「クイックサーチ」等)。"""

    count: int = 1

    def execute(self, ctx: EffectContext) -> None:
        player = _attacker_player(ctx)
        _trigger_search_choice(ctx, player, "deck", lambda card: card is not None, self.count, "山札から好きなカードを探す")


@dataclass(frozen=True)
class SearchDeckAnyCardToDiscard(Effect):
    """山札から好きなカードを最大N枚まで選んでトラッシュし、残りをシャッフルする
    (バトルコンプレッサー(Battle Compressor)等)。"""

    count: int = 1

    def execute(self, ctx: EffectContext) -> None:
        player = _attacker_player(ctx)
        _trigger_search_choice(
            ctx, player, "deck", lambda card: card is not None, self.count,
            "山札から好きなカードを選んでトラッシュする", destination="discard",
        )


@dataclass(frozen=True)
class SearchDeckToTopOfDeck(Effect):
    """山札から好きなカードをcount枚選び、残りをシャッフルしてから、選んだカードを一番上に
    (プレイヤーが選んだ順のまま、1つ目が一番上)戻す(暗号マニアの解読等)。

    実カードテキスト(公式サイトの英語ルール欄): "Search your deck for 2 cards, shuffle your deck,
    then put those cards on top of it in any order."。"up to"の記載が無いため、ポケモンカード
    公式ルール上「Nまで」ではなく「ちょうどN枚」を選ぶ必須の効果(山札の残り枚数がcount未満の場合のみ
    その枚数に切り下がる、_trigger_search_choice側の min(min_count, max_count) が処理する)。"""

    count: int

    def execute(self, ctx: EffectContext) -> None:
        player = _attacker_player(ctx)
        _trigger_search_choice(
            ctx, player, "deck", lambda card: card is not None, self.count,
            "山札からちょうど2枚選んで一番上に戻す", shuffle_after=False, destination="deck_top",
            min_count=self.count,
        )


@dataclass(frozen=True)
class PutHandCardOnTopOfDeck(Effect):
    """手札のカードを1枚選んで(してもよい)、山札をシャッフルせずそのまま一番上に置く
    (夜のアカデミー実カードテキスト: "that player may put a card from their hand on top of their
    deck."等)。"""

    def execute(self, ctx: EffectContext) -> None:
        player = _attacker_player(ctx)
        _trigger_search_choice(
            ctx, player, "hand", lambda card: card is not None, 1,
            "手札から山札の一番上に置くカードを選ぶ(選ばなくてもよい)", shuffle_after=False,
            destination="deck_top_no_shuffle",
        )


@dataclass(frozen=True)
class SearchDeckUpToTwoBasicOrOneEvolutionToHand(Effect):
    """山札から、たねポケモンを最大2枚、または進化ポケモンを1枚(どちらか片方)選んで公開し、手札に
    加える(タケシのスカウト実カードテキスト: "Search your deck for up to 2 Basic Pokémon or 1
    Evolution Pokémon, reveal them, and put them into your hand. Then, shuffle your deck."用)。
    まず1枚目を選ばせ(たね/進化どちらでも可、選ばなくてもよい)、たねポケモンを選んだ場合のみ
    続けて2枚目(たねポケモン限定)を選べる(engine.rules_engine側でmode="brocks_scouting_pick_first"
    を解決する)。"""

    def execute(self, ctx: EffectContext) -> None:
        player = _attacker_player(ctx)
        eligible_indices = [i for i, cid in enumerate(player.deck) if (c := ctx.card_db.get(cid)) is not None and c.is_pokemon]
        if not eligible_indices:
            return
        ctx.state.pending_search_choice = PendingSearchChoice(
            player_index=ctx.acting_player,
            zone="deck",
            source_indices=eligible_indices,
            card_ids=[player.deck[i] for i in eligible_indices],
            min_count=0,
            max_count=1,
            prompt="山札からたねポケモン(最大2枚)または進化ポケモン(1枚)を選ぶ",
            shuffle_after=False,
            all_card_ids=list(player.deck),
            destination="hand",
            custom_data={"mode": "brocks_scouting_pick_first"},
        )


@dataclass(frozen=True)
class SearchDiscardForBasicEnergyToHand(Effect):
    """トラッシュから基本エネルギーを最大N枚まで探して手札に加える(エネルギー回収等)。
    energy_type指定時はそのタイプ限定(炎の結晶等)。"""

    count: int
    energy_type: str | None = None

    def execute(self, ctx: EffectContext) -> None:
        player = _attacker_player(ctx)

        def matches(card):
            if card is None or not card.is_energy or card.is_special_energy:
                return False
            return self.energy_type is None or card.basic_energy_type == self.energy_type

        _trigger_search_choice(
            ctx, player, "discard", matches, self.count, "トラッシュから基本エネルギーを探す", shuffle_after=False
        )


@dataclass(frozen=True)
class AttachSelfAsRetreatReducingTool(Effect):
    """自分自身(ベンチのUnown Q)をどうぐとして対象ポケモンにつける。にげるコスト-1の効果はengine側で解決する。"""

    def execute(self, ctx: EffectContext) -> None:
        if ctx.source_pokemon is None:
            return
        player = _attacker_player(ctx)
        target = _resolve_own_target(ctx, player, exclude=ctx.source_pokemon)
        if target is None or target.attached_tool is not None:
            return
        if ctx.source_pokemon not in player.bench:
            return
        player.bench.remove(ctx.source_pokemon)
        player.discard.extend(ctx.source_pokemon.attached_energy)
        target.attached_tool = ctx.source_card_id
        ctx.log(f"{ctx.source_card_id} をどうぐとして{target.card_id}につけた")


# ---- 現行スタンダードデッキ向けに追加したプリミティブ ----


@dataclass(frozen=True)
class DiscardTopOfOpponentDeck(Effect):
    """相手の山札の上からN枚をトラッシュする。"""

    count: int

    def execute(self, ctx: EffectContext) -> None:
        opponent = ctx.state.player(ctx.opponent)
        discarded = opponent.deck[: self.count]
        opponent.deck = opponent.deck[self.count :]
        opponent.discard.extend(discarded)
        ctx.log(f"相手の山札の上から{len(discarded)}枚をトラッシュした")


@dataclass(frozen=True)
class DamagePerBenchedPokemonWithEnergyType(Effect):
    """自分のベンチのうち、指定タイプのエネルギーがついているポケモンの数だけダメージが上乗せされる。"""

    base: int
    per_pokemon: int
    energy_type: str

    def execute(self, ctx: EffectContext) -> None:
        player = _attacker_player(ctx)
        count = 0
        for mon in player.bench:
            if any(
                (ctx.card_db.get(e) and ctx.card_db.get(e).basic_energy_type == self.energy_type)
                for e in mon.attached_energy
            ):
                count += 1
        DealDamage(self.base + self.per_pokemon * count).execute(ctx)


# ---- WCS2016向けに追加したプリミティブ ----


@dataclass(frozen=True)
class DamageWithOptionalEnergyReturnBonus(Effect):
    """自分についている指定タイプの基本エネルギーを1枚、手札に戻してもよい。戻したら追加ダメージ
    (ゲッコウガの「Moonlight Slash」等)。戻せる場合でも、プレイヤーは戻さない選択ができる。"""

    base: int
    bonus: int
    energy_type: str

    def execute(self, ctx: EffectContext) -> None:
        if ctx.source_pokemon is None:
            return
        eligible = [
            i
            for i, eid in enumerate(ctx.source_pokemon.attached_energy)
            if (c := ctx.card_db.get(eid)) is not None and c.basic_energy_type == self.energy_type
        ]
        if not eligible:
            DealDamage(self.base).execute(ctx)
            return
        ctx.state.pending_search_choice = PendingSearchChoice(
            player_index=ctx.acting_player,
            zone="own_pokemon_energy_target",
            source_indices=eligible,
            card_ids=[ctx.source_pokemon.attached_energy[i] for i in eligible],
            min_count=0,
            max_count=1,
            prompt=f"{self.energy_type}エネルギーを1枚、手札に戻して{self.bonus}ダメージ追加してもよい",
            shuffle_after=False,
            all_card_ids=[ctx.source_pokemon.attached_energy[i] for i in eligible],
            cont_source_pokemon=ctx.source_pokemon,
            cont_source_card_id=ctx.source_card_id,
            custom_data={"mode": "optional_energy_return_bonus", "base": self.base, "bonus": self.bonus},
        )


@dataclass(frozen=True)
class EndTurnAfterThisAbility(Effect):
    """「この特性を使ったら、自分の番はここで終わる」(ザシアンVの「Intrepid Sword」「Roar of the Sword」等)。
    実際の番の終了はengine.rules_engine._handle_use_abilityがrun_script実行後にこのフラグを見て行う
    (このEffect自身は他のトレーナー/どうぐプレイ等を挟めないよう即座に終了させたいわけではなく、
    特性の効果解決が完了した直後というタイミングを守るため、フラグを立てるだけに留める)。"""

    def execute(self, ctx: EffectContext) -> None:
        ctx.state.forced_turn_end_after_ability = True


@dataclass(frozen=True)
class BlockOpponentAbilitiesUntilTurnEnds(Effect):
    """相手の次の番が終わるまで、相手の場・手札・トラッシュのポケモンの特性が使えなくなる
    (自分側は影響を受けない)(ゲッコウガの「Shadow Stitching」等)。場のポケモンは_ability_actions、
    トラッシュ発動系の特性(ギラティナの「Distortion Door」等)は_discard_ability_actionsの両方で
    ロックを判定している(手札発動型の特性はこのエンジンに未実装のため対象カードなし)。"""

    def execute(self, ctx: EffectContext) -> None:
        opponent = ctx.state.player(ctx.opponent)
        ctx.state.opponent_ability_lock_target = ctx.opponent
        ctx.state.opponent_ability_lock_until_turn = opponent.turns_taken + 1


@dataclass(frozen=True)
class GrantFusionStrikeDamageBonusThisTurn(Effect):
    """パワータブレット: この番の間、自分のFusion Strikeポケモンのワザは相手のバトルポケモンに
    +30ダメージ(弱点・抵抗力適用前、engine.continuous.fusion_strike_damage_bonus経由で対応)。"""

    def execute(self, ctx: EffectContext) -> None:
        player = _attacker_player(ctx)
        player.fusion_strike_damage_bonus_until_turn = player.turns_taken


@dataclass(frozen=True)
class SearchDeckAnyCardsToDiscard(Effect):
    """山札から好きなカードを最大N枚まで選んでトラッシュする(バトルコンプレッサー等)。"""

    count: int

    def execute(self, ctx: EffectContext) -> None:
        player = _attacker_player(ctx)
        _trigger_search_choice(
            ctx,
            player,
            "deck",
            lambda card: card is not None,
            self.count,
            "山札から好きなカードを選んでトラッシュする",
            shuffle_after=False,
            destination="discard",
        )


@dataclass(frozen=True)
class DamagePerOwnDiscardPokemonCount(Effect):
    """自分のトラッシュにあるポケモンカードの枚数ぶんダメージ(ミツハニーの「Bee Revenge」等)。"""

    base: int
    per_pokemon: int

    def execute(self, ctx: EffectContext) -> None:
        player = _attacker_player(ctx)
        count = sum(1 for cid in player.discard if (card := ctx.card_db.get(cid)) is not None and card.is_pokemon)
        DealDamage(self.base + self.per_pokemon * count).execute(ctx)


@dataclass(frozen=True)
class DamagePerHeadsAmongEnergyCount(Effect):
    """自分についているエネルギーの数だけコインを投げ、オモテの数ぶんダメージ(カラマネロEXの
    「MAXamar」等)。"""

    per_heads: int

    def execute(self, ctx: EffectContext) -> None:
        if ctx.source_pokemon is None:
            return
        count = len(ctx.source_pokemon.attached_energy)
        heads = sum(1 for _ in range(count) if ctx.rng.random() < 0.5)
        DealDamage(self.per_heads * heads).execute(ctx)


@dataclass(frozen=True)
class SearchDiscardForPokemonOfTypeToHand(Effect):
    """トラッシュから指定タイプのポケモンを最大N枚まで探して手札に加える(リバイタライザー等)。"""

    count: int
    pokemon_type: str

    def execute(self, ctx: EffectContext) -> None:
        player = _attacker_player(ctx)

        def matches(card):
            return card is not None and card.is_pokemon and self.pokemon_type in card.types

        _trigger_search_choice(
            ctx, player, "discard", matches, self.count, f"トラッシュから{self.pokemon_type}タイプのポケモンを探す", shuffle_after=False
        )


@dataclass(frozen=True)
class ShuffleSpecialEnergyFromDiscardIntoDeck(Effect):
    """トラッシュの特殊エネルギーを最大N枚まで選び、手札を経由せず山札に戻す(スペシャルチャージ等)。"""

    count: int

    def execute(self, ctx: EffectContext) -> None:
        player = _attacker_player(ctx)

        def matches(card):
            return card is not None and card.is_special_energy

        eligible_indices = [i for i, cid in enumerate(player.discard) if matches(ctx.card_db.get(cid))]
        chosen_indices = eligible_indices[: self.count]
        chosen_ids = [player.discard[i] for i in chosen_indices]
        for i in sorted(chosen_indices, reverse=True):
            player.discard.pop(i)
        player.deck.extend(chosen_ids)
        ctx.rng.shuffle(player.deck)


@dataclass(frozen=True)
class SearchDiscardForPokemonOfTypeToBench(Effect):
    """トラッシュから指定タイプのポケモンを1匹探して、手札を経由せず直接ベンチに出す
    (Archie's Ace in the Hole等)。複数候補があれば_trigger_search_choice経由でプレイヤーが選ぶ。"""

    pokemon_type: str

    def execute(self, ctx: EffectContext) -> None:
        player = _attacker_player(ctx)

        def matches(card):
            return card is not None and card.is_pokemon and self.pokemon_type in card.types

        _trigger_search_choice(
            ctx, player, "discard", matches, 1, f"トラッシュから{self.pokemon_type}タイプのポケモンを探してベンチに出す",
            shuffle_after=False, destination="bench",
        )


@dataclass(frozen=True)
class SearchDiscardForBasicPokemonToBench(Effect):
    """トラッシュからたねポケモンを最大count匹探して、手札を経由せず直接ベンチに出す(げんきのかけら
    等はcount=1、ホウオウ(Ho-Oh)「Flames of Revival」実カードテキスト: "Put up to 3 Basic Pokémon
    from your discard pile onto your Bench."はcount=3)。複数候補があれば_trigger_search_choice
    経由でプレイヤーが選ぶ。"""

    count: int = 1

    def execute(self, ctx: EffectContext) -> None:
        player = _attacker_player(ctx)

        def matches(card):
            return card is not None and card.is_basic

        _trigger_search_choice(
            ctx, player, "discard", matches, self.count, f"トラッシュからたねポケモンを最大{self.count}匹探してベンチに出す",
            shuffle_after=False, destination="bench",
        )


@dataclass(frozen=True)
class SwapOwnPokemonIdentityWithDeckBasic(Effect):
    """選んだ自分のたねポケモン1匹を、山札から探した別のたねポケモンと入れ替える(ついているカード・
    ダメカン・特殊状態・場に出ていたターン等はそのまま引き継ぐ)。元のポケモンは山札に戻す
    (ニンジャボーイ等)。山札内に異なるたねポケモンが複数種類あれば、どれと入れ替えるかを
    プレイヤーに選ばせる(destination="swap_identity"をengine.rules_engine側が解決する)。"""

    def execute(self, ctx: EffectContext) -> None:
        player = _attacker_player(ctx)
        target = _resolve_own_target(ctx, player)
        if target is None:
            return

        def matches(card):
            return card is not None and card.is_basic

        eligible_indices = [i for i, cid in enumerate(player.deck) if matches(ctx.card_db.get(cid))]
        if not eligible_indices:
            return
        distinct_ids = {player.deck[i] for i in eligible_indices}
        if len(distinct_ids) == 1:
            idx = eligible_indices[0]
            new_id = player.deck[idx]
            remaining = list(player.deck)
            remaining.pop(idx)
            old_id = target.card_id
            target.card_id = new_id
            remaining.append(old_id)
            player.deck = remaining
            ctx.rng.shuffle(player.deck)
            ctx.log(f"{old_id} を山札の{new_id}と入れ替えた")
            return
        ctx.state.pending_search_choice = PendingSearchChoice(
            player_index=ctx.acting_player,
            zone="deck",
            source_indices=eligible_indices,
            card_ids=[player.deck[i] for i in eligible_indices],
            min_count=1,
            max_count=1,
            prompt="入れ替えるたねポケモンを選ぶ",
            shuffle_after=True,
            all_card_ids=list(player.deck),
            destination="swap_identity",
            attach_target_pokemon=target,
        )


@dataclass(frozen=True)
class ClearAllStatusConditionsBothSides(Effect):
    """両プレイヤー・場の全ポケモンについて「ワザの効果」を取り除く(ポケモンレンジャーの実カード
    テキスト "Remove all effects of attacks on each player and his or her Pokémon." )。特殊状態に加え、
    このエンジンでワザ由来と確認済みの継続効果(シールド/ダメージ軽減・免疫/攻撃・にげる封じ/
    道連れ/サイド獲得阻止/グッズロック)も全て解除する(effects/registry.pyでATTACK_EFFECTSにのみ
    登録され、ABILITY_EFFECTSでは未使用であることを確認済み)。特性由来のロック(Hex Maniac等)は
    「ワザの効果」ではないため対象外。"""

    def execute(self, ctx: EffectContext) -> None:
        for player in ctx.state.players:
            player.attack_locked_until_turn = 0
            player.items_locked_until_turn = 0
            for mon in player.all_pokemon_in_play():
                mon.status.clear_all()
                mon.locked_attack_until_turn = 0
                mon.shielded_until_turn = 0
                mon.damage_reduction_until_turn = 0
                mon.attack_disabled_until_turn = 0
                mon.attack_coinflip_until_turn = 0
                mon.attack_bonus_until_turn = 0
                mon.effect_shield_until_turn = 0
                mon.damage_coin_shield_until_turn = 0
                mon.retaliate_equal_damage = False
                mon.no_energy_attach_until_turn = 0
                mon.no_evolve_until_turn = 0
                mon.incoming_damage_bonus_until_turn = 0
                mon.abilities_off_until_turn = 0
                mon.no_weakness_until_turn = 0
                mon.damage_prevent_threshold_until_turn = 0
                mon.retreat_disabled_until_turn = 0
                mon.destiny_bond_until_turn = 0
                mon.damage_immunity_until_turn = 0
                mon.damage_debuff_until_turn = 0
                mon.no_prize_on_ko_until_turn = 0


@dataclass(frozen=True)
class DamageWithSupporterBonusToChosenOpponentBench(Effect):
    """この番にサポートを使っていれば、選んだ相手のベンチポケモン1匹に追加ダメージ(ダメカン計算は
    ベンチのため弱点・抵抗力を無視)(MタブンネEXの「Magical Symphony」等)。"""

    base: int
    bench_bonus: int

    def execute(self, ctx: EffectContext) -> None:
        if ctx.source_pokemon is None:
            return
        DealDamage(self.base).execute(ctx)
        player = _attacker_player(ctx)
        if not player.supporter_played_this_turn or ctx.target_bench_index is None:
            return
        opponent = ctx.state.player(ctx.opponent)
        if not (0 <= ctx.target_bench_index < len(opponent.bench)):
            return
        target = opponent.bench[ctx.target_bench_index]
        if _defender_is_shielded(ctx, target):
            return
        target_card = ctx.card_db.get(target.card_id)
        if target_card is None:
            return
        dmg = resolve_attack_damage(ctx, target, target_card, self.bench_bonus, apply_weakness=False, apply_resistance=False)
        target.damage += dmg


@dataclass(frozen=True)
class DamagePerOpponentActualPrizesTaken(Effect):
    """相手が実際に取ったサイドの枚数(6-相手の残りサイド)ぶんダメージが上乗せされる(コバルオンの
    「Revenge Blast」等)。既存のDamagePerOpponentPrizesTakenは実装上「自分が取ったサイド」を
    参照しており命名と挙動が食い違うため、正しく「相手が取ったサイド」を参照する版として別名で追加。"""

    base: int
    per_prize: int

    def execute(self, ctx: EffectContext) -> None:
        opponent = ctx.state.player(ctx.opponent)
        prizes_taken = 6 - len(opponent.prizes)
        DealDamage(self.base + self.per_prize * prizes_taken).execute(ctx)


@dataclass(frozen=True)
class DamagePerOwnBenchedPokemonCount(Effect):
    """自分のベンチポケモンの数ぶんダメージが上乗せされる(タブンネEXの「Do the Wave」等)。"""

    base: int
    per_pokemon: int

    def execute(self, ctx: EffectContext) -> None:
        player = _attacker_player(ctx)
        DealDamage(self.base + self.per_pokemon * len(player.bench)).execute(ctx)


@dataclass(frozen=True)
class ReturnSelfToHandUnconditional(Effect):
    """自分自身(バトル場にいる場合のみ)をついているカードごと手札に戻す(シェイミEXの「Sky Return」等)。
    バトル場が空になるため、ベンチがある場合のみ使用可能とする。"""

    def execute(self, ctx: EffectContext) -> None:
        if ctx.source_pokemon is None:
            return
        player = _attacker_player(ctx)
        if player.active is not ctx.source_pokemon or not player.bench:
            return
        mon = player.active
        player.active = None
        player.hand.extend(mon.evolution_history)
        player.hand.append(mon.card_id)
        player.hand.extend(mon.attached_energy)
        if mon.attached_tool:
            player.hand.append(mon.attached_tool)


@dataclass(frozen=True)
class ReturnOwnPokemonToHandDiscardingAttached(Effect):
    """自分のポケモン1匹(バトル/ベンチどちらでも指定可)を手札に戻し、ついていたカードは全てトラッシュする
    (AZ等)。"""

    def execute(self, ctx: EffectContext) -> None:
        player = _attacker_player(ctx)
        target = _resolve_own_target(ctx, player)
        if target is None:
            return
        if ctx.target_bench_index is None:
            player.active = None
        else:
            player.bench.pop(ctx.target_bench_index)
        player.hand.extend(target.evolution_history)
        player.hand.append(target.card_id)
        player.discard.extend(target.attached_energy)
        if target.attached_tool:
            player.discard.append(target.attached_tool)


@dataclass(frozen=True)
class HealTargetAndClearStatus(Effect):
    """選んだ自分のポケモン1匹のダメージを回復し、特殊状態も全て治す(ポケモンセンターのお姉さん等)。"""

    amount: int

    def execute(self, ctx: EffectContext) -> None:
        player = _attacker_player(ctx)
        target = _resolve_own_target(ctx, player)
        if target is None:
            return
        target.heal(self.amount)
        target.status.clear_all()


@dataclass(frozen=True)
class DiscardAllOpponentTools(Effect):
    """相手の場の全ポケモンについているポケモンのどうぐを全てトラッシュする(Startling Megaphone等)。"""

    def execute(self, ctx: EffectContext) -> None:
        opponent = ctx.state.player(ctx.opponent)
        for mon in opponent.all_pokemon_in_play():
            if mon.attached_tool is not None:
                discard_attached_tool(ctx.state, opponent, mon)


@dataclass(frozen=True)
class DamagePerToolInPlayBothSides(Effect):
    """場にいる両プレイヤーの全ポケモンについているポケモンのどうぐの枚数ぶんダメージ
    (ヤブクロンの「ドロップシステム」等)。"""

    per_tool: int

    def execute(self, ctx: EffectContext) -> None:
        count = sum(
            1
            for player in ctx.state.players
            for mon in player.all_pokemon_in_play()
            if mon.attached_tool is not None
        )
        DealDamage(self.per_tool * count).execute(ctx)


@dataclass(frozen=True)
class DamagePerOpponentDiscardItemCount(Effect):
    """相手のトラッシュにあるグッズカードの枚数ぶんダメージ(ダストダスの「Trashalanche」等)。"""

    per_item: int

    def execute(self, ctx: EffectContext) -> None:
        opponent = ctx.state.player(ctx.opponent)
        count = sum(1 for cid in opponent.discard if (card := ctx.card_db.get(cid)) is not None and card.is_item)
        DealDamage(self.per_item * count).execute(ctx)


@dataclass(frozen=True)
class DamagePerOpponentHandCardCount(Effect):
    """相手の手札の枚数ぶんダメージが上乗せされる(メガユキメノコexの「Resentful Refrain」等)。"""

    base: int
    per_card: int

    def execute(self, ctx: EffectContext) -> None:
        opponent = ctx.state.player(ctx.opponent)
        DealDamage(self.base + self.per_card * len(opponent.hand)).execute(ctx)


@dataclass(frozen=True)
class ReturnChosenOpponentEnergyToHand(Effect):
    """相手のバトルポケモンについているエネルギーを最大count枚選び、相手の手札に戻す
    (ヤドキングの「Wash the Slate Clean」等。複数種類あれば1枚ずつプレイヤーが選ぶ)。"""

    count: int = 1

    def execute(self, ctx: EffectContext) -> None:
        opponent = ctx.state.player(ctx.opponent)
        target = opponent.active
        if target is None or not target.attached_energy:
            return
        moved = 0
        remaining = list(target.attached_energy)
        while remaining and moved < self.count:
            energy_id = remaining.pop(0)
            target.attached_energy.remove(energy_id)
            opponent.hand.append(energy_id)
            moved += 1
        if moved:
            ctx.log(f"相手のバトルポケモンについているエネルギーを{moved}枚、相手の手札に戻した")


@dataclass(frozen=True)
class DamagePerOpponentDiscardSpecialEnergyCount(Effect):
    """相手のトラッシュにある特殊エネルギーカードの枚数ぶんダメージ(フワライドの「Shadow Steal」等)。"""

    per_energy: int

    def execute(self, ctx: EffectContext) -> None:
        opponent = ctx.state.player(ctx.opponent)
        count = sum(
            1 for cid in opponent.discard if (card := ctx.card_db.get(cid)) is not None and card.is_special_energy
        )
        DealDamage(self.per_energy * count).execute(ctx)


@dataclass(frozen=True)
class DealDamageToAllOpponentPokemon(Effect):
    """相手の場の全ポケモン(バトル+ベンチ)に固定ダメージ(カプ・コケコの「Flying Flip」等)。
    ベンチには弱点・抵抗力を計算しない。apply_wr_to_active=Falseなら、バトルポケモンにも計算しない(Wings of Disaster)。"""

    amount: int
    apply_wr_to_active: bool = True

    def execute(self, ctx: EffectContext) -> None:
        if ctx.source_pokemon is None:
            return
        opponent = ctx.state.player(ctx.opponent)
        attacker_card = ctx.card_db.get(ctx.source_pokemon.card_id)
        if attacker_card is None:
            return
        targets: list[tuple[PokemonInPlay, bool]] = []
        if opponent.active is not None:
            targets.append((opponent.active, True))
        for mon in opponent.bench:
            targets.append((mon, False))
        for mon, is_active in targets:
            if _defender_is_shielded(ctx, mon):
                continue
            defender_card = ctx.card_db.get(mon.card_id)
            if defender_card is None:
                continue
            wr = is_active and self.apply_wr_to_active
            dmg = resolve_attack_damage(ctx, mon, defender_card, self.amount, apply_weakness=wr, apply_resistance=wr)
            mon.damage += dmg
            ctx.damage_dealt += dmg
        ctx.log(f"{ctx.source_card_id} が相手の場の全ポケモンに{self.amount}ダメージ")


@dataclass(frozen=True)
class DamageIfSupporterPlayedThisTurn(Effect):
    """この番にサポートを使っていれば、追加でボーナスダメージ(エルレイドの「Sensitive Blade」等)。"""

    base: int
    bonus: int

    def execute(self, ctx: EffectContext) -> None:
        player = _attacker_player(ctx)
        amount = self.base + self.bonus if player.supporter_played_this_turn else self.base
        DealDamage(amount).execute(ctx)


@dataclass(frozen=True)
class HealAllOwnPokemonOfType(Effect):
    """自分の場にいる、指定タイプの全ポケモンのダメージを回復する(ディアンシーの「Diamond Storm」、
    ラフレシアの「Rough Seas」等)。pokemon_types_any指定時は複数タイプのいずれかでよい(OR条件)。"""

    pokemon_type: str | None = None
    amount: int = 0
    pokemon_types_any: tuple[str, ...] | None = None

    def execute(self, ctx: EffectContext) -> None:
        player = _attacker_player(ctx)
        for mon in player.all_pokemon_in_play():
            card = ctx.card_db.get(mon.card_id)
            if card is None:
                continue
            matches = (self.pokemon_type is not None and self.pokemon_type in card.types) or (
                self.pokemon_types_any is not None and any(t in card.types for t in self.pokemon_types_any)
            )
            if matches:
                mon.heal(self.amount)


@dataclass(frozen=True)
class ShuffleDiscardIntoDeck(Effect):
    """トラッシュのカードをN枚、山札に戻してシャッフルする(サーナイトGXの「Twilight-GX」等、
    実カードテキストは"Shuffle N cards from your discard pile into your deck"で必ずN枚)。
    トラッシュがN枚を超えていれば、どの N枚を戻すかをプレイヤーが選ぶ(N枚以下ならそのまま全て戻す
    のでプレイヤー選択は不要)。"""

    count: int

    def execute(self, ctx: EffectContext) -> None:
        player = _attacker_player(ctx)
        if len(player.discard) <= self.count:
            moved = list(player.discard)
            player.discard = []
            player.deck.extend(moved)
            ctx.rng.shuffle(player.deck)
            ctx.log(f"トラッシュから{len(moved)}枚を山札に戻した")
            return
        ctx.state.pending_search_choice = PendingSearchChoice(
            player_index=ctx.acting_player,
            zone="discard",
            source_indices=list(range(len(player.discard))),
            card_ids=list(player.discard),
            min_count=self.count,
            max_count=self.count,
            prompt=f"山札に戻すカードを{self.count}枚選ぶ",
            shuffle_after=True,
            all_card_ids=list(player.discard),
            destination="deck",
        )


@dataclass(frozen=True)
class ChooseDiscardCardsToBottomOfDeck(Effect):
    """トラッシュからカードを最大count枚選び、シャッフルせず山札の一番下に置く(順番はプレイヤーが
    選ぶ、ヤレユータンの「Resource Management」実カードテキスト: "Put 3 cards from your discard
    pile on the bottom of your deck in any order."用。ShuffleDiscardIntoDeckと異なりシャッフルは
    しない)。トラッシュがcount枚以下ならそのまま全て戻すのでプレイヤー選択は不要。"""

    count: int

    def execute(self, ctx: EffectContext) -> None:
        player = _attacker_player(ctx)
        if len(player.discard) <= self.count:
            moved = list(player.discard)
            player.discard = []
            player.deck.extend(moved)
            ctx.log(f"トラッシュから{len(moved)}枚を山札の一番下に置いた")
            return
        ctx.state.pending_search_choice = PendingSearchChoice(
            player_index=ctx.acting_player,
            zone="discard",
            source_indices=list(range(len(player.discard))),
            card_ids=list(player.discard),
            min_count=self.count,
            max_count=self.count,
            prompt=f"山札の一番下に置くカードを{self.count}枚選ぶ",
            shuffle_after=False,
            all_card_ids=list(player.discard),
            destination="deck",
        )


@dataclass(frozen=True)
class ReturnDamagedOwnPokemonToHand(Effect):
    """ダメカンが1個以上のっている自分のポケモン1匹を、ついているカードごと手札に戻す(アセロラ等)。"""

    def execute(self, ctx: EffectContext) -> None:
        player = _attacker_player(ctx)
        target = _resolve_own_target(ctx, player)
        if target is None or target.damage <= 0:
            return
        if ctx.target_bench_index is None:
            player.active = None
        else:
            player.bench.pop(ctx.target_bench_index)
        player.hand.extend(target.evolution_history)
        player.hand.append(target.card_id)
        player.hand.extend(target.attached_energy)
        if target.attached_tool:
            player.hand.append(target.attached_tool)


@dataclass(frozen=True)
class BlockAllAbilitiesUntilOpponentTurnEnds(Effect):
    """相手の次の番が終わるまで、両プレイヤーの場・手札・トラッシュのポケモンの特性が全て
    使えなくなる(サポート「Hex Maniac」実カードテキスト: "each Pokémon in play, in each
    player's hand, and in each player's discard pile has no Abilities"。場は_ability_actions、
    トラッシュは_discard_ability_actionsの両方でglobal_ability_lock_ownerを判定して両プレイヤー分
    ブロックしている(手札発動型の特性はこのエンジンに未実装のため対象カードなし)。
    既知の限定事項: ベンチに出た瞬間等のトリガー型特性(Garbotoxin等の常時効果)は本Effectの
    対象外(UseAbilityで起動する特性のみ)。"""

    def execute(self, ctx: EffectContext) -> None:
        opponent = ctx.state.player(ctx.opponent)
        ctx.state.global_ability_lock_owner = ctx.opponent
        ctx.state.global_ability_lock_until_turn = opponent.turns_taken + 1


@dataclass(frozen=True)
class DamageIfExtraEnergyAttached(Effect):
    """このワザのコスト以外にエネルギーが指定数以上ついているなら、ダメージが上乗せされる。"""

    base: int
    bonus: int
    extra_needed: int
    cost_count: int

    def execute(self, ctx: EffectContext) -> None:
        if ctx.source_pokemon is None:
            return
        extra = len(ctx.source_pokemon.attached_energy) - self.cost_count
        amount = self.base + self.bonus if extra >= self.extra_needed else self.base
        DealDamage(amount).execute(ctx)


@dataclass(frozen=True)
class AttachEnergyFromDiscardToOwnPokemon(Effect):
    """トラッシュから、energy_typeで指定したタイプの基本エネルギーだけを最大count枚選び、自分のポケモン1匹につける(つけた側はダメカンをのせる)。
    例: energy_type="Psychic"=基本超エネルギーだけ(ワンダーパッチ/ムチュール等。「すべてのエネルギー」ではない)。

    energy_type=None のときだけ、タイプを問わず基本エネルギーを対象にする(モトムラのハイセツカザン等)。
    self_only=Trueなら対象はこのポケモン自身固定(ガラルファイヤーVの「Direflame Wings」等、
    ctx.target_bench_indexを無視しctx.source_pokemonを直接使う。ベンチにいても正しく自分自身が対象になる)。
    target_typeを指定すると、対象は自分の場のそのタイプのポケモンに限定される(engine.legal_actions側で
    候補を絞り込む。ここではフィールドの絞り込みは行わない)。target_name_prefixを指定すると、対象は
    カード名がその文字列で始まるポケモンに限定される(Nのポイントアップ実カードテキスト:
    "1 of your Benched N's Pokémon"用、同じくengine.legal_actions側で絞り込む)。
    """

    energy_type: str | None
    self_damage: int = 0
    count: int = 1
    self_only: bool = False
    target_type: str | None = None
    target_subtype: str | None = None
    target_name_prefix: str | None = None
    bench_only: bool = False

    def execute(self, ctx: EffectContext) -> None:
        player = _attacker_player(ctx)
        target = ctx.source_pokemon if self.self_only else _resolve_own_target(ctx, player)
        ctx.last_attach_succeeded = False
        if target is None:
            return
        if self.bench_only and target is player.active:
            # ワンダーパッチ実カードテキスト: "ベンチのポケモンにつける"(バトルポケモンは対象外)。
            # legal_actions側で候補をベンチのみに絞っているはずだが、二重の安全策として実行時にも弾く。
            return
        attached = 0
        remaining: list[str] = []
        for card_id in player.discard:
            card = ctx.card_db.get(card_id)
            matches = card is not None and (
                card.basic_energy_type == self.energy_type if self.energy_type else not card.is_special_energy and card.is_energy
            )
            if attached < self.count and matches:
                attached += 1
                target.attached_energy.append(card_id)
            else:
                remaining.append(card_id)
        player.discard = remaining
        if attached:
            ctx.last_attach_succeeded = True
            target.damage += self.self_damage


@dataclass(frozen=True)
class AttachEnergyFromDiscardToEachOwnBenchedOfType(Effect):
    """自分のベンチにいる、たねポケモンかつ指定タイプを持つポケモンそれぞれに、トラッシュから
    基本エネルギーを1枚ずつつける(ラティアス◇の「Dreamy Mist」等)。トラッシュ内に基本エネルギーの
    種類が複数あるときは、対象ポケモンごとにどれをつけるかプレイヤーが選ぶ
    (InstantEvolveEachTargetFromDeckと同じremaining_script連鎖パターン)。"""

    required_type: str

    def execute(self, ctx: EffectContext) -> None:
        player = _attacker_player(ctx)
        targets = tuple(
            mon
            for mon in player.bench
            if (card := ctx.card_db.get(mon.card_id)) is not None
            and card.is_basic
            and self.required_type in card.types
        )
        _attach_discard_energy_to_each_target(ctx, targets)


@dataclass(frozen=True)
class ChooseUpToNOwnBenchedThenAttachDiscardEnergyToEach(Effect):
    """このカードは、自分の場にテラスタルポケモンがいなければ使えない(legal_actionsでゲート)。
    自分のベンチの指定タイプのポケモンを最大count体まで選び、選んだそれぞれにトラッシュから
    基本エネルギーを1枚ずつつける(ガラスのラッパ実カードテキスト: "Choose up to 2 of your Benched
    Colorless Pokémon and attach a Basic Energy card from your discard pile to each of them."用)。
    実カードテキストにたねポケモン限定の記載は無いため、進化済みのColorlessポケモンも対象になる
    (以前はis_basicで誤って絞り込んでおり、進化済みポケモンしかベンチにいない場合に候補0件と
    誤判定されてしまっていた、2026-08-20発覚)。"""

    count: int
    required_type: str

    def execute(self, ctx: EffectContext) -> None:
        player = _attacker_player(ctx)
        candidates = [
            (i + 1, mon)
            for i, mon in enumerate(player.bench)
            if (card := ctx.card_db.get(mon.card_id)) is not None and self.required_type in card.types
        ]
        if not candidates:
            return
        n = min(self.count, len(candidates))
        ctx.state.pending_search_choice = PendingSearchChoice(
            player_index=ctx.acting_player,
            zone="own_pokemon_target",
            source_indices=[slot for slot, _ in candidates],
            card_ids=[mon.card_id for _, mon in candidates],
            min_count=0,
            max_count=n,
            prompt=f"トラッシュのエネルギーをつけるベンチのポケモンを最大{n}体選ぶ",
            shuffle_after=False,
            all_card_ids=[mon.card_id for _, mon in candidates],
            custom_data={"mode": "attach_discard_energy_to_chosen_targets"},
        )


def _attach_discard_energy_to_each_target(ctx: EffectContext, targets: tuple) -> None:
    if not targets:
        return
    player = _attacker_player(ctx)
    target = targets[0]
    rest = targets[1:]
    eligible_indices = [i for i, cid in enumerate(player.discard) if (c := ctx.card_db.get(cid)) is not None and c.is_energy and not c.is_special_energy]
    if not eligible_indices:
        return
    distinct_ids = {player.discard[i] for i in eligible_indices}
    if len(distinct_ids) == 1:
        idx = eligible_indices[0]
        energy_id = player.discard.pop(idx)
        target.attached_energy.append(energy_id)
        _attach_discard_energy_to_each_target(ctx, rest)
        return
    ctx.state.pending_search_choice = PendingSearchChoice(
        player_index=ctx.acting_player,
        zone="discard",
        source_indices=eligible_indices,
        card_ids=[player.discard[i] for i in eligible_indices],
        min_count=1,
        max_count=1,
        prompt=f"{target.card_id}につける基本エネルギーを選ぶ",
        shuffle_after=False,
        all_card_ids=list(player.discard),
        destination="attach_energy",
        attach_target_pokemon=target,
        cont_source_pokemon=ctx.source_pokemon,
        cont_source_card_id=ctx.source_card_id,
        custom_data={"mode": "attach_discard_energy_continue", "rest": rest},
    )


@dataclass(frozen=True)
class AttachEnergyFromDiscardToSelf(Effect):
    """トラッシュから基本エネルギーを最大count枚選び、自分自身(ctx.source_pokemon)につける。
    AttachEnergyFromDiscardToOwnPokemonと異なりtarget_bench_index経由の対象選択をせず、
    ベンチに出た瞬間に発動する特性(レックウザGXの「Stormy Winds」等)のように、対象が常に
    「今そのカード自身」であるケース用。"""

    energy_type: str | None = None
    count: int = 1

    def execute(self, ctx: EffectContext) -> None:
        if ctx.source_pokemon is None:
            return
        player = _attacker_player(ctx)
        attached = 0
        remaining: list[str] = []
        for card_id in player.discard:
            card = ctx.card_db.get(card_id)
            matches = card is not None and (
                card.basic_energy_type == self.energy_type if self.energy_type else not card.is_special_energy and card.is_energy
            )
            if attached < self.count and matches:
                attached += 1
                ctx.source_pokemon.attached_energy.append(card_id)
            else:
                remaining.append(card_id)
        player.discard = remaining


@dataclass(frozen=True)
class DamagePerOwnBoardEnergyOfTypes(Effect):
    """自分の場の全ポケモンについている、指定タイプの基本エネルギーの合計枚数ぶんダメージが
    上乗せされる(レックウザGXの「Dragon Break」等)。"""

    per_energy: int
    energy_types: tuple[str, ...]

    def execute(self, ctx: EffectContext) -> None:
        if ctx.source_pokemon is None:
            return
        player = _attacker_player(ctx)
        count = sum(
            1
            for mon in player.all_pokemon_in_play()
            for e in mon.attached_energy
            if (card := ctx.card_db.get(e)) is not None and card.basic_energy_type in self.energy_types
        )
        DealDamage(self.per_energy * count).execute(ctx)


@dataclass(frozen=True)
class MoveOpponentHandCardToTheirPrizes(Effect):
    """相手の手札を公開させ、その中から自分が選んだ1枚を相手のサイド(裏向き)に加える
    (デンジュモクGXの「Lighting-GX」実カードテキスト: "Your opponent reveals their hand.
    Add a card you find there to their Prize cards face down." — カードを選ぶのは自分側)。"""

    def execute(self, ctx: EffectContext) -> None:
        opponent = ctx.state.player(ctx.opponent)
        if not opponent.hand:
            return
        # 相手の手札を公開させた瞬間のスナップショットを、以後もこのプレイヤーの「知っている
        # 相手の手札」として保持する(この1手のうちしか使えなかった以前の実装への対応。
        # 2026-08-20)。
        ctx.state.player(ctx.acting_player).known_opponent_hand = list(opponent.hand)
        ctx.state.pending_search_choice = PendingSearchChoice(
            player_index=ctx.acting_player,
            zone="opponent_hand_to_prizes",
            source_indices=list(range(len(opponent.hand))),
            card_ids=list(opponent.hand),
            min_count=1,
            max_count=1,
            prompt="相手の手札を公開させ、サイドに加える1枚を選ぶ",
            shuffle_after=False,
            all_card_ids=list(opponent.hand),
        )


@dataclass(frozen=True)
class ClearOwnStatusConditions(Effect):
    """自分自身についているすべての特殊状態を治す。"""

    def execute(self, ctx: EffectContext) -> None:
        if ctx.source_pokemon is None:
            return
        ctx.source_pokemon.status.clear_all()


@dataclass(frozen=True)
class DamagePerTotalBenchedPokemon(Effect):
    """両者のベンチポケモンの合計数ぶんダメージが上乗せされる。"""

    base: int
    per_pokemon: int

    def execute(self, ctx: EffectContext) -> None:
        player = _attacker_player(ctx)
        opponent = ctx.state.player(ctx.opponent)
        count = len(player.bench) + len(opponent.bench)
        DealDamage(self.base + self.per_pokemon * count).execute(ctx)


@dataclass(frozen=True)
class DamagePerOpponentBenchedPokemon(Effect):
    """相手のベンチポケモンの数ぶんダメージが上乗せされる(ルガルガンGXの「Dangerous Rogue-GX」等)。"""

    base: int
    per_pokemon: int

    def execute(self, ctx: EffectContext) -> None:
        opponent = ctx.state.player(ctx.opponent)
        DealDamage(self.base + self.per_pokemon * len(opponent.bench)).execute(ctx)


@dataclass(frozen=True)
class DamagePerOwnPrizesRemaining(Effect):
    """自分の残りサイドの枚数ぶんダメージが上乗せされる(マッシブーンGXの「Absorption-GX」等)。"""

    per_prize: int

    def execute(self, ctx: EffectContext) -> None:
        player = _attacker_player(ctx)
        DealDamage(self.per_prize * len(player.prizes)).execute(ctx)


@dataclass(frozen=True)
class DamageIfOpponentPrizesRemainingExactly(Effect):
    """相手の残りサイドがちょうどN枚のとき、追加でボーナスダメージ(マッシブーンの「Sledgehammer」等)。"""

    base: int
    bonus: int
    n: int

    def execute(self, ctx: EffectContext) -> None:
        opponent = ctx.state.player(ctx.opponent)
        amount = self.base + self.bonus if len(opponent.prizes) == self.n else self.base
        DealDamage(amount).execute(ctx)


@dataclass(frozen=True)
class FlipMultipleCoinsForBonusDamage(Effect):
    """コインをN回投げて、オモテの数ぶんボーナスダメージが上乗せされる(マッシブーンの「Swing Around」等)。"""

    base: int
    count: int
    per_heads: int

    def execute(self, ctx: EffectContext) -> None:
        heads = sum(1 for _ in range(self.count) if ctx.rng.random() < 0.5)
        DealDamage(self.base + self.per_heads * heads).execute(ctx)


@dataclass(frozen=True)
class DiscardOwnEnergyForScalingDamage(Effect):
    """このポケモンについているエネルギーを最大N枚までトラッシュし、トラッシュした枚数ぶんダメージ。
    energy_type指定時はその基本タイプのエネルギーのみが対象(マグカルゴ(Ethan's Magcargo)
    「Lava Burst」実カードテキスト: "Discard up to 5 Fire Energy from this Pokémon."用)。"""

    max_count: int
    damage_per: int
    energy_type: str | None = None

    def execute(self, ctx: EffectContext) -> None:
        if ctx.source_pokemon is None:
            return
        player = _attacker_player(ctx)
        if self.energy_type is None:
            discarded = ctx.source_pokemon.attached_energy[: self.max_count]
            ctx.source_pokemon.attached_energy = ctx.source_pokemon.attached_energy[self.max_count :]
        else:
            discarded = []
            remaining = []
            for energy_id in ctx.source_pokemon.attached_energy:
                card = ctx.card_db.get(energy_id)
                if len(discarded) < self.max_count and card is not None and card.basic_energy_type == self.energy_type:
                    discarded.append(energy_id)
                else:
                    remaining.append(energy_id)
            ctx.source_pokemon.attached_energy = remaining
        player.discard.extend(discarded)
        DealDamage(self.damage_per * len(discarded)).execute(ctx)


@dataclass(frozen=True)
class DamagePerSelfDamageCountersToChosenOpponent(Effect):
    """自分についているダメカンの数だけ、選んだ相手のポケモンにダメージ(ベンチには弱点・抵抗力を計算しない)。"""

    per_counter: int

    def execute(self, ctx: EffectContext) -> None:
        if ctx.source_pokemon is None:
            return
        counters = ctx.source_pokemon.damage // 10
        DealDamageToChosenOpponentPokemon(self.per_counter * counters).execute(ctx)


@dataclass(frozen=True)
class ShuffleHandThenDrawWithPrizeBonus(Effect):
    """手札を山札に戻してシャッフルし、通常枚数を引く(サイドがちょうどN枚残っているならボーナス枚数を引く)。"""

    base_count: int
    bonus_count: int
    prizes_remaining_for_bonus: int

    def execute(self, ctx: EffectContext) -> None:
        player = _attacker_player(ctx)
        player.deck.extend(player.hand)
        player.hand = []
        ctx.rng.shuffle(player.deck)
        count = self.bonus_count if len(player.prizes) == self.prizes_remaining_for_bonus else self.base_count
        Draw(count).execute(ctx)


@dataclass(frozen=True)
class BothPlayersHandToBottomThenDrawAsymmetric(Effect):
    """おたがいのプレイヤーが手札をシャッフルして山札の一番下に置く。どちらかが1枚でも置いたなら、自分はown_count枚、
    相手はopponent_count枚引く(マリィ(swsh1-169)実カードテキスト: "Each player shuffles their hand and puts it on
    the bottom of their deck. If either player put any cards on the bottom of their deck in this way, you draw 5
    cards, and your opponent draws 4 cards.")。以前は山札全体にシャッフルして混ぜる実装だった(2026-10-06訂正)。"""

    own_count: int
    opponent_count: int

    def execute(self, ctx: EffectContext) -> None:
        any_put = False
        for player_index in (ctx.acting_player, ctx.opponent):
            player = ctx.state.player(player_index)
            if player.hand:
                any_put = True
                ctx.rng.shuffle(player.hand)
                player.deck.extend(player.hand)
                player.hand = []
        if not any_put:
            return
        for player_index, count in ((ctx.acting_player, self.own_count), (ctx.opponent, self.opponent_count)):
            player = ctx.state.player(player_index)
            for _ in range(count):
                if not player.deck:
                    break
                player.hand.append(player.deck.pop(0))
        ctx.state.player(ctx.acting_player).known_opponent_hand = []
        ctx.state.player(ctx.opponent).known_opponent_hand = []


@dataclass(frozen=True)
class BothPlayersShuffleHandIntoDeckThenDrawByPrizes(Effect):
    """おたがいのプレイヤーが手札を山札に戻してシャッフルし、それぞれ自分の残りサイドの枚数だけ山札を引く(N実カード
    テキスト: "Each player shuffles his or her hand into his or her deck. Then, each player draws a card for each of
    his or her remaining Prize cards.")。イオン(手札を山札の一番下に置く)とは別のカード。以前はNにもイオンの
    効果(山札の下に積む)を使っていた誤りを訂正(2026-10-06)。"""

    def execute(self, ctx: EffectContext) -> None:
        for player_index in (ctx.acting_player, ctx.opponent):
            player = ctx.state.player(player_index)
            player.deck.extend(player.hand)
            player.hand = []
            ctx.rng.shuffle(player.deck)
        for player_index in (ctx.acting_player, ctx.opponent):
            player = ctx.state.player(player_index)
            for _ in range(len(player.prizes)):
                if not player.deck:
                    break
                player.hand.append(player.deck.pop(0))
        ctx.state.player(ctx.acting_player).known_opponent_hand = []
        ctx.state.player(ctx.opponent).known_opponent_hand = []


@dataclass(frozen=True)
class BothPlayersShuffleHandAndDrawByPrizes(Effect):
    """イオン(Iono)実カードテキスト: "Each player shuffles their hand and puts it on the bottom
    of their deck. If either player put any cards on the bottom of their deck in this way, each
    player draws a card for each of their remaining Prize cards."

    2点、以前の実装と異なる: (1)手札は山札全体とシャッフルするのではなく、手札だけをシャッフル
    してから山札の一番下に積む(山札の途中に混ざるv1簡略版だった)。(2)どちらのプレイヤーも
    手札が0枚だった場合は、両者とも1枚も引かない("if either player put any cards"の条件。
    以前は手札の有無に関わらず常に両者が引いていた)。"""

    def execute(self, ctx: EffectContext) -> None:
        any_put_to_bottom = False
        for player_index in (ctx.acting_player, ctx.opponent):
            player = ctx.state.player(player_index)
            if player.hand:
                any_put_to_bottom = True
                ctx.rng.shuffle(player.hand)
                player.deck.extend(player.hand)  # 山札の末尾=一番下に積む(全体シャッフルはしない)
                player.hand = []
        if not any_put_to_bottom:
            return
        for player_index in (ctx.acting_player, ctx.opponent):
            player = ctx.state.player(player_index)
            for _ in range(len(player.prizes)):
                if not player.deck:
                    break
                player.hand.append(player.deck.pop(0))
        # 両者の手札が丸ごと入れ替わったので、以前互いに公開させて覚えていた相手の手札の記憶は無効化する。
        ctx.state.player(ctx.acting_player).known_opponent_hand = []
        ctx.state.player(ctx.opponent).known_opponent_hand = []


@dataclass(frozen=True)
class ReturnOwnBenchedPokemonToHandDiscardAttached(Effect):
    """自分の場のポケモン1匹(バトル場/ベンチどちらでも指定可)を手札に戻す(ついているカードは
    すべてトラッシュする。フトゥー博士のシナリオ等)。"""

    def execute(self, ctx: EffectContext) -> None:
        player = _attacker_player(ctx)
        if ctx.target_bench_index is None:
            target = player.active
            if target is None:
                return
            player.active = None
        else:
            if not (0 <= ctx.target_bench_index < len(player.bench)):
                return
            target = player.bench.pop(ctx.target_bench_index)
        player.discard.extend(target.attached_energy)
        if target.attached_tool:
            player.discard.append(target.attached_tool)
        player.hand.extend(target.evolution_history)
        player.hand.append(target.card_id)


@dataclass(frozen=True)
class SearchDeckForBasicEnergyToHand(Effect):
    """山札から基本エネルギーを最大N枚まで探して手札に加える。energy_type指定時はそのタイプ限定。

    bonus_count_if_second_first_turn指定時、後攻1ターン目ならcountの代わりにこの枚数を使う
    (エネルギースピナーの「後攻1ターン目なら3枚まで」等)。
    """

    count: int
    energy_type: str | None = None
    bonus_count_if_second_first_turn: int | None = None

    def execute(self, ctx: EffectContext) -> None:
        player = _attacker_player(ctx)
        count = self.count
        if self.bonus_count_if_second_first_turn is not None and _is_second_players_first_turn(ctx):
            count = self.bonus_count_if_second_first_turn

        def matches(card):
            if card is None or not card.is_energy or card.is_special_energy:
                return False
            return self.energy_type is None or card.basic_energy_type == self.energy_type

        _trigger_search_choice(ctx, player, "deck", matches, count, "山札から基本エネルギーを探す")


@dataclass(frozen=True)
class ChooseOneDiscardPokemonToHandOrThreeIntoDeck(Effect):
    """「次の2つから1つを選ぶ」: ①トラッシュからポケモンを1枚手札に加える ②トラッシュからポケモンを3枚山札に戻して
    シャッフルする(レスキュータンカ(sm2-130)実カードテキスト)。どちらを使うかはPlayItemのtarget_bench_indexで
    表す(None=①、0=②)。②はトラッシュにポケモンが3枚以上あるときだけ選べる(legal_actions側でゲート)。"""

    def execute(self, ctx: EffectContext) -> None:
        player = _attacker_player(ctx)
        if ctx.target_bench_index == 0:
            _trigger_search_choice(
                ctx, player, "discard", lambda card: card is not None and card.is_pokemon, 3,
                "トラッシュからポケモンを3枚選んで山札に戻す", shuffle_after=True, destination="deck", min_count=3,
            )
        else:
            _trigger_search_choice(
                ctx, player, "discard", lambda card: card is not None and card.is_pokemon, 1,
                "トラッシュからポケモンを1枚選んで手札に加える", shuffle_after=False, destination="hand",
            )


@dataclass(frozen=True)
class ShuffleFromDiscardIntoDeck(Effect):
    """トラッシュからポケモンと基本エネルギーを合計最大N枚まで選び、手札を経由せず山札に戻す
    (すごいつりざお(Super Rod)実カードテキスト: "Put up to N in any combination of Pokémon and
    Basic Energy cards from your discard pile into your deck."。どのカードを戻すかはプレイヤーが選ぶ)。
    only="pokemon"/"energy"指定時はその種類のみが対象(ふつうのつりざお(Ordinary Rod)のように、
    ポケモン/エネルギーそれぞれ独立した上限を持つカード用の内訳として使う)。"""

    count: int
    only: str | None = None  # None: 両方対象 | "pokemon" | "energy"
    exact: bool = False  # True: 「N枚を戻す」(最大ではなく、対象がN枚以上あればちょうどN枚を選ぶ)

    def execute(self, ctx: EffectContext) -> None:
        player = _attacker_player(ctx)

        def matches(card):
            if card is None:
                return False
            if self.only == "pokemon":
                return card.is_pokemon
            if self.only == "energy":
                return card.is_energy and not card.is_special_energy
            return card.is_pokemon or (card.is_energy and not card.is_special_energy)

        _trigger_search_choice(
            ctx, player, "discard", matches, self.count, "トラッシュから山札に戻すカードを選ぶ",
            shuffle_after=True, destination="deck", min_count=self.count if self.exact else 0,
        )


# ---- がブレンミラー修正(ドクロッグG/アグノムの正しい印刷)向けに追加したプリミティブ ----


@dataclass(frozen=True)
class FlipCoinThenReturnSelfToHand(Effect):
    """コインを1回投げ、オモテなら自分自身(バトル場にいる場合のみ)をついているカードごと手札に戻す。

    バトル場が空になるため、ベンチがある場合のみ使用可能とし、新しいバトルポケモンの選択待ちにする。
    """

    def execute(self, ctx: EffectContext) -> None:
        if ctx.source_pokemon is None:
            return
        player = _attacker_player(ctx)
        if player.active is not ctx.source_pokemon or not player.bench:
            return
        heads = ctx.rng.random() < 0.5
        ctx.log("コイン: オモテ" if heads else "コイン: ウラ")
        if not heads:
            return
        mon = player.active
        player.active = None
        player.hand.extend(mon.evolution_history)
        player.hand.append(mon.card_id)
        player.hand.extend(mon.attached_energy)
        if mon.attached_tool:
            player.hand.append(mon.attached_tool)
        ctx.state.pending_active_choice = [ctx.acting_player]
        ctx.state.then_after_choice = "continue"


@dataclass(frozen=True)
class TimeWalkSwapPrizeForPokemon(Effect):
    """自分の裏向きサイドを見て、ポケモンが1枚でもあれば選んで(選ばなくてもよい)公開の上手札に
    加え、加えた場合は続けて手札から1枚を選んで新しいサイド(裏向き)にする(アグノムの特性
    「Time Walk」実カードテキスト: "you may choose 1 Pokémon you find there" / "choose 1 card
    in your hand" — どちらもプレイヤーが選ぶ)。"""

    def execute(self, ctx: EffectContext) -> None:
        player = _attacker_player(ctx)
        pokemon_positions = [
            i for i, cid in enumerate(player.prizes) if (c := ctx.card_db.get(cid)) is not None and c.is_pokemon
        ]
        if not pokemon_positions:
            return
        ctx.state.pending_search_choice = PendingSearchChoice(
            player_index=ctx.acting_player,
            zone="own_prizes_pokemon_to_hand",
            source_indices=pokemon_positions,
            card_ids=[player.prizes[i] for i in pokemon_positions],
            min_count=0,
            max_count=1,
            prompt="タイムウォーク: サイドから手札に加えるポケモンを選ぶ(選ばなくてもよい)",
            shuffle_after=False,
            all_card_ids=[player.prizes[i] for i in pokemon_positions],
        )


@dataclass(frozen=True)
class DamagePerDefenderEnergyCount(Effect):
    """相手のバトルポケモンについているエネルギーの数だけダメージが上乗せされる。"""

    base: int
    per_energy: int

    def execute(self, ctx: EffectContext) -> None:
        _, defender = _defender(ctx)
        count = len(defender.attached_energy) if defender else 0
        DealDamage(self.base + self.per_energy * count).execute(ctx)


@dataclass(frozen=True)
class DamageBonusIfOwnEnergyIdAttached(Effect):
    """自分に指定IDのエネルギーが1枚でもついていればbonusダメージ上乗せ(ロケット団のフリーザーの
    「Dark Frost」: "If this Pokemon has any Team Rocket's Energy attached, this attack does 60
    more damage."等)。"""

    base: int
    bonus: int
    required_energy_id: str

    def execute(self, ctx: EffectContext) -> None:
        has_energy = ctx.source_pokemon is not None and self.required_energy_id in ctx.source_pokemon.attached_energy
        DealDamage(self.base + self.bonus if has_energy else self.base).execute(ctx)


@dataclass(frozen=True)
class DamagePerDefenderEnergyCountIfSelfHasEnergyId(Effect):
    """自分に指定IDのエネルギーが1枚でもついているときだけ、相手のバトルポケモンのエネルギー数に
    応じた追加ダメージが発生する(デオキシスEXの「Helix Force」: プラズマエネルギーがあれば
    相手のエネルギー1枚につき+30、等)。"""

    base: int
    per_energy: int
    required_energy_id: str

    def execute(self, ctx: EffectContext) -> None:
        if ctx.source_pokemon is None or self.required_energy_id not in ctx.source_pokemon.attached_energy:
            DealDamage(self.base).execute(ctx)
            return
        _, defender = _defender(ctx)
        count = len(defender.attached_energy) if defender else 0
        DealDamage(self.base + self.per_energy * count).execute(ctx)


@dataclass(frozen=True)
class DamageIfStadiumInPlay(Effect):
    """場にスタジアムが出ているときだけダメージが発生する(なければこのワザは何もしない)。"""

    amount: int

    def execute(self, ctx: EffectContext) -> None:
        if ctx.state.stadium_in_play is None:
            return
        DealDamage(self.amount).execute(ctx)


@dataclass(frozen=True)
class DiscardStadiumInPlay(Effect):
    """場に出ているスタジアムを(あれば)トラッシュする(チオンジェンの「ゆきどけ」等、"してもよい"系)。"""

    def execute(self, ctx: EffectContext) -> None:
        if ctx.state.stadium_in_play is None or ctx.state.stadium_owner is None:
            return
        owner = ctx.state.player(ctx.state.stadium_owner)
        owner.discard.append(ctx.state.stadium_in_play)
        ctx.log(f"スタジアム「{ctx.state.stadium_in_play}」をトラッシュした")
        ctx.state.stadium_in_play = None
        ctx.state.stadium_owner = None


@dataclass(frozen=True)
class DealDamageBonusIfStadiumInPlayThenDiscardIt(Effect):
    """場にスタジアムがあれば、そのぶんダメージが増え、ワザの後そのスタジアムをトラッシュする
    (イーユイ(sv5a版)の「グラウンドメルト」等)。"""

    base: int
    bonus: int

    def execute(self, ctx: EffectContext) -> None:
        has_stadium = ctx.state.stadium_in_play is not None
        amount = self.base + self.bonus if has_stadium else self.base
        DealDamage(amount).execute(ctx)
        if has_stadium:
            DiscardStadiumInPlay().execute(ctx)


@dataclass(frozen=True)
class DiscardStadiumThenOpponentDiscardChosen(Effect):
    """場に出ているスタジアムをトラッシュし、それができたら相手の手札からcount枚トラッシュする
    (こわいおねえさん(Delinquent)等、実カードテキストに"at random"の指定は無いため、どのカードを
    捨てるかは捨てる側(相手)が選ぶ。相手の手札がcount枚以下ならそのまま全て捨てるので選択不要)。"""

    count: int

    def execute(self, ctx: EffectContext) -> None:
        if ctx.state.stadium_in_play is None or ctx.state.stadium_owner is None:
            return
        owner = ctx.state.player(ctx.state.stadium_owner)
        owner.discard.append(ctx.state.stadium_in_play)
        ctx.log(f"スタジアム「{ctx.state.stadium_in_play}」をトラッシュした")
        ctx.state.stadium_in_play = None
        ctx.state.stadium_owner = None

        opponent = ctx.state.player(ctx.opponent)
        if not opponent.hand:
            return
        if len(opponent.hand) <= self.count:
            n = len(opponent.hand)
            opponent.discard.extend(opponent.hand)
            opponent.hand = []
            ctx.log(f"相手の手札から{n}枚トラッシュした")
            return
        ctx.state.pending_search_choice = PendingSearchChoice(
            player_index=ctx.opponent,
            zone="hand",
            source_indices=list(range(len(opponent.hand))),
            card_ids=list(opponent.hand),
            min_count=self.count,
            max_count=self.count,
            prompt=f"手札から{self.count}枚トラッシュするカードを選ぶ",
            shuffle_after=False,
            all_card_ids=list(opponent.hand),
            destination="discard",
        )


@dataclass(frozen=True)
class AttachEnergyFromHandToSelf(Effect):
    """手札から指定タイプの基本エネルギーを1枚選び自分自身につける(オーガポンexの「みどりのまい」等)。付いたら1枚引く。
    energy_type=Noneならタイプ不問(トルネロス(Tornadus)「Wrapped in Wind」実カードテキスト:
    "Attach a Basic Energy card from your hand to this Pokémon."用)。"""

    energy_type: str | None = None
    draw_if_attached: bool = False

    def execute(self, ctx: EffectContext) -> None:
        if ctx.source_pokemon is None:
            return
        player = _attacker_player(ctx)
        for i, card_id in enumerate(player.hand):
            card = ctx.card_db.get(card_id)
            if card is not None and card.basic_energy_type is not None and (
                self.energy_type is None or card.basic_energy_type == self.energy_type
            ):
                player.hand.pop(i)
                ctx.source_pokemon.attached_energy.append(card_id)
                if self.draw_if_attached:
                    Draw(1).execute(ctx)
                break


@dataclass(frozen=True)
class AttachEnergyFromHandToChosenOwnPokemon(Effect):
    """手札から指定タイプの基本エネルギーを1枚、自分の場のポケモン1匹につける。target_type指定時は
    そのタイプのポケモンのみが対象になる(ガメノデスの「Stone Arms」等)。heal_on_attach>0の場合、
    実際につけられたら対象のダメカンをその分回復する(カミツオロチexの「Ripening Charge」等)。

    対象はctx.target_bench_index経由で既に決まっている前提(engine.legal_actions._ability_needs_target
    がこのクラスを使う特性について、対象ポケモンごとに別々のUseAbilityアクションを用意しているため)。
    以前はここで対象を無視して毎回改めてPendingSearchChoiceを立てており、「カードを押すと対象候補の
    数だけボタンが出た直後に、もう一度同じ対象を選び直す画面が出る」という二重選択になっていた上、
    1回目のボタン群は対象を反映しないため評価値が全て同一になっていた(2026-08-27ユーザー報告で発覚)。"""

    energy_type: str
    target_type: str | None = None
    heal_on_attach: int = 0
    bench_only: bool = False  # True: ベンチのポケモンだけが対象(Excited Turbo)

    def execute(self, ctx: EffectContext) -> None:
        player = _attacker_player(ctx)
        hand_idx = None
        for i, cid in enumerate(player.hand):
            card = ctx.card_db.get(cid)
            if card is not None and card.basic_energy_type == self.energy_type:
                hand_idx = i
                break
        if hand_idx is None:
            return

        def _matches_target_type(mon: PokemonInPlay) -> bool:
            if self.target_type is None:
                return True
            mon_card = ctx.card_db.get(mon.card_id)
            return mon_card is not None and self.target_type in mon_card.types

        target = _resolve_own_target(ctx, player)
        if target is not None and _matches_target_type(target):
            card_id = player.hand.pop(hand_idx)
            target.attached_energy.append(card_id)
            if self.heal_on_attach:
                target.heal(self.heal_on_attach)
            attached_name = ctx.card_db.get(card_id).name if ctx.card_db.get(card_id) else card_id
            target_name = ctx.card_db.get(target.card_id).name if ctx.card_db.get(target.card_id) else target.card_id
            ctx.log(f"{attached_name} を {target_name} につけた")
            return

        # 対象がまだ決まっていない稀な呼び出し元向けの後方互換フォールバック(通常はここに来ない)。
        candidates = []
        if player.active is not None and _matches_target_type(player.active):
            candidates.append((0, player.active))
        for i, mon in enumerate(player.bench):
            if _matches_target_type(mon):
                candidates.append((i + 1, mon))
        if not candidates:
            return
        card_id = player.hand.pop(hand_idx)
        ctx.state.pending_search_choice = PendingSearchChoice(
            player_index=ctx.acting_player,
            zone="own_pokemon_target",
            source_indices=[slot for slot, _ in candidates],
            card_ids=[mon.card_id for _, mon in candidates],
            min_count=1,
            max_count=1,
            prompt=f"{ctx.card_db.get(card_id).name if ctx.card_db.get(card_id) else card_id}をつけるポケモンを選ぶ",
            shuffle_after=False,
            all_card_ids=[mon.card_id for _, mon in candidates],
            custom_data={
                "mode": "attach_specific_card_to_target",
                "card_id": card_id,
                "heal_amount": self.heal_on_attach,
            },
        )


@dataclass(frozen=True)
class DamagePerBothActiveEnergyCount(Effect):
    """自分と相手、両方のバトルポケモンについているエネルギーの合計数ぶんダメージが上乗せされる。
    メガニウムの特性「Wild Growth」実カードテキスト("Each Basic Grass Energy attached to all of
    your Pokemon provides GrassGrass Energy")により、自分の場にメガニウムがいれば自分側の基本
    くさエネルギーは2枚ぶんとして数える(相手側は相手自身のWild Growthの有無で判定、2026-08-23
    ユーザー報告で発覚。以前は単純なlen()で数えておりWild Growthが一切反映されていなかった)。
    ignore_weakness_resistance=True指定時、弱点・抵抗力を無視する(タプ・レレGXの「エナジードライブ」等)。"""

    base: int
    per_energy: int
    ignore_weakness_resistance: bool = False
    ignore_weakness_only: bool = False  # 弱点だけを無視する(Psychic Infinity)

    def execute(self, ctx: EffectContext) -> None:
        if ctx.source_pokemon is None:
            return
        attacker_player = _attacker_player(ctx)
        defender_player, defender = _defender(ctx)
        count = total_points(
            ctx.card_db, ctx.source_pokemon.attached_energy, ctx.source_pokemon.card_id,
            double_grass=wild_growth_active(attacker_player),
        )
        if defender is not None:
            count += total_points(
                ctx.card_db, defender.attached_energy, defender.card_id,
                double_grass=wild_growth_active(defender_player),
            )
        amount = self.base + self.per_energy * count
        if self.ignore_weakness_resistance:
            DealDamageIgnoringWeaknessResistance(amount).execute(ctx)
        elif self.ignore_weakness_only:
            DealDamageIgnoringWeaknessOnly(amount).execute(ctx)
        else:
            DealDamage(amount).execute(ctx)


@dataclass(frozen=True)
class DamagePerSelfEnergyToChosenOpponent(Effect):
    """自分についているエネルギーの数だけ、選んだ相手のポケモンにダメージ(ベンチには弱点・抵抗力を計算しない)。
    energy_type指定時はそのタイプの基本エネルギーのみを数える(モウカザル(Seaking)の「Hydro Jet」
    実カードテキスト: "for each Water Energy attached to this Pokémon"用)。"""

    per_energy: int
    energy_type: str | None = None

    def execute(self, ctx: EffectContext) -> None:
        if ctx.source_pokemon is None:
            return
        if self.energy_type is None:
            count = len(ctx.source_pokemon.attached_energy)
        else:
            count = sum(
                1
                for eid in ctx.source_pokemon.attached_energy
                if (c := ctx.card_db.get(eid)) is not None and c.basic_energy_type == self.energy_type
            )
        DealDamageToChosenOpponentPokemon(self.per_energy * count).execute(ctx)


@dataclass(frozen=True)
class DamagePerOwnAttachedEnergyCount(Effect):
    """自分についているエネルギーの数ぶんダメージ(マーシャドーGXの「Peerless Hundred Blows-GX」、
    ミュウツーGXの「Full Burst」等)。basic_only=Trueなら基本エネルギーのみを数える。"""

    per_energy: int
    basic_only: bool = False
    energy_type: str | None = None  # 指定時はその基本タイプのエネルギーのみを数える(メガライボルトex(Mega Zeraora ex)「Thunderous Fist」等)

    def execute(self, ctx: EffectContext) -> None:
        if ctx.source_pokemon is None:
            return
        if self.energy_type is not None:
            count = sum(
                1
                for e in ctx.source_pokemon.attached_energy
                if (card := ctx.card_db.get(e)) is not None and card.basic_energy_type == self.energy_type
            )
        elif self.basic_only:
            count = sum(
                1
                for e in ctx.source_pokemon.attached_energy
                if (card := ctx.card_db.get(e)) is not None and card.basic_energy_type is not None
            )
        else:
            count = len(ctx.source_pokemon.attached_energy)
        DealDamage(self.per_energy * count).execute(ctx)


@dataclass(frozen=True)
class DamagePerOpponentActiveEnergyCount(Effect):
    """相手のバトルポケモンについているエネルギーの数ぶん追加ダメージ(オーラン(Oranguru)の「Psychic」等)。"""

    base: int
    per_energy: int

    def execute(self, ctx: EffectContext) -> None:
        _, defender = _defender(ctx)
        count = len(defender.attached_energy) if defender else 0
        DealDamage(self.base + self.per_energy * count).execute(ctx)


@dataclass(frozen=True)
class DamagePerAllPokemonEnergyCountAcrossBoard(Effect):
    """場に出ている全ポケモン(両プレイヤー)についているエネルギーの合計数ぶんダメージ
    (ルナアーラ◇の「サイコストーム」等)。"""

    per_energy: int

    def execute(self, ctx: EffectContext) -> None:
        if ctx.source_pokemon is None:
            return
        count = sum(
            len(mon.attached_energy)
            for player in ctx.state.players
            for mon in player.all_pokemon_in_play()
        )
        DealDamage(self.per_energy * count).execute(ctx)


@dataclass(frozen=True)
class DamagePerOpponentAllPokemonEnergyCount(Effect):
    """相手の場に出ている全ポケモン(バトル場+ベンチ)についているエネルギーの合計数ぶんダメージ
    (カプ・コケコGXの「Tapu Thunder-GX」等)。"""

    per_energy: int

    def execute(self, ctx: EffectContext) -> None:
        if ctx.source_pokemon is None:
            return
        opponent = ctx.state.player(ctx.opponent)
        count = sum(len(mon.attached_energy) for mon in opponent.all_pokemon_in_play())
        DealDamage(self.per_energy * count).execute(ctx)


@dataclass(frozen=True)
class ReturnOwnEnergyToHand(Effect):
    """自分についているエネルギーを指定数、手札に戻す。"""

    count: int = 1

    def execute(self, ctx: EffectContext) -> None:
        if ctx.source_pokemon is None:
            return
        player = _attacker_player(ctx)
        moved = ctx.source_pokemon.attached_energy[: self.count]
        ctx.source_pokemon.attached_energy = ctx.source_pokemon.attached_energy[self.count :]
        player.hand.extend(moved)


@dataclass(frozen=True)
class ReturnOwnToolToHand(Effect):
    """自分についているどうぐを(あれば)手札に戻す(ゲノセクトEX(Fates Collide版)の「Drive Change」等)。"""

    def execute(self, ctx: EffectContext) -> None:
        if ctx.source_pokemon is None or ctx.source_pokemon.attached_tool is None:
            return
        player = _attacker_player(ctx)
        player.hand.append(ctx.source_pokemon.attached_tool)
        ctx.source_pokemon.attached_tool = None
        ctx.source_pokemon.attached_tool_owner = None


@dataclass(frozen=True)
class BothPlayersShuffleHandAndDrawFixed(Effect):
    """両方のプレイヤーが手札を山札に戻してシャッフルし、固定枚数を引く(ジャッジ等)。"""

    count: int

    def execute(self, ctx: EffectContext) -> None:
        for player_index in (ctx.acting_player, ctx.opponent):
            player = ctx.state.player(player_index)
            player.deck.extend(player.hand)
            player.hand = []
            ctx.rng.shuffle(player.deck)
            for _ in range(self.count):
                if not player.deck:
                    break
                player.hand.append(player.deck.pop(0))
        ctx.state.player(ctx.acting_player).known_opponent_hand = []
        ctx.state.player(ctx.opponent).known_opponent_hand = []


@dataclass(frozen=True)
class ReturnOwnBenchedPokemonAndAttachedToHand(Effect):
    """自分のたねポケモン1匹(バトル場/ベンチどちらでも指定可)を、ついているカードごと手札に戻す
    (トラッシュされない、ペニー等)。呼び出し側(legal_actions)でたねポケモン限定をゲートする。"""

    def execute(self, ctx: EffectContext) -> None:
        player = _attacker_player(ctx)
        if ctx.target_bench_index is None:
            target = player.active
            if target is None:
                return
            player.active = None
        else:
            if not (0 <= ctx.target_bench_index < len(player.bench)):
                return
            target = player.bench.pop(ctx.target_bench_index)
        player.hand.extend(target.evolution_history)
        player.hand.append(target.card_id)
        player.hand.extend(target.attached_energy)
        if target.attached_tool:
            player.hand.append(target.attached_tool)


@dataclass(frozen=True)
class FlipCoinThenDiscardOpponentEnergy(Effect):
    """コインを1回投げ、オモテなら相手の場のポケモン1匹(プレイ時にctx.target_bench_indexで選択済み、
    バトル場/ベンチどちらでも可)についているエネルギーを1枚トラッシュする(クラッシュハンマー実カード
    テキスト: "discard an Energy from 1 of your opponent's Pokémon"。対象はengine.legal_actions側で
    エネルギーがついているポケモンのみに絞り込み済み)。"""

    def execute(self, ctx: EffectContext) -> None:
        heads = ctx.rng.random() < 0.5
        ctx.log("コイン: オモテ" if heads else "コイン: ウラ")
        if not heads:
            return
        opponent = ctx.state.player(ctx.opponent)
        target = _resolve_opponent_target(ctx, opponent)
        if target is None or not target.attached_energy:
            return
        energy_id = target.attached_energy.pop(0)
        opponent.discard.append(energy_id)
        ctx.log("相手のポケモンのエネルギーを1枚トラッシュした")


@dataclass(frozen=True)
class DiscardHandCardToLostZone(Effect):
    """手札からカードを指定数、ロストゾーンに送る(コストとして自動選択する簡易版)。"""

    count: int = 1

    def execute(self, ctx: EffectContext) -> None:
        player = _attacker_player(ctx)
        for _ in range(min(self.count, len(player.hand))):
            player.lost_zone.append(player.hand.pop(0))


@dataclass(frozen=True)
class ChooseHandCardToLostZone(Effect):
    """手札からカードをプレイヤーに選ばせてロストゾーンに送る(ロストバキュームの使用コスト:
    「手札の他の1枚をロストゾーンに置く」)。legal_actions側で手札枚数(自分自身を除き1枚以上)を
    ゲート済みなので、必ず1枚選べる前提。"""

    count: int = 1

    def execute(self, ctx: EffectContext) -> None:
        player = _attacker_player(ctx)
        _trigger_search_choice(
            ctx, player, "hand", lambda c: True, self.count,
            "ロストゾーンに送る手札を選ぶ", shuffle_after=False, destination="lost_zone", min_count=self.count,
        )


@dataclass(frozen=True)
class SendStadiumToLostZone(Effect):
    """場に出ているスタジアムを(あれば)ロストゾーンに送る(ロストバキュームの効果本体)。"""

    def execute(self, ctx: EffectContext) -> None:
        if ctx.state.stadium_in_play is None or ctx.state.stadium_owner is None:
            return
        owner = ctx.state.player(ctx.state.stadium_owner)
        owner.lost_zone.append(ctx.state.stadium_in_play)
        ctx.log(f"スタジアム「{ctx.state.stadium_in_play}」をロストゾーンに送った")
        ctx.state.stadium_in_play = None
        ctx.state.stadium_owner = None


@dataclass(frozen=True)
class KnockOutOpponentActiveThenSelfDamage(Effect):
    """相手のバトルポケモンをきぜつさせ、成功したら自分自身にもダメカンをのせる(あばれるつき「じたばたおおえぐり」等)。"""

    self_damage: int

    def execute(self, ctx: EffectContext) -> None:
        if ctx.source_pokemon is None:
            return
        _, defender = _defender(ctx)
        if defender is None:
            return
        if not (_defender_is_shielded(ctx, defender) or _defender_blocks_non_damage_effects(ctx, defender)):
            # 即座にきぜつさせる=ワザのダメージ計算を経ない「効果」のため、ばけがくれ等でブロックされうる
            defender.damage = 9999
        from effects.era_trainers import era_self_damage_prevented

        if not era_self_damage_prevented(ctx.state, ctx.source_pokemon):
            ctx.source_pokemon.damage += self.self_damage
        ctx.log(f"{ctx.source_card_id} は相手のバトルポケモンをきぜつさせ、自分自身にも{self.self_damage}ダメージ")


@dataclass(frozen=True)
class SwitchOutOpponentActiveOpponentChoosesThenDiscardSelf(Effect):
    """相手のバトルポケモンをベンチに戻す(新しいバトルポケモンは相手が選ぶ)。そうしたら、このポケモンとついている
    カードをすべてトラッシュする(テツノツツミの特性「Hyper Blower」実カードテキスト: "switch out your opponent's
    Active Pokémon to the Bench. (Your opponent chooses the new Active Pokémon.) If you do, discard this Pokémon and
    all attached cards.")。以前は入れ替え先を自分が選ぶ実装になっていた誤りを訂正(2026-10-06)。相手のベンチが
    無ければ入れ替えられないので、このポケモンもトラッシュしない。"""

    def execute(self, ctx: EffectContext) -> None:
        opponent = ctx.state.player(ctx.opponent)
        if not opponent.bench:
            return
        ForceOpponentSwitchOpponentChooses().execute(ctx)
        DiscardSelfFromBench().execute(ctx)


@dataclass(frozen=True)
class BlockOpponentActiveAbilitiesThisTurn(Effect):
    """この番の終わりまで、相手のバトルポケモンは特性を持たない(その番にバトル場に出たポケモンも含む)
    (キャンセリングコロン実カードテキスト: "Until the end of your turn, your opponent's Active Pokémon has no
    Abilities. (This includes Pokémon that come into play during that turn.)")。以前は「相手の次の番の終わりまで」
    両者の特性を封じる長めの簡略化だった(2026-10-06訂正)。"""

    def execute(self, ctx: EffectContext) -> None:
        ctx.state.player(ctx.opponent).active_abilities_blocked_on_turn = ctx.state.turn_number


@dataclass(frozen=True)
class RemoveAllAttackEffectsBothSides(Effect):
    """おたがいのプレイヤーとそのポケモンにかかっているワザの効果をすべて取り除く(ポケモンレンジャー実カードテキスト:
    "Remove all effects of attacks on each player and his or her Pokémon.")。公式の裁定により、どく・やけど・ねむり・
    マヒ・こんらんといった特殊状態は「ワザの効果」には含まれず、取り除かれない(以前は特殊状態だけを治す誤った実装だった、
    2026-10-06訂正)。「次の番、にげられない/ワザが使えない/グッズが使えない/ダメージを受けない」といった時限効果を解除する。"""

    def execute(self, ctx: EffectContext) -> None:
        for player in ctx.state.players:
            player.attack_locked_until_turn = 0
            player.items_locked_until_turn = 0
            player.poisoned_cant_retreat_until_turn = 0
            for mon in player.all_pokemon_in_play():
                mon.locked_attack_name = None
                mon.locked_attack_until_turn = 0
                mon.shielded_until_turn = 0
                mon.damage_reduction_amount = 0
                mon.damage_reduction_until_turn = 0
                mon.attack_disabled_until_turn = 0
                mon.attack_coinflip_until_turn = 0
                mon.attack_bonus_until_turn = 0
                mon.effect_shield_until_turn = 0
                mon.damage_coin_shield_until_turn = 0
                mon.retaliate_equal_damage = False
                mon.no_energy_attach_until_turn = 0
                mon.no_evolve_until_turn = 0
                mon.incoming_damage_bonus_until_turn = 0
                mon.abilities_off_until_turn = 0
                mon.no_weakness_until_turn = 0
                mon.damage_prevent_threshold_until_turn = 0
                mon.retreat_disabled_until_turn = 0
                mon.destiny_bond_until_turn = 0
                mon.retaliate_on_damaged_until_turn = 0
                mon.retaliate_on_damaged_counters = 0
                mon.damage_immunity_until_turn = 0
                mon.damage_immunity_scope = ""
                mon.damage_debuff_until_turn = 0
                mon.outgoing_damage_debuff_until_turn = 0
                mon.outgoing_damage_debuff_amount = 0
                if mon.no_prize_on_ko_until_turn < 10**8:  # みがわりロボの恒久的なシールドは除く
                    mon.no_prize_on_ko_until_turn = 0
        ctx.log("おたがいのワザの効果をすべて取り除いた")


@dataclass(frozen=True)
class DiscardStadiumInPlayIfChosen(Effect):
    """場のスタジアムをトラッシュしてもよい(ポケモンexのピジョットexの「Blustery Wind」実カードテキスト:
    "You may discard a Stadium in play.")。トラッシュするかどうかはワザを選ぶときに決める
    (target_bench_index=0なら捨てる、Noneなら捨てない。DamageBonusIfStadiumDiscardedと同じ仕組み)。"""

    def execute(self, ctx: EffectContext) -> None:
        if ctx.target_bench_index != 0:
            return
        DiscardStadiumInPlay().execute(ctx)


@dataclass(frozen=True)
class DamageBonusIfStadiumDiscarded(Effect):
    """スタジアムをトラッシュしてもよく、そうしたら追加ダメージ(あばれるつき「Calamity Storm」実カードテキスト:
    "You may discard a Stadium in play. If you do, this attack does 120 more damage.")。
    トラッシュするかどうかはワザを選ぶときに決める: engine.legal_actionsは「トラッシュしない」(target_bench_index=None)と
    「トラッシュする」(target_bench_index=0)の2通りのAttackを出す(場にスタジアムが無ければ前者のみ)。以前は
    スタジアムがあれば必ずトラッシュしていた(してもよい、を無視していた)。"""

    base: int
    bonus: int

    def execute(self, ctx: EffectContext) -> None:
        if ctx.target_bench_index == 0 and ctx.state.stadium_in_play is not None and ctx.state.stadium_owner is not None:
            ctx.state.player(ctx.state.stadium_owner).discard.append(ctx.state.stadium_in_play)
            ctx.log(f"スタジアム「{ctx.state.stadium_in_play}」をトラッシュした")
            ctx.state.stadium_in_play = None
            ctx.state.stadium_owner = None
            DealDamage(self.base + self.bonus).execute(ctx)
        else:
            DealDamage(self.base).execute(ctx)


@dataclass(frozen=True)
class DamageBonusWithOptionalEnergyDiscard(Effect):
    """このポケモンについているエネルギーを捨ててもよく、そうしたら追加ダメージ(メタグロスの「Metallic Hammer」実カード
    テキスト: "You may discard 3 Metal Energy from this Pokémon and have this attack do 150 more damage."、メガライボルトexの
    「Riotous Blasting」: "You may discard all Energy from this Pokémon and have this attack do 130 more damage.")。
    捨てるかどうかはワザを選ぶときに決める: engine.legal_actionsは「捨てない」(target_bench_index=None)と「捨てる」
    (target_bench_index=0)の2通りのAttackを出す。捨てる場合、energy_type指定時はそのタイプの基本エネルギーを最大max_count枚
    (ついている分だけ、1枚も無くても追加ダメージは入る: 公式FAQ)、energy_type=Noneならついているエネルギーを全て捨てる。
    基本ダメージと追加ダメージは1回のダメージ計算にまとめる(以前はワザの後の「してもよい」で別のダメージ処理として与えていたため、
    抵抗力・軽減・攻撃側ボーナスが2回かかっていた、2026-10-06訂正)。"""

    base: int
    bonus: int
    energy_type: str | None = None
    max_count: int = 3

    def execute(self, ctx: EffectContext) -> None:
        if ctx.target_bench_index != 0 or ctx.source_pokemon is None:
            DealDamage(self.base).execute(ctx)
            return
        attached = ctx.source_pokemon.attached_energy
        if self.energy_type is None:
            discard_ids = list(attached)
        else:
            discard_ids = [
                e for e in attached
                if (card := ctx.card_db.get(e)) is not None and card.basic_energy_type == self.energy_type
            ][: self.max_count]
        for energy_id in discard_ids:
            attached.remove(energy_id)
        _attacker_player(ctx).discard.extend(discard_ids)
        ctx.log(f"エネルギーを{len(discard_ids)}枚トラッシュして追加ダメージ")
        DealDamage(self.base + self.bonus).execute(ctx)


@dataclass(frozen=True)
class DefenderMustFlipCoinToAttackNextTurn(Effect):
    """相手の次の番、このワザを受けたポケモンがワザを使おうとしたら、コインを投げ、ウラならそのワザは失敗する
    (実カードテキスト: "If the Defending Pokémon tries to attack during your opponent's next turn, your opponent flips a
    coin. If tails, that attack does nothing.")。判定はengine.rules_engine._handle_attack側で行う。"""

    def execute(self, ctx: EffectContext) -> None:
        _, defender = _defender(ctx)
        if defender is None:
            return
        opponent = ctx.state.player(ctx.opponent)
        defender.attack_coinflip_until_turn = opponent.turns_taken + 1


@dataclass(frozen=True)
class DealDamageToChosenOpponentBenchMulti(Effect):
    """相手のベンチポケモンを複数体(最大count体、ベンチにいる数がそれより少なければその数だけ)選び、それぞれに同じ量の
    ダメージ(弱点・抵抗力は計算しない。"Does 20 damage to 2 of your opponent's Benched Pokémon.")。"""

    count: int
    amount: int

    def execute(self, ctx: EffectContext) -> None:
        if ctx.source_pokemon is None:
            return
        opponent = ctx.state.player(ctx.opponent)
        candidates = [(i + 1, mon) for i, mon in enumerate(opponent.bench)]
        if not candidates:
            return
        n = min(self.count, len(candidates))
        ctx.state.pending_search_choice = PendingSearchChoice(
            player_index=ctx.acting_player,
            zone="opponent_pokemon_target",
            source_indices=[slot for slot, _ in candidates],
            card_ids=[mon.card_id for _, mon in candidates],
            min_count=n,
            max_count=n,
            prompt=f"ダメージを与える相手のベンチポケモンを{n}体選ぶ",
            shuffle_after=False,
            all_card_ids=[mon.card_id for _, mon in candidates],
            cont_source_pokemon=ctx.source_pokemon,
            cont_source_card_id=ctx.source_card_id,
            custom_data={"mode": "damage_multi", "amount": self.amount},
        )


@dataclass(frozen=True)
class DamageBonusWithOptionalSelfDamage(Effect):
    """自分にダメージを受けてもよく、そうしたら追加ダメージ("You may do 20 more damage. If you do, this Pokémon does 20
    damage to itself.")。受けるかどうかはワザを選ぶときに決める: engine.legal_actionsは「受けない」(target_bench_index=
    None)と「受ける」(=0)の2通りのAttackを出す(DamageBonusWithOptionalEnergyDiscardと同じ仕組み)。"""

    base: int
    bonus: int
    self_damage: int

    def execute(self, ctx: EffectContext) -> None:
        if ctx.target_bench_index != 0 or ctx.source_pokemon is None:
            DealDamage(self.base).execute(ctx)
            return
        DealDamage(self.base + self.bonus).execute(ctx)
        from effects.era_trainers import era_self_damage_prevented

        if not era_self_damage_prevented(ctx.state, ctx.source_pokemon):
            ctx.source_pokemon.damage += self.self_damage
        ctx.log(f"自分に{self.self_damage}ダメージ")


# 「してもよい」を選んだ版のワザ(Attack(i, 0))を別の選択肢として出す効果(legal_actions/display/借用ワザの選択肢が共通で参照する)
OPTIONAL_VARIANT_BONUS_EFFECTS = (DamageBonusWithOptionalEnergyDiscard, DamageBonusWithOptionalSelfDamage)


def has_optional_variant(script) -> bool:
    """スクリプトに「してもよい」を選んだ版のワザ(Attack(i, 0))を別の選択肢として出す効果が含まれるか。
    effects.era_primitivesの効果は、クラス属性optional_variant=Trueで表す。"""
    return any(isinstance(e, OPTIONAL_VARIANT_BONUS_EFFECTS) or getattr(e, "optional_variant", False) for e in script)


@dataclass(frozen=True)
class DamagePerOwnPokemonWithAttackName(Effect):
    """自分の場(バトル+ベンチ)の、指定した名前のワザを持つポケモン1匹につきper_pokemonダメージ("Does 20 damage times the
    number of your Pokémon that have the Round attack.")。"""

    per_pokemon: int
    attack_name: str

    def execute(self, ctx: EffectContext) -> None:
        player = _attacker_player(ctx)
        count = sum(
            1
            for mon in player.all_pokemon_in_play()
            if (c := ctx.card_db.get(mon.card_id)) is not None and any(a.name == self.attack_name for a in c.attacks)
        )
        DealDamage(self.per_pokemon * count).execute(ctx)


@dataclass(frozen=True)
class RevealOpponentHand(Effect):
    """相手の手札を公開させる("Your opponent reveals his or her hand.")。以後このプレイヤーの記憶として保持する。"""

    def execute(self, ctx: EffectContext) -> None:
        opponent = ctx.state.player(ctx.opponent)
        ctx.state.player(ctx.acting_player).known_opponent_hand = list(opponent.hand)
        ctx.reveal("相手の手札", list(opponent.hand))


@dataclass(frozen=True)
class DamagePerAncientCardInDiscard(Effect):
    """自分のトラッシュにある「古代」カードの枚数ぶんダメージが上乗せされる。"""

    base: int
    per_card: int

    def execute(self, ctx: EffectContext) -> None:
        player = _attacker_player(ctx)
        count = sum(
            1
            for cid in player.discard
            if ctx.card_db.get(cid) and "Ancient" in ctx.card_db.get(cid).subtypes
        )
        DealDamage(self.base + self.per_card * count).execute(ctx)


@dataclass(frozen=True)
class DamagePerOwnDiscardEnergyOfTypeCount(Effect):
    """自分のトラッシュにある指定タイプの基本エネルギーの枚数ぶんダメージ(フレアリザードンGXの
    「Power Burner-GX」等)。"""

    per_energy: int
    energy_type: str

    def execute(self, ctx: EffectContext) -> None:
        player = _attacker_player(ctx)
        count = sum(
            1
            for cid in player.discard
            if (c := ctx.card_db.get(cid)) is not None and c.basic_energy_type == self.energy_type
        )
        DealDamage(self.per_energy * count).execute(ctx)


@dataclass(frozen=True)
class DamagePerOwnDiscardBasicEnergyCountThenShuffleIntoDeck(Effect):
    """自分のトラッシュにある基本エネルギー(タイプ問わず)の枚数ぶんダメージを与え、その後
    それらのカードを山札にシャッフルして戻す(ビクティニ(プリズムスター)の「Infinity」実カード
    テキスト: "This attack does 20 damage for each basic Energy card in your discard pile. Then,
    shuffle those cards into your deck."用)。"""

    per_energy: int

    def execute(self, ctx: EffectContext) -> None:
        player = _attacker_player(ctx)
        matching = [
            cid for cid in player.discard
            if (c := ctx.card_db.get(cid)) is not None and c.is_energy and not c.is_special_energy
        ]
        DealDamage(self.per_energy * len(matching)).execute(ctx)
        if not matching:
            return
        remaining = list(player.discard)
        for cid in matching:
            remaining.remove(cid)
        player.discard = remaining
        player.deck.extend(matching)
        ctx.rng.shuffle(player.deck)
        ctx.log(f"トラッシュの基本エネルギー{len(matching)}枚を山札にシャッフルして戻した")


@dataclass(frozen=True)
class ChooseOpponentDiscardCardsToLostZone(Effect):
    """相手のトラッシュから好きなカードを最大count枚選んでロストゾーンに送る(キリンリキの
    「Get Lost」等)。"""

    count: int = 2

    def execute(self, ctx: EffectContext) -> None:
        opponent = ctx.state.player(ctx.opponent)
        if not opponent.discard:
            return
        n = min(self.count, len(opponent.discard))
        ctx.state.pending_search_choice = PendingSearchChoice(
            player_index=ctx.acting_player,
            zone="opponent_discard",
            source_indices=list(range(len(opponent.discard))),
            card_ids=list(opponent.discard),
            min_count=n,
            max_count=n,
            prompt=f"相手のトラッシュからロストゾーンに送るカードを{n}枚選ぶ",
            shuffle_after=False,
            all_card_ids=list(opponent.discard),
            destination="lost_zone",
            custom_data={"mode": "opponent_discard_to_lost_zone"},
        )


@dataclass(frozen=True)
class OpponentDiscardHandDownTo(Effect):
    """相手が、手札がcount枚になるまで(相手自身が選んで)手札をトラッシュする(クセロシキのたくらみ
    "Your opponent discards cards from their hand until they have 3 cards in their hand"等)。
    どのカードを残すかは相手プレイヤー自身の選択(PendingSearchChoice.player_indexをctx.opponentに
    することで、相手側にResolveSearchChoiceを委ねる)。"""

    count: int

    def execute(self, ctx: EffectContext) -> None:
        opponent = ctx.state.player(ctx.opponent)
        discard_amount = len(opponent.hand) - self.count
        if discard_amount <= 0:
            ctx.log(f"相手の手札は既に{self.count}枚以下なのでトラッシュしなかった")
            return
        ctx.state.pending_search_choice = PendingSearchChoice(
            player_index=ctx.opponent,
            zone="hand",
            source_indices=list(range(len(opponent.hand))),
            card_ids=list(opponent.hand),
            min_count=discard_amount,
            max_count=discard_amount,
            prompt=f"手札が{self.count}枚になるまでトラッシュする",
            shuffle_after=False,
            all_card_ids=list(opponent.hand),
            destination="discard",
        )


@dataclass(frozen=True)
class DiscardAllEnergyFromBothActivePokemon(Effect):
    """自分・相手両方のバトルポケモンについているエネルギーを全てトラッシュする(フリーザーGXの
    「Cold Crush-GX」等)。"""

    def execute(self, ctx: EffectContext) -> None:
        player = _attacker_player(ctx)
        opponent = ctx.state.player(ctx.opponent)
        if player.active is not None:
            player.discard.extend(player.active.attached_energy)
            player.active.attached_energy = []
        if opponent.active is not None:
            opponent.discard.extend(opponent.active.attached_energy)
            opponent.active.attached_energy = []


def _attach_discard_energy_freely(
    ctx: EffectContext,
    remaining_count: int,
    energy_type: str | None = None,
    then_end_turn: bool = False,
    target_type: str | None = None,
    optional: bool = False,
) -> None:
    """トラッシュの基本エネルギー(energy_type指定時はそのタイプ限定)を自分のポケモンに「好きなように」
    1枚ずつ分配してつける(ライボルトGXの「Full Voltage-GX」、ルナアーラ◇の「Full Moon Star」、
    オリジンパルキアVSTARの「Star Portal」等)。1枚つけるたびに対象を選び直せるため、同じポケモンに
    複数枚まとめてつけることも、複数のポケモンに分けてつけることもできる。target_type指定時はその
    タイプのポケモンのみが対象(「自分の水ポケモンに」等)。optional=Trueなら「Nまで」の任意枚数
    (途中でこれ以上つけないことも選べる、0枚選択=打ち切り)。"""
    if remaining_count <= 0:
        return
    player = _attacker_player(ctx)
    eligible_indices = [
        i for i, cid in enumerate(player.discard)
        if (c := ctx.card_db.get(cid)) is not None and c.is_energy and not c.is_special_energy
        and (energy_type is None or c.basic_energy_type == energy_type)
    ]
    if not eligible_indices:
        return
    candidates = []
    if player.active is not None and (target_type is None or _pokemon_has_type(ctx.card_db, player.active, target_type)):
        candidates.append((0, player.active))
    for i, mon in enumerate(player.bench):
        if target_type is None or _pokemon_has_type(ctx.card_db, mon, target_type):
            candidates.append((i + 1, mon))
    if not candidates:
        return
    ctx.state.pending_search_choice = PendingSearchChoice(
        player_index=ctx.acting_player,
        zone="own_pokemon_target",
        source_indices=[slot for slot, _ in candidates],
        card_ids=[mon.card_id for _, mon in candidates],
        min_count=0 if optional else 1,
        max_count=1,
        prompt=f"エネルギーをつける自分のポケモンを選ぶ(残り{remaining_count}枚まで)",
        shuffle_after=False,
        all_card_ids=[mon.card_id for _, mon in candidates],
        cont_source_pokemon=ctx.source_pokemon,
        cont_source_card_id=ctx.source_card_id,
        then_end_turn=then_end_turn,
        custom_data={
            "mode": "attach_discard_energy_freely_pick_target",
            "remaining": remaining_count,
            "energy_type": energy_type,
            "then_end_turn": then_end_turn,
            "target_type": target_type,
            "optional": optional,
        },
    )


def _pokemon_has_type(card_db: CardDatabase, mon: PokemonInPlay, pokemon_type: str) -> bool:
    card = card_db.get(mon.card_id)
    return card is not None and pokemon_type in card.types


@dataclass(frozen=True)
class AttachDiscardEnergyFreelyToOwnPokemon(Effect):
    """トラッシュから基本エネルギーを最大count枚、自分のポケモンに好きなように(1匹にまとめても、
    複数匹に分けてもよい)つける(ライボルトGXの実カードテキスト: "Attach N basic Energy cards
    from your discard pile to your Pokémon in any way you like."、オリジンパルキアVSTARの
    「Star Portal」実カードテキスト: "you may attach up to 3 Water Energy cards ... to your
    Water Pokémon in any way you like."も energy_type/target_type/optional で対応)。"""

    count: int
    energy_type: str | None = None
    target_type: str | None = None
    optional: bool = False

    def execute(self, ctx: EffectContext) -> None:
        _attach_discard_energy_freely(
            ctx, self.count, energy_type=self.energy_type, target_type=self.target_type, optional=self.optional
        )


@dataclass(frozen=True)
class SwitchActiveWithBenchThenPoisonSelf(Effect):
    """自分のベンチポケモン1匹をバトル場と入れ替え、新しいバトルポケモンをどく状態にする(モモワロウex
    「しはいのくさり」実カードテキスト: "you may switch 1 of your Benched Darkness Pokémon, except
    any Pecharunt ex, with your Active Pokémon. If you do, the new Active Pokémon is now Poisoned."
    等)。required_type/exclude_card_idはengine.legal_actions側で対象のベンチ候補を絞り込むために
    読まれるだけで、execute自体は「既に絞り込まれた正当な対象が選ばれている」前提でよい
    (他の対象限定系Effectと同じ設計)。"""

    required_type: str | None = None  # 対象のポケモンタイプ限定(例: モモワロウexは悪タイプのみ)
    exclude_card_id: str | None = None  # 対象から除外するカードID(例: モモワロウex自身は選べない)

    def execute(self, ctx: EffectContext) -> None:
        player = _attacker_player(ctx)
        if ctx.target_bench_index is None or ctx.target_bench_index >= len(player.bench):
            return
        new_active = player.bench.pop(ctx.target_bench_index)
        if player.active is not None:
            player.active.status.clear_all()
            player.bench.append(player.active)
        new_active.status.clear_all()
        new_active.status.poisoned = True
        player.active = new_active
        ctx.log("ベンチのポケモンをバトル場に出し、どく状態にした")


@dataclass(frozen=True)
class ShuffleSupportersFromDiscardIntoDeck(Effect):
    """トラッシュからサポートを最大N枚まで選び、手札を経由せず山札に戻す(ともだちてちょう/パソコン等)。
    実カードは"up to N"なので、対象がN枚を超えて複数あればどれを戻すかプレイヤーが選ぶ
    (以前は先頭からN枚を機械的に選んでいたv1簡略版だった)。"""

    count: int

    def execute(self, ctx: EffectContext) -> None:
        player = _attacker_player(ctx)

        def matches(card):
            return card is not None and card.is_supporter

        _trigger_search_choice(
            ctx, player, "discard", matches, self.count, "トラッシュから山札に戻すサポートを選ぶ",
            shuffle_after=True, destination="deck",
        )


@dataclass(frozen=True)
class ShuffleSelfIntoDeck(Effect):
    """自分自身をついているカードごと山札に戻してシャッフルする(アクアリターン/ノココッチの
    「Run Away Draw」等)。ワザ(バトル場限定で発動)からはバトル場にいる前提で使われるが、
    ノココッチの「Run Away Draw」のような特性はベンチにいる状態でも発動できる実カードテキストの
    ため、バトル場・ベンチどちらの場合も正しく処理する。バトル場の場合のみ新アクティブ選択が必要
    (ベンチが無ければバトル場は空のままにできないため何もしない)。"""

    def execute(self, ctx: EffectContext) -> None:
        if ctx.source_pokemon is None:
            return
        player = _attacker_player(ctx)
        if player.active is ctx.source_pokemon:
            if not player.bench:
                return
            mon = player.active
            player.active = None
            player.deck.extend(mon.evolution_history)
            player.deck.append(mon.card_id)
            player.deck.extend(mon.attached_energy)
            if mon.attached_tool:
                player.deck.append(mon.attached_tool)
            ctx.rng.shuffle(player.deck)
            ctx.state.pending_active_choice = [ctx.acting_player]
            ctx.state.then_after_choice = "continue"
        elif ctx.source_pokemon in player.bench:
            mon = ctx.source_pokemon
            player.bench.remove(mon)
            player.deck.extend(mon.evolution_history)
            player.deck.append(mon.card_id)
            player.deck.extend(mon.attached_energy)
            if mon.attached_tool:
                player.deck.append(mon.attached_tool)
            ctx.rng.shuffle(player.deck)


@dataclass(frozen=True)
class DrawThenShuffleSelfIntoDeckIfDrew(Effect):
    """count枚まで引き、実際に1枚でも引けた場合のみ自分自身をついているカードごと山札に戻して
    シャッフルする(ノココッチの「Run Away Draw」: "Once during your turn, you may draw 3 cards.
    If you drew any cards in this way, shuffle this Pokemon and all attached cards into your
    deck."。山札が0枚で1枚も引けなかった場合はシャッフルしない、という条件付き)。"""

    count: int

    def execute(self, ctx: EffectContext) -> None:
        player = _attacker_player(ctx)
        drew_any = bool(player.deck)
        for _ in range(self.count):
            if not player.deck:
                break
            player.hand.append(player.deck.pop(0))
        if drew_any:
            ShuffleSelfIntoDeck().execute(ctx)


@dataclass(frozen=True)
class DiscardSelfFromBench(Effect):
    """自分自身(ベンチにいる場合のみ)をついているカードごとトラッシュする(パラボギアの「ハイパーブロワー」等)。"""

    def execute(self, ctx: EffectContext) -> None:
        if ctx.source_pokemon is None:
            return
        player = _attacker_player(ctx)
        if ctx.source_pokemon not in player.bench:
            return
        player.bench.remove(ctx.source_pokemon)
        player.discard.extend(ctx.source_pokemon.evolution_history)
        player.discard.append(ctx.source_pokemon.card_id)
        player.discard.extend(ctx.source_pokemon.attached_energy)
        if ctx.source_pokemon.attached_tool:
            player.discard.append(ctx.source_pokemon.attached_tool)


@dataclass(frozen=True)
class DiscardTopNAttachEnergyFound(Effect):
    """山札の上からN枚をトラッシュし、その中にあったエネルギー(basic_only=Trueなら基本エネルギーのみ)を
    つける(セレスティアルロア等)。self_only=True(既定)なら自分自身固定、Falseなら自分の場から
    対象を選べる(マグカルゴGXの「Crushing Charge」)。"""

    n: int
    basic_only: bool = False
    self_only: bool = True
    energy_type: str | None = None  # 指定時は、そのタイプの基本エネルギーだけをつける(他のタイプはトラッシュのまま)

    def execute(self, ctx: EffectContext) -> None:
        if ctx.source_pokemon is None:
            return
        player = _attacker_player(ctx)
        target = ctx.source_pokemon if self.self_only else _resolve_own_target(ctx, player)
        top = player.deck[: self.n]
        player.deck = player.deck[self.n :]
        for card_id in top:
            card = ctx.card_db.get(card_id)
            matches = (
                card is not None
                and card.is_energy
                and (not self.basic_only or not card.is_special_energy)
                and (self.energy_type is None or card.basic_energy_type == self.energy_type)
            )
            if matches and target is not None:
                target.attached_energy.append(card_id)
            else:
                player.discard.append(card_id)


@dataclass(frozen=True)
class DiscardOwnEnergyToLostZone(Effect):
    """このポケモンについているエネルギーを指定数、ロストゾーンに送る(ロストインパクト等)。"""

    count: int

    def execute(self, ctx: EffectContext) -> None:
        if ctx.source_pokemon is None:
            return
        player = _attacker_player(ctx)
        moved = ctx.source_pokemon.attached_energy[: self.count]
        ctx.source_pokemon.attached_energy = ctx.source_pokemon.attached_energy[self.count :]
        player.lost_zone.extend(moved)


@dataclass(frozen=True)
class SearchDeckAnyEnergyAttachToSelf(Effect):
    """山札からエネルギーを1枚選びつける。basic_only=Trueなら基本エネルギーのみが対象
    (アルセウスVの「Trinity Charge」等)。self_only=False(既定Trueから変更)なら自分の場から
    対象を選べ、target_subtypeを指定すればそのサブタイプ(例: "V")を持つポケモンに限定できる
    (ミュウVの「Energy Mix」=Fusion Strike限定、ジラーチGXの「Star Search」=Psychic限定等)。
    target_subtypeはサブタイプ("V"等)、target_type_はポケモンタイプ("Psychic"/"Fusion Strike"は
    実際にはサブタイプではなくtypesに乗るため、legal_actions側で両方チェックする。"""

    basic_only: bool = False
    self_only: bool = True
    target_type: str | None = None
    target_subtype: str | None = None

    def execute(self, ctx: EffectContext) -> None:
        if ctx.source_pokemon is None:
            return
        player = _attacker_player(ctx)
        target = ctx.source_pokemon if self.self_only else _resolve_own_target(ctx, player)
        if target is None:
            return
        for i, card_id in enumerate(player.deck):
            card = ctx.card_db.get(card_id)
            matches = card is not None and card.is_energy and (not self.basic_only or not card.is_special_energy)
            if matches:
                player.deck.pop(i)
                target.attached_energy.append(card_id)
                ctx.rng.shuffle(player.deck)
                return


@dataclass(frozen=True)
class DrawUpToFusionStrikeCount(Effect):
    """自分の場にいる「フュージョン戦略」ポケモンの数と同じ枚数になるまで手札を引く(ゲノセクトVの特性等)。"""

    def execute(self, ctx: EffectContext) -> None:
        player = _attacker_player(ctx)
        count = sum(
            1
            for mon in player.all_pokemon_in_play()
            if (card := ctx.card_db.get(mon.card_id)) and "Fusion Strike" in card.subtypes
        )
        while len(player.hand) < count and player.deck:
            player.hand.append(player.deck.pop(0))


@dataclass(frozen=True)
class DamagePerFusionStrikeEnergyAcrossBoard(Effect):
    """自分の場の全ポケモンについているフュージョンエネルギーの合計数ぶんダメージ(メロエッタの「メロディアスエコー」等)。
    choose_target=True指定時は相手の場のポケモン1匹(バトル/ベンチ)を選んで対象にできる(アイスの「Block Slider」等)。"""

    per_energy: int
    choose_target: bool = False

    def execute(self, ctx: EffectContext) -> None:
        player = _attacker_player(ctx)
        count = sum(
            1
            for mon in player.all_pokemon_in_play()
            for energy_id in mon.attached_energy
            if ctx.card_db.get(energy_id) and "Fusion Strike" in ctx.card_db.get(energy_id).subtypes
        )
        amount = self.per_energy * count
        if self.choose_target:
            DealDamageToChosenOpponentPokemon(amount).execute(ctx)
        else:
            DealDamage(amount).execute(ctx)


@dataclass(frozen=True)
class DamagePerOwnFieldBasicEnergyTypeCountAcrossBoard(Effect):
    """自分の場の全ポケモン(バトル場+ベンチ)についている指定タイプの基本エネルギーの合計数ぶん、
    base に上乗せしてダメージを与える(オーリヴァexの「Syrup Storm」等)。メガニウムの特性
    「Wild Growth」が場にあれば、基本くさエネルギーは1枚を2枚ぶんとして数える(energy_type="Grass"の
    ときのみ該当。以前はlen()相当の単純カウントでWild Growthが一切反映されていなかった、
    2026-08-27ユーザー報告で発覚)。"""

    base: int
    per_energy: int
    energy_type: str

    def execute(self, ctx: EffectContext) -> None:
        from engine.continuous import wild_growth_active

        player = _attacker_player(ctx)
        doubled = self.energy_type == "Grass" and wild_growth_active(player)
        count = sum(
            (2 if doubled else 1)
            for mon in player.all_pokemon_in_play()
            for energy_id in mon.attached_energy
            if ctx.card_db.get(energy_id) and ctx.card_db.get(energy_id).basic_energy_type == self.energy_type
        )
        DealDamage(self.base + self.per_energy * count).execute(ctx)


@dataclass(frozen=True)
class SearchDeckForFusionStrikeEnergyAttachToTarget(Effect):
    """山札からフュージョンエネルギーを1枚選び、自分のポケモン1匹につける(エレスバのきらめき等)。"""

    def execute(self, ctx: EffectContext) -> None:
        player = _attacker_player(ctx)
        target = _resolve_own_target(ctx, player)
        if target is None:
            return
        for i, card_id in enumerate(player.deck):
            card = ctx.card_db.get(card_id)
            if card is not None and "Fusion Strike" in card.subtypes and card.is_energy:
                player.deck.pop(i)
                target.attached_energy.append(card_id)
                ctx.rng.shuffle(player.deck)
                return


@dataclass(frozen=True)
class SearchDeckForNamedPokemonToBench(Effect):
    """山札から指定した名前のポケモンを最大N匹まで探してベンチに出す(ミラーコーディネート等)。"""

    name: str
    count: int

    def execute(self, ctx: EffectContext) -> None:
        player = _attacker_player(ctx)

        def matches(card):
            return card is not None and card.name == self.name

        _trigger_search_choice(
            ctx, player, "deck", matches, self.count, f"山札から{self.name}を探してベンチに出す", destination="bench"
        )


@dataclass(frozen=True)
class DamagePerSelfEnergyOfType(Effect):
    """自分自身についている指定タイプのエネルギーの数だけダメージが上乗せされる(ブレインウェーブ等)。"""

    base: int
    per_energy: int
    energy_type: str

    def execute(self, ctx: EffectContext) -> None:
        if ctx.source_pokemon is None:
            return
        count = sum(
            1
            for e in ctx.source_pokemon.attached_energy
            if ctx.card_db.get(e) and ctx.card_db.get(e).basic_energy_type == self.energy_type
        )
        DealDamage(self.base + self.per_energy * count).execute(ctx)


@dataclass(frozen=True)
class LookTopNAttachEnergyRestToHand(Effect):
    """山札の上からN枚を見て、その中の基本エネルギー(energy_type指定時はそのタイプのみ)を
    好きなだけつけ、残りは手札に加える(サーナイトの「Shining Arcana」/ザシアンVの「Intrepid Sword」等)。
    self_only=True(既定、Intrepid Sword向け)なら対象はこのポケモン自身固定。Falseなら自分の場から
    対象を選べる(Shining Arcana、見つかった分は1体にまとめてつける簡略版)。"""

    n: int
    energy_type: str | None = None
    self_only: bool = True

    def execute(self, ctx: EffectContext) -> None:
        if ctx.source_pokemon is None:
            return
        player = _attacker_player(ctx)
        target = ctx.source_pokemon if self.self_only else _resolve_own_target(ctx, player)
        top = player.deck[: self.n]
        player.deck = player.deck[self.n :]
        attached_names = []
        for card_id in top:
            card = ctx.card_db.get(card_id)
            matches = card is not None and card.is_energy and not card.is_special_energy and (
                self.energy_type is None or card.basic_energy_type == self.energy_type
            )
            if matches and target is not None:
                target.attached_energy.append(card_id)
                attached_names.append(card.name)
            else:
                player.hand.append(card_id)
        if attached_names:
            ctx.log(f"山札の上から{len(top)}枚を見て、エネルギー({', '.join(attached_names)})をつけた")
        else:
            ctx.log(f"山札の上から{len(top)}枚を見た(つけられるエネルギーなし、手札に加えた)")
        ctx.reveal("山札の上から見えたカード", top)


@dataclass(frozen=True)
class LookTopNChooseEnergyToAttachRestToHand(Effect):
    """山札の上からN枚を見て、その中の基本エネルギー(energy_type指定時はそのタイプのみ)を好きな枚数(0枚でもよい)
    選んで自分のポケモンにつけ、残りは手札に加える(サーナイト(swsh6-61)の「Shining Arcana」実カードテキスト: "look at the
    top 2 cards of your deck and attach any number of basic Energy cards you find there to your Pokémon in any way you
    like. Put the other cards into your hand."、ザシアンV(swsh1-138)の「Intrepid Sword」: "look at the top 3 cards ...
    attach any number of Metal Energy cards you find there to this Pokémon. Put the other cards into your hand. If you
    use this Ability, your turn ends.")。self_only=Trueなら、つける先はこのポケモン自身に固定。Falseなら1枚ずつ
    自分の場のポケモンから選んで分配できる。ends_turn=Trueなら、この特性を使ったあと自分の番を終える。以前は見つけた
    該当エネルギーを自動で全てつける(Shining Arcanaは1体にまとめる)簡略版だった(2026-10-06訂正)。"""

    n: int
    energy_type: str | None = None
    self_only: bool = False
    ends_turn: bool = False

    def execute(self, ctx: EffectContext) -> None:
        if ctx.source_pokemon is None:
            return
        player = _attacker_player(ctx)
        top = player.deck[: self.n]
        player.deck = player.deck[self.n :]

        def matches(cid: str) -> bool:
            card = ctx.card_db.get(cid)
            return card is not None and card.basic_energy_type is not None and (
                self.energy_type is None or card.basic_energy_type == self.energy_type
            )

        eligible_positions = [i for i, cid in enumerate(top) if matches(cid)]
        non_eligible = [cid for i, cid in enumerate(top) if i not in eligible_positions]
        if not eligible_positions:
            player.hand.extend(top)
            ctx.log(f"山札の上から{len(top)}枚を見た(つけられるエネルギーなし、手札に加えた)")
            if self.ends_turn:
                ctx.state.forced_turn_end_after_ability = True
            return
        ctx.state.pending_search_choice = PendingSearchChoice(
            player_index=ctx.acting_player,
            zone="deck_top_n_energy_take",
            source_indices=eligible_positions,
            card_ids=[top[i] for i in eligible_positions],
            min_count=0,
            max_count=len(eligible_positions),
            prompt="山札の上から見つけたエネルギーから、つけるものを選ぶ(選ばなかったものは手札に加える)",
            shuffle_after=False,
            all_card_ids=[top[i] for i in eligible_positions],
            reveal_to_opponent=False,
            cont_source_pokemon=ctx.source_pokemon,
            cont_source_card_id=ctx.source_card_id,
            then_end_turn=self.ends_turn,
            custom_data={
                "mode": "look_top_n_energy_take",
                "non_eligible": non_eligible,
                "rest_to_hand": True,
                "self_only": self.self_only,
                "bench_only": False,
                "target_pokemon_type": None,
                "basic_stage_only": False,
            },
        )


@dataclass(frozen=True)
class LookTopNKeepMRestToLostZone(Effect):
    """山札の上からN枚を見て、好きなM枚を手札に加え、残りをロストゾーンに送る(キュワワーの特性・ギラティナVのワザ等)。"""

    n: int
    m: int

    def execute(self, ctx: EffectContext) -> None:
        player = _attacker_player(ctx)
        top = player.deck[: self.n]
        player.deck = player.deck[self.n :]
        kept = top[: self.m]
        lost = top[self.m :]
        player.hand.extend(kept)
        player.lost_zone.extend(lost)


@dataclass(frozen=True)
class DiscardEnergyFromHandForScalingDamage(Effect):
    """手札からエネルギーを好きな枚数(0枚でもよい、最大max_countまで)選んでトラッシュし、
    トラッシュした枚数ぶんダメージが上乗せされる(サーフゴーexの「Make It Rain」実カードテキスト:
    "Discard any number of Basic Energy cards from your hand."、ヒスイのジュナイパーVSTARの
    「Somersault Feathers」実カードテキスト: "You may discard up to 3 Energy cards from your
    hand."。どちらも枚数・どのカードかはプレイヤーが選ぶ)。basic_only=Trueなら基本エネルギー限定
    (Make It Rain)。"""

    base: int
    max_count: int
    damage_per: int
    basic_only: bool = False
    energy_type: str | None = None  # 指定時はその基本タイプのみ(スカーミリー(Skarmory)「Steel Cutter」等)

    def execute(self, ctx: EffectContext) -> None:
        player = _attacker_player(ctx)

        def matches(card):
            if card is None or not card.is_energy:
                return False
            if self.energy_type is not None:
                return card.basic_energy_type == self.energy_type
            return not (self.basic_only and card.is_special_energy)

        eligible_indices = [i for i, cid in enumerate(player.hand) if matches(ctx.card_db.get(cid))]
        if not eligible_indices:
            DealDamage(self.base).execute(ctx)
            return
        max_count = min(self.max_count, len(eligible_indices))
        ctx.state.pending_search_choice = PendingSearchChoice(
            player_index=ctx.acting_player,
            zone="hand",
            source_indices=eligible_indices,
            card_ids=[player.hand[i] for i in eligible_indices],
            min_count=0,
            max_count=max_count,
            prompt="トラッシュするエネルギーを選ぶ(選んだ枚数ぶんダメージが上乗せされる)",
            shuffle_after=False,
            all_card_ids=[player.hand[i] for i in eligible_indices],
            destination="discard",
            cont_source_pokemon=ctx.source_pokemon,
            cont_source_card_id=ctx.source_card_id,
            custom_data={"mode": "discard_hand_energy_scaling_damage", "base": self.base, "damage_per": self.damage_per},
        )


@dataclass(frozen=True)
class BothPlayersShuffleHandAndDrawAsymmetric(Effect):
    """両方のプレイヤーが手札を山札の下に戻してシャッフルし、自分はN枚・相手はM枚引く(マーニー等)。"""

    own_count: int
    opponent_count: int

    def execute(self, ctx: EffectContext) -> None:
        for player_index, count in ((ctx.acting_player, self.own_count), (ctx.opponent, self.opponent_count)):
            player = ctx.state.player(player_index)
            player.deck.extend(player.hand)
            player.hand = []
            ctx.rng.shuffle(player.deck)
            for _ in range(count):
                if not player.deck:
                    break
                player.hand.append(player.deck.pop(0))
        ctx.state.player(ctx.acting_player).known_opponent_hand = []
        ctx.state.player(ctx.opponent).known_opponent_hand = []


@dataclass(frozen=True)
class DamageCounterOnChosenOpponentThenSelfKnockout(Effect):
    """相手の場のポケモン1匹にダメカンをのせ、自分自身はきぜつする(デスバーンの「呪いのばくだん」等)。"""

    count: int

    def execute(self, ctx: EffectContext) -> None:
        if ctx.source_pokemon is None:
            return
        opponent = ctx.state.player(ctx.opponent)
        target = _resolve_opponent_target(ctx, opponent)
        # このEffectは(サマヨール/ヨノワールの「Cursed Blast」のように)特性由来でも使われる。
        # ミストエネルギー等の「ワザ限定」免疫(_defender_blocks_attack_only_non_damage_effects)は
        # 実カードテキストが「相手のポケモンのワザの効果を受けない」と明記されており、特性由来の
        # 効果には及ばない(2026-09-02、ユーザー指摘・公式FAQで裏取り)ため、ここでは呼ばない。
        # 一方、ばけがくれ等の「ワザ/特性共通」免疫(_defender_blocks_attack_and_ability_non_damage_effects、
        # 実カードテキスト: "Prevent all effects of your opponent's Pokémon's attacks and Abilities
        # done to this Pokémon.")は特性由来の効果にも適用されるため、こちらは呼ぶ(2026-09-04、
        # サマヨール「Cursed Blast」vsばけがくれの誤判定を修正)。
        if target is not None and not (
            _defender_is_shielded(ctx, target)
            or _defender_blocks_attack_and_ability_non_damage_effects(ctx, target)
            or (not tools_disabled(ctx.state.stadium_in_play) and _blocks_damage_counters(target))
        ):
            # ダメカンを直接のせる=ワザ自体のダメージではなく「効果」のため、ばけがくれ等でブロックされうる。
            target.damage += self.count * 10
        # 自分自身のきぜつは、相手側への効果がブロックされたかどうかに関わらず実カードテキスト通り常に発生する
        # (「相手のポケモンにダメカンをのせ、自分自身もきぜつする」は独立した2つの効果)。
        ctx.source_pokemon.damage = 9999


@dataclass(frozen=True)
class KnockOutBothActivePokemon(Effect):
    """おたがいのバトルポケモンをきぜつさせる(コノヨザルの「みちづれファイト」等)。ダメージ計算を
    経由しない直接きぜつのため、弱点・抵抗力・シールド等の影響を受けない。"""

    def execute(self, ctx: EffectContext) -> None:
        if ctx.source_pokemon is not None:
            ctx.source_pokemon.damage = 9999
        _, defender = _defender(ctx)
        if defender is not None and not (
            _defender_blocks_non_damage_effects(ctx, defender) or _defender_is_shielded(ctx, defender)
        ):
            # 相手側のきぜつは「効果」としてばけがくれ等でブロックされうるが、自分自身のきぜつは
            # 自らへの効果(相手からの効果ではない)のため、ブロックの有無に関わらず常に発生する。
            defender.damage = 9999


# ---- Players Cup 2020/2021デッキ向けに追加したプリミティブ ----


@dataclass(frozen=True)
class InflictStatusOnSelf(Effect):
    """自分自身(ワザ/特性を使っているポケモン)に特殊状態を与える(ジラーチの「スターウィッシュ」等)。"""

    condition: str

    def execute(self, ctx: EffectContext) -> None:
        if ctx.source_pokemon is None:
            return
        _apply_condition(ctx.source_pokemon, self.condition)


@dataclass(frozen=True)
class InflictHardToWakeSleepOnSelf(Effect):
    """自分自身をねむり状態にする。通常より目覚めにくい(ポケモンチェックでflip_count枚のコインを振り、
    1枚でも裏ならねむりのまま)版(カビゴンの「爆音イビキ」等)。"""

    flip_count: int = 2

    def execute(self, ctx: EffectContext) -> None:
        if ctx.source_pokemon is None:
            return
        ctx.source_pokemon.status.apply_exclusive(ExclusiveCondition.ASLEEP)
        ctx.source_pokemon.status.sleep_flip_count = self.flip_count


@dataclass(frozen=True)
class DiscardOpponentActiveSpecialEnergy(Effect):
    """相手のバトルポケモンについている特殊エネルギーを1枚トラッシュする(ザマゼンタVの「アサルトタックル」、
    ギラティナの「ディメンションブレイク」等)。"""

    def execute(self, ctx: EffectContext) -> None:
        opponent = ctx.state.player(ctx.opponent)
        if opponent.active is None:
            return
        specials = [
            e for e in opponent.active.attached_energy
            if (card := ctx.card_db.get(e)) is not None and card.is_special_energy
        ]
        if not specials:
            return
        if len(set(specials)) > 1:
            source_indices, card_ids = _field_attachment_candidates(
                ctx.state, ctx.card_db, (ctx.opponent,), include_tool=False,
                energy_predicate=lambda c: c.is_special_energy, only_pokemon=opponent.active,
            )
            ctx.state.pending_search_choice = PendingSearchChoice(
                player_index=ctx.acting_player,
                zone="field_attachment",
                source_indices=source_indices,
                card_ids=card_ids,
                min_count=1,
                max_count=1,
                prompt="トラッシュする相手のバトルポケモンの特殊エネルギーを選ぶ",
                shuffle_after=False,
                all_card_ids=list(card_ids),
                destination="discard",
                cont_source_pokemon=ctx.source_pokemon,
                cont_source_card_id=ctx.source_card_id,
            )
            return
        opponent.active.attached_energy.remove(specials[0])
        opponent.discard.append(specials[0])
        ctx.log("相手のバトルポケモンの特殊エネルギーを1枚トラッシュした")


@dataclass(frozen=True)
class DiscardOpponentActiveEnergy(Effect):
    """相手のバトルポケモンについているエネルギーを1枚(種類問わず)トラッシュする
    (ヤブクロンの「アシッドスプレー」等)。"""

    def execute(self, ctx: EffectContext) -> None:
        opponent = ctx.state.player(ctx.opponent)
        if opponent.active is None or not opponent.active.attached_energy:
            return
        if len(set(opponent.active.attached_energy)) > 1:
            # 種類の違うエネルギーが複数ついているときは、どれをトラッシュするかワザを使った側が選ぶ
            # (以前は先頭の1枚を機械的に捨てていた、2026-10-06訂正)
            source_indices, card_ids = _field_attachment_candidates(
                ctx.state, ctx.card_db, (ctx.opponent,), include_tool=False, energy_predicate=lambda c: True,
                only_pokemon=opponent.active,
            )
            ctx.state.pending_search_choice = PendingSearchChoice(
                player_index=ctx.acting_player,
                zone="field_attachment",
                source_indices=source_indices,
                card_ids=card_ids,
                min_count=1,
                max_count=1,
                prompt="トラッシュする相手のバトルポケモンのエネルギーを選ぶ",
                shuffle_after=False,
                all_card_ids=list(card_ids),
                destination="discard",
                cont_source_pokemon=ctx.source_pokemon,
                cont_source_card_id=ctx.source_card_id,
            )
            return
        energy_id = opponent.active.attached_energy.pop(0)
        opponent.discard.append(energy_id)
        ctx.log("相手のバトルポケモンのエネルギーを1枚トラッシュした")


@dataclass(frozen=True)
class DiscardOpponentActiveEnergyIfSelfHasEnergyId(Effect):
    """自分に指定IDのエネルギーが1枚でもついているときだけ、相手のバトルポケモンのエネルギーを
    1枚トラッシュする(ボルトロスEXの「Thunderous Noise」: プラズマエネルギーがあれば発動)。"""

    required_energy_id: str

    def execute(self, ctx: EffectContext) -> None:
        if ctx.source_pokemon is None or self.required_energy_id not in ctx.source_pokemon.attached_energy:
            return
        DiscardOpponentActiveEnergy().execute(ctx)


@dataclass(frozen=True)
class ReturnHandPokemonToDeck(Effect):
    """手札のポケモンを1枚選んで山札に戻す(ポケモン通信の前半部分。続けて山札検索効果につなげる用)。"""

    def execute(self, ctx: EffectContext) -> None:
        player = _attacker_player(ctx)

        def matches(card):
            return card is not None and card.is_pokemon

        _trigger_search_choice(
            ctx, player, "hand", matches, 1, "手札のポケモンを1枚山札に戻す", shuffle_after=True, destination="deck", min_count=1
        )


@dataclass(frozen=True)
class SearchDiscardForSupporterToHand(Effect):
    """トラッシュからサポートを1枚選んで手札に戻す(シロナ&カトレア等)。"""

    count: int = 1

    def execute(self, ctx: EffectContext) -> None:
        player = _attacker_player(ctx)

        def matches(card):
            return card is not None and card.is_supporter

        _trigger_search_choice(
            ctx, player, "discard", matches, self.count, "トラッシュからサポートを探す", shuffle_after=False
        )


@dataclass(frozen=True)
class OpponentShuffleHandDrawByPrizes(Effect):
    """相手が手札を山札に戻してシャッフルし、相手の残りサイド枚数ぶんカードを引く(リセットスタンプ)。"""

    def execute(self, ctx: EffectContext) -> None:
        opponent = ctx.state.player(ctx.opponent)
        opponent.deck.extend(opponent.hand)
        opponent.hand = []
        ctx.rng.shuffle(opponent.deck)
        for _ in range(len(opponent.prizes)):
            if not opponent.deck:
                break
            opponent.hand.append(opponent.deck.pop(0))
        ctx.log("相手が手札を山札に戻し、残りサイド枚数ぶんカードを引いた")
        # 手札が丸ごと入れ替わったので、以前この相手の手札を公開させて覚えていた分の記憶は無効化する
        # (rl_env.encodingのクランプだけでもほぼ自然に解消されるが、念のため明示的にも消しておく)。
        ctx.state.player(ctx.acting_player).known_opponent_hand = []


@dataclass(frozen=True)
class OpponentHandToBottomOfDeckThenDraw(Effect):
    """相手が手札をシャッフルして山札の下に置く。そうしたら、相手は山札を count 枚引く(スペシャルレッドカード
    (me4-82)実カードテキスト: "Your opponent shuffles their hand and puts it on the bottom of their deck. If they
    put any cards on the bottom of their deck in this way, they draw 3 cards.")。手札を山札全体に混ぜるのではなく
    山札の下に置くので、引くのは元々の山札の上のカード(以前は山札全体に混ぜてシャッフルしていた誤りを訂正、
    2026-10-06)。手札が0枚なら何も置けないので引かない。"""

    count: int

    def execute(self, ctx: EffectContext) -> None:
        opponent = ctx.state.player(ctx.opponent)
        if not opponent.hand:
            return
        returned = list(opponent.hand)
        opponent.hand = []
        ctx.rng.shuffle(returned)
        opponent.deck.extend(returned)
        drawn = 0
        for _ in range(self.count):
            if not opponent.deck:
                break
            opponent.hand.append(opponent.deck.pop(0))
            drawn += 1
        ctx.log(f"相手が手札を山札の下に置き、{drawn}枚引いた")
        ctx.state.player(ctx.acting_player).known_opponent_hand = []


@dataclass(frozen=True)
class OpponentShuffleHandThenDrawFixed(Effect):
    """相手が手札を山札に戻してシャッフルし、固定枚数を引く(スペシャルレッドカード等)。
    使用条件(相手の残りサイド枚数)はengine.legal_actions側でゲート済み。"""

    count: int

    def execute(self, ctx: EffectContext) -> None:
        opponent = ctx.state.player(ctx.opponent)
        opponent.deck.extend(opponent.hand)
        opponent.hand = []
        ctx.rng.shuffle(opponent.deck)
        for _ in range(self.count):
            if not opponent.deck:
                break
            opponent.hand.append(opponent.deck.pop(0))
        ctx.log(f"相手が手札を山札に戻し、{self.count}枚引いた")
        ctx.state.player(ctx.acting_player).known_opponent_hand = []


# ---- WCS2019デッキ向けに追加したプリミティブ ----


@dataclass(frozen=True)
class AttachEnergyFromHandToTarget(Effect):
    """手札から指定タイプの基本エネルギーを最大count枚選び、自分のポケモン1匹(対象指定)につける(溶接工等)。
    1枚以上つけられたら1枚引く。
    """

    energy_type: str
    max_count: int = 1
    draw_if_attached: bool = False

    def execute(self, ctx: EffectContext) -> None:
        player = _attacker_player(ctx)
        target = _resolve_own_target(ctx, player)
        if target is None:
            return
        attached = 0
        remaining_hand: list[str] = []
        for card_id in player.hand:
            card = ctx.card_db.get(card_id)
            if attached < self.max_count and card is not None and card.basic_energy_type == self.energy_type:
                attached += 1
                target.attached_energy.append(card_id)
            else:
                remaining_hand.append(card_id)
        player.hand = remaining_hand
        if attached and self.draw_if_attached:
            Draw(3).execute(ctx)


@dataclass(frozen=True)
class SearchDeckForDistinctBasicEnergyTypesToHand(Effect):
    """山札から、互いに異なるタイプの基本エネルギーを1枚ずつ、見つかった分だけ全て手札に加える
    (エネルギー転送PRO等)。同じタイプの基本エネルギーはどの1枚を選んでも結果は同じ(完全に代替可能な
    カードのため)、山札内で最初に見つかったものを使って問題ない。"""

    def execute(self, ctx: EffectContext) -> None:
        player = _attacker_player(ctx)
        picked_types: set[str] = set()
        picked_ids: list[str] = []
        remaining_deck: list[str] = []
        for card_id in player.deck:
            card = ctx.card_db.get(card_id)
            if (
                card is not None
                and card.is_energy
                and not card.is_special_energy
                and card.basic_energy_type not in picked_types
            ):
                picked_types.add(card.basic_energy_type)
                picked_ids.append(card_id)
            else:
                remaining_deck.append(card_id)
        player.hand.extend(picked_ids)
        player.deck = remaining_deck
        ctx.rng.shuffle(player.deck)
        if picked_ids:
            names = [ctx.card_db.get(cid).name if ctx.card_db.get(cid) else cid for cid in picked_ids]
            ctx.log(f"山札から {', '.join(names)} を手札に加えた")


@dataclass(frozen=True)
class SearchDeckForBasicEnergyAttachToTarget(Effect):
    """山札から基本エネルギーを最大count枚選び、自分のポケモン1匹(対象指定)につける(ビーストリング、
    ボルケニオンの「かえんスタート」等、実カードテキストが"attach them to 1 of your Pokémon"等
    1体固定の対象指定になっているもの用)。energy_type=Noneならタイプ問わず。

    bonus_count_if_second_first_turn指定時、後攻1ターン目ならcountの代わりにこの枚数を使う
    (「かえんスタート」の「後攻1ターン目なら3枚まで」等)。

    self_only=True(既定)は対象がこのポケモン自身固定。self_only=Falseにすると
    engine.legal_actions側で対象を選べるようになり、bench_only=Trueならベンチポケモンのみが対象になる
    (ムチュールの「るんるんキッス」実カードテキスト: "1 of your Benched Pokémon"用)。
    """

    count: int = 1
    energy_type: str | None = None
    bonus_count_if_second_first_turn: int | None = None
    self_only: bool = True
    bench_only: bool = False

    def execute(self, ctx: EffectContext) -> None:
        player = _attacker_player(ctx)
        target = _resolve_own_target(ctx, player)
        if target is None:
            return
        if self.bench_only and target is player.active:
            return  # ベンチが無く_resolve_own_targetがバトル場自身にフォールバックした場合、bench_only制約に反するため何もしない
        count = self.count
        if self.bonus_count_if_second_first_turn is not None and _is_second_players_first_turn(ctx):
            count = self.bonus_count_if_second_first_turn

        def matches(card):
            if card is None or not card.is_energy or card.is_special_energy:
                return False
            return self.energy_type is None or card.basic_energy_type == self.energy_type

        # 実カードルール上、「山札から選ぶ」効果は常にプレイヤー自身が山札を検索して選ぶ手続きの
        # ため、他の普通のサーチ効果と同じくプレイヤーに選ばせる(以前は山札の並び順で機械的に
        # 該当カードを先頭からcount枚まで自動選択しており、プレイヤーの選択機会が無かった。
        # ムチュールの「Delightful Kiss」でユーザーから「普通のサーチカードと同じく山札を直接見て
        # 選択できるようにしてほしい」と報告を受け、2026-08-26にこのクラス全体(かえんスタート等
        # 他のカードでも共有)をこの挙動に統一した)。
        _trigger_search_choice(
            ctx, player, "deck", matches, count,
            "山札から基本エネルギーを選んでつける", shuffle_after=True, destination="attach_energy", min_count=0,
        )
        if ctx.state.pending_search_choice is not None:
            ctx.state.pending_search_choice.attach_target_pokemon = target


def _attach_deck_energy_freely(
    ctx: EffectContext,
    remaining_count: int,
    picked_types: frozenset[str] = frozenset(),
    distinct_types: bool = False,
    bench_only: bool = False,
    then_end_turn: bool = False,
    energy_type: str | None = None,
    optional: bool = False,
    target_name_prefix: str | None = None,
) -> None:
    """山札の基本エネルギーを自分のポケモンに「好きなように」1枚ずつ分配してつける(ビクティニの
    「Victory Sign」/わざマシン エナジーターボ/リザードンexの「インフェルノリボーン」等)。
    distinct_types=Trueなら、既につけたタイプと同じタイプは以後の候補から除外する(異なるタイプの
    みを選べる制約)。bench_only=Trueならベンチのポケモンのみが対象(エナジーターボの「Benched
    Pokémon」制約)。energy_type指定時はそのタイプの基本エネルギーのみが対象(インフェルノリボーンの
    「Basic Fire Energy」制約)。optional=Trueなら「Nまで」の任意枚数(途中でこれ以上つけないことも
    選べる、0枚選択=打ち切り)。target_name_prefix指定時はその接頭辞のカード名を持つ自分のポケモンのみが
    対象(マリィのオーロンゲexの「Punk Up」実カードテキスト: "attach them to your Marnie's Pokémon
    in any way you like"等)。全て終わったら山札をシャッフルする。"""
    player = _attacker_player(ctx)

    def matches(card) -> bool:
        return (
            card is not None
            and card.is_energy
            and not card.is_special_energy
            and (energy_type is None or card.basic_energy_type == energy_type)
            and (not distinct_types or card.basic_energy_type not in picked_types)
        )

    if remaining_count <= 0:
        ctx.rng.shuffle(player.deck)
        return
    eligible_indices = [i for i, cid in enumerate(player.deck) if matches(ctx.card_db.get(cid))]
    if not eligible_indices:
        ctx.rng.shuffle(player.deck)
        return
    candidates = [] if bench_only else ([(0, player.active)] if player.active is not None else [])
    for i, mon in enumerate(player.bench):
        candidates.append((i + 1, mon))
    if target_name_prefix is not None:
        candidates = [
            (slot, mon)
            for slot, mon in candidates
            if (c := ctx.card_db.get(mon.card_id)) is not None and c.name.startswith(target_name_prefix)
        ]
    if not candidates:
        ctx.rng.shuffle(player.deck)
        return
    ctx.state.pending_search_choice = PendingSearchChoice(
        player_index=ctx.acting_player,
        zone="own_pokemon_target",
        source_indices=[slot for slot, _ in candidates],
        card_ids=[mon.card_id for _, mon in candidates],
        min_count=0 if optional else 1,
        max_count=1,
        prompt=f"エネルギーをつける自分のポケモンを選ぶ(残り{remaining_count}枚まで)",
        shuffle_after=False,
        all_card_ids=[mon.card_id for _, mon in candidates],
        then_end_turn=then_end_turn,
        custom_data={
            "mode": "attach_deck_energy_freely_pick_target",
            "remaining": remaining_count,
            "picked_types": sorted(picked_types),
            "distinct_types": distinct_types,
            "bench_only": bench_only,
            "then_end_turn": then_end_turn,
            "energy_type": energy_type,
            "optional": optional,
            "target_name_prefix": target_name_prefix,
        },
    )


@dataclass(frozen=True)
class SearchDeckForBasicEnergyAttachFreely(Effect):
    """山札から基本エネルギーを最大count枚選び、自分のポケモンに好きなように(1匹にまとめても、
    複数匹に分けてもよい)つける(ビクティニの「Victory Sign」実カードテキスト: "attach them to
    your Pokémon in any way you like"、わざマシン エナジーターボの"attach them to your Benched
    Pokémon in any way you like"、リザードンexの「インフェルノリボーン」実カードテキスト: "search
    your deck for up to 3 Basic Fire Energy cards and attach them to your Pokémon in any way you
    like"等)。distinct_types=Trueなら選ぶエネルギーは互いに異なるタイプ限定。bench_only=Trueなら
    ベンチのポケモンのみが対象。energy_type指定時はそのタイプの基本エネルギーのみが対象。"""

    count: int
    distinct_types: bool = False
    bench_only: bool = False
    energy_type: str | None = None
    optional: bool = False
    target_name_prefix: str | None = None

    def execute(self, ctx: EffectContext) -> None:
        _attach_deck_energy_freely(
            ctx, self.count, distinct_types=self.distinct_types, bench_only=self.bench_only,
            energy_type=self.energy_type, optional=self.optional, target_name_prefix=self.target_name_prefix,
        )


@dataclass(frozen=True)
class SearchDeckForBasicEnergyAttachFreelyWithSecondTurnBonus(Effect):
    """山札から指定タイプの基本エネルギーを最大base_count枚(後攻の最初の番ならbonus_count枚)選び、自分のポケモンに
    好きなようにつける(ボルケニオン(sm10-25)の「Flare Starter」実カードテキスト: "Search your deck for a Fire
    Energy card and attach it to 1 of your Pokémon. If you go second and it's your first turn, instead search for
    up to 3 Fire Energy cards and attach them to your Pokémon in any way you like. Then, shuffle your deck.")。
    以前は「このポケモン自身につける」に固定されていた誤りを訂正(2026-10-06)。"""

    base_count: int
    bonus_count: int
    energy_type: str | None = None

    def execute(self, ctx: EffectContext) -> None:
        count = self.bonus_count if _is_second_players_first_turn(ctx) else self.base_count
        _attach_deck_energy_freely(ctx, count, energy_type=self.energy_type)


@dataclass(frozen=True)
class DiscardOwnEnergyToLostZoneForScalingDamage(Effect):
    """このポケモンについているエネルギーを最大N枚までロストゾーンに送り、送った枚数ぶんダメージ
    (ズガドーンGXの「マインドブロウン」等)。"""

    max_count: int
    damage_per: int
    energy_type: str | None = None

    def execute(self, ctx: EffectContext) -> None:
        if ctx.source_pokemon is None:
            return
        player = _attacker_player(ctx)
        moved: list[str] = []
        remaining: list[str] = []
        for card_id in ctx.source_pokemon.attached_energy:
            card = ctx.card_db.get(card_id)
            matches = self.energy_type is None or (card and card.basic_energy_type == self.energy_type)
            if len(moved) < self.max_count and matches:
                moved.append(card_id)
            else:
                remaining.append(card_id)
        ctx.source_pokemon.attached_energy = remaining
        player.lost_zone.extend(moved)
        DealDamage(self.damage_per * len(moved)).execute(ctx)


@dataclass(frozen=True)
class LookTopNKeepMRestToDiscard(Effect):
    """山札の上からN枚を見て、そのうちM枚を手札に加える(選べる枚数はNに満たなければあるだけ)。
    選ばなかった残りはトラッシュする(アクロバイク/ハプウ等、実カードテキストが"put M of them into
    your hand. Discard the other card(s)"と明記しており、M枚を選ぶのは任意ではなく必須)。"""

    n: int
    m: int

    def execute(self, ctx: EffectContext) -> None:
        player = _attacker_player(ctx)
        seen = player.deck[: self.n]
        if not seen:
            return
        max_count = min(self.m, len(seen))
        ctx.state.pending_search_choice = PendingSearchChoice(
            player_index=ctx.acting_player,
            zone="deck",
            source_indices=list(range(len(seen))),
            card_ids=list(seen),
            min_count=max_count,
            max_count=max_count,
            prompt="山札の上から見たカードの中から選ぶ",
            shuffle_after=False,
            all_card_ids=list(seen),
            remaining_to_discard=True,
        )


@dataclass(frozen=True)
class DamagePerOwnBenchedPokemonOfType(Effect):
    """自分のベンチにいる指定タイプのポケモンの数だけ追加ダメージ(エーフィ&デオキシスGXの「サイキッククラブ」等)。"""

    base: int
    per_pokemon: int
    pokemon_type: str

    def execute(self, ctx: EffectContext) -> None:
        player = _attacker_player(ctx)
        count = 0
        for mon in player.bench:
            card = ctx.card_db.get(mon.card_id)
            if card is not None and self.pokemon_type in card.types:
                count += 1
        DealDamage(self.base + self.per_pokemon * count).execute(ctx)


@dataclass(frozen=True)
class SearchDiscardForSupporterOrStadiumToHand(Effect):
    """トラッシュからサポート/スタジアムを合わせて最大count枚選んで手札に戻す(ルザミーネ等)。"""

    count: int = 1

    def execute(self, ctx: EffectContext) -> None:
        player = _attacker_player(ctx)

        def matches(card):
            return card is not None and (card.is_supporter or card.is_stadium)

        _trigger_search_choice(
            ctx, player, "discard", matches, self.count, "トラッシュからサポート/スタジアムを探す", shuffle_after=False
        )


@dataclass(frozen=True)
class ClearActiveStatusConditions(Effect):
    """自分のバトルポケモンについているすべての特殊状態を治す(ミックスハーブ等、道具カードから使う版)。"""

    def execute(self, ctx: EffectContext) -> None:
        player = _attacker_player(ctx)
        if player.active is not None:
            player.active.status.clear_all()


_STATUS_LABELS = ("どく", "やけど", "ねむり", "マヒ", "こんらん")


def _present_status_labels(status) -> list[str]:
    from engine.status import ExclusiveCondition

    labels = []
    if status.poisoned:
        labels.append("どく")
    if status.burned:
        labels.append("やけど")
    if status.exclusive == ExclusiveCondition.ASLEEP:
        labels.append("ねむり")
    if status.exclusive == ExclusiveCondition.PARALYZED:
        labels.append("マヒ")
    if status.exclusive == ExclusiveCondition.CONFUSED:
        labels.append("こんらん")
    return labels


def clear_status_by_label(status, label: str) -> None:
    from engine.status import ExclusiveCondition

    if label == "どく":
        status.poisoned = False
        status.poison_severity = 1
    elif label == "やけど":
        status.burned = False
    elif label in ("ねむり", "マヒ", "こんらん"):
        status.exclusive = ExclusiveCondition.NONE
        status.paralysis_survives_next_checkup = False
        status.sleep_flip_count = 1


@dataclass(frozen=True)
class RemoveOneActiveStatusCondition(Effect):
    """自分のバトルポケモンの特殊状態を1つ(プレイヤーが選ぶ)治す(ミックスハーブ1枚使用時実カードテキスト:
    "remove a Special Condition from your Active Pokémon")。以前はすべての特殊状態を治していた(2026-10-06訂正)。
    治せる特殊状態が1つだけならそのまま治し、2つ以上あれば選択待ちにする。"""

    def execute(self, ctx: EffectContext) -> None:
        player = _attacker_player(ctx)
        if player.active is None:
            return
        labels = _present_status_labels(player.active.status)
        if not labels:
            return
        if len(labels) == 1:
            clear_status_by_label(player.active.status, labels[0])
            ctx.log(f"バトルポケモンの「{labels[0]}」を治した")
            return
        ctx.state.pending_search_choice = PendingSearchChoice(
            player_index=ctx.acting_player,
            zone="status_condition_remove_choice",
            source_indices=list(range(len(labels))),
            card_ids=labels,
            min_count=1,
            max_count=1,
            prompt="治す特殊状態を1つ選ぶ",
            shuffle_after=False,
            all_card_ids=list(labels),
            reveal_to_opponent=False,
            custom_data={"pokemon": player.active},
        )


@dataclass(frozen=True)
class FlipCoinThenReturnActiveToHand(Effect):
    """コインを1回投げ、オモテなら自分のバトルポケモンをついているカードごと手札に戻す(スーパーポケモン回収等)。

    バトル場が空になるため、ベンチがある場合のみ使用可能とする。
    """

    def execute(self, ctx: EffectContext) -> None:
        player = _attacker_player(ctx)
        if player.active is None or not player.bench:
            return
        heads = ctx.rng.random() < 0.5
        ctx.log("コイン: オモテ" if heads else "コイン: ウラ")
        if not heads:
            return
        mon = player.active
        player.active = None
        player.hand.extend(mon.evolution_history)
        player.hand.append(mon.card_id)
        player.hand.extend(mon.attached_energy)
        if mon.attached_tool:
            player.hand.append(mon.attached_tool)


@dataclass(frozen=True)
class FlipCoinThenChooseOwnPokemonReturnToHand(Effect):
    """コインを1回投げ、オモテなら自分の場のポケモン1匹(選択、バトル/ベンチどちらでも可)を
    ついているカードごと手札に戻す(スーパーポケモン回収)。対象選択はzone="own_pokemon_target"
    (mode="return_to_hand_target")をengine.rules_engine側が解決する
    (バトル場が空になった場合の新アクティブ選択もそちら側で処理する)。"""

    def execute(self, ctx: EffectContext) -> None:
        player = _attacker_player(ctx)
        heads = ctx.rng.random() < 0.5
        ctx.log("コイン: オモテ" if heads else "コイン: ウラ")
        if not heads:
            return
        candidates = []
        if player.active is not None:
            candidates.append((0, player.active))
        for i, mon in enumerate(player.bench):
            candidates.append((i + 1, mon))
        if not candidates:
            return
        ctx.state.pending_search_choice = PendingSearchChoice(
            player_index=ctx.acting_player,
            zone="own_pokemon_target",
            source_indices=[slot for slot, _ in candidates],
            card_ids=[mon.card_id for _, mon in candidates],
            min_count=1,
            max_count=1,
            prompt="手札に戻すポケモンを選ぶ",
            shuffle_after=False,
            all_card_ids=[mon.card_id for _, mon in candidates],
            custom_data={"mode": "return_to_hand_target"},
        )


@dataclass(frozen=True)
class DamagePerOwnPokemonWithSubtype(Effect):
    """自分の場(バトル+ベンチ)にいる指定サブタイプのポケモンの数だけ追加ダメージ
    (アーゴヨンGXの「ビーストレイド」等、"Ultra Beast"サブタイプで使用)。"""

    base: int
    per_pokemon: int
    subtype: str

    def execute(self, ctx: EffectContext) -> None:
        player = _attacker_player(ctx)
        count = 0
        for mon in player.all_pokemon_in_play():
            card = ctx.card_db.get(mon.card_id)
            if card is not None and self.subtype in card.subtypes:
                count += 1
        DealDamage(self.base + self.per_pokemon * count).execute(ctx)


@dataclass(frozen=True)
class DamagePerOwnPokemonWithNamePrefix(Effect):
    """自分の場(バトル+ベンチ)にいる、カード名が指定の接頭辞で始まるポケモンの数だけ追加ダメージ
    (ロケット団のワナイダーの「ロケットラッシュ」等、"Team Rocket's"のような名前接頭辞で数えるカード用)。
    also_count_card_ids: card_db上の名前が英語化されておらず接頭辞チェックに引っかからないカード
    (ロケット団のワナイダー(sv10a-9)自身等)を、card_idで明示的に追加カウントするための例外リスト。"""

    base: int
    per_pokemon: int
    name_prefix: str
    also_count_card_ids: frozenset[str] = frozenset()

    def execute(self, ctx: EffectContext) -> None:
        player = _attacker_player(ctx)
        count = 0
        for mon in player.all_pokemon_in_play():
            if mon.card_id in self.also_count_card_ids:
                count += 1
                continue
            card = ctx.card_db.get(mon.card_id)
            if card is not None and card.name.startswith(self.name_prefix):
                count += 1
        DealDamage(self.base + self.per_pokemon * count).execute(ctx)


# ---- GXワザ/VSTARパワー(1ゲームに1回制限)向けに追加したプリミティブ ----


@dataclass(frozen=True)
class ReturnSelfToHand(Effect):
    """自分自身(バトル場にいる場合のみ)をついているカードごと手札に戻す(デデンネGXの「じゃれあいリターンGX」等)。

    バトル場が空になるため、ベンチがある場合のみ使用可能とする。
    """

    def execute(self, ctx: EffectContext) -> None:
        if ctx.source_pokemon is None:
            return
        player = _attacker_player(ctx)
        if player.active is not ctx.source_pokemon or not player.bench:
            return
        mon = player.active
        player.active = None
        player.hand.extend(mon.evolution_history)
        player.hand.append(mon.card_id)
        player.hand.extend(mon.attached_energy)
        if mon.attached_tool:
            player.hand.append(mon.attached_tool)


@dataclass(frozen=True)
class ApplyDamageReductionToSelf(Effect):
    """相手の次の番の間、自分自身が受けるダメージをN軽減する(ヒスイヌメルゴンVSTARの「ローリングアイアン」等)。"""

    amount: int

    def execute(self, ctx: EffectContext) -> None:
        if ctx.source_pokemon is None:
            return
        opponent = ctx.state.player(ctx.opponent)
        ctx.source_pokemon.damage_reduction_amount = self.amount
        ctx.source_pokemon.damage_reduction_until_turn = opponent.turns_taken + 1


@dataclass(frozen=True)
class DealDamageIgnoringWeaknessResistance(Effect):
    """弱点・抵抗力を無視して固定ダメージを与える(アーゴヨンGXの「ジェットニードル」等)。
    ignore_defender_effects=Trueなら、相手のバトルポケモンにかかっている他の効果(シールド・ダメージ軽減等)も
    すべて無視する(コバルオンEXの「Steel Bullet」: "isn't affected by Weakness, Resistance, or any other
    effects on the Defending Pokémon")。"""

    amount: int
    ignore_defender_effects: bool = False

    def execute(self, ctx: EffectContext) -> None:
        if ctx.source_pokemon is None:
            return
        _, defender = _defender(ctx)
        if defender is None or (not self.ignore_defender_effects and _defender_is_shielded(ctx, defender)):
            return
        defender_card = ctx.card_db.get(defender.card_id)
        if defender_card is None:
            return
        dmg = resolve_attack_damage(
            ctx, defender, defender_card, self.amount, apply_weakness=False, apply_resistance=False,
            apply_defender_side_effects=not self.ignore_defender_effects,
        )
        defender.damage += dmg
        ctx.damage_dealt += dmg


@dataclass(frozen=True)
class DamageIfBecameActiveThisTurn(Effect):
    """このポケモンが今の自分の番にベンチからバトル場に出ていれば追加ダメージ
    (ガチガチンGXの「First Impression」/れんげきウーラオスVMAXの「Gale Thrust」)。"""

    base: int
    bonus: int

    def execute(self, ctx: EffectContext) -> None:
        if ctx.source_pokemon is None:
            return
        player = _attacker_player(ctx)
        bonus = self.bonus if ctx.source_pokemon.became_active_turn == player.turns_taken else 0
        DealDamage(self.base + bonus).execute(ctx)


@dataclass(frozen=True)
class DamageAndStatusIfBecameActiveThisTurn(Effect):
    """このポケモンが今の自分の番にベンチからバトル場に出ていれば、追加ダメージと相手への特殊状態を
    両方まとめて適用する(カプ・ライチュウ&アローラライチュウGXの「Tandem Shock」等。
    DamageIfBecameActiveThisTurnと違い、特殊状態も同じ条件に紐づく点が異なる)。"""

    base: int
    bonus: int
    status: str

    def execute(self, ctx: EffectContext) -> None:
        if ctx.source_pokemon is None:
            return
        player = _attacker_player(ctx)
        if ctx.source_pokemon.became_active_turn == player.turns_taken:
            DealDamage(self.base + self.bonus).execute(ctx)
            InflictStatusOnDefender(self.status).execute(ctx)
        else:
            DealDamage(self.base).execute(ctx)


@dataclass(frozen=True)
class DamageIfEvolvedThisTurn(Effect):
    """このポケモンが今の自分の番に進化していれば追加ダメージ(Gholdengoの「Strike It Rich」等)。
    turn_playedはたねポケモンが場に出たときにも更新されるが、進化ポケモン専用のワザにのみ
    使う想定のため「このターンに進化した」の判定として問題ない。"""

    base: int
    bonus: int

    def execute(self, ctx: EffectContext) -> None:
        if ctx.source_pokemon is None:
            DealDamage(self.base).execute(ctx)
            return
        player = _attacker_player(ctx)
        bonus = self.bonus if ctx.source_pokemon.turn_played == player.turns_taken else 0
        DealDamage(self.base + bonus).execute(ctx)


@dataclass(frozen=True)
class DamageIfEvolvedFromNamedThisTurn(Effect):
    """このポケモンが今の自分の番に、指定した名前のポケモンから進化していれば追加ダメージ
    (マグネッスの「アッパースパーク」実カードテキスト: "If this Pokémon evolved from Magneton
    during this turn, this attack does 120 more damage."用。DamageIfEvolvedThisTurnと異なり、
    「このターンに進化したか」だけでなく進化元の名前まで一致するかを見る(ふしぎなアメ等で
    Magneton以外から直接進化した場合はボーナスが乗らない)。"""

    base: int
    bonus: int
    from_name: str

    def execute(self, ctx: EffectContext) -> None:
        if ctx.source_pokemon is None:
            DealDamage(self.base).execute(ctx)
            return
        player = _attacker_player(ctx)
        evolved_this_turn = ctx.source_pokemon.turn_played == player.turns_taken
        from_correct_name = False
        if evolved_this_turn and ctx.source_pokemon.evolution_history:
            prev_card = ctx.card_db.get(ctx.source_pokemon.evolution_history[-1])
            from_correct_name = prev_card is not None and prev_card.name == self.from_name
        DealDamage(self.base + (self.bonus if from_correct_name else 0)).execute(ctx)


@dataclass(frozen=True)
class DealDamageWithSelfDebuffNextTurn(Effect):
    """通常はbase_amountのダメージ。直前の自分の番でこのワザを使っていれば(デバフがかかっていれば)
    debuff_amountのダメージになる。使うたびに次の自分の番までデバフがかかり続ける
    (マギアナEXの「Soul Blaster」: 使うと次の自分の番はダメージが下がる)。"""

    base_amount: int
    debuff_amount: int

    def execute(self, ctx: EffectContext) -> None:
        if ctx.source_pokemon is None:
            return
        mon = ctx.source_pokemon
        player = _attacker_player(ctx)
        debuffed = mon.damage_debuff_until_turn > 0 and player.turns_taken <= mon.damage_debuff_until_turn
        amount = self.debuff_amount if debuffed else self.base_amount
        DealDamage(amount).execute(ctx)
        mon.damage_debuff_until_turn = player.turns_taken + 1


@dataclass(frozen=True)
class DealDamageIgnoringWeaknessOnly(Effect):
    """弱点のみを無視してダメージを与える(抵抗力・その他の継続効果は通常通り適用する。
    ウッウの「Spit Innocently」)。"""

    amount: int

    def execute(self, ctx: EffectContext) -> None:
        if ctx.source_pokemon is None:
            return
        _, defender = _defender(ctx)
        if defender is None or _defender_is_shielded(ctx, defender):
            return
        attacker_card = ctx.card_db.get(ctx.source_pokemon.card_id)
        defender_card = ctx.card_db.get(defender.card_id)
        if attacker_card is None or defender_card is None:
            return
        dmg = resolve_attack_damage(ctx, defender, defender_card, self.amount, apply_weakness=False)
        defender.damage += dmg
        ctx.damage_dealt += dmg


@dataclass(frozen=True)
class DealDamageIgnoringAllDefenderEffects(Effect):
    """相手のバトルポケモンの効果(弱点・抵抗力・ダメージ軽減・シールド等)を一切無視して
    固定ダメージを与える(ミュウVMAXの「Max Miracle」/ギラティナVの「Shred」/
    ヒスイヌメルゴンVの「Close-Quarters Shooting」)。"""

    amount: int

    def execute(self, ctx: EffectContext) -> None:
        # 実カードテキスト: "This attack's damage isn't affected by any effects on the Defending Pokémon."
        # 弱点・抵抗力は「効果」ではなくダメージ計算の手順3・4そのものなので通常通り適用し、攻撃側の
        # 常時効果(げんきのハチマキ等)も通常通り乗る。以前は固定値をそのまま与えており、弱点・抵抗力と
        # 攻撃側のボーナスまで無視していた誤りを訂正(2026-10-06、DealDamageIgnoringDefenderShieldAndReduction
        # (ミュウツーGXの「Psystrike-GX」)と同じ処理に統一)。
        DealDamageIgnoringDefenderShieldAndReduction(self.amount).execute(ctx)


@dataclass(frozen=True)
class DealDamageIgnoringResistance(Effect):
    """抵抗力のみを無視して弱点は通常通り適用する(ダウンウィングネクロズマGXの「Dark Flash」等)。"""

    amount: int

    def execute(self, ctx: EffectContext) -> None:
        if ctx.source_pokemon is None:
            return
        _, defender = _defender(ctx)
        if defender is None or _defender_is_shielded(ctx, defender):
            return
        attacker_card = ctx.card_db.get(ctx.source_pokemon.card_id)
        defender_card = ctx.card_db.get(defender.card_id)
        if attacker_card is None or defender_card is None:
            return
        dmg = resolve_attack_damage(ctx, defender, defender_card, self.amount, apply_resistance=False)
        defender.damage += dmg
        ctx.damage_dealt += dmg
        ctx.log(f"{ctx.source_card_id} が(抵抗力を無視して) {dmg} ダメージ")


@dataclass(frozen=True)
class DealDamageIgnoringDefenderShieldAndReduction(Effect):
    """相手のバトルポケモンにかかっている効果を一切無視してダメージを与える(ミュウツーGXの
    「Psystrike-GX」実カードテキスト: "This attack's damage isn't affected by any effects on
    your opponent's Active Pokémon."。弱点・抵抗力はポケモンにかかっている「効果」ではなく手順3・4の
    計算そのものなので通常通り適用する。どうぐによる軽減・シールド・完全免疫・耐久どうぐ等、
    _apply_defender_side_damage_modifiers内の判定はすべて対象ポケモンにかかっている効果であるため
    まとめてスキップする)。"""

    amount: int

    def execute(self, ctx: EffectContext) -> None:
        if ctx.source_pokemon is None:
            return
        _, defender = _defender(ctx)
        if defender is None:
            return
        attacker_card = ctx.card_db.get(ctx.source_pokemon.card_id)
        defender_card = ctx.card_db.get(defender.card_id)
        if attacker_card is None or defender_card is None:
            return
        dmg = resolve_attack_damage(ctx, defender, defender_card, self.amount, apply_defender_side_effects=False)
        defender.damage += dmg
        ctx.damage_dealt += dmg
        ctx.log(f"{ctx.source_card_id} が(相手のバトルポケモンにかかっている効果を無視して) {dmg} ダメージ")


@dataclass(frozen=True)
class DealDamagePerOpponentPokemonWithSubtype(Effect):
    """相手の場にいる指定サブタイプ(ex等)のポケモンの数×per_pokemonダメージ(ノココッチexの
    「Tenacious Tail」等)。通常のワザダメージとして弱点・抵抗力を適用する。"""

    per_pokemon: int
    subtype: str

    def execute(self, ctx: EffectContext) -> None:
        opponent = ctx.state.player(ctx.opponent)
        count = sum(
            1
            for mon in opponent.all_pokemon_in_play()
            if (card := ctx.card_db.get(mon.card_id)) is not None and self.subtype in card.subtypes
        )
        DealDamage(self.per_pokemon * count).execute(ctx)


@dataclass(frozen=True)
class DealDamageToAllOpponentGxExPokemon(Effect):
    """相手の場のGX/EXポケモン全員に固定ダメージ(ネクロズマGXの「Black Ray-GX」等)。
    弱点・抵抗力は計算しない。"""

    amount: int
    subtypes: tuple[str, ...] = ("GX", "EX")

    def execute(self, ctx: EffectContext) -> None:
        opponent = ctx.state.player(ctx.opponent)
        subtype_set = set(self.subtypes)
        for mon in opponent.all_pokemon_in_play():
            card = ctx.card_db.get(mon.card_id)
            if card is None or not (subtype_set & set(card.subtypes)):
                continue
            if _defender_is_shielded(ctx, mon):
                continue
            dmg = resolve_attack_damage(ctx, mon, card, self.amount, apply_weakness=False, apply_resistance=False)
            mon.damage += dmg
            ctx.damage_dealt += dmg
        ctx.log(f"{ctx.source_card_id} が 相手の場のGX/EXポケモン全員に{self.amount}ダメージ")


@dataclass(frozen=True)
class DiscardOwnEnergyTypeThenBonusDamage(Effect):
    """自分についている指定タイプのエネルギーを全て捨て、捨てた枚数ぶんボーナスダメージを追加する
    (ネクロズマGXの「Prismatic Burst」等)。"""

    base: int
    energy_type: str
    bonus_per_card: int

    def execute(self, ctx: EffectContext) -> None:
        if ctx.source_pokemon is None:
            return
        discarded = [
            e
            for e in ctx.source_pokemon.attached_energy
            if (card := ctx.card_db.get(e)) is not None and card.basic_energy_type == self.energy_type
        ]
        for energy_id in discarded:
            ctx.source_pokemon.attached_energy.remove(energy_id)
        _attacker_player(ctx).discard.extend(discarded)
        DealDamage(self.base + self.bonus_per_card * len(discarded)).execute(ctx)


@dataclass(frozen=True)
class DiscardUpToOwnEnergyThenBonusDamage(Effect):
    """自分についている指定タイプのエネルギーを最大max_count枚まで(ついている分だけ、無ければ0枚)
    自動で捨て、固定ボーナスダメージを追加する(メタグロスの「Metallic Hammer」実カードテキスト:
    "You may discard 3 Metal Energy from this Pokémon and have this attack do 150 more damage."用)。
    「してもよい」自体の意思確認はAFTER_ATTACK_TRIGGER_EFFECTS(AcceptTrigger/DeclineTrigger、
    engine.rules_engineの「ワザ後の『してもよい』」機構)側で行うため、ここでは「使う」を選んだ
    後の確定処理のみを行う。捨てる枚数分はどれも同じ種類で区別する意味が無いため、個別の
    カードを選ばせず自動で捨てる。
    2026-08-26: 以前はPendingSearchChoiceで「どのエネルギーを捨てるか」を1枚ずつ選ばせていたが、
    ユーザーから「のぞむかのぞまないかだけの選択でいい」との指摘を受け、この形に変更した。
    また公式サイトFAQ(「鋼エネルギーがついていないヤドキングのワザ「ひらめきチャレンジ」の
    効果で、メタグロスのワザ「メタリックハンマー」をえらんで使い…「150」ダメージを追加する
    ことはできますか?」→「はい、できます。」)の通り、対象タイプのエネルギーが1枚も無くても
    (0枚捨てて)ボーナスは適用される。"""

    energy_type: str
    max_count: int
    bonus: int

    def execute(self, ctx: EffectContext) -> None:
        if ctx.source_pokemon is None:
            return
        matching = [
            e
            for e in ctx.source_pokemon.attached_energy
            if (card := ctx.card_db.get(e)) is not None and card.basic_energy_type == self.energy_type
        ]
        discard_ids = matching[: self.max_count]
        for energy_id in discard_ids:
            ctx.source_pokemon.attached_energy.remove(energy_id)
        _attacker_player(ctx).discard.extend(discard_ids)
        DealDamage(self.bonus).execute(ctx)


@dataclass(frozen=True)
class DiscardAllOwnEnergyThenBonusDamage(Effect):
    """DiscardUpToOwnEnergyThenBonusDamageと同じAFTER_ATTACK_TRIGGER「してもよい」機構だが、
    種類を問わずついているエネルギーを全て捨てる版(メガマニューラex「Riotous Blasting」実カード
    テキスト: "You may discard all Energy from this Pokémon and have this attack do 130 more
    damage."用)。"""

    bonus: int

    def execute(self, ctx: EffectContext) -> None:
        if ctx.source_pokemon is None:
            return
        discard_ids = list(ctx.source_pokemon.attached_energy)
        ctx.source_pokemon.attached_energy = []
        _attacker_player(ctx).discard.extend(discard_ids)
        DealDamage(self.bonus).execute(ctx)


@dataclass(frozen=True)
class DamageCountersOnDefenderPerOwnHandCount(Effect):
    """自分の手札の枚数×per_cardぶんのダメカンを相手のバトルポケモンにのせる(フーディンの
    「Powerful Hand」実カードテキスト: "Place 2 damage counters on your opponent's Active Pokémon
    for each card in your hand."用。ダメカン2個=20ダメージなので、ダメージ計算(弱点/抵抗力/シールド等)
    を経由せず直接ダメカンをのせる)。"""

    per_card: int  # ダメカンの個数(1個=10ダメージ)

    def execute(self, ctx: EffectContext) -> None:
        player = _attacker_player(ctx)
        _, defender = _defender(ctx)
        if defender is None or _defender_blocks_non_damage_effects(ctx, defender) or _defender_is_shielded(ctx, defender):
            return
        defender.damage += self.per_card * 10 * len(player.hand)


@dataclass(frozen=True)
class KnockOutDefenderIfExactDamageCounters(Effect):
    """相手のバトルポケモンにのっているダメカンがちょうどN個なら、そのポケモンをきぜつさせる
    (メガアブソルexの「Terminal Period」実カードテキスト: "If your opponent's Active Pokémon has
    exactly 6 damage counters on it, that Pokémon is Knocked Out."用)。"""

    exact_counters: int

    def execute(self, ctx: EffectContext) -> None:
        _, defender = _defender(ctx)
        if defender is None or _defender_is_shielded(ctx, defender):
            return
        # include_damage_only_immunity=False: この効果はダメージを与えず状態異常も付与しない
        # (既にのっているダメカンの数を見て即きぜつさせるだけ)ため、「ダメージのみ」を防ぐ免疫
        # (イワパレスの「Mysterious Rock Inn」等)の対象外(2026-09-14ユーザー報告の実バグ、
        # メガアブソルexの「Terminal Period」がイワパレス相手に一律ブロックされていた)。
        # ばけがくれ等の「ワザ/特性の効果を一切受けない」免疫はこの効果にも引き続き及ぶ。
        if _defender_blocks_non_damage_effects(ctx, defender, include_damage_only_immunity=False):
            return
        if defender.damage == self.exact_counters * 10:
            defender.damage = 9999


@dataclass(frozen=True)
class RevealOpponentHandThenDiscardChosen(Effect):
    """相手の手札を公開させ、その中から見つけたカードを選んでトラッシュする(メガアブソルexの
    「Claw of Darkness」実カードテキスト: "Your opponent reveals their hand, and you discard a card
    you find there."用)。count>1のとき「最大count枚まで」選べる(ビワ実カードテキスト: "look at
    your opponent's hand and choose up to 2 Item cards you find there. Discard those cards."用)。
    only_item=Trueならグッズのみが選択対象。"""

    count: int = 1
    only_item: bool = False
    only_trainer: bool = False  # "Discard a Trainer card you find there."(グッズ・サポート・スタジアム・どうぐ)

    def execute(self, ctx: EffectContext) -> None:
        opponent = ctx.state.player(ctx.opponent)
        indices = [
            i
            for i, cid in enumerate(opponent.hand)
            if (not self.only_item or ((c := ctx.card_db.get(cid)) is not None and c.is_item))
            and (not self.only_trainer or ((c := ctx.card_db.get(cid)) is not None and c.is_trainer))
        ]
        if not indices:
            return
        # 実カードテキスト上「相手の手札を公開させ」なので、選択対象を絞る条件(only_item)に
        # 関わらず手札全体が見えている。以後もこのプレイヤーの記憶として保持する(2026-08-20)。
        ctx.state.player(ctx.acting_player).known_opponent_hand = list(opponent.hand)
        ctx.state.pending_search_choice = PendingSearchChoice(
            player_index=ctx.acting_player,
            zone="opponent_hand_to_discard",
            source_indices=indices,
            card_ids=[opponent.hand[i] for i in indices],
            min_count=0 if self.count > 1 else 1,
            max_count=min(self.count, len(indices)),
            prompt=f"相手の手札を公開させ、トラッシュするカードを最大{self.count}枚選ぶ",
            shuffle_after=False,
            all_card_ids=list(opponent.hand),
        )


@dataclass(frozen=True)
class RevealOpponentHandThenChosenToBottomOfDeck(Effect):
    """相手の手札を公開させ、その中から見つけた1枚を選んで相手の山札の下に置く(N's Purrloin
    「Thieving Swipe」実カードテキスト: "Your opponent reveals their hand, and you choose a card
    you find there and put it on the bottom of their deck."用)。"""

    def execute(self, ctx: EffectContext) -> None:
        opponent = ctx.state.player(ctx.opponent)
        if not opponent.hand:
            return
        ctx.state.player(ctx.acting_player).known_opponent_hand = list(opponent.hand)
        ctx.state.pending_search_choice = PendingSearchChoice(
            player_index=ctx.acting_player,
            zone="opponent_hand_to_bottom_of_deck",
            source_indices=list(range(len(opponent.hand))),
            card_ids=list(opponent.hand),
            min_count=1,
            max_count=1,
            prompt="相手の手札を公開させ、山札の下に置くカードを選ぶ",
            shuffle_after=False,
            all_card_ids=list(opponent.hand),
        )


@dataclass(frozen=True)
class DebuffDefenderAttackDamageNextTurn(Effect):
    """相手の次の番の間、相手のバトルポケモンが使うワザのダメージがamountぶん少なくなる(チコリータの
    「Growl」実カードテキスト: "During your opponent's next turn, attacks used by the Defending
    Pokémon do 20 less damage (before applying Weakness and Resistance)."用)。"""

    amount: int

    def execute(self, ctx: EffectContext) -> None:
        _, defender = _defender(ctx)
        if defender is None:
            return
        opponent = ctx.state.player(ctx.opponent)
        defender.outgoing_damage_debuff_until_turn = opponent.turns_taken + 1
        defender.outgoing_damage_debuff_amount = self.amount


@dataclass(frozen=True)
class CopyOpponentActiveAttack(Effect):
    """相手のバトルポケモンが持つワザを1つ選び、このワザとして使う(ロケット団のミミッキュの
    「Gemstone Mimicry」実カードテキスト: "Choose 1 of your opponent's Active Tera Pokémon's attacks
    and use it as this attack."用。required_subtype指定時はその対象限定)。"""

    required_subtype: str | None = None

    def execute(self, ctx: EffectContext) -> None:
        opponent = ctx.state.player(ctx.opponent)
        if opponent.active is None:
            return
        card = ctx.card_db.get(opponent.active.card_id)
        if card is None or not card.attacks:
            return
        if self.required_subtype is not None and self.required_subtype not in card.subtypes:
            return
        _offer_revealed_card_attack_choice(ctx, opponent.active.card_id, card)


@dataclass(frozen=True)
class AttackGateMinNamedPrefixPokemonInPlay(Effect):
    """このEffectはダメージ計算に関わらない: engine.legal_actions側でこのカードの攻撃ゲート条件
    (name_prefixで始まる自分のポケモンがmin_count以上いないと攻撃できない)を表す印として、
    ATTACK_GATE_MIN_NAMED_PREFIX_CARD_IDS辞書に登録して使う(実際のゲート判定はlegal_actions.py側)。"""

    pass


@dataclass(frozen=True)
class DamageIfOwnBenchedNamePrefixInPlayElseZero(Effect):
    """自分のベンチにname_prefixで始まる名前のポケモンがいなければこのワザは不発(ダメージ0)、
    いればamountダメージを与える(ソルロックの「Cosmic Beam」実カードテキスト: "If you don't have
    Lunatone on your Bench, this attack does nothing."用)。ignore_weakness_resistance指定時は
    弱点・抵抗力を計算しない。"""

    amount: int
    name_prefix: str
    ignore_weakness_resistance: bool = False

    def execute(self, ctx: EffectContext) -> None:
        player = _attacker_player(ctx)
        has_partner = any(
            (c := ctx.card_db.get(mon.card_id)) is not None and c.name.startswith(self.name_prefix)
            for mon in player.bench
        )
        if not has_partner:
            return
        if self.ignore_weakness_resistance:
            DealDamageIgnoringWeaknessResistance(self.amount).execute(ctx)
        else:
            DealDamage(self.amount).execute(ctx)


@dataclass(frozen=True)
class DiscardChosenOwnHandSupportersThenScalingDamage(Effect):
    """名前にname_containsを含むサポートカードを手札から好きな枚数選んでトラッシュし、捨てた枚数
    ×damage_perダメージ(ロケット団のドンカラスの「Rocket Feathers」実カードテキスト: "You may
    discard any number of Supporter cards that have 'Team Rocket' in their name from your hand,
    and this attack does 60 damage for each card you discarded in this way."用)。"""

    name_contains: str
    damage_per: int

    def execute(self, ctx: EffectContext) -> None:
        player = _attacker_player(ctx)

        def matches(card):
            return card is not None and card.is_supporter and self.name_contains in card.name

        eligible_indices = [i for i, cid in enumerate(player.hand) if matches(ctx.card_db.get(cid))]
        if not eligible_indices:
            return
        ctx.state.pending_search_choice = PendingSearchChoice(
            player_index=ctx.acting_player,
            zone="hand",
            source_indices=eligible_indices,
            card_ids=[player.hand[i] for i in eligible_indices],
            min_count=0,
            max_count=len(eligible_indices),
            prompt=f"捨てる{self.name_contains}サポートを選ぶ(選ばなくてもよい)",
            shuffle_after=False,
            all_card_ids=[player.hand[i] for i in eligible_indices],
            destination="discard",
            cont_source_pokemon=ctx.source_pokemon,
            cont_source_card_id=ctx.source_card_id,
            # mode="bellowing_thunder"は zone="field_attachment" 専用の別処理(_resolve_field_
            # attachment_choice)でのみ参照される名前で、zone="hand"の選択では一切到達しないため、
            # このワザのダメージが常に発動しない(0ダメージになる)バグだった(2026-08-21発覚)。
            # zone="hand"の選択で実際に参照される、既存の汎用スケーリングダメージmodeを再利用する
            # (中身はカードの種類を問わず「捨てた枚数×damage_per」を計算するだけの汎用ロジック)。
            custom_data={"mode": "discard_hand_energy_scaling_damage", "base": 0, "damage_per": self.damage_per},
        )


@dataclass(frozen=True)
class DamagePerChosenOpponentBenchedDamageCounters(Effect):
    """相手のベンチポケモン1匹を選び、そのポケモンに既にのっているダメカンの個数×per_counter
    ダメージを与える(ロケット団のニューラの「Strike the Sleeper」実カードテキスト: "This attack
    does 20 damage to 1 of your opponent's Benched Pokémon for each damage counter on that Pokémon."
    用、ベンチのため弱点・抵抗力は計算しない)。"""

    per_counter: int

    def execute(self, ctx: EffectContext) -> None:
        opponent = ctx.state.player(ctx.opponent)
        if ctx.target_bench_index is None or not (0 <= ctx.target_bench_index < len(opponent.bench)):
            return
        target = opponent.bench[ctx.target_bench_index]
        counters = target.damage // 10
        if counters <= 0:
            return
        amount = self.per_counter * counters
        target_card = ctx.card_db.get(target.card_id)
        if target_card is None:
            return
        dmg = resolve_attack_damage(ctx, target, target_card, amount, apply_weakness=False, apply_resistance=False)
        target.damage += dmg
        ctx.damage_dealt += dmg


@dataclass(frozen=True)
class MayDiscardOwnHandCardThenOpponentDiscardsOne(Effect):
    """自分の手札から1枚選んでトラッシュしてもよく、そうしたら相手も手札から1枚トラッシュする
    (ロケット団のポリゴンの「Hacking」実カードテキスト: "Discard a card from your hand. If you do,
    your opponent discards a card from their hand."用)。"""

    def execute(self, ctx: EffectContext) -> None:
        player = _attacker_player(ctx)
        if not player.hand:
            return
        ctx.state.pending_search_choice = PendingSearchChoice(
            player_index=ctx.acting_player,
            zone="hand",
            source_indices=list(range(len(player.hand))),
            card_ids=list(player.hand),
            min_count=0,
            max_count=1,
            prompt="捨てるカードを選ぶ(選ばなくてもよい)",
            shuffle_after=False,
            all_card_ids=list(player.hand),
            destination="discard",
        )
        if ctx.state.pending_search_choice is not None:
            ctx.state.pending_search_choice.custom_data = {"mode": "hacking_opponent_discard_one"}


@dataclass(frozen=True)
class DamagePerOwnDiscardSupporterNameContainsCount(Effect):
    """自分のトラッシュにある、名前にname_containsを含むサポートカードの枚数ぶんダメージ
    (ロケット団のポリゴン2の「R Command」実カードテキスト: "This attack does 20 damage for each
    Supporter card that has 'Team Rocket' in its name in your discard pile."用)。"""

    per_card: int
    name_contains: str
    base: int = 0  # エターナル・タイフーンの「Buddy Blast」実カードテキスト: "This attack does 40 more
    # damage for each Ethan's Adventure card in your discard pile."用に基本ダメージ40を追加できるようにした

    def execute(self, ctx: EffectContext) -> None:
        player = _attacker_player(ctx)
        count = sum(
            1
            for cid in player.discard
            if (c := ctx.card_db.get(cid)) is not None and c.is_supporter and self.name_contains in c.name
        )
        DealDamage(self.base + self.per_card * count).execute(ctx)


@dataclass(frozen=True)
class SwitchSelfFromBenchToActive(Effect):
    """ベンチにいる状態で発動する特性で、自分自身をバトル場に出す(ダウンウィングネクロズマGXの
    「Invasion」等)。対象選択は不要(常に自分自身が対象)。"""

    def execute(self, ctx: EffectContext) -> None:
        if ctx.source_pokemon is None:
            return
        player = _attacker_player(ctx)
        if ctx.source_pokemon not in player.bench:
            return
        player.bench.remove(ctx.source_pokemon)
        if player.active is not None:
            player.active.status.clear_all()
            player.bench.append(player.active)
        ctx.source_pokemon.status.clear_all()
        player.active = ctx.source_pokemon


def _attach_found_energies_freely(
    ctx: EffectContext,
    remaining_cards: tuple[str, ...],
    bench_only: bool = False,
    target_pokemon_type: str | None = None,
    basic_stage_only: bool = True,
    then_end_turn: bool = False,
) -> None:
    """山札の上から見つけて手元にある(既にデッキから取り出し済みの)基本エネルギーを1枚ずつ、
    対象を選ばせながら自分のベンチ(等)に「好きなように」つけていく(マックスげんき/
    でんきはっせいき等)。対象が無ければそのカードは山札の一番下に戻してシャッフルする。"""
    if not remaining_cards:
        return
    player = _attacker_player(ctx)
    card_id, rest = remaining_cards[0], remaining_cards[1:]

    def target_ok(mon) -> bool:
        c = ctx.card_db.get(mon.card_id)
        return (
            c is not None
            and (not basic_stage_only or c.is_basic)
            and (target_pokemon_type is None or target_pokemon_type in c.types)
        )

    candidates = [] if bench_only else ([(0, player.active)] if player.active is not None and target_ok(player.active) else [])
    for i, mon in enumerate(player.bench):
        if target_ok(mon):
            candidates.append((i + 1, mon))
    if not candidates:
        player.deck.append(card_id)
        ctx.rng.shuffle(player.deck)
        _attach_found_energies_freely(ctx, rest, bench_only, target_pokemon_type, basic_stage_only, then_end_turn)
        return
    card = ctx.card_db.get(card_id)
    card_label = card.name if card is not None else card_id
    ctx.state.pending_search_choice = PendingSearchChoice(
        player_index=ctx.acting_player,
        zone="own_pokemon_target",
        source_indices=[slot for slot, _ in candidates],
        card_ids=[mon.card_id for _, mon in candidates],
        min_count=1,
        max_count=1,
        prompt=f"{card_label}をつける自分のポケモンを選ぶ",
        shuffle_after=False,
        all_card_ids=[mon.card_id for _, mon in candidates],
        cont_source_pokemon=ctx.source_pokemon,
        cont_source_card_id=ctx.source_card_id,
        then_end_turn=then_end_turn,
        custom_data={
            "mode": "attach_found_energy_pick_target",
            "card_id": card_id,
            "rest": list(rest),
            "bench_only": bench_only,
            "target_pokemon_type": target_pokemon_type,
            "basic_stage_only": basic_stage_only,
            "then_end_turn": then_end_turn,
        },
    )


@dataclass(frozen=True)
class LookTopNAttachBasicEnergyToChosenBench(Effect):
    """山札の上からN枚を見て、見つけた基本エネルギーを最大count枚、ベンチのたねポケモンに
    「好きなように」つける(マックスげんき(Max Elixir)、でんきはっせいき(Electric Generator)実
    カードテキスト: "attach ... Energy cards you find there to your Benched ... Pokémon in any way
    you like"、見つかった枚数がcountを超えるならどれを使うかも選ぶ)。energy_type指定時はそのタイプの
    基本エネルギー限定、target_pokemon_type指定時はつける先もそのタイプのベンチポケモン限定。
    見た残りは"Shuffle the other cards back into your deck"の通り、山札に戻してシャッフルする。"""

    n: int
    count: int = 1
    energy_type: str | None = None
    target_pokemon_type: str | None = None
    basic_stage_only: bool = True

    def execute(self, ctx: EffectContext) -> None:
        player = _attacker_player(ctx)
        top = player.deck[: self.n]
        tail = player.deck[self.n :]

        def matches_energy(cid: str) -> bool:
            card = ctx.card_db.get(cid)
            return card is not None and card.basic_energy_type is not None and (
                self.energy_type is None or card.basic_energy_type == self.energy_type
            )

        eligible_positions = [i for i, cid in enumerate(top) if matches_energy(cid)]
        non_eligible = [cid for i, cid in enumerate(top) if i not in eligible_positions]

        def has_bench_target() -> bool:
            return any(
                (card := ctx.card_db.get(mon.card_id)) is not None
                and (not self.basic_stage_only or card.is_basic)
                and (self.target_pokemon_type is None or self.target_pokemon_type in card.types)
                for mon in player.bench
            )

        if not eligible_positions or not has_bench_target():
            player.deck = tail + top
            ctx.rng.shuffle(player.deck)
            ctx.log(f"{ctx.source_card_id}: 山札の上から{len(top)}枚を見たが、条件に合う組み合わせが無かった")
            return

        if len(eligible_positions) <= self.count:
            taken = tuple(top[i] for i in eligible_positions)
            player.deck = tail + non_eligible
            ctx.rng.shuffle(player.deck)
            _attach_found_energies_freely(
                ctx, taken, bench_only=True, target_pokemon_type=self.target_pokemon_type,
                basic_stage_only=self.basic_stage_only,
            )
            return

        player.deck = list(tail)
        ctx.state.pending_search_choice = PendingSearchChoice(
            player_index=ctx.acting_player,
            zone="deck_top_n_energy_take",
            source_indices=eligible_positions,
            card_ids=[top[i] for i in eligible_positions],
            min_count=0,
            max_count=self.count,
            prompt=f"山札の上から見つけた基本エネルギーから、つける{self.count}枚を選ぶ",
            shuffle_after=False,
            all_card_ids=[top[i] for i in eligible_positions],
            custom_data={
                "mode": "look_top_n_energy_take",
                "non_eligible": non_eligible,
                "bench_only": True,
                "target_pokemon_type": self.target_pokemon_type,
                "basic_stage_only": self.basic_stage_only,
            },
        )


@dataclass(frozen=True)
class SearchDiscardForEnergyAttachToSelfCountEqualOpponentPokemon(Effect):
    """トラッシュから指定タイプの基本エネルギーを、相手の場のポケモンの数ぶん、自分のポケモンに
    「好きなように」つける(ルナアーラ◇の「Full Moon Star」実カードテキスト: "For each of your
    opponent's Pokémon in play, attach a [Type] Energy card from your discard pile to your
    Pokémon in any way you like."。1匹にまとめても、複数匹に分けてもよい)。"""

    energy_type: str

    def execute(self, ctx: EffectContext) -> None:
        opponent = ctx.state.player(ctx.opponent)
        count = len(opponent.all_pokemon_in_play())
        _attach_discard_energy_freely(ctx, count, energy_type=self.energy_type)


@dataclass(frozen=True)
class ApplyShieldToSelf(Effect):
    """相手の次の番の間、自分自身(このワザを使ったポケモン)はワザの効果(ダメージ含む)を受けなくなる
    (ジラーチGXの「スターシールドGX」等)。"""

    def execute(self, ctx: EffectContext) -> None:
        if ctx.source_pokemon is None:
            return
        opponent = ctx.state.player(ctx.opponent)
        ctx.source_pokemon.shielded_until_turn = opponent.turns_taken + 1


@dataclass(frozen=True)
class ApplyScopedDamageImmunityToSelf(Effect):
    """相手の次の番の間、自分自身は指定した種類のポケモンのワザによるダメージを受けなくなる
    (ジョルテオンEXの「Flash Ray」=scope"basic"、グレイシアEXの「Crystal Ray」=scope"evolution"、
    ジガルデGXの「Verdict-GX」/そらとぶピカチュウVMAXの「Max Balloon」=scope"gx_ex"/"basic"等)。"""

    scope: str

    def execute(self, ctx: EffectContext) -> None:
        if ctx.source_pokemon is None:
            return
        opponent = ctx.state.player(ctx.opponent)
        ctx.source_pokemon.damage_immunity_until_turn = opponent.turns_taken + 1
        ctx.source_pokemon.damage_immunity_scope = self.scope


@dataclass(frozen=True)
class PreventPrizesIfKnockedOutNextTurn(Effect):
    """相手の次の番の間にこのポケモンがきぜつしても、相手はサイドを取れない
    (ポイポル(FLI版)の「Knockout Reviver」)。"""

    def execute(self, ctx: EffectContext) -> None:
        if ctx.source_pokemon is None:
            return
        opponent = ctx.state.player(ctx.opponent)
        ctx.source_pokemon.no_prize_on_ko_until_turn = opponent.turns_taken + 1


@dataclass(frozen=True)
class ActivatePermanentMetalDamageReduction(Effect):
    """今後ずっと、自分の鋼ポケモンが相手のワザから受けるダメージを30軽減する
    (ルカリオ&メルメタルGXの「フルメタルウォールGX」等)。ApplyDamageReductionToSelf等の
    ターン限定軽減と異なりゲーム終了まで継続するため、PlayerState側の永続フラグとして持つ。"""

    def execute(self, ctx: EffectContext) -> None:
        _attacker_player(ctx).metal_damage_reduction_active = True


@dataclass(frozen=True)
class IfDamageDealt(Effect):
    """このワザで(シールド等に防がれず)実際にダメージが通っていればthenを実行する
    (フシギダネの「やどりぎのタネ」の「ダメージを防げなかった場合のみ」等)。"""

    then: tuple[Effect, ...]

    def execute(self, ctx: EffectContext) -> None:
        if ctx.damage_dealt <= 0:
            return
        for effect in self.then:
            effect.execute(ctx)


@dataclass(frozen=True)
class IfLastDiscardSucceeded(Effect):
    """直前の手札コスト捨て系Effect(DiscardEnergyFromHand等)が実際に何か捨てられていればthenを
    実行する(レントラーGLの「Trash Bolt」の「手札から捨てられなければ何も起こらない」)。"""

    then: tuple[Effect, ...]

    def execute(self, ctx: EffectContext) -> None:
        if not ctx.last_discard_succeeded:
            return
        for effect in self.then:
            effect.execute(ctx)


@dataclass(frozen=True)
class IfLastAttachSucceeded(Effect):
    """直前のエネルギー添付系Effect(AttachEnergyFromDiscardToOwnPokemon等)が実際に何かをつけて
    いればthenを実行する(カイの「Raihan」/メロン「Melony」の「もしついたら〜」条件)。"""

    then: tuple[Effect, ...]

    def execute(self, ctx: EffectContext) -> None:
        if not ctx.last_attach_succeeded:
            return
        for effect in self.then:
            effect.execute(ctx)


@dataclass(frozen=True)
class IfExtraEnergyAttached(Effect):
    """このワザ自身のコスト分を除いて、ついているエネルギーがextra_needed枚以上あればthenを実行する
    (GXワザの「追加でN個ついていれば〜」条件全般に対応。energy_type指定時はそのタイプのみ数える)。"""

    own_cost_count: int
    extra_needed: int
    then: tuple[Effect, ...]
    energy_type: str | None = None

    def execute(self, ctx: EffectContext) -> None:
        if ctx.source_pokemon is None:
            return
        if self.energy_type:
            count = sum(
                1
                for e in ctx.source_pokemon.attached_energy
                if ctx.card_db.get(e) and ctx.card_db.get(e).basic_energy_type == self.energy_type
            )
        else:
            count = len(ctx.source_pokemon.attached_energy)
        extra = max(0, count - self.own_cost_count)
        if extra >= self.extra_needed:
            for effect in self.then:
                effect.execute(ctx)


@dataclass(frozen=True)
class RandomPrizeDiscardAttachIfEnergyToSelf(Effect):
    """自分のサイドを1枚(裏向きのためランダムに)トラッシュし、それがエネルギーカードなら自分の場から
    選んだ1匹につける(ズガドーンGXの「バーストGX」等)。対象選択はzone="own_pokemon_target"
    (mode="attach_specific_card_to_target")をengine.rules_engine側が解決する。"""

    def execute(self, ctx: EffectContext) -> None:
        if ctx.source_pokemon is None:
            return
        player = _attacker_player(ctx)
        if not player.prizes:
            return
        idx = ctx.rng.randrange(len(player.prizes))
        card_id = player.take_prize(idx)
        card = ctx.card_db.get(card_id)
        if card is None or not card.is_energy:
            player.discard.append(card_id)
            ctx.log("サイドを1枚トラッシュした")
            return
        candidates = []
        if player.active is not None:
            candidates.append((0, player.active))
        for i, mon in enumerate(player.bench):
            candidates.append((i + 1, mon))
        if not candidates:
            player.discard.append(card_id)
            ctx.log(f"サイドの{card.name}をつけるポケモンがいないためトラッシュした")
            return
        ctx.state.pending_search_choice = PendingSearchChoice(
            player_index=ctx.acting_player,
            zone="own_pokemon_target",
            source_indices=[slot for slot, _ in candidates],
            card_ids=[mon.card_id for _, mon in candidates],
            min_count=1,
            max_count=1,
            prompt=f"サイドの{card.name}をつけるポケモンを選ぶ",
            shuffle_after=False,
            all_card_ids=[mon.card_id for _, mon in candidates],
            custom_data={"mode": "attach_specific_card_to_target", "card_id": card_id},
        )


@dataclass(frozen=True)
class ResetBothPlayersPrizes(Effect):
    """両プレイヤーがサイドを山札に戻してシャッフルし、山札の上からN枚を新たなサイドにする
    (アーゴヨンGXの「スティンガーGX」等)。"""

    count: int

    def execute(self, ctx: EffectContext) -> None:
        for player_index in (ctx.acting_player, ctx.opponent):
            player = ctx.state.player(player_index)
            player.deck.extend(player.prizes)
            player.prizes = []
            ctx.rng.shuffle(player.deck)
            player.prizes = player.deck[: self.count]
            player.reset_prize_marks()
            player.deck = player.deck[self.count :]
        ctx.log("両者のサイドをリセットした")


@dataclass(frozen=True)
class LockOpponentAttackNextTurn(Effect):
    """相手の次の番、相手はワザを使えなくなる(コバルオンGXの「アイアンルールGX」等)。"""

    def execute(self, ctx: EffectContext) -> None:
        opponent = ctx.state.player(ctx.opponent)
        opponent.attack_locked_until_turn = opponent.turns_taken + 1


@dataclass(frozen=True)
class LockOpponentGXAttacksForRestOfGame(Effect):
    """このゲームの残り、相手はGXワザを一切使えなくなる(ラティオスGXの「Clear Vision-GX」実カード
    テキスト: "For the rest of this game, your opponent can't use any GX attacks."用)。"""

    def execute(self, ctx: EffectContext) -> None:
        ctx.state.player(ctx.opponent).gx_attacks_locked = True


@dataclass(frozen=True)
class LockChosenOpponentAttackNextTurn(Effect):
    """相手のバトルポケモンが持つワザの中から選んだ1つを、相手の次の番の間だけ使えなくする
    (ラルトスの「Memory Skip」等)。ctx.target_bench_indexを「相手のバトルポケモンのワザ一覧の
    インデックス」として流用する(このワザ自体はベンチを対象にしないため空いている枠)。"""

    def execute(self, ctx: EffectContext) -> None:
        opponent = ctx.state.player(ctx.opponent)
        if opponent.active is None or ctx.target_bench_index is None:
            return
        card = ctx.card_db.get(opponent.active.card_id)
        if card is None or not (0 <= ctx.target_bench_index < len(card.attacks)):
            return
        chosen = card.attacks[ctx.target_bench_index]
        opponent.active.locked_attack_name = chosen.name
        opponent.active.locked_attack_until_turn = opponent.turns_taken + 1
        ctx.log(f"相手の「{chosen.name}」を次の相手の番は使えなくした")


@dataclass(frozen=True)
class DisableDefenderAttackNextTurn(Effect):
    """相手の次の番、このワザを受けたポケモン自身が攻撃できなくなる(アイアンバンドルの「冷凍ストリーム」等)。
    LockOpponentAttackNextTurn(プレイヤー単位)と異なり対象ポケモン自身のみを縛るため、
    にげて交代すれば新しいバトルポケモンは通常通り攻撃できる。"""

    def execute(self, ctx: EffectContext) -> None:
        _, defender = _defender(ctx)
        if defender is None:
            return
        opponent = ctx.state.player(ctx.opponent)
        defender.attack_disabled_until_turn = opponent.turns_taken + 1


@dataclass(frozen=True)
class SetSelfRetaliateOnDamagedNextTurn(Effect):
    """相手の次の番、このポケモンがワザのダメージを受けたら(きぜつしても)攻撃したポケモンに
    ダメカンをのせる(テツノイサハexの「Repulsor Axe」)。"""

    counters: int

    def execute(self, ctx: EffectContext) -> None:
        if ctx.source_pokemon is None:
            return
        opponent = ctx.state.player(ctx.opponent)
        ctx.source_pokemon.retaliate_on_damaged_until_turn = opponent.turns_taken + 1
        ctx.source_pokemon.retaliate_on_damaged_counters = self.counters


@dataclass(frozen=True)
class DisableDefenderRetreatNextTurn(Effect):
    """相手の次の番、このワザを受けたポケモン自身がにげられなくなる(デスクノアの「Shadow Bind」、
    アグノムの「ロックアップ」等)。"""

    def execute(self, ctx: EffectContext) -> None:
        _, defender = _defender(ctx)
        if defender is None:
            return
        opponent = ctx.state.player(ctx.opponent)
        defender.retreat_disabled_until_turn = opponent.turns_taken + 1


@dataclass(frozen=True)
class LockOpponentItemsNextTurn(Effect):
    """相手の次の番、相手はグッズを使えなくなる(ヒルドの「オーシャンカース」、スボミーの
    「かゆいかふん」等)。"""

    def execute(self, ctx: EffectContext) -> None:
        opponent = ctx.state.player(ctx.opponent)
        opponent.items_locked_until_turn = opponent.turns_taken + 1


@dataclass(frozen=True)
class DamageIfDefenderHasTool(Effect):
    """相手のバトルポケモンにポケモンのどうぐがついていれば追加ダメージ(ライボルトEXの
    「アサルトレーザー」等)。"""

    base: int
    bonus: int

    def execute(self, ctx: EffectContext) -> None:
        _, defender = _defender(ctx)
        bonus = self.bonus if (defender is not None and defender.attached_tool is not None) else 0
        DealDamage(self.base + bonus).execute(ctx)


@dataclass(frozen=True)
class DamageIfDefenderHasSubtype(Effect):
    """相手のバトルポケモンが指定サブタイプ(Ultra Beast等)を持っていれば追加ダメージ
    (マーシャドウの「Red Knuckles」等)。"""

    base: int
    bonus: int
    subtype: str

    def execute(self, ctx: EffectContext) -> None:
        _, defender = _defender(ctx)
        defender_card = ctx.card_db.get(defender.card_id) if defender is not None else None
        bonus = self.bonus if (defender_card is not None and self.subtype in defender_card.subtypes) else 0
        DealDamage(self.base + bonus).execute(ctx)


@dataclass(frozen=True)
class DamageIfDefenderHasSubtypeIgnoringWeaknessResistance(Effect):
    """相手のバトルポケモンが指定サブタイプ(EX等)を持っていなければ何もしない。持っていれば、
    弱点・抵抗力を無視して固定ダメージを与える(ルチャブルの特性「Shining Spirit」+ワザ
    「フライングプレス」の組み合わせ)。"""

    amount: int
    subtype: str

    def execute(self, ctx: EffectContext) -> None:
        _, defender = _defender(ctx)
        defender_card = ctx.card_db.get(defender.card_id) if defender is not None else None
        if defender_card is None or self.subtype not in defender_card.subtypes:
            return
        DealDamageIgnoringWeaknessResistance(self.amount).execute(ctx)


@dataclass(frozen=True)
class SearchDeckForSameNamePokemonToHand(Effect):
    """自分の場にいるポケモンと同じ名前のポケモンを1匹、山札から手札に加える(リピートボール)。
    候補が複数あれば_trigger_search_choice経由でプレイヤーが選ぶ。"""

    def execute(self, ctx: EffectContext) -> None:
        player = _attacker_player(ctx)
        in_play_names = {
            c.name for mon in player.all_pokemon_in_play() if (c := ctx.card_db.get(mon.card_id)) is not None
        }

        def matches(card):
            return card is not None and card.is_pokemon and card.name in in_play_names

        _trigger_search_choice(ctx, player, "deck", matches, 1, "場のポケモンと同じ名前のポケモンを山札から探す")


@dataclass(frozen=True)
class DamageIfOwnEnergyTypeCountInPlayAtLeast(Effect):
    """自分の場(バトル+ベンチ全体)についている指定タイプの基本エネルギーがthreshold枚以上あれば
    追加ダメージ(ボルケニオンの「High-Heat Blast」等)。"""

    base: int
    bonus: int
    energy_type: str
    threshold: int

    def execute(self, ctx: EffectContext) -> None:
        player = _attacker_player(ctx)
        count = 0
        for mon in player.all_pokemon_in_play():
            for energy_id in mon.attached_energy:
                energy_card = ctx.card_db.get(energy_id)
                if energy_card is not None and energy_card.basic_energy_type == self.energy_type:
                    count += 1
        bonus = self.bonus if count >= self.threshold else 0
        DealDamage(self.base + bonus).execute(ctx)


@dataclass(frozen=True)
class DamageIfOwnPokemonKnockedOutLastOpponentTurn(Effect):
    """直前の相手の番に自分のポケモンが相手のワザできぜつしていれば追加ダメージ
    (ドクロッグGの「毒リベンジ」、パオジアンexの「Megafire of Envy」等)。"""

    base: int
    bonus: int

    def execute(self, ctx: EffectContext) -> None:
        player = _attacker_player(ctx)
        bonus = self.bonus if player.pokemon_ko_by_attack_last_turn else 0
        DealDamage(self.base + bonus).execute(ctx)


@dataclass(frozen=True)
class IfOwnPokemonKnockedOutLastOpponentTurn(Effect):
    """直前の相手の番に自分のポケモンが相手のワザできぜつしていればthenを実行する
    (ドクロッグGの「毒リベンジ」のどく付与は追加ダメージと同じ条件)。"""

    then: tuple[Effect, ...]

    def execute(self, ctx: EffectContext) -> None:
        player = _attacker_player(ctx)
        if not player.pokemon_ko_by_attack_last_turn:
            return
        for effect in self.then:
            effect.execute(ctx)


@dataclass(frozen=True)
class BonusPrizeIfThisAttackKnockedOutOpponent(Effect):
    """このワザのダメージで相手のポケモンがきぜつした場合、追加でサイドを1枚多く取れる
    (アイアンハンドexの「ばんばんハンド」等)。win_conditions.apply_knockoutsが実際の
    プライズ枚数計算時にこのフラグを読み取って消費する。"""

    bonus: int = 1

    def execute(self, ctx: EffectContext) -> None:
        opponent = ctx.state.player(ctx.opponent)
        for mon in opponent.all_pokemon_in_play():
            max_hp = effective_max_hp(ctx.card_db, mon.card_id, mon.attached_tool, ctx.state.stadium_in_play, mon.attached_energy)
            if max_hp and mon.is_knocked_out(max_hp):
                _attacker_player(ctx).bonus_prize_next_knockout = self.bonus
                return


@dataclass(frozen=True)
class MoveDamageCountersFromAllOwnPokemonToChosenOpponent(Effect):
    """自分の場の全ポケモンから、それぞれダメカンをN個ずつ、選んだ相手のポケモン1匹に移す
    (クレセリアの「Moonglow Reverse」等)。移動先が指定されていなければ何もしない。"""

    count_per_pokemon: int

    def execute(self, ctx: EffectContext) -> None:
        if _damage_counter_relocation_blocked(ctx):
            return  # ミネズミの特性「かんしのめ」
        opponent = ctx.state.player(ctx.opponent)
        target = _resolve_opponent_target(ctx, opponent)
        if target is None or _defender_blocks_non_damage_effects(ctx, target):
            return  # ダメカンをのせる=「効果」のため、ばけがくれ等でブロックされうる
        player = _attacker_player(ctx)
        moved_total = 0
        for mon in player.all_pokemon_in_play():
            move_amount = min(mon.damage, self.count_per_pokemon * 10)
            if move_amount <= 0:
                continue
            mon.remove_counters(move_amount)
            moved_total += move_amount
        # 公式Q&A確認済み(ムンキドリの「Adrena-Brain」+バトルコロシアムの裁定と同様、
        # 2026-08-23): 移動元からの除去は必ず起こるが、移動先がバトルコロシアムでダメカンを
        # のせられないベンチポケモンの場合は、のせる部分だけが阻まれる(移動自体は丸ごと
        # キャンセルされない)。以前はバトルコロシアムを一切チェックしておらず、常にのって
        # しまっていた。
        if not (
            _defender_is_shielded(ctx, target)
            or (not tools_disabled(ctx.state.stadium_in_play) and _blocks_damage_counters(target))
            or (ctx.state.stadium_in_play == _BATTLE_COLOSSEUM_STADIUM_ID and target is not opponent.active)
        ):
            target.damage += moved_total
            ctx.log(f"{ctx.source_card_id} が自分の場のダメカンを合計{moved_total // 10}個、相手に移した")
        else:
            ctx.log(f"{ctx.source_card_id} が自分の場のダメカンを合計{moved_total // 10}個取り除いたが、移動先にはのらなかった")


@dataclass(frozen=True)
class IfDefenderIsEvolved(Effect):
    """相手のバトルポケモンが進化ポケモン(たねポケモンでない)なら追加効果(アイアンバンドルの
    「冷凍ストリーム」等)。"""

    then: tuple[Effect, ...]

    def execute(self, ctx: EffectContext) -> None:
        _, defender = _defender(ctx)
        if defender is None:
            return
        defender_card = ctx.card_db.get(defender.card_id)
        if defender_card is None or defender_card.is_basic:
            return
        for effect in self.then:
            effect.execute(ctx)


@dataclass(frozen=True)
class DiscardAllOpponentActiveEnergy(Effect):
    """相手のバトルポケモンについているエネルギーを全てトラッシュする(ルカリオ&メルメタルGXの
    「フルメタルウォールGX」等)。"""

    def execute(self, ctx: EffectContext) -> None:
        opponent = ctx.state.player(ctx.opponent)
        if opponent.active is None or not opponent.active.attached_energy:
            return
        opponent.discard.extend(opponent.active.attached_energy)
        opponent.active.attached_energy = []
        ctx.log("相手のバトルポケモンのエネルギーを全てトラッシュした")


@dataclass(frozen=True)
class HealAllOwnPokemon(Effect):
    """自分の場(バトル+ベンチ)にいる全てのポケモンのダメージを回復する(ミュウツー&ミュウGXの
    「ミラクルツインGX」等)。bench_only=Trueならベンチのみ(ディアンシー◇の「ダイヤモンドレイン」実
    カードテキスト: "Heal 30 damage from each of your Benched Pokémon."でベンチ全体が対象、選択不要)。
    amount指定時はその数値ぶんだけ回復する固定量版、Noneなら全回復。
    (「ベンチ2匹まで選んで」系のカード(タプ・レレGXの「Tapu Cure-GX」等)は対象選択が必要なため、
    このクラスではなくChooseOwnBenchThenHealFullyを使う)。"""

    bench_only: bool = False
    amount: int | None = None
    basic_only: bool = False  # リーラント(Leavanny)「Healing Wrapping」実カードテキスト: "Heal 100
    # damage from each of your Basic Pokémon."用

    def execute(self, ctx: EffectContext) -> None:
        player = _attacker_player(ctx)
        targets = player.bench if self.bench_only else player.all_pokemon_in_play()
        if self.basic_only:
            targets = [
                mon for mon in targets
                if (c := ctx.card_db.get(mon.card_id)) is not None and c.is_basic
            ]
        for mon in targets:
            if self.amount is None:
                mon.damage = 0
            else:
                mon.heal(self.amount)


@dataclass(frozen=True)
class DiscardTopOfOwnDeck(Effect):
    """自分の山札の上からN枚をトラッシュする(レジドラゴVSTARの「レガシースター」等)。"""

    count: int

    def execute(self, ctx: EffectContext) -> None:
        player = _attacker_player(ctx)
        discarded = player.deck[: self.count]
        player.deck = player.deck[self.count :]
        player.discard.extend(discarded)
        ctx.log(f"自分の山札の上から{len(discarded)}枚をトラッシュした")


@dataclass(frozen=True)
class DiscardTopOfOwnDeckThenUseItsAttack(Effect):
    """自分の山札の上から1枚をトラッシュし、そのカードがポケモン(「ルールを持つポケモン」を除く)
    なら、そのポケモンが持っているワザを1つ選んでこのワザとして使う(ヤドキング(sv7-39)の
    「ひらめきチャレンジ」実カードテキスト: "Discard the top card of your deck. If that card is a
    Pokemon (excluding Rule Box Pokemon), choose 1 of its attacks and use it as this attack."用)。
    ワザが1つしか無ければ自動で使う。2つ以上あれば選ばせる(zone="revealed_card_attack_choice"、
    engine.rules_engine._handle_resolve_search_choiceで解決)。"""

    def execute(self, ctx: EffectContext) -> None:
        player = _attacker_player(ctx)
        if not player.deck:
            return
        card_id = player.deck.pop(0)
        player.discard.append(card_id)
        card = ctx.card_db.get(card_id)
        name = card.name if card is not None else card_id
        ctx.log(f"自分の山札の上から{name}をトラッシュした")
        if card is None or not card.is_pokemon or (_RULE_BOX_SUBTYPES & set(card.subtypes)) or not card.attacks:
            return
        _offer_revealed_card_attack_choice(ctx, card_id, card)


def _revealed_attack_options(card_db, card_id: str, card) -> list[tuple[int, bool]]:
    """借りるワザの選択肢(ワザの番号, 「してもよい」を使う版か)。エネルギーを捨てて追加ダメージを出してもよいワザ
    (メタグロスの「Metallic Hammer」等)は、「捨てない」「捨てる」の2つの選択肢に分ける。"""
    from effects.registry import get_attack_script

    options: list[tuple[int, bool]] = []
    for i, attack in enumerate(card.attacks):
        options.append((i, False))
        if has_optional_variant(get_attack_script(card_id, attack.name)):
            options.append((i, True))
    return options


def _offer_revealed_card_attack_choice(ctx: EffectContext, card_id: str, card) -> None:
    """ワザを借りる効果(ヤドキングの「ひらめきチャレンジ」/ロケット団のミミッキュの「Gemstone Mimicry」)の共通処理。
    選択肢が1つだけなら自動で使い、2つ以上なら選ばせる(zone="revealed_card_attack_choice")。"""
    options = _revealed_attack_options(ctx.card_db, card_id, card)
    if len(options) == 1:
        run_borrowed_attack_script(ctx, card_id, card.attacks[0].name)
        return
    ctx.state.pending_search_choice = PendingSearchChoice(
        player_index=ctx.acting_player,
        zone="revealed_card_attack_choice",
        source_indices=list(range(len(options))),
        card_ids=[card_id] * len(options),
        min_count=1,
        max_count=1,
        prompt=f"{card.name}のワザを1つ選んで使う",
        shuffle_after=False,
        all_card_ids=[card_id] * len(options),
        cont_source_pokemon=ctx.source_pokemon,
        cont_source_card_id=ctx.source_card_id,
        custom_data={"mode": "revealed_card_attack_choice", "revealed_card_id": card_id, "options": options},
    )


def run_borrowed_attack_script(ctx: EffectContext, source_card_id: str, attack_name: str) -> None:
    """指定したカードの指定したワザの効果スクリプトを、現在のctx(source_pokemon/source_card_idは
    実際に攻撃しているポケモン自身のまま)で実行する(ヤドキングの「ひらめきチャレンジ」用)。"""
    from effects.interpreter import run_script
    from effects.registry import get_attack_script

    run_script(get_attack_script(source_card_id, attack_name), ctx)


@dataclass(frozen=True)
class SearchDiscardAnyCardToHand(Effect):
    """トラッシュから好きなカードを最大N枚まで選んで手札に加える(レジドラゴVSTARの「レガシースター」等)。"""

    count: int = 1

    def execute(self, ctx: EffectContext) -> None:
        player = _attacker_player(ctx)
        _trigger_search_choice(ctx, player, "discard", lambda card: card is not None, self.count, "トラッシュから好きなカードを探す", shuffle_after=False)


@dataclass(frozen=True)
class KnockOutOpponentActive(Effect):
    """相手のバトルポケモンを問答無用できぜつさせる(ギラティナVSTARの「スターレクイエム」等)。"""

    def execute(self, ctx: EffectContext) -> None:
        opponent = ctx.state.player(ctx.opponent)
        if opponent.active is None:
            return
        if _defender_blocks_non_damage_effects(ctx, opponent.active) or _defender_is_shielded(ctx, opponent.active):
            return  # 即座にきぜつさせる=ワザのダメージ計算を経ない「効果」のため、ばけがくれ等でブロックされうる
        opponent.active.damage = 9999
        ctx.log(f"{ctx.source_card_id} が相手のバトルポケモンをきぜつさせた")


# ---- 「各プレイヤーの番に1回」発動できるスタジアム効果向けに追加したプリミティブ ----


@dataclass(frozen=True)
class DiscardTopNRecoverItemsFound(Effect):
    """自分の山札の上からN枚をトラッシュし、その中にあったグッズカードだけ手札に加える(ポケストップ等)。"""

    n: int

    def execute(self, ctx: EffectContext) -> None:
        player = _attacker_player(ctx)
        top = player.deck[: self.n]
        player.deck = player.deck[self.n :]
        recovered = [cid for cid in top if (c := ctx.card_db.get(cid)) is not None and c.is_item]
        kept_in_discard = [cid for cid in top if cid not in recovered]
        player.discard.extend(kept_in_discard)
        player.hand.extend(recovered)
        if recovered:
            names = [ctx.card_db.get(cid).name for cid in recovered]
            ctx.log(f"山札の上から{len(top)}枚をトラッシュし、グッズ({', '.join(names)})を手札に加えた")
        else:
            ctx.log(f"山札の上から{len(top)}枚をトラッシュした(グッズなし)")
        # 選択の余地なく機械的にトラッシュされてしまうため、実際に何が見えたのかをWeb UIに一度表示する。
        ctx.reveal("山札の上から見えたカード", top)


@dataclass(frozen=True)
class DistributeDamageCountersFreely(Effect):
    """ダメカンをN個、相手のポケモンに好きなように分配してよい(ミュウの「サイコパワー」等)。

    bench_only=Trueならベンチのみが対象(フラッターマイクの「ヘクスハール」等)、Falseならバトル場も含む。
    max_per_targetを指定すると1体あたりの上限を課す(ギラティナ(smp-SM151)の「Distortion Door」=
    「2体に1個ずつ」等、"好きなように"ではなく"異なる対象に1個ずつ"のケース用)。
    target_own_side=Trueなら自分の場が対象になる(自滅ダメージ)。
    exactly=Trueなら"好きなように"ではなく、選んだtarget_count体全員にmax_per_target個ずつの
    固定配分になる(ガマゲロゲEXの「Grenade Hammer」=自分のベンチ2体に30ずつ、等。対象が
    target_count体に満たない場合は選べるだけ選ぶ)。
    弱点・抵抗力は計算しない。対象がいなければ何も起きない。
    """

    count: int
    bench_only: bool = False
    max_per_target: int | None = None
    target_own_side: bool = False
    exactly: bool = False
    target_count: int = 0
    damage_per_counter: int = 10  # 1個あたりのダメージ量(オリーヴァexの「オイルマシンガン」等、
    # 1回の選択が10ダメージ単位でないカード用)。

    def execute(self, ctx: EffectContext) -> None:
        side_player = ctx.state.player(ctx.acting_player) if self.target_own_side else ctx.state.player(ctx.opponent)
        num_targets = len(side_player.bench) + (0 if self.bench_only else (1 if side_player.active is not None else 0))
        if num_targets <= 0:
            return
        if self.exactly:
            if self.max_per_target is None or self.target_count <= 0:
                return
            total = self.max_per_target * min(self.target_count, num_targets)
        else:
            if self.count <= 0:
                return
            total = self.count
            if self.max_per_target is not None:
                # 対象が足りない場合は「乗せられるだけ乗せる」(ギラティナの「Distortion Door」等の実際の裁定)。
                total = min(total, num_targets * self.max_per_target)
        ctx.state.pending_damage_distribution = PendingDamageDistribution(
            player_index=ctx.acting_player,
            total_counters=total,
            bench_only=self.bench_only,
            max_per_target=self.max_per_target,
            source_card_id=ctx.source_card_id,
            target_own_side=self.target_own_side,
            fixed_per_target=self.exactly,
            damage_per_counter=self.damage_per_counter,
            effect_source=ctx.effect_source,
        )


@dataclass(frozen=True)
class DiscardOwnEnergyOfTypeThenDistributeDamageFreely(Effect):
    """自分についている指定タイプのエネルギーを好きな枚数トラッシュし、トラッシュした枚数×damage_perの
    ダメージ(ダメカンとして)を相手のポケモンに好きなように分配する(ドータクンBREAKの「メタルレイン」
    実カードテキスト: "Discard as many Metal Energy attached to this Pokémon as you like."。
    にげるコストの温存等、あえて全ては捨てない選択にも意味があるため、何枚捨てるかはプレイヤーが選ぶ)。
    弱点・抵抗力は計算しない。"""

    energy_type: str
    damage_per: int

    def execute(self, ctx: EffectContext) -> None:
        if ctx.source_pokemon is None:
            return
        matching_indices = [
            i for i, e in enumerate(ctx.source_pokemon.attached_energy)
            if (c := ctx.card_db.get(e)) is not None and c.basic_energy_type == self.energy_type
        ]
        if not matching_indices:
            return
        ctx.state.pending_search_choice = PendingSearchChoice(
            player_index=ctx.acting_player,
            zone="own_source_pokemon_energy",
            source_indices=matching_indices,
            card_ids=[ctx.source_pokemon.attached_energy[i] for i in matching_indices],
            min_count=0,
            max_count=len(matching_indices),
            prompt=f"トラッシュする{self.energy_type}エネルギーを選ぶ",
            shuffle_after=False,
            all_card_ids=[ctx.source_pokemon.attached_energy[i] for i in matching_indices],
            cont_source_pokemon=ctx.source_pokemon,
            cont_source_card_id=ctx.source_card_id,
            custom_data={"mode": "discard_own_energy_then_distribute_damage", "damage_per": self.damage_per},
        )


@dataclass(frozen=True)
class DistributeDamageCountersFreelyConditional(Effect):
    """追加エネルギーの枚数によって配分するダメカン総数が変わる版(エーフィ&デオキシスGXの
    「クロスディヴィジョンGX」等)。"""

    base_count: int
    bonus_count: int
    own_cost_count: int
    extra_needed: int
    energy_type: str | None = None
    bench_only: bool = False

    def execute(self, ctx: EffectContext) -> None:
        if ctx.source_pokemon is None:
            return
        if self.energy_type:
            attached = sum(
                1
                for e in ctx.source_pokemon.attached_energy
                if ctx.card_db.get(e) and ctx.card_db.get(e).basic_energy_type == self.energy_type
            )
        else:
            attached = len(ctx.source_pokemon.attached_energy)
        extra = max(0, attached - self.own_cost_count)
        total = self.base_count + self.bonus_count if extra >= self.extra_needed else self.base_count
        DistributeDamageCountersFreely(total, bench_only=self.bench_only).execute(ctx)


@dataclass(frozen=True)
class SwitchOwnActiveWithFirstBench(Effect):
    """自分のバトルポケモンをベンチの先頭のポケモンと入れ替える(クロススイッチャー等、対象選択は簡略化)。"""

    def execute(self, ctx: EffectContext) -> None:
        player = _attacker_player(ctx)
        if player.active is None or not player.bench:
            return
        new_active = player.bench.pop(0)
        old_active = player.active
        old_active.status.clear_all()
        player.bench.append(old_active)
        new_active.status.clear_all()
        player.active = new_active


@dataclass(frozen=True)
class MoveDamageCountersFromSelfToOpponentActive(Effect):
    """自分の場の任意のポケモン1体についているダメカンを最大max_count個まで選んだ数だけ、選んだ
    相手のポケモン(バトル/ベンチどちらでも指定可)に移す(ムンキドリの「Adrena-Brain」実カード
    テキスト: "you may move up to 3 damage counters from 1 of your Pokémon to 1 of your opponent's
    Pokémon"。移動元の候補が2体以上いる場合の選択に加え、移動する個数(0〜max_count)もプレイヤーが
    選ぶ)。"""

    max_count: int

    def execute(self, ctx: EffectContext) -> None:
        if _damage_counter_relocation_blocked(ctx):
            return  # ミネズミの特性「かんしのめ」
        opponent = ctx.state.player(ctx.opponent)
        target = _resolve_opponent_target(ctx, opponent)
        if target is None:
            return
        # 公式Q&A確認済み(2026-08-23、ユーザー提示のFAQで裏取り): バトルコロシアムがある状態で
        # 相手のベンチポケモンを移動先に選んでも、選択自体は可能。ただし移動先にダメカンがのらない
        # (バトルコロシアムの効果でベンチポケモンは特性/ワザの効果でダメカンがのらないため)結果、
        # 選んだダメカンは移動元から取り除かれるだけで、移動先にはのらずに処理が終わる
        # (「移動自体が丸ごと発生しない」わけではなく、除去は起こるが追加だけ阻まれる)。そのため
        # ここでは移動先の免疫チェックによる早期returnはせず、実際に加算する段階
        # (engine.rules_engine._handle_resolve_search_choiceのdamage_counter_amount_choice)で
        # 判定する。
        player = ctx.state.player(ctx.acting_player)
        candidates = [(i, mon) for i, mon in enumerate(player.all_pokemon_in_play()) if mon.damage > 0]
        if not candidates:
            return
        if len(candidates) == 1:
            _trigger_move_damage_counters_amount_choice(ctx, candidates[0][1], target, self.max_count)
            return
        ctx.state.pending_search_choice = PendingSearchChoice(
            player_index=ctx.acting_player,
            zone="own_pokemon_target",
            source_indices=[i for i, _ in candidates],
            card_ids=[mon.card_id for _, mon in candidates],
            min_count=1,
            max_count=1,
            prompt="ダメカンを移動する自分のポケモンを選ぶ",
            shuffle_after=False,
            all_card_ids=[mon.card_id for _, mon in candidates],
            attach_target_pokemon=target,
            custom_data={"mode": "adrena_brain_pick_source", "max_count": self.max_count},
        )


def _trigger_move_damage_counters_amount_choice(
    ctx: EffectContext, source: PokemonInPlay, target: PokemonInPlay, max_count: int
) -> None:
    """移動元・移動先が確定した後、実際に何個(0個でもよい)移すかをプレイヤーに選ばせる。"""
    available = min(max_count, source.damage // 10)
    if available <= 0:
        return
    labels = [f"{n}個" for n in range(available + 1)]  # "0個"(移動しない)〜"available個"
    ctx.state.pending_search_choice = PendingSearchChoice(
        player_index=ctx.acting_player,
        zone="damage_counter_amount_choice",
        source_indices=list(range(len(labels))),
        card_ids=labels,
        min_count=1,
        max_count=1,
        prompt="ダメカンを何個移すか選ぶ",
        shuffle_after=False,
        all_card_ids=labels,
        reveal_to_opponent=False,
        custom_data={"source_pokemon": source, "target_pokemon": target},
    )


@dataclass(frozen=True)
class DamagePerBottomNCardsWithAttackName(Effect):
    """山札の下からn枚を見て、指定したワザ名を持つポケモンの数だけdamage_per点ずつダメージ。
    見つかったポケモンは山札に戻してシャッフルし、それ以外は全てトラッシュする(シザリガーの
    「Bug Out」等)。"""

    n: int
    attack_name: str
    damage_per: int

    def execute(self, ctx: EffectContext) -> None:
        player = _attacker_player(ctx)
        n = min(self.n, len(player.deck))
        bottom = player.deck[len(player.deck) - n :] if n else []
        rest = player.deck[: len(player.deck) - n] if n else list(player.deck)
        found_pokemon: list[str] = []
        discarded: list[str] = []
        for card_id in bottom:
            card = ctx.card_db.get(card_id)
            if card is not None and card.is_pokemon and any(a.name == self.attack_name for a in card.attacks):
                found_pokemon.append(card_id)
            else:
                discarded.append(card_id)
        player.deck = rest + found_pokemon
        ctx.rng.shuffle(player.deck)
        player.discard.extend(discarded)
        ctx.log(f"山札の下{n}枚を確認し、「{self.attack_name}」持ちを{len(found_pokemon)}匹見つけた")
        DealDamage(self.damage_per * len(found_pokemon)).execute(ctx)


@dataclass(frozen=True)
class SearchDiscardForNamedPokemonToBench(Effect):
    """トラッシュから指定した名前のポケモンを最大count匹選んで、手札を経由せず直接ベンチに出す
    (デスマスの「Come and Get You」等)。"""

    name: str
    count: int

    def execute(self, ctx: EffectContext) -> None:
        player = _attacker_player(ctx)

        def matches(card):
            return card is not None and card.name == self.name

        _trigger_search_choice(
            ctx, player, "discard", matches, self.count, f"トラッシュから{self.name}を探してベンチに出す", destination="bench"
        )


@dataclass(frozen=True)
class BonusPrizeIfTeraKnockedOutOpponentThisTurn(Effect):
    """このカードを使った番の間、自分のテラスタルポケモンのワザで相手のバトルポケモンをきぜつさせたら
    追加でサイドを1枚多く取れる(ブライアー等)。実際の付与はrules_engine._mark_ko_by_attackが
    このフラグを見て消費する。"""

    def execute(self, ctx: EffectContext) -> None:
        _attacker_player(ctx).bonus_prize_if_tera_ko_this_turn = True


@dataclass(frozen=True)
class AttachAnyHandEnergyToOwnActiveWithChoice(Effect):
    """自分の手札のエネルギー(基本/特殊問わず)を1枚、プレイヤーが選んで自分のバトルポケモンにつける
    (サカキの威厳の2段階目、他のカードでも「手札のエネルギーを1枚つける」の内部ステップとして使える
    汎用プリミティブ)。"""

    def execute(self, ctx: EffectContext) -> None:
        player = _attacker_player(ctx)
        if player.active is None:
            return

        def matches(card):
            return card is not None and card.is_energy

        _trigger_search_choice(
            ctx, player, "hand", matches, 1, "自分のバトルポケモンにつけるエネルギーを選ぶ",
            shuffle_after=False, destination="attach_energy",
        )
        if ctx.state.pending_search_choice is not None:
            ctx.state.pending_search_choice.attach_target_pokemon = player.active


@dataclass(frozen=True)
class BounceOpponentActiveEnergyThenAttachFromHand(Effect):
    """相手のバトルポケモンについているエネルギーを1枚、プレイヤーが選んで相手の手札に戻し、そうした
    場合、自分の手札のエネルギーを1枚、プレイヤーが選んで自分のバトルポケモンにつける(サカキの威厳
    実カードテキスト: "Put an Energy attached to your opponent's Active Pokémon into their hand.
    If you do, attach an Energy card from your hand to your Active Pokémon."。どちらも複数種類
    あれば選ぶ)。"""

    def execute(self, ctx: EffectContext) -> None:
        opponent = ctx.state.player(ctx.opponent)
        if opponent.active is None or not opponent.active.attached_energy:
            return
        player = _attacker_player(ctx)
        attach_script: tuple[Effect, ...] = ()
        if player.active is not None and any(
            (c := ctx.card_db.get(cid)) is not None and c.is_energy for cid in player.hand
        ):
            attach_script = (AttachAnyHandEnergyToOwnActiveWithChoice(),)

        source_indices: list[tuple] = [("energy", ctx.opponent, "active", i) for i in range(len(opponent.active.attached_energy))]
        card_ids = list(opponent.active.attached_energy)
        ctx.state.pending_search_choice = PendingSearchChoice(
            player_index=ctx.acting_player,
            zone="field_attachment",
            source_indices=source_indices,
            card_ids=card_ids,
            min_count=1,
            max_count=1,
            prompt="相手のバトルポケモンから手札に戻すエネルギーを選ぶ",
            shuffle_after=False,
            all_card_ids=card_ids,
            destination="hand",
            remaining_script=attach_script,
            cont_source_pokemon=ctx.source_pokemon,
            cont_source_card_id=ctx.source_card_id,
        )


@dataclass(frozen=True)
class ChooseOwnPokemonThenMoveOneBasicEnergyToAnother(Effect):
    """自分のポケモン間で基本エネルギーを1枚だけ移動する(エネルギーつけかえ/フシギバナの
    「エネルギー転送」/ドータクンGの「Galactic Switch」)。
    移動元(基本エネルギーがついている自分のポケモン)を選ぶ→移動元の基本エネルギーを1枚選ぶ→
    移動先(移動元以外の自分のポケモン)を選ぶ、の3段階。zone="own_pokemon_target"/
    "own_pokemon_energy_target"のmode="energy_switch_*"をengine.rules_engine側が解決する
    (ミュウEXの「Replace」と同じ選択の枠組みを使うが、1回移動したら終了する点が異なる)。
    energy_type指定時はそのタイプの基本エネルギーのみが対象(Noneなら基本エネルギー全種)。
    source_subtype指定時は移動元をそのサブタイプのポケモンに限定する(Galactic Switch=SPポケモン限定)。
    self_damage_after指定時、移動が実際に行われるならその前提で発動元自身にダメカンを追加する
    (Galactic Switch「Then, put 2 damage counters on Bronzong G」、移動先/移動元とは別に発動元固定)。"""

    energy_type: str | None = None
    source_subtype: str | None = None
    self_damage_after: int = 0

    def execute(self, ctx: EffectContext) -> None:
        player = _attacker_player(ctx)

        def matches(mon: PokemonInPlay) -> bool:
            if self.source_subtype is not None:
                card = ctx.card_db.get(mon.card_id)
                if card is None or self.source_subtype not in card.subtypes:
                    return False
            return any(
                (c := ctx.card_db.get(e)) is not None
                and c.is_energy
                and not c.is_special_energy
                and (self.energy_type is None or c.basic_energy_type == self.energy_type)
                for e in mon.attached_energy
            )

        candidates = []
        if player.active is not None and matches(player.active):
            candidates.append((0, player.active))
        for i, mon in enumerate(player.bench):
            if matches(mon):
                candidates.append((i + 1, mon))
        if not candidates:
            ctx.log("移動できるエネルギーがついている自分のポケモンがいない")
            return
        if self.self_damage_after and ctx.source_pokemon is not None:
            from effects.era_trainers import era_self_damage_prevented

            if not era_self_damage_prevented(ctx.state, ctx.source_pokemon):
                ctx.source_pokemon.damage += self.self_damage_after
        ctx.state.pending_search_choice = PendingSearchChoice(
            player_index=ctx.acting_player,
            zone="own_pokemon_target",
            source_indices=[slot for slot, _ in candidates],
            card_ids=[mon.card_id for _, mon in candidates],
            min_count=1,
            max_count=1,
            prompt="エネルギーを移動する元のポケモンを選ぶ",
            shuffle_after=False,
            all_card_ids=[mon.card_id for _, mon in candidates],
            custom_data={"mode": "energy_switch_pick_source", "energy_type": self.energy_type},
        )


@dataclass(frozen=True)
class DamageIfOwnBenchedPokemonDamaged(Effect):
    """自分のベンチポケモンに1匹でもダメカンがのっていれば、追加でボーナスダメージ(ジジーロンGXの「Berserk」等)。"""

    base: int
    bonus: int

    def execute(self, ctx: EffectContext) -> None:
        player = _attacker_player(ctx)
        amount = self.base + self.bonus if any(mon.damage > 0 for mon in player.bench) else self.base
        DealDamage(amount).execute(ctx)


@dataclass(frozen=True)
class MoveEnergyFromChosenBenchToActive(Effect):
    """選んだ自分のベンチポケモンについているエネルギーを1枚(自動選択)、自分のバトルポケモンに移す
    (マルチつけかえ等)。"""

    def execute(self, ctx: EffectContext) -> None:
        player = _attacker_player(ctx)
        if player.active is None or ctx.target_bench_index is None:
            return
        if not (0 <= ctx.target_bench_index < len(player.bench)):
            return
        source = player.bench[ctx.target_bench_index]
        if not source.attached_energy:
            return
        energy_id = source.attached_energy.pop(0)
        player.active.attached_energy.append(energy_id)
        ctx.log(f"自分のベンチポケモンから{energy_id}をバトルポケモンに移した")


@dataclass(frozen=True)
class SwapSelfFromPrizesForBasicPokemon(Effect):
    """自分の裏向きサイドを見て、その中のたねポケモンを1枚(自分で選ぶ。選ばなくてもよい)公開して手札に加え、
    代わりにこのカード自身をサイドとして裏向きに置く(ヒスイヘビーボール実カードテキスト: "Look at your
    face-down Prize cards. You may reveal a Basic Pokémon you find there, put it into your hand, and put this
    Hisuian Heavy Ball in its place as a face-down Prize card. (If you don't reveal a Basic Pokémon, put this card
    in the discard pile.) Then, shuffle your face-down Prize cards.")。たねポケモンを選ばなければ、このカードは
    トラッシュに置かれる(グッズの使用後処理がトラッシュに送るので、ここでは何もしない)。以前は先頭のたねポケモンを
    自動で選ぶだけでなく、このカードがサイドとトラッシュの両方に残る(カードが複製される)不具合があった
    (2026-10-06訂正)。"""

    def execute(self, ctx: EffectContext) -> None:
        player = _attacker_player(ctx)
        eligible = [i for i, cid in enumerate(player.prizes) if (c := ctx.card_db.get(cid)) is not None and c.is_basic]
        if not eligible:
            ctx.log("サイドにたねポケモンが無かった(このカードはトラッシュに置かれる)")
            return
        ctx.state.pending_search_choice = PendingSearchChoice(
            player_index=ctx.acting_player,
            zone="own_prizes_swap_for_basic",
            source_indices=eligible,
            card_ids=[player.prizes[i] for i in eligible],
            min_count=0,
            max_count=1,
            prompt="サイドから手札に加えるたねポケモンを選ぶ(選ばなければ、このカードはトラッシュに置かれる)",
            shuffle_after=False,
            all_card_ids=[player.prizes[i] for i in eligible],
            custom_data={"card_id": ctx.source_card_id},
        )


@dataclass(frozen=True)
class MoveBasicPokemonFromOpponentDiscardToTheirBench(Effect):
    """相手のトラッシュからたねポケモンを1匹選び、相手のベンチに出す(こだまのつのぶえ(Echoing Horn)、
    ターゲットホイッスル(Target Whistle)実カードテキスト: "Put a Basic Pokémon from your opponent's
    discard pile onto their Bench."。「あなたが置く」効果のため、どのポケモンにするかは相手ではなく
    自分(カードを使った側)が選ぶ)。"""

    def execute(self, ctx: EffectContext) -> None:
        from engine.continuous import effective_bench_limit

        opponent = ctx.state.player(ctx.opponent)
        if len(opponent.bench) >= effective_bench_limit(ctx.state, opponent, ctx.card_db):
            return
        eligible_indices = [i for i, cid in enumerate(opponent.discard) if (c := ctx.card_db.get(cid)) is not None and c.is_basic]
        if not eligible_indices:
            return
        ctx.state.pending_search_choice = PendingSearchChoice(
            player_index=ctx.acting_player,
            zone="opponent_discard_to_their_bench",
            source_indices=eligible_indices,
            card_ids=[opponent.discard[i] for i in eligible_indices],
            min_count=1,
            max_count=1,
            prompt="相手のトラッシュから相手のベンチに出すたねポケモンを選ぶ",
            shuffle_after=False,
            all_card_ids=[opponent.discard[i] for i in eligible_indices],
        )


@dataclass(frozen=True)
class DamagePerOwnPokemonInPlay(Effect):
    """自分の場(バトル+ベンチ)にいるポケモンの総数だけダメージ(ゾロアークGXの「連携乱打」等)。"""

    per_pokemon: int

    def execute(self, ctx: EffectContext) -> None:
        player = _attacker_player(ctx)
        count = len(player.all_pokemon_in_play())
        DealDamage(self.per_pokemon * count).execute(ctx)


@dataclass(frozen=True)
class TakeOwnPrizeCard(Effect):
    """ダメージを与えずサイドを1枚取る(カミツルギGXの「ブレードGX」等)。"""

    def execute(self, ctx: EffectContext) -> None:
        player = _attacker_player(ctx)
        if player.prizes:
            card = player.take_prize()
            player.hand.append(card)
            ctx.log(f"{ctx.source_card_id} の効果でサイドを1枚取った")



def _evolve_own_basic_directly_from_hand(ctx: EffectContext, target: PokemonInPlay, card_id: str, target_bench_index: int | None) -> None:
    player = _attacker_player(ctx)
    if card_id in player.hand:
        player.hand.remove(card_id)
    evolved = PokemonInPlay(
        card_id=card_id,
        attached_energy=list(target.attached_energy),
        damage=target.damage,
        turn_played=player.turns_taken,
        attached_tool=target.attached_tool,
        evolution_history=[*target.evolution_history, target.card_id],
    )
    if target_bench_index is None:
        player.active = evolved
    else:
        player.bench[target_bench_index] = evolved
    ctx.log(f"{target.card_id} を手札の{card_id}に直接2進化させた(ふしぎなアメ)")

    # 「手札から進化させて出したとき、してもよい」系の特性(リザードンexの「インフェルノリボーン」等)。
    # ふしぎなアメでの進化も「手札の進化カードを使ってポケモンを進化させた」ことに変わりなく、
    # 実際のカードでもこの手のトリガーは発動する(通常のEvolveアクションと同じ処理を行う)。
    from effects.registry import get_evolve_trigger_script
    from engine.rules_engine import _evolve_trigger_condition_met, _set_pending_trigger

    trigger_script = get_evolve_trigger_script(card_id)
    if trigger_script and _evolve_trigger_condition_met(card_id, player, ctx.card_db):
        _set_pending_trigger(ctx.state, ctx.acting_player, card_id, evolved, trigger_script)


@dataclass(frozen=True)
class EvolveOwnBasicDirectlyFromHand(Effect):
    """手札にある2進化先のカードを使い、自分のたねポケモン1匹を1進化を飛ばして直接2進化させる
    (ふしぎなアメ)。対象の合法性(1ターン目でない/出したばかりでない/該当2進化先が手札にある)は
    legal_actions._has_rare_candy_evolution_in_handで事前にゲート済み。手札に該当する2進化先が
    複数種類あれば、どれに進化させるかをプレイヤーが選ぶ(同名カードの重複はどれを選んでも結果が
    同じなので選択不要)。"""

    def execute(self, ctx: EffectContext) -> None:
        player = _attacker_player(ctx)
        target = _resolve_own_target(ctx, player)
        if target is None:
            return
        target_card = ctx.card_db.get(target.card_id)
        if target_card is None:
            return

        def matches(card):
            if card is None or "Stage 2" not in card.subtypes or card.evolves_from is None:
                return False
            return any(
                c.name == card.evolves_from and c.evolves_from == target_card.name
                for c in ctx.card_db.find_by_name(card.evolves_from)
            )

        eligible_indices = [i for i, cid in enumerate(player.hand) if matches(ctx.card_db.get(cid))]
        if not eligible_indices:
            return
        distinct_ids = {player.hand[i] for i in eligible_indices}
        target_bench_index = ctx.target_bench_index
        if len(distinct_ids) == 1:
            _evolve_own_basic_directly_from_hand(ctx, target, player.hand[eligible_indices[0]], target_bench_index)
            return
        ctx.state.pending_search_choice = PendingSearchChoice(
            player_index=ctx.acting_player,
            zone="rare_candy_evolve_choice",
            source_indices=eligible_indices,
            card_ids=[player.hand[i] for i in eligible_indices],
            min_count=1,
            max_count=1,
            prompt=f"{target.card_id}を直接2進化させるカードを手札から選ぶ",
            shuffle_after=False,
            all_card_ids=[player.hand[i] for i in eligible_indices],
            custom_data={"target_bench_index": target_bench_index},
        )


@dataclass(frozen=True)
class InstantEvolveAnyOwnPokemonFromDeck(Effect):
    """自分の場のポケモン(バトル/ベンチ、出したばかりのものは除く)のうち、山札に進化先がある
    最初の1匹を、手札を経由せず直接重ねて進化させる(ディアンシーの「Sparkling Wish」等)。"""

    def execute(self, ctx: EffectContext) -> None:
        player = _attacker_player(ctx)
        if player.turns_taken <= 1:
            return
        candidates: list[PokemonInPlay] = []
        if player.active is not None:
            candidates.append(player.active)
        candidates.extend(player.bench)
        for target in candidates:
            if target.turn_played == player.turns_taken:
                continue
            target_card = ctx.card_db.get(target.card_id)
            if target_card is None:
                continue

            def matches(card, _name=target_card.name):
                return card is not None and card.evolves_from == _name

            eligible = [(i, cid) for i, cid in enumerate(player.deck) if matches(ctx.card_db.get(cid))]
            if not eligible:
                continue
            idx, evolution_id = eligible[0]
            remaining = list(player.deck)
            remaining.pop(idx)
            player.deck = remaining
            ctx.rng.shuffle(player.deck)
            evolved = PokemonInPlay(
                card_id=evolution_id,
                attached_energy=list(target.attached_energy),
                damage=target.damage,
                turn_played=target.turn_played,
                attached_tool=target.attached_tool,
                evolution_history=[*target.evolution_history, target.card_id],
            )
            if target is player.active:
                player.active = evolved
            else:
                player.bench[player.bench.index(target)] = evolved
            ctx.log(f"{target.card_id} を山札の {evolution_id} に進化させた")
            return


@dataclass(frozen=True)
class InstantEvolveAnyOwnPokemonFromDeckThenChainEvolve(Effect):
    """自分の場のたねポケモン(バトル/ベンチ、出したばかりのものは除く)のうち山札に1進化先が
    ある1匹を直接重ねて進化させ、それで進化させられた場合はさらにその同じポケモンを対象に
    山札に2進化先があれば重ねて進化させる(グランドツリーの「各プレイヤーの番に1回」
    スタジアム能力)。

    対象になれる自分のポケモンが複数いる場合、および進化先候補(山札内でその対象から進化する
    カード)が2種類以上ある場合は、それぞれプレイヤーに選ばせる(以前はどちらも「最初に見つかった
    1つ」を無条件で自動選択していたため、例えばメガ進化先とex進化先の両方が山札にある場合に
    どちらに進化するか選べない不具合があった、2026-09-01発覚)。候補が1つしかなければ選択なしで
    そのまま進化させる。"""

    def execute(self, ctx: EffectContext) -> None:
        player = _attacker_player(ctx)
        if player.turns_taken <= 1:
            return
        slot_candidates: list[tuple[int, PokemonInPlay]] = []
        if player.active is not None:
            slot_candidates.append((0, player.active))
        for i, mon in enumerate(player.bench):
            slot_candidates.append((i + 1, mon))

        eligible: list[tuple[int, PokemonInPlay]] = []
        for slot, target in slot_candidates:
            if target.turn_played == player.turns_taken:
                continue
            target_card = ctx.card_db.get(target.card_id)
            if target_card is None or not target_card.is_basic:
                continue

            def matches_stage1(card, _name=target_card.name):
                return card is not None and card.evolves_from == _name and "Stage 1" in card.subtypes

            if any(matches_stage1(ctx.card_db.get(cid)) for cid in player.deck):
                eligible.append((slot, target))

        if not eligible:
            return
        if len(eligible) == 1:
            _grand_tree_evolve_step1(ctx, eligible[0][1])
            return
        ctx.state.pending_search_choice = PendingSearchChoice(
            player_index=ctx.acting_player,
            zone="own_pokemon_target",
            source_indices=[slot for slot, _ in eligible],
            card_ids=[mon.card_id for _, mon in eligible],
            min_count=1,
            max_count=1,
            prompt="グランドツリーで進化させる自分のポケモンを選ぶ",
            shuffle_after=False,
            all_card_ids=[mon.card_id for _, mon in eligible],
            custom_data={"mode": "grand_tree_pick_source"},
        )


def _grand_tree_evolve_step1(ctx: EffectContext, target: PokemonInPlay) -> None:
    """グランドツリー: 選ばれた対象を、山札のstage1候補から自分で1枚選んで直接重ねて進化させる
    (zone="deck", destination="evolve_target",
    custom_data mode="grand_tree_chain_stage2_continue"をengine.rules_engine側が解決し、
    解決後に続けてstage2チェーン(_grand_tree_chain_stage2)を試みる)。実カードの「山札から検索する」
    効果は同名カード(同じ印刷)の複数枚だけが候補でも必ずプレイヤー自身が選ぶ手続きのため、候補が
    1種類しかなくても選択を省略しない(イシズマイの「かくせい」修正、2026-08-25と同じ方針)。"""
    player = _attacker_player(ctx)
    target_card = ctx.card_db.get(target.card_id)
    if target_card is None:
        return

    def matches_stage1(card, _name=target_card.name):
        return card is not None and card.evolves_from == _name and "Stage 1" in card.subtypes

    eligible_indices = [i for i, cid in enumerate(player.deck) if matches_stage1(ctx.card_db.get(cid))]
    if not eligible_indices:
        return
    ctx.state.pending_search_choice = PendingSearchChoice(
        player_index=ctx.acting_player,
        zone="deck",
        source_indices=eligible_indices,
        card_ids=[player.deck[i] for i in eligible_indices],
        min_count=1,
        max_count=1,
        prompt=f"{target_card.name}の進化先を選ぶ(グランドツリー)",
        shuffle_after=True,
        all_card_ids=list(player.deck),
        destination="evolve_target",
        attach_target_pokemon=target,
        cont_source_pokemon=ctx.source_pokemon,
        cont_source_card_id=ctx.source_card_id,
        custom_data={"mode": "grand_tree_chain_stage2_continue"},
    )


def _grand_tree_chain_stage2(ctx: EffectContext, evolved: PokemonInPlay) -> None:
    """グランドツリー: stage1に進化させた対象をさらに、山札のstage2候補から自分で1枚選んで
    重ねて進化させる(候補が0種類なら何もしない)。_grand_tree_evolve_step1と同じ方針で、
    候補が同名カードの複数枚だけでも選択を省略しない。"""
    player = _attacker_player(ctx)
    evolved_card = ctx.card_db.get(evolved.card_id)
    if evolved_card is None:
        return

    def matches_stage2(card, _name=evolved_card.name):
        return card is not None and card.evolves_from == _name and "Stage 2" in card.subtypes

    eligible_indices = [i for i, cid in enumerate(player.deck) if matches_stage2(ctx.card_db.get(cid))]
    if not eligible_indices:
        return
    ctx.state.pending_search_choice = PendingSearchChoice(
        player_index=ctx.acting_player,
        zone="deck",
        source_indices=eligible_indices,
        card_ids=[player.deck[i] for i in eligible_indices],
        min_count=1,
        max_count=1,
        prompt=f"{evolved_card.name}の進化先を選ぶ(グランドツリー)",
        shuffle_after=True,
        all_card_ids=list(player.deck),
        destination="evolve_target",
        attach_target_pokemon=evolved,
        cont_source_pokemon=ctx.source_pokemon,
        cont_source_card_id=ctx.source_card_id,
    )


@dataclass(frozen=True)
class ContinueSiblingEvolveQueue(Effect):
    """イーブイの「Resonant Evolution」を使って進化させる選択が終わったあと、まだ聞いていない他のイーブイに
    続けて特性を使うか尋ねる(remaining_scriptとして使う)。"""

    def execute(self, ctx: EffectContext) -> None:
        from engine.rules_engine import _offer_next_sibling_evolve_trigger

        _offer_next_sibling_evolve_trigger(ctx.state, ctx.card_db, ctx.acting_player)


@dataclass(frozen=True)
class InstantEvolveSelfFromDeck(Effect):
    """自分自身(ctx.source_pokemon)を、山札にある進化先1匹に直接重ねて進化させる(イーブイの
    「Energy Evolution」実カードテキスト: "search your deck for a card that evolves from this
    Pokémon that is the same type as that Energy card"。つけた基本エネルギーと同じタイプの進化先
    限定。候補が複数種類あれば選ばせる(ctx.triggering_energy_idで判定できないほど古い/汎用の
    呼び出し元では、後方互換としてタイプ判定をスキップする)。
    allow_just_played=Trueなら、場に出した(進化した)ばかりのポケモンでも進化できる(イーブイ(swsh10-119)の
    特性「Resonant Evolution」: テキストに「出したばかりでない」条件が無いため)。既定のFalseは従来通り。"""

    allow_just_played: bool = False

    def execute(self, ctx: EffectContext) -> None:
        if ctx.source_pokemon is None:
            return
        player = _attacker_player(ctx)
        target = ctx.source_pokemon
        if target.turn_played == player.turns_taken and not self.allow_just_played:
            return
        target_card = ctx.card_db.get(target.card_id)
        if target_card is None:
            return
        energy_type: str | None = None
        if ctx.triggering_energy_id:
            energy_card = ctx.card_db.get(ctx.triggering_energy_id)
            if energy_card is not None:
                energy_type = energy_card.basic_energy_type

        def matches(card):
            if card is None or card.evolves_from != target_card.name:
                return False
            return energy_type is None or energy_type in card.types

        eligible_indices = [i for i, cid in enumerate(player.deck) if matches(ctx.card_db.get(cid))]
        if not eligible_indices:
            return
        # 実カードルール上、「山札から選ぶ」効果は常にプレイヤー自身が山札を検索して選ぶ手続きの
        # ため、候補が同名カードの複数枚だけであっても選択画面を出す(以前は候補が全て同じ
        # card_idのときだけ自動で1枚目を選んでいたが、イシズマイの「かくせい」でユーザーから
        # 「山札から自分でイワパレスを選択できるようにしてほしい」と報告を受け、2026-08-25に
        # このクラス(イーブイの「Energy Evolution」も共有)に限り自動選択をやめた)。
        ctx.state.pending_search_choice = PendingSearchChoice(
            player_index=ctx.acting_player,
            zone="deck",
            source_indices=eligible_indices,
            card_ids=[player.deck[i] for i in eligible_indices],
            min_count=1,
            max_count=1,
            prompt=f"{target.card_id}の進化先を選ぶ",
            shuffle_after=True,
            all_card_ids=list(player.deck),
            destination="evolve_target",
            attach_target_pokemon=target,
        )


@dataclass(frozen=True)
class ChooseOwnBenchThenHealFully(Effect):
    """自分のベンチポケモンを最大count体選び、それぞれのダメージを全回復する
    (テテフGXの「Tapu Cure-GX」)。"""

    count: int

    def execute(self, ctx: EffectContext) -> None:
        player = _attacker_player(ctx)
        if not player.bench:
            return
        ctx.state.pending_search_choice = PendingSearchChoice(
            player_index=ctx.acting_player,
            zone="own_pokemon_target",
            source_indices=[i + 1 for i in range(len(player.bench))],
            card_ids=[mon.card_id for mon in player.bench],
            min_count=0,
            max_count=min(self.count, len(player.bench)),
            prompt=f"ダメージを回復するベンチポケモンを{self.count}体まで選ぶ",
            shuffle_after=False,
            all_card_ids=[mon.card_id for mon in player.bench],
            custom_data={"mode": "heal_chosen_bench"},
        )


@dataclass(frozen=True)
class ChooseOwnBenchThenInstantEvolveFromDeck(Effect):
    """自分のベンチポケモンを最大count体選び、それぞれ山札から進化先を探して手札を経由せず
    直接重ねて進化させる(わざマシン進化)。1ターン目・出したばかりのポケモンは対象外。"""

    count: int

    def execute(self, ctx: EffectContext) -> None:
        player = _attacker_player(ctx)
        if player.turns_taken <= 1:
            return
        candidates = [(i + 1, mon) for i, mon in enumerate(player.bench) if mon.turn_played != player.turns_taken]
        if not candidates:
            return
        ctx.state.pending_search_choice = PendingSearchChoice(
            player_index=ctx.acting_player,
            zone="own_pokemon_target",
            source_indices=[slot for slot, _ in candidates],
            card_ids=[mon.card_id for _, mon in candidates],
            min_count=0,
            max_count=min(self.count, len(candidates)),
            prompt=f"進化させるベンチポケモンを{self.count}体まで選ぶ",
            shuffle_after=False,
            all_card_ids=[mon.card_id for _, mon in candidates],
            custom_data={"mode": "tech_machine_evolution"},
        )


def _evolve_in_place_from_deck(player, target: PokemonInPlay, evolution_id: str) -> PokemonInPlay:
    evolved = PokemonInPlay(
        card_id=evolution_id,
        attached_energy=list(target.attached_energy),
        damage=target.damage,
        turn_played=target.turn_played,
        attached_tool=target.attached_tool,
        evolution_history=[*target.evolution_history, target.card_id],
    )
    if target is player.active:
        player.active = evolved
    elif target in player.bench:
        player.bench[player.bench.index(target)] = evolved
    return evolved


@dataclass(frozen=True)
class InstantEvolveEachTargetFromDeck(Effect):
    """複数の対象ポケモンに対して、1体ずつ山札から進化先を探して直接重ねて進化させる
    (わざマシン進化の内部チェーン。SearchEnergyAttachToEachTargetと同じremaining_script連鎖パターン)。
    進化先候補(山札内でその対象から進化するカード)が2種類以上あれば、どれに進化させるかを
    プレイヤーに選ばせる(destination="evolve_target"をengine.rules_engine側が解決する)。
    候補が1種類のみ(同名カードが複数枚でもよい)なら選択なしでそのまま進化させる。

    then_end_turn: ワザの効果として発動した場合はTrue(わざマシン進化)。全対象の解決が終わった
    時点でターンを終了させるため、保留(PendingSearchChoice)が新たに発生する場合はその
    then_end_turn/custom_dataにも伝播させる必要がある(then_end_turn/custom_data staleness
    バグクラス: Turbo Energize等と同根)。"""

    targets: tuple[PokemonInPlay, ...]
    then_end_turn: bool = False

    def execute(self, ctx: EffectContext) -> None:
        if not self.targets:
            return
        player = _attacker_player(ctx)
        target = self.targets[0]
        rest = self.targets[1:]
        target_card = ctx.card_db.get(target.card_id)
        if target_card is None:
            if rest:
                InstantEvolveEachTargetFromDeck(rest, then_end_turn=self.then_end_turn).execute(ctx)
            return

        def matches(card, _name=target_card.name):
            return card is not None and card.evolves_from == _name

        eligible_indices = [i for i, cid in enumerate(player.deck) if matches(ctx.card_db.get(cid))]
        if not eligible_indices:
            ctx.log(f"{target_card.name} の進化先が山札に見つからなかった")
            if rest:
                InstantEvolveEachTargetFromDeck(rest, then_end_turn=self.then_end_turn).execute(ctx)
            return
        distinct_ids = {player.deck[i] for i in eligible_indices}
        if len(distinct_ids) == 1:
            idx = eligible_indices[0]
            evolution_id = player.deck[idx]
            remaining = list(player.deck)
            remaining.pop(idx)
            player.deck = remaining
            ctx.rng.shuffle(player.deck)
            _evolve_in_place_from_deck(player, target, evolution_id)
            ctx.log(f"{target.card_id} を山札の {evolution_id} に進化させた")
            if rest:
                InstantEvolveEachTargetFromDeck(rest, then_end_turn=self.then_end_turn).execute(ctx)
            return
        ctx.state.pending_search_choice = PendingSearchChoice(
            player_index=ctx.acting_player,
            zone="deck",
            source_indices=eligible_indices,
            card_ids=[player.deck[i] for i in eligible_indices],
            min_count=1,
            max_count=1,
            prompt=f"{target_card.name}の進化先を選ぶ",
            shuffle_after=True,
            all_card_ids=list(player.deck),
            destination="evolve_target",
            attach_target_pokemon=target,
            cont_source_pokemon=ctx.source_pokemon,
            cont_source_card_id=ctx.source_card_id,
            then_end_turn=self.then_end_turn,
            custom_data={
                "mode": "tech_machine_evolution_continue",
                "rest": rest,
                "then_end_turn": self.then_end_turn,
            },
        )


@dataclass(frozen=True)
class ShuffleHandDrawPerTotalBenchedPokemon(Effect):
    """手札を山札に戻し、両プレイヤーのベンチポケモンの合計数ぶんカードを引き直す(アクロマ等)。"""

    def execute(self, ctx: EffectContext) -> None:
        player = _attacker_player(ctx)
        opponent = ctx.state.player(ctx.opponent)
        count = len(player.bench) + len(opponent.bench)
        player.deck.extend(player.hand)
        player.hand = []
        ctx.rng.shuffle(player.deck)
        for _ in range(count):
            if not player.deck:
                break
            player.hand.append(player.deck.pop(0))
        ctx.log(f"手札を山札に戻し、{count}枚引き直した(ベンチ合計数ぶん)")


@dataclass(frozen=True)
class AttachToolToOpponentActiveEX(Effect):
    """相手の場の任意のEXポケモン(バトル/ベンチ、どうぐが何もついていないもの)を選んで、
    このどうぐをつける(ヘッドノイザー等)。ワザのコストが無色1つぶん増える効果は
    engine.energy.effective_attack_cost経由で対応済み。「外れたとき、そのカードの持ち主
    (つけたプレイヤー)のトラッシュに置く」ルールは、PokemonInPlay.attached_tool_ownerとstate.discard_attached_tool
    で対応する(以前は場のポケモンの持ち主側のトラッシュに置かれていた、2026-10-06訂正)。"""

    def execute(self, ctx: EffectContext) -> None:
        opponent = ctx.state.player(ctx.opponent)
        target = _resolve_opponent_target(ctx, opponent)
        if target is None or target.attached_tool is not None:
            return
        target_card = ctx.card_db.get(target.card_id)
        if target_card is None or "EX" not in target_card.subtypes:
            return
        target.attached_tool = ctx.source_card_id
        target.attached_tool_owner = ctx.acting_player  # 外れたときは、つけたプレイヤーのトラッシュに置かれる
        ctx.log("相手のポケモンにどうぐをつけた")


@dataclass(frozen=True)
class DamagePerOwnDiscardPokemonWithAttackName(Effect):
    """自分のトラッシュにある、指定した名前のワザを持つポケモンカードの枚数ぶんダメージ
    (バチュル/バケッチャ/ランプラーの「ナイトマーチ」等)。"""

    attack_name: str
    per_pokemon: int

    def execute(self, ctx: EffectContext) -> None:
        player = _attacker_player(ctx)
        count = sum(
            1
            for cid in player.discard
            if (card := ctx.card_db.get(cid)) is not None
            and card.is_pokemon
            and any(a.name == self.attack_name for a in card.attacks)
        )
        DealDamage(self.per_pokemon * count).execute(ctx)


@dataclass(frozen=True)
class DiscardOpponentActiveSpecialEnergyOnly(Effect):
    """相手のバトルポケモンについている特殊エネルギーを1枚選んでトラッシュする(改造ハンマー等)。
    どうぐには手を出さない(Xerosicとの違い)。"""

    def execute(self, ctx: EffectContext) -> None:
        opponent = ctx.state.player(ctx.opponent)
        target = opponent.active
        if target is None:
            return
        for i, energy_id in enumerate(target.attached_energy):
            card = ctx.card_db.get(energy_id)
            if card is not None and card.is_special_energy:
                opponent.discard.append(target.attached_energy.pop(i))
                ctx.log("相手のバトルポケモンの特殊エネルギーを1枚トラッシュした")
                return


@dataclass(frozen=True)
class SearchDeckForCardNameAttachToTarget(Effect):
    """山札から名前を指定したカード(特殊エネルギー等)を1枚探し、自分のポケモン1匹(対象指定、
    required_subtype指定時はそのサブタイプ限定)につける(ころころ団マシーン等)。"""

    card_name: str
    required_subtype: str | None = None

    def execute(self, ctx: EffectContext) -> None:
        player = _attacker_player(ctx)
        target = _resolve_own_target(ctx, player)
        if target is None:
            return
        if self.required_subtype is not None:
            target_card = ctx.card_db.get(target.card_id)
            if target_card is None or self.required_subtype not in target_card.subtypes:
                return
        idx = next((i for i, cid in enumerate(player.deck) if (c := ctx.card_db.get(cid)) is not None and c.name == self.card_name), None)
        if idx is None:
            ctx.rng.shuffle(player.deck)
            ctx.log(f"山札に{self.card_name}が見つからなかった")
            return
        card_id = player.deck.pop(idx)
        target.attached_energy.append(card_id)
        ctx.rng.shuffle(player.deck)
        ctx.log(f"山札から{self.card_name}を探して{target.card_id}につけた")


@dataclass(frozen=True)
class SearchDiscardForSubtypeToHand(Effect):
    """トラッシュから指定サブタイプを持つカードをcount枚(既定1枚)探して手札に加える(忍びの三人衆等)。"""

    subtype: str
    count: int = 1

    def execute(self, ctx: EffectContext) -> None:
        player = _attacker_player(ctx)

        def matches(card):
            return card_has_subtype(card, self.subtype)

        _trigger_search_choice(
            ctx, player, "discard", matches, self.count, f"トラッシュから{self.subtype}のカードを探す", shuffle_after=False
        )


@dataclass(frozen=True)
class SearchDiscardForTrainerToHand(Effect):
    """トラッシュからトレーナーズカード(グッズ/サポート/スタジアム)を1枚探して手札に加える
    (ダウジングマシン等)。"""

    def execute(self, ctx: EffectContext) -> None:
        player = _attacker_player(ctx)

        def matches(card):
            return card is not None and (card.is_item or card.is_supporter or card.is_stadium)

        _trigger_search_choice(ctx, player, "discard", matches, 1, "トラッシュからトレーナーズを探す", shuffle_after=False)


@dataclass(frozen=True)
class SearchDiscardForItemToHand(Effect):
    """トラッシュからグッズカードを最大count枚探して手札に加える(サーナイトの「ジャンクハント」等)。"""

    count: int = 1

    def execute(self, ctx: EffectContext) -> None:
        player = _attacker_player(ctx)

        def matches(card):
            return card is not None and card.is_item

        _trigger_search_choice(
            ctx, player, "discard", matches, self.count, "トラッシュからグッズを探す", shuffle_after=False
        )


@dataclass(frozen=True)
class SearchDeckForSubtypePokemonToHand(Effect):
    """山札から指定サブタイプ(Team Plasma等)を持つポケモンを1匹探して手札に加える(プラズマボール等)。"""

    subtype: str

    def execute(self, ctx: EffectContext) -> None:
        player = _attacker_player(ctx)

        def matches(card):
            return card is not None and card.is_pokemon and card_has_subtype(card, self.subtype)

        _trigger_search_choice(ctx, player, "deck", matches, 1, f"山札から{self.subtype}のポケモンを探す")


@dataclass(frozen=True)
class HealFullyAndDiscardAllEnergy(Effect):
    """選んだ自分のポケモン1匹のダメージを全回復し、ついているエネルギーを全てトラッシュする(まんたんのくすり等)。"""

    def execute(self, ctx: EffectContext) -> None:
        player = _attacker_player(ctx)
        target = _resolve_own_target(ctx, player)
        if target is None:
            return
        target.heal(9999)
        player.discard.extend(target.attached_energy)
        target.attached_energy = []


@dataclass(frozen=True)
class DealDamageWithCoinFlipBonus(Effect):
    """基本ダメージに、コインを指定回数振ってオモテが1回でも出ればボーナスダメージを追加する
    (ガルーラEXの「Kindred Kick」等)。合算してから弱点・抵抗力を1回だけ計算する。"""

    base: int
    bonus: int
    coin_count: int = 1

    def execute(self, ctx: EffectContext) -> None:
        heads_count = sum(1 for _ in range(self.coin_count) if ctx.rng.random() < 0.5)
        ctx.coin_heads_count = heads_count
        DealDamage(self.base + (self.bonus if heads_count > 0 else 0)).execute(ctx)


@dataclass(frozen=True)
class DealDamageFlipUntilTailsBonus(Effect):
    """コインをウラが出るまで繰り返し投げ、オモテの数だけボーナスダメージを追加する
    (MガルーラEXの「Wham Bam Punch」等)。合算してから弱点・抵抗力を1回だけ計算する。"""

    base: int
    bonus_per_heads: int
    max_flips: int = 50  # 無限ループ防止の安全上限

    def execute(self, ctx: EffectContext) -> None:
        heads_count = 0
        for _ in range(self.max_flips):
            if ctx.rng.random() < 0.5:
                heads_count += 1
            else:
                break
        ctx.coin_heads_count = heads_count
        DealDamage(self.base + self.bonus_per_heads * heads_count).execute(ctx)


@dataclass(frozen=True)
class DevolveAllOpponentEvolvedPokemon(Effect):
    """相手の場の進化ポケモンを全て1段階退化させ、外れた進化カードを相手の手札に加える
    (わざマシン ふるいもどし「Devolution」等)。evolution_historyが空(たねポケモン)の対象は何もしない。"""

    def execute(self, ctx: EffectContext) -> None:
        opponent = ctx.state.player(ctx.opponent)
        for mon in opponent.all_pokemon_in_play():
            if not mon.evolution_history:
                continue
            opponent.hand.append(mon.card_id)
            mon.card_id = mon.evolution_history.pop()
        ctx.log("相手の場の進化ポケモンを退化させた")


@dataclass(frozen=True)
class DiscardSelfSearchBasicToActiveInPlace(Effect):
    """自分自身(バトル場にいる必要がある)をついているカードごとトラッシュし、山札から選んだ
    別のたねポケモン(自分自身と同名は除く)をその場に直接出す(メタモンの「Transformative Start」等)。
    ダメカン・特殊状態・ついていたカードは一切引き継がない(そのポケモン自体がトラッシュされるため)。"""

    def execute(self, ctx: EffectContext) -> None:
        if ctx.source_pokemon is None:
            return
        player = _attacker_player(ctx)
        if player.active is not ctx.source_pokemon:
            return
        self_card = ctx.card_db.get(ctx.source_pokemon.card_id)
        self_name = self_card.name if self_card is not None else None

        def matches(card):
            return card is not None and card.is_basic and card.name != self_name

        _trigger_search_choice(
            ctx, player, "deck", matches, 1, "山札に出すたねポケモンを選ぶ",
            shuffle_after=True, destination="active_in_place",
        )


@dataclass(frozen=True)
class AttachEnergyFromDiscardToOwnPokemonWithChoice(Effect):
    """トラッシュから基本エネルギーを最大count枚、プレイヤーに選ばせて自分のポケモン1匹(対象指定)に
    つける(オーリム博士の気迫等)。energy_type=Noneならタイプ問わず。
    bench_only/target_type/target_name_prefixはAttachEnergyFromDiscardToOwnPokemonと同じ意味で、
    対象の絞り込みはengine.legal_actions側(_attach_target_filters)で行う。"""

    energy_type: str | None
    count: int = 1
    bench_only: bool = False
    target_type: str | None = None
    target_subtype: str | None = None
    target_name_prefix: str | None = None

    def execute(self, ctx: EffectContext) -> None:
        player = _attacker_player(ctx)
        target = _resolve_own_target(ctx, player)
        if target is None:
            return

        def matches(card):
            return card is not None and (
                card.basic_energy_type == self.energy_type
                if self.energy_type
                else (card.is_energy and not card.is_special_energy)
            )

        _trigger_search_choice(
            ctx, player, "discard", matches, self.count, "トラッシュから基本エネルギーを選んでつける",
            shuffle_after=False, destination="attach_energy",
        )
        if ctx.state.pending_search_choice is not None:
            ctx.state.pending_search_choice.attach_target_pokemon = target


@dataclass(frozen=True)
class SearchDeckByCriterionToHand(Effect):
    """山札から指定条件(SearchDeckMultiCriteriaと同じ条件文字列)に合うカードを最大count枚まで、
    プレイヤーに選ばせて手札に加える(ヨルノズクの「ほうせきさがし」=trainer最大2枚等、1回の選択で
    複数枚まとめて選べる場合用)。"""

    criterion: str
    count: int = 1

    def execute(self, ctx: EffectContext) -> None:
        player = _attacker_player(ctx)

        def matches(card):
            return card is not None and SearchDeckMultiCriteria._matches(card, self.criterion)

        _trigger_search_choice(ctx, player, "deck", matches, self.count, f"山札から{self.criterion}を最大{self.count}枚探す")


# ---- 場のどうぐ/特殊エネルギー/スタジアムを選ぶ効果(zone="field_attachment")用の候補列挙 ----


def _field_attachment_candidates(
    state,
    card_db,
    sides: tuple[int, ...],
    include_tool: bool = False,
    energy_predicate=None,
    include_stadium: bool = False,
    exclude_pokemon: PokemonInPlay | None = None,
    only_pokemon: PokemonInPlay | None = None,
) -> tuple[list[tuple], list[str]]:
    """場のポケモンについているどうぐ/特殊エネルギー(+スタジアム)の候補一覧を作る。
    戻り値は(PendingSearchChoice.source_indices用のタプル一覧, 対応するcard_id一覧)。
    タプルは("tool", side, slot) / ("energy", side, slot, energy_index) / ("stadium",)の形式
    (side: 0/1、slot: "active"またはベンチindex)。engine.rules_engine._resolve_field_attachment_choice
    が同じ形式を前提に解決する。only_pokemon指定時は、そのポケモン1体についているものだけを候補にする
    (オーガポン いどのめんexの「Torrential Pump」実カードテキスト: "You may shuffle 3 Energy
    attached to this Pokemon into your deck."用、exclude_pokemonの逆で「これだけ」を絞り込む)。"""
    source_indices: list[tuple] = []
    card_ids: list[str] = []
    for side in sides:
        player = state.players[side]
        slots: list[tuple] = [("active", player.active)] + [(i, mon) for i, mon in enumerate(player.bench)]
        for slot, mon in slots:
            if mon is None or mon is exclude_pokemon:
                continue
            if only_pokemon is not None and mon is not only_pokemon:
                continue
            if include_tool and mon.attached_tool is not None:
                source_indices.append(("tool", side, slot))
                card_ids.append(mon.attached_tool)
            if energy_predicate is not None:
                for ei, energy_id in enumerate(mon.attached_energy):
                    energy_card = card_db.get(energy_id)
                    if energy_card is not None and energy_predicate(energy_card):
                        source_indices.append(("energy", side, slot, ei))
                        card_ids.append(energy_id)
    from effects.era_sm_hooks import ITEM_SUPPORTER_IMMUNE_STADIUMS

    if include_stadium and state.stadium_in_play and state.stadium_in_play not in ITEM_SUPPORTER_IMMUNE_STADIUMS:
        # ヒートファクトリー◇(sm8-178)は「相手がアイテム/サポートを使ってもこのスタジアムへの
        # 効果を防ぐ」常時効果を持つため、このトレーナーズ由来の候補列挙からは常に除外する。
        source_indices.append(("stadium",))
        card_ids.append(state.stadium_in_play)
    return source_indices, card_ids


@dataclass(frozen=True)
class MoveChosenOwnEnergyToSelfThenSwitchActive(Effect):
    """自分の他のポケモンについている指定タイプの基本エネルギーを好きな枚数(0枚でもよい)選んで
    自分自身につけ、1枚でも移したら自分自身をバトル場と入れ替える(カプ・コケコGXの
    「Aero Trail」等。手札からベンチに出したときのトリガーとして使う想定)。"""

    energy_type: str

    def execute(self, ctx: EffectContext) -> None:
        if ctx.source_pokemon is None:
            return
        source_indices, card_ids = _field_attachment_candidates(
            ctx.state,
            ctx.card_db,
            (ctx.acting_player,),
            energy_predicate=lambda c: c.basic_energy_type == self.energy_type,
            exclude_pokemon=ctx.source_pokemon,
        )
        if not card_ids:
            return
        ctx.state.pending_search_choice = PendingSearchChoice(
            player_index=ctx.acting_player,
            zone="field_attachment",
            source_indices=source_indices,
            card_ids=card_ids,
            min_count=0,
            max_count=len(card_ids),
            prompt=f"{self.energy_type}エネルギーを自分の他のポケモンから何枚でも移す(移さなくてもよい)",
            shuffle_after=False,
            all_card_ids=list(card_ids),
            destination="attach_energy",
            attach_target_pokemon=ctx.source_pokemon,
            custom_data={"mode": "move_energy_then_switch_active"},
        )


@dataclass(frozen=True)
class MoveChosenBenchEnergyToActive(Effect):
    """自分のベンチポケモンについているエネルギーを最大max_count枚まで選んで、自分のバトルポケモンに
    移す(Nの筋書き(N's Plan)等)。"""

    max_count: int
    exact: bool = False  # True: 「最大」ではなくちょうどmax_count枚(マルチつけかえ: "Move an Energy")
    basic_only: bool = False  # True: 基本エネルギーだけが対象

    def execute(self, ctx: EffectContext) -> None:
        player = _attacker_player(ctx)
        if player.active is None:
            return
        source_indices, card_ids = _field_attachment_candidates(
            ctx.state,
            ctx.card_db,
            (ctx.acting_player,),
            energy_predicate=(lambda c: c.basic_energy_type is not None) if self.basic_only else (lambda c: True),
            exclude_pokemon=player.active,
        )
        if not card_ids:
            return
        ctx.state.pending_search_choice = PendingSearchChoice(
            player_index=ctx.acting_player,
            zone="field_attachment",
            source_indices=source_indices,
            card_ids=card_ids,
            min_count=min(self.max_count, len(card_ids)) if self.exact else 0,
            max_count=min(self.max_count, len(card_ids)),
            prompt=(
                f"ベンチポケモンについているエネルギーを{self.max_count}枚、バトルポケモンに移す"
                if self.exact else f"ベンチポケモンについているエネルギーを最大{self.max_count}枚、バトルポケモンに移す"
            ),
            shuffle_after=False,
            all_card_ids=list(card_ids),
            destination="attach_energy",
            attach_target_pokemon=player.active,
        )


@dataclass(frozen=True)
class SwitchSelfToActiveThenMoveChosenOwnEnergy(Effect):
    """自分自身とバトルポケモンを入れ替え、入れ替えたなら自分の他のポケモンについているエネルギーを
    好きな枚数(0枚でもよい)自分自身に移す(フリーザーGXの「Legendary Ascent」等。手札からベンチに
    出したときのトリガーとして使う想定)。energy_type指定時はその基本エネルギータイプのみが対象
    (フリーザーGX等)。energy_type=None(既定)なら、タイプ・特殊エネルギーを問わず自分の場についている
    全てのエネルギーが対象になる(テツノイサハexの「ラピッドバーニア」実カードテキスト:
    "choose any amount of Energy attached to your Pokémon in play"用)。"""

    energy_type: str | None = None

    def execute(self, ctx: EffectContext) -> None:
        if ctx.source_pokemon is None:
            return
        player = _attacker_player(ctx)
        if ctx.source_pokemon not in player.bench or player.active is None:
            return
        bench_index = player.bench.index(ctx.source_pokemon)
        new_active = player.bench.pop(bench_index)
        old_active = player.active
        old_active.status.clear_all()
        player.bench.append(old_active)
        new_active.status.clear_all()
        new_active.became_active_turn = player.turns_taken
        player.active = new_active

        if self.energy_type is not None:
            energy_predicate = lambda c: c.basic_energy_type == self.energy_type
            prompt = f"{self.energy_type}エネルギーを自分の他のポケモンから何枚でも移す(移さなくてもよい)"
        else:
            energy_predicate = lambda c: c.is_energy
            prompt = "エネルギーを自分の他のポケモンから何枚でも移す(移さなくてもよい)"
        source_indices, card_ids = _field_attachment_candidates(
            ctx.state,
            ctx.card_db,
            (ctx.acting_player,),
            energy_predicate=energy_predicate,
            exclude_pokemon=new_active,
        )
        if not card_ids:
            return
        ctx.state.pending_search_choice = PendingSearchChoice(
            player_index=ctx.acting_player,
            zone="field_attachment",
            source_indices=source_indices,
            card_ids=card_ids,
            min_count=0,
            max_count=len(card_ids),
            prompt=prompt,
            shuffle_after=False,
            all_card_ids=list(card_ids),
            destination="attach_energy",
            attach_target_pokemon=new_active,
        )


@dataclass(frozen=True)
class DiscardChosenFieldToolOrSpecialEnergy(Effect):
    """場の任意のポケモン(自分・相手どちらも)についているどうぐ/特殊エネルギーを1枚選んでトラッシュする
    (クセロシキ等)。"""

    def execute(self, ctx: EffectContext) -> None:
        source_indices, card_ids = _field_attachment_candidates(
            ctx.state, ctx.card_db, (0, 1), include_tool=True, energy_predicate=lambda c: c.is_special_energy
        )
        if not card_ids:
            ctx.log("場にトラッシュできるどうぐ/特殊エネルギーが無い")
            return
        ctx.state.pending_search_choice = PendingSearchChoice(
            player_index=ctx.acting_player,
            zone="field_attachment",
            source_indices=source_indices,
            card_ids=card_ids,
            min_count=1,
            max_count=1,
            prompt="トラッシュするどうぐ/特殊エネルギーを選ぶ",
            shuffle_after=False,
            all_card_ids=list(card_ids),
            destination="discard",
        )


@dataclass(frozen=True)
class DiscardChosenOpponentSpecialEnergy(Effect):
    """相手の場の任意のポケモン(バトル/ベンチどちらでも可)についている特殊エネルギーを1枚選んで
    トラッシュする(つよいひっぱりハンマー/改造ハンマー等、Enhanced Hammer)。"""

    def execute(self, ctx: EffectContext) -> None:
        source_indices, card_ids = _field_attachment_candidates(
            ctx.state, ctx.card_db, (ctx.opponent,), include_tool=False, energy_predicate=lambda c: c.is_special_energy
        )
        if not card_ids:
            ctx.log("相手の場にトラッシュできる特殊エネルギーが無い")
            return
        ctx.state.pending_search_choice = PendingSearchChoice(
            player_index=ctx.acting_player,
            zone="field_attachment",
            source_indices=source_indices,
            card_ids=card_ids,
            min_count=1,
            max_count=1,
            prompt="トラッシュする相手の特殊エネルギーを選ぶ",
            shuffle_after=False,
            all_card_ids=list(card_ids),
            destination="discard",
        )


@dataclass(frozen=True)
class DiscardChosenOpponentAnyEnergy(Effect):
    """相手の場の任意のポケモン(バトル/ベンチどちらでも可)についているエネルギーを種類を問わず
    1枚選んでトラッシュする(プルメリ(Plumeria)の内部チェーン用)。"""

    def execute(self, ctx: EffectContext) -> None:
        source_indices, card_ids = _field_attachment_candidates(
            ctx.state, ctx.card_db, (ctx.opponent,), include_tool=False, energy_predicate=lambda c: True
        )
        if not card_ids:
            ctx.log("相手の場にトラッシュできるエネルギーが無い")
            return
        ctx.state.pending_search_choice = PendingSearchChoice(
            player_index=ctx.acting_player,
            zone="field_attachment",
            source_indices=source_indices,
            card_ids=card_ids,
            min_count=1,
            max_count=1,
            prompt="トラッシュする相手のエネルギーを選ぶ",
            shuffle_after=False,
            all_card_ids=list(card_ids),
            destination="discard",
        )


@dataclass(frozen=True)
class DiscardHandCostThenDiscardChosenOpponentEnergy(Effect):
    """手札からdiscard_count枚をトラッシュすることをコストとし、1枚以上捨てたなら相手の場の
    任意のポケモンについているエネルギーを1枚選んでトラッシュする(プルメリ(Plumeria)の
    「Corrosive」等)。"""

    discard_count: int = 2

    def execute(self, ctx: EffectContext) -> None:
        player = _attacker_player(ctx)
        n = min(self.discard_count, len(player.hand))
        if n <= 0:
            return
        _trigger_search_choice(
            ctx,
            player,
            "hand",
            lambda card: True,
            n,
            f"トラッシュするカードを{n}枚選ぶ",
            shuffle_after=False,
            destination="discard",
            min_count=n,
        )
        if ctx.state.pending_search_choice is not None:
            ctx.state.pending_search_choice.remaining_script = (DiscardChosenOpponentAnyEnergy(),)


@dataclass(frozen=True)
class DiscardChosenFieldToolsOrStadium(Effect):
    """場のどうぐ(自分・相手どちらも)を、include_stadium=Trueならスタジアムも合わせて好きな
    組み合わせで最大2枚までトラッシュする(フィールドブロアーはスタジアムも対象、
    どうぐハンター(Tool Scrapper)はどうぐのみ)。"""

    include_stadium: bool = True
    max_count: int = 2
    destination: str = "discard"

    def execute(self, ctx: EffectContext) -> None:
        source_indices, card_ids = _field_attachment_candidates(
            ctx.state, ctx.card_db, (0, 1), include_tool=True, energy_predicate=None, include_stadium=self.include_stadium
        )
        if not card_ids:
            ctx.log("場に対象にできるどうぐが無い")
            return
        verb = "ロストゾーンに送る" if self.destination == "lost_zone" else "トラッシュする"
        ctx.state.pending_search_choice = PendingSearchChoice(
            player_index=ctx.acting_player,
            zone="field_attachment",
            source_indices=source_indices,
            card_ids=card_ids,
            min_count=min(1, len(card_ids)) if self.max_count == 1 else 0,
            max_count=min(self.max_count, len(card_ids)),
            prompt=f"{verb}どうぐ{'/スタジアム' if self.include_stadium else ''}を選ぶ(最大{self.max_count}枚)",
            shuffle_after=False,
            all_card_ids=list(card_ids),
            destination=self.destination,
        )


@dataclass(frozen=True)
class MoveChosenOwnFireEnergyToSelf(Effect):
    """自分の他のポケモンについている炎エネルギーを好きな数だけ選んで自分自身に移動する
    (ヒードランGXの「Burning Road」、ベンチからバトル場に出た瞬間に発動)。"""

    count: int | None = None  # 指定時はちょうどこの枚数(足りなければあるだけ)を移す(Flash Fire: 1枚)

    def execute(self, ctx: EffectContext) -> None:
        if ctx.source_pokemon is None:
            return
        source_indices, card_ids = _field_attachment_candidates(
            ctx.state,
            ctx.card_db,
            (ctx.acting_player,),
            include_tool=False,
            energy_predicate=lambda c: c.basic_energy_type == "Fire",
            exclude_pokemon=ctx.source_pokemon,
        )
        if not card_ids:
            ctx.log("移動できる炎エネルギーが自分の他のポケモンについていない")
            return
        if self.count is not None:
            ctx.state.pending_search_choice = PendingSearchChoice(
                player_index=ctx.acting_player,
                zone="field_attachment",
                source_indices=source_indices,
                card_ids=card_ids,
                min_count=min(self.count, len(card_ids)),
                max_count=min(self.count, len(card_ids)),
                prompt="自分につける炎エネルギーを選ぶ",
                shuffle_after=False,
                all_card_ids=list(card_ids),
                destination="attach_energy",
                attach_target_pokemon=ctx.source_pokemon,
            )
            return
        ctx.state.pending_search_choice = PendingSearchChoice(
            player_index=ctx.acting_player,
            zone="field_attachment",
            source_indices=source_indices,
            card_ids=card_ids,
            min_count=0,
            max_count=len(card_ids),
            prompt="自分につける炎エネルギーを選ぶ",
            shuffle_after=False,
            all_card_ids=list(card_ids),
            destination="attach_energy",
            attach_target_pokemon=ctx.source_pokemon,
        )


@dataclass(frozen=True)
class DiscardOwnBasicEnergyThenScalingDamage(Effect):
    """自分の場の任意のポケモン(このポケモン自身も含む)についている基本エネルギー
    (energy_type指定時はそのタイプのみ)を選んでトラッシュ(destination="lost_zone"ならロストゾーンへ)し、
    捨てた枚数ぶんダメージ(タケルライコexの「Bellowing Thunder」、ズガドーンGXの「Mind Blown」等)。
    exact_count指定時はちょうどその枚数を選ばせる(ギラティナVSTARの「Lost Impact」、この場合
    damage_per=0にすればダメージ無しで単に移動するだけの効果としても使える)。捨てた/送った枚数は
    選択が確定した時点でしか分からないため、ダメージ計算はengine.rules_engine._resolve_field_attachment_choice
    がcustom_data={"mode": "bellowing_thunder", ...}を見て行う。"""

    damage_per: int
    energy_type: str | None = None
    destination: str = "discard"
    exact_count: int | None = None
    max_selectable: int | None = None  # ロケット団のミュウツーexの「Erasure Ball」等: 「最大2枚まで」のような上限
    bench_only: bool = False  # 同上: 自分のベンチのポケモンについているエネルギー限定(攻撃ポケモン自身は対象外)
    any_energy: bool = False  # 同上: 基本エネルギーに限らず、特殊エネルギーも対象にする
    base: int = 0  # 「このワザは○ダメージ+捨てた枚数×N」の基本ダメージ(0枚でも与える)。マグカルゴGXの「Lava Flow」
    # (50+)/ジェネセクトEXの「Rapid Blaster」(100+)用。基本ダメージと追加ダメージを別々のDealDamageにすると、
    # げんきのハチマキ等の攻撃側ボーナス・抵抗力・防御側の軽減が2回ずつ適用されてしまうため、合計で1回の
    # ダメージ計算にする(2026-10-06訂正)
    source_only: bool = False  # True: このワザを使うポケモン自身についているエネルギーだけが対象("from this Pokémon")

    def execute(self, ctx: EffectContext) -> None:
        if ctx.source_pokemon is None:
            return
        source_indices, card_ids = _field_attachment_candidates(
            ctx.state,
            ctx.card_db,
            (ctx.acting_player,),
            include_tool=False,
            energy_predicate=lambda c: c.is_energy and (self.any_energy or not c.is_special_energy) and (
                self.energy_type is None or c.basic_energy_type == self.energy_type
            ),
            exclude_pokemon=ctx.source_pokemon if self.bench_only else None,
            only_pokemon=ctx.source_pokemon if self.source_only else None,
        )
        if not card_ids:
            ctx.log("対象にできるエネルギーが自分の場に無い")
            if self.base > 0:
                DealDamage(self.base).execute(ctx)
            return
        max_count = min(self.exact_count, len(card_ids)) if self.exact_count is not None else len(card_ids)
        if self.max_selectable is not None:
            max_count = min(max_count, self.max_selectable)
        min_count = max_count if self.exact_count is not None else 0
        verb = "ロストゾーンに送る" if self.destination == "lost_zone" else "トラッシュする"
        ctx.state.pending_search_choice = PendingSearchChoice(
            player_index=ctx.acting_player,
            zone="field_attachment",
            source_indices=source_indices,
            card_ids=card_ids,
            min_count=min_count,
            max_count=max_count,
            prompt=f"{verb}エネルギーを選ぶ",
            shuffle_after=False,
            all_card_ids=list(card_ids),
            destination=self.destination,
            cont_source_pokemon=ctx.source_pokemon,
            cont_source_card_id=ctx.source_card_id,
            custom_data={"mode": "bellowing_thunder", "damage_per": self.damage_per, "base": self.base},
        )


# ---- 自分の場のポケモン自体を選ぶ効果(zone="own_pokemon_target"/"own_pokemon_energy_target")----


@dataclass(frozen=True)
class SearchEnergyAttachToEachTarget(Effect):
    """複数の対象ポケモンに対して、1体ずつ山札から該当タイプの基本エネルギーを検索してつける
    (ゼルネアスの「Geomancy」の内部チェーン用。SearchDeckMultiCriteriaと同じremaining_script連鎖パターン)。"""

    targets: tuple[PokemonInPlay, ...]
    energy_type: str
    poison_active: bool = False  # True: バトルポケモンにエネルギーをつけたら、そのポケモンをどくにする(ジェニーの秘技)
    energy_card_name: str = ""  # 指定時は、基本エネルギーのタイプではなくこのカード名のエネルギー(特殊エネルギー可)を探す
    # (エレスバのきらめきの「フュージョンエネルギー」)

    def execute(self, ctx: EffectContext) -> None:
        if not self.targets:
            return
        player = _attacker_player(ctx)
        target = self.targets[0]
        rest = self.targets[1:]

        def matches(card):
            if card is None or not card.is_energy:
                return False
            if self.energy_card_name:
                return card.name == self.energy_card_name
            return not card.is_special_energy and card.basic_energy_type == self.energy_type
        prompt_name = self.energy_card_name or f"{self.energy_type}エネルギー"

        _trigger_search_choice(
            ctx, player, "deck", matches, 1, f"{prompt_name}を探してつける",
            shuffle_after=True, destination="attach_energy",
        )
        if ctx.state.pending_search_choice is not None:
            ctx.state.pending_search_choice.attach_target_pokemon = target
            if self.poison_active:
                ctx.state.pending_search_choice.custom_data = {"poison_if_attached_to_active": True}
            if rest:
                ctx.state.pending_search_choice.remaining_script = (
                    SearchEnergyAttachToEachTarget(rest, self.energy_type, self.poison_active, self.energy_card_name),
                )
        elif rest:
            # 山札に該当エネルギーが無かった場合でも、残りの対象には引き続き試す。
            SearchEnergyAttachToEachTarget(rest, self.energy_type, self.poison_active, self.energy_card_name).execute(ctx)


@dataclass(frozen=True)
class ChooseOwnBenchThenSearchEnergyAttach(Effect):
    """自分のベンチポケモンを選び、選んだ数ぶん山札から該当エネルギーを探して1枚ずつつける
    (ゼルネアスの「Geomancy」等)。"""

    count: int
    energy_type: str

    def execute(self, ctx: EffectContext) -> None:
        player = _attacker_player(ctx)
        if not player.bench:
            ctx.log("ベンチにポケモンがいない")
            return
        max_count = min(self.count, len(player.bench))
        ctx.state.pending_search_choice = PendingSearchChoice(
            player_index=ctx.acting_player,
            zone="own_pokemon_target",
            source_indices=[i + 1 for i in range(len(player.bench))],
            card_ids=[mon.card_id for mon in player.bench],
            min_count=0,
            max_count=max_count,
            prompt=f"{self.energy_type}エネルギーをつけるベンチポケモンを{self.count}体まで選ぶ",
            shuffle_after=False,
            all_card_ids=[mon.card_id for mon in player.bench],
            custom_data={"mode": "geomancy", "energy_type": self.energy_type},
        )


@dataclass(frozen=True)
class ChooseOwnPokemonThenSearchEnergyAttach(Effect):
    """自分の場のポケモン(バトル場+ベンチ)を最大count体選び、選んだ各体に山札から該当エネルギーを
    探して1枚ずつつける(ジェニーの秘技等)。ChooseOwnBenchThenSearchEnergyAttachと同じ解決経路
    (mode="geomancy")を、対象候補をベンチだけでなくバトル場も含む形で再利用する。"""

    count: int
    energy_type: str
    target_type: str | None = None  # 指定時は、そのタイプの自分のポケモンだけが対象(ジェニーの秘技: "your Darkness Pokémon")
    poison_active: bool = False  # True: バトルポケモンにエネルギーをつけたら、そのポケモンをどくにする

    def execute(self, ctx: EffectContext) -> None:
        player = _attacker_player(ctx)
        candidates: list[tuple[int, PokemonInPlay]] = []
        if player.active is not None:
            candidates.append((0, player.active))
        for i, mon in enumerate(player.bench):
            candidates.append((i + 1, mon))
        if self.target_type is not None:
            candidates = [
                (slot, mon) for slot, mon in candidates
                if (c := ctx.card_db.get(mon.card_id)) is not None and self.target_type in c.types
            ]
        if not candidates:
            ctx.log("対象にできるポケモンが場にいない")
            return
        max_count = min(self.count, len(candidates))
        ctx.state.pending_search_choice = PendingSearchChoice(
            player_index=ctx.acting_player,
            zone="own_pokemon_target",
            source_indices=[slot for slot, _ in candidates],
            card_ids=[mon.card_id for _, mon in candidates],
            min_count=0,
            max_count=max_count,
            prompt=f"{self.energy_type}エネルギーをつけるポケモンを{self.count}体まで選ぶ",
            shuffle_after=False,
            all_card_ids=[mon.card_id for _, mon in candidates],
            custom_data={"mode": "geomancy", "energy_type": self.energy_type, "poison_active": self.poison_active},
        )


@dataclass(frozen=True)
class ChooseOwnPokemonThenSearchSpecificEnergyAttach(Effect):
    """自分の場の、指定のサブタイプのポケモンを最大count体選び、選んだ各体に山札から指定した名前のエネルギーを探して
    1枚ずつつける(エレスバのきらめき実カードテキスト: "Choose up to 2 of your Fusion Strike Pokémon. For each of
    those Pokémon, search your deck for a Fusion Strike Energy card and attach it to that Pokémon.")。以前は
    ベンチの1匹に固定で、山札から自動でつける簡略版だった(2026-10-06訂正)。"""

    count: int
    energy_card_name: str
    target_subtype: str

    def execute(self, ctx: EffectContext) -> None:
        player = _attacker_player(ctx)
        candidates: list[tuple[int, PokemonInPlay]] = []
        if player.active is not None:
            candidates.append((0, player.active))
        for i, mon in enumerate(player.bench):
            candidates.append((i + 1, mon))
        candidates = [
            (slot, mon) for slot, mon in candidates
            if (c := ctx.card_db.get(mon.card_id)) is not None and self.target_subtype in c.subtypes
        ]
        if not candidates:
            ctx.log("対象にできるポケモンが場にいない")
            return
        ctx.state.pending_search_choice = PendingSearchChoice(
            player_index=ctx.acting_player,
            zone="own_pokemon_target",
            source_indices=[slot for slot, _ in candidates],
            card_ids=[mon.card_id for _, mon in candidates],
            min_count=0,
            max_count=min(self.count, len(candidates)),
            prompt=f"{self.energy_card_name}をつけるポケモンを{self.count}体まで選ぶ",
            shuffle_after=False,
            all_card_ids=[mon.card_id for _, mon in candidates],
            custom_data={"mode": "geomancy", "energy_type": "", "energy_card_name": self.energy_card_name},
        )


@dataclass(frozen=True)
class SearchDeckDistinctBasicEnergyAttachToEachTarget(Effect):
    """複数の対象に1体ずつ、山札から基本エネルギーを探してつける。2体目以降は、直前に見つけて
    ついたエネルギーと異なるタイプのみ検索対象にする(ミラージュゲートの「異なるタイプの基本
    エネルギーを最大2枚、自分のポケモンに好きなようにつける」)。previous_targetは直前に処理した
    対象で、そのattached_energyの最後の1枚からタイプを判定する。"""

    targets: tuple["PokemonInPlay", ...]
    previous_target: "PokemonInPlay | None" = None

    def execute(self, ctx: EffectContext) -> None:
        if not self.targets:
            return
        player = _attacker_player(ctx)
        target = self.targets[0]
        rest = self.targets[1:]

        exclude_type = None
        if self.previous_target is not None and self.previous_target.attached_energy:
            prev_card = ctx.card_db.get(self.previous_target.attached_energy[-1])
            if prev_card is not None:
                exclude_type = prev_card.basic_energy_type

        def matches(card):
            return (
                card is not None
                and card.is_energy
                and not card.is_special_energy
                and (exclude_type is None or card.basic_energy_type != exclude_type)
            )

        _trigger_search_choice(
            ctx, player, "deck", matches, 1, "つける基本エネルギーを探す", shuffle_after=True, destination="attach_energy",
        )
        if ctx.state.pending_search_choice is not None:
            ctx.state.pending_search_choice.attach_target_pokemon = target
            if rest:
                ctx.state.pending_search_choice.remaining_script = (
                    SearchDeckDistinctBasicEnergyAttachToEachTarget(rest, previous_target=target),
                )
        elif rest:
            SearchDeckDistinctBasicEnergyAttachToEachTarget(rest, previous_target=self.previous_target).execute(ctx)


@dataclass(frozen=True)
class ChooseOwnPokemonThenSearchDistinctBasicEnergyAttach(Effect):
    """自分の場のポケモン(バトル場+ベンチ)を最大max_count体選び、各々に山札から異なるタイプの
    基本エネルギーを1枚ずつ探してつける(ミラージュゲート)。"""

    max_count: int = 2

    def execute(self, ctx: EffectContext) -> None:
        player = _attacker_player(ctx)
        candidates: list[tuple[int, "PokemonInPlay"]] = []
        if player.active is not None:
            candidates.append((0, player.active))
        for i, mon in enumerate(player.bench):
            candidates.append((i + 1, mon))
        if not candidates:
            ctx.log("場にポケモンがいない")
            return
        max_count = min(self.max_count, len(candidates))
        ctx.state.pending_search_choice = PendingSearchChoice(
            player_index=ctx.acting_player,
            zone="own_pokemon_target",
            source_indices=[slot for slot, _ in candidates],
            card_ids=[mon.card_id for _, mon in candidates],
            min_count=0,
            max_count=max_count,
            prompt=f"基本エネルギーをつけるポケモンを{self.max_count}体まで選ぶ",
            shuffle_after=False,
            all_card_ids=[mon.card_id for _, mon in candidates],
            custom_data={"mode": "mirage_gate"},
        )


@dataclass(frozen=True)
class ChooseOwnPokemonThenSearchDistinctEnergyAttach(Effect):
    """直前にremaining_scriptで手札に加えた基本エネルギー(ctx.last_picked_card_ids)と異なる
    タイプの基本エネルギーをもう1枚山札から探してつける対象を、自分の場から選ぶ
    (Crispinの2段階目: 手札に加えた後、もう1枚をつける対象を選ぶ)。"""

    def execute(self, ctx: EffectContext) -> None:
        player = _attacker_player(ctx)
        candidates: list[tuple[int, "PokemonInPlay"]] = []
        if player.active is not None:
            candidates.append((0, player.active))
        for i, mon in enumerate(player.bench):
            candidates.append((i + 1, mon))
        if not candidates:
            ctx.log("場にポケモンがいない")
            return
        exclude_type = None
        if ctx.last_picked_card_ids:
            prev_card = ctx.card_db.get(ctx.last_picked_card_ids[0])
            if prev_card is not None:
                exclude_type = prev_card.basic_energy_type
        ctx.state.pending_search_choice = PendingSearchChoice(
            player_index=ctx.acting_player,
            zone="own_pokemon_target",
            source_indices=[slot for slot, _ in candidates],
            card_ids=[mon.card_id for _, mon in candidates],
            min_count=0,
            max_count=1,
            prompt="もう1枚(手札に加えた方と異なるタイプ)の基本エネルギーをつけるポケモンを選ぶ(選ばなくてもよい)",
            shuffle_after=False,
            all_card_ids=[mon.card_id for _, mon in candidates],
            custom_data={"mode": "crispin_attach", "exclude_type": exclude_type},
        )


@dataclass(frozen=True)
class SearchDeckBasicEnergyToHandThenChooseDistinctAttach(Effect):
    """異なるタイプの基本エネルギーを最大2枚山札から探し、1枚を手札に、もう1枚を選んだ自分の
    ポケモンにつける(Crispin)。手札に加える1枚(任意)→自分の場のポケモンを選ぶ(任意)→それと
    異なるタイプのもう1枚をつける、という3段階の連鎖で実装する。"""

    def execute(self, ctx: EffectContext) -> None:
        player = _attacker_player(ctx)

        def matches_any_basic_energy(card):
            return card is not None and card.is_energy and not card.is_special_energy

        _trigger_search_choice(
            ctx, player, "deck", matches_any_basic_energy, 1, "手札に加える基本エネルギーを探す(0枚でもよい)",
            shuffle_after=True, destination="hand",
        )
        if ctx.state.pending_search_choice is not None:
            ctx.state.pending_search_choice.remaining_script = (ChooseOwnPokemonThenSearchDistinctEnergyAttach(),)
        else:
            ChooseOwnPokemonThenSearchDistinctEnergyAttach().execute(ctx)


@dataclass(frozen=True)
class LookTopCardThenHandOrDiscardDraw(Effect):
    """山札の一番上を見て、手札に加えるか、そのままトラッシュして1枚引くかを選ぶ
    (トレッキングシューズ)。確定処理はengine.rules_engine._handle_resolve_search_choice側の
    custom_data={"mode": "trekking_shoes"}フックが行う。"""

    def execute(self, ctx: EffectContext) -> None:
        player = _attacker_player(ctx)
        if not player.deck:
            ctx.log("山札が無い")
            return
        top = player.deck[0]
        ctx.state.pending_search_choice = PendingSearchChoice(
            player_index=ctx.acting_player,
            zone="deck",
            source_indices=[0],
            card_ids=[top],
            min_count=0,
            max_count=1,
            prompt="山札の一番上を見た。手札に加える、またはトラッシュして1枚引く",
            shuffle_after=False,
            all_card_ids=[top],
            destination="hand",
            custom_data={"mode": "trekking_shoes"},
        )


@dataclass(frozen=True)
class AttachDiscardEnergyToEachAncientTargetThenDraw(Effect):
    """複数の対象(Ancientポケモン)に1体ずつ、トラッシュから基本エネルギー(タイプ問わず)を
    プレイヤーに選ばせて1枚つける。全対象を処理し終えた時点で1枚でもついていたら3枚引く
    (オーリム博士の気迫)。all_targets/initial_countsは開始時点のエネルギー枚数のスナップショットで、
    「1枚でもついたか」をチェーンの最後にまとめて判定するために使う。"""

    targets: tuple[PokemonInPlay, ...]
    all_targets: tuple[PokemonInPlay, ...]
    initial_counts: tuple[int, ...]

    def execute(self, ctx: EffectContext) -> None:
        if not self.targets:
            attached_any = any(
                len(mon.attached_energy) > before for mon, before in zip(self.all_targets, self.initial_counts)
            )
            if attached_any:
                Draw(3).execute(ctx)
            return

        player = _attacker_player(ctx)
        target = self.targets[0]
        rest = self.targets[1:]

        def matches(card):
            return card is not None and card.is_energy and not card.is_special_energy

        _trigger_search_choice(
            ctx, player, "discard", matches, 1, "トラッシュから基本エネルギーを選んでつける",
            shuffle_after=False, destination="attach_energy",
        )
        if ctx.state.pending_search_choice is not None:
            ctx.state.pending_search_choice.attach_target_pokemon = target
            ctx.state.pending_search_choice.remaining_script = (
                AttachDiscardEnergyToEachAncientTargetThenDraw(rest, self.all_targets, self.initial_counts),
            )
        else:
            # トラッシュに該当カードが無かった場合でも、残りの対象には引き続き試す。
            AttachDiscardEnergyToEachAncientTargetThenDraw(rest, self.all_targets, self.initial_counts).execute(ctx)


@dataclass(frozen=True)
class ChooseOwnAncientPokemonThenAttachDiscardEnergy(Effect):
    """自分の場の「Ancient」ポケモンを最大count体選び、選んだ各体にトラッシュから基本エネルギーを
    1枚ずつつける(オーリム博士の気迫)。"""

    count: int

    def execute(self, ctx: EffectContext) -> None:
        player = _attacker_player(ctx)
        candidates: list[tuple[int, PokemonInPlay]] = []
        if player.active is not None:
            card = ctx.card_db.get(player.active.card_id)
            if card is not None and "Ancient" in card.subtypes:
                candidates.append((0, player.active))
        for i, mon in enumerate(player.bench):
            card = ctx.card_db.get(mon.card_id)
            if card is not None and "Ancient" in card.subtypes:
                candidates.append((i + 1, mon))
        if not candidates:
            ctx.log("場に「Ancient」ポケモンがいない")
            return
        max_count = min(self.count, len(candidates))
        ctx.state.pending_search_choice = PendingSearchChoice(
            player_index=ctx.acting_player,
            zone="own_pokemon_target",
            source_indices=[slot for slot, _ in candidates],
            card_ids=[mon.card_id for _, mon in candidates],
            min_count=0,
            max_count=max_count,
            prompt=f"トラッシュから基本エネルギーをつける「Ancient」ポケモンを{self.count}体まで選ぶ",
            shuffle_after=False,
            all_card_ids=[mon.card_id for _, mon in candidates],
            custom_data={"mode": "sada_vitality"},
        )


@dataclass(frozen=True)
class ChooseSourceThenMoveEnergyFreely(Effect):
    """自分のポケモン間でエネルギーを1枚ずつ、好きなだけ好きなように移動する(ミュウEXの「Replace」等)。
    移動元ポケモンを選ぶ(0体なら終了)→そこから移動するエネルギーを1枚選ぶ→移動先を選ぶ、という3段階を
    繰り返す。2・3段階目以降の遷移はengine.rules_engine._resolve_own_pokemon_target_choice/
    _resolve_own_pokemon_energy_target_choiceが処理する(zone="own_pokemon_target"/"own_pokemon_energy_target")。"""

    def execute(self, ctx: EffectContext) -> None:
        player = _attacker_player(ctx)
        candidates = []
        if player.active is not None and player.active.attached_energy:
            candidates.append((0, player.active))
        for i, mon in enumerate(player.bench):
            if mon.attached_energy:
                candidates.append((i + 1, mon))
        if not candidates:
            ctx.log("移動できるエネルギーがついているポケモンがいない")
            return
        ctx.state.pending_search_choice = PendingSearchChoice(
            player_index=ctx.acting_player,
            zone="own_pokemon_target",
            source_indices=[slot for slot, _ in candidates],
            card_ids=[mon.card_id for _, mon in candidates],
            min_count=0,
            max_count=1,
            prompt="エネルギーを移動する元のポケモンを選ぶ(選ばなければ終了)",
            shuffle_after=False,
            all_card_ids=[mon.card_id for _, mon in candidates],
            custom_data={"mode": "replace_pick_source"},
        )


@dataclass(frozen=True)
class SetDestinyBondShield(Effect):
    """相手の次の番、このポケモンをきぜつさせたポケモンも道連れできぜつさせる(Gastlyの「Destiny Bond」)。
    実際の道連れ判定はengine.rules_engine._mark_ko_by_attackで行う。"""

    def execute(self, ctx: EffectContext) -> None:
        if ctx.source_pokemon is None:
            return
        opponent = ctx.state.player(ctx.opponent)
        ctx.source_pokemon.destiny_bond_until_turn = opponent.turns_taken + 1


@dataclass(frozen=True)
class MoveSelfAndAttachedToBottomOfDeck(Effect):
    """自分自身をついているカードごと山札の一番下に戻す(Uxieの「Psychic Restore」等、ワザ後の
    『してもよい』効果として使う)。バトル場が空になるため、新アクティブ選択が必要な場合は
    engine.rules_engine._handle_accept_triggerが処理する。"""

    def execute(self, ctx: EffectContext) -> None:
        if ctx.source_pokemon is None:
            return
        player = _attacker_player(ctx)
        if player.active is not ctx.source_pokemon:
            return
        mon = player.active
        player.active = None
        player.deck.extend(mon.evolution_history)
        player.deck.append(mon.card_id)
        player.deck.extend(mon.attached_energy)
        if mon.attached_tool:
            player.deck.append(mon.attached_tool)


@dataclass(frozen=True)
class DamageIfOtherAncientPokemonAttackedLastOwnTurn(Effect):
    """直前の自分の番に、自分の他の「Ancient」タイプのポケモンがワザを使っていれば追加ダメージ
    (コライドンの「Unrelenting Onslaught」等)。"""

    base: int
    bonus: int

    def execute(self, ctx: EffectContext) -> None:
        player = _attacker_player(ctx)
        bonus = 0
        if player.last_attack_used is not None:
            last_card_id, _ = player.last_attack_used
            if ctx.source_pokemon is None or last_card_id != ctx.source_pokemon.card_id:
                last_card = ctx.card_db.get(last_card_id)
                if last_card is not None and "Ancient" in last_card.subtypes:
                    bonus = self.bonus
        DealDamage(self.base + bonus).execute(ctx)


# ---- Jレギュレーション新規カード実装ぶん(2026-08-26〜) ----


@dataclass(frozen=True)
class BonusDamageIfSelfDamaged(Effect):
    """自分自身(このポケモン)にダメカンが1個でも乗っていれば追加ダメージ
    (マッギョex「Flopping Trap」実カードテキスト: "If this Pokémon has any damage
    counters on it, this attack does 100 more damage."用)。"""

    base: int
    bonus: int

    def execute(self, ctx: EffectContext) -> None:
        bonus = self.bonus if ctx.source_pokemon is not None and ctx.source_pokemon.damage > 0 else 0
        DealDamage(self.base + bonus).execute(ctx)


@dataclass(frozen=True)
class BonusDamageIfOpponentPrizesAtMost(Effect):
    """相手の残りサイドがthreshold枚以下なら追加ダメージ(カービンク「カウンタージュエル」
    実カードテキスト: "If your opponent has 2 or fewer Prize cards remaining, this attack does
    100 more damage."用)。"""

    base: int
    bonus: int
    threshold: int

    def execute(self, ctx: EffectContext) -> None:
        opponent = ctx.state.player(ctx.opponent)
        bonus = self.bonus if len(opponent.prizes) <= self.threshold else 0
        DealDamage(self.base + bonus).execute(ctx)


@dataclass(frozen=True)
class BonusDamageIfSelfBurnedOrPoisoned(Effect):
    """自分自身がやけど・どく状態なら追加ダメージ(ムクホーク(Staraptor)「Facade」実カードテキスト:
    "If this Pokémon is Burned or Poisoned, this attack does 100 more damage."用)。"""

    base: int
    bonus: int

    def execute(self, ctx: EffectContext) -> None:
        bonus = 0
        if ctx.source_pokemon is not None and (ctx.source_pokemon.status.burned or ctx.source_pokemon.status.poisoned):
            bonus = self.bonus
        DealDamage(self.base + bonus).execute(ctx)


@dataclass(frozen=True)
class DamageIfSelfSameAttackUsedLastOwnTurn(Effect):
    """直前の自分の番に、このポケモン自身が同じワザを使っていれば追加ダメージ(トゲデマルex
    「Spiky Rolling」のような「連続で同じワザを使うと強くなる」系タイプの実カードテキスト用。
    attack_nameはこのワザ自身の名前を指定する)。"""

    base: int
    bonus: int
    attack_name: str

    def execute(self, ctx: EffectContext) -> None:
        player = _attacker_player(ctx)
        bonus = 0
        if (
            player.last_attack_used is not None
            and ctx.source_pokemon is not None
            and player.last_attack_used == (ctx.source_pokemon.card_id, self.attack_name)
        ):
            bonus = self.bonus
        DealDamage(self.base + bonus).execute(ctx)


@dataclass(frozen=True)
class DamagePerHeadsForEachAttachedEnergy(Effect):
    """このポケモンについている(energy_type指定時はそのタイプのみの)エネルギーの枚数ぶん
    コインを投げ、オモテの枚数×damage_per_headsのダメージ(ノココッチex(Dudunsparce ex)
    「Work Rush」実カードテキスト: "Flip a coin for each Energy attached to this Pokémon. This
    attack does 80 damage for each heads."、ボルケニオン(Volcanion)「Powerful Steam」実カード
    テキスト: "Flip a coin for each Water Energy attached to this Pokémon."用。
    DealDamagePerHeadsと違い、コインを投げる回数がついているエネルギーの枚数で決まる(固定回数ではない))。"""

    damage_per_heads: int
    energy_type: str | None = None
    base: int = 0  # 「30+ / Flip a coin for each Water Energy ... 10 more damage for each heads」の基本ダメージ

    def execute(self, ctx: EffectContext) -> None:
        if ctx.source_pokemon is None:
            return
        if self.energy_type is None:
            coin_count = len(ctx.source_pokemon.attached_energy)
        else:
            coin_count = sum(
                1
                for e in ctx.source_pokemon.attached_energy
                if (c := ctx.card_db.get(e)) is not None and c.basic_energy_type == self.energy_type
            )
        heads_count = sum(1 for _ in range(coin_count) if ctx.rng.random() < 0.5)
        ctx.coin_heads_count = heads_count
        DealDamage(self.base + heads_count * self.damage_per_heads).execute(ctx)


@dataclass(frozen=True)
class DamagePerEnergyOnAllOpponentPokemon(Effect):
    """相手の場の全てのポケモン(バトル+ベンチ)についているエネルギーの合計枚数×damage_per_energyの
    ダメージ(エネコロロ(Delcatty)「Energy Crush」実カードテキスト: "This attack does 40 damage for
    each Energy attached to all of your opponent's Pokémon."用)。"""

    damage_per_energy: int

    def execute(self, ctx: EffectContext) -> None:
        opponent = ctx.state.player(ctx.opponent)
        total_energy = sum(len(mon.attached_energy) for mon in opponent.all_pokemon_in_play())
        DealDamage(total_energy * self.damage_per_energy).execute(ctx)


@dataclass(frozen=True)
class DamagePerOwnFieldNamePrefixCount(Effect):
    """自分の場(バトル+ベンチ)にいる、カード名がname_prefixで始まるポケモンの数×damage_per_pokemonの
    ダメージ(エリカのウツボット(Erika's Victreebel)「Flower Garden Rondo」実カードテキスト:
    "This attack does 40 damage for each of your Erika's Pokémon in play."用。攻撃しているこの
    ポケモン自身も対象に含める(実カードテキスト通り、自分自身も"in play"の1体としてカウントされる))。"""

    damage_per_pokemon: int
    name_prefix: str

    def execute(self, ctx: EffectContext) -> None:
        player = _attacker_player(ctx)
        count = sum(
            1
            for mon in player.all_pokemon_in_play()
            if (c := ctx.card_db.get(mon.card_id)) is not None and c.name.startswith(self.name_prefix)
        )
        DealDamage(count * self.damage_per_pokemon).execute(ctx)


@dataclass(frozen=True)
class DamagePerHeadsUntilTails(Effect):
    """裏が出るまでコインを投げ続け、オモテの数×damage_per_headsぶんのダメージ(ビリリダマex
    (Voltorb ex)「Hundred-Hitting Ball」実カードテキスト: "Flip a coin until you get tails. This
    attack does 100 more damage for each heads."用)。"""

    base: int
    damage_per_heads: int

    def execute(self, ctx: EffectContext) -> None:
        heads_count = 0
        while ctx.rng.random() < 0.5:
            heads_count += 1
        ctx.coin_heads_count = heads_count
        DealDamage(self.base + heads_count * self.damage_per_heads).execute(ctx)


@dataclass(frozen=True)
class BonusDamageIfDefenderHasSubtype(Effect):
    """相手のバトルポケモンが指定サブタイプ(例: "ex")を持っていれば追加ダメージ(ミライドンex
    「ハドロンスパーク」実カードテキスト: "If your opponent's Active Pokémon is a Pokémon ex, this
    attack does 120 more damage."用)。"""

    base: int
    bonus: int
    subtype: str

    def execute(self, ctx: EffectContext) -> None:
        opponent = ctx.state.player(ctx.opponent)
        bonus = 0
        if opponent.active is not None:
            defender_card = ctx.card_db.get(opponent.active.card_id)
            if defender_card is not None and self.subtype in defender_card.subtypes:
                bonus = self.bonus
        DealDamage(self.base + bonus).execute(ctx)




@dataclass(frozen=True)
class DamagePerEnergyOnOpponentActive(Effect):
    """相手のバトルポケモンについているエネルギーの枚数×damage_per_energyぶんの追加ダメージ
    (メガタブンネex(Mega Audino ex)「Ear Force」実カードテキスト: "This attack does 80 more
    damage for each Energy attached to your opponent's Active Pokémon."用)。"""

    base: int
    damage_per_energy: int

    def execute(self, ctx: EffectContext) -> None:
        opponent = ctx.state.player(ctx.opponent)
        bonus = 0
        if opponent.active is not None:
            bonus = len(opponent.active.attached_energy) * self.damage_per_energy
        DealDamage(self.base + bonus).execute(ctx)


@dataclass(frozen=True)
class BonusDamageIfDefenderAlreadyDamaged(Effect):
    """相手のバトルポケモンにダメカンが1個でも乗っていれば追加ダメージ(アオキのオトリバ
    (Larry's Rufflet)「Peck the Wound」実カードテキスト: "If your opponent's Active Pokémon
    already has any damage counters on it, this attack does 80 more damage."用)。"""

    base: int
    bonus: int

    def execute(self, ctx: EffectContext) -> None:
        opponent = ctx.state.player(ctx.opponent)
        bonus = self.bonus if opponent.active is not None and opponent.active.damage > 0 else 0
        DealDamage(self.base + bonus).execute(ctx)


@dataclass(frozen=True)
class SearchDeckForNonRuleBoxPokemonToHand(Effect):
    """山札からルール箱を持たないポケモンを1枚選び、公開して手札に加える(ポケパッド(Poké Pad)
    実カードテキスト: "Search your deck for a Pokémon that doesn't have a Rule Box, reveal it, and
    put it into your hand."用)。"""

    count: int = 1

    def execute(self, ctx: EffectContext) -> None:
        player = _attacker_player(ctx)

        def matches(card):
            return card is not None and card.is_pokemon and not (_RULE_BOX_SUBTYPES & set(card.subtypes))

        _trigger_search_choice(ctx, player, "deck", matches, self.count, "山札からルール箱を持たないポケモンを探す")


@dataclass(frozen=True)
class SearchDeckForNamePrefixPokemonToHand(Effect):
    """山札から、カード名がname_prefixで始まるポケモンを最大count枚まで選び、公開して手札に加える
    (エリカのモンジャラ(Erika's Tangela)の特性「Gathering of Blossoms」実カードテキスト:
    "Search your deck for an Erika's Pokémon, reveal it, and put it into your hand."用)。"""

    name_prefix: str
    count: int = 1

    def execute(self, ctx: EffectContext) -> None:
        player = _attacker_player(ctx)

        def matches(card):
            return card is not None and card.is_pokemon and card.name.startswith(self.name_prefix)

        _trigger_search_choice(ctx, player, "deck", matches, self.count, f"山札から{self.name_prefix}のポケモンを探す")


@dataclass(frozen=True)
class ShuffleSelfEnergyIntoDeck(Effect):
    """自分についている全てのエネルギーを山札に戻してシャッフルする(メガエアームドex(Mega
    Skarmory ex)「Sonic Ripper」実カードテキスト: "Shuffle all Energy attached to this Pokémon
    into your deck"用。ダメージ部分は同じ効果リスト内で別途DealDamageToChosenOpponentPokemon等を
    並べて表現する。これは、engine.legal_actions._targets_chosen_opponent_pokemonが対象選択の
    要否をスクリプト内の個々の効果クラスで判定しているため、ダメージ効果を別のラッパークラスに
    包んでしまうと対象選択(ベンチ含む)が合法手に出なくなるバグを避けるため)。"""

    def execute(self, ctx: EffectContext) -> None:
        if ctx.source_pokemon is None:
            return
        player = _attacker_player(ctx)
        player.deck.extend(ctx.source_pokemon.attached_energy)
        ctx.source_pokemon.attached_energy = []
        ctx.rng.shuffle(player.deck)


@dataclass(frozen=True)
class SearchDiscardForFightingPokemonOrEnergyToHand(Effect):
    """トラッシュから、闘タイプのポケモンと基本闘エネルギーの任意の組み合わせで最大count枚まで
    選んで手札に加える(タリオン(Tarragon)実カードテキスト: "Put up to 4 in any combination of
    Fighting Pokémon and Basic Fighting Energy cards from your discard pile into your hand."用)。"""

    count: int = 4

    def execute(self, ctx: EffectContext) -> None:
        player = _attacker_player(ctx)

        def matches(card):
            if card is None:
                return False
            if card.is_pokemon:
                return "Fighting" in card.types
            return card.is_energy and not card.is_special_energy and card.basic_energy_type == "Fighting"

        _trigger_search_choice(ctx, player, "discard", matches, self.count, f"トラッシュから闘タイプのポケモン/基本闘エネルギーを最大{self.count}枚探す", shuffle_after=False)


@dataclass(frozen=True)
class DamagePerOwnPrizesTaken(Effect):
    """実カードテキスト"...for each Prize card you have taken"通り、自分(攻撃側)が既に取った
    サイドの枚数(=自分の残りサイドの少なさ)を参照する(レントラー(Luxray)「Incessant
    Onslaught」実カードテキスト: "This attack does 70 damage for each Prize card you have taken."用。
    相手が取ったサイドを参照するDamagePerOpponentPrizesTakenとは主語が逆)。"""

    base: int
    per_prize: int

    def execute(self, ctx: EffectContext) -> None:
        player = _attacker_player(ctx)
        prizes_taken = 6 - len(player.prizes)
        DealDamage(self.base + self.per_prize * prizes_taken).execute(ctx)


@dataclass(frozen=True)
class DealDamageIgnoringResistanceOnly(Effect):
    """抵抗力だけを無視して(弱点は通常通り計算して)ダメージを与える(ランドロス(Landorus)
    「Rock Tumble」実カードテキスト: "This attack's damage isn't affected by Resistance."用。
    弱点・抵抗力の両方を無視するDealDamageIgnoringWeaknessResistanceとは異なる)。"""

    amount: int

    def execute(self, ctx: EffectContext) -> None:
        if ctx.source_pokemon is None:
            return
        _, defender = _defender(ctx)
        if defender is None or _defender_is_shielded(ctx, defender):
            return
        defender_card = ctx.card_db.get(defender.card_id)
        if defender_card is None:
            return
        dmg = resolve_attack_damage(ctx, defender, defender_card, self.amount, apply_resistance=False)
        defender.damage += dmg
        ctx.damage_dealt += dmg


@dataclass(frozen=True)
class BonusDamageIfOwnBenchDamaged(Effect):
    """自分のベンチポケモンに1体でもダメカンが乗っていれば追加ダメージ(ハラバリー(Hawlucha)
    「Vengeful Kick」実カードテキスト: "If your Benched Pokémon have any damage counters on them,
    this attack does 60 more damage."用)。"""

    base: int
    bonus: int

    def execute(self, ctx: EffectContext) -> None:
        player = _attacker_player(ctx)
        bonus = self.bonus if any(mon.damage > 0 for mon in player.bench) else 0
        DealDamage(self.base + bonus).execute(ctx)


@dataclass(frozen=True)
class DamageCounterFixedOnOpponentActive(Effect):
    """相手のバトルポケモン(対象選択不要、常にバトル場固定)にダメカンをcount個のせる
    (ゴースト(Haunter)「Haunt」実カードテキスト: "Place 3 damage counters on your opponent's
    Active Pokémon."用。DamageCounterOnChosenOpponentPokemonと異なり対象選択が発生しない)。"""

    count: int

    def execute(self, ctx: EffectContext) -> None:
        opponent = ctx.state.player(ctx.opponent)
        target = opponent.active
        if target is None or _defender_is_shielded(ctx, target) or _defender_blocks_non_damage_effects(ctx, target):
            return
        if not tools_disabled(ctx.state.stadium_in_play) and _blocks_damage_counters(target):
            return
        target.damage += self.count * 10
        ctx.log(f"相手のバトルポケモンにダメカンを{self.count}個のせた")


@dataclass(frozen=True)
class ReturnOwnAttachedEnergyToHand(Effect):
    """自分についているエネルギーを1枚、山札を経由せず直接手札に戻す(ランドロス(Landorus)
    「Screw Knuckle」実カードテキスト: "Put an Energy attached to this Pokémon into your hand."用)。"""

    def execute(self, ctx: EffectContext) -> None:
        if ctx.source_pokemon is None or not ctx.source_pokemon.attached_energy:
            return
        player = _attacker_player(ctx)
        energy_id = ctx.source_pokemon.attached_energy.pop(0)
        player.hand.append(energy_id)


@dataclass(frozen=True)
class DamageToAllOwnBenchedPokemon(Effect):
    """自分のベンチポケモン全員に固定ダメージ(弱点・抵抗力は計算しない)を与える(ホルード
    (Diggersby)「Earthquake」実カードテキスト: "This attack also does 30 damage to each of your
    Benched Pokémon. (Don't apply Weakness and Resistance for Benched Pokémon.)"用)。"""

    amount: int

    def execute(self, ctx: EffectContext) -> None:
        player = _attacker_player(ctx)
        for mon in player.bench:
            mon.damage += self.amount


@dataclass(frozen=True)
class RandomOpponentHandDiscardDownTo(Effect):
    """相手の手札からランダムに、手札がcount枚になるまでトラッシュする(トリミアン(Furfrou)
    「Hand Trim」実カードテキスト: "Discard random cards from your opponent's hand until they
    have 5 cards in their hand."用。OpponentDiscardHandDownToと異なり、残すカードを相手ではなく
    ランダムに決める)。"""

    count: int

    def execute(self, ctx: EffectContext) -> None:
        opponent = ctx.state.player(ctx.opponent)
        discard_amount = len(opponent.hand) - self.count
        if discard_amount <= 0:
            return
        for _ in range(discard_amount):
            idx = ctx.rng.randrange(len(opponent.hand))
            opponent.discard.append(opponent.hand.pop(idx))
        ctx.log(f"相手の手札からランダムに{discard_amount}枚をトラッシュした")


@dataclass(frozen=True)
class BonusDamageIfCardInOwnDiscard(Effect):
    """自分のトラッシュに指定したカード(card_ids、複数の再録違い等をまとめて指定できる)のいずれかが
    あれば追加ダメージ(ジャローダ(Serperior)「Solar Coiling」実カードテキスト: "If Rosa's
    Encouragement is in your discard pile, this attack does 150 more damage."用)。"""

    base: int
    bonus: int
    card_ids: tuple[str, ...]

    def execute(self, ctx: EffectContext) -> None:
        player = _attacker_player(ctx)
        bonus = self.bonus if any(cid in player.discard for cid in self.card_ids) else 0
        DealDamage(self.base + bonus).execute(ctx)


@dataclass(frozen=True)
class DiscardOpponentActiveTool(Effect):
    """相手のバトルポケモンについているポケモンのどうぐをトラッシュする(ラッタ(Raticate)
    「Scrape Off」実カードテキスト: "Before doing damage, discard all Pokémon Tools from your
    opponent's Active Pokémon."用。ワザのダメージ計算より前に処理する必要があるため、
    DealDamageより先にスクリプトへ並べて使う)。"""

    def execute(self, ctx: EffectContext) -> None:
        opponent = ctx.state.player(ctx.opponent)
        if opponent.active is not None and opponent.active.attached_tool is not None:
            discard_attached_tool(ctx.state, opponent, opponent.active)


@dataclass(frozen=True)
class DamagePerHandCardMatchingNames(Effect):
    """手札にある、指定した名前(names)のいずれかに一致するカードの枚数×damage_per_cardぶんの
    ダメージ(ソード(Doublade)「Weaponized Swords」実カードテキスト: "Reveal any number of
    Honedge, Doublade, and Aegislash from your hand, and this attack does 60 damage for each
    card you revealed in this way."用。公開するだけで手札からは減らないため、"任意枚数を公開
    してよい"は常に全て公開するのが得(LookTopNRevealMatchingToHand等と同じ簡略化方針)。"""

    damage_per_card: int
    names: tuple[str, ...]

    def execute(self, ctx: EffectContext) -> None:
        player = _attacker_player(ctx)
        count = sum(
            1
            for cid in player.hand
            if (c := ctx.card_db.get(cid)) is not None and c.name in self.names
        )
        DealDamage(count * self.damage_per_card).execute(ctx)


@dataclass(frozen=True)
class DamagePerNamedBenchedDamageCounters(Effect):
    """自分のベンチにいる、指定した名前(name)のポケモン全員のダメカン合計数×per_counterぶんの
    ダメージ(ラッタ(Raticate)「Retaliatory Incisors」実カードテキスト: "This attack does 40
    damage for each damage counter on all of your Benched Rattata."用)。"""

    per_counter: int
    name: str

    def execute(self, ctx: EffectContext) -> None:
        player = _attacker_player(ctx)
        counters = sum(
            mon.damage // 10
            for mon in player.bench
            if (c := ctx.card_db.get(mon.card_id)) is not None and c.name == self.name
        )
        DealDamage(counters * self.per_counter).execute(ctx)


@dataclass(frozen=True)
class HealOwnActiveFixed(Effect):
    """自分のバトルポケモン(対象選択不要、常にバトル場固定)のダメージをamount回復する
    (ルミオーズガレット(Lumiose Galette)実カードテキスト: "Heal 20 damage and remove a Special
    Condition from your Active Pokémon."用。HealTargetと違いtarget_bench_index経由の対象選択を
    行わない)。"""

    amount: int

    def execute(self, ctx: EffectContext) -> None:
        player = _attacker_player(ctx)
        if player.active is not None:
            player.active.heal(self.amount)


@dataclass(frozen=True)
class SwitchActiveWithBenchThenHealBenchedIfEx(Effect):
    """選んだベンチポケモンとバトルポケモンを入れ替え、ベンチに下がった側がex(GX/EX/ex/VMAX/VSTAR等の
    ルール箱持ちを含む「ex」表記限定)なら、そのポケモンのダメカンをheal_amountぶん回復する
    (AZのやすらぎ(AZ's Tranquility)実カードテキスト: "If you moved a Pokémon ex to your Bench in
    this way, heal 80 damage from that Pokémon."用)。"""

    heal_amount: int

    def execute(self, ctx: EffectContext) -> None:
        player = _attacker_player(ctx)
        if ctx.target_bench_index is None or ctx.target_bench_index >= len(player.bench):
            return
        new_active = player.bench.pop(ctx.target_bench_index)
        old_active = player.active
        if old_active is not None:
            old_active_card = ctx.card_db.get(old_active.card_id)
            if old_active_card is not None and "ex" in old_active_card.subtypes:
                old_active.heal(self.heal_amount)
            player.bench.append(old_active)
        player.active = new_active
        ctx.log(f"{ctx.source_card_id} でバトルポケモンを入れ替えた")


@dataclass(frozen=True)
class DealDamagePerOwnBenchedDamagedPokemon(Effect):
    """自分のベンチポケモンのうちダメカンが乗っている数ぶん追加ダメージ(ガーディロミラーex
    (Gourgeist ex)「Horrifying Rondo」実カードテキスト: "This attack does 50 more damage for each
    of your Benched Pokémon that has any damage counters on it."用)。"""

    base: int
    per_damaged_bench: int

    def execute(self, ctx: EffectContext) -> None:
        player = _attacker_player(ctx)
        count = sum(1 for mon in player.bench if mon.damage > 0)
        DealDamage(self.base + self.per_damaged_bench * count).execute(ctx)


@dataclass(frozen=True)
class DiscardToolsAndSpecialEnergyFromAllOpponentPokemon(Effect):
    """相手の場の全ポケモンについているポケモンのどうぐ・特殊エネルギーを全てトラッシュする
    (メガドラミドロex(Mega Dragalge ex)「Corrosive Liquid」実カードテキスト: "Discard all Pokémon
    Tools and Special Energy from all of your opponent's Pokémon."用)。"""

    def execute(self, ctx: EffectContext) -> None:
        opponent = ctx.state.player(ctx.opponent)
        for mon in opponent.all_pokemon_in_play():
            if mon.attached_tool is not None:
                discard_attached_tool(ctx.state, opponent, mon)
            remaining: list[str] = []
            for eid in mon.attached_energy:
                card = ctx.card_db.get(eid)
                if card is not None and card.is_special_energy:
                    opponent.discard.append(eid)
                else:
                    remaining.append(eid)
            mon.attached_energy = remaining
        ctx.log(f"{ctx.source_card_id} で相手の場の全ポケモンのどうぐ・特殊エネルギーをトラッシュした")


@dataclass(frozen=True)
class HealAllPokemonBothSides(Effect):
    """場の両プレイヤーの全ポケモンのダメカンをamountぶん回復する(メガフラエッテex(Mega Floette ex)
    「Gentle Light」実カードテキスト: "Heal 30 damage from each Pokémon (both yours and your
    opponent's)."用)。"""

    amount: int

    def execute(self, ctx: EffectContext) -> None:
        for player in ctx.state.players:
            for mon in player.all_pokemon_in_play():
                mon.heal(self.amount)


@dataclass(frozen=True)
class RevealOpponentHandThenDrawPerPokemonFound(Effect):
    """相手が手札を公開し、その中にいるポケモンカードの枚数ぶんカードを引く(エマ(Emma)実カード
    テキスト: "Your opponent reveals their hand, and you draw a card for each Pokémon you find
    there."用)。"""

    def execute(self, ctx: EffectContext) -> None:
        player = _attacker_player(ctx)
        opponent = ctx.state.player(ctx.opponent)
        count = sum(1 for cid in opponent.hand if (card := ctx.card_db.get(cid)) is not None and card.is_pokemon)
        ctx.log(f"相手の手札を公開: ポケモン{count}枚")
        Draw(count).execute(ctx)


@dataclass(frozen=True)
class BonusDamageIfSelfUndamaged(Effect):
    """自分自身にダメカンが1個も乗っていなければ追加ダメージ(メガエルレイドex(Mega Gallade ex)
    「Gale Slash」実カードテキスト: "If this Pokémon has no damage counters on it, this attack does
    150 more damage."用)。"""

    base: int
    bonus: int

    def execute(self, ctx: EffectContext) -> None:
        bonus = self.bonus if (ctx.source_pokemon is not None and ctx.source_pokemon.damage == 0) else 0
        DealDamage(self.base + bonus).execute(ctx)


@dataclass(frozen=True)
class DealDamageLessPerSelfDamageCounters(Effect):
    """自分自身に乗っているダメカン1個につきダメージが減少する(メガファイヤローex(Mega Pyroar ex)
    「Fiery Big Bang」実カードテキスト: "This attack does 10 less damage for each damage counter on
    this Pokémon."用)。"""

    base: int
    per_self_damage_counter: int

    def execute(self, ctx: EffectContext) -> None:
        counters = ctx.source_pokemon.damage // 10 if ctx.source_pokemon is not None else 0
        DealDamage(max(0, self.base - self.per_self_damage_counter * counters)).execute(ctx)


@dataclass(frozen=True)
class DamagePerAllOpponentPokemonDamageCounters(Effect):
    """相手の場の全ポケモン(バトル+ベンチ)に乗っているダメカンの合計数ぶん追加ダメージ
    (デスカーン(Trevenant)「Overwhelming Pain」実カードテキスト: "This attack does 10 more damage
    for each damage counter on all of your opponent's Pokémon."用)。"""

    base: int
    per_counter: int

    def execute(self, ctx: EffectContext) -> None:
        opponent = ctx.state.player(ctx.opponent)
        counters = sum(mon.damage // 10 for mon in opponent.all_pokemon_in_play())
        DealDamage(self.base + self.per_counter * counters).execute(ctx)


@dataclass(frozen=True)
class BonusDamageIfDefenderHasNoRetreatCost(Effect):
    """相手のバトルポケモンのにげるコストが0なら追加ダメージ(マスキッパ(Carnivine)「Chomp Whole」
    実カードテキスト: "If your opponent's Active Pokémon has no Retreat Cost, this attack does 80
    more damage."用)。"""

    base: int
    bonus: int

    def execute(self, ctx: EffectContext) -> None:
        _, defender = _defender(ctx)
        defender_card = ctx.card_db.get(defender.card_id) if defender is not None else None
        bonus = self.bonus if (defender_card is not None and defender_card.retreat_cost_count == 0) else 0
        DealDamage(self.base + bonus).execute(ctx)


@dataclass(frozen=True)
class BonusDamageIfSelfHasAnySpecialEnergyAttached(Effect):
    """自分自身に特殊エネルギーが(タイプ問わず)何か1枚でもついていれば追加ダメージ(ナットレイ
    (Ferrothorn)「Special Whip」実カードテキスト: "If this Pokémon has any Special Energy attached,
    this attack does 70 more damage."用)。"""

    base: int
    bonus: int

    def execute(self, ctx: EffectContext) -> None:
        has_special = ctx.source_pokemon is not None and any(
            (c := ctx.card_db.get(eid)) is not None and c.is_special_energy for eid in ctx.source_pokemon.attached_energy
        )
        DealDamage(self.base + (self.bonus if has_special else 0)).execute(ctx)


@dataclass(frozen=True)
class DamageWithBonusBenchIfExtraEnergy(Effect):
    """このワザのコストに加えて、追加でextra_neededぶん以上のエネルギーがついていれば、選んだ相手の
    ベンチポケモンにもbench_bonusダメージ(デオキシス「Psyspear」実カードテキスト: "If this Pokémon
    has at least 2 extra Energy attached (in addition to this attack's cost), this attack also does
    120 damage to 1 of your opponent's Benched Pokémon."用)。"""

    base: int
    cost_count: int
    extra_needed: int
    bench_bonus: int

    def execute(self, ctx: EffectContext) -> None:
        DealDamage(self.base).execute(ctx)
        if ctx.source_pokemon is None:
            return
        extra = len(ctx.source_pokemon.attached_energy) - self.cost_count
        if extra >= self.extra_needed:
            DealBonusDamageToChosenOpponentBench(self.bench_bonus).execute(ctx)


@dataclass(frozen=True)
class DamagePerOwnAttachedEnergyOfTypeAcrossBoard(Effect):
    """自分の場(バトル+ベンチ)の全ポケモンについている、指定タイプのエネルギーの合計数ぶんダメージ
    (ゼルネアス(Xerneas)「Geo Storm」実カードテキスト: "This attack does 30 damage for each Psychic
    Energy attached to all of your Pokémon."用)。"""

    per_energy: int
    energy_type: str

    def execute(self, ctx: EffectContext) -> None:
        player = _attacker_player(ctx)
        count = sum(
            1
            for mon in player.all_pokemon_in_play()
            for eid in mon.attached_energy
            if (c := ctx.card_db.get(eid)) is not None and c.basic_energy_type == self.energy_type
        )
        DealDamage(self.per_energy * count).execute(ctx)


@dataclass(frozen=True)
class DrawPerOpponentPokemonWithSubtypes(Effect):
    """相手の場にいる指定サブタイプ(いずれか)のポケモンの数だけカードを引く(ジェット(Jett)実カード
    テキスト: "Draw a card for each of your opponent's Mega Evolution Pokémon ex in play."用。
    「Mega Evolution Pokémon ex」は"MEGA"かつ"ex"の両方を持つポケモンを指す)。"""

    subtypes: tuple[str, ...]

    def execute(self, ctx: EffectContext) -> None:
        opponent = ctx.state.player(ctx.opponent)
        subtype_set = set(self.subtypes)
        count = sum(
            1
            for mon in opponent.all_pokemon_in_play()
            if (c := ctx.card_db.get(mon.card_id)) is not None and subtype_set <= set(c.subtypes)
        )
        Draw(count).execute(ctx)


@dataclass(frozen=True)
class ConfuseBothActiveNonDarknessPokemon(Effect):
    """両プレイヤーのバトルポケモンのうち、悪タイプでない方をすべてこんらんにする(ダークベル
    (Dark Bell)実カードテキスト: "Both Active non-Darkness Pokémon are now Confused."用)。"""

    def execute(self, ctx: EffectContext) -> None:
        for player in ctx.state.players:
            mon = player.active
            if mon is None:
                continue
            card = ctx.card_db.get(mon.card_id)
            if card is not None and "Darkness" not in card.types:
                mon.status.apply_exclusive(ExclusiveCondition.CONFUSED)


@dataclass(frozen=True)
class DamageOnlyIfDefenderConfused(Effect):
    """相手のバトルポケモンがこんらんでなければ、このワザは何もしない(マーラッカ(Malamar)
    「Brain Crush」実カードテキスト: "If your opponent's Active Pokémon isn't Confused, this attack
    does nothing."用)。"""

    amount: int

    def execute(self, ctx: EffectContext) -> None:
        _, defender = _defender(ctx)
        if defender is None or defender.status.exclusive != ExclusiveCondition.CONFUSED:
            return
        DealDamage(self.amount).execute(ctx)


@dataclass(frozen=True)
class ShuffleOwnHandIntoDeckThenDraw(Effect):
    """自分の手札を山札に戻してシャッフルし、count枚引く(コレクレー(Morpeko ex)「Wheely Draw」
    実カードテキスト用。両プレイヤー版のBothPlayersShuffleHandAndDrawFixedと異なり自分のみ)。
    bonus_count_if_prizes_remaining指定時、自分の残りサイドがちょうど6枚(ダメージを受けていない)なら
    countの代わりにこの枚数を引く(リーリエの決意(Lillie's Determination)実カードテキスト用)。"""

    count: int
    bonus_count_if_prizes_remaining: int | None = None

    def execute(self, ctx: EffectContext) -> None:
        player = _attacker_player(ctx)
        count = self.count
        if self.bonus_count_if_prizes_remaining is not None and len(player.prizes) == 6:
            count = self.bonus_count_if_prizes_remaining
        player.deck.extend(player.hand)
        player.hand = []
        ctx.rng.shuffle(player.deck)
        for _ in range(count):
            if not player.deck:
                break
            player.hand.append(player.deck.pop(0))


@dataclass(frozen=True)
class DamageIgnoringWeaknessBonusIfSelfDamaged(Effect):
    """自分自身にダメカンがmin_countersカウンタ以上乗っていれば追加ダメージ、弱点は計算しない
    (Chi-Yu「Whirling Envy」実カードテキスト: "If this Pokémon has 2 or more damage counters on it,
    this attack does 90 more damage. This attack's damage isn't affected by Weakness."用)。"""

    base: int
    bonus: int
    min_counters: int

    def execute(self, ctx: EffectContext) -> None:
        if ctx.source_pokemon is None:
            return
        counters = ctx.source_pokemon.damage // 10
        amount = self.base + (self.bonus if counters >= self.min_counters else 0)
        _, defender = _defender(ctx)
        if defender is None or _defender_is_shielded(ctx, defender):
            return
        defender_card = ctx.card_db.get(defender.card_id)
        if defender_card is None:
            return
        dmg = resolve_attack_damage(ctx, defender, defender_card, amount, apply_weakness=False)
        defender.damage += dmg
        ctx.damage_dealt += dmg
        ctx.log(f"{ctx.source_card_id} が(弱点を無視して) {dmg} ダメージ")


@dataclass(frozen=True)
class BonusDamageIfDefenderType(Effect):
    """相手のバトルポケモンが指定タイプなら追加ダメージ(ドーミラー(Bronzor)「Mirror Attack」
    実カードテキスト: "If your opponent's Active Pokémon is a Metal Pokémon, this attack does 30
    more damage."用)。"""

    base: int
    bonus: int
    defender_type: str

    def execute(self, ctx: EffectContext) -> None:
        _, defender = _defender(ctx)
        defender_card = ctx.card_db.get(defender.card_id) if defender is not None else None
        matches = defender_card is not None and self.defender_type in defender_card.types
        DealDamage(self.base + (self.bonus if matches else 0)).execute(ctx)


@dataclass(frozen=True)
class DamagePerTotalBenchedPokemonBothSides(Effect):
    """両プレイヤーのベンチポケモンの合計数ぶん追加ダメージ(ドードリオ(Toucannon)「Feather Rondo」
    実カードテキスト: "This attack does 20 more damage for each Benched Pokémon (both yours and your
    opponent's)."用)。"""

    base: int
    per_bench: int

    def execute(self, ctx: EffectContext) -> None:
        count = sum(len(p.bench) for p in ctx.state.players)
        DealDamage(self.base + self.per_bench * count).execute(ctx)


@dataclass(frozen=True)
class DamageReducedPerDefenderEnergyCount(Effect):
    """相手のバトルポケモンについているエネルギーの数だけダメージが減る(パオジアン(Tinkaton)
    「Windup Swing」実カードテキスト: "This attack does 60 less damage for each Energy attached to
    your opponent's Active Pokémon."用)。"""

    base: int
    per_energy: int

    def execute(self, ctx: EffectContext) -> None:
        _, defender = _defender(ctx)
        count = len(defender.attached_energy) if defender is not None else 0
        DealDamage(max(0, self.base - self.per_energy * count)).execute(ctx)


@dataclass(frozen=True)
class DealFixedDamageToAllBenchedPokemonBothSides(Effect):
    """両プレイヤーのベンチポケモン全員に固定ダメージ(弱点・抵抗力は計算しない、クサイハナ
    (Gloom)「Disperse Drool」実カードテキスト: "This attack also does 20 damage to each Benched
    Pokémon (both yours and your opponent's)."用)。"""

    amount: int

    def execute(self, ctx: EffectContext) -> None:
        for player in ctx.state.players:
            for mon in player.bench:
                if _defender_is_shielded(ctx, mon):
                    continue
                mon.damage += self.amount
                ctx.damage_dealt += self.amount


@dataclass(frozen=True)
class BonusDamageIfOwnBoardEnergyTypeCountAtLeast(Effect):
    """自分の場(バトル+ベンチ)についている指定タイプのエネルギーの合計がmin_count以上なら追加ダメージ
    (ライコウ(Raikou)「Electro Fall」実カードテキスト: "If you have at least 4 Lightning Energy in
    play, this attack does 90 more damage."用)。"""

    base: int
    bonus: int
    energy_type: str
    min_count: int

    def execute(self, ctx: EffectContext) -> None:
        player = _attacker_player(ctx)
        count = sum(
            1
            for mon in player.all_pokemon_in_play()
            for eid in mon.attached_energy
            if (c := ctx.card_db.get(eid)) is not None and c.basic_energy_type == self.energy_type
        )
        DealDamage(self.base + (self.bonus if count >= self.min_count else 0)).execute(ctx)


@dataclass(frozen=True)
class AllCoinsHeadsThen(Effect):
    """コインをcount枚投げ、全て表ならthenを実行する(ケンタロス(Miltank)「Bellyful of Milk」、
    ガチグマ(Bewear)「Hyper Lariat」等)。"""

    count: int
    then: tuple[Effect, ...] = ()

    def execute(self, ctx: EffectContext) -> None:
        all_heads = all(ctx.rng.random() < 0.5 for _ in range(self.count))
        ctx.log(f"コインを{self.count}枚投げて" + ("全て表" if all_heads else "裏を含む"))
        if all_heads:
            for effect in self.then:
                effect.execute(ctx)


@dataclass(frozen=True)
class BonusDamageIfDefenderBurned(Effect):
    """相手のバトルポケモンがやけどなら追加ダメージ(メガバクーダex(Mega Camerupt ex)「Roasting
    Heat」実カードテキスト用)。"""

    base: int
    bonus: int

    def execute(self, ctx: EffectContext) -> None:
        _, defender = _defender(ctx)
        burned = defender is not None and defender.status.burned
        DealDamage(self.base + (self.bonus if burned else 0)).execute(ctx)


@dataclass(frozen=True)
class DamageReducedIfDefenderAlreadyDamaged(Effect):
    """相手のバトルポケモンに既にダメカンが乗っていれば、ダメージが低い方の値になる(メガクチートex
    「Huge Bite」実カードテキスト: "If your opponent's Active Pokémon already has any damage counters
    on it, this attack's base damage is 30."用)。"""

    normal: int
    reduced: int

    def execute(self, ctx: EffectContext) -> None:
        _, defender = _defender(ctx)
        already_damaged = defender is not None and defender.damage > 0
        DealDamage(self.reduced if already_damaged else self.normal).execute(ctx)


@dataclass(frozen=True)
class BonusDamageIfOwnPrizesRemainingExactly(Effect):
    """自分の残りサイドがちょうどcount枚のとき追加ダメージ(ハガネール(Steelix)「Welcoming Tail」
    実カードテキスト: "If you have exactly 6 Prize cards remaining, this attack does 200 more
    damage."用。相手側の残りサイドを見るBonusDamageIfOpponentPrizesExactlyとは対象が異なる)。"""

    base: int
    bonus: int
    count: int

    def execute(self, ctx: EffectContext) -> None:
        player = _attacker_player(ctx)
        bonus = self.bonus if len(player.prizes) == self.count else 0
        DealDamage(self.base + bonus).execute(ctx)


@dataclass(frozen=True)
class BonusDamageIfOpponentPrizesExactly(Effect):
    """相手の残りサイドがちょうどcount枚のとき追加ダメージ(ハイパッチ(Palafin)「Knuckle Justice」
    実カードテキスト: "If your opponent has exactly 1 Prize card remaining, this attack does 200
    more damage."用)。"""

    base: int
    bonus: int
    count: int

    def execute(self, ctx: EffectContext) -> None:
        opponent = ctx.state.player(ctx.opponent)
        bonus = self.bonus if len(opponent.prizes) == self.count else 0
        DealDamage(self.base + bonus).execute(ctx)


@dataclass(frozen=True)
class BonusDamageIfOwnHandEmpty(Effect):
    """自分の手札が0枚のとき追加ダメージ(ヤドラン(Slowbro)「All Out」実カードテキスト: "If you have
    no cards in your hand, this attack does 160 more damage."用)。"""

    base: int
    bonus: int

    def execute(self, ctx: EffectContext) -> None:
        player = _attacker_player(ctx)
        DealDamage(self.base + (self.bonus if not player.hand else 0)).execute(ctx)


@dataclass(frozen=True)
class BonusDamageIfDefenderIsEvolved(Effect):
    """相手のバトルポケモンが進化ポケモンなら追加ダメージ(コライドン(Koraidon)「Battle Claw」
    実カードテキスト: "If your opponent's Active Pokémon is an Evolution Pokémon, this attack does
    30 more damage."用)。"""

    base: int
    bonus: int

    def execute(self, ctx: EffectContext) -> None:
        _, defender = _defender(ctx)
        defender_card = ctx.card_db.get(defender.card_id) if defender is not None else None
        is_evolved = defender_card is not None and defender_card.is_pokemon and not defender_card.is_basic
        DealDamage(self.base + (self.bonus if is_evolved else 0)).execute(ctx)


@dataclass(frozen=True)
class DamagePerColorlessInOpponentActiveRetreatCost(Effect):
    """相手のバトルポケモンのにげるコストに含まれる無色エネルギーの数だけ追加ダメージ(メガシャン
    デラex(Mega Chandelure ex)「Phantom Maze」、マーシャドー(Marshadow)「Shadowy Knot」実カード
    テキスト用)。"""

    base: int
    per_colorless: int

    def execute(self, ctx: EffectContext) -> None:
        _, defender = _defender(ctx)
        defender_card = ctx.card_db.get(defender.card_id) if defender is not None else None
        count = defender_card.retreat_cost_count if defender_card is not None else 0
        DealDamage(self.base + self.per_colorless * count).execute(ctx)


@dataclass(frozen=True)
class BonusDamageIfAnyOwnBenchedDamaged(Effect):
    """自分のベンチポケモンに1匹でもダメカンが乗っていれば追加ダメージ(メガダークライex(Mega
    Darkrai ex)「Dusk Raid」実カードテキスト: "If your Benched Pokémon have any damage counters on
    them, this attack does 110 more damage."用)。"""

    base: int
    bonus: int

    def execute(self, ctx: EffectContext) -> None:
        player = _attacker_player(ctx)
        has_damaged = any(mon.damage > 0 for mon in player.bench)
        DealDamage(self.base + (self.bonus if has_damaged else 0)).execute(ctx)


@dataclass(frozen=True)
class DevolveOpponentActiveIfEvolved(Effect):
    """ダメージを伴わず、相手のバトルポケモンが進化ポケモンなら1段階退化させ、外れた進化カードを
    相手の手札に加える(アーケオスの特性「Ancient Wing」実カードテキスト: "Once during your turn,
    if this Pokémon is in the Active Spot, you may devolve 1 of your opponent's evolved Pokémon
    by putting the highest Stage Evolution card on it into your opponent's hand."用。「してもよい」
    は特性を使うかどうかの選択自体で表現され、相手のバトルポケモンが進化ポケモンでなければ
    何もしない)。"""

    def execute(self, ctx: EffectContext) -> None:
        opponent = ctx.state.player(ctx.opponent)
        target = opponent.active
        if target is None or not target.evolution_history:
            return
        opponent.hand.append(target.card_id)
        target.card_id = target.evolution_history.pop()


@dataclass(frozen=True)
class DealDamageThenDevolveOpponentActiveIfEvolved(Effect):
    """相手のバトルポケモンが進化ポケモンなら1段階退化させ、外れた進化カードを相手の手札に加える
    (ネンドール(Claydol)「Devolution Ray」実カードテキスト: "If your opponent's Active Pokémon is
    an evolved Pokémon, devolve it by putting the highest Stage Evolution card on it into your
    opponent's hand."用)。"""

    amount: int

    def execute(self, ctx: EffectContext) -> None:
        DealDamage(self.amount).execute(ctx)
        opponent = ctx.state.player(ctx.opponent)
        target = opponent.active
        if target is None or not target.evolution_history:
            return
        opponent.hand.append(target.card_id)
        target.card_id = target.evolution_history.pop()
        ctx.log(f"{ctx.source_card_id} で相手のバトルポケモンを退化させた")


@dataclass(frozen=True)
class OpponentPoisonedCantRetreatNextTurn(Effect):
    """相手の次の番の間、どくのポケモンはにげられなくする(新しくどくになったポケモンも含む)
    (ロクシーの気迫(Roxie's Performance)実カードテキスト用)。"""

    def execute(self, ctx: EffectContext) -> None:
        opponent = ctx.state.player(ctx.opponent)
        opponent.poisoned_cant_retreat_until_turn = opponent.turns_taken + 1


@dataclass(frozen=True)
class DamageToChosenOpponentPokemonScaledByOwnPokemonNamedCoinFlips(Effect):
    """自分の場に指定の名前を含むポケモンが1匹につきコインを1枚投げ、表の数だけ選んだ相手の
    ポケモン1匹に固定ダメージ(タウロス(Tauros)「Target Together」実カードテキスト: "flip a coin
    for each of your Pokémon in play that has "Tauros" in its name. This attack does 50 damage to
    the chosen Pokémon for each heads."用。弱点・抵抗力は計算しない)。"""

    per_heads: int
    name_contains: str

    def execute(self, ctx: EffectContext) -> None:
        player = _attacker_player(ctx)
        flips = sum(
            1
            for mon in player.all_pokemon_in_play()
            if (c := ctx.card_db.get(mon.card_id)) is not None and self.name_contains in c.name
        )
        heads_count = sum(1 for _ in range(flips) if ctx.rng.random() < 0.5)
        amount = self.per_heads * heads_count
        if ctx.target_bench_index is None:
            opponent = ctx.state.player(ctx.opponent)
            target = opponent.active
            if target is None or _defender_is_shielded(ctx, target):
                return
            target_card = ctx.card_db.get(target.card_id)
            if target_card is None:
                return
            dmg = resolve_attack_damage(ctx, target, target_card, amount)
            target.damage += dmg
            ctx.damage_dealt += dmg
        else:
            DealBonusDamageToChosenOpponentBench(amount).execute(ctx)


@dataclass(frozen=True)
class BonusDamageIfStadiumInPlay(Effect):
    """場にスタジアムがあれば追加ダメージ(トラッシュはしない、モルフォン(Vivillon)「Blow
    Through」実カードテキスト: "If a Stadium is in play, this attack does 60 more damage."用。
    スタジアムをトラッシュするDealDamageBonusIfStadiumInPlayThenDiscardItとは異なる)。"""

    base: int
    bonus: int

    def execute(self, ctx: EffectContext) -> None:
        bonus = self.bonus if ctx.state.stadium_in_play is not None else 0
        DealDamage(self.base + bonus).execute(ctx)


@dataclass(frozen=True)
class DiscardOpponentDeckPerHeadsUntilTails(Effect):
    """裏が出るまでコインを投げ続け、オモテの数だけ相手の山札の上からトラッシュする
    (ロケット団のディグダ「Relentless Burrowing」実カードテキスト: "Flip a coin until you get tails.
    For each heads, discard the top card of your opponent's deck."用)。"""

    def execute(self, ctx: EffectContext) -> None:
        heads_count = 0
        while ctx.rng.random() < 0.5:
            heads_count += 1
        ctx.coin_heads_count = heads_count
        if heads_count:
            DiscardTopOfOpponentDeck(heads_count).execute(ctx)


@dataclass(frozen=True)
class DealDamageIfHandCountExactly(Effect):
    """自分の手札がちょうどcount枚のときだけダメージを与える(それ以外なら「このワザは何もしない」、
    マラカッチ(Medicham)「Seventh Kick」実カードテキスト: "If you don't have exactly 7 cards in your
    hand, this attack does nothing."用)。"""

    amount: int
    count: int

    def execute(self, ctx: EffectContext) -> None:
        player = _attacker_player(ctx)
        if len(player.hand) == self.count:
            DealDamage(self.amount).execute(ctx)


@dataclass(frozen=True)
class DamagePerToolAttachedBothSides(Effect):
    """両プレイヤーの場にいる、どうぐがついている全てのポケモンの数×per_toolのダメージ
    (ドータクン(Bronzong)「Tool Drop」実カードテキスト: "This attack does 40 damage for each Pokémon
    Tool attached to all Pokémon."用)。"""

    per_tool: int

    def execute(self, ctx: EffectContext) -> None:
        count = sum(
            1
            for player in ctx.state.players
            for mon in player.all_pokemon_in_play()
            if mon.attached_tool is not None
        )
        DealDamage(count * self.per_tool).execute(ctx)


@dataclass(frozen=True)
class DamagePerEnergyCardInOpponentHand(Effect):
    """相手が手札を公開し、その中にあるエネルギーカードの枚数×per_energyのダメージ
    (アゲハント(Beautifly)「Energy Straw」実カードテキスト: "Your opponent reveals their hand, and
    this attack does 80 damage for each Energy card you find there."用)。"""

    per_energy: int

    def execute(self, ctx: EffectContext) -> None:
        opponent = ctx.state.player(ctx.opponent)
        count = sum(1 for cid in opponent.hand if (c := ctx.card_db.get(cid)) is not None and c.is_energy)
        DealDamage(count * self.per_energy).execute(ctx)


@dataclass(frozen=True)
class DamagePerOwnNamedPokemonWithDamageCounters(Effect):
    """自分の場(バトル+ベンチ)にいる、カード名にname_containsを含み、かつダメカンが1個以上乗っている
    ポケモンの数×per_pokemonのダメージ(パルデアのケンタロス(Paldean Tauros)「Raging Charge」実カード
    テキスト: "This attack does 40 damage for each of your Pokémon that has \"Tauros\" in its name that
    has any damage counters on it."用)。"""

    per_pokemon: int
    name_contains: str

    def execute(self, ctx: EffectContext) -> None:
        player = _attacker_player(ctx)
        count = sum(
            1
            for mon in player.all_pokemon_in_play()
            if mon.damage > 0
            and (c := ctx.card_db.get(mon.card_id)) is not None
            and self.name_contains in c.name
        )
        DealDamage(count * self.per_pokemon).execute(ctx)


@dataclass(frozen=True)
class BonusDamageIfOwnBenchHasSubtypeOfType(Effect):
    """自分のベンチに、指定サブタイプかつ指定タイプのポケモンが1匹でもいれば追加ダメージ
    (ヤミラミ(Sableye)「Cocky Claw」実カードテキスト: "If you have any Stage 2 Darkness Pokémon on
    your Bench, this attack does 70 more damage."用)。"""

    base: int
    bonus: int
    subtype: str
    pokemon_type: str

    def execute(self, ctx: EffectContext) -> None:
        player = _attacker_player(ctx)
        has_match = any(
            (c := ctx.card_db.get(mon.card_id)) is not None
            and self.subtype in c.subtypes
            and self.pokemon_type in c.types
            for mon in player.bench
        )
        DealDamage(self.base + (self.bonus if has_match else 0)).execute(ctx)


@dataclass(frozen=True)
class DealDamageIfOpponentPrizesInRange(Effect):
    """相手の残りサイドがlow以上high以下でなければ「このワザは何もしない」(ハシュード(Hop's
    Cramorant)「Fickle Spitting」実カードテキスト: "If your opponent doesn't have exactly 3 or 4
    Prize cards remaining, this attack does nothing."用)。"""

    amount: int
    low: int
    high: int

    def execute(self, ctx: EffectContext) -> None:
        opponent = ctx.state.player(ctx.opponent)
        if self.low <= len(opponent.prizes) <= self.high:
            DealDamage(self.amount).execute(ctx)


@dataclass(frozen=True)
class BonusDamageIfSelfHasToolAttached(Effect):
    """自分自身にポケモンのどうぐがついていれば追加ダメージ(オンバーン(Noivern)「Enhanced
    Blade」実カードテキスト: "If this Pokémon has a Pokémon Tool attached, this attack does 70 more
    damage."用)。"""

    base: int
    bonus: int

    def execute(self, ctx: EffectContext) -> None:
        has_tool = ctx.source_pokemon is not None and ctx.source_pokemon.attached_tool is not None
        DealDamage(self.base + (self.bonus if has_tool else 0)).execute(ctx)


@dataclass(frozen=True)
class BonusDamageIfTeamRocketSupporterPlayedThisTurn(Effect):
    """この番に「Team Rocket's」の名を含むサポートを手札からプレイしていれば追加ダメージ
    (ロケット団のガブリアスex(Team Rocket's Kangaskhan ex)「Wicked Impact」実カードテキスト:
    "If you played a Supporter card that has \"Team Rocket\" in its name from your hand during this
    turn, this attack does 100 more damage."用)。"""

    base: int
    bonus: int

    def execute(self, ctx: EffectContext) -> None:
        player = _attacker_player(ctx)
        DealDamage(self.base + (self.bonus if player.team_rocket_supporter_played_this_turn else 0)).execute(ctx)


@dataclass(frozen=True)
class DamagePerOwnTeamRocketsPokemonInPlay(Effect):
    """自分の場(バトル+ベンチ)にいる「Team Rocket's」ポケモンの数×per_pokemonのダメージ
    (ロケット団のクサリヘビ(Team Rocket's Spidops)「Rocket Rush」実カードテキスト: "This attack
    does 30 damage for each of your Team Rocket's Pokémon in play."用)。"""

    per_pokemon: int

    def execute(self, ctx: EffectContext) -> None:
        player = _attacker_player(ctx)
        count = sum(1 for mon in player.all_pokemon_in_play() if is_team_rockets_pokemon(ctx.card_db.get(mon.card_id)))
        DealDamage(count * self.per_pokemon).execute(ctx)


@dataclass(frozen=True)
class DealDamageIfDefenderBurned(Effect):
    """相手のバトルポケモンがやけどでなければ「このワザは何もしない」(バクーダ(Camerupt)
    「Roasting Burn」実カードテキスト: "If your opponent's Active Pokémon isn't Burned, this attack
    does nothing."用)。"""

    amount: int

    def execute(self, ctx: EffectContext) -> None:
        _, defender = _defender(ctx)
        if defender is not None and defender.status.burned:
            DealDamage(self.amount).execute(ctx)


@dataclass(frozen=True)
class DamagePerOpponentDiscardBasicEnergyCount(Effect):
    """相手のトラッシュにある基本エネルギーの枚数×per_cardのダメージ(バルジーナ(N's Darmanitan)
    「Back Draft」実カードテキスト: "This attack does 30 damage for each Basic Energy card in your
    opponent's discard pile."用)。"""

    per_card: int

    def execute(self, ctx: EffectContext) -> None:
        opponent = ctx.state.player(ctx.opponent)
        count = sum(
            1 for cid in opponent.discard if (c := ctx.card_db.get(cid)) is not None and not c.is_special_energy and c.is_energy
        )
        DealDamage(count * self.per_card).execute(ctx)


@dataclass(frozen=True)
class DamagePerOwnToolAttachedCount(Effect):
    """自分の場(バトル+ベンチ)にいる、どうぐがついている全てのポケモンの数×per_toolのダメージ
    (ロトム(Rotom)「Gadget Show」実カードテキスト: "This attack does 30 damage for each Pokémon Tool
    attached to all of your Pokémon."用。ドータクンの「Tool Drop」(両者の場が対象)とは異なり自分の場のみ)。"""

    per_tool: int

    def execute(self, ctx: EffectContext) -> None:
        player = _attacker_player(ctx)
        count = sum(1 for mon in player.all_pokemon_in_play() if mon.attached_tool is not None)
        DealDamage(count * self.per_tool).execute(ctx)


@dataclass(frozen=True)
class BonusDamageIfOwnDiscardEnergyCountAtLeast(Effect):
    """自分のトラッシュにある指定タイプの基本エネルギーがmin_count枚以上あれば追加ダメージ
    (シャンデラ(Chandelure)「Incendiary Pillar」実カードテキスト: "If you have 10 or more Basic Fire
    Energy cards in your discard pile, this attack does 100 more damage."用)。"""

    base: int
    bonus: int
    energy_type: str
    min_count: int

    def execute(self, ctx: EffectContext) -> None:
        player = _attacker_player(ctx)
        count = sum(
            1 for cid in player.discard if (c := ctx.card_db.get(cid)) is not None and c.basic_energy_type == self.energy_type
        )
        DealDamage(self.base + (self.bonus if count >= self.min_count else 0)).execute(ctx)


@dataclass(frozen=True)
class HealSelfEqualToDamageDealt(Effect):
    """このワザで相手のバトルポケモンに与えたダメージと同じ数値だけ、自分自身のダメージを回復する
    (ビリジオン(Virizion)「Giga Drain」実カードテキスト: "Heal from this Pokémon the same amount of
    damage you did to your opponent's Active Pokémon."用。直前のDealDamage等の後に置くこと)。"""

    def execute(self, ctx: EffectContext) -> None:
        if ctx.source_pokemon is not None:
            ctx.source_pokemon.heal(ctx.damage_dealt)


@dataclass(frozen=True)
class DealDamageIfDefenderAlreadyDamaged(Effect):
    """相手のバトルポケモンにダメカンが1個も無ければ「このワザは何もしない」(バスラオ(Basculin)
    「Bared Fangs」実カードテキスト: "If your opponent's Active Pokémon has no damage counters on it
    before this attack does damage, this attack does nothing."用)。"""

    amount: int

    def execute(self, ctx: EffectContext) -> None:
        _, defender = _defender(ctx)
        if defender is not None and defender.damage > 0:
            DealDamage(self.amount).execute(ctx)


@dataclass(frozen=True)
class DiscardOpponentActiveEnergyOfType(Effect):
    """相手のバトルポケモンについている指定タイプのエネルギーを1枚トラッシュする(コアルヒー
    (Ducklett)「Firefighting」実カードテキスト: "Discard a Fire Energy from your opponent's Active
    Pokémon."用)。"""

    energy_type: str

    def execute(self, ctx: EffectContext) -> None:
        opponent = ctx.state.player(ctx.opponent)
        if opponent.active is None:
            return
        for i, energy_id in enumerate(opponent.active.attached_energy):
            card = ctx.card_db.get(energy_id)
            if card is not None and card.basic_energy_type == self.energy_type:
                opponent.active.attached_energy.pop(i)
                opponent.discard.append(energy_id)
                ctx.log(f"相手のバトルポケモンの{self.energy_type}エネルギーを1枚トラッシュした")
                return


@dataclass(frozen=True)
class BonusDamageIfSelfHasEnergyType(Effect):
    """自分自身に指定タイプのエネルギーが1枚でもついていれば追加ダメージ(マッスグマ(Stunfisk)
    「Muddy Bolt」実カードテキスト: "If this Pokémon has any Fighting Energy attached, this attack
    does 20 more damage."用)。"""

    base: int
    bonus: int
    energy_type: str
    min_count: int = 1  # ユキノオー(Abomasnow)「Frozen Wood」実カードテキスト: "If this Pokémon has 2
    # or more Grass Energy attached, this attack does 120 more damage."用に必要枚数を指定できるようにした

    def execute(self, ctx: EffectContext) -> None:
        count = 0
        if ctx.source_pokemon is not None:
            count = sum(
                1
                for e in ctx.source_pokemon.attached_energy
                if (c := ctx.card_db.get(e)) is not None and c.basic_energy_type == self.energy_type
            )
        DealDamage(self.base + (self.bonus if count >= self.min_count else 0)).execute(ctx)


@dataclass(frozen=True)
class DealFixedDamageToAllOpponentBenchedPokemon(Effect):
    """相手のベンチポケモン全員に固定ダメージ(弱点・抵抗力は計算しない、バイバニラ(N's Vanilluxe)
    「Blizzard」実カードテキスト: "This attack also does 10 damage to each of your opponent's Benched
    Pokémon."用)。"""

    amount: int

    def execute(self, ctx: EffectContext) -> None:
        opponent = ctx.state.player(ctx.opponent)
        for mon in opponent.bench:
            if _defender_is_shielded(ctx, mon) or _self_bench_full_immunity(mon):
                continue
            mon_card = ctx.card_db.get(mon.card_id)
            if mon_card is not None and _bench_pokemon_damage_immune(mon_card, opponent):
                continue
            mon.damage += self.amount
            ctx.damage_dealt += self.amount


@dataclass(frozen=True)
class DoubleAllOpponentDamageCounters(Effect):
    """相手の場の全てのポケモンについているダメカンの数を2倍にする(バイバニラ(N's Vanilluxe)
    「Snow Coating」実カードテキスト: "Double the number of damage counters on each of your opponent's
    Pokémon."用)。"""

    def execute(self, ctx: EffectContext) -> None:
        opponent = ctx.state.player(ctx.opponent)
        for mon in opponent.all_pokemon_in_play():
            mon.damage *= 2


@dataclass(frozen=True)
class EachPlayerDraws(Effect):
    """自分・相手の両方が指定枚数ドローする(ユキノオー(Frosmoth)「Alluring Wings」実カードテキスト:
    "Each player draws a card."用)。"""

    count: int = 1

    def execute(self, ctx: EffectContext) -> None:
        for idx in range(2):
            player = ctx.state.player(idx)
            for _ in range(self.count):
                if not player.deck:
                    break
                player.hand.append(player.deck.pop(0))


@dataclass(frozen=True)
class FlipMultipleCoinsForBonusDamageThenStatusIfAnyHeads(Effect):
    """コインをcount枚投げてオモテの数×per_headsぶんダメージを上乗せし、1枚でもオモテが出ていれば
    相手のバトルポケモンを指定の特殊状態にする(バイバニラ(Vanilluxe)「Double Freeze」実カード
    テキスト: "Flip 2 coins. This attack does 90 damage for each heads. If either of them is heads,
    your opponent's Active Pokémon is now Paralyzed."用)。"""

    count: int
    per_heads: int
    condition: str
    min_heads: int = 1  # バタフリー(Butterfree)「Scale Hurricane」実カードテキスト: "If at least 2 of
    # them are heads, your opponent's Active Pokémon is now Paralyzed."用に閾値を指定できるようにした

    def execute(self, ctx: EffectContext) -> None:
        heads = sum(1 for _ in range(self.count) if ctx.rng.random() < 0.5)
        DealDamage(self.per_heads * heads).execute(ctx)
        if heads >= self.min_heads:
            InflictStatusOnDefender(condition=self.condition).execute(ctx)


@dataclass(frozen=True)
class DamageCounterOnChosenOpponentBenchIfActiveHasSpecialCondition(Effect):
    """相手のバトルポケモンが特殊状態(どく・やけど・ねむり・マヒ・こんらんのいずれか)であれば、
    選んだ相手のベンチポケモン1匹にダメカンを乗せる(ミカルゲ(Mismagius)「Assassin's Magic」実カード
    テキスト: "If your opponent's Active Pokémon is affected by a Special Condition, place 6 damage
    counters on 1 of your opponent's Benched Pokémon."用。ダメカンを直接のせる効果のため弱点・抵抗力は
    計算しない)。"""

    count: int

    def execute(self, ctx: EffectContext) -> None:
        opponent = ctx.state.player(ctx.opponent)
        active = opponent.active
        has_condition = active is not None and (
            active.status.poisoned or active.status.burned or active.status.exclusive != ExclusiveCondition.NONE
        )
        if has_condition:
            DamageCounterOnChosenOpponentPokemon(count=self.count).execute(ctx)


@dataclass(frozen=True)
class BonusDamagePerBenchCountBothSides(Effect):
    """両プレイヤーのベンチポケモンの合計数×per_pokemonぶん追加ダメージ(リーリエのピッピex
    (Lillie's Clefairy ex)「Full Moon Rondo」実カードテキスト: "This attack does 20 more damage for
    each Benched Pokémon (both yours and your opponent's)."用)。"""

    base: int
    per_pokemon: int

    def execute(self, ctx: EffectContext) -> None:
        count = sum(len(player.bench) for player in ctx.state.players)
        DealDamage(self.base + count * self.per_pokemon).execute(ctx)


@dataclass(frozen=True)
class BonusDamageIfDefenderHasResistanceType(Effect):
    """相手のバトルポケモンが指定タイプへの抵抗力を持っていれば追加ダメージ(ダンゴロ(Boldore)
    「Smack Down」実カードテキスト: "If your opponent's Active Pokémon has Fighting Resistance, this
    attack does 50 more damage."用)。"""

    base: int
    bonus: int
    resistance_type: str

    def execute(self, ctx: EffectContext) -> None:
        _, defender = _defender(ctx)
        has_resistance = False
        if defender is not None:
            defender_card = ctx.card_db.get(defender.card_id)
            if defender_card is not None:
                has_resistance = any(r.type == self.resistance_type for r in defender_card.resistances)
        DealDamage(self.base + (self.bonus if has_resistance else 0)).execute(ctx)


@dataclass(frozen=True)
class DamagePerTypeBenchedDamageCounters(Effect):
    """自分のベンチにいる、指定タイプを持つポケモン全員のダメカン合計数×per_counterぶんのダメージ
    (ダイノーズ(Gigalith)「Vengeful Cannon」実カードテキスト: "This attack does 20 damage for each
    damage counter on all of your Benched Fighting Pokémon."用)。"""

    per_counter: int
    pokemon_type: str

    def execute(self, ctx: EffectContext) -> None:
        player = _attacker_player(ctx)
        counters = sum(
            mon.damage // 10
            for mon in player.bench
            if (c := ctx.card_db.get(mon.card_id)) is not None and self.pokemon_type in c.types
        )
        DealDamage(counters * self.per_counter).execute(ctx)


@dataclass(frozen=True)
class FlipCoinPerOwnPokemonOfTypeForDamage(Effect):
    """自分の場(バトル+ベンチ)にいる指定タイプのポケモンの数だけコインを投げ、オモテの数×per_heads
    ぶんダメージ(シザヤンマ(Scrafty)「Ruffians Attack」実カードテキスト: "Flip a coin for each
    Darkness Pokémon you have in play. This attack does 60 damage for each heads."用)。"""

    per_heads: int
    pokemon_type: str

    def execute(self, ctx: EffectContext) -> None:
        player = _attacker_player(ctx)
        coin_count = sum(
            1 for mon in player.all_pokemon_in_play() if (c := ctx.card_db.get(mon.card_id)) is not None and self.pokemon_type in c.types
        )
        heads = sum(1 for _ in range(coin_count) if ctx.rng.random() < 0.5)
        DealDamage(heads * self.per_heads).execute(ctx)


@dataclass(frozen=True)
class DamagePerOpponentBenchedPokemonCount(Effect):
    """相手のベンチポケモンの数×per_pokemonぶんダメージ(ゾロアーク(Zoroark)「Mind Jack」実カード
    テキスト: "This attack does 30 damage for each of your opponent's Benched Pokémon."用)。"""

    per_pokemon: int
    base: int = 0  # 「40+ / 20 more damage for each of your opponent's Benched Pokémon」の基本ダメージ

    def execute(self, ctx: EffectContext) -> None:
        opponent = ctx.state.player(ctx.opponent)
        DealDamage(self.base + len(opponent.bench) * self.per_pokemon).execute(ctx)


@dataclass(frozen=True)
class BonusDamageIfHandCountEqualsOpponent(Effect):
    """自分の手札枚数と相手の手札枚数が同じなら追加ダメージ(ゴチルゼル(Gothitelle)「Synchro
    Shot」実カードテキスト: "If you have the same number of cards in your hand as your opponent, this
    attack does 90 more damage."用)。"""

    base: int
    bonus: int

    def execute(self, ctx: EffectContext) -> None:
        player = _attacker_player(ctx)
        opponent = ctx.state.player(ctx.opponent)
        equal = len(player.hand) == len(opponent.hand)
        DealDamage(self.base + (self.bonus if equal else 0)).execute(ctx)


@dataclass(frozen=True)
class ForceOpponentShuffleHandThenDraw(Effect):
    """相手の手札を山札に戻してシャッフルし、指定枚数引かせる(ゴチルゼル(Gothitelle)「Distorted
    Future」実カードテキスト: "you may have your opponent shuffle their hand into their deck and draw
    3 cards."用)。"""

    count: int

    def execute(self, ctx: EffectContext) -> None:
        opponent = ctx.state.player(ctx.opponent)
        opponent.deck.extend(opponent.hand)
        opponent.hand = []
        ctx.rng.shuffle(opponent.deck)
        for _ in range(self.count):
            if not opponent.deck:
                break
            opponent.hand.append(opponent.deck.pop(0))


@dataclass(frozen=True)
class BonusDamageIfNamedPokemonOnBench(Effect):
    """自分のベンチに指定した名前のポケモンが1匹でもいれば追加ダメージ(アリアドス(Durant)「Bite
    Together」実カードテキスト: "If Durant is on your Bench, this attack does 20 more damage."用)。
    contains=True指定時は完全一致ではなく名前に含むかで判定する(ドサイドン(Team Rocket's Nidoqueen)
    「Love Impact」実カードテキスト: "If a Pokémon that has 'Nidoking' in its name is on your Bench,
    this attack does 120 more damage."用)。"""

    base: int
    bonus: int
    name: str
    contains: bool = False

    def execute(self, ctx: EffectContext) -> None:
        player = _attacker_player(ctx)

        def _matches(c) -> bool:
            return (self.name in c.name) if self.contains else (c.name == self.name)

        has_match = any((c := ctx.card_db.get(mon.card_id)) is not None and _matches(c) for mon in player.bench)
        DealDamage(self.base + (self.bonus if has_match else 0)).execute(ctx)


@dataclass(frozen=True)
class FlipCoinsThenRetrieveFromDiscardToHand(Effect):
    """コインをcount枚投げ、オモテの数まで自分のトラッシュから好きなカードを選んで手札に加える
    (グリガルデ(Stoutland)「Odor Sleuth」実カードテキスト: "Flip 3 coins. Put a number of cards up to
    the number of heads from your discard pile into your hand."用)。"""

    count: int

    def execute(self, ctx: EffectContext) -> None:
        heads = sum(1 for _ in range(self.count) if ctx.rng.random() < 0.5)
        ctx.coin_heads_count = heads
        player = _attacker_player(ctx)
        if heads <= 0 or not player.discard:
            return
        ctx.state.pending_search_choice = PendingSearchChoice(
            player_index=ctx.acting_player,
            zone="discard",
            source_indices=list(range(len(player.discard))),
            card_ids=list(player.discard),
            min_count=0,
            max_count=min(heads, len(player.discard)),
            prompt=f"トラッシュから最大{heads}枚選んで手札に加える",
            shuffle_after=False,
            all_card_ids=list(player.discard),
            destination="hand",
        )


@dataclass(frozen=True)
class DealDamageIfOwnBenchCountAtMost(Effect):
    """自分のベンチポケモンの数がmax_count以下なら「このワザは何もしない」(ビクティニ(Victini)
    「V-Force」実カードテキスト: "If you have 4 or fewer Benched Pokémon, this attack does
    nothing."用。文面上は「4匹以下なら何もしない」=5匹以上いないと発動しないの意)。"""

    amount: int
    min_more_than: int

    def execute(self, ctx: EffectContext) -> None:
        player = _attacker_player(ctx)
        if len(player.bench) > self.min_more_than:
            DealDamage(self.amount).execute(ctx)


@dataclass(frozen=True)
class DamagePerOpponentHandTrainerCount(Effect):
    """相手が手札を公開し、その中にあるトレーナーズカードの枚数×per_cardのダメージ(モフーラン
    (Whimsicott ex)「Wondrous Cotton」実カードテキスト: "Your opponent reveals their hand. This
    attack does 50 damage for each Trainer card you find there."用)。"""

    per_card: int

    def execute(self, ctx: EffectContext) -> None:
        opponent = ctx.state.player(ctx.opponent)
        count = sum(1 for cid in opponent.hand if (c := ctx.card_db.get(cid)) is not None and c.supertype == "Trainer")
        DealDamage(count * self.per_card).execute(ctx)


@dataclass(frozen=True)
class DealDamageIfDefenderHasSubtypeIgnoringWeaknessResistance(Effect):
    """相手のバトルポケモンが指定サブタイプ(例: "ex")でなければ「このワザは何もしない」、該当すれば
    弱点・抵抗力を無視して固定ダメージ(エンブオー(Sawk)「Rising Chop」実カードテキスト: "If your
    opponent's Active Pokémon isn't a Pokémon ex, this attack does nothing. This attack's damage isn't
    affected by Weakness or Resistance."用)。"""

    amount: int
    subtype: str

    def execute(self, ctx: EffectContext) -> None:
        _, defender = _defender(ctx)
        if defender is None:
            return
        defender_card = ctx.card_db.get(defender.card_id)
        if defender_card is not None and self.subtype in defender_card.subtypes:
            DealDamageIgnoringWeaknessResistance(self.amount).execute(ctx)


@dataclass(frozen=True)
class BonusDamageIfSameEnergyCountAsDefender(Effect):
    """自分自身と相手のバトルポケモンについているエネルギーの数が同じなら追加ダメージ(チャーレム
    (Medicham)「Harmonious Spirit Palm」実カードテキスト: "If this Pokémon and your opponent's Active
    Pokémon have the same amount of Energy attached, this attack does 120 more damage."用)。"""

    base: int
    bonus: int

    def execute(self, ctx: EffectContext) -> None:
        _, defender = _defender(ctx)
        same = (
            ctx.source_pokemon is not None
            and defender is not None
            and len(ctx.source_pokemon.attached_energy) == len(defender.attached_energy)
        )
        DealDamage(self.base + (self.bonus if same else 0)).execute(ctx)


@dataclass(frozen=True)
class DamagePerDefenderSpecialConditionCount(Effect):
    """相手のバトルポケモンにかかっている特殊状態(どく・やけど・ねむり・マヒ・こんらん)の数×
    per_conditionぶんダメージ(ベトベター(Team Rocket's Muk)「Hazardous Venom」実カードテキスト:
    "This attack does 100 damage for each Special Condition affecting your opponent's Active
    Pokémon."用)。"""

    per_condition: int
    base: int = 0  # 「20+ / 50 more damage for each Special Condition」の基本ダメージ

    def execute(self, ctx: EffectContext) -> None:
        _, defender = _defender(ctx)
        count = 0
        if defender is not None:
            if defender.status.poisoned:
                count += 1
            if defender.status.burned:
                count += 1
            if defender.status.exclusive != ExclusiveCondition.NONE:
                count += 1
        DealDamage(self.base + count * self.per_condition).execute(ctx)


@dataclass(frozen=True)
class DamagePerPokemonBothSidesNamedContains(Effect):
    """両プレイヤーの場(バトル+ベンチ)にいる、カード名にnamesのいずれかを含むポケモンの総数×
    per_pokemonぶんダメージ(マタドガス(Team Rocket's Weezing)「Explode Together Now」実カード
    テキスト: "This attack does 40 damage for each Pokémon in play that has 'Koffing' or 'Weezing' in
    its name (both yours and your opponent's)."用)。"""

    per_pokemon: int
    names: tuple[str, ...]

    def execute(self, ctx: EffectContext) -> None:
        count = sum(
            1
            for player in ctx.state.players
            for mon in player.all_pokemon_in_play()
            if (c := ctx.card_db.get(mon.card_id)) is not None and any(n in c.name for n in self.names)
        )
        DealDamage(count * self.per_pokemon).execute(ctx)


@dataclass(frozen=True)
class BonusDamageIfSelfNotDamaged(Effect):
    """自分自身にダメカンが1個も無ければ追加ダメージ(マホイップex(Arven's Mabosstiff ex)
    「Vigorous Tackle」実カードテキスト: "If this Pokémon has no damage counters on it, this attack
    does 120 more damage."用)。"""

    base: int
    bonus: int

    def execute(self, ctx: EffectContext) -> None:
        not_damaged = ctx.source_pokemon is not None and ctx.source_pokemon.damage == 0
        DealDamage(self.base + (self.bonus if not_damaged else 0)).execute(ctx)


@dataclass(frozen=True)
class DealDamageIfCanDiscardEnergyFromHand(Effect):
    """手札から指定タイプの基本エネルギーをちょうどcount枚捨てられるときだけダメージを与える(捨てる
    のはコストとして必須、足りなければ「このワザは何もしない」。ラフレシア(Lurantis)「Petal Blade
    Dance」実カードテキスト: "Discard 2 Basic Grass Energy cards from your hand. If you can't discard 2
    cards in this way, this attack does nothing."用)。"""

    amount: int
    count: int
    energy_type: str

    def execute(self, ctx: EffectContext) -> None:
        player = _attacker_player(ctx)
        matching = [
            cid for cid in player.hand
            if (c := ctx.card_db.get(cid)) is not None and c.basic_energy_type == self.energy_type
        ]
        if len(matching) < self.count:
            return
        to_discard = matching[: self.count]
        for cid in to_discard:
            player.hand.remove(cid)
        player.discard.extend(to_discard)
        DealDamage(self.amount).execute(ctx)


@dataclass(frozen=True)
class LockSelfRetreatNextTurn(Effect):
    """次の自分の番、このポケモンはにげられなくなる(エアームド(Skarmory)「Roost」実カード
    テキスト: "During your next turn, this Pokémon can't retreat."用。DisableDefenderRetreatNextTurnは
    相手ポケモンが対象なのに対し、こちらは自分自身が対象)。"""

    def execute(self, ctx: EffectContext) -> None:
        if ctx.source_pokemon is None:
            return
        player = _attacker_player(ctx)
        ctx.source_pokemon.retreat_disabled_until_turn = player.turns_taken + 1


@dataclass(frozen=True)
class SelfDamageUnlessAllCoinsTails(Effect):
    """コインをcount枚投げて、1枚でもオモテが出たら自分自身にamountダメージ(ラッタ(Team Rocket's
    Raticate)「Reckless Abandon」実カードテキスト: "Flip 2 coins. If both of them are tails, this
    Pokémon also does 90 damage to itself."を反転させた表現。つまり全て裏のときだけ自傷しない)。"""

    count: int
    amount: int

    def execute(self, ctx: EffectContext) -> None:
        all_tails = all(ctx.rng.random() >= 0.5 for _ in range(self.count))
        if not all_tails:
            SelfDamage(self.amount).execute(ctx)


@dataclass(frozen=True)
class BonusDamageIfDefenderIsEvolutionPokemon(Effect):
    """相手のバトルポケモンがたねポケモンでなければ(進化ポケモンなら)追加ダメージ(ケンタロス
    (Tauros)「Clean Hit」実カードテキスト: "If your opponent's Active Pokémon is an Evolution
    Pokémon, this attack does 50 more damage."用)。"""

    base: int
    bonus: int

    def execute(self, ctx: EffectContext) -> None:
        _, defender = _defender(ctx)
        is_evolution = False
        if defender is not None:
            defender_card = ctx.card_db.get(defender.card_id)
            is_evolution = defender_card is not None and not defender_card.is_basic
        DealDamage(self.base + (self.bonus if is_evolution else 0)).execute(ctx)


@dataclass(frozen=True)
class DiscardDefenderTool(Effect):
    """ダメージを与える前に、相手のバトルポケモンについているポケモンのどうぐを全てトラッシュする
    (ぺろぺろキャンディ(Arven's Skwovet)「Gnaw Through」実カードテキスト: "Before doing damage,
    discard all Pokémon Tools from your opponent's Active Pokémon."用)。"""

    def execute(self, ctx: EffectContext) -> None:
        opponent = ctx.state.player(ctx.opponent)
        if opponent.active is not None and opponent.active.attached_tool is not None:
            discard_attached_tool(ctx.state, opponent, opponent.active)


@dataclass(frozen=True)
class HealOwnActiveBonusIfNamedPrefix(Effect):
    """自分のバトルポケモンのダメージをamount回復する。バトルポケモンの名前がname_prefixで
    始まっていればbonus_amountを回復する(アルベールのサンドイッチ(Arven's Sandwich)実カード
    テキスト: "Heal 30 damage from your Active Pokémon. If that Pokémon is an Arven's Pokémon, heal
    100 damage from it instead."用)。"""

    amount: int
    bonus_amount: int
    name_prefix: str

    def execute(self, ctx: EffectContext) -> None:
        player = _attacker_player(ctx)
        if player.active is None:
            return
        active_card = ctx.card_db.get(player.active.card_id)
        amount = self.amount
        if active_card is not None and active_card.name.startswith(self.name_prefix):
            amount = self.bonus_amount
        player.active.heal(amount)


@dataclass(frozen=True)
class DrawBonusIfOpponentPrizesAtMost(Effect):
    """手札をbase枚になるまで引く。相手の残りサイドがthreshold枚以下ならbonus枚になるまで引く
    (MCのアオリ(Emcee's Hype)実カードテキスト: "Draw 2 cards. If your opponent has 3 or fewer Prize
    cards remaining, draw 2 more cards."用)。"""

    base: int
    bonus: int
    threshold: int

    def execute(self, ctx: EffectContext) -> None:
        player = _attacker_player(ctx)
        opponent = ctx.state.player(ctx.opponent)
        count = self.bonus if len(opponent.prizes) <= self.threshold else self.base
        for _ in range(count):
            if not player.deck:
                break
            player.hand.append(player.deck.pop(0))




# ---- Iレギュレーション新規カード実装 第9バッチ向けに追加したプリミティブ ----


@dataclass(frozen=True)
class DamageCounterOnOwnActive(Effect):
    """自分のバトルポケモンにダメカンをのせる(弱点・抵抗力は計算しない、対象選択不要)。
    ロケット団の切り札爆弾(Team Rocket's Venture Bomb)実カードテキスト: "If tails, put 2 damage
    counters on your Active Pokémon."用。"""

    count: int = 1

    def execute(self, ctx: EffectContext) -> None:
        player = _attacker_player(ctx)
        if player.active is None:
            return
        player.active.damage += self.count * 10
        ctx.log(f"{ctx.source_card_id} が自分のバトルポケモンにダメカンを{self.count}個のせた")


@dataclass(frozen=True)
class KnockOutDefenderIfCanDiscardEnergyFromHand(Effect):
    """手札から指定タイプの基本エネルギーをちょうどcount枚捨てられるときだけ、相手のバトルポケモンを
    問答無用できぜつさせる(捨てるのはコストとして必須、足りなければ「このワザは何もしない」。
    カミツオロチ(Hydrapple)「Hydra Breath」実カードテキスト: "Discard 6 Basic Grass Energy cards from
    your hand, and Knock Out your opponent's Active Pokémon. If you can't discard 6 cards in this way,
    this attack does nothing."用)。"""

    count: int
    energy_type: str

    def execute(self, ctx: EffectContext) -> None:
        player = _attacker_player(ctx)
        matching = [
            cid for cid in player.hand
            if (c := ctx.card_db.get(cid)) is not None and c.basic_energy_type == self.energy_type
        ]
        if len(matching) < self.count:
            return
        to_discard = matching[: self.count]
        for cid in to_discard:
            player.hand.remove(cid)
        player.discard.extend(to_discard)
        KnockOutOpponentActive().execute(ctx)


@dataclass(frozen=True)
class ShuffleRandomFromOpponentHandIntoDeck(Effect):
    """相手の手札からランダムに1枚選び、公開してから山札に戻してシャッフルする(ロトム(Rotom)
    「Astonish」実カードテキスト: "Choose a random card from your opponent's hand. Your opponent
    reveals that card and shuffles it into their deck."用)。"""

    def execute(self, ctx: EffectContext) -> None:
        opponent = ctx.state.player(ctx.opponent)
        if not opponent.hand:
            return
        idx = ctx.rng.randrange(len(opponent.hand))
        card_id = opponent.hand.pop(idx)
        opponent.deck.append(card_id)
        ctx.rng.shuffle(opponent.deck)
        name = ctx.card_db.get(card_id).name if ctx.card_db.get(card_id) else card_id
        ctx.log(f"相手の手札からランダムに{name}が公開され、山札に戻ってシャッフルされた")


@dataclass(frozen=True)
class DamagePerNamePrefixMilledFromTopOfOwnDeck(Effect):
    """自分の山札の上からcount枚をトラッシュし、その中にあった名前がname_prefixで始まるカードの
    枚数×per_pokemonのダメージ(ミストのギャラドス(Misty's Gyarados)「Splashing Panic」実カード
    テキスト: "Discard the top 7 cards of your deck, and this attack does 70 damage for each Misty's
    Pokémon that you discarded in this way."用)。"""

    count: int
    per_pokemon: int
    name_prefix: str

    def execute(self, ctx: EffectContext) -> None:
        player = _attacker_player(ctx)
        milled = player.deck[: self.count]
        player.deck = player.deck[self.count :]
        player.discard.extend(milled)
        matched = sum(
            1
            for cid in milled
            if (c := ctx.card_db.get(cid)) is not None and c.name.startswith(self.name_prefix)
        )
        ctx.log(f"{ctx.source_card_id} が山札の上から{len(milled)}枚をトラッシュし、うち{matched}枚が{self.name_prefix}のカードだった")
        DealDamage(matched * self.per_pokemon).execute(ctx)


@dataclass(frozen=True)
class DiscardOwnTeamRocketEnergyThenKnockOutDefender(Effect):
    """このポケモンについているロケット団のエネルギーを1枚トラッシュできるときだけ、相手のバトル
    ポケモンとつけられているカードを全てトラッシュする(通常のきぜつと同様にサイドを取る)。
    ロケット団のファイヤー(Team Rocket's Moltres ex)「Evil Incineration」実カードテキスト:
    "Discard a Team Rocket's Energy from this Pokémon. If you do, discard your opponent's Active
    Pokémon and all attached cards."用。"""

    def execute(self, ctx: EffectContext) -> None:
        if ctx.source_pokemon is None:
            return
        from engine.energy import TEAM_ROCKET_ENERGY_ID, TEAM_ROCKET_ENERGY_REPRINT_ID

        matching = [
            e for e in ctx.source_pokemon.attached_energy
            if e in (TEAM_ROCKET_ENERGY_ID, TEAM_ROCKET_ENERGY_REPRINT_ID)
        ]
        if not matching:
            return
        energy_id = matching[0]
        ctx.source_pokemon.attached_energy.remove(energy_id)
        player = _attacker_player(ctx)
        player.discard.append(energy_id)
        KnockOutOpponentActive().execute(ctx)


# ---- Iレギュレーション新規カード実装 第10バッチ向けに追加したプリミティブ ----


@dataclass(frozen=True)
class FlipCoinPerOpponentBenchCountForDamageToActive(Effect):
    """相手のベンチポケモンの数だけコインを投げ、裏の数×per_tailsのダメージを相手のバトルポケモンに
    与える(弱点・抵抗力は計算しない)。ロケット団のスリーパー(Team Rocket's Hypno)「Bench
    Manipulation」実カードテキスト: "Your opponent flips a coin for each of their Benched Pokémon.
    This attack does 80 damage to your opponent's Active Pokémon for each tails. This attack's damage
    isn't affected by Weakness or Resistance."用。"""

    per_tails: int

    def execute(self, ctx: EffectContext) -> None:
        opponent = ctx.state.player(ctx.opponent)
        tails_count = sum(1 for _ in opponent.bench if ctx.rng.random() >= 0.5)
        DealDamageIgnoringWeaknessResistance(tails_count * self.per_tails).execute(ctx)


@dataclass(frozen=True)
class SearchDeckForNamePrefixBasicPokemonToBench(Effect):
    """山札から、カード名がname_prefixで始まるたねポケモンを最大count匹まで探してベンチに出す
    (スティーブンのバルビート(Steven's Baltoy)「Summoning Sign」実カードテキスト: "Search your deck
    for up to 2 Basic Steven's Pokémon and put them onto your Bench."用)。"""

    name_prefix: str
    count: int

    def execute(self, ctx: EffectContext) -> None:
        player = _attacker_player(ctx)

        def matches(card):
            return card is not None and card.is_basic and card.name.startswith(self.name_prefix)

        _trigger_search_choice(
            ctx, player, "deck", matches, self.count,
            f"山札から{self.name_prefix}のたねポケモンを探してベンチに出す", destination="bench",
        )


@dataclass(frozen=True)
class ReshuffleTakenPrizesAndRedraw(Effect):
    """自分の残りサイド(表向きにせず)をシャッフルして山札の下に加え、そこから同じ枚数を山札の
    上から取って新しいサイドにする(かえっこチケット(Redeemable Ticket)実カードテキスト: "Count
    your Prize cards, shuffle them, and put them on the bottom of your deck. Then, take that many
    cards from the top of your deck and put them face down as your Prize cards."用)。"""

    def execute(self, ctx: EffectContext) -> None:
        player = _attacker_player(ctx)
        count = len(player.prizes)
        if count == 0:
            return
        old_prizes = player.prizes
        player.prizes = []
        player.deck.extend(old_prizes)
        ctx.rng.shuffle(player.deck)
        player.prizes = player.deck[:count]
        player.reset_prize_marks()
        player.deck = player.deck[count:]
        ctx.log(f"{ctx.source_card_id} がサイド{count}枚をシャッフルして山札に加え、新しいサイドを取った")


@dataclass(frozen=True)
class HealTargetThenDiscardEnergyIfHealed(Effect):
    """選んだ自分のポケモン1匹のダメージをamountぶん回復する。実際に回復したなら、そのポケモンから
    エネルギーを1枚トラッシュする(かいふくのくすり改めスーパーポーション(Super Potion)実カード
    テキスト: "Heal 60 damage from 1 of your Pokémon. If you healed any damage in this way, discard
    an Energy from that Pokémon."用)。"""

    amount: int

    def execute(self, ctx: EffectContext) -> None:
        player = _attacker_player(ctx)
        target = _resolve_own_target(ctx, player)
        if target is None:
            return
        healed = target.damage > 0
        target.heal(self.amount)
        if healed and target.attached_energy:
            energy_id = target.attached_energy.pop(0)
            player.discard.append(energy_id)


@dataclass(frozen=True)
class DiscardChosenOpponentToolAndSpecialEnergy(Effect):
    """選んだ相手のポケモン1匹(バトル/ベンチどちらでも指定可)についているポケモンのどうぐと
    特殊エネルギーをそれぞれ1枚トラッシュする(ワル者(Ruffian)実カードテキスト: "Discard a Pokémon
    Tool and a Special Energy from 1 of your opponent's Pokémon."用)。"""

    def execute(self, ctx: EffectContext) -> None:
        opponent = ctx.state.player(ctx.opponent)
        target = _resolve_opponent_target(ctx, opponent)
        if target is None:
            return
        if target.attached_tool is not None:
            discard_attached_tool(ctx.state, opponent, target)
        special_idx = next(
            (i for i, e in enumerate(target.attached_energy) if (c := ctx.card_db.get(e)) is not None and c.is_special_energy),
            None,
        )
        if special_idx is not None:
            energy_id = target.attached_energy.pop(special_idx)
            opponent.discard.append(energy_id)


@dataclass(frozen=True)
class DamagePerOwnBenchedSubtypeCount(Effect):
    """自分のベンチにいる、指定サブタイプを持つポケモンの数×per_pokemonのダメージ(マンムーex
    (Mamoswine ex)「Rumbling March」実カードテキスト: "This attack does 40 more damage for each
    Stage 2 Pokémon on your Bench."用)。"""

    base: int
    per_pokemon: int
    subtype: str

    def execute(self, ctx: EffectContext) -> None:
        player = _attacker_player(ctx)
        count = sum(
            1
            for mon in player.bench
            if (c := ctx.card_db.get(mon.card_id)) is not None and self.subtype in c.subtypes
        )
        DealDamage(self.base + self.per_pokemon * count).execute(ctx)


# ---- Iレギュレーション新規カード実装 第11バッチ向けに追加したプリミティブ ----


@dataclass(frozen=True)
class DealFixedDamageToAllOwnBenchedPokemon(Effect):
    """自分のベンチポケモン全員に固定ダメージ(弱点・抵抗力は計算しない、ダンデのサダイジャ
    (Hop's Sandaconda)「Break Ground」実カードテキスト: "This attack also does 20 damage to each of
    your Benched Pokémon."用)。"""

    amount: int

    def execute(self, ctx: EffectContext) -> None:
        player = _attacker_player(ctx)
        for mon in player.bench:
            if _defender_is_shielded(ctx, mon) or _self_bench_full_immunity(mon):
                continue
            mon_card = ctx.card_db.get(mon.card_id)
            if mon_card is not None and _bench_pokemon_damage_immune(mon_card, player):
                continue
            mon.damage += self.amount
            ctx.damage_dealt += self.amount


@dataclass(frozen=True)
class DamagePerNamePrefixBoardEnergyCount(Effect):
    """自分の場(バトル+ベンチ)にいる、名前がname_prefixで始まる自分のポケモンについている指定
    タイプのエネルギーの合計数×per_energyのダメージが上乗せされる(ヨノのボルトロス(Iono's
    Voltorb)「Voltaic Chain」実カードテキスト: "This attack does 20 more damage for each Lightning
    Energy attached to all of your Iono's Pokémon."用)。"""

    base: int
    per_energy: int
    energy_type: str
    name_prefix: str

    def execute(self, ctx: EffectContext) -> None:
        player = _attacker_player(ctx)
        count = sum(
            1
            for mon in player.all_pokemon_in_play()
            if (mc := ctx.card_db.get(mon.card_id)) is not None and mc.name.startswith(self.name_prefix)
            for eid in mon.attached_energy
            if (ec := ctx.card_db.get(eid)) is not None and ec.basic_energy_type == self.energy_type
        )
        DealDamage(self.base + self.per_energy * count).execute(ctx)


@dataclass(frozen=True)
class BonusDamageIfTwoNamedPokemonOnBench(Effect):
    """自分のベンチに、指定した2つの名前のポケモンが両方いれば追加ダメージ(メタグロス(Metagross)
    「Conjoined Beams」実カードテキスト: "If Beldum and Metang are on your Bench, this attack does
    150 more damage."用)。"""

    base: int
    bonus: int
    name_a: str
    name_b: str

    def execute(self, ctx: EffectContext) -> None:
        player = _attacker_player(ctx)
        names = {mc.name for mon in player.bench if (mc := ctx.card_db.get(mon.card_id)) is not None}
        bonus = self.bonus if self.name_a in names and self.name_b in names else 0
        DealDamage(self.base + bonus).execute(ctx)


@dataclass(frozen=True)
class WinGameIfExactlyOnePrizeRemaining(Effect):
    """このワザを使ったとき、自分の残りサイドがちょうど1枚なら即座にこのゲームに勝利する(Nの
    ギガイアス改めシギリスGX……ではなくNのギガシギルの「Victory Symbol」実カードテキスト:
    "If you use this attack when you have exactly 1 Prize card remaining, you win this game."用)。"""

    def execute(self, ctx: EffectContext) -> None:
        player = _attacker_player(ctx)
        if len(player.prizes) == 1:
            ctx.state.winner = ctx.acting_player
            ctx.state.win_reason = "victory_symbol"
            ctx.log(f"{ctx.source_card_id} の「Victory Symbol」によりゲームに勝利した")


@dataclass(frozen=True)
class LookTopCardMayDiscard(Effect):
    """自分の山札の一番上を見て、そのカードを捨ててもよい(イワンコ(Rockruff)「Dig It Up」実
    カードテキスト: "Look at the top card of your deck. You may discard that card."用。「捨てても
    よい」は常に捨てる側を選ぶ規約に従い無条件で捨てる)。"""

    def execute(self, ctx: EffectContext) -> None:
        player = _attacker_player(ctx)
        if not player.deck:
            return
        card_id = player.deck.pop(0)
        player.discard.append(card_id)


@dataclass(frozen=True)
class DiscardDefenderEnergyPerHeads(Effect):
    """コインをcoin_count枚投げ、オモテの数だけ相手のバトルポケモンについているエネルギーを
    トラッシュする(ラッキー鋏改めヌケニンではなくガケガニ(Klawf)「Snipping Pincers」実カード
    テキスト: "Flip 2 coins. For each heads, discard an Energy from your opponent's Active
    Pokémon."用)。"""

    coin_count: int

    def execute(self, ctx: EffectContext) -> None:
        heads = sum(1 for _ in range(self.coin_count) if ctx.rng.random() < 0.5)
        for _ in range(heads):
            DiscardOpponentActiveEnergy().execute(ctx)


@dataclass(frozen=True)
class MoveDefenderEnergyToOpponentHand(Effect):
    """相手のバトルポケモンについているエネルギーを1枚、相手の手札に戻す(オクタン(Octillery)
    「Aqua Wash」実カードテキスト: "You may put an Energy attached to your opponent's Active
    Pokémon into their hand."用)。"""

    def execute(self, ctx: EffectContext) -> None:
        opponent = ctx.state.player(ctx.opponent)
        if opponent.active is None or not opponent.active.attached_energy:
            return
        energy_id = opponent.active.attached_energy.pop(0)
        opponent.hand.append(energy_id)


@dataclass(frozen=True)
class DiscardDefenderToolThenParalyzeIfDiscarded(Effect):
    """ダメージを与える前に、相手のバトルポケモンについているどうぐをトラッシュする。実際にどうぐを
    トラッシュできたときだけ、相手のバトルポケモンをマヒ状態にする(Nのジャラコ改めNのメリープ
    ……ではなくNのバチュル(N's Joltik)「Zapping Short」実カードテキスト: "Before doing damage,
    discard all Pokémon Tools from your opponent's Active Pokémon. If you discarded a Pokémon Tool
    in this way, your opponent's Active Pokémon is now Paralyzed."用)。"""

    def execute(self, ctx: EffectContext) -> None:
        opponent = ctx.state.player(ctx.opponent)
        if opponent.active is not None and opponent.active.attached_tool is not None:
            discard_attached_tool(ctx.state, opponent, opponent.active)
            InflictStatusOnDefender(condition="paralyzed").execute(ctx)


@dataclass(frozen=True)
class ShuffleHandThenDrawEqualToOpponentHandSize(Effect):
    """自分の手札を山札に戻してシャッフルし、相手の手札の枚数と同じ数だけ引く(ソーナンス(Mr.
    Mime)「Mimic」実カードテキスト: "Shuffle your hand into your deck. Then, draw a card for each
    card in your opponent's hand."用)。"""

    def execute(self, ctx: EffectContext) -> None:
        player = _attacker_player(ctx)
        opponent = ctx.state.player(ctx.opponent)
        count = len(opponent.hand)
        player.deck.extend(player.hand)
        player.hand = []
        ctx.rng.shuffle(player.deck)
        Draw(count).execute(ctx)


# ---- Iレギュレーション新規カード実装 第12バッチ向けに追加したプリミティブ ----


@dataclass(frozen=True)
class OpponentDiscardExactlyFromHand(Effect):
    """相手が、手札からちょうどcount枚(手札がそれ未満ならあるだけ)を自分で選んでトラッシュする
    (サンディコ(Sandile)「Tighten Up」実カードテキスト: "Your opponent discards a card from their
    hand."用。相手自身が選ぶ点はOpponentDiscardHandDownToと同じだが、こちらは「何枚残すか」ではなく
    「何枚捨てるか」を直接指定する)。"""

    count: int

    def execute(self, ctx: EffectContext) -> None:
        opponent = ctx.state.player(ctx.opponent)
        discard_amount = min(self.count, len(opponent.hand))
        if discard_amount <= 0:
            return
        ctx.state.pending_search_choice = PendingSearchChoice(
            player_index=ctx.opponent,
            zone="hand",
            source_indices=list(range(len(opponent.hand))),
            card_ids=list(opponent.hand),
            min_count=discard_amount,
            max_count=discard_amount,
            prompt=f"手札から{discard_amount}枚トラッシュする",
            shuffle_after=False,
            all_card_ids=list(opponent.hand),
            destination="discard",
        )


@dataclass(frozen=True)
class BonusDamageIfOpponentHandCountAtMost(Effect):
    """相手の手札がthreshold枚以下なら追加ダメージ(クロコダイル改めクロコロク(Krookodile)
    「Cursed Slug」実カードテキスト: "If your opponent has 3 or fewer cards in their hand, this
    attack does 120 more damage."用)。"""

    base: int
    bonus: int
    threshold: int

    def execute(self, ctx: EffectContext) -> None:
        opponent = ctx.state.player(ctx.opponent)
        bonus = self.bonus if len(opponent.hand) <= self.threshold else 0
        DealDamage(self.base + bonus).execute(ctx)


@dataclass(frozen=True)
class DamageReducedByDefenderRetreatCostColorless(Effect):
    """相手のバトルポケモンのにげるコスト(無色換算)1個につきper_colorlessぶんダメージが少なくなる
    (ドッコラー(Throh)「Shoulder Throw」実カードテキスト: "This attack does 30 less damage for each
    Colorless in your opponent's Active Pokémon's Retreat Cost."用)。"""

    base: int
    per_colorless: int

    def execute(self, ctx: EffectContext) -> None:
        _, defender = _defender(ctx)
        retreat_cost = 0
        if defender is not None:
            defender_card = ctx.card_db.get(defender.card_id)
            if defender_card is not None:
                retreat_cost = len(defender_card.retreat_cost)
        DealDamage(max(0, self.base - self.per_colorless * retreat_cost)).execute(ctx)


@dataclass(frozen=True)
class RevealOpponentHandOnly(Effect):
    """相手に手札を公開させる(以後の追加効果は無い、ポッポ(Pidove)「Scout」実カードテキスト:
    "Your opponent reveals their hand."用)。"""

    def execute(self, ctx: EffectContext) -> None:
        opponent = ctx.state.player(ctx.opponent)
        ctx.state.player(ctx.acting_player).known_opponent_hand = list(opponent.hand)


@dataclass(frozen=True)
class DamagePerOwnEvolvedPokemonInPlay(Effect):
    """自分の場(バトル+ベンチ)にいる進化ポケモンの数×per_pokemonのダメージが上乗せされる
    (ダブラン(Reuniclus)「Evo-Lariat」実カードテキスト: "This attack does 40 more damage for each of
    your Evolution Pokémon in play."用)。"""

    base: int
    per_pokemon: int

    def execute(self, ctx: EffectContext) -> None:
        player = _attacker_player(ctx)
        count = sum(
            1
            for mon in player.all_pokemon_in_play()
            if (c := ctx.card_db.get(mon.card_id)) is not None and c.is_pokemon and not c.is_basic
        )
        DealDamage(self.base + self.per_pokemon * count).execute(ctx)


@dataclass(frozen=True)
class KnockOutDefenderIfBasic(Effect):
    """相手のバトルポケモンがたねポケモンなら、問答無用できぜつさせる(クリムガンZ改めオノノクス
    (Haxorus)「Axe Blast」実カードテキスト: "If your opponent's Active Pokémon is a Basic Pokémon,
    it is Knocked Out."用)。"""

    def execute(self, ctx: EffectContext) -> None:
        opponent = ctx.state.player(ctx.opponent)
        if opponent.active is None:
            return
        defender_card = ctx.card_db.get(opponent.active.card_id)
        if defender_card is not None and defender_card.is_basic:
            KnockOutOpponentActive().execute(ctx)


@dataclass(frozen=True)
class DealFixedDamageToAllOpponentBenchedPokemonScaledByPrizesTaken(Effect):
    """相手の取ったサイドの枚数×per_prizeのダメージを、相手のベンチポケモン全員に与える(弱点・
    抵抗力は計算しない、キュレムex(Kyurem ex)「Blizzard Burst」実カードテキスト: "This attack also
    does 10 damage to each of your opponent's Benched Pokémon for each Prize card your opponent has
    taken."用)。"""

    per_prize: int

    def execute(self, ctx: EffectContext) -> None:
        opponent = ctx.state.player(ctx.opponent)
        prizes_taken = 6 - len(opponent.prizes)
        amount = prizes_taken * self.per_prize
        if amount <= 0:
            return
        DealFixedDamageToAllOpponentBenchedPokemon(amount).execute(ctx)


@dataclass(frozen=True)
class BonusDamageIfDefenderHasSpecialCondition(Effect):
    """相手のバトルポケモンが特殊状態(どく・やけど・ねむり・マヒ・こんらんのいずれか)であれば
    追加ダメージ(モロバレル(Amoonguss)「Dangerous Reaction」実カードテキスト: "If your opponent's
    Active Pokémon is affected by a Special Condition, this attack does 120 more damage."用)。"""

    base: int
    bonus: int

    def execute(self, ctx: EffectContext) -> None:
        _, defender = _defender(ctx)
        has_condition = defender is not None and defender.status.is_any
        DealDamage(self.base + (self.bonus if has_condition else 0)).execute(ctx)


@dataclass(frozen=True)
class DamagePerOwnPokemonWithNamedAttackInPlay(Effect):
    """自分の場(バトル+ベンチ)にいる、指定した名前のワザを持つポケモンの数×per_pokemonの
    ダメージ(オタマロ(Tympole)/ガマガル(Palpitoad)/ガマゲロゲ(Seismitoad)「Round」実カード
    テキスト: "This attack does 20 damage for each of your Pokémon in play that has the Round
    attack."用。このワザ自身を使っているポケモンも含めて数える)。"""

    per_pokemon: int
    attack_name: str

    def execute(self, ctx: EffectContext) -> None:
        player = _attacker_player(ctx)
        count = sum(
            1
            for mon in player.all_pokemon_in_play()
            if (c := ctx.card_db.get(mon.card_id)) is not None
            and any(a.name == self.attack_name for a in (c.attacks or []))
        )
        DealDamage(self.per_pokemon * count).execute(ctx)


# 生成されたパッシブ特性(effects/generated_abilities.py)のうち、既存のIDテーブルで処理できる種別を取り込む
def _merge_generated_passive_tables() -> None:
    from effects.passives import ids_with_kind

    _SURVIVE_LETHAL_HIT_AT_FULL_HP_ABILITY_IDS.update(ids_with_kind("survive_full_hp"))
    _COINFLIP_SURVIVE_LETHAL_HIT_ABILITY_IDS.update(ids_with_kind("survive_coin"))


_merge_generated_passive_tables()
