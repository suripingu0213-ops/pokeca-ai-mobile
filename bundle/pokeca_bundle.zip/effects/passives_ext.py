"""パッシブ特性の追加種別(2026-10-07: XY4〜XY12・SV〜メガ時代の特性の取り込み)。

effects/passives.py の各フック(ダメージ軽減・無効化/にげるコスト/ワザのコスト/最大HP/ワザの追加ダメージ等)から呼ばれる。
種別とパラメータは effects.passives.SUPPORTED_PASSIVE_KINDS に登録し、scripts/generate_abilities_patterns_b.py が宣言を生成する。
"""

from __future__ import annotations

from cards.card_db import card_has_subtype
from effects.passives import _has_energy, active_passives, global_passives, team_passives


def _energy_count(mon) -> int:
    return len(mon.attached_energy)


def _is_evolution(card) -> bool:
    return card is not None and card.is_pokemon and not card.is_basic


# ---------------------------------------------------------------------------------------------
# ダメージ・効果の無効化(防御側)
# ---------------------------------------------------------------------------------------------
def ext_damage_immune(ctx, defender, attacker_card) -> bool:
    """ワザの「ダメージだけ」を無効にする特性(Miraculous Scales/Mighty Shield/Poison Enzyme/Ancient Bulwark)。"""
    state, card_db = ctx.state, ctx.card_db
    owner_index = ctx.opponent
    attacker_mon = ctx.source_pokemon
    if (
        defender.shield_vs_ability_until > 0
        and attacker_card is not None
        and attacker_card.abilities
        and state.player(ctx.acting_player).turns_taken <= defender.shield_vs_ability_until
    ):
        return True  # Psy Protection: 特性を持つポケモンのワザのダメージを受けない
    if (
        defender.ex_attack_shield_until > 0
        and attacker_card is not None
        and "ex" in attacker_card.subtypes
        and state.player(ctx.acting_player).turns_taken <= defender.ex_attack_shield_until
    ):
        return True  # Acerola's Mischief: 相手のポケモンexのワザのダメージを受けない
    from effects.passives_cond import cond_prevent_check

    if cond_prevent_check(ctx, defender, "damage"):
        return True
    for kind, params in active_passives(state, card_db, owner_index, defender):
        if kind == "immune_damage_from_attackers_with_subtype" and attacker_card is not None and params["subtype"] in attacker_card.subtypes:
            return True
        if kind == "immune_damage_from_attackers_with_special_energy" and attacker_mon is not None and any(
            (e := card_db.get(eid)) is not None and e.is_special_energy for eid in attacker_mon.attached_energy
        ):
            return True
        if kind == "immune_damage_from_poisoned_attackers" and attacker_mon is not None and attacker_mon.status.poisoned:
            return True
    owner = state.player(owner_index)
    from effects.era_energy_g import bench_immune_by_energy

    if bench_immune_by_energy(defender, card_db.get(defender.card_id), owner):
        return True  # シャドウィダークネスエネルギー
    for holder, params in team_passives(state, card_db, owner_index, "team_damage_immune_vs_low_energy"):
        if params.get("holder_bench_only") and holder is owner.active:
            continue
        if attacker_mon is not None and _energy_count(attacker_mon) <= params["max_energy"]:
            return True
    return False


def ext_full_immune(ctx, defender, attacker_card) -> bool:
    """ワザのダメージも効果も受けない特性(Neutral Shield/Holy Shield/Metal Fortress)。"""
    state, card_db = ctx.state, ctx.card_db
    owner_index = ctx.opponent
    owner = state.player(owner_index)
    from effects.passives_cond import cond_prevent_check

    if cond_prevent_check(ctx, defender, "all"):
        return True
    for kind, params in active_passives(state, card_db, owner_index, defender):
        if kind == "immune_from_evolution_attackers" and _is_evolution(attacker_card):
            return True
        if kind == "immune_from_attackers_with_name_part" and attacker_card is not None and params["part"] in attacker_card.name:
            return True
    if defender is not owner.active and team_passives(state, card_db, owner_index, "team_bench_attack_immune_full"):
        return True
    return False


def ext_effects_immune(ctx, defender) -> bool:
    """ワザの(ダメージ以外の)効果だけを受けない特性(Wind Charm: 持ち主がバトル場にいる間、自分の全ポケモン)/Acerola's Mischief。"""
    state, card_db = ctx.state, ctx.card_db
    if defender.ex_attack_shield_until > 0 and ctx.source_pokemon is not None:
        attacker_card = card_db.get(ctx.source_pokemon.card_id)
        if attacker_card is not None and "ex" in attacker_card.subtypes and state.player(ctx.acting_player).turns_taken <= defender.ex_attack_shield_until:
            return True
    from effects.passives_cond import cond_prevent_check

    if cond_prevent_check(ctx, defender, "effects"):
        return True
    owner = state.player(ctx.opponent)
    for holder, _params in team_passives(state, card_db, ctx.opponent, "team_attack_effect_immune_while_active"):
        if holder is owner.active:
            return True
    return False


def ext_defender_damage(ctx, defender, defender_card, attacker_card, damage: int) -> int:
    """防御側のパッシブ特性による追加の軽減(High Density Armor/Shining Body/Heavy Bumper)。"""
    state, card_db = ctx.state, ctx.card_db
    owner_index = ctx.opponent
    if (
        defender.evolution_damage_reduction_until > 0
        and attacker_card is not None
        and _is_evolution(attacker_card)
        and state.player(ctx.acting_player).turns_taken <= defender.evolution_damage_reduction_until
    ):
        damage = max(0, damage - defender.evolution_damage_reduction_amount)  # Metal Block
    for kind, params in active_passives(state, card_db, owner_index, defender):
        if kind == "damage_reduction_conditional":
            if params.get("if_full_hp") and defender.damage > 0:
                continue
            et = params.get("if_energy_type")
            if et and not _has_energy(card_db, defender, et):
                continue
            damage = max(0, damage - params["amount"])
        elif kind == "damage_reduction_per_opp_retreat":
            opp_active = state.player(ctx.acting_player).active
            oc = card_db.get(opp_active.card_id) if opp_active is not None else None
            if oc is not None:
                damage = max(0, damage - params["amount_per"] * oc.retreat_cost_count)
    from effects.passives_cond import cond_defender_damage

    return cond_defender_damage(ctx, defender, damage)


# ---------------------------------------------------------------------------------------------
# 攻撃側
# ---------------------------------------------------------------------------------------------
def ext_attacker_bonus(ctx, defender, defender_card, attacker_card) -> int:
    """攻撃側のパッシブ特性による追加ダメージ(Overgrow: 残りHPが少ないとき)。"""
    mon = ctx.source_pokemon
    if mon is None:
        return 0
    bonus = 0
    state, card_db = ctx.state, ctx.card_db
    from engine.continuous import effective_max_hp

    if mon.next_turn_attack_bonus_until > 0 and state.player(ctx.acting_player).turns_taken == mon.next_turn_attack_bonus_until:
        bonus += mon.next_turn_attack_bonus  # 自分の次の番のワザの追加ダメージ
    for kind, params in active_passives(state, card_db, ctx.acting_player, mon):
        if kind == "self_attack_bonus_if_low_hp":
            max_hp = effective_max_hp(card_db, mon.card_id, mon.attached_tool, state.stadium_in_play, mon.attached_energy)
            if max_hp - mon.damage <= params["hp"]:
                bonus += params["amount"]
    from effects.passives_cond import cond_attacker_bonus

    return bonus + cond_attacker_bonus(ctx, defender, defender_card)


def ext_ignore_defender_effects(ctx) -> bool:
    """Zap Zone: 自分の(指定タイプの)ポケモンのワザのダメージは、相手のバトルポケモンにかかっている効果を受けない。"""
    mon = ctx.source_pokemon
    if mon is None:
        return False
    from effects.passives import _types

    types = _types(ctx.card_db, mon)
    from effects.era_attacks_i import card_matches

    attacker_card = ctx.card_db.get(mon.card_id)
    for rule in ctx.state.player(ctx.acting_player).attack_bonus_rules_this_turn:
        if rule.get("ignore_defender_effects") and (not rule["spec"] or card_matches(attacker_card, rule["spec"])):
            return True  # フィービ: この番、VMAXのワザのダメージは相手のバトルポケモンにかかっている効果を受けない
    for _holder, params in team_passives(ctx.state, ctx.card_db, ctx.acting_player, "team_ignore_defender_effects"):
        if not params.get("attacker_type") or params["attacker_type"] in types:
            return True
    return False


# ---------------------------------------------------------------------------------------------
# にげるコスト・ワザのコスト・最大HP
# ---------------------------------------------------------------------------------------------
def ext_retreat_delta(state, card_db, owner_index: int, mon, card) -> int:
    """にげるコストの増減(負=軽くなる)。"""
    delta = 0
    owner = state.player(owner_index)
    for holder, params in team_passives(state, card_db, owner_index, "bench_active_retreat_reduction"):
        if holder is not owner.active and mon is owner.active:
            delta -= params["amount"]  # Retreat Aid: ベンチにいる間、バトルポケモンのにげるコストが軽くなる
    for holder, params in team_passives(state, card_db, owner_index, "team_retreat_reduction_if_stadium"):
        if state.stadium_in_play is not None and card is not None and params["type"] in card.types:
            delta -= params["amount"]  # Dragon Road
    for _k, params in active_passives(state, card_db, owner_index, mon, "self_retreat_reduction_per_bench_name"):
        if mon is owner.active:
            n = sum(1 for m in owner.bench if (c := card_db.get(m.card_id)) is not None and c.name == params["name"])
            delta -= params["amount_per"] * n  # Sparkling Induction
    for _idx, _holder, params in global_passives(state, card_db, "global_retreat_increase_except_subtype"):
        if card is not None and not card_has_subtype(card, params["except_subtype"]):
            delta += params["amount"]  # Sludge Festival
    from effects.passives_cond import cond_retreat_cost

    delta += cond_retreat_cost(state, card_db, owner_index, mon)[1]
    return delta


def ext_no_retreat(state, card_db, owner_index: int, mon) -> bool:
    """My Way: スタジアムが場に出ているなら、このポケモンはにげるコストがない。"""
    from effects.passives_cond import cond_retreat_cost

    if cond_retreat_cost(state, card_db, owner_index, mon)[0]:
        return True
    return state.stadium_in_play is not None and bool(active_passives(state, card_db, owner_index, mon, "no_retreat_if_stadium"))


def ext_attack_cost(state, card_db, owner_index: int, out: list, mon=None) -> list:
    """ワザのコストの変更(Calming Aroma: 自分のポケモンのワザは指定タイプのエネルギー1個ぶん少なくなる/Nighttime Mine/Thunder Mountain)。"""
    if mon is not None and state.stadium_in_play is not None:
        from effects.era_trainers_g import NIGHTTIME_MINE_IDS, THUNDER_MOUNTAIN_IDS

        mon_card = card_db.get(mon.card_id)
        if mon_card is not None:
            if state.stadium_in_play in NIGHTTIME_MINE_IDS and "Tera" in mon_card.subtypes:
                out = list(out) + ["Colorless"]  # Nighttime Mine: テラスタルポケモン(おたがい)のワザは無色1個ぶん多くなる
            if state.stadium_in_play in THUNDER_MOUNTAIN_IDS and "Lightning" in mon_card.types and "Lightning" in out:
                out = list(out)
                out.remove("Lightning")  # Thunder Mountain: 雷ポケモン(おたがい)のワザは雷1個ぶん少なくなる
    for _holder, params in team_passives(state, card_db, owner_index, "team_attack_cost_remove_type"):
        if params["type"] in out:
            out.remove(params["type"])
            break
    from effects.passives_cond import cond_attack_cost

    return cond_attack_cost(state, card_db, owner_index, out, mon)


def ext_max_hp(state, card_db, owner_index: int, mon, hp: int) -> int:
    """最大HPの上書き(Gourgantic: 草エネルギーがついていれば最大HPが200)。"""
    for _k, params in active_passives(state, card_db, owner_index, mon, "self_hp_set_if_energy"):
        if _has_energy(card_db, mon, params["energy_type"]):
            hp = params["hp"]
    from effects.passives_cond import cond_max_hp

    return cond_max_hp(state, card_db, owner_index, mon, hp)


# ---------------------------------------------------------------------------------------------
# ロック系
# ---------------------------------------------------------------------------------------------
def tools_disabled_by_ability(state, card_db) -> bool:
    """Tool Concealment(場にいる間)/Fright Night(バトル場にいる間): 場のポケモンのどうぐは効果を持たない。"""
    from effects.generated_abilities import GENERATED_PASSIVES

    for idx in (0, 1):
        owner = state.player(idx)
        for mon in owner.all_pokemon_in_play():
            if mon.card_id not in GENERATED_PASSIVES:
                continue
            for kind, _params in active_passives(state, card_db, idx, mon):
                if kind == "global_tools_disabled":
                    return True
                if kind == "global_tools_disabled_while_active" and mon is owner.active:
                    return True
    return False


def tool_attach_locked(state, card_db) -> bool:
    """Slip Trip: 両プレイヤーが手札からポケモンのどうぐをつけられない。"""
    return bool(global_passives(state, card_db, "global_tool_attach_lock"))


def stadium_play_locked(state, card_db) -> bool:
    """Barrier Shrine: 両プレイヤーが手札からスタジアムを使えない。"""
    return bool(global_passives(state, card_db, "global_stadium_play_lock"))


def hand_block_active(state, card_db, player_index: int) -> bool:
    """Hand Block: 相手の場にスタジアムが出ていれば、player_indexは手札から特殊エネルギーをつけられない(持ち主=相手側)。"""
    return state.stadium_in_play is not None and bool(
        team_passives(state, card_db, 1 - player_index, "opp_special_energy_attach_lock_if_stadium")
    )


def abilities_locked_except_type(state, card_db, card) -> bool:
    """Bide Barricade: バトル場のこのポケモンがいる間、(指定タイプのポケモン以外の)場のポケモンは特性を持たない。
    ability_suppressed内から呼ばれるため、持ち主自身の封印判定は_holder_check=Trueで(相互再帰を避けて)行う。"""
    from effects.generated_abilities import GENERATED_PASSIVES
    from engine.continuous import ability_suppressed

    for idx in (0, 1):
        active = state.player(idx).active
        entries = GENERATED_PASSIVES.get(active.card_id) if active is not None else None
        if not entries:
            continue
        for _n, kind, params in entries:
            if kind == "global_ability_lock_except_type" and params["except_type"] not in card.types:
                if not ability_suppressed(state, card_db, idx, active, _holder_check=True):
                    return True
    return False


# ---------------------------------------------------------------------------------------------
# きぜつ時(相手のワザのダメージで)
# ---------------------------------------------------------------------------------------------
def ext_on_knocked_out(ctx, ko_mon, owner_index: int) -> None:
    """相手のワザのダメージできぜつしたポケモンについて、パッシブ特性で変わる行き先(Infinite Shadow: 手札へ/Diver's Catch: 基本水エネルギーを手札へ)。"""
    state, card_db = ctx.state, ctx.card_db
    ko_card = card_db.get(ko_mon.card_id)
    for kind, _params in active_passives(state, card_db, owner_index, ko_mon):
        if kind == "ko_return_to_hand":
            ko_mon.rescued_to_hand_pending = True  # 本体は手札へ、ついていた他のカードはトラッシュ
    for _holder, params in team_passives(state, card_db, owner_index, "team_ko_energy_to_hand"):
        if ko_card is not None and params["pokemon_type"] in ko_card.types:
            ko_mon.energy_to_hand_pending = True
            ko_mon.energy_to_hand_only_type = params["energy_type"]


def collect_ko_followups_ext(state, card_db, owner_index: int, pokemon, by_attack: bool, was_active: bool) -> None:
    """きぜつしたポケモン(トラッシュする前)の、きぜつ時に選択を挟むパッシブ特性(Final Chain/Photon Cord)を待ち行列に積む。"""
    if not by_attack:
        return
    from effects.generated_abilities import GENERATED_PASSIVES

    entries = GENERATED_PASSIVES.get(pokemon.card_id)
    if not entries:
        return
    from engine.continuous import ability_suppressed

    if ability_suppressed(state, card_db, owner_index, pokemon):
        return
    owner = state.player(owner_index)
    for name, kind, params in entries:
        if kind == "ko_followup_search_any":
            state.ko_followups.append({"kind": "search_deck_any", "owner": owner_index, "label": name})
        elif kind == "ko_move_energy_to_bench" and was_active and owner.bench:
            ids = [
                e for e in pokemon.attached_energy
                if (c := card_db.get(e)) is not None and c.is_energy and not c.is_special_energy and c.basic_energy_type == params["energy_type"]
            ]
            if ids:
                state.ko_followups.append(
                    {"kind": "energy_move_bench", "owner": owner_index, "energy_ids": ids, "max": params["max"], "label": name}
                )


# ---------------------------------------------------------------------------------------------
# バトルポケモンがベンチに下がったとき(Holes/Swirling Prose)・にげる(Slimy Sliding)
# ---------------------------------------------------------------------------------------------
def active_snapshot(state):
    """apply_action前の両プレイヤーのバトルポケモンと手番(after_active_moved_to_benchと対で使う)。"""
    if not state.setup_complete:
        return None
    return (state.players[0].active, state.players[1].active, state.current_player)


def after_active_moved_to_bench(state, card_db, before) -> None:
    """手番プレイヤーのバトルポケモンが、(にげる・入れ替え効果の原因を問わず)ベンチに下がったなら、相手の特性を適用する。
    Holes: ベンチに下がったポケモンにダメカンをのせる / Swirling Prose: 持ち主がバトル場にいれば、新しいバトルポケモンをこんらんにする。"""
    if before is None or state.is_game_over():
        return
    from effects.generated_abilities import GENERATED_PASSIVES

    if not any(kind in ("opp_bench_move_counters", "opp_bench_move_confuse_new_active") for entries in GENERATED_PASSIVES.values() for _n, kind, _p in entries):
        return
    prev_actives = (before[0], before[1])
    turn_player = before[2]
    prev = prev_actives[turn_player]
    owner = state.player(turn_player)
    if prev is None or owner.active is prev or not any(m is prev for m in owner.bench):
        return
    opp_index = 1 - turn_player
    from effects.primitives import _apply_condition, _blocks_damage_counters

    for _holder, params in team_passives(state, card_db, opp_index, "opp_bench_move_counters"):
        if not _blocks_damage_counters(prev):
            prev.damage += params["counters"] * 10
            state.add_log(f"相手の特性で、ベンチに下がったポケモンにダメカンを{params['counters']}個のせた")
    opp = state.player(opp_index)
    for holder, _params in team_passives(state, card_db, opp_index, "opp_bench_move_confuse_new_active"):
        if holder is opp.active and owner.active is not None:
            _apply_condition(owner.active, "confused")
            state.add_log("相手の特性で、新しくバトル場に出たポケモンがこんらんになった")


def retreat_fails_by_coin(state, card_db, actor: int) -> bool:
    """Slimy Sliding: 相手の場にこの特性のポケモンがいれば、にげるときコインを1回投げ、ウラなら(コストを払わず)入れ替わらない(重ならない)。"""
    if not team_passives(state, card_db, 1 - actor, "opp_retreat_coin_fail"):
        return False
    tails = state.rng.random() >= 0.5
    state.add_log("Slimy Sliding: にげるためのコイン " + ("ウラ。入れ替わらない" if tails else "オモテ"))
    return tails


# ---------------------------------------------------------------------------------------------
# 手札からのポケモンを出すロック(Potent Glare)・グッズ/サポートの効果を受けない(Snow Camouflage/Protective Sail)
# ---------------------------------------------------------------------------------------------
def ability_pokemon_play_locked(state, card_db, player_index: int, card) -> bool:
    """Potent Glare: 相手のバトルポケモンの特性で、特性を持つポケモンを手札から出せない(例外の名前の接頭辞つき)。"""
    if card is None or not card.abilities:
        return False
    from effects.passives_cond import cond_locked

    if cond_locked(state, card_db, player_index, "ability_pokemon"):
        return True
    opp_index = 1 - player_index
    active = state.player(opp_index).active
    if active is None:
        return False
    for _k, params in active_passives(state, card_db, opp_index, active, "opp_cant_play_ability_pokemon_while_active"):
        if params.get("except_name_prefix") and card.name.startswith(params["except_name_prefix"]):
            continue
        return True
    return False


def card_effect_shielded(state, card_db, played_by: int, kind: str, target_bench_index, script) -> bool:
    """Snow Camouflage/Protective Sail: played_byが手札から使ったグッズ("item")/サポート("supporter")の、相手のポケモン(1匹を対象に
    とる場合は、そのポケモン。対象を選ばない場合はバトルポケモン)への効果を無効にするか。"""
    from effects.era_special import _script_affects_opponent_pokemon

    if not _script_affects_opponent_pokemon(script):
        return False
    opp_index = 1 - played_by
    owner = state.player(opp_index)
    if target_bench_index is None:
        target = owner.active
    else:
        target = owner.bench[target_bench_index] if 0 <= target_bench_index < len(owner.bench) else None
    if target is None:
        return False
    return any(kind in params["kinds"] for _k, params in active_passives(state, card_db, opp_index, target, "self_card_effect_shield"))


def on_evolved_from_hand(state, card_db, actor: int, evolved) -> None:
    """Darkest Impulse: 相手の場にこの特性のポケモンがいれば、手札から進化させたポケモンにダメカンをのせる(重ならない)。"""
    from effects.generated_abilities import GENERATED_PASSIVES

    if not any(kind == "opp_evolve_counters" for entries in GENERATED_PASSIVES.values() for _n, kind, _p in entries):
        return
    holders = team_passives(state, card_db, 1 - actor, "opp_evolve_counters")
    if not holders:
        return
    from effects.primitives import _blocks_damage_counters

    counters = max(params["counters"] for _h, params in holders)  # 「この特性の効果は重ならない」: 1回だけ
    if not _blocks_damage_counters(evolved):
        evolved.damage += counters * 10
        state.add_log(f"相手の特性で、進化したポケモンにダメカンを{counters}個のせた")
