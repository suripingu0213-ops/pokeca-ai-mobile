"""時代ごとのカード取り込み(2026-10-06〜)で追加した効果プリミティブその5(ワザ選択・ワザのコピー・タイプ変更・ダメカン移動)。

effects/era_primitives*.py と同じ規約。ダメージを与えるものは必ずDealDamageを1回だけ経由する。
ワザ選択時に選ぶもの(特殊状態/タイプ/相手のワザ番号)は、Attack(i, k)のkとして渡す(ctx.target_bench_index)。
"""

from __future__ import annotations

from dataclasses import dataclass

from effects.context import EffectContext
from effects.primitives import (
    DealDamage,
    Effect,
    InflictStatusOnDefender,
    _attacker_player,
    _defender,
    _defender_blocks_effect,
)
from engine.state import PendingSearchChoice

POKEMON_TYPES = ("Grass", "Fire", "Water", "Lightning", "Psychic", "Fighting", "Darkness", "Metal", "Fairy", "Dragon")


@dataclass(frozen=True)
class InflictChosenStatusOnDefender(Effect):
    """相手のバトルポケモンを、選んだ特殊状態にする(Miracle Powder/Conversion Powder)。選ぶ特殊状態はワザ選択時にAttack(i, k)のk
    (optionsの何番目か)で渡す。コインの結果は選択に影響しないので、ワザ選択時に選んでも情報は変わらない。"""

    options: tuple
    status_choice_options = None  # インスタンスごとにoptionsを返す(下のプロパティ参照)

    def execute(self, ctx: EffectContext) -> None:
        k = ctx.target_bench_index
        if k is None or not (0 <= k < len(self.options)):
            return
        InflictStatusOnDefender(self.options[k]).execute(ctx)


# status_choice_optionsは「インスタンスの属性」として参照される(legal_actions/display)ため、フィールド値をそのまま見せる
InflictChosenStatusOnDefender.status_choice_options = property(lambda self: self.options)  # type: ignore[assignment]


@dataclass(frozen=True)
class ChooseTypeSwitch(Effect):
    """次の自分の番の終わりまで、このポケモンを選んだタイプにする(Type Switch)。選ぶタイプはAttack(i, k)のk(POKEMON_TYPESの何番目か)。"""

    status_choice_options = POKEMON_TYPES

    def execute(self, ctx: EffectContext) -> None:
        k = ctx.target_bench_index
        if ctx.source_pokemon is None or k is None or not (0 <= k < len(POKEMON_TYPES)):
            return
        ctx.source_pokemon.type_override = POKEMON_TYPES[k]
        ctx.source_pokemon.type_override_until_turn = _attacker_player(ctx).turns_taken + 1
        ctx.log(f"このポケモンは{POKEMON_TYPES[k]}タイプになった")


@dataclass(frozen=True)
class ForceDefenderAttackNextTurn(Effect):
    """相手のバトルポケモンのワザを1つ選び、相手の次の番、そのポケモンはそのワザしか使えない(Encore)。選ぶワザは、Attack(i, k)のk
    (相手のバトルポケモンのワザの何番目か)で渡す。"""

    chooses_opponent_attack = True

    def execute(self, ctx: EffectContext) -> None:
        opponent = ctx.state.player(ctx.opponent)
        active = opponent.active
        k = ctx.target_bench_index
        if active is None or k is None or _defender_blocks_effect(ctx, active):
            return
        card = ctx.card_db.get(active.card_id)
        if card is None or not (0 <= k < len(card.attacks)):
            return
        active.forced_attack_name = card.attacks[k].name
        active.forced_attack_until_turn = opponent.turns_taken + 1
        ctx.log(f"相手の次の番、{card.attacks[k].name}しか使えない")


@dataclass(frozen=True)
class SwapDamageWithDefender(Effect):
    """このポケモンについているダメカンと、相手のバトルポケモンについているダメカンを全て入れ替える(Damage Change)。"""

    def execute(self, ctx: EffectContext) -> None:
        _, defender = _defender(ctx)
        mon = ctx.source_pokemon
        if mon is None or defender is None or _defender_blocks_effect(ctx, defender):
            return
        mon.damage, defender.damage = defender.damage, mon.damage
        ctx.log("おたがいのバトルポケモンのダメカンを入れ替えた")


@dataclass(frozen=True)
class ReturnOwnEnergyTypeToHand(Effect):
    """このポケモンについている指定タイプの基本エネルギーをcount枚、手札に戻す(Giant Whirlpool)。"""

    count: int
    energy_type: str

    def execute(self, ctx: EffectContext) -> None:
        mon = ctx.source_pokemon
        if mon is None:
            return
        player = _attacker_player(ctx)
        n = 0
        for e in list(mon.attached_energy):
            c = ctx.card_db.get(e)
            if n < self.count and c is not None and c.basic_energy_type == self.energy_type:
                mon.attached_energy.remove(e)
                player.hand.append(e)
                n += 1


@dataclass(frozen=True)
class SelfDamagePerSelfCounters(Effect):
    """このポケモンについているダメカン1個につき、このポケモン自身にperダメージ(Crimson Edge)。"""

    per: int

    def execute(self, ctx: EffectContext) -> None:
        mon = ctx.source_pokemon
        if mon is None:
            return
        extra = (mon.damage // 10) * self.per
        mon.damage += extra
        ctx.log(f"このポケモン自身に{extra}ダメージ")


@dataclass(frozen=True)
class CoinCountOverrideNextTurn(Effect):
    """次の自分の番、このポケモンの指定のワザで投げるコインの数がcount枚になる(Exciting Shake)。"""

    attack_name: str
    count: int

    def execute(self, ctx: EffectContext) -> None:
        mon = ctx.source_pokemon
        if mon is None:
            return
        mon.coin_count_override_attack = self.attack_name
        mon.coin_count_override_amount = self.count
        mon.coin_count_override_until_turn = _attacker_player(ctx).turns_taken + 1


def _revealed_options_for_card(ctx, card_id, card, require_energy_of=None, reentrant_effect=None):
    """借りられるワザの選択肢(ワザの番号, 「してもよい」版か)。reentrant_effectに今実行中のコピー効果を渡すと、
    そのコピー効果自身を持つワザ(ベンチの同名ポケモンの「ナイトジョーカー」等)は選択肢から外す。
    それを選んでも、その効果でまた全く同じ選択肢が出るだけで、最終的に使えるワザの集合は変わらない
    (選ばせると無限再帰になる。なお他に選べるワザが無ければ「使えるワザが無い」になる)。"""
    from effects.primitives import _revealed_attack_options

    options = _revealed_attack_options(ctx.card_db, card_id, card)
    if reentrant_effect is not None:
        from effects.registry import get_attack_script

        options = [
            (ai, variant) for (ai, variant) in options
            if reentrant_effect not in get_attack_script(card_id, card.attacks[ai].name)
        ]
    if require_energy_of is None:
        return options
    from engine.energy import can_pay_cost

    mon = ctx.source_pokemon
    ok = []
    for (ai, variant) in options:
        if mon is not None and can_pay_cost(ctx.card_db, mon.attached_energy, card.attacks[ai].cost, mon.card_id):
            ok.append((ai, variant))
    return ok


def _offer_options(ctx: EffectContext, option_cards: list, options: list, prompt: str) -> None:
    from effects.primitives import run_borrowed_attack_script

    if not options:
        ctx.log("使えるワザが無い")
        return
    if len(options) == 1:
        card_id = option_cards[0]
        card = ctx.card_db.get(card_id)
        ai, variant = options[0]
        ctx.target_bench_index = 0 if variant else None
        run_borrowed_attack_script(ctx, card_id, card.attacks[ai].name)
        return
    pending = PendingSearchChoice(
        player_index=ctx.acting_player,
        zone="revealed_card_attack_choice",
        source_indices=list(range(len(options))),
        card_ids=list(option_cards),
        min_count=1,
        max_count=1,
        prompt=prompt,
        shuffle_after=False,
        all_card_ids=list(option_cards),
        cont_source_pokemon=ctx.source_pokemon,
        cont_source_card_id=ctx.source_card_id,
        custom_data={
            "mode": "revealed_card_attack_choice", "revealed_card_id": option_cards[0], "options": options,
            "option_card_ids": list(option_cards),
        },
    )
    ctx.state.pending_search_choice = pending


@dataclass(frozen=True)
class ChooseBenchedPokemonAttackAndUse(Effect):
    """自分のベンチのポケモンのワザを1つ選び、このワザとして使う(Assist)。ワザのコストは必要ない(このワザのコストを払っているため)。"""

    def execute(self, ctx: EffectContext) -> None:
        player = _attacker_player(ctx)
        option_cards: list = []
        options: list = []
        seen = set()
        for mon in player.bench:
            if mon.card_id in seen:
                continue
            seen.add(mon.card_id)
            card = ctx.card_db.get(mon.card_id)
            if card is None or not card.attacks:
                continue
            for opt in _revealed_options_for_card(ctx, mon.card_id, card, reentrant_effect=self):
                options.append(opt)
                option_cards.append(mon.card_id)
        _offer_options(ctx, option_cards, options, "ベンチのポケモンのワザを1つ選んで使う")


def ctr_start(ctx: EffectContext, spec: dict, remaining, then_end_turn: bool = False) -> None:
    """ダメカンを1個ずつ移していく選択のループ。spec: src="own"|"opp"(移す元の持ち主)、dest="defender"|"other_opp"、
    optional=Trueなら移す元を選ばずに打ち切れる。remaining=None は「好きなだけ」。"""
    from effects.era_primitives_b import _carry, _set_pending, _slots

    if remaining is not None and remaining <= 0:
        return
    owner = ctx.state.player(ctx.acting_player if spec["src"] == "own" else ctx.opponent)
    sources = [(slot, mon) for slot, mon in _slots(owner) if mon.damage > 0]
    if spec.get("src_name_prefix"):
        sources = [
            (s, m) for s, m in sources
            if (c := ctx.card_db.get(m.card_id)) is not None and c.name.startswith(spec["src_name_prefix"])
        ]
    if spec["dest"] in ("other_opp", "other_own"):
        sources = [(s, m) for s, m in sources if len(_slots(owner)) > 1]
    if spec["dest"] == "self":
        sources = [(s, m) for s, m in sources if m is not ctx.source_pokemon]
    if spec["dest"] == "defender" and ctx.state.player(ctx.opponent).active is None:
        return
    if not sources:
        return
    pending = PendingSearchChoice(
        player_index=ctx.acting_player,
        zone="gen_pokemon_pick",
        source_indices=[s for s, _ in sources],
        card_ids=[m.card_id for _, m in sources],
        min_count=0 if spec.get("optional") else 1,
        max_count=1,
        prompt="ダメカンを1個移す元のポケモンを選ぶ" + ("(選ばなければ終了)" if spec.get("optional") else ""),
        shuffle_after=False,
        all_card_ids=[m.card_id for _, m in sources],
        custom_data={"op": "ctr_pick_source", "spec": spec, "remaining": remaining},
    )
    _set_pending(ctx.state, _carry(pending, ctx), then_end_turn)


def ctr_after_source(ctx: EffectContext, spec: dict, remaining, source_slot: int, then_end_turn: bool) -> None:
    from effects.era_primitives_b import _carry, _mon_at, _set_pending, _slots

    state = ctx.state
    owner = state.player(ctx.acting_player if spec["src"] == "own" else ctx.opponent)
    source = _mon_at(owner, source_slot)
    if source is None or source.damage <= 0:
        return
    if spec["dest"] == "defender":
        dest = state.player(ctx.opponent).active
        _ctr_move(ctx, source, dest)
        ctr_start(ctx, spec, None if remaining is None else remaining - 1, then_end_turn)
        return
    if spec["dest"] == "self":
        _ctr_move(ctx, source, ctx.source_pokemon)
        ctr_start(ctx, spec, None if remaining is None else remaining - 1, then_end_turn)
        return
    dests = [(s, m) for s, m in _slots(owner) if s != source_slot]
    if not dests:
        return
    if len(dests) == 1:
        _ctr_move(ctx, source, dests[0][1])
        ctr_start(ctx, spec, None if remaining is None else remaining - 1, then_end_turn)
        return
    pending = PendingSearchChoice(
        player_index=ctx.acting_player,
        zone="gen_pokemon_pick",
        source_indices=[s for s, _ in dests],
        card_ids=[m.card_id for _, m in dests],
        min_count=1,
        max_count=1,
        prompt="ダメカンを移す先のポケモンを選ぶ",
        shuffle_after=False,
        all_card_ids=[m.card_id for _, m in dests],
        custom_data={"op": "ctr_pick_dest", "spec": spec, "remaining": remaining, "source_slot": source_slot},
    )
    _set_pending(state, _carry(pending, ctx), then_end_turn)


def ctr_after_dest(ctx: EffectContext, spec: dict, remaining, source_slot: int, dest_slot: int, then_end_turn: bool) -> None:
    from effects.era_primitives_b import _mon_at

    owner = ctx.state.player(ctx.acting_player if spec["src"] == "own" else ctx.opponent)
    _ctr_move(ctx, _mon_at(owner, source_slot), _mon_at(owner, dest_slot))
    ctr_start(ctx, spec, None if remaining is None else remaining - 1, then_end_turn)


def _ctr_move(ctx: EffectContext, source, dest) -> None:
    if source is None or dest is None or source.damage <= 0:
        return
    source.remove_counters(10)
    dest.damage += 10
    ctx.log("ダメカン1個を移した")


@dataclass(frozen=True)
class MoveDamageCountersFreely(Effect):
    """ダメカンを1個ずつ、好きなポケモンから好きなポケモンへ移す。src: "own"|"opp"(移す元の持ち主)、dest: "defender"(相手のバトルポケモン)|
    "other_opp"(相手の別のポケモン)、count: 移す個数(None=好きなだけ)。count指定のときは必ずその数(移せる限り)移す(Damakinesis/Ear Influence)。"""

    src: str
    dest: str
    count: int | None = None
    src_name_prefix: str | None = None

    def ability_gate(self, state, player, mon, zone, card_db) -> bool:
        """特性として使うとき、ダメカンののったポケモン(移す元)があるか。"""
        owner = player if self.src == "own" else state.player(1 - (0 if player is state.players[0] else 1))
        for m in owner.all_pokemon_in_play():
            if m.damage <= 0:
                continue
            if self.src_name_prefix and not ((c := card_db.get(m.card_id)) is not None and c.name.startswith(self.src_name_prefix)):
                continue
            if self.dest == "self" and m is mon:
                continue
            return True
        return False

    def execute(self, ctx: EffectContext) -> None:
        spec = {"src": self.src, "dest": self.dest, "optional": self.count is None, "src_name_prefix": self.src_name_prefix}
        ctr_start(ctx, spec, self.count)


@dataclass(frozen=True)
class CopyDefenderAttackIfEnergyMet(Effect):
    """相手のバトルポケモンのワザを1つ選び、このポケモンにそのワザに必要なエネルギーがついていれば、このワザとして使う(Imittack)。"""

    def execute(self, ctx: EffectContext) -> None:
        opponent = ctx.state.player(ctx.opponent)
        if opponent.active is None:
            return
        card = ctx.card_db.get(opponent.active.card_id)
        if card is None or not card.attacks:
            return
        options = _revealed_options_for_card(ctx, opponent.active.card_id, card, require_energy_of=True, reentrant_effect=self)
        _offer_options(ctx, [opponent.active.card_id] * len(options), options, f"{card.name}のワザを1つ選んで使う")
