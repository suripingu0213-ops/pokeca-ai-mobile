"""scripts/generate_tool_passives.py が自動生成した、どうぐ/スタジアムの常時効果の宣言(手で編集しない。再生成で上書きされる)。"""

from __future__ import annotations

TOOL_PASSIVES: dict[str, tuple] = {
    'sv1-192': (
        ('cond_damage_taken', {'scope': 'self', 'amount': 30, 'when': ['holder:type:Fighting']}),
    ),
    'sv1-197': (
        ('cond_attack_bonus', {'scope': 'self', 'amount': 10, 'when': []}),
    ),
    'sv2-193': (
        ('cond_status_immune', {'scope': 'self', 'statuses': ['asleep', 'confused', 'paralyzed']}),
    ),
    'sv3pt5-155': (
        ('cond_retreat', {'scope': 'self', 'when': ['holder:stage:Stage 2']}),
    ),
    'sv3pt5-164': (
        ('cond_weakness', {'scope': 'self', 'when': ['holder:basic']}),
    ),
    'sv3pt5-165': (
        ('cond_damage_taken', {'scope': 'self', 'amount': 30, 'when': ['holder:stage:Stage 1']}),
    ),
    'sv4-159': (
        ('cond_hp', {'scope': 'self', 'amount': 60, 'when': ['holder:subtype:Ancient']}),
        ('cond_status_immune', {'scope': 'self', 'statuses': 'all', 'when': ['holder:subtype:Ancient']}),
    ),
    'sv4-162': (
        ('cond_damage_taken', {'scope': 'self', 'amount': 40, 'when': ['own_prizes_more_than_opp']}),
    ),
    'sv4-166': (
        ('cond_hp', {'scope': 'self', 'amount': 100, 'when': ['holder:no_rule_box']}),
    ),
    'sv4-265': (
        ('cond_hp', {'scope': 'self', 'amount': 100, 'when': ['holder:no_rule_box']}),
    ),
    'sv5-140': (
        ('cond_hp', {'scope': 'self', 'amount': 60, 'when': ['holder:subtype:Ancient']}),
        ('cond_status_immune', {'scope': 'self', 'statuses': 'all', 'when': ['holder:subtype:Ancient']}),
    ),
    'sv5-152': (
        ('cond_hp', {'scope': 'self', 'amount': 100, 'when': []}),
    ),
    'sv7-137': (
        ('cond_retreat', {'scope': 'team', 'affects': 'both', 'amount': 1, 'target': {'zone': 'active'}, 'when': ['active']}),
    ),
    'sv7-140': (
        ('cond_damage_taken', {'scope': 'self', 'amount': 60, 'src': {'type': 'Fire'}, 'discard_after': True}),
    ),
    'sv7-141': (
        ('cond_damage_taken', {'scope': 'self', 'amount': 60, 'src': {'type': 'Psychic'}, 'discard_after': True}),
    ),
    'sv7-142': (
        ('cond_cost', {'scope': 'self', 'remove_any': 1, 'when': ['holder:subtype:Tera']}),
    ),
    'sv8-163': (
        ('cond_damage_taken', {'scope': 'self', 'amount': 60, 'src': {'type': 'Metal'}, 'discard_after': True}),
    ),
    'sv8-168': (
        ('cond_damage_taken', {'scope': 'self', 'amount': 60, 'src': {'type': 'Darkness'}, 'discard_after': True}),
    ),
    'sv8-184': (
        ('cond_damage_taken', {'scope': 'self', 'amount': 60, 'src': {'type': 'Water'}, 'discard_after': True}),
    ),
    'sv8pt5-111': (
        ('cond_damage_taken', {'scope': 'self', 'amount': 60, 'src': {'type': 'Dragon'}, 'discard_after': True}),
    ),
    'sv8pt5-129': (
        ('cond_cost', {'scope': 'self', 'remove_any': 1, 'when': ['holder:subtype:Tera']}),
    ),
    'swsh1-158': (
        ('cond_hp', {'scope': 'self', 'amount': 30, 'when': []}),
    ),
    'swsh1-185': (
        ('cond_attack_bonus', {'scope': 'self', 'amount': 10, 'when': []}),
    ),
    'swsh11-165': (
        ('cond_prevent', {'mode': 'damage', 'scope': 'self', 'src': {'remaining_hp_at_most': 40}, 'when': []}),
    ),
    'swsh12-169': (
        ('cond_damage_taken', {'scope': 'self', 'amount': 30, 'src': {'subtype': ['V']}, 'nostack': 'v_guard'}),
    ),
    'swsh12-215': (
        ('cond_damage_taken', {'scope': 'self', 'amount': 30, 'src': {'subtype': ['V']}, 'nostack': 'v_guard'}),
    ),
    'swsh2-206': (
        ('cond_hp', {'scope': 'self', 'amount': 30, 'when': []}),
    ),
    'swsh3-157': (
        ('cond_prevent', {'mode': 'effects', 'scope': 'team', 'when': ['active']}),
    ),
    'swsh3-160': (
        ('cond_hp', {'scope': 'self', 'amount': 50, 'when': ['holder:basic|not_subtype:GX']}),
    ),
    'swsh3-171': (
        ('cond_attack_bonus', {'scope': 'self', 'amount': 30, 'src': {'zone': 'active'}, 'when': ['holder_weak_to_opp_active']}),
    ),
    'swsh3-174': (
        ('cond_hp', {'scope': 'self', 'amount': 20, 'when': ['holder:type:Fire']}),
    ),
    'swsh3-175': (
        ('cond_retreat', {'scope': 'self', 'when': ['holder:type:Darkness']}),
    ),
    'swsh3-176': (
        ('cond_attack_bonus', {'scope': 'self', 'amount': 20, 'when': ['holder:type:Colorless']}),
    ),
    'swsh3-199': (
        ('cond_prevent', {'mode': 'effects', 'scope': 'team', 'when': ['active']}),
    ),
    'swsh4-152': (
        ('cond_hp', {'scope': 'self', 'amount': -100, 'when': ['holder:subtype:VMAX']}),
    ),
    'swsh4-160': (
        ('cond_attack_bonus', {'scope': 'self', 'amount': 30, 'src': {'subtype': ['V', 'GX'], 'zone': 'bench'}, 'when': []}),
    ),
    'swsh4-162': (
        ('cond_status_immune', {'scope': 'self', 'statuses': 'all', 'when': ['holder:type:Grass']}),
    ),
    'swsh4-163': (
        ('cond_weakness', {'scope': 'self', 'when': ['holder:type:Metal']}),
    ),
    'swsh4-164': (
        ('cond_damage_taken', {'scope': 'self', 'amount': 20, 'when': ['holder:type:Fighting']}),
    ),
    'swsh4-165': (
        ('cond_prevent', {'mode': 'effects', 'scope': 'self', 'when': ['holder:type:Water']}),
    ),
    'swsh4-200': (
        ('cond_hp', {'scope': 'self', 'amount': 50, 'when': ['holder:basic|not_subtype:GX']}),
    ),
    'swsh4-201': (
        ('cond_hp', {'scope': 'self', 'amount': -100, 'when': ['holder:subtype:VMAX']}),
    ),
    'swsh4-203': (
        ('cond_attack_bonus', {'scope': 'self', 'amount': 30, 'src': {'subtype': ['V', 'GX'], 'zone': 'bench'}, 'when': []}),
    ),
    'swsh45-61': (
        ('cond_hp', {'scope': 'self', 'amount': 70, 'when': ['holder:name_any:Zamazenta|subtype:V']}),
    ),
    'swsh45-62': (
        ('cond_attack_bonus', {'scope': 'self', 'amount': 30, 'when': ['holder:name_any:Zacian|subtype:V']}),
    ),
    'swsh5-141': (
        ('cond_attack_bonus', {'scope': 'self', 'amount': 20, 'src': {'zone': 'active'}}),
    ),
    'swsh5-183': (
        ('cond_attack_bonus', {'scope': 'self', 'amount': 20, 'src': {'zone': 'active'}}),
    ),
    'swsh6-133': (
        ('cond_attack_bonus', {'scope': 'self', 'amount': 30, 'src': {'type': 'Metal'}, 'when': []}),
    ),
    'swsh6-138': (
        ('cond_attack_bonus', {'scope': 'self', 'amount': 30, 'src': {'type': 'Fire'}, 'when': []}),
    ),
    'swsh6-141': (
        ('cond_damage_taken', {'scope': 'self', 'amount': 30, 'when': ['holder:name_any:Galarian']}),
    ),
    'swsh6-143': (
        ('cond_attack_bonus', {'scope': 'self', 'amount': 30, 'src': {'type': 'Darkness'}, 'when': []}),
    ),
    'swsh6-155': (
        ('cond_attack_bonus', {'scope': 'self', 'amount': 30, 'src': {'type': 'Grass'}, 'when': []}),
    ),
    'swsh6-157': (
        ('cond_status_immune', {'scope': 'self', 'statuses': ['poisoned']}),
    ),
    'swsh6-159': (
        ('cond_status_immune', {'scope': 'self', 'statuses': ['paralyzed']}),
    ),
    'swsh7-145': (
        ('cond_attack_bonus', {'scope': 'self', 'amount': 30, 'src': {'type': 'Fighting'}, 'when': []}),
    ),
    'swsh7-147': (
        ('cond_cost', {'scope': 'self', 'remove_colorless': 1, 'when': ['holder:subtype:V|name_any:Vaporeon,Jolteon,Flareon']}),
    ),
    'swsh7-148': (
        ('cond_damage_taken', {'scope': 'self', 'amount': 20, 'when': ['holder:no_ability']}),
    ),
    'swsh7-156': (
        ('cond_attack_bonus', {'scope': 'self', 'amount': 30, 'src': {'type': 'Lightning'}, 'when': []}),
    ),
    'swsh7-159': (
        ('cond_retreat', {'scope': 'self', 'when': ['holder:subtype:V|name_any:Leafeon,Glaceon']}),
        ('cond_weakness', {'scope': 'self', 'when': ['holder:subtype:V|name_any:Leafeon,Glaceon']}),
    ),
    'swsh7-231': (
        ('cond_damage_taken', {'scope': 'self', 'amount': 20, 'when': ['holder:no_ability']}),
    ),
    'swsh8-243': (
        ('cond_attack_bonus', {'scope': 'self', 'amount': 30, 'src': {'type': 'Water'}, 'when': []}),
    ),
    'swsh9-136': (
        ('cond_attack_bonus', {'scope': 'self', 'amount': 30, 'src': {'type': 'Psychic'}, 'when': []}),
    ),
    'swsh9-142': (
        ('cond_attack_bonus', {'scope': 'self', 'amount': 30, 'src': {'type': 'Dragon'}, 'when': []}),
    ),
    'swsh9-146': (
        ('cond_damage_taken', {'scope': 'self', 'amount': 30, 'when': ['holder:no_rule_box']}),
    ),
}

STADIUM_PASSIVES: dict[str, tuple] = {
    'sv1-167': (
        ('cond_retreat', {'scope': 'team', 'affects': 'both', 'amount': -1, 'target': {'basic': True}}),
    ),
    'sv2-175': (
        ('cond_retreat', {'scope': 'team', 'affects': 'both', 'amount': 1, 'target': {'basic': True, 'not_type': 'Fighting'}}),
    ),
    'sv2-186': (
        ('cond_attack_bonus', {'scope': 'team', 'affects': 'both', 'amount': 10, 'target': {'stage': 'Stage 1'}}),
    ),
    'sv3-192': (
        ('cond_cost', {'scope': 'team', 'affects': 'both', 'add_colorless': 1, 'target': {'basic': True}}),
    ),
    'sv4-263': (
        ('cond_retreat', {'scope': 'team', 'affects': 'both', 'amount': -1, 'target': {'basic': True}}),
    ),
    'sv5-148': (
        ('cond_damage_taken', {'scope': 'team', 'affects': 'both', 'amount': 30, 'target': {'type': 'Metal'}}),
    ),
    'sv5-156': (
        ('cond_between_turns', {'counters': 2, 'poisoned': True, 'both': True, 'target': {'not_type': 'Darkness'}}),
    ),
    'sv6pt5-60': (
        ('cond_prevent', {'mode': 'damage', 'scope': 'team', 'affects': 'both', 'target': {'no_rule_box': True}, 'src': {'subtype': ['ex', 'V']}}),
    ),
    'sv8-180': (
        ('cond_hp', {'scope': 'team', 'affects': 'both', 'amount': 30, 'target': {'basic': True}}),
    ),
    'sv8pt5-108': (
        ('cond_status_immune', {'scope': 'team', 'affects': 'both', 'statuses': 'all', 'target': {'has_energy': True}}),
    ),
    'svp-150': (
        ('cond_retreat', {'scope': 'team', 'affects': 'both', 'amount': -1, 'target': {'name': 'Psyduck'}}),
    ),
    'svp-45': (
        ('cond_retreat', {'scope': 'team', 'affects': 'both', 'amount': -1, 'target': {'name': 'Psyduck'}}),
    ),
    'swsh11-160': (
        ('cond_damage_taken', {'scope': 'team', 'affects': 'both', 'amount': 20, 'target': {'has_energy_type': ['Water', 'Fighting']}}),
    ),
    'swsh2-160': (
        ('cond_retreat', {'scope': 'team', 'affects': 'both', 'amount': 2, 'target': {'zone': 'active'}}),
    ),
    'swsh4-150': (
        ('cond_damage_taken', {'scope': 'team', 'affects': 'both', 'amount': 20, 'target': {'basic': True}}),
    ),
    'swsh5-138': (
        ('cond_retreat', {'scope': 'team', 'affects': 'both', 'amount': -2, 'target': {'subtype': ['Rapid Strike']}}),
    ),
}

TOOL_REACTIONS: dict[str, tuple] = {
    'sv2-174': (
        ('react_attach_counters', {'n': 2, 'target': {'not_type': 'Water', 'basic': True}}),
    ),
    'sv3-197': (
        ('react_ko_counters', {'n': 4}),
    ),
    'sv3pt5-163': (
        ('react_eot_heal', {'n': 20, 'when': ['active'], 'own_turn': True}),
    ),
    'sv4-161': (
        ('react_ko_discard_random', {}),
    ),
    'sv4-166': (
        ('react_ko_prize_delta', {'delta': 1, 'when': ['holder:no_rule_box']}),
    ),
    'sv4-182': (
        ('react_attach_heal', {'n': 30}),
    ),
    'sv4-265': (
        ('react_ko_prize_delta', {'delta': 1, 'when': ['holder:no_rule_box']}),
    ),
    'sv5-151': (
        ('react_ko_baton', {'n': 3, 'when': ['holder:retreat_exactly:4', 'active']}),
    ),
    'sv6-150': (
        ('react_damaged_move_energy_bench', {}),
    ),
    'sv6-164': (
        ('react_survive_full_hp', {}),
    ),
    'sv6pt5-63': (
        ('react_eot_powerglass', {'when': ['active'], 'own_turn': True}),
    ),
    'sv6pt5-97': (
        ('react_eot_powerglass', {'when': ['active'], 'own_turn': True}),
    ),
    'sv7-134': (
        ('react_damaged_counters', {'n': 12}),
        ('react_damaged_discard_if_placed', {}),
    ),
    'sv8-162': (
        ('react_ko_search', {'n': 3}),
    ),
    'swsh1-167': (
        ('react_ko_draw_to', {'n': 7}),
    ),
    'swsh1-168': (
        ('react_eot_cure', {'discard_after': True}),
    ),
    'swsh1-182': (
        ('react_eot_heal', {'n': 30, 'min_counters': 3, 'discard_after': True}),
    ),
    'swsh1-186': (
        ('react_energy_hand_cost', {}),
    ),
    'swsh10-142': (
        ('react_bench_counters', {'n': 2}),
    ),
    'swsh10-152': (
        ('react_weakness_multiplier', {'mult': 3}),
    ),
    'swsh11-170': (
        ('react_attack_despite_status', {}),
    ),
    'swsh11-171': (
        ('react_ko_draw_to', {'n': 7}),
    ),
    'swsh12-155': (
        ('react_eot_heal', {'n': 120, 'remaining_at_most': 30, 'needs_damage': True}),
        ('react_eot_discard_if_healed', {}),
    ),
    'swsh12-168': (
        ('react_evolve_heal', {'n': 100, 'from_subtype': 'V'}),
    ),
    'swsh12-213': (
        ('react_bench_counters', {'n': 2}),
    ),
    'swsh2-155': (
        ('react_damaged_status', {'status': 'burned', 'when': ['holder:type:Fire']}),
    ),
    'swsh2-157': (
        ('react_ko_mill', {'n': 2}),
    ),
    'swsh2-172': (
        ('react_damaged_counters', {'n': 2, 'when': ['holder:type:Psychic']}),
    ),
    'swsh2-173': (
        ('react_attach_draw', {'n': 2, 'when': ['holder:type:Lightning']}),
    ),
    'swsh2-174': (
        ('react_energy_tokens', {}),
        ('react_energy_tokens', {}),
    ),
    'swsh2-209': (
        ('react_energy_tokens', {}),
        ('react_energy_tokens', {}),
    ),
    'swsh3-158': (
        ('react_ko_prizes_discarded', {}),
    ),
    'swsh3-170': (
        ('react_active_to_bench_counters', {'n': 2}),
    ),
    'swsh4-152': (
        ('react_ko_prize_delta', {'delta': -1, 'when': ['holder:subtype:VMAX']}),
        ('react_attach_restriction', {'vmax_remaining_over': 100}),
    ),
    'swsh4-161': (
        ('react_vmax_evolve_heal', {'n': 100}),
    ),
    'swsh4-201': (
        ('react_ko_prize_delta', {'delta': -1, 'when': ['holder:subtype:VMAX']}),
        ('react_attach_restriction', {'vmax_remaining_over': 100}),
    ),
    'swsh6-135': (
        ('react_no_heal', {}),
    ),
    'swsh6-147': (
        ('react_attach_counters', {'n': 2, 'target': {'not_type': 'Psychic'}}),
    ),
    'swsh6-152': (
        ('react_damaged_energy_to_hand', {}),
    ),
    'swsh6-158': (
        ('react_damaged_draw', {'n': 1}),
    ),
    'swsh6-228': (
        ('react_damaged_energy_to_hand', {}),
    ),
    'swsh7-155': (
        ('react_ko_prize_delta', {'delta': -1, 'when': ['holder:subtype:V|name_any:Sylveon']}),
    ),
    'swsh7-160': (
        ('react_damaged_opp_discard', {'n': 1}),
    ),
    'swsh8-234': (
        ('react_ko_search', {'when': ['holder:subtype:VMAX'], 'n': 1}),
    ),
    'swsh8-242': (
        ('react_retreat_energy_to_hand', {}),
    ),
}
