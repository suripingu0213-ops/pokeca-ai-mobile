"""メガ時代(ME・SV10〜)・SM・XYの残りのワザ用プリミティブ(2026-10-07)。scripts/generate_effects_batch13.py のパターンが使う。"""

from __future__ import annotations

from dataclasses import dataclass

from effects.context import EffectContext
from effects.primitives import DealDamage, DealDamageToChosenOpponentPokemon, Effect, _attacker_player, _defender_blocks_effect
from engine.state import PendingSearchChoice


@dataclass(frozen=True)
class FirstTurnUsableMarker(Effect):
    """先攻のときは、最初の自分の番でも使えるワザであることを表す印(何もしない。Quick Gift/Fast Flight)。"""

    usable_on_first_turn_if_first_player = True

    def execute(self, ctx: EffectContext) -> None:
        return


@dataclass(frozen=True)
class DealDamagePlusDamageTakenLastTurn(Effect):
    """このポケモンが相手の前の番にワザのダメージを受けていたら、そのダメージぶん追加で与える(Juggernaut Horn)。"""

    base: int

    def execute(self, ctx: EffectContext) -> None:
        mon = ctx.source_pokemon
        extra = mon.last_attack_damage_taken if mon is not None and mon.last_attack_damage_turn == ctx.state.turn_number - 1 else 0
        DealDamage(self.base + max(0, extra)).execute(ctx)


@dataclass(frozen=True)
class DamageIfOwnNamedKnockedOutLastTurn(Effect):
    """直前の相手の番に、自分の(名前が接頭辞で始まる)ポケモンがワザのダメージできぜつしていれば追加ダメージ(Horrifying Revenge)。"""

    base: int
    bonus: int
    prefix: str

    def execute(self, ctx: EffectContext) -> None:
        player = _attacker_player(ctx)
        hit = any(name.startswith(self.prefix) for name in player.ko_by_attack_names_last_turn)
        DealDamage(self.base + (self.bonus if hit else 0)).execute(ctx)


@dataclass(frozen=True)
class DamageIfOwnBenchedNamedDamaged(Effect):
    """自分のベンチの指定の名前のポケモンにダメカンがのっていれば追加ダメージ(Master's Punch)。"""

    base: int
    bonus: int
    name: str

    def execute(self, ctx: EffectContext) -> None:
        player = _attacker_player(ctx)
        hit = any(m.damage > 0 and (c := ctx.card_db.get(m.card_id)) is not None and c.name == self.name for m in player.bench)
        DealDamage(self.base + (self.bonus if hit else 0)).execute(ctx)


@dataclass(frozen=True)
class DamagePerOwnBenchedNameContains(Effect):
    """自分のベンチの、名前に指定の語を含むポケモン1匹につき追加ダメージ(Fossil Beatdown)。"""

    base: int
    per: int
    text: str

    def execute(self, ctx: EffectContext) -> None:
        player = _attacker_player(ctx)
        n = sum(1 for m in player.bench if (c := ctx.card_db.get(m.card_id)) is not None and self.text in c.name)
        DealDamage(self.base + self.per * n).execute(ctx)


@dataclass(frozen=True)
class DamagePerOpponentPokemonWithAbility(Effect):
    """相手の場の、特性を持つポケモン1匹につき追加ダメージ(Evil Admonition)。"""

    base: int
    per: int

    def execute(self, ctx: EffectContext) -> None:
        opponent = ctx.state.player(ctx.opponent)
        n = sum(1 for m in opponent.all_pokemon_in_play() if (c := ctx.card_db.get(m.card_id)) is not None and c.abilities)
        DealDamage(self.base + self.per * n).execute(ctx)


@dataclass(frozen=True)
class DamageIfOwnBenchedHaveEnergyNamed(Effect):
    """自分のベンチのポケモンに、指定の名前のエネルギーがついていれば追加ダメージ(Shadowy Whip)。"""

    base: int
    bonus: int
    energy_name: str

    def execute(self, ctx: EffectContext) -> None:
        player = _attacker_player(ctx)
        hit = any(
            (c := ctx.card_db.get(e)) is not None and c.name == self.energy_name for m in player.bench for e in m.attached_energy
        )
        DealDamage(self.base + (self.bonus if hit else 0)).execute(ctx)


def _remaining_hp(ctx: EffectContext, mon) -> int:
    from engine.continuous import effective_max_hp

    return effective_max_hp(ctx.card_db, mon.card_id, mon.attached_tool, ctx.state.stadium_in_play, mon.attached_energy) - mon.damage


@dataclass(frozen=True)
class KnockOutLeastHpPokemonInPlay(Effect):
    """場(おたがい)の、このポケモン以外で残りHPが最も少ないポケモン1匹をきぜつさせる(同じなら選ぶ)(Bring Down)。"""

    def execute(self, ctx: EffectContext) -> None:
        candidates = []
        for side in (ctx.acting_player, ctx.opponent):
            for mon in ctx.state.player(side).all_pokemon_in_play():
                if mon is ctx.source_pokemon:
                    continue
                candidates.append((side, mon, _remaining_hp(ctx, mon)))
        if not candidates:
            return
        least = min(hp for _s, _m, hp in candidates)
        tied = [(s, m) for s, m, hp in candidates if hp == least]
        side, mon = tied[0] if len(tied) == 1 else tied[ctx.rng.randrange(len(tied))]
        if side == ctx.opponent and _defender_blocks_effect(ctx, mon):
            return
        mon.damage += 10000
        ctx.log(f"{mon.card_id} がきぜつした(場で残りHPが最も少なかった)")


@dataclass(frozen=True)
class KnockOutOpponentPokemonWithHpAtMost(Effect):
    """相手の場の、残りHPがhp以下のポケモンを全てきぜつさせる(Soul Destroyer)。"""

    hp: int

    def execute(self, ctx: EffectContext) -> None:
        for mon in ctx.state.player(ctx.opponent).all_pokemon_in_play():
            if _remaining_hp(ctx, mon) <= self.hp and not _defender_blocks_effect(ctx, mon):
                mon.damage += 10000
                ctx.log(f"{mon.card_id} がきぜつした(残りHP{self.hp}以下)")


@dataclass(frozen=True)
class OpponentChoosesHandCardsToDeck(Effect):
    """相手が手札のカードをcount枚選び、山札に戻してシャッフルする(Cursed Words)。手札がcount枚以下なら全て。"""

    count: int

    def execute(self, ctx: EffectContext) -> None:
        opponent = ctx.state.player(ctx.opponent)
        if not opponent.hand:
            return
        n = min(self.count, len(opponent.hand))
        ctx.state.pending_search_choice = PendingSearchChoice(
            player_index=ctx.opponent,
            zone="gen_hand_pick",
            source_indices=list(range(len(opponent.hand))),
            card_ids=list(opponent.hand),
            min_count=n,
            max_count=n,
            prompt=f"手札から山札に戻すカードを{n}枚選ぶ",
            shuffle_after=False,
            all_card_ids=list(opponent.hand),
            custom_data={"op": "own_hand_to_deck"},
            effect_source=ctx.effect_source,
        )


def _op_own_hand_to_deck(state, card_db, choice, selected, action, ctx, custom) -> bool:
    owner = state.player(choice.player_index)
    for i in sorted((choice.source_indices[p] for p in selected), reverse=True):
        if 0 <= i < len(owner.hand):
            owner.deck.append(owner.hand.pop(i))
    state.rng.shuffle(owner.deck)
    state.add_log("手札から選んだカードを山札に戻してシャッフルした")
    return False


@dataclass(frozen=True)
class DiscardTopNDamagePerBasicEnergy(Effect):
    """自分の山札の上からn枚をトラッシュし、その中の指定タイプの基本エネルギー1枚につき、per ダメージ(Iceberg Breaker)。"""

    n: int
    per: int
    energy_type: str

    def execute(self, ctx: EffectContext) -> None:
        player = _attacker_player(ctx)
        count = 0
        for _ in range(min(self.n, len(player.deck))):
            card_id = player.deck.pop(0)
            player.discard.append(card_id)
            c = ctx.card_db.get(card_id)
            if c is not None and c.is_energy and not c.is_special_energy and c.basic_energy_type == self.energy_type:
                count += 1
        if count:
            DealDamage(self.per * count).execute(ctx)


@dataclass(frozen=True)
class DamagePerOwnDiscardBasicEnergyOfTypeThenShuffle(Effect):
    """自分のトラッシュの指定タイプの基本エネルギー1枚につき per ダメージ。そのあと、そのカードを山札に戻してシャッフルする(Riptide)。"""

    per: int
    energy_type: str

    def execute(self, ctx: EffectContext) -> None:
        player = _attacker_player(ctx)
        cards = [cid for cid in player.discard if (c := ctx.card_db.get(cid)) is not None and c.is_energy and not c.is_special_energy and c.basic_energy_type == self.energy_type]
        if cards:
            DealDamage(self.per * len(cards)).execute(ctx)
        for cid in cards:
            player.discard.remove(cid)
            player.deck.append(cid)
        ctx.rng.shuffle(player.deck)


@dataclass(frozen=True)
class DiscardStadiumThenOpponentCantPlayStadium(Effect):
    """場にスタジアムがあればトラッシュし、そうしたら相手は次の番、手札からスタジアムを使えない(Scorching Earth)。"""

    def execute(self, ctx: EffectContext) -> None:
        state = ctx.state
        if state.stadium_in_play is None:
            return
        owner = state.stadium_owner
        discarded = state.stadium_in_play
        state.stadium_in_play = None
        state.stadium_owner = None
        state.stadium_orientation_target = None
        (state.player(owner) if owner is not None else _attacker_player(ctx)).discard.append(discarded)
        state.player(ctx.opponent).stadiums_locked_until_turn = state.player(ctx.opponent).turns_taken + 1
        ctx.log("スタジアムをトラッシュし、相手は次の番、スタジアムを使えない")


@dataclass(frozen=True)
class LookTopCardMayDiscard(Effect):
    """自分の山札の一番上を見て、トラッシュしてもよい(Brighten and Burn)。"""

    def execute(self, ctx: EffectContext) -> None:
        player = _attacker_player(ctx)
        if not player.deck:
            return
        ctx.state.pending_search_choice = PendingSearchChoice(
            player_index=ctx.acting_player,
            zone="deck",
            source_indices=[0],
            card_ids=[player.deck[0]],
            min_count=0,
            max_count=1,
            prompt="山札の一番上のカードをトラッシュしてもよい",
            shuffle_after=False,
            all_card_ids=[player.deck[0]],
            destination="discard",
            reveal_to_opponent=False,
            effect_source=ctx.effect_source,
        )


@dataclass(frozen=True)
class LookTopNPokemonToBench(Effect):
    """山札の上からn枚を見て、その中のたねポケモンを好きな数ベンチに出す。残りは山札に戻してシャッフルする(Trick Portal)。"""

    n: int

    def execute(self, ctx: EffectContext) -> None:
        from engine.continuous import effective_bench_limit

        player = _attacker_player(ctx)
        positions = [i for i, cid in enumerate(player.deck[: self.n]) if (c := ctx.card_db.get(cid)) is not None and c.is_pokemon and c.is_basic]
        space = effective_bench_limit(ctx.state, player, ctx.card_db) - len(player.bench)
        if not positions or space <= 0:
            ctx.rng.shuffle(player.deck)
            return
        ctx.state.pending_search_choice = PendingSearchChoice(
            player_index=ctx.acting_player,
            zone="deck",
            source_indices=positions,
            card_ids=[player.deck[i] for i in positions],
            min_count=0,
            max_count=min(space, len(positions)),
            prompt="山札の上から見たたねポケモンを、好きな数ベンチに出す",
            shuffle_after=True,
            all_card_ids=[player.deck[i] for i in positions],
            destination="bench",
            effect_source=ctx.effect_source,
        )


@dataclass(frozen=True)
class NextTurnSelfAttackBonus(Effect):
    """自分の次の番、このポケモンのワザは相手のバトルポケモンに+amountダメージ(弱点・抵抗力の前)(No Reprieve/Slumbering Smack)。"""

    amount: int

    def execute(self, ctx: EffectContext) -> None:
        mon = ctx.source_pokemon
        if mon is None:
            return
        mon.next_turn_attack_bonus = self.amount
        mon.next_turn_attack_bonus_until = _attacker_player(ctx).turns_taken + 1


@dataclass(frozen=True)
class DiscardBasicEnergyFromHandOrNothing(Effect):
    """手札から指定タイプの基本エネルギーをcount枚トラッシュする。トラッシュできなければこのワザは何もしない(Infernal Slash)。"""

    count: int
    energy_type: str
    then: tuple = ()

    def execute(self, ctx: EffectContext) -> None:
        from effects.primitives import _trigger_search_choice

        player = _attacker_player(ctx)
        n = sum(1 for cid in player.hand if (c := ctx.card_db.get(cid)) is not None and c.is_energy and not c.is_special_energy and c.basic_energy_type == self.energy_type)
        if n < self.count:
            ctx.log("手札に必要なエネルギーが足りないので、このワザは何もしない")
            return
        _trigger_search_choice(
            ctx, player, "hand",
            lambda c: c is not None and c.is_energy and not c.is_special_energy and c.basic_energy_type == self.energy_type,
            self.count, f"トラッシュする基本{self.energy_type}エネルギーを{self.count}枚選ぶ", shuffle_after=False, destination="discard", min_count=self.count,
        )
        pending = ctx.state.pending_search_choice
        if pending is not None:
            pending.remaining_script = tuple(self.then)
            pending.cont_source_pokemon = ctx.source_pokemon
            pending.cont_source_card_id = ctx.source_card_id
            pending.effect_source = ctx.effect_source


@dataclass(frozen=True)
class DealDamageOnlyIfSelfHasEnergyNamed(Effect):
    """このポケモンに指定の名前のエネルギーがついていなければ、このワザは何もしない。ついていればamountダメージ(Giga Railgun)。"""

    amount: int
    energy_name: str

    def execute(self, ctx: EffectContext) -> None:
        mon = ctx.source_pokemon
        if mon is None or not any((c := ctx.card_db.get(e)) is not None and c.name == self.energy_name for e in mon.attached_energy):
            ctx.log(f"{self.energy_name}がついていないので、このワザは何もしない")
            return
        DealDamage(self.amount).execute(ctx)


@dataclass(frozen=True)
class IfSupporterNamedPlayedThisTurn(Effect):
    """この番、指定の名前のサポートを手札から使っていれば、thenを実行する(Twister Spewing)。"""

    name: str
    then: tuple = ()

    def execute(self, ctx: EffectContext) -> None:
        if self.name in _attacker_player(ctx).supporter_names_this_turn:
            for effect in self.then:
                effect.execute(ctx)


@dataclass(frozen=True)
class FlipUntilTailsSearchDeckForCardsToHand(Effect):
    """ウラが出るまでコインを投げ、オモテの数まで、山札から好きなカードを手札に加える(All-You-Can-Grab)。"""

    def execute(self, ctx: EffectContext) -> None:
        from effects.primitives import SearchDeckAnyCardToHand

        heads = 0
        while ctx.rng.random() < 0.5:
            heads += 1
        ctx.log(f"コイン: オモテ{heads}回")
        if heads > 0:
            SearchDeckAnyCardToHand(count=heads).execute(ctx)


@dataclass(frozen=True)
class AttachDiscardEnergyUpToOpponentEnergyCount(Effect):
    """相手の場の全てのポケモンについているエネルギーの数まで、トラッシュの基本エネルギー(指定タイプ)を、自分の(指定タイプの)ポケモンに好きなようにつける(Tail Generator)。"""

    energy_type: str
    target_type: str

    def execute(self, ctx: EffectContext) -> None:
        from effects.era_primitives_b import AttachEnergyGeneric

        opponent = ctx.state.player(ctx.opponent)
        n = sum(len(m.attached_energy) for m in opponent.all_pokemon_in_play())
        if n <= 0:
            return
        AttachEnergyGeneric(
            source="discard", count=n, basic_only=True, energy_type=self.energy_type, target_type=self.target_type, optional=True
        ).execute(ctx)


@dataclass(frozen=True)
class FlipCoinsThenAttachMultiplied(Effect):
    """コインをcoins枚投げ、オモテ1枚につき山札から基本エネルギーをper_head枚まで、自分のポケモンに好きなようにつける(Kaleidowaltz)。"""

    coins: int
    per_head: int

    def execute(self, ctx: EffectContext) -> None:
        from effects.era_primitives_b import AttachEnergyGeneric

        heads = sum(1 for _ in range(self.coins) if ctx.rng.random() < 0.5)
        ctx.log(f"コイン: オモテ{heads}回")
        if heads > 0:
            AttachEnergyGeneric(source="deck", count=heads * self.per_head, basic_only=True, optional=True).execute(ctx)


@dataclass(frozen=True)
class FlipUntilTailsRandomOpponentHandToDeck(Effect):
    """ウラが出るまでコインを投げ、オモテ1回につき相手の手札からランダムに1枚を公開させ、山札に戻してシャッフルする(Horrifying Bite)。"""

    def execute(self, ctx: EffectContext) -> None:
        from effects.era_trainers import RandomOpponentHandCardsToDeck

        heads = 0
        while ctx.rng.random() < 0.5:
            heads += 1
        ctx.log(f"コイン: オモテ{heads}回")
        if heads > 0:
            RandomOpponentHandCardsToDeck(heads).execute(ctx)


@dataclass(frozen=True)
class FlipCoinsThenOpponentHandPickToDeck(Effect):
    """コインをcoins枚投げ、1枚でもオモテなら相手は手札を公開する。オモテ1枚につき、そこから1枚を選んで相手の山札に戻してシャッフルする(Snap Inspection)。"""

    coins: int

    def execute(self, ctx: EffectContext) -> None:
        heads = sum(1 for _ in range(self.coins) if ctx.rng.random() < 0.5)
        ctx.log(f"コイン: オモテ{heads}回")
        opponent = ctx.state.player(ctx.opponent)
        if heads <= 0 or not opponent.hand:
            return
        _attacker_player(ctx).known_opponent_hand = list(opponent.hand)
        ctx.reveal("相手の手札", list(opponent.hand))
        n = min(heads, len(opponent.hand))
        ctx.state.pending_search_choice = PendingSearchChoice(
            player_index=ctx.acting_player,
            zone="gen_hand_pick",
            source_indices=list(range(len(opponent.hand))),
            card_ids=list(opponent.hand),
            min_count=n,
            max_count=n,
            prompt=f"相手の山札に戻す、相手の手札のカードを{n}枚選ぶ",
            shuffle_after=False,
            all_card_ids=list(opponent.hand),
            custom_data={"op": "opp_hand_pick_to_deck"},
            effect_source=ctx.effect_source,
        )


def _op_opp_hand_pick_to_deck(state, card_db, choice, selected, action, ctx, custom) -> bool:
    opponent = state.player(1 - choice.player_index)
    for i in sorted((choice.source_indices[p] for p in selected), reverse=True):
        if 0 <= i < len(opponent.hand):
            opponent.deck.append(opponent.hand.pop(i))
    state.rng.shuffle(opponent.deck)
    state.add_log("相手の手札から選んだカードを相手の山札に戻してシャッフルした")
    return False


@dataclass(frozen=True)
class CopyOwnBenchedPokemonAttack(Effect):
    """自分のベンチの(名前が接頭辞で始まる/サブタイプを持つ)ポケモンのワザを1つ選び、このワザとして使う(Night Joker)。"""

    name_prefix: str | None = None
    subtype: str | None = None

    def execute(self, ctx: EffectContext) -> None:
        from effects.era_primitives_e import _offer_options, _revealed_options_for_card

        player = _attacker_player(ctx)
        option_cards: list = []
        options: list = []
        seen = set()
        for mon in player.bench:
            if mon.card_id in seen:
                continue
            seen.add(mon.card_id)
            card = ctx.card_db.get(mon.card_id)
            if card is None or not card.attacks:
                continue
            if self.name_prefix and not card.name.startswith(self.name_prefix):
                continue
            if self.subtype and self.subtype not in card.subtypes:
                continue
            for opt in _revealed_options_for_card(ctx, mon.card_id, card, reentrant_effect=self):
                options.append(opt)
                option_cards.append(mon.card_id)
        _offer_options(ctx, option_cards, options, "ベンチのポケモンのワザを1つ選んで使う")


@dataclass(frozen=True)
class CopyOpponentPokemonAttackIfHandEmpty(Effect):
    """自分の手札が無ければ、相手の場のポケモン1匹のワザを1つ選び、このワザとして使う(Skill Thief)。"""

    def execute(self, ctx: EffectContext) -> None:
        if _attacker_player(ctx).hand:
            ctx.log("手札があるので、このワザは何もしない")
            return
        from effects.era_primitives_f import CopyChosenOpponentPokemonAttack

        CopyChosenOpponentPokemonAttack().execute(ctx)


@dataclass(frozen=True)
class CopyOpponentBenchedPokemonAttack(Effect):
    """相手のベンチのポケモンのワザを1つ選び、このワザとして使う(Rainbow Moves。エネルギーのコストは必要ない)。"""

    def execute(self, ctx: EffectContext) -> None:
        from effects.era_primitives_e import _offer_options, _revealed_options_for_card

        opponent = ctx.state.player(ctx.opponent)
        option_cards: list = []
        options: list = []
        seen = set()
        for mon in opponent.bench:
            if mon.card_id in seen:
                continue
            seen.add(mon.card_id)
            card = ctx.card_db.get(mon.card_id)
            if card is None or not card.attacks:
                continue
            for opt in _revealed_options_for_card(ctx, mon.card_id, card, reentrant_effect=self):
                options.append(opt)
                option_cards.append(mon.card_id)
        _offer_options(ctx, option_cards, options, "相手のベンチのポケモンのワザを1つ選んで使う")


@dataclass(frozen=True)
class CopyOpponentLastNonGxAttack(Effect):
    """相手のポケモンが相手の前の番にGXワザ以外のワザを使っていれば、それをこのワザとして使う(Copycat)。"""

    def execute(self, ctx: EffectContext) -> None:
        from effects.primitives import run_borrowed_attack_script

        used = ctx.state.player(ctx.opponent).last_attack_used
        if not used:
            ctx.log("相手の前の番にワザは使われていない")
            return
        card_id, attack_name = used
        card = ctx.card_db.get(card_id)
        attack = next((a for a in card.attacks if a.name == attack_name), None) if card is not None else None
        if attack is None or "GX attack in a game" in (attack.text or ""):
            ctx.log("相手が前の番に使ったのはGXワザなので、このワザは何もしない")
            return
        run_borrowed_attack_script(ctx, card_id, attack_name)


@dataclass(frozen=True)
class DiscardTopCardUseSupporterEffect(Effect):
    """自分の山札の一番上をトラッシュし、それがサポートなら、その効果をこのワザの効果として使う(Supernatural Shapeshifter)。"""

    def execute(self, ctx: EffectContext) -> None:
        from effects.interpreter import run_script
        from effects.registry import get_trainer_script

        player = _attacker_player(ctx)
        if not player.deck:
            return
        card_id = player.deck.pop(0)
        player.discard.append(card_id)
        card = ctx.card_db.get(card_id)
        if card is not None and card.is_supporter:
            ctx.log(f"トラッシュしたサポート {card.name} の効果を使う")
            run_script(get_trainer_script(card_id), ctx)


@dataclass(frozen=True)
class EvolveEachOwnBenchedFromDeck(Effect):
    """自分のベンチのポケモンそれぞれについて、山札から進化先を探して、そのポケモンに重ねて進化させる(Cellular Ascension)。"""

    def execute(self, ctx: EffectContext) -> None:
        from effects.primitives import InstantEvolveEachTargetFromDeck

        player = _attacker_player(ctx)
        if player.bench:
            InstantEvolveEachTargetFromDeck(tuple(player.bench)).execute(ctx)


@dataclass(frozen=True)
class ShieldSelfIfDefenderKnockedOut(Effect):
    """このワザのダメージで相手のポケモンがきぜつしたなら、相手の次の番、このポケモンはワザのダメージも効果も受けない(Critical Slash)。"""

    def execute(self, ctx: EffectContext) -> None:
        from effects.primitives import ApplyShieldToSelf, _defender
        from engine.continuous import effective_max_hp

        _, defender = _defender(ctx)
        if defender is None:
            return
        max_hp = effective_max_hp(ctx.card_db, defender.card_id, defender.attached_tool, ctx.state.stadium_in_play, defender.attached_energy)
        if max_hp and defender.damage >= max_hp:
            ApplyShieldToSelf().execute(ctx)


@dataclass(frozen=True)
class SetOpponentAttachLock(Effect):
    """相手の次の番の制限: kind="special_energy"=手札から特殊エネルギーをつけられない(Bind Pulse)/"defender_energy"=手札からエネルギーをこのワザを受けたポケモンにつけられない(Cursed Roots)/
    "defender_counters"=手札からエネルギーをそのポケモンにつけるたびにダメカンをamount個のせる(Electrified Incisors)。"""

    kind: str
    amount: int = 0

    def execute(self, ctx: EffectContext) -> None:
        opponent = ctx.state.player(ctx.opponent)
        until = opponent.turns_taken + 1
        if self.kind == "special_energy":
            opponent.special_energy_attach_locked_until_turn = until
            return
        from effects.primitives import _defender

        _, defender = _defender(ctx)
        if defender is None or _defender_blocks_effect(ctx, defender):
            return
        if self.kind == "defender_energy":
            defender.no_energy_attach_until_turn = until  # (Cross Slicerと同じ制限)
        elif self.kind == "defender_counters":
            defender.attach_counters_until_turn = until
            defender.attach_counters_amount = self.amount


@dataclass(frozen=True)
class SetSelfAttackerShield(Effect):
    """相手の次の番、(特性を持つポケモン/進化ポケモン)からのこのポケモンへのダメージを防ぐ/減らす(Psy Protection/Metal Block)。
    kind="ability"=特性を持つポケモンのワザのダメージを全て防ぐ/"evolution"=進化ポケモンのワザのダメージをamount減らす。"""

    kind: str
    amount: int = 0

    def execute(self, ctx: EffectContext) -> None:
        mon = ctx.source_pokemon
        if mon is None:
            return
        until = ctx.state.player(ctx.opponent).turns_taken + 1
        if self.kind == "ability":
            mon.shield_vs_ability_until = until
        else:
            mon.evolution_damage_reduction_until = until
            mon.evolution_damage_reduction_amount = self.amount


@dataclass(frozen=True)
class DealDamageToChosenOpponentPokemonIf(DealDamageToChosenOpponentPokemon):
    """相手の場のポケモン1匹を選んでamountダメージ(ベンチは弱点・抵抗力を計算しない)。条件を満たさなければ何もしない。
    condition: ""=無条件 / "own_discard_10_basic_fighting"=自分のトラッシュに基本闘エネルギーが10枚以上(Tar Cannon)。
    special_energy_only=Trueなら、特殊エネルギーがついている相手のポケモンだけを選べる(Bone Sniper)。"""

    condition: str = ""
    special_energy_only: bool = False

    def execute(self, ctx: EffectContext) -> None:
        if self.condition == "own_discard_10_basic_fighting":
            n = sum(1 for cid in _attacker_player(ctx).discard if (c := ctx.card_db.get(cid)) is not None and c.is_energy and not c.is_special_energy and c.basic_energy_type == "Fighting")
            if n < 10:
                ctx.log("トラッシュの基本闘エネルギーが10枚に満たないので、このワザは何もしない")
                return
        super().execute(ctx)


@dataclass(frozen=True)
class DamagePerOpponentPrizesTakenLastTurn(Effect):
    """相手が直前の番にとったサイド1枚につき追加ダメージ(Settle the Score)。"""

    base: int
    per: int

    def execute(self, ctx: EffectContext) -> None:
        taken = ctx.state.player(ctx.opponent).prizes_taken_this_turn
        DealDamage(self.base + self.per * taken).execute(ctx)


@dataclass(frozen=True)
class LookAtOpponentFaceDownPrize(Effect):
    """相手の裏向きのサイドを1枚見る(Searching Eyes)。見るだけで、ゲームの状態は変わらない(ログに残す)。"""

    def execute(self, ctx: EffectContext) -> None:
        opponent = ctx.state.player(ctx.opponent)
        face_down = [i for i in range(len(opponent.prizes)) if opponent.prize_mark(i) == 0]
        if face_down:
            ctx.log("相手の裏向きのサイドを1枚見た")


@dataclass(frozen=True)
class LockOpponentHandPlayNextTurn(Effect):
    """相手は次の番、手札から(kind="trainers"=トレーナーズ(グッズ/サポート/スタジアム/どうぐ)/"all"=カード全て)を使えない。"""

    kind: str

    def execute(self, ctx: EffectContext) -> None:
        opponent = ctx.state.player(ctx.opponent)
        until = opponent.turns_taken + 1
        opponent.items_locked_until_turn = until
        opponent.supporters_locked_until_turn = until
        opponent.stadiums_locked_until_turn = until
        opponent.tools_locked_until_turn = until
        if self.kind == "all":
            opponent.hand_cards_locked_until_turn = until


@dataclass(frozen=True)
class ShuffleHandIntoDeckThenDrawPerOpponentHand(Effect):
    """自分の手札を山札に戻してシャッフルし、相手の手札の枚数ぶん引く。"""

    def execute(self, ctx: EffectContext) -> None:
        from effects.primitives import Draw

        player = _attacker_player(ctx)
        n = len(ctx.state.player(ctx.opponent).hand)
        player.deck.extend(player.hand)
        player.hand = []
        ctx.rng.shuffle(player.deck)
        if n:
            Draw(n).execute(ctx)


def _register_conditions() -> None:
    from effects.era_primitives import EXTRA_CONDITIONS

    def defender_subtype_any(ctx, arg, player, opponent, self_mon, defender):
        card = ctx.card_db.get(defender.card_id) if defender is not None else None
        subtypes = arg.split(",") if isinstance(arg, str) else list(arg)
        return card is not None and bool(set(subtypes) & set(card.subtypes))

    EXTRA_CONDITIONS["defender_subtype_any"] = defender_subtype_any


_register_conditions()


def register_ops() -> None:
    from effects.era_primitives_b import GENERIC_OP_HANDLERS

    GENERIC_OP_HANDLERS.update({"own_hand_to_deck": _op_own_hand_to_deck, "opp_hand_pick_to_deck": _op_opp_hand_pick_to_deck})


register_ops()
