"""条件付きパッシブ特性の汎用種別(2026-10-07: SM時代の特性の取り込み)。

SMの特性は「〜の間」「〜がいれば」「エネルギーがついていれば」のような条件+対象(自分/チーム/相手)+効果の組み合わせが多いので、
種別ごとに専用のクラスを作らず、条件(when)と対象の絞り込み(target/src)をデータとして持つ汎用の種別で表す。
宣言は scripts/generate_abilities_patterns_e.py が生成し、各フックは effects/passives.py と effects/passives_ext.py から呼ばれる。

共通のパラメータ:
  scope    "self"=この特性を持つポケモンだけ / "team"=持ち主側の全ポケモン(targetで絞る)
  affects  "own"(既定)=持ち主側 / "opp"=持ち主の相手側 / "both"=両者。targetで絞る側のポケモンがどちらか。
  when     この特性を持つポケモン(持ち主)側の条件のリスト("名前:引数")。全て満たすとき有効。
  target   効果を受けるポケモン(防御側/ワザを使う側/にげる側…)の絞り込み
  src      相手側(ワザを使うポケモン/ダメージを受けるポケモン)の絞り込み
  nostack  「この特性は重ならない」の重複排除キー
"""

from __future__ import annotations

from effects.passives import _has_energy, _locate, _types, active_passives, team_passives

import os

try:  # どうぐ・スタジアムの効果の宣言(scripts/generate_tool_passives.pyが生成。生成スクリプト自身は環境変数で無視して冪等にする)
    if os.environ.get("POKECA_IGNORE_GENERATED_TOOLS"):
        raise ImportError
    from effects.generated_tool_passives import STADIUM_PASSIVES, TOOL_PASSIVES
except ImportError:  # pragma: no cover
    TOOL_PASSIVES: dict = {}
    STADIUM_PASSIVES: dict = {}

COND_KINDS = frozenset({
    "cond_bench_limit", "cond_attach_counters",
    "cond_damage_taken", "cond_prevent", "cond_attack_bonus", "cond_retreat", "cond_weakness", "cond_hp", "cond_cost",
    "cond_status_immune", "cond_ability_lock", "cond_lock", "cond_between_turns", "cond_counter_shield",
})


# ---------------------------------------------------------------------------------------------
# 条件・絞り込み
# ---------------------------------------------------------------------------------------------
def _pokemon_count(player) -> int:
    return len(player.all_pokemon_in_play())


def _own_names(card_db, player) -> set:
    return {c.name for m in player.all_pokemon_in_play() if (c := card_db.get(m.card_id)) is not None}


def _subtypes_in_play(state, card_db, player, subtypes) -> bool:
    return any((c := card_db.get(m.card_id)) is not None and any(s in c.subtypes for s in subtypes) for m in player.all_pokemon_in_play())


def holder_ok(state, card_db, idx: int, holder, when) -> bool:
    """この特性を持つポケモン(holder, プレイヤーidx)の条件(when)を全て満たすか。"""
    if not when:
        return True
    if holder is None:
        return False  # スタジアムの効果には、持ち主のポケモンに関する条件は付かない
    owner = state.player(idx)
    opp = state.player(1 - idx)
    for cond in when:
        name, _, arg = cond.partition(":")
        if name == "active":
            ok = holder is owner.active
        elif name == "bench":
            ok = holder is not owner.active
        elif name == "energy_any":
            ok = bool(holder.attached_energy)
        elif name == "energy_type":
            ok = _has_energy(card_db, holder, arg)
        elif name == "energy_at_most":
            ok = len(holder.attached_energy) <= int(arg)
        elif name == "basic_energy_any":
            ok = any((c := card_db.get(e)) is not None and c.is_energy and not c.is_special_energy for e in holder.attached_energy)
        elif name == "special_energy_any":
            ok = any((c := card_db.get(e)) is not None and c.is_special_energy for e in holder.attached_energy)
        elif name == "full_hp":
            ok = holder.damage == 0
        elif name == "stadium":
            ok = state.stadium_in_play is not None
        elif name == "opp_in_play_subtype":
            ok = _subtypes_in_play(state, card_db, opp, arg.split("|"))
        elif name == "opp_prizes_at_most":
            ok = len(opp.prizes) <= int(arg)
        elif name == "own_prizes_more_than_opp":
            ok = len(owner.prizes) > len(opp.prizes)
        elif name == "own_name_in_play":
            ok = set(arg.split("|")) <= _own_names(card_db, owner)
        elif name == "own_type_in_play":
            ok = any(arg in _types(card_db, m) for m in owner.all_pokemon_in_play())
        elif name == "not_more_in_play":
            ok = _pokemon_count(owner) <= _pokemon_count(opp)
        elif name == "fewer_in_play":
            ok = _pokemon_count(owner) < _pokemon_count(opp)
        elif name == "first_turn":
            ok = owner.turns_taken <= 1
        elif name == "opp_active_subtype":
            oc = card_db.get(opp.active.card_id) if opp.active is not None else None
            ok = oc is not None and arg in oc.subtypes
        elif name == "stadiums_in_discard_at_least":
            ok = sum(1 for cid in owner.discard if (c := card_db.get(cid)) is not None and c.is_stadium) >= int(arg)
        elif name == "played_supporter_named":
            ok = arg in owner.supporter_names_this_turn
        elif name == "holder":
            from effects.era_attacks_i import card_matches

            ok = card_matches(card_db.get(holder.card_id), arg)  # このポケモン(どうぐがついているポケモン)の絞り込み
        elif name == "holder_weak_to_opp_active":
            hc = card_db.get(holder.card_id)
            oc = card_db.get(opp.active.card_id) if opp.active is not None else None
            ok = hc is not None and oc is not None and any(w.type in _types(card_db, opp.active) for w in hc.weaknesses)
        elif name == "energy_type_at_least":  # "energy_type_at_least:Metal:2": その基本エネルギーが2枚以上ついている
            etype, _, count = arg.partition(":")
            ok = sum(1 for e in holder.attached_energy if (c := card_db.get(e)) is not None and c.basic_energy_type == etype) >= int(count)
        elif name == "same_energy_as_opp_active":
            ok = opp.active is not None and len(holder.attached_energy) == len(opp.active.attached_energy)
        elif name == "remaining_hp_at_most":
            from engine.continuous import effective_max_hp

            ok = effective_max_hp(card_db, holder.card_id, holder.attached_tool, state.stadium_in_play, holder.attached_energy) - holder.damage <= int(arg)
        elif name == "tools_in_discard_at_least":
            ok = sum(1 for cid in owner.discard if (c := card_db.get(cid)) is not None and c.is_pokemon_tool) >= int(arg)
        else:
            ok = False  # 未知の条件は成立させない(誤って効果を出さない)
        if not ok:
            return False
    return True


def match(state, card_db, mon, flt, owner_index: int | None = None) -> bool:
    """monが絞り込み(flt)に合うか。fltがNone/空なら常に真。owner_indexは、monがどちらの場にいるか(zone判定用)。"""
    if not flt:
        return True
    card = card_db.get(mon.card_id)
    if card is None:
        return False
    if "type" in flt:
        want = flt["type"] if isinstance(flt["type"], (list, tuple)) else [flt["type"]]
        if not set(want) & set(_types(card_db, mon)):
            return False
    if flt.get("not_type") and flt["not_type"] in _types(card_db, mon):
        return False
    if "subtype" in flt:
        want = flt["subtype"] if isinstance(flt["subtype"], (list, tuple)) else [flt["subtype"]]
        if not any(s in card.subtypes for s in want):
            return False
    if flt.get("not_subtype") and any(s in card.subtypes for s in flt["not_subtype"]):
        return False
    if "name" in flt and card.name != flt["name"]:
        return False
    if flt.get("not_name") and card.name == flt["not_name"]:
        return False
    if "name_in" in flt and card.name not in flt["name_in"]:
        return False
    if "name_part" in flt and flt["name_part"] not in card.name:
        return False
    if flt.get("basic") and not card.is_basic:
        return False
    if flt.get("evolution") and card.is_basic:
        return False
    if "stage" in flt and flt["stage"] not in card.subtypes:
        return False
    if flt.get("evolves_from") and card.evolves_from != flt["evolves_from"]:
        return False
    if flt.get("special_energy") and not any((c := card_db.get(e)) is not None and c.is_special_energy for e in mon.attached_energy):
        return False
    if "energy_at_most" in flt and len(mon.attached_energy) > flt["energy_at_most"]:
        return False
    if "has_energy_type" in flt:
        kinds = flt["has_energy_type"] if isinstance(flt["has_energy_type"], (list, tuple)) else [flt["has_energy_type"]]
        if not any(_has_energy(card_db, mon, k) for k in kinds):
            return False
    if flt.get("has_energy") and not mon.attached_energy:
        return False
    if flt.get("has_ability") and not card.abilities:
        return False
    if flt.get("has_attack") and not any(a.name == flt["has_attack"] for a in card.attacks):
        return False
    if flt.get("damaged") and mon.damage <= 0:
        return False
    if "remaining_hp_at_most" in flt:
        from engine.continuous import effective_max_hp

        if effective_max_hp(card_db, mon.card_id, mon.attached_tool, state.stadium_in_play, mon.attached_energy) - mon.damage > flt["remaining_hp_at_most"]:
            return False
    if flt.get("poisoned") and not mon.status.poisoned:
        return False
    if flt.get("confused") and mon.status.exclusive.name != "CONFUSED":
        return False
    if flt.get("any_status") and not mon.status.is_any:
        return False
    zone = flt.get("zone")
    if zone is not None and owner_index is not None:
        active = state.player(owner_index).active
        if (zone == "active") != (mon is active):
            return False
    return True


def bench_limit_override(state, card_db, player_index: int, limit: int) -> int:
    """特性によるベンチの上限の変更(ホコタテのDust Field: 相手のベンチは3匹まで/Eternal Zone: 自分のポケモンが全員あくタイプなら8匹まで)。小さいほうを優先する。"""
    shrink = None
    grow = None
    player = state.player(player_index)
    for hidx in (0, 1):
        for holder, params in cond_sources(state, card_db, hidx, "cond_bench_limit"):
            aff = params.get("affects", "own")
            if not ((aff == "own" and hidx == player_index) or (aff == "opp" and hidx != player_index)):
                continue
            if not holder_ok(state, card_db, hidx, holder, params.get("when")):
                continue
            all_type = params.get("all_type")
            if all_type and not all(all_type in _types(card_db, m) for m in player.all_pokemon_in_play()):
                continue
            new = params["limit"]
            if new < limit:
                shrink = new if shrink is None else min(shrink, new)
            elif new > limit:
                grow = new if grow is None else max(grow, new)
    if shrink is not None:
        return shrink
    return grow if grow is not None else limit


def cond_sources(state, card_db, hidx: int, kind: str) -> list:
    """hidx側の場にあるkindの効果の発生源: 特性を持つポケモン・どうぐがついているポケモン(holder=そのポケモン)。(holder, params)の一覧。"""
    out = list(team_passives(state, card_db, hidx, kind))
    if TOOL_PASSIVES:
        from engine.continuous import tools_disabled
        from engine.energy import special_energy_effects_suppressed

        tools_on = not tools_disabled(state.stadium_in_play)
        energy_on = not special_energy_effects_suppressed()
        for mon in state.player(hidx).all_pokemon_in_play():
            if tools_on:
                for k, params in TOOL_PASSIVES.get(mon.attached_tool, ()) if mon.attached_tool else ():
                    if k == kind:
                        out.append((mon, params))
            if energy_on:  # SWSH/SVの特殊エネルギーの効果(ついているポケモンが持ち主。どうぐ無効の影響は受けない)
                for energy_id in mon.attached_energy:
                    for k, params in TOOL_PASSIVES.get(energy_id, ()):
                        if k == kind:
                            out.append((mon, params))
    return out


def _stadium_sources(state, kind: str) -> list:
    if state.stadium_in_play is None:
        return []
    return [params for k, params in STADIUM_PASSIVES.get(state.stadium_in_play, ()) if k == kind]


def _holders(state, card_db, idx: int, kind: str, affects: str):
    """kindの効果のうち、idx側のポケモンに効くもの: (持ち主のプレイヤー番号, holder(スタジアムならNone), params)。"""
    out = []
    for hidx in (0, 1):
        for holder, params in cond_sources(state, card_db, hidx, kind):
            aff = params.get("affects", "own")
            if aff == "both" or (aff == "own" and hidx == idx) or (aff == "opp" and hidx != idx):
                out.append((hidx, holder, params))
    for params in _stadium_sources(state, kind):
        out.append((state.stadium_owner if state.stadium_owner is not None else 0, None, params))  # スタジアムは両者に効く(targetで絞る)
    return out


def _applies(state, card_db, idx: int, mon, hidx: int, holder, params, *, flt_key: str = "target") -> bool:
    """monへ、holderの特性(params)の効果が及ぶか(scope/target/when)。"""
    if not holder_ok(state, card_db, hidx, holder, params.get("when")):
        return False
    if params.get("scope", "team") == "self":
        return mon is holder
    return match(state, card_db, mon, params.get(flt_key), idx)


def _attacker_card_and_mon(ctx):
    mon = ctx.source_pokemon
    return mon, (ctx.card_db.get(mon.card_id) if mon is not None else None)


def _src_ok(ctx, params) -> bool:
    flt = params.get("src")
    if not flt:
        return True
    mon = ctx.source_pokemon
    if mon is None:
        return False
    return match(ctx.state, ctx.card_db, mon, flt, ctx.acting_player)


# ---------------------------------------------------------------------------------------------
# 防御側: ダメージの軽減・特定のダメージ値の無効
# ---------------------------------------------------------------------------------------------
def cond_defender_damage(ctx, defender, damage: int) -> int:
    if damage <= 0:
        return damage
    state, card_db = ctx.state, ctx.card_db
    idx = ctx.opponent
    used: set = set()
    for hidx, holder, params in _holders(state, card_db, idx, "cond_damage_taken", "own"):
        if not _applies(state, card_db, idx, defender, hidx, holder, params):
            continue
        if not _src_ok(ctx, params):
            continue
        if params.get("nostack"):
            if params["nostack"] in used:
                continue
            used.add(params["nostack"])
        if "prevent_values" in params:
            if damage in params["prevent_values"]:
                return 0
            continue
        if params.get("amount") is not None:
            damage = max(0, damage - params["amount"])
            if params.get("discard_after") and holder is defender and defender.attached_tool is not None:
                from effects.primitives import discard_attached_tool

                discard_attached_tool(state, state.player(idx), defender)  # きのみ: 軽減したらトラッシュする
    return damage


def cond_prevent_check(ctx, defender, mode: str) -> bool:
    """modeは"damage"(ダメージだけ)/"effects"(ダメージ以外の効果)/"all"(全部)。いずれかの特性が防ぐならTrue。"""
    state, card_db = ctx.state, ctx.card_db
    idx = ctx.opponent
    for hidx, holder, params in _holders(state, card_db, idx, "cond_prevent", "own"):
        if params.get("mode") != mode:
            continue
        if not _applies(state, card_db, idx, defender, hidx, holder, params):
            continue
        if _src_ok(ctx, params):
            return True
    return False


def counters_shielded(state, card_db, mon) -> bool:
    """monが、相手のワザ・特性によるダメカンのせる効果を受けないか(Daunting Pose)。"""
    idx = _locate(state, mon)
    if idx is None:
        return False
    for hidx, holder, params in _holders(state, card_db, idx, "cond_counter_shield", "own"):
        if _applies(state, card_db, idx, mon, hidx, holder, params):
            return True
    return False


# ---------------------------------------------------------------------------------------------
# 攻撃側: 追加ダメージ
# ---------------------------------------------------------------------------------------------
def cond_attacker_bonus(ctx, defender, defender_card) -> int:
    mon = ctx.source_pokemon
    if mon is None:
        return 0
    state, card_db = ctx.state, ctx.card_db
    idx = ctx.acting_player
    bonus = 0
    used: set = set()
    for hidx, holder, params in _holders(state, card_db, idx, "cond_attack_bonus", "own"):
        if not _applies(state, card_db, idx, mon, hidx, holder, params):
            continue
        sflt = params.get("src")
        if sflt and (defender is None or not match(state, card_db, defender, sflt, ctx.opponent)):
            continue
        if params.get("nostack"):
            if params["nostack"] in used:
                continue
            used.add(params["nostack"])
        amount = params["amount"]
        per = params.get("per")
        if per == "opp_in_play_subtype":
            opp = state.player(1 - hidx)
            subs = params["per_arg"]
            amount *= sum(1 for m in opp.all_pokemon_in_play() if (c := card_db.get(m.card_id)) is not None and any(s in c.subtypes for s in subs))
        elif per == "prizes_taken":
            amount *= 6 - len(state.player(hidx).prizes)
        elif per == "opp_prizes_taken":
            amount *= 6 - len(state.player(1 - hidx).prizes)
        bonus += amount
    attacker_card = card_db.get(mon.card_id)
    from effects.era_attacks_i import card_matches

    for rule in state.player(idx).attack_bonus_rules_this_turn:
        if rule["spec"] and not card_matches(attacker_card, rule["spec"]):
            continue
        bonus += rule["amount"] + rule["per_prize"] * (6 - len(state.player(1 - idx).prizes))
    return bonus


# ---------------------------------------------------------------------------------------------
# にげるコスト・弱点/抵抗力・最大HP・ワザのコスト
# ---------------------------------------------------------------------------------------------
def cond_retreat_cost(state, card_db, owner_index: int, mon) -> tuple[bool, int]:
    """(にげるコストがなくなるか, にげるコストの増減)。"""
    free = False
    delta = 0
    for hidx, holder, params in _holders(state, card_db, owner_index, "cond_retreat", "own"):
        if not _applies(state, card_db, owner_index, mon, hidx, holder, params):
            continue
        if params.get("amount") is None:
            free = True
        else:
            delta += params["amount"]
    return free, delta


def cond_weakness_override(state, card_db, owner_index: int, defender, defender_card):
    """弱点/抵抗力を消す(cond_weakness)。(弱点を消すか, 抵抗力を消すか)。"""
    no_weak = no_res = False
    for hidx, holder, params in _holders(state, card_db, owner_index, "cond_weakness", "own"):
        if not _applies(state, card_db, owner_index, defender, hidx, holder, params):
            continue
        if params.get("fx") == "resistance":
            no_res = True
        else:
            no_weak = True
    return no_weak, no_res


def cond_max_hp(state, card_db, owner_index: int, mon, hp: int) -> int:
    used: set = set()
    for hidx, holder, params in _holders(state, card_db, owner_index, "cond_hp", "own"):
        if not _applies(state, card_db, owner_index, mon, hidx, holder, params):
            continue
        if params.get("nostack"):
            if params["nostack"] in used:
                continue
            used.add(params["nostack"])
        if "set" in params:
            hp = params["set"]
        else:
            hp += params["amount"]
    return hp


def cond_attack_cost(state, card_db, owner_index: int, out: list, mon) -> list:
    """ワザのコストの増減。remove_colorless=N(無色をN個まで減らす)/add_colorless=N/all=True(コストを全て無視する)。"""
    if mon is None:
        return out
    used: set = set()
    for hidx, holder, params in _holders(state, card_db, owner_index, "cond_cost", "own"):
        if not _applies(state, card_db, owner_index, mon, hidx, holder, params):
            continue
        if params.get("nostack"):
            if params["nostack"] in used:
                continue
            used.add(params["nostack"])
        if params.get("all"):
            return []
        out = list(out)
        if params.get("remove_all_colorless"):
            out = [t for t in out if t != "Colorless"]
        amount = params.get("remove_colorless", 0)
        per = params.get("per")
        if per == "opp_in_play_subtype":
            subs = params["per_arg"]
            amount *= sum(
                1 for m in state.player(1 - hidx).all_pokemon_in_play()
                if (c := card_db.get(m.card_id)) is not None and any(s in c.subtypes for s in subs)
            )
        elif per == "own_discard_name_part":
            amount *= sum(1 for cid in state.player(hidx).discard if (c := card_db.get(cid)) is not None and params["per_arg"] in c.name)
        elif per == "opp_prizes_taken":
            amount *= 6 - len(state.player(1 - hidx).prizes)
        for _ in range(amount):
            if "Colorless" in out:
                out.remove("Colorless")
        out += ["Colorless"] * params.get("add_colorless", 0)
        for _ in range(params.get("remove_any", 0)):
            if out:
                out.remove("Colorless" if "Colorless" in out else out[-1])  # どのタイプのエネルギーでもよい: 無色を優先して1個減らす
        for t in params.get("remove_types", ()):
            if t in out:
                out.remove(t)
    return out


# ---------------------------------------------------------------------------------------------
# 特殊状態
# ---------------------------------------------------------------------------------------------
def cond_status_blocked(state, card_db, owner_index: int, mon) -> set:
    out: set = set()
    for hidx, holder, params in _holders(state, card_db, owner_index, "cond_status_immune", "own"):
        if not _applies(state, card_db, owner_index, mon, hidx, holder, params):
            continue
        sts = params["statuses"]
        if sts == "all":
            out.update({"poisoned", "burned", "asleep", "confused", "paralyzed"})
        else:
            out.update(sts)
    return out


# ---------------------------------------------------------------------------------------------
# 特性を持たなくなる/トレーナーズ等のロック/番の間
# ---------------------------------------------------------------------------------------------
def cond_ability_locked(state, card_db, card, mon, owner_index: int) -> bool:
    """monの特性を封じる特性があるか(Freezing Gaze/Lazy/Sol Shade/Power of Alchemy/Shady Tail)。ability_suppressed内から呼ばれる。"""
    from effects.generated_abilities import GENERATED_PASSIVES
    from engine.continuous import ability_suppressed

    for params in _stadium_sources(state, "cond_ability_lock"):
        aff = params.get("affects", "both")
        if (
            (aff == "both" or (aff == "own" and False) or aff == "opp")
            and not (params.get("except_subtype") and any(s in card.subtypes for s in params["except_subtype"]))
            and match(state, card_db, mon, params.get("target"), owner_index)
        ):
            return True  # スタジアム(Path to the Peak等)
    for hidx in (0, 1):
        for holder in state.player(hidx).all_pokemon_in_play():
            entries = GENERATED_PASSIVES.get(holder.card_id)
            if not entries:
                continue
            for aname, kind, params in entries:
                if kind != "cond_ability_lock":
                    continue
                aff = params.get("affects", "own")
                if not (aff == "both" or (aff == "own" and hidx == owner_index) or (aff == "opp" and hidx != owner_index)):
                    continue
                if mon is holder and not params.get("incl_self"):
                    continue
                if params.get("except_ability") and any(a.name == params["except_ability"] for a in card.abilities):
                    continue
                if params.get("except_subtype") and any(s in card.subtypes for s in params["except_subtype"]):
                    continue
                if not match(state, card_db, mon, params.get("target"), owner_index):
                    continue
                if ability_suppressed(state, card_db, hidx, holder, _holder_check=True):
                    continue
                if not holder_ok(state, card_db, hidx, holder, params.get("when")):
                    continue
                return True
    return False


def hand_card_ability_locked(state, card_db, card, player_index: int) -> bool:
    """手札・トラッシュにあるポケモンの特性(Freezing Gaze: 手札・トラッシュのGX/EXも特性を持たない)用。持ち主側から見たcardの封印。"""
    from effects.generated_abilities import GENERATED_PASSIVES

    for hidx in (0, 1):
        for holder in state.player(hidx).all_pokemon_in_play():
            for _aname, kind, params in GENERATED_PASSIVES.get(holder.card_id, ()):
                if kind != "cond_ability_lock" or not params.get("zones_all"):
                    continue
                aff = params.get("affects", "own")
                if not (aff == "both" or (aff == "own" and hidx == player_index) or (aff == "opp" and hidx != player_index)):
                    continue
                if params.get("except_subtype") and any(s in card.subtypes for s in params["except_subtype"]):
                    continue
                tflt = params.get("target") or {}
                if "subtype" in tflt and not any(s in card.subtypes for s in tflt["subtype"]):
                    continue
                if tflt.get("basic") and not card.is_basic:
                    continue
                if holder_ok(state, card_db, hidx, holder, params.get("when")):
                    return True
    return False


def cond_locked(state, card_db, player_index: int, what: str) -> bool:
    """player_indexの(相手の特性による)ロック: what=item/tool/special_energy/stadium/supporter/ability_pokemon。"""
    for holder, params in cond_sources(state, card_db, 1 - player_index, "cond_lock"):
        if what in params.get("what", ()) and holder_ok(state, card_db, 1 - player_index, holder, params.get("when")):
            return True
    return False


def cond_checkup_counters(state, card_db) -> None:
    """ポケモンチェックでのダメカン追加(More Poison/Panic Spores/Perilous Jungle)。bothなら両者の場のポケモン、そうでなければ持ち主の相手の場のポケモンが対象。"""
    from effects.primitives import _blocks_damage_counters

    sources = [(hidx, holder, params) for hidx in (0, 1) for holder, params in cond_sources(state, card_db, hidx, "cond_between_turns")]
    sources += [(0, None, params) for params in _stadium_sources(state, "cond_between_turns")]
    for hidx, holder, params in sources:
        if not holder_ok(state, card_db, hidx, holder, params.get("when")):
            continue
        sides = (0, 1) if params.get("both") else (1 - hidx,)
        for side in sides:
            for t in state.player(side).all_pokemon_in_play():
                if params.get("poisoned") and not t.status.poisoned:
                    continue
                if params.get("confused") and t.status.exclusive.name != "CONFUSED":
                    continue
                if not match(state, card_db, t, params.get("target"), side):
                    continue
                if _blocks_damage_counters(t) or counters_shielded(state, card_db, t):
                    continue
                t.damage += params["counters"] * 10


_ = active_passives
