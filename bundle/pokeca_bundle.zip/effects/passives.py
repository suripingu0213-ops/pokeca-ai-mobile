"""パッシブ(常時発動)特性の宣言的な実装基盤(2026-10-06〜、BW〜XY世代の取り込み)。

カードごとにエンジン側のIDテーブルへ手で登録していく従来の方法だと、同じ特性を持つ再録カードや大量の新カードに
追随できないため、scripts/generate_abilities.py が英語原文から(特性名, 種別, パラメータ)を生成し
(effects/generated_abilities.py: GENERATED_PASSIVES)、このモジュールの関数がエンジンの各フック地点(ダメージ計算・
ポケモンチェック・にげるコスト・弱点抵抗力・HP・ワザのコスト・各種ロック)から呼ばれて効果を適用する。

「特性が封じられている間は働かない」判定(engine.continuous.ability_suppressed)は、ここで一括して行う
(active_passives/team_passives/global_passives はいずれも、封じられているポケモンの特性を含めない)。
"""

from __future__ import annotations

import os

try:  # 生成物が無い(初回生成前/生成中)でも動くようにする
    if os.environ.get("POKECA_IGNORE_GENERATED_ABILITIES"):
        raise ImportError
    from effects.generated_abilities import GENERATED_PASSIVES
except ImportError:  # pragma: no cover
    GENERATED_PASSIVES: dict[str, tuple] = {}


# エンジン側のフックが実装済みの種別(scripts/generate_abilities.pyはこの種別のパッシブだけを生成する。フックを足したらここに追加する)
SUPPORTED_PASSIVE_KINDS = frozenset({
    "cond_damage_taken", "cond_prevent", "cond_attack_bonus", "cond_retreat", "cond_weakness", "cond_hp", "cond_cost",
    "cond_status_immune", "cond_ability_lock", "cond_lock", "cond_between_turns", "cond_counter_shield",  # effects/passives_cond.py
    "ko_fewer_prize_if_named_in_play", "cond_bench_limit", "cond_attach_counters",
    "damage_reduction", "damage_reduction_if_energy", "coin_prevent", "coin_reduce", "survive_full_hp", "survive_coin",
    "immune_from_basic_attackers", "immune_from_attackers_with_ability", "team_immune_vs_subtype", "team_damage_reduction",
    "bench_damage_immune", "retaliate_counters", "retaliate_status", "retaliate_discard_random_hand",
    "team_attack_bonus", "self_attack_bonus_vs_type", "self_attack_bonus_if_status", "ignore_weakness_resistance",
    "ignore_defender_effects", "team_ignore_resistance",
    "immune_from_attackers_with_subtype", "immune_from_attackers_with_special_energy", "ability_effect_immune",
    "team_attack_effect_immune_if_energy", "team_active_type_retaliate_counters", "self_attack_bonus_if_hand_equal",
    "between_turns_heal", "between_turns_counters_opponent", "burn_counters", "sleep_flip_count",
    "team_no_weakness", "self_no_weakness_if_energy", "weakness_x4_all", "team_resistance_override",
    "opp_dragon_weakness_psychic", "status_immune_self", "team_status_immune_if_energy",
    "lock_opponent_items_while_active", "lock_opponent_items_and_tools_while_active", "lock_opponent_supporters_while_active",
    "lock_opponent_special_energy_attach_while_active", "ace_spec_lock", "two_supporters", "no_evolve_for_both",
    "evolve_on_play_turn", "break_no_abilities", "no_retreat_cost", "team_no_retreat_if_energy", "opp_active_retreat_increase",
    "opp_retreat_increase", "team_retreat_reduction", "opp_poisoned_cant_retreat", "opp_active_cant_retreat_while_active",
    "attack_cost_reduction_per_opp_subtype", "ignore_colorless_cost_if_hand_count", "team_ignore_colorless_cost_for_names",
    "opp_basic_attack_cost_increase", "team_hp_bonus", "self_hp_per_bench", "self_hp_per_energy",
    "ko_retaliate_counters", "ko_retaliate_status", "ko_coin_retaliate_counters", "ko_discard_opp_deck", "bonus_prize_on_ko",
    "ko_no_prize", "ko_no_prize_vs_subtype", "team_ko_prize_reduction_vs_subtype", "cant_attack_if_own_prizes_in",
    "cant_attack_if_opp_active_basic", "cant_attack_if_few_pokemon", "attack_on_first_turn", "on_self_attach_heal",
    "team_on_attach_heal_while_active", "opp_attach_counters_while_active", "opp_coins_tails_while_active",
    "opp_active_damage_reduction", "self_attack_effect_immune", "bench_attack_immune_full", "retaliate_counters_per_energy",
    "retaliate_discard_energy", "retaliate_equal_damage_vs_subtype", "self_hp_if_special_energy",
    "self_attack_bonus_if_mega_ex", "self_attack_bonus_per_opp_prize_taken", "garbotoxin",
    "energy_is_type", "team_energy_double", "types_are", "type_same_as_opp_active", "borrow_attacks",
    "team_borrow_previous_evolutions",
    # passives_ext.py(2026-10-07)
    "immune_damage_from_attackers_with_subtype", "immune_damage_from_attackers_with_special_energy",
    "immune_damage_from_poisoned_attackers", "team_damage_immune_vs_low_energy", "immune_from_evolution_attackers",
    "immune_from_attackers_with_name_part", "team_bench_attack_immune_full", "team_attack_effect_immune_while_active",
    "damage_reduction_conditional", "damage_reduction_per_opp_retreat", "self_attack_bonus_if_low_hp",
    "team_ignore_defender_effects", "bench_active_retreat_reduction", "team_retreat_reduction_if_stadium",
    "self_retreat_reduction_per_bench_name", "global_retreat_increase_except_subtype", "no_retreat_if_stadium",
    "team_attack_cost_remove_type", "self_hp_set_if_energy", "global_tools_disabled", "global_tools_disabled_while_active",
    "global_tool_attach_lock", "global_stadium_play_lock", "opp_special_energy_attach_lock_if_stadium",
    "global_ability_lock_except_type", "ko_coin_knockout_attacker",
    "ko_return_to_hand", "team_ko_energy_to_hand", "ko_followup_search_any", "ko_move_energy_to_bench", "global_counter_move_lock",
    "team_add_type_to_stage", "cant_attack_if_few_subtype", "ignore_cost_if_hand_equal_for_attack",
    "opp_cant_play_ability_pokemon_while_active", "opp_bench_move_counters", "opp_bench_move_confuse_new_active",
    "opp_retreat_coin_fail", "self_card_effect_shield", "opp_evolve_counters",
})


def _mirror_item_pokemon_passives() -> None:
    """化石グッズ(Antique〜Fossil)が場でポケモンとして扱われるときの合成カードID(<ID>-mon)にも、特性(パッシブ)を結びつける。"""
    from cards.card_db import ANTIQUE_FOSSIL_ITEM_IDS

    for item_id in ANTIQUE_FOSSIL_ITEM_IDS:
        if item_id in GENERATED_PASSIVES:
            GENERATED_PASSIVES[item_id + "-mon"] = GENERATED_PASSIVES[item_id]


_mirror_item_pokemon_passives()


def passives_of(card_id: str) -> tuple:
    """カードIDが持つパッシブ特性: ((特性名, 種別, パラメータdict), ...)。"""
    return GENERATED_PASSIVES.get(card_id, ())


def ids_with_kind(kind: str) -> dict[str, dict]:
    """指定した種別のパッシブ特性を持つカードID → パラメータ。既存のIDテーブルへの取り込み用。"""
    out: dict[str, dict] = {}
    for card_id, entries in GENERATED_PASSIVES.items():
        for _name, k, params in entries:
            if k == kind:
                out[card_id] = params
    return out


def active_passives(state, card_db, owner_index: int, mon, kind: str | None = None) -> list[tuple[str, dict]]:
    """monが今持っているパッシブ特性(特性が封じられていなければ)の(種別, パラメータ)一覧。kind指定で絞り込む。"""
    entries = GENERATED_PASSIVES.get(mon.card_id)
    if not entries:
        return []
    if kind is not None and not any(k == kind for _n, k, _p in entries):
        return []
    from engine.continuous import ability_suppressed

    if ability_suppressed(state, card_db, owner_index, mon):
        return []
    return [(k, p) for _n, k, p in entries if kind is None or k == kind]


def team_passives(state, card_db, owner_index: int, kind: str) -> list[tuple[object, dict]]:
    """owner_indexのプレイヤーの場にいる、指定種別のパッシブ特性を持つポケモンとそのパラメータ(特性が封じられているものは除く)。"""
    out = []
    for mon in state.player(owner_index).all_pokemon_in_play():
        for _k, params in active_passives(state, card_db, owner_index, mon, kind):
            out.append((mon, params))
    return out


def global_passives(state, card_db, kind: str) -> list[tuple[int, object, dict]]:
    """両プレイヤーの場にいる、指定種別のパッシブ特性を持つポケモン(owner_index, mon, params)。"""
    out = []
    for idx in (0, 1):
        for mon, params in team_passives(state, card_db, idx, kind):
            out.append((idx, mon, params))
    return out


def _types(card_db, mon) -> tuple:
    from engine.energy import current_state

    state = current_state()
    if state is not None:
        owner_index = _locate(state, mon)
        if owner_index is not None:
            return mon_types(state, card_db, owner_index, mon)
    card = card_db.get(mon.card_id)
    if card is None:
        return ()
    if mon.type_override:
        return (mon.type_override,)
    return tuple(card.types)


# ---------------------------------------------------------------------------------------------
# ダメージ計算: 防御側
# ---------------------------------------------------------------------------------------------
def attacker_has_ability(attacker_card) -> bool:
    return bool(attacker_card is not None and attacker_card.abilities)


def defender_is_immune(ctx, defender, attacker_card) -> bool:
    """防御側(defender)が、このワザのダメージ(と効果)を完全に受けないパッシブ特性を持つか(Bright Down/Intimidating Mane/Plasma Steel)。"""
    state, card_db = ctx.state, ctx.card_db
    owner_index = ctx.opponent
    if attacker_card is None:
        return False
    from effects.era_trainers import era_silver_mirror_blocks

    if era_silver_mirror_blocks(ctx, defender):
        return True  # シルバーミラー
    attacker_mon = ctx.source_pokemon
    owner_player = state.player(owner_index)
    for kind, params in active_passives(state, card_db, owner_index, defender):
        if kind == "bench_attack_immune_full" and defender is not owner_player.active:
            return True
        if kind == "immune_from_basic_attackers" and attacker_card.is_basic:
            return True
        if kind == "immune_from_attackers_with_ability" and attacker_has_ability(attacker_card):
            return True
        if kind == "immune_from_attackers_with_subtype" and params["subtype"] in attacker_card.subtypes:
            return True
        if kind == "immune_from_attackers_with_special_energy" and attacker_mon is not None and any(
            (e := card_db.get(eid)) is not None and e.is_special_energy for eid in attacker_mon.attached_energy
        ):
            return True
    defender_card = card_db.get(defender.card_id)
    if defender_card is not None:
        for _mon, params in team_passives(state, card_db, owner_index, "team_immune_vs_subtype"):
            if params.get("defender_type") in defender_card.types and params.get("attacker_subtype") in attacker_card.subtypes:
                return True
    from effects.passives_ext import ext_damage_immune, ext_full_immune

    return ext_full_immune(ctx, defender, attacker_card) or ext_damage_immune(ctx, defender, attacker_card)


def attack_effects_immune(ctx, defender) -> bool:
    """防御側が、このワザの(ダメージ以外の)効果を受けないパッシブ特性を持つか(Bright Down/Safeguard/Mighty Shell/Solar Revelation)。"""
    from effects.era_trainers import era_silver_mirror_blocks, era_tool_blocks_attack_effects

    if ctx.source_pokemon is not None and (era_silver_mirror_blocks(ctx, defender) or era_tool_blocks_attack_effects(ctx, defender)):
        return True  # シルバーミラー/ベントスプーン
    if not GENERATED_PASSIVES or ctx.source_pokemon is None:
        return False
    state, card_db = ctx.state, ctx.card_db
    attacker_card = card_db.get(ctx.source_pokemon.card_id)
    if attacker_card is None:
        return False
    for kind, params in active_passives(state, card_db, ctx.opponent, defender):
        if kind == "immune_from_attackers_with_ability" and attacker_has_ability(attacker_card):
            return True
        if kind == "immune_from_attackers_with_subtype" and params["subtype"] in attacker_card.subtypes:
            return True
        if kind == "immune_from_attackers_with_special_energy" and any(
            (e := card_db.get(eid)) is not None and e.is_special_energy for eid in ctx.source_pokemon.attached_energy
        ):
            return True
    if defender.attached_energy and team_passives(state, card_db, ctx.opponent, "team_attack_effect_immune_if_energy"):
        return True
    owner = state.player(ctx.opponent)
    for kind, _params in active_passives(state, card_db, ctx.opponent, defender):
        if kind == "self_attack_effect_immune":
            return True  # Emperor's Stance/Anticipation: ワザの効果(ダメージを除く)を受けない
        if kind == "bench_attack_immune_full" and defender is not owner.active:
            return True  # So Submerged
    from effects.passives_ext import ext_effects_immune, ext_full_immune

    return ext_full_immune(ctx, defender, attacker_card) or ext_effects_immune(ctx, defender)


def apply_defender_passives(ctx, defender, defender_card, attacker_card, damage: int) -> int:
    """ワザのダメージ(弱点・抵抗力の後)に、防御側のパッシブ特性による軽減/無効化を適用する。"""
    if damage <= 0:
        return damage
    state, card_db = ctx.state, ctx.card_db
    owner_index = ctx.opponent
    owner = state.player(owner_index)
    attacker_types = _types(card_db, ctx.source_pokemon) if ctx.source_pokemon is not None else ()
    for kind, params in active_passives(state, card_db, owner_index, defender):
        if kind == "damage_reduction":
            needed = params.get("attacker_types")
            if needed and not (set(needed) & set(attacker_types)):
                continue
            damage = max(0, damage - params["amount"])
        elif kind == "damage_reduction_if_energy":
            if defender.attached_energy:
                damage = max(0, damage - params["amount"])
        elif kind == "coin_prevent":
            if ctx.rng.random() < 0.5:
                ctx.log(f"{defender.card_id} はコインがオモテでダメージを防いだ")
                return 0
        elif kind == "coin_reduce":
            if ctx.rng.random() < 0.5:
                ctx.log(f"{defender.card_id} はコインがオモテでダメージを{params['amount']}軽減した")
                damage = max(0, damage - params["amount"])
        elif kind == "bench_damage_immune":
            if defender is not owner.active:
                return 0
    from effects.passives_ext import ext_defender_damage

    damage = ext_defender_damage(ctx, defender, defender_card, attacker_card, damage)
    attacker_turns = state.player(ctx.acting_player).turns_taken
    for entry in owner.damage_reductions:
        if attacker_turns > entry["until"]:
            continue
        if entry["type"] is not None and entry["type"] not in defender_card.types:
            continue
        if entry["subtype"] is not None and entry["subtype"] not in defender_card.subtypes:
            continue
        if entry.get("attacker_subtype") and (attacker_card is None or entry["attacker_subtype"] not in attacker_card.subtypes):
            continue  # 相手の特定のサブタイプ(ポケモンV等)のワザだけ軽減(ファイナ)
        damage = 0 if entry["amount"] is None else max(0, damage - entry["amount"])  # Iron Defender/Lusamine
    used_keys: set = set()
    for _mon, params in team_passives(state, card_db, owner_index, "team_damage_reduction"):
        if params.get("holder_active_only") and _mon is not owner.active:
            continue
        if params.get("no_stack_key"):
            if params["no_stack_key"] in used_keys:
                continue  # 「この特性の効果は重ならない」
            used_keys.add(params["no_stack_key"])
        if params.get("defender_type") and params["defender_type"] not in defender_card.types:
            continue
        energy_type = params.get("energy_type")
        if energy_type and not any(
            (e := card_db.get(eid)) is not None and e.basic_energy_type == energy_type for eid in defender.attached_energy
        ):
            continue
        damage = max(0, damage - params["amount"])
    return damage


# ---------------------------------------------------------------------------------------------
# ダメージ計算: 攻撃側
# ---------------------------------------------------------------------------------------------
def attacker_passive_bonus(ctx, defender, defender_card, attacker_card) -> int:
    """相手のバトルポケモンへのワザのダメージ(弱点・抵抗力の前)に加わる、攻撃側のパッシブ特性による追加ダメージ。"""
    state, card_db = ctx.state, ctx.card_db
    mon = ctx.source_pokemon
    if mon is None:
        return 0
    bonus = 0
    attacker_types = _types(card_db, mon)
    used_keys: set = set()
    for _holder, params in team_passives(state, card_db, ctx.acting_player, "team_attack_bonus"):
        needed = params.get("attacker_type")
        if needed and needed not in attacker_types:
            continue
        if params.get("attacker_subtype") and (attacker_card is None or params["attacker_subtype"] not in attacker_card.subtypes):
            continue
        if params.get("attacker_basic") and (attacker_card is None or not attacker_card.is_basic):
            continue
        if params.get("attacker_name") and (attacker_card is None or attacker_card.name != params["attacker_name"]):
            continue
        if params.get("attacker_name_prefix") and (attacker_card is None or not attacker_card.name.startswith(params["attacker_name_prefix"])):
            continue
        if params.get("exclude_name") and attacker_card is not None and attacker_card.name == params["exclude_name"]:
            continue
        if params.get("no_stack_key"):
            if params["no_stack_key"] in used_keys:
                continue  # 「この特性の効果は重ならない」
            used_keys.add(params["no_stack_key"])
        bonus += params["amount"]
    for bonus_type, bonus_amount, bonus_basic_only in state.player(ctx.acting_player).attack_bonuses_this_turn:
        # Steam Up等: この番の間、指定タイプ(のたね)ポケモンのワザのダメージが増える
        if bonus_type == "NoRuleBox":
            from effects.primitives import _RULE_BOX_SUBTYPES

            if attacker_card is not None and not (_RULE_BOX_SUBTYPES & set(attacker_card.subtypes)):
                bonus += bonus_amount  # Gladion's Final Battle: ルールを持たないポケモンのワザ
        elif bonus_type in attacker_types and (not bonus_basic_only or (attacker_card is not None and attacker_card.is_basic)):
            bonus += bonus_amount
    for kind, params in active_passives(state, card_db, ctx.acting_player, mon):
        if kind == "self_attack_bonus_vs_type":
            if defender_card is not None and params["defender_type"] in defender_card.types:
                bonus += params["amount"]
        elif kind == "self_attack_bonus_if_status":
            if mon.status.is_any:
                bonus += params["amount"]
        elif kind == "self_attack_bonus_if_mega_ex":
            owner_p = state.player(ctx.acting_player)
            if any(
                (c := card_db.get(m.card_id)) is not None and "MEGA" in c.subtypes and params["type"] in c.types
                for m in owner_p.all_pokemon_in_play()
            ):
                bonus += params["amount"]
        elif kind == "self_attack_bonus_per_opp_prize_taken":
            bonus += params["amount"] * (6 - len(state.player(ctx.opponent).prizes))
        elif kind == "self_attack_bonus_if_hand_equal":
            if len(state.player(ctx.acting_player).hand) == len(state.player(ctx.opponent).hand):
                bonus += params["amount"]
    from effects.passives_ext import ext_attacker_bonus

    return bonus + ext_attacker_bonus(ctx, defender, defender_card, attacker_card)


def attacker_passive_flags(ctx) -> dict:
    """攻撃側のパッシブ特性による「弱点/抵抗力/防御側の効果を無視する」フラグ。"""
    mon = ctx.source_pokemon
    flags = {"ignore_weakness": False, "ignore_resistance": False, "ignore_defender_effects": False}
    if mon is None:
        return flags
    state, card_db = ctx.state, ctx.card_db
    for kind, _params in active_passives(state, card_db, ctx.acting_player, mon):
        if kind == "ignore_weakness_resistance":
            flags["ignore_weakness"] = flags["ignore_resistance"] = True
        elif kind == "ignore_defender_effects":
            flags["ignore_defender_effects"] = True
    attacker_types = _types(card_db, mon)
    for _holder, params in team_passives(state, card_db, ctx.acting_player, "team_ignore_resistance"):
        if params.get("attacker_type") in attacker_types:
            flags["ignore_resistance"] = True
    from effects.passives_ext import ext_ignore_defender_effects

    if ext_ignore_defender_effects(ctx):
        flags["ignore_defender_effects"] = True
    return flags


# ---------------------------------------------------------------------------------------------
# バトル場でワザのダメージを受けたときの反撃
# ---------------------------------------------------------------------------------------------
def retaliation_on_damaged(ctx, defender, dmg: int) -> None:
    """「バトル場にいて相手のワザのダメージを受けたら(きぜつしても)」系の特性(Rough Skin/Poison Point/Lamentation等)。"""
    if dmg <= 0 or ctx.source_pokemon is None:
        return
    state, card_db = ctx.state, ctx.card_db
    owner_index = ctx.opponent
    owner = state.player(owner_index)
    if defender is not owner.active:
        return
    from effects.primitives import _apply_condition, _blocks_damage_counters

    defender_card = card_db.get(defender.card_id)
    for _holder, params in team_passives(state, card_db, owner_index, "team_active_type_retaliate_counters"):
        if defender_card is not None and params["defender_type"] in defender_card.types and not _blocks_damage_counters(ctx.source_pokemon):
            ctx.source_pokemon.damage += params["counters"] * 10
            ctx.log(f"{defender.card_id} が受けたダメージで、特性により攻撃したポケモンにダメカンを{params['counters']}個のせた")
    for kind, params in active_passives(state, card_db, owner_index, defender):
        if kind == "retaliate_counters":
            if not _blocks_damage_counters(ctx.source_pokemon):
                ctx.source_pokemon.damage += params["counters"] * 10
                ctx.log(f"{defender.card_id} の特性で、攻撃したポケモンにダメカンを{params['counters']}個のせた")
        elif kind == "retaliate_status":
            for status in params["statuses"]:
                _apply_condition(ctx.source_pokemon, status)
            ctx.log(f"{defender.card_id} の特性で、攻撃したポケモンが{'・'.join(params['statuses'])}になった")
        elif kind == "retaliate_counters_per_energy":
            n = sum(1 for e in defender.attached_energy if (c := card_db.get(e)) is not None and c.basic_energy_type == params["energy_type"])
            if n and not _blocks_damage_counters(ctx.source_pokemon):
                ctx.source_pokemon.damage += params["counters"] * n * 10
                ctx.log(f"{defender.card_id} の特性で、攻撃したポケモンにダメカンを{params['counters'] * n}個のせた")
        elif kind == "retaliate_discard_energy":
            for _ in range(params["count"]):
                if ctx.source_pokemon.attached_energy:
                    state.player(ctx.acting_player).discard.append(ctx.source_pokemon.attached_energy.pop(0))
        elif kind == "retaliate_equal_damage_vs_subtype":
            attacker_card = card_db.get(ctx.source_pokemon.card_id)
            if attacker_card is not None and set(params["subtypes"]) & set(attacker_card.subtypes) and not _blocks_damage_counters(ctx.source_pokemon):
                ctx.source_pokemon.damage += (dmg // 10) * 10
                ctx.log(f"{defender.card_id} の特性で、受けたダメージと同じ数のダメカンを攻撃したポケモンにのせた")
        elif kind == "retaliate_discard_random_hand":
            attacker_owner = state.player(ctx.acting_player)
            if attacker_owner.hand:
                card_id = attacker_owner.hand.pop(ctx.rng.randrange(len(attacker_owner.hand)))
                attacker_owner.discard.append(card_id)
                ctx.log(f"{defender.card_id} の特性で、相手の手札からランダムに1枚トラッシュした")


# ---------------------------------------------------------------------------------------------
# にげるコスト・ワザのコスト・最大HP(engine.energy / engine.continuous から、バインド中のstateを使って呼ばれる)
# ---------------------------------------------------------------------------------------------
def _locate(state, mon):
    """monが場にいるプレイヤーの番号(同一オブジェクト判定)。いなければNone。"""
    for idx in (0, 1):
        for m in state.player(idx).all_pokemon_in_play():
            if m is mon:
                return idx
    return None


def _has_energy(card_db, mon, energy_type: str) -> bool:
    return any((e := card_db.get(eid)) is not None and e.basic_energy_type == energy_type for eid in mon.attached_energy)


def adjust_retreat_cost(card_db, mon, cost: int) -> int:
    """にげるコスト(無色の個数)にパッシブ特性の効果を反映する。"""
    from engine.energy import current_state

    state = current_state()
    if state is None or not GENERATED_PASSIVES:
        return cost
    owner_index = _locate(state, mon)
    if owner_index is None:
        return cost
    card = card_db.get(mon.card_id)
    delta = 0
    for kind, params in active_passives(state, card_db, owner_index, mon):
        if kind == "no_retreat_cost":
            cond = params["if_energy"]
            if (cond == "any" and mon.attached_energy) or (cond == "none" and not mon.attached_energy) or (
                cond not in ("any", "none") and _has_energy(card_db, mon, cond)
            ):
                return 0
    from effects.passives_ext import ext_no_retreat, ext_retreat_delta

    if ext_no_retreat(state, card_db, owner_index, mon):
        return 0
    for _holder, params in team_passives(state, card_db, owner_index, "team_no_retreat_if_energy"):
        if _has_energy(card_db, mon, params["energy_type"]):
            return 0
    for _holder, params in team_passives(state, card_db, owner_index, "team_retreat_reduction"):
        if card is not None and params["subtype"] in card.subtypes:
            delta -= params["amount"]
    delta += ext_retreat_delta(state, card_db, owner_index, mon, card)
    opponent_index = 1 - owner_index
    for _holder, params in team_passives(state, card_db, opponent_index, "opp_retreat_increase"):
        delta += params["amount"]
    if mon is state.player(owner_index).active:
        for _holder, params in team_passives(state, card_db, opponent_index, "opp_active_retreat_increase"):
            delta += params["amount"]
    return max(0, cost + delta)


def retreat_blocked(state, card_db, owner_index: int, mon) -> bool:
    """パッシブ特性により、monがにげられないか(Poison Barrier/Block)。"""
    if not GENERATED_PASSIVES:
        return False
    opponent_index = 1 - owner_index
    if mon.status.poisoned and team_passives(state, card_db, opponent_index, "opp_poisoned_cant_retreat"):
        return True
    if mon is state.player(owner_index).active:
        opponent_active = state.player(opponent_index).active
        if opponent_active is not None and active_passives(
            state, card_db, opponent_index, opponent_active, "opp_active_cant_retreat_while_active"
        ):
            return True
    return False


def adjust_attack_cost(card_db, mon, cost: tuple, attack_name: str | None = None) -> tuple:
    """ワザのコストにパッシブ特性の効果を反映する(Drifting Balloon/Sonic Vision/Sniper's Eye/King's Song/Nervous Seed)。"""
    from engine.energy import current_state

    state = current_state()
    if state is None or not GENERATED_PASSIVES:
        return cost
    owner_index = _locate(state, mon)
    if owner_index is None:
        return cost
    card = card_db.get(mon.card_id)
    owner = state.player(owner_index)
    opponent = state.player(1 - owner_index)
    out = list(cost)
    for kind, params in active_passives(state, card_db, owner_index, mon):
        if kind == "attack_cost_reduction_per_opp_subtype":
            n = sum(
                1 for m in opponent.all_pokemon_in_play()
                if (c := card_db.get(m.card_id)) is not None and params["subtype"] in c.subtypes
            )
            for _ in range(min(n * params.get("amount_per", 1), out.count("Colorless"))):
                out.remove("Colorless")
        elif kind == "ignore_cost_if_hand_equal_for_attack":
            if attack_name == params["attack"] and len(owner.hand) == len(opponent.hand):
                out = []  # Tuning Echo
        elif kind == "ignore_colorless_cost_if_hand_count":
            hand = owner.hand if params["hand_owner"] == "self" else opponent.hand
            if len(hand) == params["count"]:
                out = [] if params.get("all_energy") else [t for t in out if t != "Colorless"]
    for _holder, params in team_passives(state, card_db, owner_index, "team_ignore_colorless_cost_for_names"):
        if card is not None and card.name in params["names"]:
            out = [t for t in out if t != "Colorless"]
    from effects.passives_ext import ext_attack_cost

    out = ext_attack_cost(state, card_db, owner_index, out, mon)
    if card is not None and card.is_basic:
        for holder, params in team_passives(state, card_db, 1 - owner_index, "opp_basic_attack_cost_increase"):
            if params.get("active_only") and state.player(1 - owner_index).active is not holder:
                continue
            names = params.get("requires_names")
            if names and not all(
                any((c := card_db.get(m.card_id)) is not None and c.name == n for m in state.player(1 - owner_index).all_pokemon_in_play())
                for n in names
            ):
                continue  # Downer Material: 持ち主の場に指定の名前のポケモンがそろっているとき
            out.extend(["Colorless"] * params["amount"])
    return tuple(out)


def adjust_max_hp(card_db, card_id: str, attached_energy, hp: int) -> int:
    """最大HPにパッシブ特性の効果を反映する(Dark Shade/Flower Veil/Craftsmanship/Benevolent Boss)。"""
    from engine.energy import current_state

    state = current_state()
    if state is None or not GENERATED_PASSIVES or attached_energy is None or hp <= 0:
        return hp
    mon = owner_index = None
    for idx in (0, 1):
        for m in state.player(idx).all_pokemon_in_play():
            if m.attached_energy is attached_energy:
                mon, owner_index = m, idx
    if mon is None:
        return hp
    card = card_db.get(card_id)
    owner = state.player(owner_index)
    for kind, params in active_passives(state, card_db, owner_index, mon):
        if kind == "self_hp_per_energy":
            n = sum(1 for e in mon.attached_energy if (c := card_db.get(e)) is not None and c.basic_energy_type == params["energy_type"])
            hp += params["amount"] * n
        elif kind == "self_hp_per_bench":
            if mon is owner.active:
                hp += params["amount"] * len(owner.bench)
        elif kind == "self_hp_if_special_energy":
            if any((c := card_db.get(e)) is not None and c.is_special_energy for e in mon.attached_energy):
                hp += params["amount"]
    from effects.passives_ext import ext_max_hp

    hp = ext_max_hp(state, card_db, owner_index, mon, hp)
    used_hp_keys: set = set()
    if card is not None:
        for _holder, params in team_passives(state, card_db, owner_index, "team_hp_bonus"):
            if params.get("no_stack_key"):
                if params["no_stack_key"] in used_hp_keys:
                    continue
                used_hp_keys.add(params["no_stack_key"])
            if params.get("subtype") and params["subtype"] not in card.subtypes:
                continue
            if params.get("type") and params["type"] not in card.types:
                continue
            hp += params["amount"]
    return hp


# ---------------------------------------------------------------------------------------------
# ポケモンチェック(番の間)
# ---------------------------------------------------------------------------------------------
def checkup_burn_extra_damage(state, card_db, owner_index: int) -> int:
    """owner_indexのバトルポケモンがやけどのとき、相手のパッシブ特性(Scorching Scales)で増える、ポケモンチェックのやけどダメージ(HP単位)。"""
    if not GENERATED_PASSIVES:
        return 0
    extra = 0
    for _holder, params in team_passives(state, card_db, 1 - owner_index, "burn_counters"):
        extra = max(extra, params["counters"] * 10 - 20)
    return extra


def prepare_checkup(state, card_db) -> None:
    """ポケモンチェックの前に、パッシブ特性による下準備をする(Stir and Snooze: ねむりのとき、おきるコイン判定が2枚になる)。"""
    if not GENERATED_PASSIVES:
        return
    for idx in (0, 1):
        active = state.player(idx).active
        if active is None:
            continue
        for _k, params in active_passives(state, card_db, idx, active, "sleep_flip_count"):
            if active.status.exclusive.name == "ASLEEP":
                active.status.sleep_flip_count = max(active.status.sleep_flip_count, params["count"])


def apply_between_turns(state, card_db) -> None:
    """ポケモンチェックの終わりに「番の間、〜する」系のパッシブ特性を適用する(Royal Heal/Sparkling Particles/Rain Dish/Sand Slammer)。"""
    if not GENERATED_PASSIVES:
        return
    from effects.passives_cond import cond_checkup_counters
    from effects.primitives import _blocks_damage_counters

    cond_checkup_counters(state, card_db)
    for idx in (0, 1):
        owner = state.player(idx)
        for mon in list(owner.all_pokemon_in_play()):
            for kind, params in active_passives(state, card_db, idx, mon):
                if kind == "between_turns_heal":
                    targets = [mon] if params["scope"] == "self" else owner.all_pokemon_in_play()
                    for t in targets:
                        if t.damage > 0:
                            t.damage = max(0, t.damage - params["amount"])
                elif kind == "between_turns_counters_opponent":
                    if params.get("active_only") and mon is not owner.active:
                        continue
                    for t in state.player(1 - idx).all_pokemon_in_play():
                        if params.get("basic_only") and not ((tc := card_db.get(t.card_id)) is not None and tc.is_basic):
                            continue
                        if not _blocks_damage_counters(t):
                            t.damage += params["counters"] * 10


# ---------------------------------------------------------------------------------------------
# 弱点・抵抗力
# ---------------------------------------------------------------------------------------------
def apply_weakness_passives(ctx, defender, defender_card):
    """防御側のカード情報(弱点・抵抗力)に、場のパッシブ特性による上書きを反映したものを返す。"""
    if not GENERATED_PASSIVES:
        return defender_card
    from dataclasses import replace

    from cards.models import WeaknessResistance

    state, card_db = ctx.state, ctx.card_db
    owner_index = ctx.opponent
    # 両プレイヤーの場にいる全員の弱点を×4にする(Allergy Panic)
    if global_passives(state, card_db, "weakness_x4_all"):
        defender_card = replace(
            defender_card, weaknesses=tuple(WeaknessResistance(type=w.type, value="×4") for w in defender_card.weaknesses)
        )
    from effects.era_energy_g import no_weakness_by_energy

    if no_weakness_by_energy(defender, defender_card):
        return replace(defender_card, weaknesses=())  # フラッシュエネルギー
    # 弱点を持たなくなる
    if active_passives(state, card_db, owner_index, defender, "self_no_weakness_if_energy"):
        for _k, params in active_passives(state, card_db, owner_index, defender, "self_no_weakness_if_energy"):
            if _has_energy(card_db, defender, params["energy_type"]):
                return replace(defender_card, weaknesses=())
    from effects.passives_cond import cond_weakness_override

    cond_no_weak, cond_no_res = cond_weakness_override(state, card_db, owner_index, defender, defender_card)
    if cond_no_res:
        defender_card = replace(defender_card, resistances=())
    if cond_no_weak:
        return replace(defender_card, weaknesses=())
    for _holder, params in team_passives(state, card_db, owner_index, "team_no_weakness"):
        if params.get("defender_type") and params["defender_type"] not in defender_card.types:
            continue
        if params.get("requires_energy") and not defender.attached_energy:
            continue
        names = params.get("requires_names")
        if names and not all(
            any((c := card_db.get(m.card_id)) is not None and c.name == n for m in state.player(owner_index).all_pokemon_in_play())
            for n in names
        ):
            continue
        return replace(defender_card, weaknesses=())
    # 抵抗力の数値を上書きする(Secret Key)
    for _holder, params in team_passives(state, card_db, owner_index, "team_resistance_override"):
        if params.get("defender_type") in defender_card.types:
            defender_card = replace(
                defender_card,
                resistances=tuple(WeaknessResistance(type=r.type, value=params["value"]) for r in defender_card.resistances),
            )
    return defender_card


def dragon_weakness_is_psychic(ctx) -> bool:
    """攻撃側の場に「相手のドラゴンポケモンの弱点をエスパーにする」特性(Fairy Zone)を持つポケモンがいるか。"""
    return bool(GENERATED_PASSIVES) and bool(team_passives(ctx.state, ctx.card_db, ctx.acting_player, "opp_dragon_weakness_psychic"))


# ---------------------------------------------------------------------------------------------
# 特殊状態にならない
# ---------------------------------------------------------------------------------------------
def status_immune_all(state, card_db, owner_index: int, mon) -> bool:
    """monが特殊状態に一切ならない(パッシブ特性: Immunity/Sweet Veil等)か。"""
    from cards.card_db import POKEMON_AS_ITEM

    if mon.card_id in POKEMON_AS_ITEM:
        return True  # みがわりロボ/化石グッズ: 特殊状態にならない
    from effects.era_energy_g import status_immune_by_energy

    if status_immune_by_energy(mon, card_db.get(mon.card_id)):
        return True  # バブリーウォーターエネルギー
    if not GENERATED_PASSIVES:
        return False
    if active_passives(state, card_db, owner_index, mon, "status_immune_self"):
        return True
    for _holder, params in team_passives(state, card_db, owner_index, "team_status_immune_if_energy"):
        if params.get("statuses") == "all" and _has_energy(card_db, mon, params["energy_type"]):
            return True
    return False


def blocked_statuses(state, card_db, owner_index: int, mon) -> set:
    """monがならない特殊状態(poisoned/burned/asleep/confused/paralyzed)の集合(部分的な免疫: Frozen Charm等)。"""
    from effects.era_trainers import era_blocked_statuses

    out: set = set(era_blocked_statuses(state, card_db, owner_index, mon))  # ヘビーブーツ/カオスタワー
    if not GENERATED_PASSIVES:
        return out
    from effects.passives_cond import cond_status_blocked

    out |= cond_status_blocked(state, card_db, owner_index, mon)
    for _holder, params in team_passives(state, card_db, owner_index, "team_status_immune_if_energy"):
        if params.get("statuses") != "all" and _has_energy(card_db, mon, params["energy_type"]):
            out.update(params["statuses"])
    return out


# ---------------------------------------------------------------------------------------------
# トレーナーズ・エネルギー・進化のロック
# ---------------------------------------------------------------------------------------------
def _opponent_active_holds(state, card_db, player_index: int, kind: str) -> bool:
    opponent_active = state.player(1 - player_index).active
    return opponent_active is not None and bool(active_passives(state, card_db, 1 - player_index, opponent_active, kind))


def items_locked(state, card_db, player_index: int) -> bool:
    """相手のバトルポケモンの特性(Magic Room/Oceanic Curse)で、グッズを使えないか。"""
    from effects.passives_cond import cond_locked

    return bool(GENERATED_PASSIVES) and (
        _opponent_active_holds(state, card_db, player_index, "lock_opponent_items_while_active")
        or _opponent_active_holds(state, card_db, player_index, "lock_opponent_items_and_tools_while_active")
        or cond_locked(state, card_db, player_index, "item")
    )


def tools_locked(state, card_db, player_index: int) -> bool:
    from effects.passives_cond import cond_locked

    return bool(GENERATED_PASSIVES) and (
        _opponent_active_holds(state, card_db, player_index, "lock_opponent_items_and_tools_while_active")
        or cond_locked(state, card_db, player_index, "tool")
    )


def supporters_locked(state, card_db, player_index: int) -> bool:
    from effects.passives_cond import cond_locked

    return bool(GENERATED_PASSIVES) and (
        _opponent_active_holds(state, card_db, player_index, "lock_opponent_supporters_while_active")
        or cond_locked(state, card_db, player_index, "supporter")
    )


def special_energy_attach_locked(state, card_db, player_index: int) -> bool:
    if not GENERATED_PASSIVES:
        return False
    from effects.passives_cond import cond_locked

    if _opponent_active_holds(state, card_db, player_index, "lock_opponent_special_energy_attach_while_active"):
        return True
    if cond_locked(state, card_db, player_index, "special_energy"):
        return True
    from effects.passives_ext import hand_block_active

    return hand_block_active(state, card_db, player_index)  # Hand Block


def ace_spec_locked(state, card_db) -> bool:
    """場に「両プレイヤーがACE SPECを使えない」特性(Sealing Scream)を持つポケモンがいるか。"""
    return bool(GENERATED_PASSIVES) and bool(global_passives(state, card_db, "ace_spec_lock"))


def can_play_two_supporters(state, card_db, player_index: int) -> bool:
    return bool(GENERATED_PASSIVES) and bool(team_passives(state, card_db, player_index, "two_supporters"))


def evolution_banned(state, card_db) -> bool:
    """場に「両プレイヤーが手札からポケモンを進化させられない」特性(Ancient Power)を持つポケモンがいるか。"""
    return bool(GENERATED_PASSIVES) and bool(global_passives(state, card_db, "no_evolve_for_both"))


def can_evolve_on_play_turn(state, card_db, owner_index: int, mon) -> bool:
    """「出した番/最初の番でも進化できる」特性(Adaptive Evolution/Stimulated Evolution)を持つか。"""
    if not GENERATED_PASSIVES:
        return False
    owner = state.player(owner_index)
    for _k, params in active_passives(state, card_db, owner_index, mon, "evolve_on_play_turn"):
        needed = params.get("if_in_play")
        if needed and not any(
            (c := card_db.get(m.card_id)) is not None and c.name == needed for m in owner.all_pokemon_in_play()
        ):
            continue
        opp_subtype = params.get("if_opp_active_subtype")
        if opp_subtype:
            opp_active = state.player(1 - owner_index).active
            oc = card_db.get(opp_active.card_id) if opp_active is not None else None
            if oc is None or opp_subtype not in oc.subtypes:
                continue  # Fighting Roar: 相手のバトルポケモンがexのとき
        return True
    return False


def break_has_no_abilities(state, card_db, card) -> bool:
    """「ポケモンBREANは特性を持たない」特性(Devour Light)が場にあり、cardがBREAKか(特性の封印判定用。保持者自身の封印は見ない)。"""
    if not GENERATED_PASSIVES or "BREAK" not in card.subtypes:
        return False
    for idx in (0, 1):
        for m in state.player(idx).all_pokemon_in_play():
            for _n, k, _p in GENERATED_PASSIVES.get(m.card_id, ()):
                if k == "break_no_abilities":
                    return True
    return False


# ---------------------------------------------------------------------------------------------
# きぜつ(相手のワザのダメージで)・サイド
# ---------------------------------------------------------------------------------------------
def on_knocked_out_by_attack(ctx, ko_mon, owner_index: int) -> None:
    """相手のワザのダメージでko_monがきぜつしたとき(場から取り除かれる前)の、きぜつしたポケモンのパッシブ特性
    (Exploding Needles/Spiteful Spirit/Destiny Burst/Aftermath)と、攻撃側のパッシブ特性(Overflow/Greedy Eater)。"""
    if not GENERATED_PASSIVES:
        return
    state, card_db = ctx.state, ctx.card_db
    owner = state.player(owner_index)
    attacker_owner = state.player(ctx.acting_player)
    attacker = ctx.source_pokemon
    ko_card = card_db.get(ko_mon.card_id)
    from effects.passives_ext import ext_on_knocked_out
    from effects.primitives import _apply_condition, _blocks_damage_counters

    ext_on_knocked_out(ctx, ko_mon, owner_index)
    for kind, params in active_passives(state, card_db, owner_index, ko_mon):
        if params.get("active_only") and ko_mon is not owner.active:
            continue
        if kind == "ko_retaliate_counters" and attacker is not None and not _blocks_damage_counters(attacker):
            attacker.damage += params["counters"] * 10
            ctx.log(f"{ko_mon.card_id} の特性で、攻撃したポケモンにダメカンを{params['counters']}個のせた")
        elif kind == "ko_retaliate_status" and attacker is not None:
            for status in params["statuses"]:
                _apply_condition(attacker, status)
            ctx.log(f"{ko_mon.card_id} の特性で、攻撃したポケモンが{'・'.join(params['statuses'])}になった")
        elif kind == "ko_coin_retaliate_counters" and attacker is not None:
            if ctx.rng.random() < 0.5 and not _blocks_damage_counters(attacker):
                attacker.damage += params["counters"] * 10
                ctx.log(f"{ko_mon.card_id} の特性(コインオモテ)で、攻撃したポケモンにダメカンを{params['counters']}個のせた")
        elif kind == "ko_coin_knockout_attacker" and attacker is not None:
            if ctx.rng.random() < 0.5:
                attacker.damage = 9999
                ctx.log(f"{ko_mon.card_id} の特性(コインオモテ)で、攻撃したポケモンもきぜつした")
        elif kind == "ko_discard_opp_deck":
            for _ in range(params["count"]):
                if not attacker_owner.deck:
                    break
                attacker_owner.discard.append(attacker_owner.deck.pop(0))
    if attacker is not None:
        for kind, params in active_passives(state, card_db, ctx.acting_player, attacker):
            if kind == "bonus_prize_on_ko":
                if params.get("defender_basic_only") and (ko_card is None or not ko_card.is_basic):
                    continue
                attacker_owner.bonus_prize_next_knockout += params["amount"]
                ctx.log(f"{attacker.card_id} の特性で、サイドをさらに{params['amount']}枚取る")


def adjust_ko_prize(state, card_db, owner_index: int, mon, prize_count: int) -> int:
    """きぜつしたmon(owner_index側)について、相手が取るサイド枚数にパッシブ特性の効果を反映する
    (Empty Shell/Fragile Husk/Shadowy Concealment)。"""
    if not GENERATED_PASSIVES:
        return prize_count
    attacker_card = card_db.get(mon.ko_attacker_card_id) if mon.ko_attacker_card_id else None
    for kind, params in active_passives(state, card_db, owner_index, mon):
        if kind == "ko_no_prize":
            return 0
        if kind == "ko_no_prize_vs_subtype" and attacker_card is not None and params["subtype"] in attacker_card.subtypes:
            return 0
        if kind == "ko_fewer_prize_if_named_in_play" and mon.ko_attacker_card_id:
            owner = state.player(owner_index)
            if any((c := card_db.get(m.card_id)) is not None and c.name == params["name"] for m in owner.all_pokemon_in_play()):
                prize_count -= 1  # ワザのダメージできぜつしたとき(おっと、そうはいかない/Oh No You Don't)
    mon_card = card_db.get(mon.card_id)
    used: set = set()
    for _holder, params in team_passives(state, card_db, owner_index, "team_ko_prize_reduction_vs_subtype"):
        if attacker_card is None or mon_card is None:
            continue
        if params["defender_type"] not in mon_card.types or params["attacker_subtype"] not in attacker_card.subtypes:
            continue
        key = params.get("no_stack_key")
        if key and key in used:
            continue
        if key:
            used.add(key)
        prize_count -= params["amount"]
    return max(0, prize_count)


# ---------------------------------------------------------------------------------------------
# ワザを使えない・先攻1ターン目のワザ
# ---------------------------------------------------------------------------------------------
def attack_restricted(state, card_db, owner_index: int, mon) -> bool:
    """パッシブ特性により、monがワザを使えないか(Airhead/Unobservant/Power Bind)。"""
    if not GENERATED_PASSIVES:
        return False
    owner = state.player(owner_index)
    opponent = state.player(1 - owner_index)
    for kind, params in active_passives(state, card_db, owner_index, mon):
        if kind == "cant_attack_if_own_prizes_in" and len(owner.prizes) in params["values"]:
            return True
        if kind == "cant_attack_if_opp_active_basic":
            oc = card_db.get(opponent.active.card_id) if opponent.active is not None else None
            if oc is not None and oc.is_basic:
                return True
        if kind == "cant_attack_if_few_pokemon" and len(owner.all_pokemon_in_play()) <= params["count"]:
            return True
        if kind == "cant_attack_if_few_subtype":
            from cards.card_db import card_has_subtype

            n = sum(
                1 for side in (0, 1) for m in state.player(side).all_pokemon_in_play()
                if card_has_subtype(card_db.get(m.card_id), params["subtype"])
            )
            if n <= params["count"]:
                return True  # Power Saver: 場(両プレイヤー)のそのサブタイプのポケモンが少ないとワザを使えない
    return False


def attacks_on_first_turn(state, card_db, owner_index: int, mon) -> bool:
    """「先攻なら最初の番からワザを使える」パッシブ特性(Debut Performance)を持つか(先攻かどうかは呼び出し側で確認済み)。"""
    return bool(GENERATED_PASSIVES) and bool(active_passives(state, card_db, owner_index, mon, "attack_on_first_turn"))


# ---------------------------------------------------------------------------------------------
# 手札からエネルギーをつけたとき
# ---------------------------------------------------------------------------------------------
def on_energy_attached_from_hand(state, card_db, actor: int, target) -> None:
    """手札からtarget(actor側のポケモン)にエネルギーをつけたときの、パッシブ特性(Earthen Awakening/Auto Heal/Electromagnetic Wall)。"""
    if not GENERATED_PASSIVES:
        return
    owner = state.player(actor)
    opponent_index = 1 - actor
    from effects.primitives import _blocks_damage_counters

    for _k, params in active_passives(state, card_db, actor, target, "on_self_attach_heal"):
        target.damage = max(0, target.damage - params["amount"])
    owner_active = owner.active
    if owner_active is not None:
        for _k, params in active_passives(state, card_db, actor, owner_active, "team_on_attach_heal_while_active"):
            target.damage = max(0, target.damage - params["amount"])
    opponent_active = state.player(opponent_index).active
    if opponent_active is not None:
        for _k, params in active_passives(state, card_db, opponent_index, opponent_active, "opp_attach_counters_while_active"):
            if not _blocks_damage_counters(target):
                target.damage += params["counters"] * 10
                state.add_log(f"{opponent_active.card_id} の特性で、{target.card_id}にダメカンを{params['counters']}個のせた")


def opponent_coins_are_tails(state, card_db, acting_player: int) -> bool:
    """相手のバトルポケモンの特性(Contrary)で、acting_playerのコインが全てウラ扱いになるか。"""
    if not GENERATED_PASSIVES:
        return False
    opponent_active = state.player(1 - acting_player).active
    return opponent_active is not None and bool(active_passives(state, card_db, 1 - acting_player, opponent_active, "opp_coins_tails_while_active"))


def attack_damage_reduction_from_opponent(ctx, attacker_card) -> int:
    """防御側の場のパッシブ特性による、相手のバトルポケモンのワザのダメージ軽減(Intimidating Fang/Gloomy Garbage)。弱点・抵抗力の前に適用する。"""
    if not GENERATED_PASSIVES or ctx.source_pokemon is None:
        return 0
    state, card_db = ctx.state, ctx.card_db
    owner_index = ctx.opponent
    owner = state.player(owner_index)
    reduction = 0
    attacker_owner = state.player(ctx.acting_player)
    if ctx.source_pokemon is not attacker_owner.active:
        return 0
    for holder, params in team_passives(state, card_db, owner_index, "opp_active_damage_reduction"):
        if params.get("holder_active_only") and holder is not owner.active:
            continue
        if params.get("attacker_has_tool") and ctx.source_pokemon.attached_tool is None:
            continue
        reduction += params["amount"]
    return reduction


# ---------------------------------------------------------------------------------------------
# エネルギーの提供タイプ・ポケモンのタイプ・借りるワザ
# ---------------------------------------------------------------------------------------------
def adjust_energy_tokens(card_db, energy_card_id: str, host_card_id, all_attached_energy_ids, tokens: list) -> list:
    """エネルギーが提供するタイプトークンに、パッシブ特性の効果(Dark Aura/Psychic Mirage)を反映する。"""
    from engine.energy import current_state

    state = current_state()
    if state is None or not GENERATED_PASSIVES or all_attached_energy_ids is None:
        return tokens
    mon = owner_index = None
    for idx in (0, 1):
        for m in state.player(idx).all_pokemon_in_play():
            if m.attached_energy is all_attached_energy_ids:
                mon, owner_index = m, idx
    if mon is None:
        return tokens
    for _k, params in active_passives(state, card_db, owner_index, mon, "energy_is_type"):
        return [params["type"] for _ in tokens]  # Dark Aura: ついているエネルギーはすべて指定のタイプのエネルギーになる
    energy_card = card_db.get(energy_card_id)
    host_card = card_db.get(mon.card_id)
    if energy_card is not None and host_card is not None and energy_card.basic_energy_type is not None:
        for _holder, params in team_passives(state, card_db, owner_index, "team_energy_double"):
            if energy_card.basic_energy_type == params["energy_type"] and params["pokemon_type"] in host_card.types:
                return list(tokens) + list(tokens)  # Psychic Mirage: 基本のエスパーエネルギーがエスパーエネルギー2個ぶんになる(重ならない)
                # (複数の特性があっても1回だけ倍になる: ここで即returnするため)
    return tokens


def mon_types(state, card_db, owner_index: int, mon) -> tuple:
    """パッシブ特性(Double Type/Dual Armor/Color Change)を反映した、場のポケモンのタイプ。"""
    card = card_db.get(mon.card_id)
    if card is None:
        return ()
    if mon.type_override and state.player(owner_index).turns_taken <= mon.type_override_until_turn:
        return (mon.type_override,)
    types = tuple(card.types)
    if mon.attached_tool is not None:
        from effects.era_sm_hooks import memory_type
        from engine.continuous import tools_disabled

        memory = memory_type(card, mon.attached_tool)  # シルヴァディGXのメモリ(タイプが変わる)
        if memory is not None and not tools_disabled(state.stadium_in_play):
            return (memory,)
    if not GENERATED_PASSIVES:
        return types
    for _holder, params in team_passives(state, card_db, owner_index, "team_add_type_to_stage"):
        if params["stage"] in card.subtypes and params["type"] not in types:
            types = types + (params["type"],)  # Aqua Effect/Electric Effect: 元のタイプに加えてそのタイプにもなる
    for kind, params in active_passives(state, card_db, owner_index, mon):
        if kind == "types_are":
            cond = params.get("if_energy")
            if cond and not _has_energy(card_db, mon, cond):
                continue
            return tuple(params["types"])
        if kind == "type_same_as_opp_active" and mon is state.player(owner_index).active:
            opp_active = state.player(1 - owner_index).active
            oc = card_db.get(opp_active.card_id) if opp_active is not None else None
            if oc is not None:
                return tuple(oc.types)
    return types


def borrowed_attack_sources(state, card_db, owner_index: int, mon) -> list[tuple[str, str]]:
    """monが、パッシブ特性で借りて使えるワザの持ち主(zone, card_id)の一覧(Versatile/Time Recall/Metamorphosis Gene/Shadow Hunt等)。"""
    if not GENERATED_PASSIVES:
        return []
    owner = state.player(owner_index)
    opponent = state.player(1 - owner_index)
    out: list[tuple[str, str]] = []
    seen: set = set()

    def add(zone, card_id):
        card = card_db.get(card_id)
        if card is None or not card.is_pokemon or not card.attacks or (zone, card_id) in seen:
            return
        seen.add((zone, card_id))
        out.append((zone, card_id))

    for _k, params in active_passives(state, card_db, owner_index, mon, "borrow_attacks"):
        src = params["sources"]
        if src == "any_in_play":
            for m in owner.all_pokemon_in_play():
                add("bench" if m is not owner.active else "own_active", m.card_id)
            for m in opponent.all_pokemon_in_play():
                add("opponent_active" if m is opponent.active else "opponent_bench", m.card_id)
        elif src == "own_basic_in_play":
            for m in owner.all_pokemon_in_play():
                c = card_db.get(m.card_id)
                if c is not None and c.is_basic:
                    add("bench", m.card_id)
        elif src == "opp_active":
            if mon is owner.active and opponent.active is not None:
                add("opponent_active", opponent.active.card_id)
        elif src == "own_discard_basic":
            for cid in owner.discard:
                c = card_db.get(cid)
                if c is not None and c.is_basic:
                    add("discard", cid)
        elif src == "own_gx_ex_bench_or_discard":
            for m in owner.bench:
                c = card_db.get(m.card_id)
                if c is not None and ({"GX", "EX"} & set(c.subtypes)):
                    add("bench", m.card_id)
            for cid in owner.discard:
                c = card_db.get(cid)
                if c is not None and ({"GX", "EX"} & set(c.subtypes)):
                    add("discard", cid)
    from effects.era_trainers import era_shrine_of_memories_active

    if mon is owner.active and mon.evolution_history and (
        era_shrine_of_memories_active(state) or team_passives(state, card_db, owner_index, "team_borrow_previous_evolutions")
    ):  # Shrine of Memories(スタジアム)も同じ効果
        for cid in mon.evolution_history:
            add("previous", cid)
    return out
