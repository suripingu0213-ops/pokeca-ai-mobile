"""SWSH/SV期の特殊エネルギー(2026-10-07): タイプの提供・つけられる制限・つけるコスト。

「ついているポケモンへの効果」(カードの効果の宣言)は scripts/generate_tool_passives.py が生成する TOOL_PASSIVES / TOOL_REACTIONS(どうぐと同じ表。
ID はカードごとに一意)で、effects/passives_cond.py と effects/era_tools_j.py が処理する。ここでは、カードの文面から次を導く:
  - 提供するエネルギー(トークン): 「it provides X Energy」「every type of Energy but only 1 at a time」「Fighting and Darkness ... 1 at a time」等
  - つけられるポケモンの制限(「This card can only be attached to a Single Strike Pokémon.」)
  - つけるためのコスト(オーロラエネルギー: 手札を1枚トラッシュする)
"""

from __future__ import annotations

import re

from engine.energy import EXTRA_MULTI_TYPE_TOKENS, WILDCARD_TOKEN

TYPES = ("Grass", "Fire", "Water", "Lightning", "Psychic", "Fighting", "Darkness", "Metal", "Fairy", "Dragon", "Colorless")
SINGLE_STRIKE_TOKEN = "FightingDarknessEither"
EXTRA_MULTI_TYPE_TOKENS.setdefault(SINGLE_STRIKE_TOKEN, frozenset({"Fighting", "Darkness"}))  # 2タイプのどちらか1つとして使える(Single Strike Energy)

_TEXT_CACHE: dict[str, tuple] = {}


def _text(card) -> str:
    return " ".join((" ".join(card.rules or [])).replace(chr(1), " ").split())


def _parse(card) -> tuple:
    """(トークン仕様, つけられるサブタイプ, つけるコストが手札1枚か)。トークン仕様: None/("types", [..])/("every",)/("either", [..])/("twin",)。"""
    cached = _TEXT_CACHE.get(card.id)
    if cached is not None:
        return cached
    text = _text(card)
    token = None
    if re.search(r"it provides every type of Energy but provides only 1 Energy at a time", text):
        token = ("every",)
    elif m := re.search(r"it provides (Fighting) and (Darkness) Energy but provides only 1 Energy at a time", text):
        token = ("either", [m.group(1), m.group(2)])
    elif "isn't a Pokémon V or a Pokémon-GX, it provides ColorlessColorless Energy" in text:
        token = ("twin",)
    elif m := re.search(r"it provides ((?:Colorless)+|" + "|".join(TYPES) + r") Energy", text):
        words = re.findall("|".join(TYPES), m.group(1))
        token = ("types", words)
    subtype = None
    if m := re.search(r"This card can only be attached to an? ([\w ]+?) Pokémon\.", text):
        subtype = m.group(1)
    hand_cost = "only if you discard another card from your hand" in text
    result = (token, subtype, hand_cost)
    _TEXT_CACHE[card.id] = result
    return result


def era_energy_tokens_j(card_db, energy_card_id: str, host_card_id) -> list | None:
    """特殊エネルギー(文面から導けるもの)が提供するトークン。該当しなければNone。"""
    card = card_db.get(energy_card_id)
    if card is None or not card.is_special_energy:
        return None
    token, _subtype, _cost = _parse(card)
    if token is None:
        return None
    kind = token[0]
    if kind == "every":
        return [WILDCARD_TOKEN]
    if kind == "either":
        return [SINGLE_STRIKE_TOKEN]
    if kind == "twin":
        host = card_db.get(host_card_id) if host_card_id else None
        if host is not None and ("V" in host.subtypes or "GX" in host.subtypes):
            return ["Colorless"]
        return ["Colorless", "Colorless"]
    return list(token[1])


def attach_allowed_j(card_db, energy_card_id: str, target_card) -> bool:
    """「〜ポケモンにだけつけられる」特殊エネルギー(Single Strike/Impact/Spiral)をtarget_cardにつけてよいか。"""
    card = card_db.get(energy_card_id)
    if card is None or not card.is_special_energy:
        return True
    _token, subtype, _cost = _parse(card)
    return subtype is None or subtype in target_card.subtypes


def attach_needs_other_hand_card(card_db, energy_card_id: str) -> bool:
    """オーロラエネルギー: つけるには、手札のほかのカードを1枚トラッシュする必要がある。"""
    card = card_db.get(energy_card_id)
    return card is not None and card.is_special_energy and _parse(card)[2]
