"""時代ごとのカード取り込み(2026-10-06〜)で追加した効果プリミティブその2(選択を伴う効果の共通基盤)。

effects/era_primitives.py と同じ規約。このモジュールは、複数のカードで共通する「プレイヤーが途中で選ぶ」効果を、
カードごとに専用の選択モードを増やさずに済むよう汎用化したもの:
  - AttachEnergyGeneric:       手札/トラッシュ/山札のエネルギーを、自分のポケモンに好きなようにつける
  - MoveEnergyGeneric:         自分/相手の場のエネルギーを別のポケモンに(1枚、または好きなだけ)移す
  - RevealOpponentHandPick:    相手の手札を公開させ、見つけたカードを選んで(トラッシュ/山札の下/山札に混ぜる)
  - LookOpponentDeckTop...:    相手の山札の上を見る(並べ替える/シャッフルさせてもよい)
選択待ちは専用のzone("gen_pokemon_pick"/"gen_energy_pick"/"gen_hand_pick"/"gen_deck_pick")と、
手札/トラッシュ/山札の通常zone+custom_data["mode"]="gen_continue"で表し、解決は engine.rules_engine から
resolve_generic_zone / resolve_generic_continue に委譲される。then_end_turn(ワザの効果として発生した保留)は
解決のたびに新しい保留へ引き継ぐ。
"""

from __future__ import annotations

from dataclasses import dataclass

from effects.context import EffectContext
from effects.primitives import DealDamage, Effect, _attacker_player, _defender
from engine.state import PendingSearchChoice

GENERIC_ZONES = frozenset({"gen_pokemon_pick", "gen_energy_pick", "gen_hand_pick", "gen_deck_pick"})

# 別のモジュール(effects/era_trainers.py等)が登録する、汎用選択の解決処理。
# GENERIC_OP_HANDLERS[op](state, card_db, choice, selected, action, ctx, custom) -> 続き(remaining_script)を消費したか
# GENERIC_CONTINUE_HANDLERS[op](ctx, choice, custom, picked_card_ids): 通常のzoneの選択(mode="gen_continue")が確定した後の続き
GENERIC_OP_HANDLERS: dict = {}
GENERIC_CONTINUE_HANDLERS: dict = {}


# ---------------------------------------------------------------------------------------------
# 共通ヘルパー
# ---------------------------------------------------------------------------------------------
def _slots(player) -> list[tuple[int, object]]:
    """(スロット番号, PokemonInPlay)の一覧。0=バトル場、1..=ベンチ+1。"""
    out = []
    if player.active is not None:
        out.append((0, player.active))
    for i, mon in enumerate(player.bench):
        out.append((i + 1, mon))
    return out


def _mon_at(player, slot: int):
    if slot == 0:
        return player.active
    bi = slot - 1
    return player.bench[bi] if 0 <= bi < len(player.bench) else None


def _slot_of(player, mon) -> int | None:
    if mon is None:
        return None
    if player.active is mon:
        return 0
    for i, m in enumerate(player.bench):
        if m is mon:
            return i + 1
    return None


def _zone_cards(player, zone: str) -> list[str]:
    return {"hand": player.hand, "deck": player.deck}.get(zone, player.discard)


def _energy_ok(card, spec: dict) -> bool:
    """spec["basic_only"]/spec["energy_type"]/spec["special_only"]に合うエネルギーか。"""
    if card is None or not card.is_energy:
        return False
    if spec.get("basic_only") and card.is_special_energy:
        return False
    if spec.get("special_only") and not card.is_special_energy:
        return False
    et = spec.get("energy_type")
    if et and card.basic_energy_type != et:
        return False
    eta = spec.get("energy_types_any")
    if eta and card.basic_energy_type not in eta:
        return False  # 「炎エネルギー、闘エネルギー、または1枚ずつ」等、いずれかのタイプの基本エネルギー
    if spec.get("energy_name") and card.name != spec["energy_name"]:
        return False
    if card.basic_energy_type in spec.get("exclude_types", ()):
        return False  # 「違うタイプの基本エネルギーを〜枚」: すでにつけたタイプは選べない(Rebirth)
    return True


def _target_ok(card_db, mon, spec: dict) -> bool:
    card = card_db.get(mon.card_id)
    if card is None:
        return False
    if spec.get("target_type") and spec["target_type"] not in card.types:
        return False
    if spec.get("target_subtype") and spec["target_subtype"] not in card.subtypes:
        return False
    if spec.get("exclude_subtype") and any(s in card.subtypes for s in spec["exclude_subtype"].split(",")):
        return False  # カンマ区切りで複数("GX,EX"=ポケモンGX/EXは除く)
    if spec.get("no_ko_target") and card.hp is not None and card.hp - mon.damage <= spec.get("counters_on_target", 0) * 10:
        return False  # 「きぜつするポケモンには使えない」(ダメカンをのせるとのこりHPが0以下になる)
    if spec.get("target_name_prefix") and not card.name.startswith(spec["target_name_prefix"]):
        return False
    if spec.get("target_names") and card.name not in spec["target_names"]:
        return False
    if spec.get("target_stage") and spec["target_stage"] not in card.subtypes:
        return False
    if spec.get("target_types_any") and not any(t in card.types for t in spec["target_types_any"]):
        return False
    return True


def _set_pending(state, pending: PendingSearchChoice, then_end_turn: bool) -> None:
    pending.then_end_turn = then_end_turn
    if isinstance(pending.custom_data, dict):
        pending.custom_data["then_end_turn"] = then_end_turn
    state.pending_search_choice = pending


def _cont_ctx(state, card_db, choice) -> EffectContext:
    return EffectContext(
        state=state,
        card_db=card_db,
        acting_player=choice.actor(),
        source_pokemon=choice.cont_source_pokemon,
        source_card_id=choice.cont_source_card_id,
        rng=state.rng,
    )


def _carry(pending: PendingSearchChoice, ctx: EffectContext) -> PendingSearchChoice:
    pending.cont_source_pokemon = ctx.source_pokemon
    pending.cont_source_card_id = ctx.source_card_id
    pending.effect_source = ctx.effect_source
    return pending


# ---------------------------------------------------------------------------------------------
# エネルギーを自由につける(手札/トラッシュ/山札 → 自分のポケモン)
# ---------------------------------------------------------------------------------------------
def attach_generic_start(
    ctx: EffectContext, spec: dict, remaining: int, used: tuple = (), locked_slot: int | None = None,
    then_end_turn: bool = False,
) -> None:
    player = _attacker_player(ctx)
    source = _zone_cards(player, spec["source"])
    limit = spec.get("deck_limit")  # 山札の上からlimit枚だけが対象(Energized Steps/Serene Grace)
    eligible = [i for i, cid in enumerate(source) if _energy_ok(ctx.card_db.get(cid), spec) and (limit is None or i < limit)]
    if remaining <= 0 or not eligible:
        _attach_finish(ctx, spec)
        return
    if spec.get("self_only"):
        locked_slot = _slot_of(player, ctx.source_pokemon)
        if locked_slot is None:
            _attach_finish(ctx, spec)
            return
    if locked_slot is not None:
        mon = _mon_at(player, locked_slot)
        if mon is None:
            _attach_finish(ctx, spec)
            return
        _attach_pick_card(ctx, spec, remaining, locked_slot, mon, used, eligible, then_end_turn)
        return
    candidates = [
        (slot, mon)
        for slot, mon in _slots(player)
        if (not spec.get("bench_only") or slot > 0)
        and (not spec.get("active_only") or slot == 0)
        and not (spec.get("distinct_targets") and slot in used)
        and _target_ok(ctx.card_db, mon, spec)
    ]
    if not candidates:
        _attach_finish(ctx, spec)
        return
    optional = bool(spec.get("optional"))
    if len(candidates) == 1 and not optional:
        slot, mon = candidates[0]
        _attach_pick_card(ctx, spec, remaining, slot, mon, used, eligible, then_end_turn)
        return
    pending = PendingSearchChoice(
        player_index=ctx.acting_player,
        zone="gen_pokemon_pick",
        source_indices=[slot for slot, _ in candidates],
        card_ids=[mon.card_id for _, mon in candidates],
        min_count=0 if optional else 1,
        max_count=1,
        prompt=f"エネルギーをつける自分のポケモンを選ぶ(残り{remaining}枚まで)" if optional else "エネルギーをつける自分のポケモンを選ぶ",
        shuffle_after=False,
        all_card_ids=[mon.card_id for _, mon in candidates],
        custom_data={"op": "attach_pick_target", "spec": spec, "remaining": remaining, "used": list(used)},
    )
    _set_pending(ctx.state, _carry(pending, ctx), then_end_turn)


def _attach_pick_card(ctx, spec, remaining, slot, mon, used, eligible, then_end_turn) -> None:
    player = _attacker_player(ctx)
    source = _zone_cards(player, spec["source"])
    ids = [source[i] for i in eligible]
    next_used = tuple(used) + (slot,)
    if len(set(ids)) == 1:
        energy_id = source.pop(eligible[0])
        mon.attached_energy.append(energy_id)
        ctx.last_attach_succeeded = True
        ctx.log(f"{energy_id}を{mon.card_id}につけた")
        if spec.get("distinct_energy_types"):
            spec = dict(spec)
            spec["exclude_types"] = list(spec.get("exclude_types", ())) + [ctx.card_db.get(energy_id).basic_energy_type]
        attach_generic_next(ctx, spec, remaining - 1, slot, next_used, then_end_turn)
        return
    pending = PendingSearchChoice(
        player_index=ctx.acting_player,
        zone=spec["source"],
        source_indices=list(eligible),
        card_ids=ids,
        min_count=1,
        max_count=1,
        prompt=f"{mon.card_id}につけるエネルギーを選ぶ",
        shuffle_after=False,
        all_card_ids=list(source),
        destination="attach_energy",
        attach_target_pokemon=mon,
        custom_data={
            "mode": "gen_continue", "op": "attach_next", "spec": spec, "remaining": remaining - 1, "slot": slot,
            "used": list(next_used),
        },
    )
    _set_pending(ctx.state, _carry(pending, ctx), then_end_turn)


def attach_generic_next(ctx, spec, remaining, slot, used, then_end_turn) -> None:
    if spec.get("counters_on_target") and ctx.last_attach_succeeded:
        mon = _mon_at(_attacker_player(ctx), slot)
        if mon is not None:
            mon.damage += 10 * spec["counters_on_target"]
    if spec.get("heal_on_target") and ctx.last_attach_succeeded:
        mon = _mon_at(_attacker_player(ctx), slot)
        if mon is not None:
            mon.heal(spec["heal_on_target"])  # つけたポケモンのダメージを回復する(Ripening Charge等)
    locked = slot if spec.get("single_target") else None
    if spec.get("deck_limit") is not None:
        spec = dict(spec)
        spec["deck_limit"] = max(0, spec["deck_limit"] - 1)  # 山札の上のカードを1枚つけた分、上のlimit枚の範囲が1つ縮む
    attach_generic_start(ctx, spec, remaining, used=tuple(used), locked_slot=locked, then_end_turn=then_end_turn)


def _attach_finish(ctx: EffectContext, spec: dict) -> None:
    if spec["source"] == "deck":
        ctx.state.rng.shuffle(_attacker_player(ctx).deck)


@dataclass(frozen=True)
class AttachEnergyGeneric(Effect):
    """エネルギー(手札/トラッシュ/山札から)を自分のポケモンにつける。1枚つけるごとに対象とカードを選び直せる。

    source: "hand"|"discard"|"deck"。count: つける最大枚数(99=「好きなだけ」)。
    basic_only: 基本エネルギーのみ。energy_type: そのタイプの基本エネルギーのみ。
    self_only: このポケモンにつける。bench_only: ベンチのポケモンのみ。target_type/target_subtype: 対象の条件。
    single_target: 1匹にまとめてつける("to 1 of your Pokémon")。distinct_targets: 同じポケモンに2度つけない("each of those")。
    optional: 「してもよい」(つけるポケモンを選ばず打ち切れる)。"""

    source: str
    count: int = 1
    basic_only: bool = False
    energy_type: str | None = None
    self_only: bool = False
    bench_only: bool = False
    target_type: str | None = None
    target_subtype: str | None = None
    single_target: bool = False
    distinct_targets: bool = False
    optional: bool = False
    special_only: bool = False
    target_name_prefix: str | None = None
    exclude_subtype: str | None = None
    counters_on_target: int = 0  # つけた先のポケモンにダメカンをのせる(Flare Navigate)
    heal_on_target: int = 0  # つけた先のポケモンのダメージを回復する(Ripening Charge)
    distinct_energy_types: bool = False  # つけるエネルギーは全て違うタイプにする(Rebirth)
    deck_limit: int | None = None  # source="deck"のとき、山札の上からこの枚数だけを対象にする(Energized Steps/Serene Grace)
    active_only: bool = False  # バトルポケモンにだけつける(Lethargic Charge)
    target_names: tuple = ()  # つけ先は、これらの名前のポケモンだけ
    target_stage: str | None = None  # つけ先は、この進化段階("Stage 2"等)のポケモンだけ
    target_types_any: tuple = ()  # つけ先は、これらのタイプのいずれかを持つポケモンだけ
    energy_types_any: tuple = ()  # つけるエネルギーは、これらのタイプのいずれかの基本エネルギーだけ
    energy_name: str | None = None  # つけるエネルギーは、この名前のカードだけ(特殊エネルギー名)
    no_ko_target: bool = False  # ダメカンをのせるとき、それできぜつするポケモンにはつけられない

    def spec(self) -> dict:
        return {
            "source": self.source, "basic_only": self.basic_only, "energy_type": self.energy_type,
            "self_only": self.self_only, "bench_only": self.bench_only, "target_type": self.target_type,
            "target_subtype": self.target_subtype, "single_target": self.single_target,
            "distinct_targets": self.distinct_targets, "optional": self.optional, "special_only": self.special_only,
            "target_name_prefix": self.target_name_prefix, "exclude_subtype": self.exclude_subtype,
            "counters_on_target": self.counters_on_target, "heal_on_target": self.heal_on_target,
            "distinct_energy_types": self.distinct_energy_types,
            "deck_limit": self.deck_limit, "active_only": self.active_only, "target_names": self.target_names,
            "target_stage": self.target_stage, "target_types_any": self.target_types_any,
            "energy_types_any": self.energy_types_any, "energy_name": self.energy_name, "no_ko_target": self.no_ko_target,
        }

    def ability_gate(self, state, player, mon, zone, card_db) -> bool:
        """特性として使うとき、つけられるエネルギーとつけ先があるか(何も起きない特性を合法手に出さない)。"""
        spec = self.spec()
        source = _zone_cards(player, spec["source"])
        if not any(_energy_ok(card_db.get(cid), spec) for cid in source):
            return False
        if spec.get("self_only"):
            return True
        return any(
            (not spec.get("bench_only") or slot > 0) and (not spec.get("active_only") or slot == 0) and _target_ok(card_db, m, spec)
            for slot, m in _slots(player)
        )

    def execute(self, ctx: EffectContext) -> None:
        ctx.last_attach_succeeded = False
        attach_generic_start(ctx, self.spec(), self.count)


@dataclass(frozen=True)
class FlipCoinsThenAttachEnergyGeneric(Effect):
    """コインをcoins枚投げ(until_tails=Trueなら裏が出るまで)、オモテ1枚につきエネルギーを1枚つける
    (Seafaring/Energy Hunt/Stormy Seas)。"""

    attach: AttachEnergyGeneric
    coins: int = 0
    until_tails: bool = False

    def execute(self, ctx: EffectContext) -> None:
        heads = 0
        if self.until_tails:
            while ctx.rng.random() < 0.5:
                heads += 1
        else:
            heads = sum(1 for _ in range(self.coins) if ctx.rng.random() < 0.5)
        ctx.coin_heads_count = heads
        ctx.log(f"コイン: オモテ{heads}回")
        if heads <= 0:
            return
        ctx.last_attach_succeeded = False
        attach_generic_start(ctx, self.attach.spec(), heads)


# ---------------------------------------------------------------------------------------------
# エネルギーを移す(自分/相手の場のポケモン間)
# ---------------------------------------------------------------------------------------------
def _mv_sources(ctx_state, card_db, owner_player, spec, self_slot):
    """移動元の候補(スロット, ポケモン): 条件に合うエネルギーがついていて、移動先の候補が1つ以上あるもの。"""
    out = []
    for slot, mon in _slots(owner_player):
        sel = spec["sources"]
        if sel == "active" and slot != 0:
            continue
        if sel == "bench" and slot == 0:
            continue
        if sel == "self" and slot != self_slot:
            continue
        if not any(_energy_ok(card_db.get(e), spec) for e in mon.attached_energy):
            continue
        if not _mv_dests(owner_player, spec, self_slot, slot, card_db):
            continue
        out.append((slot, mon))
    return out


def _mv_dests(owner_player, spec, self_slot, source_slot, card_db=None):
    out = []
    for slot, mon in _slots(owner_player):
        if slot == source_slot:
            continue
        prefix = spec.get("dest_name_prefix")
        if prefix and (card_db is None or not (card_db.get(mon.card_id) and card_db.get(mon.card_id).name.startswith(prefix))):
            continue  # 移動先は名前がprefixで始まるポケモンだけ(Magma Switch: チームマグマ団のポケモン)
        names = spec.get("dest_names")
        if names and (card_db is None or not (card_db.get(mon.card_id) and card_db.get(mon.card_id).name in names)):
            continue  # 移動先は、これらの名前のポケモンだけ(ミスティの水ポケモン号令)
        sel = spec["dests"]
        if sel == "bench" and slot == 0:
            continue
        if sel == "active" and slot != 0:
            continue
        if sel == "self" and slot != self_slot:
            continue
        out.append((slot, mon))
    return out


def mv_start(ctx: EffectContext, spec: dict, then_end_turn: bool = False) -> None:
    owner_index = ctx.acting_player if spec["owner"] == "own" else ctx.opponent
    owner = ctx.state.player(owner_index)
    self_slot = _slot_of(owner, ctx.source_pokemon) if spec["owner"] == "own" else None
    sources = _mv_sources(ctx.state, ctx.card_db, owner, spec, self_slot)
    if not sources:
        return
    freely = bool(spec.get("freely"))
    may = bool(spec.get("may"))
    if len(sources) == 1 and not freely:
        mv_pick_energy(ctx, spec, sources[0][0], then_end_turn)
        return
    pending = PendingSearchChoice(
        player_index=ctx.acting_player,
        zone="gen_pokemon_pick",
        source_indices=[slot for slot, _ in sources],
        card_ids=[mon.card_id for _, mon in sources],
        min_count=0 if (freely or may) else 1,
        max_count=1,
        prompt="エネルギーを移す元のポケモンを選ぶ" + ("(選ばなければ終了)" if (freely or may) else ""),
        shuffle_after=False,
        all_card_ids=[mon.card_id for _, mon in sources],
        custom_data={"op": "mv_pick_source", "spec": spec},
    )
    _set_pending(ctx.state, _carry(pending, ctx), then_end_turn)


def mv_pick_energy(ctx: EffectContext, spec: dict, source_slot: int, then_end_turn: bool) -> None:
    owner_index = ctx.acting_player if spec["owner"] == "own" else ctx.opponent
    owner = ctx.state.player(owner_index)
    source = _mon_at(owner, source_slot)
    if source is None:
        return
    eligible = [i for i, e in enumerate(source.attached_energy) if _energy_ok(ctx.card_db.get(e), spec)]
    if not eligible:
        return
    may = bool(spec.get("may")) and not spec.get("freely")
    ids = [source.attached_energy[i] for i in eligible]
    if len(set(ids)) == 1 and not may:
        mv_pick_dest(ctx, spec, source_slot, eligible[0], then_end_turn)
        return
    pending = PendingSearchChoice(
        player_index=ctx.acting_player,
        zone="gen_energy_pick",
        source_indices=eligible,
        card_ids=ids,
        min_count=0 if may else 1,
        max_count=1,
        prompt="移すエネルギーを選ぶ" + ("(選ばなければ移さない)" if may else ""),
        shuffle_after=False,
        all_card_ids=list(ids),
        custom_data={"op": "mv_pick_energy", "spec": spec, "source_slot": source_slot},
    )
    _set_pending(ctx.state, _carry(pending, ctx), then_end_turn)


def mv_pick_dest(ctx: EffectContext, spec: dict, source_slot: int, energy_index: int, then_end_turn: bool) -> None:
    owner_index = ctx.acting_player if spec["owner"] == "own" else ctx.opponent
    owner = ctx.state.player(owner_index)
    self_slot = _slot_of(owner, ctx.source_pokemon) if spec["owner"] == "own" else None
    dests = _mv_dests(owner, spec, self_slot, source_slot, ctx.card_db)
    if not dests:
        return
    if len(dests) == 1:
        _mv_do_move(ctx, spec, source_slot, energy_index, dests[0][0], then_end_turn)
        return
    pending = PendingSearchChoice(
        player_index=ctx.acting_player,
        zone="gen_pokemon_pick",
        source_indices=[slot for slot, _ in dests],
        card_ids=[mon.card_id for _, mon in dests],
        min_count=1,
        max_count=1,
        prompt="エネルギーを移す先のポケモンを選ぶ",
        shuffle_after=False,
        all_card_ids=[mon.card_id for _, mon in dests],
        custom_data={"op": "mv_pick_dest", "spec": spec, "source_slot": source_slot, "energy_index": energy_index},
    )
    _set_pending(ctx.state, _carry(pending, ctx), then_end_turn)


def _mv_do_move(ctx, spec, source_slot, energy_index, dest_slot, then_end_turn) -> None:
    owner_index = ctx.acting_player if spec["owner"] == "own" else ctx.opponent
    owner = ctx.state.player(owner_index)
    source = _mon_at(owner, source_slot)
    dest = _mon_at(owner, dest_slot)
    if source is None or dest is None or not (0 <= energy_index < len(source.attached_energy)):
        return
    energy_id = source.attached_energy.pop(energy_index)
    dest.attached_energy.append(energy_id)
    ctx.last_attach_succeeded = True
    ctx.log(f"エネルギー({energy_id})を{source.card_id}から{dest.card_id}へ移した")
    if spec.get("freely"):
        mv_start(ctx, {**spec, "moved": True}, then_end_turn)  # 「好きなだけ」の途中でやめたとき、1枚でも移したかを引き継ぐ


@dataclass(frozen=True)
class MoveEnergyGeneric(Effect):
    """エネルギーを移す。owner: "own"(自分の場)|"opp"(相手の場。選ぶのは攻撃側)。
    sources/dests: "any"|"active"|"bench"|"self"(このポケモン。ownのみ)。移動元と移動先は別のポケモン。
    freely=Trueは「好きなだけ好きなように」(移す元を選ばなければ終了)、may=Trueは「してもよい」。
    energy_type/basic_only/special_only: 移せるエネルギーの条件。"""

    owner: str = "own"
    sources: str = "any"
    dests: str = "any"
    energy_type: str | None = None
    basic_only: bool = False
    special_only: bool = False
    freely: bool = False
    may: bool = False
    energy_name: str | None = None
    dest_name_prefix: str | None = None
    dest_names: tuple = ()

    def spec(self) -> dict:
        return {
            "owner": self.owner, "sources": self.sources, "dests": self.dests, "energy_type": self.energy_type,
            "basic_only": self.basic_only, "special_only": self.special_only, "freely": self.freely, "may": self.may,
            "energy_name": self.energy_name, "dest_name_prefix": self.dest_name_prefix, "dest_names": self.dest_names,
        }

    def ability_gate(self, state, player, mon, zone, card_db) -> bool:
        """特性として使うとき、移せるエネルギーと移動先があるか。"""
        spec = self.spec()
        # ownerが"own"のときだけ判定する(相手の場の判定はctxが要るため、使える前提にする)
        if spec["owner"] != "own":
            return True
        return bool(_mv_sources(state, card_db, player, spec, _slot_of(player, mon)))

    def execute(self, ctx: EffectContext) -> None:
        ctx.last_attach_succeeded = False
        mv_start(ctx, self.spec())


# ---------------------------------------------------------------------------------------------
# 相手の手札を公開させて選ぶ / 相手の山札の上を見る
# ---------------------------------------------------------------------------------------------
def _hand_pick_ok(card, criteria: str) -> bool:
    if card is None:
        return False
    if criteria == "any":
        return True
    if criteria == "supporter":
        return card.is_supporter
    if criteria == "item":
        return card.is_item
    if criteria == "pokemon":
        return card.is_pokemon
    if criteria == "energy":
        return card.is_energy
    if criteria == "trainer":
        return card.is_item or card.is_supporter or card.is_stadium or card.is_pokemon_tool
    return False


@dataclass(frozen=True)
class RevealOpponentHandPick(Effect):
    """相手の手札を公開させ、見つけたカード(criteria)を1枚選ぶ。選んだカードはdest("discard"|"bottom"|"shuffle_in")
    へ送られ、そのあとthen(Effectのタプル)を実行する(ctx.last_picked_card_idsに選んだカード)。
    optional=Trueなら選ばなくてもよい。候補が無ければthen_if_none(あれば)だけを実行する。"""

    criteria: str = "any"
    dest: str = "discard"
    optional: bool = False
    then: tuple = ()
    then_if_none: tuple = ()

    def execute(self, ctx: EffectContext) -> None:
        opponent = ctx.state.player(ctx.opponent)
        ctx.state.player(ctx.acting_player).known_opponent_hand = list(opponent.hand)
        indices = [i for i, cid in enumerate(opponent.hand) if _hand_pick_ok(ctx.card_db.get(cid), self.criteria)]
        if not indices:
            for e in self.then_if_none:
                e.execute(ctx)
            return
        pending = PendingSearchChoice(
            player_index=ctx.acting_player,
            zone="gen_hand_pick",
            source_indices=indices,
            card_ids=[opponent.hand[i] for i in indices],
            min_count=0 if self.optional else 1,
            max_count=1,
            prompt="相手の手札を公開させ、カードを1枚選ぶ" + ("(選ばなくてもよい)" if self.optional else ""),
            shuffle_after=False,
            all_card_ids=list(opponent.hand),
            remaining_script=tuple(self.then),
            custom_data={"op": "hand_pick", "dest": self.dest, "then_len": len(self.then)},
        )
        pending.cont_source_pokemon = ctx.source_pokemon
        pending.cont_source_card_id = ctx.source_card_id
        pending.cont_target_bench_index = ctx.target_bench_index
        pending.effect_source = ctx.effect_source
        pending.custom_data["then_if_none_effects"] = tuple(self.then_if_none)
        ctx.state.pending_search_choice = pending


@dataclass(frozen=True)
class DamageBonusIfPickedAny(Effect):
    """直前の選択で1枚以上選ばれていればbase+bonus、そうでなければbaseのダメージ(Whisk Away)。"""

    base: int
    bonus: int

    def execute(self, ctx: EffectContext) -> None:
        DealDamage(self.base + (self.bonus if ctx.last_picked_card_ids else 0)).execute(ctx)


@dataclass(frozen=True)
class UseEffectOfPickedSupporter(Effect):
    """直前に選んだ(相手の手札にあった)サポートのカード効果を、ワザを使っている側が使ったものとして実行する
    (Silent Claw/Hand Control: 「そのカードの効果を、このワザの効果として使う」/「あなたがすべての決定をする」)。"""

    def execute(self, ctx: EffectContext) -> None:
        from effects.interpreter import run_script
        from effects.registry import get_trainer_script

        if not ctx.last_picked_card_ids:
            return
        card_id = ctx.last_picked_card_ids[0]
        sub_ctx = EffectContext(
            state=ctx.state, card_db=ctx.card_db, acting_player=ctx.acting_player, source_pokemon=None,
            source_card_id=card_id, target_bench_index=None, rng=ctx.rng,
        )
        ctx.log(f"サポート「{card_id}」の効果を使った")
        run_script(get_trainer_script(card_id), sub_ctx)


@dataclass(frozen=True)
class DiscardAllOwnBasicEnergyOfEitherTypeThenDamage(Effect):
    """「基本の炎エネルギー全部か基本の雷エネルギー全部のどちらか」を選んでトラッシュし、トラッシュした枚数×perダメージ
    (Rayquaza-EXのDragon Burst)。どちらも持っていなければ0ダメージ。"""

    type_a: str
    type_b: str
    per: int

    def execute(self, ctx: EffectContext) -> None:
        mon = ctx.source_pokemon
        if mon is None:
            return
        counts = {}
        for t in (self.type_a, self.type_b):
            counts[t] = sum(1 for e in mon.attached_energy if (c := ctx.card_db.get(e)) is not None and c.basic_energy_type == t)
        options = [t for t in (self.type_a, self.type_b) if counts[t] > 0]
        if not options:
            DealDamage(0).execute(ctx)
            return
        if len(options) == 1:
            _discard_all_type_then_damage(ctx, options[0], self.per)
            return
        # どちらを捨てるかは「してもよい」型のワザ選択ではなく、効果の途中で選ぶ(相手のポケモンへのダメージ計算は選択後)
        pending = PendingSearchChoice(
            player_index=ctx.acting_player,
            zone="gen_energy_pick",
            source_indices=list(range(len(options))),
            card_ids=[next(e for e in mon.attached_energy if (c := ctx.card_db.get(e)) is not None and c.basic_energy_type == t) for t in options],
            min_count=1,
            max_count=1,
            prompt="トラッシュするエネルギーのタイプを選ぶ(そのタイプの基本エネルギーを全て)",
            shuffle_after=False,
            all_card_ids=[next(e for e in mon.attached_energy if (c := ctx.card_db.get(e)) is not None and c.basic_energy_type == t) for t in options],
            custom_data={"op": "either_type_discard", "types": list(options), "per": self.per},
        )
        pending.cont_source_pokemon = ctx.source_pokemon
        pending.cont_source_card_id = ctx.source_card_id
        ctx.state.pending_search_choice = pending


def _discard_all_type_then_damage(ctx: EffectContext, energy_type: str, per: int) -> None:
    mon = ctx.source_pokemon
    kept, gone = [], []
    for e in mon.attached_energy:
        c = ctx.card_db.get(e)
        (gone if c is not None and c.basic_energy_type == energy_type else kept).append(e)
    mon.attached_energy = kept
    ctx.state.player(ctx.acting_player).discard.extend(gone)
    DealDamage(per * len(gone)).execute(ctx)


# ---------------------------------------------------------------------------------------------
# 相手の山札の上
# ---------------------------------------------------------------------------------------------
@dataclass(frozen=True)
class LookOpponentDeckTopReorder(Effect):
    """相手の山札の上からcount枚を見て、好きな順番で山札の上に戻す(Watcheck/Fortunate Eye)。"""

    count: int

    def execute(self, ctx: EffectContext) -> None:
        opponent = ctx.state.player(ctx.opponent)
        n = min(self.count, len(opponent.deck))
        if n <= 0:
            return
        top = list(opponent.deck[:n])
        pending = PendingSearchChoice(
            player_index=ctx.acting_player,
            zone="gen_deck_pick",
            source_indices=list(range(n)),
            card_ids=top,
            min_count=n,
            max_count=n,
            prompt=f"相手の山札の上{n}枚を見て、戻す順番に選ぶ(最初に選んだカードが一番上)",
            shuffle_after=False,
            all_card_ids=list(top),
            destination="deck_top_no_shuffle",
            reveal_to_opponent=False,
            custom_data={"op": "opp_deck_reorder", "n": n},
        )
        pending.cont_source_pokemon = ctx.source_pokemon
        pending.cont_source_card_id = ctx.source_card_id
        ctx.state.pending_search_choice = pending


@dataclass(frozen=True)
class LookOpponentDeckTopMayShuffle(Effect):
    """相手の山札の一番上のカードを見て、そのあと相手に山札をシャッフルさせてもよい(Mine)。"""

    def execute(self, ctx: EffectContext) -> None:
        opponent = ctx.state.player(ctx.opponent)
        if not opponent.deck:
            return
        pending = PendingSearchChoice(
            player_index=ctx.acting_player,
            zone="gen_deck_pick",
            source_indices=[0],
            card_ids=[opponent.deck[0]],
            min_count=0,
            max_count=1,
            prompt="相手の山札の一番上を見た。選ぶと相手は山札をシャッフルする(選ばなければそのまま)",
            shuffle_after=False,
            all_card_ids=[opponent.deck[0]],
            reveal_to_opponent=False,
            custom_data={"op": "opp_deck_peek_shuffle"},
        )
        pending.cont_source_pokemon = ctx.source_pokemon
        pending.cont_source_card_id = ctx.source_card_id
        ctx.state.pending_search_choice = pending


# ---------------------------------------------------------------------------------------------
# 解決(engine.rules_engineから呼ばれる)
# ---------------------------------------------------------------------------------------------
@dataclass
class GenericResult:
    """汎用選択の解決結果。consumed_remaining: choice.remaining_scriptを自分で実行したか。last_attach_succeeded: 直近のエネルギー添付が
    実際に行われたか(続きのスクリプトのctxに引き継ぐ)。"""

    consumed_remaining: bool = False
    last_attach_succeeded: bool = False


def resolve_generic_zone(state, card_db, choice, selected: list[int], action) -> GenericResult:
    """gen_*系zoneの選択を解決する。呼び出し側が事前にstate.pending_search_choice=Noneにしている。"""
    ctx = _cont_ctx(state, card_db, choice)
    ctx.target_bench_index = choice.cont_target_bench_index
    ctx.effect_source = choice.effect_source
    consumed = _resolve_generic_zone_inner(state, card_db, choice, selected, action, ctx)
    return GenericResult(bool(consumed), ctx.last_attach_succeeded)


def _resolve_generic_zone_inner(state, card_db, choice, selected: list[int], action, ctx) -> bool:
    custom = choice.custom_data if isinstance(choice.custom_data, dict) else {}
    op = custom.get("op")
    then_end_turn = choice.then_end_turn
    player = state.player(choice.player_index)

    handler = GENERIC_OP_HANDLERS.get(op)
    if handler is not None:
        return bool(handler(state, card_db, choice, selected, action, ctx, custom))

    if op == "pick_then":
        if selected:
            effect = custom["effect"]
            effect.apply(ctx, choice.source_indices[selected[0]])
            if effect.then:
                from effects.interpreter import run_script

                run_script(tuple(effect.then), ctx)
        return False

    if op == "attach_pick_target":
        spec = custom["spec"]
        if not selected:
            _attach_finish(ctx, spec)
            return
        slot = choice.source_indices[selected[0]]
        mon = _mon_at(player, slot)
        src = _zone_cards(player, spec["source"])
        limit = spec.get("deck_limit")
        eligible = [i for i, cid in enumerate(src) if _energy_ok(card_db.get(cid), spec) and (limit is None or i < limit)]
        if mon is None or not eligible:
            _attach_finish(ctx, spec)
            return
        _attach_pick_card(ctx, spec, custom["remaining"], slot, mon, tuple(custom.get("used", ())), eligible, then_end_turn)
        return

    if op == "mv_pick_source":
        if not selected:
            ctx.last_attach_succeeded = bool(custom["spec"].get("moved"))
            return
        mv_pick_energy(ctx, custom["spec"], choice.source_indices[selected[0]], then_end_turn)
        return

    if op == "mv_pick_energy":
        if not selected:
            return
        mv_pick_dest(ctx, custom["spec"], custom["source_slot"], choice.source_indices[selected[0]], then_end_turn)
        return

    if op == "mv_pick_dest":
        if not selected:
            return
        _mv_do_move(ctx, custom["spec"], custom["source_slot"], custom["energy_index"], choice.source_indices[selected[0]], then_end_turn)
        return

    if op == "either_type_discard":
        if not selected:
            return
        _discard_all_type_then_damage(ctx, custom["types"][choice.source_indices[selected[0]]], custom["per"])
        return

    if op == "hand_pick":
        opponent = state.player(state.opponent_index(choice.player_index))
        picked_ids: list[str] = []
        dest = custom.get("dest", "discard")
        for idx in sorted((choice.source_indices[pos] for pos in selected), reverse=True):
            if 0 <= idx < len(opponent.hand):
                picked_ids.append(opponent.hand[idx] if dest == "stay" else opponent.hand.pop(idx))  # "stay"=相手の手札に残したまま(選ぶだけ)
        for cid in picked_ids:
            if dest == "stay":
                continue
            if dest == "discard":
                opponent.discard.append(cid)
            elif dest == "bottom":
                opponent.deck.append(cid)
            else:  # shuffle_in
                opponent.deck.append(cid)
        if picked_ids and dest == "shuffle_in":
            state.rng.shuffle(opponent.deck)
        if picked_ids:
            state.add_log(f"相手の手札から{', '.join(picked_ids)}を選んだ")
        ctx.last_picked_card_ids = tuple(picked_ids)
        script = tuple(choice.remaining_script)
        if not picked_ids:
            script = tuple(custom.get("then_if_none_effects", ())) + tuple(choice.remaining_script)[custom.get("then_len", 0):]
        from effects.interpreter import run_script

        run_script(script, ctx)
        return True

    if op == "discard_board_energy_damage":
        entries = custom["entries"]
        picked = sorted((entries[choice.source_indices[pos]] for pos in selected), key=lambda t: (t[0], t[1]), reverse=True)
        for slot, ei in picked:
            mon = _mon_at(player, slot)
            if mon is not None and 0 <= ei < len(mon.attached_energy):
                player.discard.append(mon.attached_energy.pop(ei))
        DealDamage(custom.get("base", 0) + custom["per"] * len(picked)).execute(ctx)
        return False

    if op == "attach_card_to_target":
        slot = choice.source_indices[selected[0]] if selected else 0
        mon = _mon_at(player, slot)
        card_id = custom["card_id"]
        if mon is None:
            player.discard.append(card_id)
        else:
            mon.attached_energy.append(card_id)
            ctx.last_attach_succeeded = True
            state.add_log(f"トラッシュした{card_id}を{mon.card_id}につけた")
        return False

    if op == "damage_own_bench":
        for pos in selected:
            mon = _mon_at(player, choice.source_indices[pos])
            if mon is not None:
                mon.damage += custom["amount"]
        state.add_log(f"自分のベンチポケモン{len(selected)}匹に{custom['amount']}ダメージ")
        return False

    if op == "move_all_counters_to_defender":
        from effects.era_primitives_c import MoveAllDamageCountersToDefender

        _, defender = _defender(ctx)
        source = _mon_at(player, choice.source_indices[selected[0]]) if selected else None
        if defender is not None:
            MoveAllDamageCountersToDefender._move(ctx, source, defender)
        return False

    if op == "move_one_counter_to_opponent":
        opponent = state.player(state.opponent_index(choice.player_index))
        source = _mon_at(player, choice.source_indices[selected[0]]) if selected else None
        target = _mon_at(opponent, custom["target_slot"])
        if source is not None and target is not None and source.damage > 0:
            source.remove_counters(10)
            target.damage += 10
            state.add_log("ダメカン1個を相手のポケモンに移した")
        return False

    if op in ("ctr_pick_source", "ctr_pick_dest"):
        from effects.era_primitives_e import ctr_after_dest, ctr_after_source

        if not selected:
            return False
        slot = choice.source_indices[selected[0]]
        if op == "ctr_pick_source":
            ctr_after_source(ctx, custom["spec"], custom["remaining"], slot, then_end_turn)
        else:
            ctr_after_dest(ctx, custom["spec"], custom["remaining"], custom["source_slot"], slot, then_end_turn)
        return False

    if op == "opp_deck_reorder":
        opponent = state.player(state.opponent_index(choice.player_index))
        n = custom.get("n", 0)
        ordered_positions = list(dict.fromkeys(action.selected_indices))
        top = opponent.deck[:n]
        new_top = [top[p] for p in ordered_positions if 0 <= p < len(top)]
        if len(new_top) == len(top):
            opponent.deck[:n] = new_top
        state.add_log("相手の山札の上を並べ替えた")
        return

    if op == "opp_deck_peek_shuffle":
        opponent = state.player(state.opponent_index(choice.player_index))
        if selected:
            state.rng.shuffle(opponent.deck)
            state.add_log("相手は山札をシャッフルした")
        return


def resolve_generic_continue(state, card_db, choice, picked_card_ids: list[str]) -> GenericResult:
    """手札/トラッシュ/山札の通常zoneで、mode="gen_continue"の選択が確定した後の続き。"""
    custom = choice.custom_data if isinstance(choice.custom_data, dict) else {}
    ctx = _cont_ctx(state, card_db, choice)
    ctx.effect_source = choice.effect_source
    ctx.last_attach_succeeded = bool(picked_card_ids)
    continue_handler = GENERIC_CONTINUE_HANDLERS.get(custom.get("op"))
    if continue_handler is not None:
        continue_handler(ctx, choice, custom, picked_card_ids)
        return GenericResult(False, ctx.last_attach_succeeded)
    if custom.get("op") == "attach_next":
        spec = custom["spec"]
        if spec.get("distinct_energy_types"):
            spec = dict(spec)
            spec["exclude_types"] = list(spec.get("exclude_types", ())) + [
                t for cid in picked_card_ids if (t := card_db.get(cid).basic_energy_type) is not None
            ]
        attach_generic_next(ctx, spec, custom["remaining"], custom["slot"], tuple(custom.get("used", ())), choice.then_end_turn)
    elif custom.get("op") == "distinct_evolution_next":
        from effects.era_primitives_c import distinct_evolution_search_step

        types = tuple(custom.get("picked_types", ()))
        for cid in picked_card_ids:
            card = card_db.get(cid)
            if card is not None:
                types = types + tuple(card.types)
        if picked_card_ids:
            distinct_evolution_search_step(ctx, custom["evolves_from"], custom["remaining"], types)
        else:
            state.rng.shuffle(state.player(choice.player_index).deck)
    return GenericResult(False, ctx.last_attach_succeeded)
