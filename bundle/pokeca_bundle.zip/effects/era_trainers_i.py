"""サン&ムーン期(SM)のグッズ/サポートのうち、文面の自動生成(generate_effects_batch17.py)では実装できなかったものの実装(2026-10-07)。

effects/era_trainer_specs.py のキーとカードIDの対応(effects/generated_era_trainer_ids.py)を使い、install()が
effects/era_trainers.py の reg(キー, スクリプト, ゲート) に登録する(era_trainers.install()から呼ばれる)。
選択を伴う効果は、これまでと同じく PendingSearchChoice(zone="gen_*" / 通常zone+mode="gen_continue")とGENERIC_OP_HANDLERSで解決する。
"""

from __future__ import annotations

from dataclasses import dataclass

from effects.context import EffectContext
from effects.generated_era_trainer_ids import IDS
from effects.primitives import Draw, Effect, SearchDeckMultiCriteria, _attacker_player, _trigger_search_choice
from engine.state import PendingSearchChoice


def _ids(key: str) -> tuple:
    return tuple(card_id for card_id, _tag in IDS.get(key, ()))


def _matches(ctx: EffectContext, card_id: str, criterion: str) -> bool:
    c = ctx.card_db.get(card_id)
    return c is not None and (criterion == "any" or SearchDeckMultiCriteria._matches(c, criterion))


def _numeric_choice(ctx: EffectContext, player_index: int, labels: tuple, op: str, prompt: str, **custom) -> None:
    """「0枚〜N枚のうち何枚か」のような数や選択肢を、ラベル付きの選択(gen_pokemon_pick)で選ばせる。選んだ番号は解決処理にselected[0]として渡る。"""
    ctx.state.pending_search_choice = PendingSearchChoice(
        player_index=player_index,
        zone="gen_pokemon_pick",
        source_indices=list(range(len(labels))),
        card_ids=list(labels),
        min_count=1,
        max_count=1,
        prompt=prompt,
        shuffle_after=False,
        all_card_ids=list(labels),
        custom_data={"op": op, "user": ctx.acting_player, **custom},
        effect_source=ctx.effect_source,
        cont_source_pokemon=ctx.source_pokemon,
        cont_source_card_id=ctx.source_card_id,
    )


# ---------------------------------------------------------------------------------------------
# 手札・山札・サイド
# ---------------------------------------------------------------------------------------------
@dataclass(frozen=True)
class DrawFromBottom(Effect):
    """山札の下からcount枚引く(ルッカー)。"""

    count: int

    def execute(self, ctx: EffectContext) -> None:
        player = _attacker_player(ctx)
        for _ in range(self.count):
            if not player.deck:
                break
            player.hand.append(player.deck.pop())


@dataclass(frozen=True)
class DrawPerOwnDiscardNamed(Effect):
    """base枚引く。そのあと、自分のトラッシュにある、指定の名前のカード1枚につきper枚引く(ナタネ等)。"""

    base: int
    per: int
    name: str

    def execute(self, ctx: EffectContext) -> None:
        player = _attacker_player(ctx)
        n = sum(1 for cid in player.discard if (c := ctx.card_db.get(cid)) is not None and c.name == self.name)
        Draw(self.base + self.per * n).execute(ctx)


@dataclass(frozen=True)
class EachPlayerShuffleHandDrawSame(Effect):
    """おたがいに、手札の枚数を数え、手札を山札に戻してシャッフルし、その枚数ぶん引く(ウィケ)。"""

    def execute(self, ctx: EffectContext) -> None:
        for side in (ctx.acting_player, ctx.opponent):
            player = ctx.state.player(side)
            n = len(player.hand)
            player.deck.extend(player.hand)
            player.hand = []
            ctx.rng.shuffle(player.deck)
            for _ in range(n):
                if not player.deck:
                    break
                player.hand.append(player.deck.pop(0))


@dataclass(frozen=True)
class IlimaEffect(Effect):
    """おたがいに、手札を山札に戻してシャッフルし、コインを1回投げる。オモテならそのプレイヤーは6枚、ウラなら3枚引く(イリマ)。"""

    heads: int = 6
    tails: int = 3

    def execute(self, ctx: EffectContext) -> None:
        for side in (ctx.acting_player, ctx.opponent):
            player = ctx.state.player(side)
            player.deck.extend(player.hand)
            player.hand = []
            ctx.rng.shuffle(player.deck)
            is_heads = ctx.rng.random() < 0.5
            ctx.log(f"player{side} のコイン: {'オモテ' if is_heads else 'ウラ'}")
            for _ in range(self.heads if is_heads else self.tails):
                if not player.deck:
                    break
                player.hand.append(player.deck.pop(0))


@dataclass(frozen=True)
class RotomDexEffect(Effect):
    """自分のサイドの枚数を数え、サイドを全て山札に戻してシャッフルする。そのあと、その枚数を山札の上から取って新しいサイド(裏向き)にする(ロトムずかん)。"""

    def execute(self, ctx: EffectContext) -> None:
        player = _attacker_player(ctx)
        n = len(player.prizes)
        if n == 0:
            return
        player.deck.extend(player.prizes)
        player.prizes = []
        ctx.rng.shuffle(player.deck)
        player.prizes = [player.deck.pop(0) for _ in range(min(n, len(player.deck)))]
        ctx.log(f"サイド{n}枚を山札に戻してシャッフルし、山札の上から{len(player.prizes)}枚を新しいサイドにした")


@dataclass(frozen=True)
class ShuffleChosenHandCardsIntoDeckThenDraw(Effect):
    """手札からshuffle枚を選んで山札に戻してシャッフルする。そうしたらdraw枚引く(ビルのメンテナンス)。手札が足りなければ何もしない。"""

    shuffle: int
    draw: int

    def execute(self, ctx: EffectContext) -> None:
        player = _attacker_player(ctx)
        if len(player.hand) < self.shuffle:
            return
        _trigger_search_choice(
            ctx, player, "hand", lambda c: True, self.shuffle, f"山札に戻す手札を{self.shuffle}枚選ぶ", shuffle_after=True,
            destination="deck", min_count=self.shuffle,
        )
        if ctx.state.pending_search_choice is not None:
            ctx.state.pending_search_choice.custom_data = {"mode": "gen_continue", "op": "draw_n", "n": self.draw}


@dataclass(frozen=True)
class DiscardHandCardsThenDrawPerCard(Effect):
    """手札から条件(criterion)に合うカードを最大max_count枚選んでトラッシュし、トラッシュした1枚につきper枚引く(ロクシー/ウルトラビースト調査隊)。"""

    criterion: str
    max_count: int
    per: int

    def execute(self, ctx: EffectContext) -> None:
        player = _attacker_player(ctx)
        eligible = [i for i, cid in enumerate(player.hand) if _matches(ctx, cid, self.criterion)]
        if not eligible:
            return
        ctx.state.pending_search_choice = PendingSearchChoice(
            player_index=ctx.acting_player,
            zone="gen_hand_pick",
            source_indices=eligible,
            card_ids=[player.hand[i] for i in eligible],
            min_count=0,
            max_count=min(self.max_count, len(eligible)),
            prompt="トラッシュする手札を選ぶ(選ばなくてもよい)",
            shuffle_after=False,
            all_card_ids=[player.hand[i] for i in eligible],
            custom_data={"op": "discard_hand_draw_per", "per": self.per},
            effect_source=ctx.effect_source,
            cont_source_pokemon=ctx.source_pokemon,
            cont_source_card_id=ctx.source_card_id,
        )


def _op_discard_hand_draw_per(state, card_db, choice, selected, action, ctx, custom) -> bool:
    player = state.player(choice.player_index)
    n = 0
    for pos in sorted((choice.source_indices[p] for p in selected), reverse=True):
        if 0 <= pos < len(player.hand):
            player.discard.append(player.hand.pop(pos))
            n += 1
    if n:
        Draw(custom["per"] * n).execute(ctx)
    return False


@dataclass(frozen=True)
class RollerSkaterEffect(Effect):
    """手札を1枚トラッシュする。そうしたら2枚引く。トラッシュしたのがエネルギーなら、さらに2枚引く(ローラースケーター)。"""

    draw: int = 2
    bonus: int = 2

    def execute(self, ctx: EffectContext) -> None:
        player = _attacker_player(ctx)
        if not player.hand:
            return
        ctx.state.pending_search_choice = PendingSearchChoice(
            player_index=ctx.acting_player,
            zone="gen_hand_pick",
            source_indices=list(range(len(player.hand))),
            card_ids=list(player.hand),
            min_count=1,
            max_count=1,
            prompt="トラッシュする手札を1枚選ぶ",
            shuffle_after=False,
            all_card_ids=list(player.hand),
            custom_data={"op": "roller_skater", "draw": self.draw, "bonus": self.bonus},
            effect_source=ctx.effect_source,
            cont_source_pokemon=ctx.source_pokemon,
            cont_source_card_id=ctx.source_card_id,
        )


def _op_roller_skater(state, card_db, choice, selected, action, ctx, custom) -> bool:
    player = state.player(choice.player_index)
    if not selected:
        return False
    pos = choice.source_indices[selected[0]]
    if not 0 <= pos < len(player.hand):
        return False
    card_id = player.hand.pop(pos)
    player.discard.append(card_id)
    card = card_db.get(card_id)
    Draw(custom["draw"] + (custom["bonus"] if card is not None and card.is_energy else 0)).execute(ctx)
    return False


@dataclass(frozen=True)
class EachPlayerMayDrawUpTo(Effect):
    """おたがいに、山札から最大count枚まで好きな枚数を引いてよい(使った側が先)(エリカ)。"""

    count: int

    def execute(self, ctx: EffectContext) -> None:
        labels = tuple(f"{n}枚引く" for n in range(self.count + 1))
        _numeric_choice(ctx, ctx.acting_player, labels, "each_may_draw", "山札から何枚引くか選ぶ(最大%d枚)" % self.count, next_player=ctx.opponent, count=self.count)


def _op_each_may_draw(state, card_db, choice, selected, action, ctx, custom) -> bool:
    player = state.player(choice.player_index)
    n = choice.source_indices[selected[0]] if selected else 0
    for _ in range(n):
        if not player.deck:
            break
        player.hand.append(player.deck.pop(0))
    state.add_log(f"player{choice.player_index} は山札を{n}枚引いた")
    nxt = custom.get("next_player")
    if nxt is not None and nxt != choice.player_index:
        labels = tuple(f"{k}枚引く" for k in range(custom["count"] + 1))
        state.pending_search_choice = PendingSearchChoice(
            player_index=nxt,
            zone="gen_pokemon_pick",
            source_indices=list(range(len(labels))),
            card_ids=list(labels),
            min_count=1,
            max_count=1,
            prompt="山札から何枚引くか選ぶ(最大%d枚)" % custom["count"],
            shuffle_after=False,
            all_card_ids=list(labels),
            custom_data={"op": "each_may_draw", "user": custom["user"], "next_player": None, "count": custom["count"]},
            effect_source=choice.effect_source,
            then_end_turn=choice.then_end_turn,
        )
    return False


@dataclass(frozen=True)
class TormentingSprayEffect(Effect):
    """相手の手札から無作為に1枚を選び、相手はそのカードを公開する。サポートならトラッシュする(ひきさくスプレー)。"""

    def execute(self, ctx: EffectContext) -> None:
        opponent = ctx.state.player(ctx.opponent)
        if not opponent.hand:
            return
        idx = ctx.rng.randrange(len(opponent.hand))
        card_id = opponent.hand[idx]
        ctx.reveal("相手の手札から選んだカード", [card_id])
        card = ctx.card_db.get(card_id)
        if card is not None and card.is_supporter:
            opponent.discard.append(opponent.hand.pop(idx))
            ctx.log("公開されたサポートをトラッシュした")


@dataclass(frozen=True)
class DiscardTopThenTakeKind(Effect):
    """山札の上からn枚をトラッシュする。そのうち条件(criterion)に合うカードを全て手札に加える(クレイ)。"""

    n: int
    criterion: str

    def execute(self, ctx: EffectContext) -> None:
        player = _attacker_player(ctx)
        top = [player.deck.pop(0) for _ in range(min(self.n, len(player.deck)))]
        taken = [cid for cid in top if _matches(ctx, cid, self.criterion)]
        player.discard.extend(cid for cid in top if not _matches(ctx, cid, self.criterion))
        player.hand.extend(taken)
        ctx.log(f"山札の上から{len(top)}枚をトラッシュし、そのうち{len(taken)}枚を手札に加えた")


@dataclass(frozen=True)
class DiscardTopThenAttachEnergyToBenched(Effect):
    """山札の上からn枚をトラッシュする。そのうち基本エネルギーを、自分のベンチの(ptypeの)ポケモン1匹につける(Nのけつい)。"""

    n: int
    ptype: str

    def execute(self, ctx: EffectContext) -> None:
        player = _attacker_player(ctx)
        top = [player.deck.pop(0) for _ in range(min(self.n, len(player.deck)))]
        energies = [cid for cid in top if (c := ctx.card_db.get(cid)) is not None and c.is_energy and not c.is_special_energy]
        rest = list(top)
        for cid in energies:
            rest.remove(cid)
        player.discard.extend(rest)
        ctx.log(f"山札の上から{len(top)}枚をトラッシュした")
        targets = [
            (i + 1, m) for i, m in enumerate(player.bench)
            if (c := ctx.card_db.get(m.card_id)) is not None and self.ptype in c.types
        ]
        if not energies or not targets:
            player.discard.extend(energies)
            return
        if len(targets) == 1:
            targets[0][1].attached_energy.extend(energies)
            ctx.log(f"基本エネルギー{len(energies)}枚を{targets[0][1].card_id}につけた")
            return
        ctx.state.pending_search_choice = PendingSearchChoice(
            player_index=ctx.acting_player,
            zone="gen_pokemon_pick",
            source_indices=[s for s, _ in targets],
            card_ids=[m.card_id for _, m in targets],
            min_count=1,
            max_count=1,
            prompt="エネルギーをつけるベンチのポケモンを選ぶ",
            shuffle_after=False,
            all_card_ids=[m.card_id for _, m in targets],
            custom_data={"op": "attach_list_to_target", "energies": tuple(energies)},
            effect_source=ctx.effect_source,
            cont_source_pokemon=ctx.source_pokemon,
            cont_source_card_id=ctx.source_card_id,
        )


def _op_attach_list_to_target(state, card_db, choice, selected, action, ctx, custom) -> bool:
    from effects.era_primitives_b import _mon_at

    player = state.player(choice.player_index)
    mon = _mon_at(player, choice.source_indices[selected[0]]) if selected else None
    if mon is None:
        player.discard.extend(custom["energies"])
        return False
    mon.attached_energy.extend(custom["energies"])
    state.add_log(f"基本エネルギー{len(custom['energies'])}枚を{mon.card_id}につけた")
    return False


@dataclass(frozen=True)
class SearchDeckBasicDistinctTypesToBench(Effect):
    """山札から、タイプの違うたねポケモンを最大count匹まで選んでベンチに出す(オーキド博士のそなえ)。1匹ずつ、すでに選んだタイプは選べない。"""

    count: int
    excluded: tuple = ()
    to_hand: bool = False  # Trueなら、たねポケモンに限らず、手札に加える(サビーナ&ブライセン)

    def execute(self, ctx: EffectContext) -> None:
        player = _attacker_player(ctx)
        excluded = set(self.excluded)

        def ok(c):
            return c is not None and c.is_pokemon and (self.to_hand or c.is_basic) and not (set(c.types) & excluded)

        _trigger_search_choice(
            ctx, player, "deck", ok, 1, f"山札から、{'/'.join(sorted(excluded)) or 'どれでも'}以外のタイプのたねポケモンを1匹ベンチに出す(最大{self.count}匹)",
            shuffle_after=True, destination="bench",
        )
        if ctx.state.pending_search_choice is not None and self.count > 1:
            ctx.state.pending_search_choice.custom_data = {
                "mode": "gen_continue", "op": "distinct_basic_next", "remaining": self.count - 1, "picked_types": tuple(sorted(excluded)),
                "to_hand": self.to_hand,
            }


def _continue_distinct_basic_next(ctx, choice, custom, picked_card_ids) -> None:
    types = set(custom.get("picked_types", ()))
    for cid in picked_card_ids:
        card = ctx.card_db.get(cid)
        if card is not None:
            types |= set(card.types)
    if picked_card_ids and custom.get("remaining", 0) > 0:
        SearchDeckBasicDistinctTypesToBench(count=custom["remaining"], excluded=tuple(sorted(types)), to_hand=bool(custom.get("to_hand"))).execute(ctx)


@dataclass(frozen=True)
class LookTopNTake(Effect):
    """山札の上(from_top=Falseなら下)からn枚を見て、条件(criterion)に合うカードをm枚(exact=Trueなら足りる限りちょうどm枚、Falseなら最大m枚)選んで手札に加える。
    残り(rest): "shuffle"=山札に戻してシャッフル / "discard"=トラッシュ / "reorder"=好きな順番で山札の上(下)に戻す。"""

    n: int
    m: int
    criterion: str = "any"
    exact: bool = False
    rest: str = "shuffle"
    from_top: bool = True

    def execute(self, ctx: EffectContext) -> None:
        player = _attacker_player(ctx)
        seen = player.deck[: self.n] if self.from_top else player.deck[-self.n:] if self.n else []
        if not seen:
            return
        eligible = [i for i, cid in enumerate(seen) if _matches(ctx, cid, self.criterion)]
        if not eligible:
            _look_top_take_finish(ctx.state, ctx.rng, player, len(seen), self.from_top, [], self.rest)
            if self.rest == "reorder" and self.from_top and len(seen) > 1:
                from effects.primitives import LookTopNReorderOnTop

                LookTopNReorderOnTop(len(seen)).execute(ctx)
            return
        max_count = min(self.m, len(eligible))
        ctx.state.pending_search_choice = PendingSearchChoice(
            player_index=ctx.acting_player,
            zone="gen_deck_pick",
            source_indices=eligible,
            card_ids=[seen[i] for i in eligible],
            min_count=max_count if self.exact else 0,
            max_count=max_count,
            prompt=f"山札の{'上' if self.from_top else '下'}{len(seen)}枚から手札に加えるカードを選ぶ",
            shuffle_after=False,
            all_card_ids=list(seen),
            custom_data={
                "op": "look_top_take", "n": len(seen), "rest": self.rest, "from_top": self.from_top,
            },
            effect_source=ctx.effect_source,
            cont_source_pokemon=ctx.source_pokemon,
            cont_source_card_id=ctx.source_card_id,
        )


def _look_top_take_finish(state, rng, player, n: int, from_top: bool, taken_positions: list[int], rest: str) -> list[str]:
    """見たn枚のうち、選ばれた位置のカードを手札に加え、残りをrestの通りに片づける。手札に加えたcard_idの並びを返す。"""
    seen_slice = slice(0, n) if from_top else slice(len(player.deck) - n, len(player.deck))
    seen = player.deck[seen_slice]
    del player.deck[seen_slice]
    taken = [seen[p] for p in taken_positions]
    left = [seen[p] for p in range(len(seen)) if p not in set(taken_positions)]
    player.hand.extend(taken)
    if rest == "discard":
        player.discard.extend(left)
    elif rest == "shuffle":
        player.deck.extend(left)
        rng.shuffle(player.deck)
    elif rest == "bottom_shuffle":
        rng.shuffle(left)
        player.deck.extend(left)  # 残りをシャッフルして、山札の下に置く(リカ)
    else:  # reorder(順番はここでは元の並びのまま。続けて並べ替えの選択を出す呼び出し側がいる)
        if from_top:
            player.deck[0:0] = left
        else:
            player.deck.extend(left)
    return taken


def _op_look_top_take(state, card_db, choice, selected, action, ctx, custom) -> bool:
    player = state.player(choice.player_index)
    n, rest, from_top = custom["n"], custom["rest"], custom["from_top"]
    positions = [choice.source_indices[p] for p in selected]
    _look_top_take_finish(state, state.rng, player, n, from_top, positions, rest)
    if rest == "reorder":
        left = n - len(positions)
        if left > 1 and from_top:
            from effects.primitives import LookTopNReorderOnTop

            LookTopNReorderOnTop(left).execute(ctx)
    state.add_log("山札から見たカードのうち、選んだカードを手札に加えた")
    return False


# ---------------------------------------------------------------------------------------------
# コイン・手札コスト・トラッシュ/サイドの操作
# ---------------------------------------------------------------------------------------------
@dataclass(frozen=True)
class FlipCoinsThenRepeat(Effect):
    """コインをcoins枚投げ、オモテ1枚につきeffectを1回行う(ティンバーボール/ルアーボール/デンキチャージャー)。"""

    coins: int
    effect: Effect

    def execute(self, ctx: EffectContext) -> None:
        from effects.interpreter import run_script

        heads = sum(1 for _ in range(self.coins) if ctx.rng.random() < 0.5)
        ctx.coin_heads_count = heads
        ctx.log(f"コイン{self.coins}枚: オモテ{heads}枚")
        if heads:
            run_script((self.effect,) * heads, ctx)


@dataclass(frozen=True)
class DiscardMatchingFromHand(Effect):
    """手札から条件(criterion)に合うカードをcount枚選んでトラッシュする(コストとして)。足りなければ何もしない。"""

    criterion: str
    count: int

    def execute(self, ctx: EffectContext) -> None:
        player = _attacker_player(ctx)
        _trigger_search_choice(
            ctx, player, "hand", lambda c: c is not None and (self.criterion == "any" or SearchDeckMultiCriteria._matches(c, self.criterion)),
            self.count, f"トラッシュする手札を{self.count}枚選ぶ", shuffle_after=False, destination="discard", min_count=self.count,
        )


@dataclass(frozen=True)
class DiscardNamedFromHand(Effect):
    """手札から、指定の名前のカードをそれぞれ1枚ずつトラッシュする(モルガン: ダナ・エビ・ニタ)。"""

    names: tuple

    def execute(self, ctx: EffectContext) -> None:
        player = _attacker_player(ctx)
        for name in self.names:
            for i, cid in enumerate(player.hand):
                c = ctx.card_db.get(cid)
                if c is not None and c.name == name:
                    player.discard.append(player.hand.pop(i))
                    break


@dataclass(frozen=True)
class PutHandCardsInLostZoneThenDraw(Effect):
    """手札からcount枚を選んでロストゾーンに置く。そうしたらdraw枚引く(ロストブレンダー)。"""

    count: int
    draw: int

    def execute(self, ctx: EffectContext) -> None:
        player = _attacker_player(ctx)
        _trigger_search_choice(
            ctx, player, "hand", lambda c: True, self.count, f"ロストゾーンに置く手札を{self.count}枚選ぶ", shuffle_after=False,
            destination="lost_zone", min_count=self.count,
        )
        if ctx.state.pending_search_choice is not None:
            ctx.state.pending_search_choice.custom_data = {"mode": "gen_continue", "op": "draw_n", "n": self.draw}


@dataclass(frozen=True)
class ReturnChosenOpponentDiscard(Effect):
    """相手のトラッシュから1枚を選んで、相手の手札(destination="hand")/山札の下("deck_bottom")に戻す(サプライズボックス/リターンラベル)。"""

    destination: str = "hand"

    def execute(self, ctx: EffectContext) -> None:
        opponent = ctx.state.player(ctx.opponent)
        if not opponent.discard:
            return
        ctx.state.pending_search_choice = PendingSearchChoice(
            player_index=ctx.acting_player,
            zone="gen_deck_pick",
            source_indices=list(range(len(opponent.discard))),
            card_ids=list(opponent.discard),
            min_count=1,
            max_count=1,
            prompt="相手のトラッシュから、戻すカードを1枚選ぶ",
            shuffle_after=False,
            all_card_ids=list(opponent.discard),
            custom_data={"op": "return_opponent_discard", "destination": self.destination},
            effect_source=ctx.effect_source,
        )


def _op_return_opponent_discard(state, card_db, choice, selected, action, ctx, custom) -> bool:
    opponent = state.player(1 - choice.player_index)
    if not selected:
        return False
    pos = choice.source_indices[selected[0]]
    if not 0 <= pos < len(opponent.discard):
        return False
    card_id = opponent.discard.pop(pos)
    destination = custom["destination"]
    {"hand": opponent.hand, "lost_zone": opponent.lost_zone}.get(destination, opponent.deck).append(card_id)
    state.add_log(f"相手のトラッシュから{card_id}を相手の{ {'hand': '手札', 'lost_zone': 'ロストゾーン'}.get(destination, '山札の下') }に送った")
    return False


@dataclass(frozen=True)
class PutDefenderEnergyOnTopOfDeck(Effect):
    """相手のバトルポケモンについているエネルギーを1枚(違う種類があれば選んで)、相手の山札の上に置く(ニタ)。"""

    def execute(self, ctx: EffectContext) -> None:
        from effects.era_attacks_h import _opp_energy_entries

        opponent = ctx.state.player(ctx.opponent)
        source_indices, card_ids = _opp_energy_entries(ctx, only_slot=0)
        if not card_ids:
            return
        if len(set(card_ids)) == 1:
            opponent.deck.insert(0, opponent.active.attached_energy.pop())
            return
        ctx.state.pending_search_choice = PendingSearchChoice(
            player_index=ctx.acting_player,
            zone="field_attachment",
            source_indices=source_indices,
            card_ids=card_ids,
            min_count=1,
            max_count=1,
            prompt="山札の上に置く相手のバトルポケモンのエネルギーを選ぶ",
            shuffle_after=False,
            all_card_ids=list(card_ids),
            destination="deck_top",
            effect_source=ctx.effect_source,
        )


@dataclass(frozen=True)
class RemoveAllAttackEffectsOnOwnSide(Effect):
    """自分と自分の場の全てのポケモンにかかっている、ワザの効果をすべて取り除く(チャネラー)。特殊状態は取り除かない。"""

    def execute(self, ctx: EffectContext) -> None:
        import dataclasses

        from engine.state import PlayerState, PokemonInPlay

        player = _attacker_player(ctx)
        for f in dataclasses.fields(PlayerState):
            if f.name.endswith(("_locked_until_turn", "_lock_until_turn")) and f.name != "gx_attacks_locked" and isinstance(getattr(player, f.name, None), int):
                setattr(player, f.name, 0)
        for mon in player.all_pokemon_in_play():
            for f in dataclasses.fields(PokemonInPlay):
                if f.name.endswith("_until_turn") and f.name not in ("became_active_turn",) and isinstance(mon.__dict__.get(f.name, 0), int):
                    mon.__dict__[f.name] = 0
        ctx.log("自分と自分のポケモンにかかっているワザの効果を全て取り除いた")


# ---------------------------------------------------------------------------------------------
# 「この番」の効果の印
# ---------------------------------------------------------------------------------------------
@dataclass(frozen=True)
class SetGxOverride(Effect):
    """この番、指定のポケモン("name:ジガルデGX"/"type:Water")は、GXワザを使ったあとでもGXワザを使える(ボニー/ミスティ&ロレイ)。"""

    entry: str

    def execute(self, ctx: EffectContext) -> None:
        _attacker_player(ctx).gx_override_this_turn.append(self.entry)


@dataclass(frozen=True)
class SetEndTurnDrawTo(Effect):
    """この番の終わりに、手札がn枚になるまで山札を引く(ブルーのたくらみ)。"""

    n: int

    def execute(self, ctx: EffectContext) -> None:
        _attacker_player(ctx).end_turn_draw_to = self.n


@dataclass(frozen=True)
class SetEndTurnHandLimit(Effect):
    """この番の終わりに、手札がthreshold枚以上なら、keep枚になるまで好きな手札を山札に戻す(リーリエの全力)。"""

    threshold: int
    keep: int

    def execute(self, ctx: EffectContext) -> None:
        _attacker_player(ctx).end_turn_hand_limit = (self.threshold, self.keep)


@dataclass(frozen=True)
class SetIgnoreDefenderEffectsForSubtype(Effect):
    """この番、指定のサブタイプのポケモンのワザのダメージは、相手のバトルポケモンにかかっている効果を受けない(ウルトラフォレスト カートボーイ)。"""

    subtype: str

    def execute(self, ctx: EffectContext) -> None:
        _attacker_player(ctx).ignore_defender_effects_subtype_this_turn = self.subtype


@dataclass(frozen=True)
class SetPlayedCardDestination(Effect):
    """いま使っているこのカード自身の行き先を指定する("hand"=手札に戻す)。coin=Trueならコインがオモテのときだけ(カヒリ)。"""

    destination: str
    coin: bool = False

    def execute(self, ctx: EffectContext) -> None:
        if self.coin:
            heads = ctx.rng.random() < 0.5
            ctx.log("コイン: " + ("オモテ" if heads else "ウラ"))
            if not heads:
                return
        ctx.state.played_card_destination = self.destination


# ---------------------------------------------------------------------------------------------
# サイドを見る(グラジオ/ビーストボール)
# ---------------------------------------------------------------------------------------------
@dataclass(frozen=True)
class LookAtPrizesTakeOne(Effect):
    """自分の裏向きのサイドを見て、条件(criterion)に合うカードを1枚(optional=Trueなら選ばなくてもよい)手札に加える。選んだら、このカード自身を
    サイドに混ぜてシャッフルする(グラジオ=必ず1枚/ビーストボール=ウルトラビーストを見つけたときだけ。見つけなければトラッシュ)。"""

    criterion: str = "any"
    optional: bool = False

    def execute(self, ctx: EffectContext) -> None:
        player = _attacker_player(ctx)
        eligible = [i for i, cid in enumerate(player.prizes) if _matches(ctx, cid, self.criterion)]
        if not eligible:
            return
        ctx.state.pending_search_choice = PendingSearchChoice(
            player_index=ctx.acting_player,
            zone="gen_deck_pick",
            source_indices=eligible,
            card_ids=[player.prizes[i] for i in eligible],
            min_count=0 if self.optional else 1,
            max_count=1,
            prompt="自分のサイドを見て、手札に加えるカードを1枚選ぶ" + ("(選ばなくてもよい)" if self.optional else ""),
            shuffle_after=False,
            all_card_ids=list(player.prizes),
            custom_data={"op": "prize_take_one"},
            effect_source=ctx.effect_source,
            cont_source_card_id=ctx.source_card_id,
        )
        ctx.state.played_card_destination = "prizes"  # 選んだらこのカードをサイドに混ぜる(選ばなければ_op側でトラッシュに戻す)


def _op_prize_take_one(state, card_db, choice, selected, action, ctx, custom) -> bool:
    player = state.player(choice.player_index)
    if not selected:
        # 選ばなかった: このカードはサイドに混ざらずトラッシュへ(使い終えた処理が先にサイドへ入れているので、取り出してトラッシュに移す)
        for i in range(len(player.prizes) - 1, -1, -1):
            if player.prizes[i] == choice.cont_source_card_id:
                player.take_prize(i)
                player.prizes_taken_this_turn -= 1
                player.discard.append(choice.cont_source_card_id)
                break
        player.reset_prize_marks()
        return False
    pos = choice.source_indices[selected[0]]
    if 0 <= pos < len(player.prizes):
        player.hand.append(player.take_prize(pos))
        player.prizes_taken_this_turn -= 1  # 「サイドを取った」ではない(手札に加えただけ)
        player.reset_prize_marks()
        state.rng.shuffle(player.prizes)
        state.add_log("サイドから1枚を手札に加え、このカードをサイドに混ぜてシャッフルした")
    return False


# ---------------------------------------------------------------------------------------------
# 選択の連鎖(効果の続きを、あとから作られる選択待ちの後ろにつなぐ)
# ---------------------------------------------------------------------------------------------
def _run_chain(state, ctx, choice, script: tuple) -> bool:
    """解決処理の中でscriptを実行する。新しい選択待ちが作られたら、元の選択の残り(remaining_script)をその後ろにつけて、残りは消費済みとして返す。"""
    from effects.interpreter import run_script

    run_script(tuple(script), ctx)
    if state.pending_search_choice is not None:
        pending = state.pending_search_choice
        pending.remaining_script = tuple(pending.remaining_script) + tuple(choice.remaining_script)
        pending.then_end_turn = choice.then_end_turn
        return True
    return False


@dataclass(frozen=True)
class OptionalDiscardBonus(Effect):
    """「このカードを使うとき、手札からほかのカードをn枚トラッシュしてもよい。そうしたら、(追加の効果)」型のTAG TEAMサポート。
    はい: n枚トラッシュしてからupgradedを実行 / いいえ(または手札が足りない): baseだけ実行。"""

    n: int
    base: tuple
    upgraded: tuple

    def execute(self, ctx: EffectContext) -> None:
        from effects.interpreter import run_script

        player = _attacker_player(ctx)
        if len(player.hand) < self.n:
            run_script(tuple(self.base), ctx)
            return
        labels = (f"はい: 手札を{self.n}枚トラッシュして、追加の効果を得る", "いいえ")
        _numeric_choice(ctx, ctx.acting_player, labels, "optional_discard_bonus", f"手札をほかに{self.n}枚トラッシュしますか?", n=self.n, base=tuple(self.base), upgraded=tuple(self.upgraded))


def _op_optional_discard_bonus(state, card_db, choice, selected, action, ctx, custom) -> bool:
    from effects.primitives import DiscardCardsFromHand

    if selected and choice.source_indices[selected[0]] == 0:
        return _run_chain(state, ctx, choice, (DiscardCardsFromHand(custom["n"]),) + tuple(custom["upgraded"]))
    return _run_chain(state, ctx, choice, tuple(custom["base"]))


@dataclass(frozen=True)
class CynthiaCaitlinEffect(Effect):
    """サポートをトラッシュから手札に加える(このカード・この効果でトラッシュしたカードは選べない)。このカードを使うとき、手札をほかに1枚トラッシュしてもよく、
    そうしたら3枚引く(シロナ&カトレア)。"""

    def execute(self, ctx: EffectContext) -> None:
        player = _attacker_player(ctx)
        if not player.hand:
            self._take_supporter(ctx, ())
            return
        _numeric_choice(ctx, ctx.acting_player, ("はい: 手札を1枚トラッシュして、3枚引く", "いいえ"), "cc_decide", "手札をほかに1枚トラッシュして3枚引きますか?")

    @staticmethod
    def _take_supporter(ctx: EffectContext, excluded_cards: tuple) -> None:
        player = _attacker_player(ctx)
        left = list(excluded_cards)
        eligible = []
        for i, cid in enumerate(player.discard):
            c = ctx.card_db.get(cid)
            if c is None or not c.is_supporter or c.name == "Cynthia & Caitlin":
                continue
            if cid in left:  # この効果でトラッシュしたカードは選べない(同じカードIDが元からトラッシュにあれば、その枚数ぶんは選べる)
                left.remove(cid)
                continue
            eligible.append(i)
        if not eligible:
            return
        ctx.state.pending_search_choice = PendingSearchChoice(
            player_index=ctx.acting_player,
            zone="gen_deck_pick",
            source_indices=eligible,
            card_ids=[player.discard[i] for i in eligible],
            min_count=1,
            max_count=1,
            prompt="トラッシュから手札に加えるサポートを選ぶ",
            shuffle_after=False,
            all_card_ids=[player.discard[i] for i in eligible],
            custom_data={"op": "cc_take"},
            effect_source=ctx.effect_source,
        )


def _op_cc_decide(state, card_db, choice, selected, action, ctx, custom) -> bool:
    player = state.player(choice.player_index)
    if selected and choice.source_indices[selected[0]] == 0 and player.hand:
        state.pending_search_choice = PendingSearchChoice(
            player_index=choice.player_index,
            zone="gen_hand_pick",
            source_indices=list(range(len(player.hand))),
            card_ids=list(player.hand),
            min_count=1,
            max_count=1,
            prompt="トラッシュする手札を1枚選ぶ",
            shuffle_after=False,
            all_card_ids=list(player.hand),
            custom_data={"op": "cc_discard"},
            effect_source=choice.effect_source,
            then_end_turn=choice.then_end_turn,
        )
        return True
    CynthiaCaitlinEffect._take_supporter(ctx, ())
    if state.pending_search_choice is not None:
        state.pending_search_choice.then_end_turn = choice.then_end_turn
    return True


def _op_cc_discard(state, card_db, choice, selected, action, ctx, custom) -> bool:
    player = state.player(choice.player_index)
    discarded = ()
    if selected:
        pos = choice.source_indices[selected[0]]
        if 0 <= pos < len(player.hand):
            card_id = player.hand.pop(pos)
            player.discard.append(card_id)
            discarded = (card_id,)
            Draw(3).execute(ctx)
    CynthiaCaitlinEffect._take_supporter(ctx, discarded)
    return True


def _op_cc_take(state, card_db, choice, selected, action, ctx, custom) -> bool:
    player = state.player(choice.player_index)
    if selected:
        pos = choice.source_indices[selected[0]]
        if 0 <= pos < len(player.discard):
            player.hand.append(player.discard.pop(pos))
    return False


@dataclass(frozen=True)
class EachPlayerDiscardsBenchedDownTo(Effect):
    """おたがいに、ベンチのポケモンがn匹になるまで、(自分で選んで)ベンチのポケモンをトラッシュする。相手が先(ベルバ&ブライセンマン)。"""

    n: int
    first: str = "opponent"

    def execute(self, ctx: EffectContext) -> None:
        order = (ctx.opponent, ctx.acting_player) if self.first == "opponent" else (ctx.acting_player, ctx.opponent)
        self._step(ctx.state, ctx.card_db, ctx, order, 0)

    def _step(self, state, card_db, ctx, order, k) -> None:
        for idx in range(k, len(order)):
            side = order[idx]
            player = state.player(side)
            extra = len(player.bench) - self.n
            if extra <= 0:
                continue
            state.pending_search_choice = PendingSearchChoice(
                player_index=side,
                zone="gen_pokemon_pick",
                source_indices=[i + 1 for i in range(len(player.bench))],
                card_ids=[m.card_id for m in player.bench],
                min_count=extra,
                max_count=extra,
                prompt=f"トラッシュするベンチのポケモンを{extra}匹選ぶ(ベンチが{self.n}匹になるまで)",
                shuffle_after=False,
                all_card_ids=[m.card_id for m in player.bench],
                custom_data={"op": "bench_down_to", "n": self.n, "order": order, "next": idx + 1},
                effect_source=ctx.effect_source,
                cont_source_pokemon=ctx.source_pokemon,
                cont_source_card_id=ctx.source_card_id,
            )
            return


def _op_bench_down_to(state, card_db, choice, selected, action, ctx, custom) -> bool:
    player = state.player(choice.player_index)
    for slot in sorted((choice.source_indices[p] for p in selected), reverse=True):
        if 1 <= slot <= len(player.bench):
            mon = player.bench.pop(slot - 1)
            player.discard.extend(mon.evolution_history)
            player.discard.append(mon.card_id)
            player.discard.extend(mon.attached_energy)
            if mon.attached_tool:
                player.discard.append(mon.attached_tool)
    EachPlayerDiscardsBenchedDownTo(custom["n"])._step(state, card_db, ctx, custom["order"], custom["next"])
    if state.pending_search_choice is not None:
        state.pending_search_choice.remaining_script = tuple(state.pending_search_choice.remaining_script) + tuple(choice.remaining_script)
        state.pending_search_choice.then_end_turn = choice.then_end_turn
        return True
    return False


@dataclass(frozen=True)
class DiscardTopOfEachPlayersDeck(Effect):
    """おたがいの山札の上からn枚ずつトラッシュする。"""

    n: int

    def execute(self, ctx: EffectContext) -> None:
        for side in (ctx.acting_player, ctx.opponent):
            player = ctx.state.player(side)
            for _ in range(min(self.n, len(player.deck))):
                player.discard.append(player.deck.pop(0))


@dataclass(frozen=True)
class LysandrePrismEffect(Effect):
    """自分の場の炎ポケモン1匹につき、相手のトラッシュから(自分で選んで)カード1枚をロストゾーンに置く(ロストゾーン送り)(ライラ◇)。"""

    def execute(self, ctx: EffectContext) -> None:
        from effects.interpreter import run_script

        n = sum(1 for m in _attacker_player(ctx).all_pokemon_in_play() if (c := ctx.card_db.get(m.card_id)) is not None and "Fire" in c.types)
        if n:
            run_script((ReturnChosenOpponentDiscard(destination="lost_zone"),) * n, ctx)


@dataclass(frozen=True)
class FriendBallEffect(Effect):
    """山札から、相手の場のポケモンのどれかと同じタイプのポケモンを1枚探して手札に加える(フレンドボール)。"""

    def execute(self, ctx: EffectContext) -> None:
        types: set = set()
        for m in ctx.state.player(ctx.opponent).all_pokemon_in_play():
            c = ctx.card_db.get(m.card_id)
            if c is not None:
                types |= set(c.types)
        _trigger_search_choice(
            ctx, _attacker_player(ctx), "deck", lambda c: c is not None and c.is_pokemon and bool(set(c.types) & types), 1,
            "山札から、相手のポケモンと同じタイプのポケモンを探す",
        )


@dataclass(frozen=True)
class RemoveOpponentToolSpecialEnergyOrStadium(Effect):
    """相手のポケモンについているどうぐ・特殊エネルギー1枚、または場のスタジアム1枚を選んで、トラッシュ(destination="discard")/ロストゾーンに置く(destination="lost_zone")(ファバ/きけんなドリル)。"""

    destination: str = "lost_zone"

    def execute(self, ctx: EffectContext) -> None:
        from effects.primitives import _field_attachment_candidates

        source_indices, card_ids = _field_attachment_candidates(
            ctx.state, ctx.card_db, (ctx.opponent,), include_tool=True, energy_predicate=lambda c: c.is_special_energy, include_stadium=True
        )
        if not card_ids:
            ctx.log("対象にできるどうぐ・特殊エネルギー・スタジアムが無い")
            return
        ctx.state.pending_search_choice = PendingSearchChoice(
            player_index=ctx.acting_player,
            zone="field_attachment",
            source_indices=source_indices,
            card_ids=card_ids,
            min_count=1,
            max_count=1,
            prompt="相手のどうぐ・特殊エネルギー、または場のスタジアムを1枚選ぶ",
            shuffle_after=False,
            all_card_ids=list(card_ids),
            destination=self.destination,
            effect_source=ctx.effect_source,
        )


@dataclass(frozen=True)
class DevolveOwnToDeck(Effect):
    """自分の進化したポケモン1匹を選び、そのポケモンについている進化カードを好きな枚数(上のものから)山札に戻してシャッフルする。そのポケモンはこの番、進化できない
    (退化スプレーZ)。"""

    def execute(self, ctx: EffectContext) -> None:
        from effects.era_primitives_b import _slots

        player = _attacker_player(ctx)
        slots = [(s, m) for s, m in _slots(player) if m.evolution_history]
        if not slots:
            return
        ctx.state.pending_search_choice = PendingSearchChoice(
            player_index=ctx.acting_player,
            zone="gen_pokemon_pick",
            source_indices=[s for s, _ in slots],
            card_ids=[m.card_id for _, m in slots],
            min_count=1,
            max_count=1,
            prompt="退化させる進化したポケモンを選ぶ",
            shuffle_after=False,
            all_card_ids=[m.card_id for _, m in slots],
            custom_data={"op": "devolve_z_pick"},
            effect_source=ctx.effect_source,
            cont_source_pokemon=ctx.source_pokemon,
            cont_source_card_id=ctx.source_card_id,
        )


def _op_devolve_z_pick(state, card_db, choice, selected, action, ctx, custom) -> bool:
    from effects.era_primitives_b import _mon_at

    player = state.player(choice.player_index)
    slot = choice.source_indices[selected[0]] if selected else None
    mon = _mon_at(player, slot) if slot is not None else None
    if mon is None or not mon.evolution_history:
        return False
    labels = tuple(f"{k}枚(上の進化カードから)山札に戻す" for k in range(1, len(mon.evolution_history) + 1))
    if len(labels) == 1:
        _devolve_z_do(state, player, mon, 1)
        return False
    state.pending_search_choice = PendingSearchChoice(
        player_index=choice.player_index,
        zone="gen_pokemon_pick",
        source_indices=list(range(len(labels))),
        card_ids=list(labels),
        min_count=1,
        max_count=1,
        prompt="山札に戻す進化カードの枚数を選ぶ",
        shuffle_after=False,
        all_card_ids=list(labels),
        custom_data={"op": "devolve_z_count", "slot": slot},
        effect_source=choice.effect_source,
        then_end_turn=choice.then_end_turn,
    )
    return True


def _op_devolve_z_count(state, card_db, choice, selected, action, ctx, custom) -> bool:
    from effects.era_primitives_b import _mon_at

    player = state.player(choice.player_index)
    mon = _mon_at(player, custom["slot"])
    if mon is not None and selected:
        _devolve_z_do(state, player, mon, choice.source_indices[selected[0]] + 1)
    return False


def _devolve_z_do(state, player, mon, count: int) -> None:
    for _ in range(min(count, len(mon.evolution_history))):
        player.deck.append(mon.card_id)
        mon.card_id = mon.evolution_history.pop()
    state.rng.shuffle(player.deck)
    mon.no_evolve_until_turn = player.turns_taken  # そのポケモンはこの番、進化できない
    state.add_log(f"進化カードを{count}枚山札に戻してシャッフルした")


@dataclass(frozen=True)
class EvolveChosenOwnFromDeck(Effect):
    """自分のポケモン1匹を選び、山札から、そのポケモンから進化するカードを探して重ねて進化させる(ダスクストーン/ベストなリーフ/レッド&ブルー)。
    ptype=対象のタイプ、names=進化先の名前の限定、subtype_card=進化先のサブタイプ(GX等)、ignore_timing=最初の番/出したばかりのポケモンにも使える、
    twice=進化させたあと、さらに1回進化させる(ステージ1になっていれば)。"""

    ptype: str | None = None
    names: tuple = ()
    subtype_card: str | None = None
    ignore_timing: bool = False
    twice: bool = False
    bench_only: bool = False
    no_ability: bool = False  # 進化先は特性を持たないカードだけ(サルヴァトーレ)

    def _eligible(self, ctx: EffectContext, player, mon) -> bool:
        from cards.card_db import card_has_subtype
        from engine.legal_actions import _can_evolve_target

        target_card = ctx.card_db.get(mon.card_id)
        if target_card is None or (self.ptype and self.ptype not in target_card.types):
            return False
        for cid in set(player.deck):
            c = ctx.card_db.get(cid)
            if c is None or not c.is_pokemon or c.evolves_from != target_card.name:
                continue
            if self.names and c.name not in self.names:
                continue
            if self.subtype_card and not card_has_subtype(c, self.subtype_card):
                continue
            if self.no_ability and c.abilities:
                continue
            if self.ignore_timing or _can_evolve_target(ctx.state, mon, c, player, ctx.card_db):
                return True
        return False

    def execute(self, ctx: EffectContext) -> None:
        from effects.era_primitives_b import _slots

        player = _attacker_player(ctx)
        slots = [(s, m) for s, m in _slots(player) if not (self.bench_only and s == 0) and self._eligible(ctx, player, m)]
        if not slots:
            ctx.log("進化させられるポケモンがいない")
            return
        if len(slots) == 1:
            self._evolve(ctx, slots[0][1])
            return
        ctx.state.pending_search_choice = PendingSearchChoice(
            player_index=ctx.acting_player,
            zone="gen_pokemon_pick",
            source_indices=[s for s, _ in slots],
            card_ids=[m.card_id for _, m in slots],
            min_count=1,
            max_count=1,
            prompt="進化させるポケモンを選ぶ",
            shuffle_after=False,
            all_card_ids=[m.card_id for _, m in slots],
            custom_data={"op": "evolve_chosen_pick", "effect": self},
            effect_source=ctx.effect_source,
            cont_source_pokemon=ctx.source_pokemon,
            cont_source_card_id=ctx.source_card_id,
        )

    def _evolve(self, ctx: EffectContext, mon) -> None:
        from cards.card_db import card_has_subtype
        from effects.primitives import InstantEvolveEachTargetFromDeck, _evolve_in_place_from_deck

        player = _attacker_player(ctx)
        target_card = ctx.card_db.get(mon.card_id)
        indices = [
            i for i, cid in enumerate(player.deck)
            if (c := ctx.card_db.get(cid)) is not None and c.is_pokemon and c.evolves_from == target_card.name
            and (not self.names or c.name in self.names) and (not self.subtype_card or card_has_subtype(c, self.subtype_card))
            and not (self.no_ability and c.abilities)
        ]
        if not indices:
            return
        rest = (mon,) if self.twice else ()
        if len({player.deck[i] for i in indices}) == 1:
            evolution_id = player.deck.pop(indices[0])
            ctx.rng.shuffle(player.deck)
            _evolve_in_place_from_deck(player, mon, evolution_id)
            ctx.log(f"{target_card.name} を山札の {evolution_id} に進化させた")
            if rest:
                InstantEvolveEachTargetFromDeck(rest).execute(ctx)
            return
        ctx.state.pending_search_choice = PendingSearchChoice(
            player_index=ctx.acting_player,
            zone="deck",
            source_indices=indices,
            card_ids=[player.deck[i] for i in indices],
            min_count=1,
            max_count=1,
            prompt=f"{target_card.name}の進化先を選ぶ",
            shuffle_after=True,
            all_card_ids=list(player.deck),
            destination="evolve_target",
            attach_target_pokemon=mon,
            cont_source_pokemon=ctx.source_pokemon,
            cont_source_card_id=ctx.source_card_id,
            custom_data={"mode": "tech_machine_evolution_continue", "rest": rest, "then_end_turn": False},
        )


def _op_evolve_chosen_pick(state, card_db, choice, selected, action, ctx, custom) -> bool:
    from effects.era_primitives_b import _mon_at

    if not selected:
        return False
    mon = _mon_at(state.player(choice.player_index), choice.source_indices[selected[0]])
    if mon is not None:
        custom["effect"]._evolve(ctx, mon)
    if state.pending_search_choice is not None:
        state.pending_search_choice.remaining_script = tuple(state.pending_search_choice.remaining_script) + tuple(choice.remaining_script)
        state.pending_search_choice.then_end_turn = choice.then_end_turn
        return True
    return False


@dataclass(frozen=True)
class NanuEffect(Effect):
    """トラッシュのたねあくポケモン1匹を選び、自分の場のポケモン1匹と入れ替える。ついているカード・ダメカン・特殊状態・場に出ていた番数等はそのまま新しいポケモンに引き継ぐ。
    入れ替わった元のポケモン(進化していれば進化カードも)はトラッシュへ(サポート「Nanu」)。"""

    def execute(self, ctx: EffectContext) -> None:
        player = _attacker_player(ctx)
        candidates = [
            i for i, cid in enumerate(player.discard)
            if (c := ctx.card_db.get(cid)) is not None and c.is_pokemon and c.is_basic and "Darkness" in c.types
        ]
        if not candidates or not player.all_pokemon_in_play():
            return
        ctx.state.pending_search_choice = PendingSearchChoice(
            player_index=ctx.acting_player,
            zone="gen_deck_pick",
            source_indices=candidates,
            card_ids=[player.discard[i] for i in candidates],
            min_count=1,
            max_count=1,
            prompt="トラッシュから、場のポケモンと入れ替えるたねあくポケモンを選ぶ",
            shuffle_after=False,
            all_card_ids=[player.discard[i] for i in candidates],
            custom_data={"op": "nanu_pick_discard"},
            effect_source=ctx.effect_source,
        )


def _op_nanu_pick_discard(state, card_db, choice, selected, action, ctx, custom) -> bool:
    from effects.era_primitives_b import _slots

    if not selected:
        return False
    player = state.player(choice.player_index)
    discard_index = choice.source_indices[selected[0]]
    slots = _slots(player)
    state.pending_search_choice = PendingSearchChoice(
        player_index=choice.player_index,
        zone="gen_pokemon_pick",
        source_indices=[s for s, _ in slots],
        card_ids=[m.card_id for _, m in slots],
        min_count=1,
        max_count=1,
        prompt="トラッシュのポケモンと入れ替える、場のポケモンを選ぶ",
        shuffle_after=False,
        all_card_ids=[m.card_id for _, m in slots],
        custom_data={"op": "nanu_pick_target", "discard_index": discard_index},
        effect_source=choice.effect_source,
        then_end_turn=choice.then_end_turn,
    )
    return True


def _op_nanu_pick_target(state, card_db, choice, selected, action, ctx, custom) -> bool:
    from effects.era_primitives_b import _mon_at

    player = state.player(choice.player_index)
    mon = _mon_at(player, choice.source_indices[selected[0]]) if selected else None
    index = custom["discard_index"]
    if mon is None or index >= len(player.discard):
        return False
    new_id = player.discard[index]
    old_top = mon.card_id
    player.discard[index] = old_top  # 入れ替わった元のポケモンはトラッシュへ
    player.discard.extend(mon.evolution_history)
    mon.evolution_history = []
    mon.card_id = new_id
    state.add_log(f"トラッシュの{new_id}と{old_top}を入れ替えた(ついているカード・ダメカンなどはそのまま)")
    return False


@dataclass(frozen=True)
class PeekingRedCardEffect(Effect):
    """相手の手札を公開させる。そのあと、相手に手札の枚数を数えさせ、手札を山札に戻してシャッフルして、その枚数だけ引かせてもよい(のぞき見レッドカード)。"""

    def execute(self, ctx: EffectContext) -> None:
        opponent = ctx.state.player(ctx.opponent)
        ctx.state.player(ctx.acting_player).known_opponent_hand = list(opponent.hand)
        ctx.reveal("相手の手札", list(opponent.hand))
        if not opponent.hand:
            return
        _numeric_choice(ctx, ctx.acting_player, ("はい: 相手に手札を山札に戻してシャッフルさせ、同じ枚数を引かせる", "いいえ"), "peeking_red_card", "相手に手札を入れ替えさせますか?")


def _op_peeking_red_card(state, card_db, choice, selected, action, ctx, custom) -> bool:
    if selected and choice.source_indices[selected[0]] == 0:
        opponent = state.player(1 - choice.player_index)
        n = len(opponent.hand)
        opponent.deck.extend(opponent.hand)
        opponent.hand = []
        state.rng.shuffle(opponent.deck)
        for _ in range(n):
            if not opponent.deck:
                break
            opponent.hand.append(opponent.deck.pop(0))
        state.add_log(f"相手は手札{n}枚を山札に戻して、{n}枚引いた")
    return False


@dataclass(frozen=True)
class IngoEmmetEffect(Effect):
    """山札の一番上を見て、「手札を全てトラッシュして5枚引く」か「手札を全てトラッシュして山札の下から5枚引く」かを選ぶ(Ingo & Emmet)。"""

    n: int = 5

    def execute(self, ctx: EffectContext) -> None:
        player = _attacker_player(ctx)
        if player.deck:
            ctx.reveal("山札の一番上のカード", [player.deck[0]])
        labels = (f"手札を全てトラッシュして、山札から{self.n}枚引く", f"手札を全てトラッシュして、山札の下から{self.n}枚引く")
        _numeric_choice(ctx, ctx.acting_player, labels, "ingo_emmet", "どちらにするか選ぶ(山札の一番上を見た)", n=self.n)


def _op_ingo_emmet(state, card_db, choice, selected, action, ctx, custom) -> bool:
    player = state.player(choice.player_index)
    player.discard.extend(player.hand)
    player.hand = []
    from_bottom = bool(selected and choice.source_indices[selected[0]] == 1)
    for _ in range(custom["n"]):
        if not player.deck:
            break
        player.hand.append(player.deck.pop() if from_bottom else player.deck.pop(0))
    return False


# ---------------------------------------------------------------------------------------------
# 小さな効果
# ---------------------------------------------------------------------------------------------
@dataclass(frozen=True)
class ShuffleOwnDeck(Effect):
    """自分の山札をシャッフルする。"""

    def execute(self, ctx: EffectContext) -> None:
        ctx.rng.shuffle(_attacker_player(ctx).deck)


@dataclass(frozen=True)
class HalaEffect(Effect):
    """自分の手札を山札に戻してシャッフルする。GXワザを使ったことがあればgx_draw枚、なければelse_draw枚引く(ハラ)。"""

    gx_draw: int
    else_draw: int

    def execute(self, ctx: EffectContext) -> None:
        player = _attacker_player(ctx)
        player.deck.extend(player.hand)
        player.hand = []
        ctx.rng.shuffle(player.deck)
        Draw(self.gx_draw if player.used_gx_attack_this_game else self.else_draw).execute(ctx)


@dataclass(frozen=True)
class WillEffect(Effect):
    """この番、ワザ・特性・トレーナーズの効果で次にコインを投げるとき、最初の1枚のオモテ/ウラを自分で選べる(ウィル)。
    ここ(カードを使うとき)でオモテ/ウラのどちらにするかを決めておき、最初のコイン1回だけその結果になる(EffectContextの乱数源が見る)。"""

    def execute(self, ctx: EffectContext) -> None:
        _numeric_choice(ctx, ctx.acting_player, ("オモテにする", "ウラにする"), "will_choice", "次に投げるコインの最初の1枚を、オモテにするかウラにするか選ぶ")


def _op_will_choice(state, card_db, choice, selected, action, ctx, custom) -> bool:
    state.player(choice.player_index).coin_first_forced = choice.source_indices[selected[0]] if selected else 0
    return False


# ---------------------------------------------------------------------------------------------
# 条件(IfConditionで使う)
# ---------------------------------------------------------------------------------------------
def register_conditions() -> None:
    from effects import era_primitives as _ep

    def own_active_subtype(ctx, arg, player, opponent, self_mon, defender) -> bool:
        card = ctx.card_db.get(player.active.card_id) if player.active is not None else None
        return card is not None and arg in card.subtypes

    def active_types_match(ctx, arg, player, opponent, self_mon, defender) -> bool:
        a = ctx.card_db.get(player.active.card_id) if player.active is not None else None
        b = ctx.card_db.get(opponent.active.card_id) if opponent.active is not None else None
        return a is not None and b is not None and bool(set(a.types) & set(b.types))

    def second_player_first_turn(ctx, arg, player, opponent, self_mon, defender) -> bool:
        return player.turns_taken == 1 and ctx.acting_player != ctx.state.first_player

    _ep.EXTRA_CONDITIONS.update({
        "own_active_subtype": own_active_subtype,
        "active_types_match": active_types_match,
        "second_player_first_turn": second_player_first_turn,
    })


def register_ops() -> None:
    from effects.era_primitives_b import GENERIC_CONTINUE_HANDLERS, GENERIC_OP_HANDLERS

    GENERIC_OP_HANDLERS.update({
        "discard_hand_draw_per": _op_discard_hand_draw_per,
        "roller_skater": _op_roller_skater,
        "each_may_draw": _op_each_may_draw,
        "attach_list_to_target": _op_attach_list_to_target,
        "look_top_take": _op_look_top_take,
        "return_opponent_discard": _op_return_opponent_discard,
        "prize_take_one": _op_prize_take_one,
        "optional_discard_bonus": _op_optional_discard_bonus,
        "cc_decide": _op_cc_decide,
        "cc_discard": _op_cc_discard,
        "cc_take": _op_cc_take,
        "bench_down_to": _op_bench_down_to,
        "devolve_z_pick": _op_devolve_z_pick,
        "devolve_z_count": _op_devolve_z_count,
        "evolve_chosen_pick": _op_evolve_chosen_pick,
        "nanu_pick_discard": _op_nanu_pick_discard,
        "nanu_pick_target": _op_nanu_pick_target,
        "peeking_red_card": _op_peeking_red_card,
        "ingo_emmet": _op_ingo_emmet,
        "will_choice": _op_will_choice,
        "spell_tag_step": _op_spell_tag_step,
        "own_top_pick": _op_own_top_pick,
        "rainbow_brush_pick": _op_rainbow_brush_pick,
        "quiz_pick_pokemon": _op_quiz_pick_pokemon,
        "quiz_pick_attack": _op_quiz_pick_attack,
        "quiz_guess": _op_quiz_guess,
        "mdc_src": _op_mdc_src,
        "mdc_dst": _op_mdc_dst,
        "mdc_count": _op_mdc_count,
        "mdc_multi_dst": _op_mdc_multi_dst,
    })
    GENERIC_CONTINUE_HANDLERS.update({"distinct_basic_next": _continue_distinct_basic_next})




# ---------------------------------------------------------------------------------------------
# 登録
# ---------------------------------------------------------------------------------------------
_INSTALLED = False


def _gate(name: str, arg: str = ""):
    from effects.era_trainer_gates import GATE_FUNCS

    func = GATE_FUNCS[name]
    return lambda state, player, player_index, card_db: func(state, player, player_index, card_db, arg)


def _all_gates(*gates):
    return lambda state, player, player_index, card_db: all(g(state, player, player_index, card_db) for g in gates)


def install(reg) -> None:
    """era_trainers.install() から呼ばれる。reg(キー, スクリプト, ゲート)はグッズ/サポートの登録関数。"""
    global _INSTALLED
    if _INSTALLED:
        return
    _INSTALLED = True
    from effects.era_abilities import PickPokemonThen
    from effects.era_attacks_h import (
        DiscardChosenOpponentEnergyCount, DrawPerOwnPokemonMatching, HealAllOwnPokemonWithEnergyType, SearchDiscardByCriterionToHand,
        ShuffleFromDiscardByCriterionIntoDeck,
    )
    from effects.era_primitives import IfCondition, ShuffleHandThenDrawEqualToOpponentHand
    from effects.era_primitives_b import AttachEnergyGeneric, MoveEnergyGeneric, RevealOpponentHandPick, UseEffectOfPickedSupporter
    from effects.era_primitives_f import ChooseOneEffectBranch
    from effects.era_trainers import AttackBonusThisTurn
    from effects.era_trainers_g import ChipChipIceAxe
    from effects.primitives import (
        BothPlayersShuffleHandAndDrawFixed, DiscardAnyHandCardsOptional, DiscardCardsFromHand, DiscardHandCostThenDiscardChosenOpponentEnergy,
        DiscardStadiumInPlay, Draw, DrawUpTo, FlipCoinThen, HealTargetAndClearStatus, LookTopNReorderOnTop, OpponentDiscardExactlyFromHand,
        RemoveOneActiveStatusCondition, SearchDeckAnyCardToHand, SearchDeckByCriterionToHand, SearchDeckMultiCriteria, SearchDeckToTopOfDeck,
        SwitchActiveWithBench, SwitchActiveWithBenchThenHealBenched,
    )

    install_field(reg)
    from effects import era_tools_j, era_trainers_j  # noqa: F401  (era_tools_jは選択待ちの続き(ops)の登録のためにimportする)

    era_trainers_j.install(reg)
    era_tools_j.install_granted()
    era_tools_j.install_stadiums()
    era_tools_j.install_quads()
    from effects import era_energy_j  # noqa: F401  (Single Strike等のトークンの登録のためにimportする)
    deck_ok = _gate("deck_nonempty")
    pick_heal = lambda amount, **kw: PickPokemonThen(side="own", action="heal", amount=amount, **kw)  # noqa: E731

    # ---- 回復
    reg("big_malasada", (pick_heal(20, active_only=True), RemoveOneActiveStatusCondition()))
    reg("lana_sm", (HealAllOwnPokemonWithEnergyType(energy_type="Water", amount=50),))
    reg("gardenia_sm", (pick_heal(80, require_energy_type="Grass"),))
    reg("last_chance_potion", (pick_heal(120, remaining_hp_at_most=30),))
    reg("life_herb", (FlipCoinThen(heads=(HealTargetAndClearStatus(60),)),))
    reg("moomoo_milk", (pick_heal(60, coins=2),))
    reg("pokemon_breeder", (Draw(2), pick_heal(20, active_only=True)), deck_ok)
    reg("switch_raft", (SwitchActiveWithBenchThenHealBenched(30),), _all_gates(_active_is_water))

    # ---- 引く・手札
    reg("ilima", (IlimaEffect(),))
    reg("kukui_sm", (Draw(2), AttackBonusThisTurn(flat=20)))
    reg("rotom_dex", (RotomDexEffect(),))
    reg("samson_oak", (Draw(2), IfCondition(condition="active_types_match", then=(Draw(2),))))
    reg("blues_tactics", (SetEndTurnDrawTo(8),))
    reg("bug_catcher_sm", (Draw(2), FlipCoinThen(heads=(Draw(2),))))
    reg("coach_trainer", (Draw(2), IfCondition(condition="own_active_subtype", arg="TAG TEAM", then=(Draw(2),))))
    reg("blaines_last_stand", (DrawPerOwnPokemonMatching(per=2, ptype="Fire"),), _gate("hand_only_this"))
    reg("erikas_hospitality", (DrawPerOwnPokemonMatching(side="opp", per=1),), _gate("hand_others_at_most", "4"))
    reg("jessie_james", (OpponentDiscardExactlyFromHand(2), DiscardCardsFromHand(2)))
    reg("roller_skater", (RollerSkaterEffect(),))
    reg("roxie_sm", (DiscardHandCardsThenDrawPerCard(criterion="pokemon_not_subtype:GX|EX", max_count=2, per=3),))
    reg("ultra_recon_squad", (DiscardHandCardsThenDrawPerCard(criterion="ultra_beast", max_count=2, per=3),))
    reg("hala_sm", (HalaEffect(gx_draw=7, else_draw=4),))
    reg("wicke", (EachPlayerShuffleHandDrawSame(),))
    reg("judge_sm", (BothPlayersShuffleHandAndDrawFixed(4),))
    reg("copycat_sm", (ShuffleHandThenDrawEqualToOpponentHand(),))
    reg("bills_maintenance", (ShuffleChosenHandCardsIntoDeckThenDraw(shuffle=1, draw=3),))
    reg("tv_reporter", (Draw(3), DiscardCardsFromHand(1)), deck_ok)
    reg("sightseer", (DiscardAnyHandCardsOptional(), DrawUpTo(7)), deck_ok)
    reg("looker_sm", (DrawFromBottom(3),))
    reg("whitney_sm", (DrawPerOwnDiscardNamed(base=1, per=2, name="Whitney"),))
    reg("erika_sm", (EachPlayerMayDrawUpTo(3),))
    reg("lillies_full_force", (Draw(4), SetEndTurnHandLimit(threshold=3, keep=2)))
    reg("lost_blender", (PutHandCardsInLostZoneThenDraw(count=2, draw=1),), _gate("hand_others_at_least", "2"))
    reg("kahili", (Draw(2), SetPlayedCardDestination("hand", coin=True)), deck_ok)
    reg("ingo_emmet", (IngoEmmetEffect(),))

    # ---- サーチ・山札の上を見る
    reg("janine_sm", (LookTopNTake(n=4, m=2, criterion="any", exact=True, rest="shuffle"),))
    reg("energy_loto", (LookTopNTake(n=7, m=1, criterion="any_energy", rest="shuffle"),))
    reg("pokenav", (LookTopNTake(n=3, m=1, criterion="or:pokemon|any_energy", rest="reorder"),))
    reg("underground_expedition", (LookTopNTake(n=5, m=2, criterion="any", exact=True, rest="reorder", from_top=False),))
    reg("poke_maniac", (SearchDeckByCriterionToHand("pokemon_retreat_exactly:4", count=3),))
    reg("olivia_sm", (SearchDeckByCriterionToHand("subtype_card:GX", count=2),))
    reg("lisia", (SearchDeckByCriterionToHand("subtype_card:Prism Star", count=2),))
    reg("apricorn_maker", (SearchDeckByCriterionToHand("item_name_contains:Ball", count=2),))
    reg("looker_whistle", (SearchDeckByCriterionToHand("named:Looker", count=2),))
    reg("friend_ball", (FriendBallEffect(),))
    reg("net_ball", (SearchDeckByCriterionToHand("or:basic_type_pokemon:Grass|energy_type:Grass", count=1),))
    reg("mallow_sm", (SearchDeckToTopOfDeck(2),))
    reg("oaks_setup", (SearchDeckBasicDistinctTypesToBench(count=3),))
    reg("jasmine_sm", (
        IfCondition(condition="not_second_player_first_turn", then=(SearchDeckByCriterionToHand("type_pokemon:Metal", count=1),)),
        IfCondition(condition="second_player_first_turn", then=(SearchDeckByCriterionToHand("type_pokemon:Metal", count=5),)),
    ))
    reg("timer_ball", (FlipCoinsThenRepeat(coins=2, effect=SearchDeckByCriterionToHand("evolution_pokemon", count=1)),))
    reg("lure_ball", (FlipCoinsThenRepeat(coins=3, effect=SearchDiscardByCriterionToHand("evolution_pokemon", count=1)),))
    reg("electrocharger", (FlipCoinsThenRepeat(coins=2, effect=ShuffleFromDiscardByCriterionIntoDeck("named:Electropower", count=1)),))
    reg("rotom_dex_finder", (ChooseOneEffectBranch(
        labels=("好きな順番で山札の上に戻す", "山札をシャッフルする"), branches=((LookTopNReorderOnTop(4),), (ShuffleOwnDeck(),)),
    ),))
    reg("fossil_excavation_map", (ChooseOneEffectBranch(
        labels=("山札からカセキを探す", "トラッシュからカセキを手札に加える"),
        branches=((SearchDeckByCriterionToHand("named:Unidentified Fossil", count=1),), (SearchDiscardByCriterionToHand("named:Unidentified Fossil", count=1),)),
    ),))
    reg("energy_recycle_system", (ChooseOneEffectBranch(
        labels=("トラッシュの基本エネルギーを1枚手札に加える", "トラッシュの基本エネルギーを3枚山札に戻す"),
        branches=((SearchDiscardByCriterionToHand("basic_energy", count=1),), (ShuffleFromDiscardByCriterionIntoDeck("basic_energy", count=3),)),
    ),))
    reg("judge_whistle", (ChooseOneEffectBranch(
        labels=("1枚引く", "トラッシュからジャッジを手札に加える"),
        branches=((Draw(1),), (SearchDiscardByCriterionToHand("named:Judge", count=1),)),
    ),))
    reg("lanas_fishing_rod", (ShuffleFromDiscardByCriterionIntoDeck("pokemon", count=1), ShuffleFromDiscardByCriterionIntoDeck("pokemon_tool", count=1)))
    reg("aether_foundation_employee", (SearchDiscardByCriterionToHand("pokemon_name_contains:Alolan", count=2),))
    reg("diantha", (SearchDiscardByCriterionToHand("any", count=2),), _gate("ko_last_turn", "Fairy"))
    reg("molayne", (DiscardMatchingFromHand("energy_type:Metal", 2), ShuffleFromDiscardByCriterionIntoDeck("trainer", count=1)), _hand_has_two_metal)
    reg("crasher_wake", (DiscardMatchingFromHand("energy_type:Water", 2), SearchDeckAnyCardToHand(2)), _hand_has_two_water)
    reg("morgan", (DiscardNamedFromHand(("Dana", "Evelyn", "Nita")), AttachEnergyGeneric(source="deck", count=99, deck_limit=12, optional=True), ShuffleOwnDeck()), _hand_has_dana_evelyn_nita)

    # ---- エネルギー・どうぐ・スタジアム
    reg("brocks_training", (AttachEnergyGeneric(
        source="hand", count=1, single_target=True,
        target_names=("Geodude", "Graveler", "Golem", "Onix-GX", "Cubone", "Rhyhorn", "Rhydon", "Sudowoodo"),
    ),))
    reg("mistys_water_command", (MoveEnergyGeneric(
        owner="own", energy_type="Water", basic_only=True, freely=True,
        dest_names=("Psyduck", "Horsea", "Staryu", "Starmie-GX", "Magikarp", "Gyarados", "Lapras"),
    ),))
    reg("masked_royal", (AttachEnergyGeneric(
        source="hand", count=1, basic_only=True, single_target=True, target_stage="Stage 2", target_types_any=("Grass", "Fire", "Water"),
    ),))
    reg("ns_resolve", (DiscardTopThenAttachEnergyToBenched(n=6, ptype="Dragon"),))
    reg("eneporter", (MoveEnergyGeneric(owner="opp", special_only=True),))
    reg("damage_mover", (PickPokemonThen(side="own", action="take_counters", amount=3, damaged_only=True, then=(
        PickPokemonThen(side="own", action="give_counters", exclude_picked=True),)),))
    reg("grimsley_sm", (PickPokemonThen(side="opp", action="take_counters", amount=3, damaged_only=True, then=(
        PickPokemonThen(side="opp", action="give_counters", exclude_picked=True),)),))

    # ---- 相手への効果
    reg("team_skull_grunt", (RevealOpponentHandPick(criteria="energy", dest="discard", then=(RevealOpponentHandPick(criteria="energy", dest="discard"),)),))
    reg("sabrinas_suggestion", (RevealOpponentHandPick(criteria="supporter", dest="stay", optional=True, then=(UseEffectOfPickedSupporter(),)),))
    reg("morty_sm", (RevealOpponentHandPick(criteria="any", dest="shuffle_in", then=(RevealOpponentHandPick(criteria="any", dest="shuffle_in"),)),),
        _gate("ko_last_turn", "Psychic"))
    reg("peeking_red_card", (PeekingRedCardEffect(),))
    reg("tormenting_spray", (TormentingSprayEffect(),))
    reg("surprise_box", (ReturnChosenOpponentDiscard(destination="hand"),))
    reg("return_label", (ReturnChosenOpponentDiscard(destination="deck_bottom"),))
    reg("lysandre_prism", (LysandrePrismEffect(),))
    reg("nita", (PutDefenderEnergyOnTopOfDeck(),), _gate("opponent_active_subtype", "Basic"))
    reg("wait_and_see_hammer", (DiscardChosenOpponentEnergyCount(1),), _gate("second_player_first_turn"))
    reg("faba", (RemoveOpponentToolSpecialEnergyOrStadium(destination="lost_zone"),))
    reg("dangerous_drill", (DiscardMatchingFromHand("type_pokemon:Darkness", 1), RemoveOpponentToolSpecialEnergyOrStadium(destination="discard")),
        _gate("hand_has_pokemon_of_type", "Darkness"))
    reg("plumeria_sm", (DiscardHandCostThenDiscardChosenOpponentEnergy(discard_count=2),), _gate("hand_others_at_least", "2"))
    reg("giovannis_exile", (PickPokemonThen(side="own", action="discard_all", bench_only=True, undamaged_only=True, optional=True, then=(
        PickPokemonThen(side="own", action="discard_all", bench_only=True, undamaged_only=True, optional=True),)),))
    reg("channeler", (RemoveAllAttackEffectsOnOwnSide(),))
    reg("ultra_forest_kartenvoy", (SetIgnoreDefenderEffectsForSubtype("Ultra Beast"),))
    reg("bonnie", (DiscardStadiumInPlay(), SetGxOverride("name:Zygarde-GX")), _gate("stadium_in_play"))
    reg("beast_ball", (LookAtPrizesTakeOne(criterion="ultra_beast", optional=True),))
    reg("gladion_sm", (LookAtPrizesTakeOne(criterion="any", optional=False),))
    reg("devolution_spray_z", (DevolveOwnToDeck(),))
    reg("dusk_stone", (EvolveChosenOwnFromDeck(names=("Mismagius", "Honchkrow", "Chandelure", "Aegislash"), ignore_timing=True),))
    reg("nanu", (NanuEffect(),))
    reg("will_sm", (WillEffect(),))
    reg("clay_sm", (DiscardTopThenTakeKind(n=7, criterion="item"),))
    reg("hiker_sm", (ChooseOneEffectBranch(
        labels=("自分の山札を見る", "相手の山札を見る"), branches=((LookOwnTopNChooseOneOnTop(5),), (ChipChipIceAxe(n=5),)),
    ),))
    reg("rainbow_brush", (RainbowBrushEffect(),))
    reg("blaines_quiz_show", (BlainesQuizShowEffect(),))

    # ---- TAG TEAMサポート(手札を捨てると追加の効果)
    reg("guzma_hala", (OptionalDiscardBonus(
        n=2, base=(SearchDeckMultiCriteria(("stadium",)),), upgraded=(SearchDeckMultiCriteria(("stadium", "pokemon_tool", "special_energy")),),
    ),))
    reg("misty_lorelei", (OptionalDiscardBonus(
        n=5, base=(SearchDeckByCriterionToHand("energy_type:Water", count=3),),
        upgraded=(SearchDeckByCriterionToHand("energy_type:Water", count=3), SetGxOverride("type:Water")),
    ),))
    reg("mallow_lana", (OptionalDiscardBonus(n=2, base=(SwitchActiveWithBench(),), upgraded=(SwitchActiveWithBenchThenHealBenched(120),)),))
    reg("sabrina_brycen", (OptionalDiscardBonus(
        n=5, base=(SearchDeckByCriterionToHand("basic_energy", count=2),),
        upgraded=(SearchDeckByCriterionToHand("basic_energy", count=2), SearchDeckBasicDistinctTypesToBench(count=3, to_hand=True)),
    ),))
    reg("cynthia_caitlin", (CynthiaCaitlinEffect(),))
    reg("bellelba_brycen", (OptionalDiscardBonus(
        n=3, base=(DiscardTopOfEachPlayersDeck(3),), upgraded=(DiscardTopOfEachPlayersDeck(3), EachPlayerDiscardsBenchedDownTo(3)),
    ),))
    reg("red_blue", (OptionalDiscardBonus(
        n=2, base=(EvolveChosenOwnFromDeck(subtype_card="GX"),), upgraded=(EvolveChosenOwnFromDeck(subtype_card="GX"),),
    ),))


# ---- ゲート(使える条件)
def _active_is_water(state, player, player_index, card_db) -> bool:
    c = card_db.get(player.active.card_id) if player.active is not None else None
    return c is not None and "Water" in c.types and bool(player.bench)


def _count_hand(card_db, player, pred) -> int:
    return sum(1 for cid in player.hand if (c := card_db.get(cid)) is not None and pred(c))


def _hand_has_two_metal(state, player, player_index, card_db) -> bool:
    return _count_hand(card_db, player, lambda c: c.is_energy and not c.is_special_energy and c.basic_energy_type == "Metal") >= 2


def _hand_has_two_water(state, player, player_index, card_db) -> bool:
    return _count_hand(card_db, player, lambda c: c.is_energy and not c.is_special_energy and c.basic_energy_type == "Water") >= 2


def _hand_has_dana_evelyn_nita(state, player, player_index, card_db) -> bool:
    names = [c.name for cid in player.hand if (c := card_db.get(cid)) is not None]
    return all(n in names for n in ("Dana", "Evelyn", "Nita"))


# ---------------------------------------------------------------------------------------------
# SMのどうぐ・スタジアム(effects/era_sm_hooks.py)に付随する選択
# ---------------------------------------------------------------------------------------------
def start_spell_tag_counters(state, card_db, entry: dict, cont: dict) -> bool:
    """スペルタグ: きぜつしたとき、相手のポケモンにダメカンを好きなように4個のせる(1個ずつ、同じポケモンに続けてのせてもよい)。選択待ちを立てたらTrue。"""
    owner_index = entry["owner"]
    return _spell_tag_step(state, owner_index, entry["count"], cont)


def _spell_tag_step(state, owner_index: int, remaining: int, cont: dict) -> bool:
    from effects.era_primitives_b import _slots

    opponent = state.player(1 - owner_index)
    slots = _slots(opponent)
    if remaining <= 0 or not slots:
        return False
    state.pending_search_choice = PendingSearchChoice(
        player_index=owner_index,
        zone="gen_pokemon_pick",
        source_indices=[s for s, _ in slots],
        card_ids=[m.card_id for _, m in slots],
        min_count=1,
        max_count=1,
        prompt=f"スペルタグ: ダメカンをのせる相手のポケモンを選ぶ(あと{remaining}個)",
        shuffle_after=False,
        all_card_ids=[m.card_id for _, m in slots],
        custom_data={"op": "spell_tag_step", "remaining": remaining, "ko_cont": cont, "owner": owner_index},
    )
    return True


def _op_spell_tag_step(state, card_db, choice, selected, action, ctx, custom) -> bool:
    from effects.era_primitives_b import _mon_at
    from effects.primitives import _blocks_damage_counters

    owner_index = custom["owner"]
    opponent = state.player(1 - owner_index)
    mon = _mon_at(opponent, choice.source_indices[selected[0]]) if selected else None
    if mon is not None and not _blocks_damage_counters(mon):
        mon.damage += 10
        state.add_log(f"スペルタグの効果で、{mon.card_id} にダメカンを1個のせた")
    _spell_tag_step(state, owner_index, custom["remaining"] - 1, custom["ko_cont"])
    return True


@dataclass(frozen=True)
class SearchDeckEvolvesFromToBench(Effect):
    """山札から、指定の名前のポケモンから進化するポケモンを最大count匹まで選んでベンチに出す(ポケモン研究所)。"""

    evolves_from: str
    count: int

    def execute(self, ctx: EffectContext) -> None:
        from effects.primitives import _trigger_search_choice

        _trigger_search_choice(
            ctx, _attacker_player(ctx), "deck", lambda c: c is not None and c.is_pokemon and c.evolves_from == self.evolves_from, self.count,
            f"山札から、{self.evolves_from}から進化するポケモンをベンチに出す(最大{self.count}匹)", shuffle_after=True, destination="bench",
        )


def install_field(reg) -> None:
    """どうぐ・スタジアム・特殊エネルギーの、表への登録(era_trainers_i.installから呼ぶ)。"""
    from effects import registry as R
    from effects.era_abilities import PickPokemonThen
    from effects.era_attacks_h import SearchDiscardByCriterionToHand
    from effects.era_sm_hooks import (
        BLACK_MARKET_IDS, LAVENDER_TOWN_IDS, LIFE_FOREST_IDS, METAL_CORE_BARRIER_IDS, GIANT_BOMB_IDS, MT_CORONET_IDS, RESEARCH_LAB_IDS,
        WARP_ENERGY_SM_IDS,
    )
    from effects.primitives import EndTurnAfterThisAbility, RevealOpponentHand
    from engine import rules_engine as RE

    _ = (BLACK_MARKET_IDS, reg)
    RE._OPPONENT_TURN_END_DISCARD_TOOL_IDS.update(METAL_CORE_BARRIER_IDS | GIANT_BOMB_IDS)  # 相手の番の終わりにトラッシュされるどうぐ
    for card_id in WARP_ENERGY_SM_IDS:
        RE._TRIGGER_TARGET_KIND.setdefault(card_id, "own_bench")
    stadiums = R.STADIUM_ABILITY_EFFECTS
    for card_id in MT_CORONET_IDS:
        stadiums.setdefault(card_id, (SearchDiscardByCriterionToHand("energy_type:Metal", count=2),))
    for card_id in RESEARCH_LAB_IDS:
        stadiums.setdefault(card_id, (SearchDeckEvolvesFromToBench("Unidentified Fossil", 2), EndTurnAfterThisAbility()))
    for card_id in LIFE_FOREST_IDS:
        stadiums.setdefault(card_id, (PickPokemonThen(side="own", action="heal_clear", amount=60, ptype="Grass"),))
    for card_id in LAVENDER_TOWN_IDS:
        stadiums.setdefault(card_id, (RevealOpponentHand(),))


# ---------------------------------------------------------------------------------------------
# ハイカー / レインボーブラシ / ブレインのクイズ大会
# ---------------------------------------------------------------------------------------------
@dataclass(frozen=True)
class LookOwnTopNChooseOneOnTop(Effect):
    """自分の山札の上からn枚を見て1枚を選び、残りは山札に戻してシャッフルする。そのあと選んだカードを山札の上に置く(ハイカー: 自分の山札の場合)。"""

    n: int

    def execute(self, ctx: EffectContext) -> None:
        player = _attacker_player(ctx)
        seen = player.deck[: self.n]
        if not seen:
            return
        ctx.state.pending_search_choice = PendingSearchChoice(
            player_index=ctx.acting_player,
            zone="gen_deck_pick",
            source_indices=list(range(len(seen))),
            card_ids=list(seen),
            min_count=1,
            max_count=1,
            prompt="自分の山札の上から見たカードのうち、山札の上に置く1枚を選ぶ(他は山札に戻してシャッフルする)",
            shuffle_after=False,
            all_card_ids=list(seen),
            custom_data={"op": "own_top_pick", "n": len(seen)},
            effect_source=ctx.effect_source,
        )


def _op_own_top_pick(state, card_db, choice, selected, action, ctx, custom) -> bool:
    player = state.player(choice.player_index)
    n = custom["n"]
    seen = player.deck[:n]
    if not selected or not seen:
        return False
    picked = seen[choice.source_indices[selected[0]]]
    rest = list(seen)
    rest.remove(picked)
    del player.deck[:n]
    player.deck.extend(rest)
    state.rng.shuffle(player.deck)
    player.deck.insert(0, picked)
    state.add_log("自分の山札の上から見て、選んだ1枚を山札の上に置いた")
    return False


@dataclass(frozen=True)
class RainbowBrushEffect(Effect):
    """自分のポケモンについているエネルギーカード1枚を選ぶ。山札から基本エネルギーを1枚探して、そのカードと入れ替える。最初のエネルギーカードは山札に混ぜる(レインボーブラシ)。"""

    def execute(self, ctx: EffectContext) -> None:
        from engine.display import card_name

        player = _attacker_player(ctx)
        if not any((c := ctx.card_db.get(cid)) is not None and c.is_energy and not c.is_special_energy for cid in player.deck):
            ctx.log("山札に基本エネルギーが無い")
            return
        entries = [(m, ei) for m in player.all_pokemon_in_play() for ei in range(len(m.attached_energy))]
        if not entries:
            return
        labels = [f"{card_name(ctx.card_db, m.card_id)} の {card_name(ctx.card_db, m.attached_energy[ei])}" for m, ei in entries]
        ctx.state.pending_search_choice = PendingSearchChoice(
            player_index=ctx.acting_player,
            zone="gen_pokemon_pick",
            source_indices=list(range(len(entries))),
            card_ids=labels,
            min_count=1,
            max_count=1,
            prompt="入れ替えるエネルギーカードを選ぶ",
            shuffle_after=False,
            all_card_ids=labels,
            custom_data={"op": "rainbow_brush_pick", "entries": [(m, m.attached_energy[ei]) for m, ei in entries]},
            effect_source=ctx.effect_source,
            cont_source_pokemon=ctx.source_pokemon,
            cont_source_card_id=ctx.source_card_id,
        )


def _op_rainbow_brush_pick(state, card_db, choice, selected, action, ctx, custom) -> bool:
    from effects.primitives import _trigger_search_choice

    if not selected:
        return False
    mon, old_id = custom["entries"][choice.source_indices[selected[0]]]
    player = state.player(choice.player_index)
    _trigger_search_choice(
        ctx, player, "deck", lambda c: c is not None and c.is_energy and not c.is_special_energy, 1,
        "山札から、入れ替える基本エネルギーを1枚探す", shuffle_after=True, destination="attach_energy",
    )
    pending = state.pending_search_choice
    if pending is None:
        return False
    pending.attach_target_pokemon = mon
    pending.remaining_script = (FinishRainbowBrush(mon, old_id, len(mon.attached_energy)),)
    pending.cont_acting_player = choice.player_index
    pending.then_end_turn = choice.then_end_turn
    return True


@dataclass(frozen=True)
class FinishRainbowBrush(Effect):
    """レインボーブラシの後半: 新しい基本エネルギーがついたら、元のエネルギーカードを外して山札に混ぜる(何も探さなかったら入れ替わらない)。"""

    mon: object
    old_energy_id: str
    count_before: int

    def execute(self, ctx: EffectContext) -> None:
        mon = self.mon
        if len(mon.attached_energy) > self.count_before and self.old_energy_id in mon.attached_energy:
            mon.attached_energy.remove(self.old_energy_id)
            player = _attacker_player(ctx)
            player.deck.append(self.old_energy_id)
            ctx.rng.shuffle(player.deck)
            ctx.log("元のエネルギーカードを山札に混ぜてシャッフルした")


@dataclass(frozen=True)
class BlainesQuizShowEffect(Effect):
    """手札のポケモン1枚を裏向きに置き、持っているワザの名前を相手に教える。相手がそのポケモンの名前を当てたら相手が4枚、外したら自分が4枚引く。ポケモンは手札に戻す(ブレインのクイズ大会)。"""

    draw: int = 4

    def execute(self, ctx: EffectContext) -> None:
        player = _attacker_player(ctx)
        eligible = [i for i, cid in enumerate(player.hand) if (c := ctx.card_db.get(cid)) is not None and c.is_pokemon and c.attacks]
        if not eligible:
            return
        ctx.state.pending_search_choice = PendingSearchChoice(
            player_index=ctx.acting_player,
            zone="gen_hand_pick",
            source_indices=eligible,
            card_ids=[player.hand[i] for i in eligible],
            min_count=1,
            max_count=1,
            prompt="裏向きに置く手札のポケモンを選ぶ",
            shuffle_after=False,
            all_card_ids=[player.hand[i] for i in eligible],
            custom_data={"op": "quiz_pick_pokemon", "draw": self.draw},
            effect_source=ctx.effect_source,
            cont_source_pokemon=ctx.source_pokemon,
            cont_source_card_id=ctx.source_card_id,
        )


def _op_quiz_pick_pokemon(state, card_db, choice, selected, action, ctx, custom) -> bool:
    if not selected:
        return False
    player = state.player(choice.player_index)
    card_id = player.hand[choice.source_indices[selected[0]]]
    card = card_db.get(card_id)
    names = [a.name for a in card.attacks]
    if len(names) == 1:
        return _quiz_ask_opponent(state, card_db, choice, card_id, names[0], custom["draw"])
    state.pending_search_choice = PendingSearchChoice(
        player_index=choice.player_index,
        zone="gen_pokemon_pick",
        source_indices=list(range(len(names))),
        card_ids=names,
        min_count=1,
        max_count=1,
        prompt="相手に教えるワザの名前を選ぶ",
        shuffle_after=False,
        all_card_ids=names,
        custom_data={"op": "quiz_pick_attack", "card_id": card_id, "names": names, "draw": custom["draw"]},
        effect_source=choice.effect_source,
        then_end_turn=choice.then_end_turn,
    )
    return True


def _op_quiz_pick_attack(state, card_db, choice, selected, action, ctx, custom) -> bool:
    name = custom["names"][choice.source_indices[selected[0]]] if selected else custom["names"][0]
    return _quiz_ask_opponent(state, card_db, choice, custom["card_id"], name, custom["draw"])


def _quiz_ask_opponent(state, card_db, choice, card_id: str, attack_name: str, draw: int) -> bool:
    candidates = sorted({c.name for c in card_db.all() if c.is_pokemon and any(a.name == attack_name for a in c.attacks)})
    answer = card_db.get(card_id).name
    if answer not in candidates:
        candidates.append(answer)
    state.pending_search_choice = PendingSearchChoice(
        player_index=1 - choice.player_index,
        zone="gen_pokemon_pick",
        source_indices=list(range(len(candidates))),
        card_ids=candidates,
        min_count=1,
        max_count=1,
        prompt=f"相手が裏向きに置いたポケモン(ワザ「{attack_name}」を持つ)の名前を当てる",
        shuffle_after=False,
        all_card_ids=candidates,
        custom_data={"op": "quiz_guess", "answer": answer, "candidates": candidates, "user": choice.player_index, "draw": draw},
        effect_source=choice.effect_source,
        cont_acting_player=choice.player_index,
        then_end_turn=choice.then_end_turn,
    )
    return True


def _op_quiz_guess(state, card_db, choice, selected, action, ctx, custom) -> bool:
    guess = custom["candidates"][choice.source_indices[selected[0]]] if selected else None
    right = guess == custom["answer"]
    receiver = choice.player_index if right else custom["user"]
    player = state.player(receiver)
    for _ in range(custom["draw"]):
        if not player.deck:
            break
        player.hand.append(player.deck.pop(0))
    state.add_log(f"クイズ: 相手は「{guess}」と答え、正解は「{custom['answer']}」。{'相手' if right else '自分'}が{custom['draw']}枚引いた")
    return False


# ---------------------------------------------------------------------------------------------
# ダメカンを移す(Shady Move / Ominous Posture / Power Suction 等)
# ---------------------------------------------------------------------------------------------
@dataclass(frozen=True)
class MoveDamageCounters(Effect):
    """ダメカンを、1匹(元)から別の1匹(先)へ移す。count=移す個数(up_to=Trueなら0〜count個を選べる)。
    scope: "own"(自分のポケモン同士)|"any"(両者の場のポケモン同士)|"own_to_opp_active"(自分のポケモンから相手のバトルポケモンへ)|
    "other_own_to_self"(自分の他のポケモンからこのポケモンへ)。pokemon_type: 元と先の両方に求めるタイプ。
    元にダメカンがあるときだけ使える(特性なら、使える条件にもなる)。"""

    count: int = 1
    scope: str = "own"
    pokemon_type: str | None = None
    up_to: bool = False

    def _sides(self, state, me: int) -> tuple:
        return (me, 1 - me) if self.scope == "any" else (me,)

    def _type_ok(self, ctx_or_db, mon) -> bool:
        if self.pokemon_type is None:
            return True
        card = ctx_or_db.get(mon.card_id)
        return card is not None and self.pokemon_type in card.types

    def sources(self, state, card_db, me: int, holder) -> list:
        out = []
        for pi in self._sides(state, me):
            for slot, mon in _slots_of(state.player(pi)):
                if mon.damage <= 0 or not self._type_ok(card_db, mon):
                    continue
                if self.scope == "other_own_to_self" and mon is holder:
                    continue
                if self.scope == "active_to_opp_active" and slot != 0:
                    continue  # 元はバトルポケモンだけ(アガサ)
                out.append((pi, slot))
        return out

    def ability_gate(self, state, player, mon, zone, card_db) -> bool:
        me = 0 if player is state.players[0] else 1
        sources = self.sources(state, card_db, me, mon)
        return any(self.destinations(state, card_db, me, mon, src) for src in sources)

    def destinations(self, state, card_db, me: int, holder, source) -> list:
        spi, sslot = source
        src_mon = _mon_of(state, spi, sslot)
        if self.scope in ("own_to_opp_active", "active_to_opp_active"):
            active = state.player(1 - me).active
            return [(1 - me, 0)] if active is not None else []
        if self.scope == "other_own_to_self":
            slot = _slot_index(state.player(me), holder)
            return [(me, slot)] if slot is not None else []
        out = []
        for pi in self._sides(state, me):
            for slot, mon in _slots_of(state.player(pi)):
                if mon is src_mon or not self._type_ok(card_db, mon):
                    continue
                out.append((pi, slot))
        return out

    def execute(self, ctx: EffectContext) -> None:
        sources = self.sources(ctx.state, ctx.card_db, ctx.acting_player, ctx.source_pokemon)
        sources = [s for s in sources if self.destinations(ctx.state, ctx.card_db, ctx.acting_player, ctx.source_pokemon, s)]
        if not sources:
            return
        labels = [f"player{pi} {ctx.card_db.get(_mon_of(ctx.state, pi, slot).card_id).name}" for pi, slot in sources]
        ctx.state.pending_search_choice = PendingSearchChoice(
            player_index=ctx.acting_player,
            zone="gen_pokemon_pick",
            source_indices=list(range(len(sources))),
            card_ids=labels,
            min_count=1,
            max_count=1,
            prompt="ダメカンを移す元のポケモンを選ぶ",
            shuffle_after=False,
            all_card_ids=labels,
            custom_data={"op": "mdc_src", "spec": (self.count, self.scope, self.pokemon_type, self.up_to), "sources": sources},
            effect_source=ctx.effect_source,
            cont_source_pokemon=ctx.source_pokemon,
            cont_source_card_id=ctx.source_card_id,
        )


def _slots_of(player):
    from effects.era_primitives_b import _slots

    return _slots(player)


def _mon_of(state, pi: int, slot: int):
    from effects.era_primitives_b import _mon_at

    return _mon_at(state.player(pi), slot)


def _slot_index(player, mon):
    from effects.era_primitives_b import _slot_of

    return _slot_of(player, mon)


def _mdc_effect(spec) -> MoveDamageCounters:
    count, scope, ptype, up_to = spec
    return MoveDamageCounters(count=count, scope=scope, pokemon_type=ptype, up_to=up_to)


def _op_mdc_src(state, card_db, choice, selected, action, ctx, custom) -> bool:
    if not selected:
        return False
    source = custom["sources"][choice.source_indices[selected[0]]]
    effect = _mdc_effect(custom["spec"])
    me = choice.actor()
    holder = choice.cont_source_pokemon
    dests = effect.destinations(state, card_db, me, holder, source)
    if not dests:
        return False
    if len(dests) == 1:
        return _mdc_after_dest(state, card_db, choice, custom, source, dests[0])
    labels = [f"player{pi} {card_db.get(_mon_of(state, pi, slot).card_id).name}" for pi, slot in dests]
    state.pending_search_choice = PendingSearchChoice(
        player_index=choice.player_index,
        zone="gen_pokemon_pick",
        source_indices=list(range(len(dests))),
        card_ids=labels,
        min_count=1,
        max_count=1,
        prompt="ダメカンを移す先のポケモンを選ぶ",
        shuffle_after=False,
        all_card_ids=labels,
        custom_data={"op": "mdc_dst", "spec": custom["spec"], "source": source, "dests": dests},
        effect_source=choice.effect_source,
        cont_acting_player=choice.cont_acting_player,
        cont_source_pokemon=choice.cont_source_pokemon,
        cont_source_card_id=choice.cont_source_card_id,
        then_end_turn=choice.then_end_turn,
    )
    return True


def _op_mdc_dst(state, card_db, choice, selected, action, ctx, custom) -> bool:
    if not selected:
        return False
    return _mdc_after_dest(state, card_db, choice, custom, custom["source"], custom["dests"][choice.source_indices[selected[0]]])


def _mdc_after_dest(state, card_db, choice, custom, source, dest) -> bool:
    count, _scope, _ptype, up_to = custom["spec"]
    src_mon = _mon_of(state, *source)
    available = src_mon.damage // 10
    n = min(count, available)
    if _scope == "own_multi":
        # 1個ずつ、移す先を選ぶ(最大count個。やめてもよい): ダメカンポンプ
        _mdc_apply(state, source, dest, 1)
        return _mdc_multi_next(state, card_db, choice, custom, source, count - 1)
    if up_to and n > 1:
        labels = [str(i) for i in range(n + 1)]
        state.pending_search_choice = PendingSearchChoice(
            player_index=choice.player_index,
            zone="gen_pokemon_pick",
            source_indices=list(range(len(labels))),
            card_ids=labels,
            min_count=1,
            max_count=1,
            prompt="移すダメカンの数を選ぶ",
            shuffle_after=False,
            all_card_ids=labels,
            custom_data={"op": "mdc_count", "source": source, "dest": dest},
            effect_source=choice.effect_source,
            cont_acting_player=choice.cont_acting_player,
            cont_source_pokemon=choice.cont_source_pokemon,
            cont_source_card_id=choice.cont_source_card_id,
            then_end_turn=choice.then_end_turn,
        )
        return True
    _mdc_apply(state, source, dest, n)
    return False


def _mdc_multi_next(state, card_db, choice, custom, source, remaining: int) -> bool:
    src_mon = _mon_of(state, *source)
    if remaining <= 0 or src_mon is None or src_mon.damage <= 0:
        return False
    me = choice.actor()
    effect = _mdc_effect(custom["spec"])
    dests = effect.destinations(state, card_db, me, choice.cont_source_pokemon, source)
    if not dests:
        return False
    labels = [f"player{pi} {card_db.get(_mon_of(state, pi, slot).card_id).name}" for pi, slot in dests] + ["やめる"]
    state.pending_search_choice = PendingSearchChoice(
        player_index=choice.player_index, zone="gen_pokemon_pick", source_indices=list(range(len(labels))), card_ids=labels, min_count=1,
        max_count=1, prompt=f"ダメカンを移す先を選ぶ(あと{remaining}個まで)", shuffle_after=False, all_card_ids=labels,
        custom_data={"op": "mdc_multi_dst", "spec": custom["spec"], "source": source, "dests": dests, "remaining": remaining},
        effect_source=choice.effect_source, cont_acting_player=choice.cont_acting_player, cont_source_pokemon=choice.cont_source_pokemon,
        cont_source_card_id=choice.cont_source_card_id, then_end_turn=choice.then_end_turn,
    )
    return True


def _op_mdc_multi_dst(state, card_db, choice, selected, action, ctx, custom) -> bool:
    idx = choice.source_indices[selected[0]] if selected else len(custom["dests"])
    if idx >= len(custom["dests"]):
        return False
    _mdc_apply(state, custom["source"], custom["dests"][idx], 1)
    return _mdc_multi_next(state, card_db, choice, custom, custom["source"], custom["remaining"] - 1)


def _op_mdc_count(state, card_db, choice, selected, action, ctx, custom) -> bool:
    n = choice.source_indices[selected[0]] if selected else 0
    _mdc_apply(state, custom["source"], custom["dest"], n)
    return False


def _mdc_apply(state, source, dest, n: int) -> None:
    src_mon = _mon_of(state, *source)
    dst_mon = _mon_of(state, *dest)
    if src_mon is None or dst_mon is None or n <= 0:
        return
    n = min(n, src_mon.damage // 10)
    src_mon.damage -= 10 * n
    dst_mon.damage += 10 * n
    state.add_log(f"ダメカンを{n}個、{src_mon.card_id} から {dst_mon.card_id} へ移した")


register_conditions()
register_ops()
