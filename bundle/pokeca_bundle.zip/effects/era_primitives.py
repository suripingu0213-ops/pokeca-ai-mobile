"""時代ごとのカード取り込み(2026-10-06〜)で追加した効果プリミティブ。

effects/primitives.py と同じ規約(frozen dataclassのEffect、execute(ctx))。ダメージを与えるものは必ず
DealDamageを1回だけ経由し、基本ダメージと追加ダメージを合算してから弱点・抵抗力・各種修正を1回だけ適用する。
"""

from __future__ import annotations

from dataclasses import dataclass, replace

from effects.context import EffectContext
from effects.primitives import (
    DealDamage,
    Effect,
    _attacker_player,
    _defender,
    _defender_is_shielded,
    resolve_attack_damage,
)
from engine.status import ExclusiveCondition


# ---------------------------------------------------------------------------------------------
# 条件つき追加ダメージ
# ---------------------------------------------------------------------------------------------
def _special_condition_count(mon) -> int:
    count = 0
    if mon.status.poisoned:
        count += 1
    if mon.status.burned:
        count += 1
    if mon.status.exclusive != ExclusiveCondition.NONE:
        count += 1
    return count


# 別のモジュール(effects/era_primitives_f.py等)が登録する条件: EXTRA_CONDITIONS[名前](ctx, arg, player, opponent, self_mon, defender) -> bool
EXTRA_CONDITIONS: dict = {}


def condition_met(ctx: EffectContext, condition: str, arg: str = "") -> bool:
    """ConditionalBonusDamageの条件判定。条件名の先頭に"not_"を付けると否定になる。"""
    if condition.startswith("not_"):
        return not condition_met(ctx, condition[4:], arg)
    player = _attacker_player(ctx)
    opponent = ctx.state.player(ctx.opponent)
    self_mon = ctx.source_pokemon
    _, defender = _defender(ctx)
    extra = EXTRA_CONDITIONS.get(condition)
    if extra is not None:
        return bool(extra(ctx, arg, player, opponent, self_mon, defender))
    if condition == "same_hand_count":
        return len(player.hand) == len(opponent.hand)
    if condition == "self_special_condition":
        return self_mon is not None and _special_condition_count(self_mon) > 0
    if condition == "defender_special_condition":
        return defender is not None and _special_condition_count(defender) > 0
    if condition == "defender_stage":
        card = ctx.card_db.get(defender.card_id) if defender is not None else None
        return card is not None and arg in card.subtypes
    if condition == "own_bench_named":
        return any((c := ctx.card_db.get(m.card_id)) is not None and c.name == arg for m in player.bench)
    if condition == "defender_has_tool":
        return defender is not None and defender.attached_tool is not None
    if condition == "self_fewer_hp":
        if self_mon is None or defender is None:
            return False
        return _remaining_hp(ctx, self_mon) < _remaining_hp(ctx, defender)
    if condition == "defender_damage_counters_at_least":
        return defender is not None and defender.damage // 10 >= int(arg)
    if condition == "self_has_energy_named":
        return self_mon is not None and any(
            (c := ctx.card_db.get(e)) is not None and c.name == arg for e in self_mon.attached_energy
        )
    if condition == "self_damaged":
        return self_mon is not None and self_mon.damage > 0
    if condition == "defender_asleep":
        return defender is not None and defender.status.exclusive == ExclusiveCondition.ASLEEP
    if condition == "defender_damaged":
        return defender is not None and defender.damage > 0
    if condition == "bench_count_at_least":
        return len(player.bench) >= int(arg)
    if condition == "self_has_energy_type":
        return self_mon is not None and any(
            (c := ctx.card_db.get(e)) is not None and c.basic_energy_type == arg for e in self_mon.attached_energy
        )
    if condition == "self_has_special_energy":
        return self_mon is not None and any(
            (c := ctx.card_db.get(e)) is not None and c.is_special_energy for e in self_mon.attached_energy
        )
    if condition == "defender_has_special_energy":
        return defender is not None and any(
            (c := ctx.card_db.get(e)) is not None and c.is_special_energy for e in defender.attached_energy
        )
    if condition == "defender_type" and defender is not None and defender.type_override and (
        ctx.state.player(ctx.opponent).turns_taken <= defender.type_override_until_turn
    ):
        return defender.type_override == arg
    if condition == "defender_type" and defender is not None:
        from effects.passives import mon_types

        types = mon_types(ctx.state, ctx.card_db, ctx.opponent, defender)
        if types:
            return arg in types
    if condition == "defender_type":
        card = ctx.card_db.get(defender.card_id) if defender is not None else None
        return card is not None and arg in card.types
    if condition == "defender_resists":
        card = ctx.card_db.get(defender.card_id) if defender is not None else None
        return card is not None and any(r.type == arg for r in card.resistances)
    if condition == "defender_has_resistance":
        card = ctx.card_db.get(defender.card_id) if defender is not None else None
        return card is not None and bool(card.resistances)
    if condition == "defender_no_retreat":
        card = ctx.card_db.get(defender.card_id) if defender is not None else None
        return card is not None and card.retreat_cost_count == 0
    if condition == "defender_named":
        card = ctx.card_db.get(defender.card_id) if defender is not None else None
        return card is not None and card.name == arg
    if condition == "self_full_hp":
        return self_mon is not None and self_mon.damage == 0
    if condition == "self_remaining_hp_at_most":
        return self_mon is not None and _remaining_hp(ctx, self_mon) <= int(arg)
    if condition == "stadium_in_play":
        return ctx.state.stadium_in_play is not None
    if condition == "more_hand_than_opponent":
        return len(player.hand) > len(opponent.hand)
    if condition == "self_burned_or_poisoned":
        return self_mon is not None and (self_mon.status.burned or self_mon.status.poisoned)
    if condition == "self_energy_matches_defender_type":
        card = ctx.card_db.get(defender.card_id) if defender is not None else None
        if self_mon is None or card is None:
            return False
        return any(
            (c := ctx.card_db.get(e)) is not None and c.basic_energy_type is not None and c.basic_energy_type in card.types
            for e in self_mon.attached_energy
        )
    if condition == "opponent_has_named_in_play":
        return any(
            (c := ctx.card_db.get(m.card_id)) is not None and c.name.startswith(arg)
            for m in opponent.all_pokemon_in_play()
        )
    if condition == "defender_no_energy":
        return defender is not None and not defender.attached_energy
    if condition == "own_bench_stage":
        return any((c := ctx.card_db.get(m.card_id)) is not None and arg in c.subtypes for m in player.bench)
    if condition == "opponent_prizes_exactly":
        return len(opponent.prizes) == int(arg)
    if condition == "defender_subtype":
        card = ctx.card_db.get(defender.card_id) if defender is not None else None
        return card is not None and arg in card.subtypes
    if condition == "own_bench_type":
        return any((c := ctx.card_db.get(m.card_id)) is not None and arg in c.types for m in player.bench)
    if condition == "own_in_play_named":
        return any((c := ctx.card_db.get(m.card_id)) is not None and c.name == arg for m in player.all_pokemon_in_play())
    if condition == "own_in_play_subtype":
        return any((c := ctx.card_db.get(m.card_id)) is not None and arg in c.subtypes for m in player.all_pokemon_in_play())
    if condition == "ko_named_last_turn":
        return arg in player.ko_by_attack_names_last_turn
    if condition == "defender_poisoned":
        return defender is not None and defender.status.poisoned
    if condition == "self_asleep":
        return self_mon is not None and self_mon.status.exclusive == ExclusiveCondition.ASLEEP
    return False


def _remaining_hp(ctx: EffectContext, mon) -> int:
    card = ctx.card_db.get(mon.card_id)
    return max(0, (card.hp or 0) - mon.damage) if card is not None else 0


@dataclass(frozen=True)
class ConditionalBonusDamage(Effect):
    """条件を満たすとき、基本ダメージにbonusを加えて1回のダメージ計算にする("If ..., this attack does N more damage.")。
    condition: same_hand_count / self_special_condition / defender_special_condition / defender_stage(arg="Stage 2") /
    own_bench_named(arg=カード名) / defender_has_tool / self_fewer_hp / defender_damage_counters_at_least(arg=個数) /
    self_has_energy_named(arg=エネルギーのカード名)。"""

    base: int
    bonus: int
    condition: str
    arg: str = ""

    def execute(self, ctx: EffectContext) -> None:
        extra = self.bonus if condition_met(ctx, self.condition, self.arg) else 0
        DealDamage(self.base + extra).execute(ctx)


@dataclass(frozen=True)
class ConditionalBonusPerDamage(Effect):
    """条件を満たすとき、さらに数に応じた追加ダメージ("If this Pokémon has any Plasma Energy attached, this attack does N more
    damage for each Energy attached to the Defending Pokémon.")。条件を満たさなければ基本ダメージだけ。"""

    base: int
    per: int
    condition: str
    counted: str  # "defender_energy" | "defender_damage_counters"
    arg: str = ""

    def execute(self, ctx: EffectContext) -> None:
        _, defender = _defender(ctx)
        extra = 0
        if defender is not None and condition_met(ctx, self.condition, self.arg):
            if self.counted == "defender_energy":
                extra = self.per * len(defender.attached_energy)
            elif self.counted == "defender_damage_counters":
                extra = self.per * (defender.damage // 10)
        DealDamage(self.base + extra).execute(ctx)


# ---------------------------------------------------------------------------------------------
# 数に応じたダメージ
# ---------------------------------------------------------------------------------------------
@dataclass(frozen=True)
class DamagePerAllPokemonInPlay(Effect):
    """場に出ているポケモン(自分・相手とも、バトル場+ベンチ)1匹につきper_pokemonダメージ。"""

    per_pokemon: int

    def execute(self, ctx: EffectContext) -> None:
        total = len(ctx.state.player(ctx.acting_player).all_pokemon_in_play()) + len(
            ctx.state.player(ctx.opponent).all_pokemon_in_play()
        )
        DealDamage(self.per_pokemon * total).execute(ctx)


@dataclass(frozen=True)
class DamagePerOwnPokemonInPlayOfType(Effect):
    """自分の場(バトル場+ベンチ)の、指定タイプのポケモン1匹につきper_pokemonダメージ。"""

    per_pokemon: int
    pokemon_type: str

    def execute(self, ctx: EffectContext) -> None:
        count = sum(
            1
            for m in _attacker_player(ctx).all_pokemon_in_play()
            if (c := ctx.card_db.get(m.card_id)) is not None and self.pokemon_type in c.types
        )
        DealDamage(self.per_pokemon * count).execute(ctx)


@dataclass(frozen=True)
class DamagePerOwnPokemonInPlayNamed(Effect):
    """自分の場(バトル場+ベンチ)の、指定した名前のポケモン1匹につきper_pokemonダメージ。"""

    per_pokemon: int
    name: str

    def execute(self, ctx: EffectContext) -> None:
        count = sum(
            1
            for m in _attacker_player(ctx).all_pokemon_in_play()
            if (c := ctx.card_db.get(m.card_id)) is not None and c.name == self.name
        )
        DealDamage(self.per_pokemon * count).execute(ctx)


@dataclass(frozen=True)
class DamagePerSelfEnergyNamed(Effect):
    """このポケモンについている、指定した名前のエネルギー(特殊エネルギー等)1枚につきper追加ダメージ(Plasma Energy等)。"""

    base: int
    per: int
    name: str

    def execute(self, ctx: EffectContext) -> None:
        if ctx.source_pokemon is None:
            return
        count = sum(
            1
            for e in ctx.source_pokemon.attached_energy
            if (c := ctx.card_db.get(e)) is not None and c.name == self.name
        )
        DealDamage(self.base + self.per * count).execute(ctx)


@dataclass(frozen=True)
class DamagePerDistinctBasicEnergyTypes(Effect):
    """このポケモンについている基本エネルギーの、種類の数1つにつきper追加ダメージ。"""

    base: int
    per: int

    def execute(self, ctx: EffectContext) -> None:
        if ctx.source_pokemon is None:
            return
        types = {
            c.basic_energy_type
            for e in ctx.source_pokemon.attached_energy
            if (c := ctx.card_db.get(e)) is not None and c.basic_energy_type is not None
        }
        DealDamage(self.base + self.per * len(types)).execute(ctx)


@dataclass(frozen=True)
class DiscardAllOwnEnergyOfTypeThenDamagePer(Effect):
    """このポケモンについている指定タイプの基本エネルギーを全てトラッシュし、トラッシュした枚数×perダメージ。"""

    energy_type: str
    per: int

    def execute(self, ctx: EffectContext) -> None:
        if ctx.source_pokemon is None:
            return
        player = _attacker_player(ctx)
        kept, discarded = [], []
        for e in ctx.source_pokemon.attached_energy:
            c = ctx.card_db.get(e)
            (discarded if c is not None and c.basic_energy_type == self.energy_type else kept).append(e)
        ctx.source_pokemon.attached_energy = kept
        player.discard.extend(discarded)
        DealDamage(self.per * len(discarded)).execute(ctx)


# ---------------------------------------------------------------------------------------------
# コインを使うダメージ
# ---------------------------------------------------------------------------------------------
@dataclass(frozen=True)
class FlipCoinsAllHeadsBonusDamage(Effect):
    """コインをcount枚投げ、全てオモテなら追加ダメージ("Flip 2 coins. If both of them are heads, this attack does N more damage.")。"""

    base: int
    bonus: int
    count: int

    def execute(self, ctx: EffectContext) -> None:
        heads = sum(1 for _ in range(self.count) if ctx.rng.random() < 0.5)
        ctx.coin_heads_count = heads
        DealDamage(self.base + (self.bonus if heads == self.count else 0)).execute(ctx)


@dataclass(frozen=True)
class DealDamageUnlessAllCoinsTails(Effect):
    """コインをcount枚投げ、全てウラならこのワザは何もしない(1枚でもオモテならダメージを与える)。"""

    base: int
    count: int

    def execute(self, ctx: EffectContext) -> None:
        heads = sum(1 for _ in range(self.count) if ctx.rng.random() < 0.5)
        ctx.coin_heads_count = heads
        if heads > 0:
            DealDamage(self.base).execute(ctx)


@dataclass(frozen=True)
class DamagePerHeadsToAllOpponentPokemon(Effect):
    """コインをcoin_count枚投げ、オモテ1枚につきdamage_per_headsダメージを相手の場の全ポケモンに与える
    (ベンチは弱点・抵抗力を計算しない)。"""

    coin_count: int
    damage_per_heads: int

    def execute(self, ctx: EffectContext) -> None:
        heads = sum(1 for _ in range(self.coin_count) if ctx.rng.random() < 0.5)
        ctx.coin_heads_count = heads
        amount = heads * self.damage_per_heads
        if amount <= 0:
            return
        from effects.primitives import DealDamageToAllOpponentPokemon

        DealDamageToAllOpponentPokemon(amount).execute(ctx)


@dataclass(frozen=True)
class CoinFlipDamageToEachOpponentPokemon(Effect):
    """相手の場のポケモン1匹ごとにコインを投げ、オモテならそのポケモンにamountダメージ(ベンチは弱点・抵抗力を計算しない)。"""

    amount: int

    def execute(self, ctx: EffectContext) -> None:
        from effects.primitives import DealDamageToAllOpponentPokemon

        opponent = ctx.state.player(ctx.opponent)
        mons = opponent.all_pokemon_in_play()
        for mon in mons:
            if ctx.rng.random() < 0.5:
                _damage_single_opponent_pokemon(ctx, mon, self.amount)


def _damage_single_opponent_pokemon(ctx: EffectContext, mon, amount: int) -> None:
    """相手の1匹にダメージ(バトルポケモンは弱点・抵抗力を計算、ベンチは計算しない)。"""
    opponent = ctx.state.player(ctx.opponent)
    if _defender_is_shielded(ctx, mon):
        return
    card = ctx.card_db.get(mon.card_id)
    if card is None:
        return
    if mon is opponent.active:
        dealt = resolve_attack_damage(ctx, mon, card, amount)
    else:
        dealt = amount
    mon.damage += dealt
    ctx.damage_dealt += dealt


# ---------------------------------------------------------------------------------------------
# 次の番まで続く効果
# ---------------------------------------------------------------------------------------------
@dataclass(frozen=True)
class NextTurnAttackBonus(Effect):
    """自分の次の番、このポケモンのワザ(attack_name指定時はそのワザだけ)のダメージにamountを加える
    ("During your next turn, this Pokémon's Echoed Voice attack does 50 more damage (before applying Weakness and
    Resistance).")。ダメージ計算の「攻撃側の効果」(弱点・抵抗力の前)で加算する。"""

    amount: int
    attack_name: str = ""

    def execute(self, ctx: EffectContext) -> None:
        if ctx.source_pokemon is None:
            return
        ctx.source_pokemon.attack_bonus_until_turn = _attacker_player(ctx).turns_taken + 1
        ctx.source_pokemon.attack_bonus_amount = self.amount
        ctx.source_pokemon.attack_bonus_attack_name = self.attack_name


@dataclass(frozen=True)
class NoWeaknessNextOpponentTurn(Effect):
    """相手の次の番、このポケモンは弱点を持たない。"""

    def execute(self, ctx: EffectContext) -> None:
        if ctx.source_pokemon is None:
            return
        ctx.source_pokemon.no_weakness_until_turn = ctx.state.player(ctx.opponent).turns_taken + 1


@dataclass(frozen=True)
class PreventDamageUpToNextOpponentTurn(Effect):
    """相手の次の番、このポケモンがワザでダメージを受けるとき、そのダメージがthreshold以下なら防ぐ("prevent that
    attack's damage done to this Pokémon if that damage is 40 or less")。"""

    threshold: int

    def execute(self, ctx: EffectContext) -> None:
        if ctx.source_pokemon is None:
            return
        ctx.source_pokemon.damage_prevent_threshold_until_turn = ctx.state.player(ctx.opponent).turns_taken + 1
        ctx.source_pokemon.damage_prevent_threshold = self.threshold


# ---------------------------------------------------------------------------------------------
# 手札
# ---------------------------------------------------------------------------------------------
@dataclass(frozen=True)
class ShuffleHandThenDrawEqualToOpponentHand(Effect):
    """自分の手札を山札に戻してシャッフルし、相手の手札の枚数と同じだけ引く。"""

    def execute(self, ctx: EffectContext) -> None:
        player = _attacker_player(ctx)
        opponent = ctx.state.player(ctx.opponent)
        draw_count = len(opponent.hand)
        player.deck.extend(player.hand)
        player.hand = []
        ctx.rng.shuffle(player.deck)
        for _ in range(draw_count):
            if not player.deck:
                break
            player.hand.append(player.deck.pop(0))


@dataclass(frozen=True)
class ShuffleHandThenDrawWithNamedBenchBonus(Effect):
    """自分の手札を山札に戻してシャッフルし、count枚引く。ベンチに指定した名前のポケモンがいればさらにbonus枚引く
    ("If Minun is on your Bench, draw 4 more cards.")。"""

    count: int
    bonus: int
    name: str

    def execute(self, ctx: EffectContext) -> None:
        player = _attacker_player(ctx)
        total = self.count
        if any((c := ctx.card_db.get(m.card_id)) is not None and c.name == self.name for m in player.bench):
            total += self.bonus
        player.deck.extend(player.hand)
        player.hand = []
        ctx.rng.shuffle(player.deck)
        for _ in range(total):
            if not player.deck:
                break
            player.hand.append(player.deck.pop(0))


@dataclass(frozen=True)
class HealAllOwnPokemonWithEnergy(Effect):
    """自分の場の、エネルギーがついているポケモン全員のダメージをamountずつ回復する("Heal 20 damage from each of your
    Pokémon that has any Energy attached to it.")。"""

    amount: int

    def execute(self, ctx: EffectContext) -> None:
        for mon in _attacker_player(ctx).all_pokemon_in_play():
            if mon.attached_energy:
                mon.heal(self.amount)


@dataclass(frozen=True)
class IfSelfHasEnergyNamed(Effect):
    """このポケモンに指定した名前のエネルギー(Plasma Energy等)がついていれば、thenの効果を実行する。"""

    name: str
    then: tuple = ()

    def execute(self, ctx: EffectContext) -> None:
        if ctx.source_pokemon is None:
            return
        if any((c := ctx.card_db.get(e)) is not None and c.name == self.name for e in ctx.source_pokemon.attached_energy):
            for effect in self.then:
                effect.execute(ctx)


@dataclass(frozen=True)
class DamageIfCondition(Effect):
    """条件を満たすときだけbaseダメージを与える(満たさなければこのワザは何もしない)。"If ..., this attack does nothing."の
    条件を反転した形で使う(例: ドリームイーター=相手がねむりでなければ何もしない)。"""

    base: int
    condition: str
    arg: str = ""

    def execute(self, ctx: EffectContext) -> None:
        if condition_met(ctx, self.condition, self.arg):
            DealDamage(self.base).execute(ctx)
        else:
            ctx.log("条件を満たさないので、このワザは何もしなかった")


@dataclass(frozen=True)
class IfCondition(Effect):
    """条件を満たすときだけ、thenの効果を実行する(ダメージの後ろに足す追加効果用)。"""

    condition: str
    then: tuple = ()
    arg: str = ""

    def execute(self, ctx: EffectContext) -> None:
        if condition_met(ctx, self.condition, self.arg):
            for effect in self.then:
                effect.execute(ctx)


@dataclass(frozen=True)
class DamagePerOwnHandCount(Effect):
    """自分の手札1枚につきper_cardダメージ。"""

    per_card: int

    def execute(self, ctx: EffectContext) -> None:
        DealDamage(self.per_card * len(_attacker_player(ctx).hand)).execute(ctx)


@dataclass(frozen=True)
class DamagePerOwnPokemonEnergyCount(Effect):
    """自分の場の全てのポケモンについているエネルギー1個につきper_energyダメージ。"""

    per_energy: int

    def execute(self, ctx: EffectContext) -> None:
        total = sum(len(m.attached_energy) for m in _attacker_player(ctx).all_pokemon_in_play())
        DealDamage(self.per_energy * total).execute(ctx)


@dataclass(frozen=True)
class DamagePerHeadsForEachSelfDamageCounter(Effect):
    """このポケモンのダメカン1個につきコインを1枚投げ、オモテ1枚につきdamage_per_headsダメージ。"""

    damage_per_heads: int

    def execute(self, ctx: EffectContext) -> None:
        if ctx.source_pokemon is None:
            return
        coins = ctx.source_pokemon.damage // 10
        heads = sum(1 for _ in range(coins) if ctx.rng.random() < 0.5)
        ctx.coin_heads_count = heads
        DealDamage(heads * self.damage_per_heads).execute(ctx)


@dataclass(frozen=True)
class DamagePerPrizesTakenBothPlayers(Effect):
    """両プレイヤーが取ったサイドの合計枚数1枚につきper_prizeダメージ。"""

    base: int
    per_prize: int

    def execute(self, ctx: EffectContext) -> None:
        taken = (6 - len(ctx.state.player(ctx.acting_player).prizes)) + (6 - len(ctx.state.player(ctx.opponent).prizes))
        DealDamage(self.base + self.per_prize * taken).execute(ctx)


@dataclass(frozen=True)
class HealDefender(Effect):
    """相手のバトルポケモンのダメージをamountぶん回復する("Heal 30 damage from both Active Pokémon.")。"""

    amount: int

    def execute(self, ctx: EffectContext) -> None:
        _, defender = _defender(ctx)
        if defender is not None:
            defender.heal(self.amount)


@dataclass(frozen=True)
class OpponentDraws(Effect):
    """相手がcount枚引く("Your opponent draws a card.")。"""

    count: int

    def execute(self, ctx: EffectContext) -> None:
        opponent = ctx.state.player(ctx.opponent)
        for _ in range(self.count):
            if not opponent.deck:
                break
            opponent.hand.append(opponent.deck.pop(0))


@dataclass(frozen=True)
class OpponentDiscardsFromHand(Effect):
    """相手が、自分で選んで手札をcount枚トラッシュする("Your opponent discards a card from his or her hand.")。"""

    count: int

    def execute(self, ctx: EffectContext) -> None:
        from engine.state import PendingSearchChoice

        opponent = ctx.state.player(ctx.opponent)
        n = min(self.count, len(opponent.hand))
        if n <= 0:
            return
        ctx.state.pending_search_choice = PendingSearchChoice(
            player_index=ctx.opponent,
            zone="hand",
            source_indices=list(range(len(opponent.hand))),
            card_ids=list(opponent.hand),
            min_count=n,
            max_count=n,
            prompt=f"手札を{n}枚トラッシュする",
            shuffle_after=False,
            all_card_ids=list(opponent.hand),
            destination="discard",
        )


@dataclass(frozen=True)
class ClearDefenderStatusConditions(Effect):
    """相手のバトルポケモンの特殊状態を全て治す("Remove all Special Conditions from the Defending Pokémon.")。"""

    def execute(self, ctx: EffectContext) -> None:
        _, defender = _defender(ctx)
        if defender is not None:
            defender.status.clear_all()


@dataclass(frozen=True)
class DamageCountersOnEachOpponentPokemon(Effect):
    """相手の場の全てのポケモンにダメカンをcount個ずつのせる(弱点・抵抗力は計算しない)。"""

    count: int

    def execute(self, ctx: EffectContext) -> None:
        for mon in ctx.state.player(ctx.opponent).all_pokemon_in_play():
            mon.damage += 10 * self.count


@dataclass(frozen=True)
class DrawWithNamedBenchBonus(Effect):
    """count枚引き、ベンチに指定した名前のポケモンがいればさらにbonus枚引く。"""

    count: int
    bonus: int
    name: str

    def execute(self, ctx: EffectContext) -> None:
        from effects.primitives import Draw

        player = _attacker_player(ctx)
        total = self.count
        if any((c := ctx.card_db.get(m.card_id)) is not None and c.name == self.name for m in player.bench):
            total += self.bonus
        if total > 0:
            Draw(total).execute(ctx)


@dataclass(frozen=True)
class DiscardOwnHandBasicEnergyOfChoiceThenDraw(Effect):
    """手札の基本エネルギーを1枚(どれかは自分で選んで)トラッシュし、そうしたらdraw_count枚引く。energy_type指定時はそのタイプのみ。
    手札に対象が無ければ何もしない。"""

    draw_count: int
    energy_type: str | None = None

    def execute(self, ctx: EffectContext) -> None:
        from effects.primitives import Draw, _trigger_search_choice

        player = _attacker_player(ctx)

        def matches(card):
            return (
                card is not None
                and card.basic_energy_type is not None
                and (self.energy_type is None or card.basic_energy_type == self.energy_type)
            )

        _trigger_search_choice(
            ctx, player, "hand", matches, 1, "トラッシュする基本エネルギーを選ぶ", shuffle_after=False, destination="discard",
            min_count=1,
        )
        pending = ctx.state.pending_search_choice
        if pending is not None:
            pending.remaining_script = (Draw(self.draw_count),)
            pending.cont_source_pokemon = ctx.source_pokemon
            pending.cont_source_card_id = ctx.source_card_id


@dataclass(frozen=True)
class DamagePerEnergyTypeAcrossBothSides(Effect):
    """場の全ポケモン(両プレイヤー)についている、指定タイプの基本エネルギー1個につきper追加ダメージ。"""

    base: int
    per: int
    energy_type: str

    def execute(self, ctx: EffectContext) -> None:
        count = 0
        for idx in (ctx.acting_player, ctx.opponent):
            for mon in ctx.state.player(idx).all_pokemon_in_play():
                count += sum(
                    1 for e in mon.attached_energy
                    if (c := ctx.card_db.get(e)) is not None and c.basic_energy_type == self.energy_type
                )
        DealDamage(self.base + self.per * count).execute(ctx)


@dataclass(frozen=True)
class DamagePerOwnBoardEnergyOfType(Effect):
    """自分の場の全ポケモンについている、指定タイプの基本エネルギー1個につきper追加ダメージ。"""

    base: int
    per: int
    energy_type: str

    def execute(self, ctx: EffectContext) -> None:
        count = 0
        for mon in _attacker_player(ctx).all_pokemon_in_play():
            count += sum(
                1 for e in mon.attached_energy
                if (c := ctx.card_db.get(e)) is not None and c.basic_energy_type == self.energy_type
            )
        DealDamage(self.base + self.per * count).execute(ctx)


# ---------------------------------------------------------------------------------------------
# 第9弾
# ---------------------------------------------------------------------------------------------
@dataclass(frozen=True)
class DealDamageToChosenOpponentPokemonPerSelfEnergy(Effect):
    """相手の場のポケモン1匹(自分で選ぶ。ベンチは弱点・抵抗力を計算しない)に、このポケモンについているエネルギー(energy_type指定時は
    そのタイプのみ)1個につきperダメージ。"""

    per: int
    energy_type: str | None = None
    attack_target = "opp_any"  # engine.legal_actionsが相手の場のポケモンを選ぶ選択肢を出す

    def execute(self, ctx: EffectContext) -> None:
        from effects.primitives import DealDamageToChosenOpponentPokemon

        if ctx.source_pokemon is None:
            return
        if self.energy_type is None:
            count = len(ctx.source_pokemon.attached_energy)
        else:
            count = sum(
                1 for e in ctx.source_pokemon.attached_energy
                if (c := ctx.card_db.get(e)) is not None and c.basic_energy_type == self.energy_type
            )
        DealDamageToChosenOpponentPokemon(self.per * count).execute(ctx)


@dataclass(frozen=True)
class SetDefenderRemainingHP(Effect):
    """相手のバトルポケモンに、残りHPがhpになるまでダメカンをのせる(残りHPがすでにhp以下なら何もしない)。"""

    hp: int

    def execute(self, ctx: EffectContext) -> None:
        _, defender = _defender(ctx)
        if defender is None:
            return
        card = ctx.card_db.get(defender.card_id)
        if card is None or card.hp is None:
            return
        target_damage = card.hp - self.hp
        if defender.damage < target_damage:
            defender.damage = target_damage


@dataclass(frozen=True)
class SetBothActiveRemainingHP(Effect):
    """両方のバトルポケモンに、それぞれ残りHPがhpになるまでダメカンをのせる。"""

    hp: int

    def execute(self, ctx: EffectContext) -> None:
        SetDefenderRemainingHP(self.hp).execute(ctx)
        if ctx.source_pokemon is not None:
            card = ctx.card_db.get(ctx.source_pokemon.card_id)
            if card is not None and card.hp is not None and ctx.source_pokemon.damage < card.hp - self.hp:
                ctx.source_pokemon.damage = card.hp - self.hp


@dataclass(frozen=True)
class ReturnDefenderToOpponentHand(Effect):
    """相手のバトルポケモンとついているカードを全て、相手の手札に戻す。"""

    def execute(self, ctx: EffectContext) -> None:
        opponent = ctx.state.player(ctx.opponent)
        mon = opponent.active
        if mon is None:
            return
        opponent.hand.extend(mon.evolution_history)
        opponent.hand.append(mon.card_id)
        opponent.hand.extend(mon.attached_energy)
        if mon.attached_tool:
            opponent.hand.append(mon.attached_tool)
        opponent.active = None
        if opponent.bench:
            ctx.state.pending_active_choice = [ctx.opponent] + [i for i in ctx.state.pending_active_choice if i != ctx.opponent]


@dataclass(frozen=True)
class ShuffleDefenderIntoOpponentDeck(Effect):
    """相手のバトルポケモンとついているカードを全て、相手の山札に戻してシャッフルする。"""

    def execute(self, ctx: EffectContext) -> None:
        opponent = ctx.state.player(ctx.opponent)
        mon = opponent.active
        if mon is None:
            return
        opponent.deck.extend(mon.evolution_history)
        opponent.deck.append(mon.card_id)
        opponent.deck.extend(mon.attached_energy)
        if mon.attached_tool:
            opponent.deck.append(mon.attached_tool)
        opponent.active = None
        ctx.rng.shuffle(opponent.deck)
        if opponent.bench:
            ctx.state.pending_active_choice = [ctx.opponent] + [i for i in ctx.state.pending_active_choice if i != ctx.opponent]


@dataclass(frozen=True)
class DiscardTopNDamagePerEnergyType(Effect):
    """自分の山札の上からn枚をトラッシュし、その中の指定タイプの基本エネルギー1枚につきperダメージ。"""

    n: int
    per: int
    energy_type: str

    def execute(self, ctx: EffectContext) -> None:
        player = _attacker_player(ctx)
        top = player.deck[: self.n]
        player.deck = player.deck[self.n :]
        player.discard.extend(top)
        count = sum(1 for cid in top if (c := ctx.card_db.get(cid)) is not None and c.basic_energy_type == self.energy_type)
        DealDamage(self.per * count).execute(ctx)


@dataclass(frozen=True)
class DiscardTopNBonusPerSupporter(Effect):
    """自分の山札の上からn枚をトラッシュし、その中のサポート1枚につきper追加ダメージ。"""

    n: int
    base: int
    per: int

    def execute(self, ctx: EffectContext) -> None:
        player = _attacker_player(ctx)
        top = player.deck[: self.n]
        player.deck = player.deck[self.n :]
        player.discard.extend(top)
        count = sum(1 for cid in top if (c := ctx.card_db.get(cid)) is not None and c.is_supporter)
        DealDamage(self.base + self.per * count).execute(ctx)


@dataclass(frozen=True)
class FlipCoinsLadderDamage(Effect):
    """コインをcount枚投げ、オモテの枚数(1枚以上)に応じてtiers[オモテの数-1]のダメージ(オモテ0枚なら0。bonus=Trueなら
    baseに加算する追加ダメージ、Falseなら固定ダメージ)。"Flip 3 coins. If 1 of them is heads, this attack does 10 damage. If 2 ... 30
    ... If all ... 60."""

    count: int
    tiers: tuple[int, ...]
    base: int = 0
    bonus: bool = False

    def execute(self, ctx: EffectContext) -> None:
        heads = sum(1 for _ in range(self.count) if ctx.rng.random() < 0.5)
        ctx.coin_heads_count = heads
        extra = self.tiers[heads - 1] if heads >= 1 else 0
        DealDamage(self.base + extra if self.bonus else extra).execute(ctx)


@dataclass(frozen=True)
class FlipTwoCoinsParalyzeOrNothing(Effect):
    """コインを2枚投げ、2枚ともオモテなら相手をマヒにする。2枚ともウラなら何もしない(それ以外はダメージだけ)。"""

    base: int

    def execute(self, ctx: EffectContext) -> None:
        from effects.primitives import InflictStatusOnDefender

        heads = sum(1 for _ in range(2) if ctx.rng.random() < 0.5)
        ctx.coin_heads_count = heads
        if heads == 0:
            return
        DealDamage(self.base).execute(ctx)
        if heads == 2:
            InflictStatusOnDefender("paralyzed").execute(ctx)


@dataclass(frozen=True)
class SelfDamageIfAllCoinsTails(Effect):
    """コインをcount枚投げ、全てウラなら自分にamountダメージ。"""

    count: int
    amount: int

    def execute(self, ctx: EffectContext) -> None:
        heads = sum(1 for _ in range(self.count) if ctx.rng.random() < 0.5)
        ctx.coin_heads_count = heads
        if heads == 0 and ctx.source_pokemon is not None:
            from effects.era_trainers import era_self_damage_prevented

            if not era_self_damage_prevented(ctx.state, ctx.source_pokemon):
                ctx.source_pokemon.damage += self.amount
            ctx.log(f"自分に{self.amount}ダメージ")


@dataclass(frozen=True)
class FlipUntilTailsThenRepeat(Effect):
    """ウラが出るまでコインを投げ続け、オモテ1回につきeffectを1回実行する。"""

    effect: Effect

    def execute(self, ctx: EffectContext) -> None:
        heads = 0
        while ctx.rng.random() < 0.5 and heads < 50:
            heads += 1
        ctx.coin_heads_count = heads
        for _ in range(heads):
            self.effect.execute(ctx)


@dataclass(frozen=True)
class DamageToOpponentBenchSharingTypeWithDefender(Effect):
    """相手のベンチポケモンのうち、相手のバトルポケモンとタイプを共有するもの全員に固定ダメージ(弱点・抵抗力は計算しない)。"""

    amount: int

    def execute(self, ctx: EffectContext) -> None:
        opponent = ctx.state.player(ctx.opponent)
        if opponent.active is None:
            return
        active_card = ctx.card_db.get(opponent.active.card_id)
        if active_card is None:
            return
        for mon in opponent.bench:
            card = ctx.card_db.get(mon.card_id)
            if card is not None and set(card.types) & set(active_card.types):
                mon.damage += self.amount
                ctx.damage_dealt += self.amount


# ---------------------------------------------------------------------------------------------
# 第10弾
# ---------------------------------------------------------------------------------------------
def _own_matching_energy(ctx: EffectContext, energy_type: str | None) -> list[str]:
    if ctx.source_pokemon is None:
        return []
    return [
        e for e in ctx.source_pokemon.attached_energy
        if (c := ctx.card_db.get(e)) is not None
        and (energy_type is None or c.basic_energy_type == energy_type)
    ]


@dataclass(frozen=True)
class OptionalCostEffect(Effect):
    """「〜してもよい。そうしたら、(このワザは追加ダメージ/追加効果)」型のワザ。使うかどうかはワザを選ぶときに決める
    (engine.legal_actionsが「使わない」Attack(i)と「使う」Attack(i, 0)を出す)。使う版では、まずコストを払い、そのあと基本ダメージ+
    追加ダメージ(1回のダメージ計算)と追加効果を実行する。コストを払えないときは「使う」版は出さない。
    cost: "energy"(エネルギー1枚、cost_arg=タイプ名かNone) / "all_energy_type"(cost_arg=タイプの全て) /
    "two_energy_types"(cost_arg="Grass,Fighting") / "hand_item"(手札のグッズ1枚。cost_argにカード名の一部を指定可) /
    "stadium"(場のスタジアム) / "none"。"""

    base: int
    bonus: int
    cost: str
    cost_arg: str | None = None
    then: tuple = ()
    optional_variant = True

    def variant_payable(self, state, player, mon, card_db) -> bool:
        if self.cost == "energy":
            return any(
                (c := card_db.get(e)) is not None and (self.cost_arg is None or c.basic_energy_type == self.cost_arg)
                for e in mon.attached_energy
            )
        if self.cost == "all_energy_type":
            return any((c := card_db.get(e)) is not None and c.basic_energy_type == self.cost_arg for e in mon.attached_energy)
        if self.cost == "two_energy_types":
            for t in (self.cost_arg or "").split(","):
                if not any((c := card_db.get(e)) is not None and c.basic_energy_type == t for e in mon.attached_energy):
                    return False
            return True
        if self.cost == "hand_item":
            return any(
                (c := card_db.get(cid)) is not None and c.is_item and (not self.cost_arg or self.cost_arg in c.name)
                for cid in player.hand
            )
        if self.cost == "stadium":
            return state.stadium_in_play is not None
        return True

    def execute(self, ctx: EffectContext) -> None:
        from effects.interpreter import run_script
        from effects.primitives import (
            DiscardAllOwnEnergy,
            DiscardCardsFromHand,
            DiscardOwnEnergy,
            DiscardStadiumInPlay,
        )

        player = _attacker_player(ctx)
        if ctx.target_bench_index != 0 or ctx.source_pokemon is None or not self.variant_payable(
            ctx.state, player, ctx.source_pokemon, ctx.card_db
        ):
            DealDamage(self.base).execute(ctx)
            return
        steps: list[Effect] = []
        if self.cost == "energy":
            steps.append(DiscardOwnEnergy(count=1, energy_type=self.cost_arg))
        elif self.cost == "all_energy_type":
            steps.append(DiscardAllOwnEnergy(energy_type=self.cost_arg))
        elif self.cost == "two_energy_types":
            steps += [DiscardOwnEnergy(count=1, energy_type=t) for t in (self.cost_arg or "").split(",")]
        elif self.cost == "hand_item":
            steps.append(DiscardCardsFromHand(count=1, only_item=True))
        elif self.cost == "stadium":
            steps.append(DiscardStadiumInPlay())
        steps.append(DealDamage(self.base + self.bonus) if self.bonus or self.base else DealDamage(0))
        steps.extend(self.then)
        run_script(tuple(steps), ctx)


@dataclass(frozen=True)
class DamagePerHeadsPlusStatusIfAny(Effect):
    """コインをcoin_count枚投げ、オモテ1枚につきdamage_per_headsダメージ。1枚でもオモテなら相手のバトルポケモンに状態異常。"""

    coin_count: int
    damage_per_heads: int
    status: str

    def execute(self, ctx: EffectContext) -> None:
        from effects.primitives import InflictStatusOnDefender

        heads = sum(1 for _ in range(self.coin_count) if ctx.rng.random() < 0.5)
        ctx.coin_heads_count = heads
        DealDamage(heads * self.damage_per_heads).execute(ctx)
        if heads > 0:
            InflictStatusOnDefender(self.status).execute(ctx)


@dataclass(frozen=True)
class DamagePerHeadsToChosenOpponentPokemon(Effect):
    """コインをcoin_count枚投げ、オモテ1枚につきdamage_per_headsダメージを、相手の場のポケモン1匹(自分で選ぶ。ベンチは弱点・
    抵抗力を計算しない)に与える。"""

    coin_count: int
    damage_per_heads: int
    attack_target = "opp_any"

    def execute(self, ctx: EffectContext) -> None:
        from effects.primitives import DealDamageToChosenOpponentPokemon

        heads = sum(1 for _ in range(self.coin_count) if ctx.rng.random() < 0.5)
        ctx.coin_heads_count = heads
        if heads > 0:
            DealDamageToChosenOpponentPokemon(heads * self.damage_per_heads).execute(ctx)


def _chosen_opponent_target(ctx: EffectContext):
    from effects.primitives import _resolve_opponent_target

    return _resolve_opponent_target(ctx, ctx.state.player(ctx.opponent))


@dataclass(frozen=True)
class DealDamageToChosenOpponentPokemonCustomWR(Effect):
    """相手の場のポケモン1匹(自分で選ぶ)にamountダメージ。bench_weakness_resistance=Trueならベンチにも弱点・抵抗力を計算する
    ("Also apply Weakness and Resistance for Benched Pokémon")。ignore_weakness_resistance=Trueなら対象がバトルポケモンでも
    弱点・抵抗力を計算しない。ignore_effects=Trueならそのポケモンにかかっている効果も無視する。"""

    amount: int
    bench_weakness_resistance: bool = False
    ignore_weakness_resistance: bool = False
    ignore_effects: bool = False
    attack_target = "opp_any"

    def execute(self, ctx: EffectContext) -> None:
        if ctx.source_pokemon is None:
            return
        opponent = ctx.state.player(ctx.opponent)
        target = _chosen_opponent_target(ctx)
        if target is None or (not self.ignore_effects and _defender_is_shielded(ctx, target)):
            return
        card = ctx.card_db.get(target.card_id)
        if card is None:
            return
        is_active = target is opponent.active
        apply_wr = not self.ignore_weakness_resistance and (is_active or self.bench_weakness_resistance)
        dealt = resolve_attack_damage(
            ctx, target, card, self.amount, apply_weakness=apply_wr, apply_resistance=apply_wr,
            apply_defender_side_effects=not self.ignore_effects,
        )
        target.damage += dealt
        ctx.damage_dealt += dealt


@dataclass(frozen=True)
class FlipCoinThenDiscardChosenOpponentEnergy(Effect):
    """コインを1回投げ、オモテなら相手の場のポケモン1匹(自分で選ぶ)についているエネルギーを1枚トラッシュする。"""

    attack_target = "opp_any"

    def execute(self, ctx: EffectContext) -> None:
        from effects.primitives import FlipCoinThenDiscardOpponentEnergy

        FlipCoinThenDiscardOpponentEnergy().execute(ctx)


@dataclass(frozen=True)
class DamageBonusPerOpponentPokemonWithSubtype(Effect):
    """相手の場のポケモンのうち、指定サブタイプ(EX等)1匹につきper追加ダメージ。"""

    base: int
    per: int
    subtype: str

    def execute(self, ctx: EffectContext) -> None:
        count = sum(
            1 for m in ctx.state.player(ctx.opponent).all_pokemon_in_play()
            if (c := ctx.card_db.get(m.card_id)) is not None and self.subtype in c.subtypes
        )
        DealDamage(self.base + self.per * count).execute(ctx)


@dataclass(frozen=True)
class DamagePerOwnBenchedDamageCounters(Effect):
    """自分のベンチポケモン(name_prefix指定時はその名前のものだけ)に乗っているダメカン1個につきper追加ダメージ。"""

    base: int
    per: int
    name_prefix: str = ""

    def execute(self, ctx: EffectContext) -> None:
        total = 0
        for m in _attacker_player(ctx).bench:
            c = ctx.card_db.get(m.card_id)
            if self.name_prefix and (c is None or not c.name.startswith(self.name_prefix)):
                continue
            total += m.damage // 10
        DealDamage(self.base + self.per * total).execute(ctx)


@dataclass(frozen=True)
class DamagePerOwnBenchedNamed(Effect):
    """自分のベンチの、指定した名前のポケモン1匹につきper追加ダメージ。"""

    base: int
    per: int
    name: str

    def execute(self, ctx: EffectContext) -> None:
        count = sum(
            1 for m in _attacker_player(ctx).bench if (c := ctx.card_db.get(m.card_id)) is not None and c.name == self.name
        )
        DealDamage(self.base + self.per * count).execute(ctx)


@dataclass(frozen=True)
class DiscardAllItemsFromOpponentHand(Effect):
    """相手の手札を公開させ、その中のグッズを全てトラッシュする。"""

    def execute(self, ctx: EffectContext) -> None:
        opponent = ctx.state.player(ctx.opponent)
        ctx.state.player(ctx.acting_player).known_opponent_hand = list(opponent.hand)
        ctx.reveal("相手の手札", list(opponent.hand))
        kept = []
        for cid in opponent.hand:
            c = ctx.card_db.get(cid)
            (opponent.discard if c is not None and c.is_item else kept).append(cid)
        opponent.hand = kept


@dataclass(frozen=True)
class LockOpponentSupportersNextTurn(Effect):
    """相手の次の番、相手はサポートを使えない。"""

    def execute(self, ctx: EffectContext) -> None:
        opponent = ctx.state.player(ctx.opponent)
        opponent.supporters_locked_until_turn = opponent.turns_taken + 1


@dataclass(frozen=True)
class DefenderCannotAttachEnergyNextTurn(Effect):
    """相手は次の番、手札からこのワザを受けたポケモンにエネルギーをつけられない。"""

    def execute(self, ctx: EffectContext) -> None:
        _, defender = _defender(ctx)
        if defender is not None:
            defender.no_energy_attach_until_turn = ctx.state.player(ctx.opponent).turns_taken + 1


@dataclass(frozen=True)
class DefenderCannotEvolveNextTurn(Effect):
    """相手は次の番、手札からポケモンを出して、このワザを受けたポケモンを進化させられない。"""

    def execute(self, ctx: EffectContext) -> None:
        _, defender = _defender(ctx)
        if defender is not None:
            defender.no_evolve_until_turn = ctx.state.player(ctx.opponent).turns_taken + 1


@dataclass(frozen=True)
class DefenderNoAbilitiesUntilEndOfNextTurn(Effect):
    """このワザを受けたポケモンは、あなたの次の番の終わりまで特性を持たない。"""

    def execute(self, ctx: EffectContext) -> None:
        _, defender = _defender(ctx)
        if defender is not None:
            defender.abilities_off_until_turn = ctx.state.player(ctx.acting_player).turns_taken + 1


@dataclass(frozen=True)
class IncomingDamageIncreaseNextTurn(Effect):
    """相手の次の番、このポケモンがワザで受けるダメージがamount増える(弱点・抵抗力のあと)。"""

    amount: int

    def execute(self, ctx: EffectContext) -> None:
        if ctx.source_pokemon is None:
            return
        ctx.source_pokemon.incoming_damage_bonus_until_turn = ctx.state.player(ctx.opponent).turns_taken + 1
        ctx.source_pokemon.incoming_damage_bonus_amount = self.amount


@dataclass(frozen=True)
class DamageCountersOnEachDamagedOpponentPokemon(Effect):
    """相手の場の、すでにダメカンが乗っているポケモン全員に、ダメカンをcount個ずつのせる。"""

    count: int

    def execute(self, ctx: EffectContext) -> None:
        for mon in ctx.state.player(ctx.opponent).all_pokemon_in_play():
            if mon.damage > 0:
                mon.damage += 10 * self.count
