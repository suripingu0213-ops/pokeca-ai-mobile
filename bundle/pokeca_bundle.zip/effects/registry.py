"""カードID → 効果スクリプトのマッピング(厳選カードプール用)。

新しいカードを追加するときは、ここに1エントリ追加するだけでよい
(既存のプリミティブで表現できない効果があれば primitives.py に追加する)。
"""

from __future__ import annotations

from effects.card_aliases import AliasStr

_PLASMA_ENERGY_ID = AliasStr("bw10-91")  # プラズマエネルギー(再録のIDとも==で等しい)

from effects.primitives import (
    CopyOpponentActiveAttack,
    DamageCountersOnDefenderPerOwnHandCount,
    DamageIfOwnBenchedNamePrefixInPlayElseZero,
    DamagePerChosenOpponentBenchedDamageCounters,
    DamagePerOwnDiscardSupporterNameContainsCount,
    DebuffDefenderAttackDamageNextTurn,
    DiscardChosenOwnHandSupportersThenScalingDamage,
    DiscardUpToOwnEnergyThenBonusDamage,
    KnockOutDefenderIfExactDamageCounters,
    MayDiscardOwnHandCardThenOpponentDiscardsOne,
    RevealOpponentHandThenChosenToBottomOfDeck,
    RevealOpponentHandOnly,
    RevealOpponentHandThenDiscardChosen,
    ActivatePermanentMetalDamageReduction,
    AttachEnergyFromDiscardToEachOwnBenchedOfType,
    AttachEnergyFromDiscardToOwnPokemon,
    AttachEnergyFromDiscardToOwnPokemonWithChoice,
    BonusPrizeIfTeraKnockedOutOpponentThisTurn,
    BonusPrizeIfThisAttackKnockedOutOpponent,
    BounceOpponentActiveEnergyThenAttachFromHand,
    AttachEnergyFromHandToChosenOwnPokemon,
    AttachEnergyFromHandToSelf,
    ChooseUpToNOwnBenchedThenAttachDiscardEnergyToEach,
    AttachEnergyFromHandToTarget,
    AttachSelfAsRetreatReducingTool,
    AttachToolToOpponentActiveEX,
    ApplyDamageReductionToSelf,
    ApplyScopedDamageImmunityToSelf,
    ApplyShieldToSelf,
    BenchDamageAll,
    BothPlayersShuffleHandAndDrawAsymmetric,
    BothPlayersShuffleHandAndDrawByPrizes,
    BothPlayersShuffleHandIntoDeckThenDrawByPrizes,
    BothPlayersHandToBottomThenDrawAsymmetric,
    BothPlayersShuffleHandAndDrawFixed,
    ClearActiveStatusConditions,
    ClearOwnStatusConditions,
    DamageCounterOnChosenOpponentPokemon,
    DamageCounterOnDefender,
    DamageCounterOnOwnActive,
    DamageCounterOnChosenOpponentThenSelfKnockout,
    DamagePerNamePrefixBoardEnergyCount,
    DamagePerNamePrefixMilledFromTopOfOwnDeck,
    DamageCounterOnChosenOwnPokemon,
    DamageIfDefenderHasEnergy,
    DamageIfDefenderHasSubtype,
    DamageIfDefenderIsSP,
    DamageIfDefenderPoisoned,
    DamageToChosenOwnPokemonIgnoringWeaknessResistance,
    DealBonusDamageToChosenOpponentBench,
    DealDamageFlipUntilTailsBonus,
    DealDamageWithCoinFlipBonus,
    DevolveAllOpponentEvolvedPokemon,
    DiscardAnyHandCardsOptional,
    DiscardSelfSearchBasicToActiveInPlace,
    DiscardOpponentActiveSpecialEnergyOnly,
    SearchDeckForCardNameAttachToTarget,
    SearchDeckByCriterionToHand,
    SearchDiscardForSubtypeToHand,
    SearchDiscardForTrainerToHand,
    HealFullyAndDiscardAllEnergy,
    DamageIfExtraEnergyAttached,
    DamageIfOwnEnergyTypeCountInPlayAtLeast,
    DamageIfOwnPokemonKnockedOutLastOpponentTurn,
    DamageIfOwnPrizesRemainingExactly,
    DamageBonusIfStadiumDiscarded,
    DamageBonusWithOptionalEnergyDiscard,
    DamageIfStadiumInPlay,
    DamagePerBottomNCardsWithAttackName,
    DamagePerAncientCardInDiscard,
    DamagePerOwnDiscardBasicEnergyCountThenShuffleIntoDeck,
    DamagePerOwnDiscardEnergyOfTypeCount,
    DamagePerOpponentHandCardCount,
    DamagePerOwnPokemonWithNamePrefix,
    DamagePerBenchedPokemonWithEnergyType,
    DamagePerBothActiveEnergyCount,
    DamagePerDefenderDamageCounters,
    DamagePerDefenderEnergyCount,
    DamagePerFusionStrikeEnergyAcrossBoard,
    DamagePerOwnFieldBasicEnergyTypeCountAcrossBoard,
    DamagePerOpponentPrizesTaken,
    DamagePerOwnBenchedPokemonOfType,
    DamagePerOwnPokemonInPlay,
    DamagePerOwnPokemonWithSubtype,
    DamagePerSelfDamageCounters,
    DamagePerSelfDamageCountersToChosenOpponent,
    DamagePerSelfEnergyOfType,
    DamagePerSelfEnergyToChosenOpponent,
    DamagePerTotalBenchedPokemon,
    DealDamage,
    DealDamageIgnoringAllDefenderEffects,
    DealDamageIgnoringWeaknessOnly,
    DealDamageIgnoringWeaknessResistance,
    DealDamageWithSelfDebuffNextTurn,
    DamageAndStatusIfBecameActiveThisTurn,
    DamageIfBecameActiveThisTurn,
    DealDamagePerHeads,
    DealDamageToChosenOpponentPokemon,
    DealDamageToChosenOpponentPokemonMulti,
    DamageIfDefenderHasTool,
    DamagePerToolInPlayBothSides,
    DiscardAllOpponentActiveEnergy,
    DiscardAllOwnEnergy,
    DiscardAllOwnEnergyThenBonusDamage,
    DiscardCardsFromHand,
    DiscardOwnHandBasicEnergyThenDraw,
    DiscardHandCostThenRetrieveEnergyExcludingDiscarded,
    DiscardOpponentActiveEnergy,
    DiscardEnergyFromHand,
    DiscardEnergyFromHandForScalingDamage,
    DiscardHandThenDraw,
    DiscardOwnBasicEnergyThenScalingDamage,
    DiscardChosenOpponentToolAndSpecialEnergy,
    DiscardOwnEnergy,
    DiscardOwnTeamRocketEnergyThenKnockOutDefender,
    DiscardRandomFromOpponentHand,
    DiscardAllEnergyFromBothActivePokemon,
    ChooseOpponentDiscardCardsToLostZone,
    DiscardOwnEnergyForScalingDamage,
    BothPlayersSwitchActiveEachChoosesOwn,
    DamageBonusAndIgnoreEffectsIfExtraEnergy,
    DiscardHandEnergyThenSwitchOpponentBench,
    DiscardOwnSpecificEnergyThenDealDamage,
    BlockOpponentActiveAbilitiesThisTurn,
    DiscardStadiumInPlayIfChosen,
    SwitchOutOpponentActiveOpponentChoosesThenDiscardSelf,
    SwitchActiveWithBenchThenMayDiscardToHealOld,
    RevealUntilSupporterToHand,
    PeekOwnPrizes,
    TurnPrizesFaceUp,
    LookTopNReorderOnTop,
    MoveDamageCountersBetweenOpponentPokemon,
    MoveOpponentDiscardCardToTheirPrizes,
    DiscardSelfFromBench,
    DiscardStadiumInPlay,
    DiscardOpponentActiveSpecialEnergy,
    DiscardTopNAttachEnergyFound,
    DiscardTopNRecoverItemsFound,
    DisableDefenderAttackNextTurn,
    DisableDefenderRetreatNextTurn,
    DistributeDamageCountersFreely,
    MoveChosenBenchEnergyToActive,
    SwitchOwnActiveWithBenchThenForceOpponentSwitch,
    SwitchActiveWithBenchOrExVDamageBonusThisTurn,
    DealDamagePerOpponentPokemonWithSubtype,
    SetSelfRetaliateOnDamagedNextTurn,
    OpponentDiscardHandDownTo,
    DrawPerOpponentBenchCount,
    DealDamageBonusIfStadiumInPlayThenDiscardIt,
    DamagePerOwnNamedPokemonWithDamageCounters,
    BonusDamageIfOwnBenchHasSubtypeOfType,
    DiscardOpponentDeckPerHeadsUntilTails,
    DealDamageIfHandCountExactly,
    DamagePerToolAttachedBothSides,
    DamagePerEnergyCardInOpponentHand,
    DealDamageIfOpponentPrizesInRange,
    BonusDamageIfSelfHasToolAttached,
    BonusDamageIfTwoNamedPokemonOnBench,
    BonusDamageIfTeamRocketSupporterPlayedThisTurn,
    DamagePerOwnTeamRocketsPokemonInPlay,
    BonusDamagePerBenchCountBothSides,
    DealDamageIfDefenderBurned,
    DamagePerOpponentDiscardBasicEnergyCount,
    DamagePerOwnToolAttachedCount,
    BonusDamageIfOwnDiscardEnergyCountAtLeast,
    HealSelfEqualToDamageDealt,
    DealDamageIfDefenderAlreadyDamaged,
    DiscardDefenderEnergyPerHeads,
    DiscardDefenderToolThenParalyzeIfDiscarded,
    DiscardOpponentActiveEnergyOfType,
    BonusDamageIfSelfHasEnergyType,
    DealFixedDamageToAllOpponentBenchedPokemon,
    DealFixedDamageToAllOpponentBenchedPokemonScaledByPrizesTaken,
    DealFixedDamageToAllOwnBenchedPokemon,
    DoubleAllOpponentDamageCounters,
    EachPlayerDraws,
    FlipMultipleCoinsForBonusDamageThenStatusIfAnyHeads,
    DamageCounterOnChosenOpponentBenchIfActiveHasSpecialCondition,
    BonusDamageIfDefenderHasResistanceType,
    DamagePerTypeBenchedDamageCounters,
    FlipCoinPerOwnPokemonOfTypeForDamage,
    DamagePerOpponentBenchedPokemonCount,
    BonusDamageIfHandCountEqualsOpponent,
    ForceOpponentShuffleHandThenDraw,
    BonusDamageIfNamedPokemonOnBench,
    FlipCoinsThenRetrieveFromDiscardToHand,
    DealDamageIfOwnBenchCountAtMost,
    DamagePerOpponentHandTrainerCount,
    DealDamageIfDefenderHasSubtypeIgnoringWeaknessResistance,
    BonusDamageIfSameEnergyCountAsDefender,
    DamagePerDefenderSpecialConditionCount,
    DamagePerPokemonBothSidesNamedContains,
    BonusDamageIfSelfNotDamaged,
    DealDamageIfCanDiscardEnergyFromHand,
    LockSelfRetreatNextTurn,
    SelfDamageUnlessAllCoinsTails,
    BonusDamageIfDefenderIsEvolutionPokemon,
    DiscardDefenderTool,
    HealOwnActiveBonusIfNamedPrefix,
    DrawBonusIfOpponentPrizesAtMost,
    DamageCountersOnAllOpponentPokemonIfOwnHideNSneakDiscardThreshold,
    DealDamageBonusIfOwnHideNSneakDiscardThreshold,
    DiscardChosenNonRuleBoxPokemonThenDrawPerCount,
    DistributeDamageCountersFreelyConditional,
    DiscardTopOfOpponentDeck,
    DiscardTopOfOwnDeck,
    DiscardTopOfOwnDeckThenUseItsAttack,
    Draw,
    DrawBonusIfActive,
    DrawThenShuffleSelfIntoDeckIfDrew,
    DrawUpToBonusIfAllOwnPokemonNamePrefix,
    DrawUpTo,
    EndTurnAfterThisAbility,
    DrawUpToFusionStrikeCount,
    Effect,
    FlipCoinThen,
    FlipCoinThenDiscardOpponentEnergy,
    FlipCoinThenChooseOwnPokemonReturnToHand,
    FlipCoinThenReturnSelfToHand,
    ForceOpponentSwitchChosenBench,
    ForceOpponentSwitchOpponentChooses,
    ForceOpponentSwitchChosenBenchThenSwitchOwnActive,
    HealAllOwnPokemon,
    HealAllOwnSPPokemon,
    HealOwnActiveIfEnergyCountAtLeast,
    HealSelf,
    HealSelfPerAttachedEnergyId,
    FlipCoinPerOpponentBenchCountForDamageToActive,
    HealTarget,
    HealTargetThenDiscardEnergyIfHealed,
    HealTargetThenDiscardAllEnergy,
    HealTargetThenReturnAttachedEnergyToHandIfHealed,
    IfDefenderIsEvolved,
    IfDamageDealt,
    IfExtraEnergyAttached,
    IfLastAttachSucceeded,
    IfLastDiscardSucceeded,
    IfOwnPokemonKnockedOutLastOpponentTurn,
    InflictHardToWakeSleepOnSelf,
    InflictHeavyPoison,
    InflictStatusOnDefender,
    InflictStatusOnSelf,
    KnockOutBothActivePokemon,
    KnockOutDefenderIfCanDiscardEnergyFromHand,
    KnockOutDefenderIfBasic,
    KnockOutOpponentActive,
    KnockOutOpponentActiveThenSelfDamage,
    LockChosenOpponentAttackNextTurn,
    LockOpponentAttackNextTurn,
    LockOpponentGXAttacksForRestOfGame,
    LockOpponentItemsNextTurn,
    LockOwnAttackNextTurn,
    LookTopNAttachEnergyRestToHand,
    LookTopNChooseEnergyToAttachRestToHand,
    LookTopNChooseByCriteriaToHand,
    LookTopCardMayDiscard,
    LookTopNKeepMRestToDiscard,
    LookTopNKeepMRestToLostZone,
    MoveBasicPokemonFromOpponentDiscardToTheirBench,
    MoveDamageCountersFromAllOwnPokemonToChosenOpponent,
    MoveDamageCountersFromSelfToOpponentActive,
    MoveDefenderEnergyToOpponentHand,
    MoveEnergyBetweenOwnPokemon,
    MoveEnergyOnOpponentSide,
    NotImplementedEffect,
    OpponentShuffleHandDrawByPrizes,
    OpponentShuffleHandThenDrawFixed,
    OpponentHandToBottomOfDeckThenDraw,
    RandomPrizeDiscardAttachIfEnergyToSelf,
    ResetBothPlayersPrizes,
    ReturnHandPokemonToDeck,
    ReturnSelfToHand,
    ReturnOwnBenchedPokemonAndAttachedToHand,
    ReturnOwnBenchedPokemonToHand,
    ReturnOwnBenchedPokemonToHandDiscardAttached,
    ReturnChosenOpponentEnergyToHand,
    ReturnOwnEnergyToHand,
    RevealTopNChooseOneToHandOtherToBottom,
    SearchDeckAndAttachEnergy,
    SearchDeckAnyCardToHand,
    SearchDeckToTopOfDeck,
    SearchDeckUpToTwoBasicOrOneEvolutionToHand,
    SearchDeckForDistinctBasicEnergyTypesToHand,
    SearchDeckAnyEnergyAttachToSelf,
    SearchDeckBasicPokemonAndEnergy,
    SearchDeckForBasicEnergyAttachToTarget,
    SearchDeckForBasicEnergyAttachFreely,
    SearchDeckForBasicEnergyAttachFreelyWithSecondTurnBonus,
    AttachDiscardEnergyFreelyToOwnPokemon,
    SearchDeckForBasicEnergyToHand,
    SearchDeckForBasicPokemonToBench,
    SearchDeckForBasicExOrThreeBasicToBench,
    SearchDeckForFusionStrikeEnergyAttachToTarget,
    SearchDeckForNamedPokemonToBench,
    SearchDeckForPokemonToHand,
    PutHandCardOnTopOfDeck,
    SearchDeckMultiCriteria,
    SearchDiscardAnyCardToHand,
    SearchDiscardForBasicEnergyToHand,
    SearchDiscardForNamedPokemonToBench,
    SearchDiscardForPokemonOrEnergy,
    SearchDiscardForPokemonToHand,
    SearchDiscardForSPAndEnergy,
    SearchDiscardForSupporterOrStadiumToHand,
    SearchDiscardForSupporterToHand,
    SelfDamage,
    SwapSelfFromPrizesForBasicPokemon,
    ShuffleFromDiscardIntoDeck,
    ShuffleHandDrawPerTotalBenchedPokemon,
    ReshuffleTakenPrizesAndRedraw,
    ShuffleHandIntoDeckThenDraw,
    ShuffleHandThenDrawEqualToOpponentHandSize,
    ShuffleRandomFromOpponentHandIntoDeck,
    ShuffleHandThenDrawWithPrizeBonus,
    ShuffleSelfIntoDeck,
    ShuffleSupportersFromDiscardIntoDeck,
    SwapHandPokemonForDeckSearch,
    SwitchActiveWithBench,
    SwitchSelfToActiveThenMoveChosenOwnEnergy,
    SwitchActiveWithBenchThenHealBenched,
    SwitchActiveWithBenchThenPoisonSelf,
    SwitchOwnActiveWithFirstBench,
    TakeOwnPrizeCard,
    TimeWalkSwapPrizeForPokemon,
    TopDeckThenSearchPokemon,
    DamagePerOwnAttachedEnergyCount,
    DamagePerOpponentActiveEnergyCount,
    DamagePerAllPokemonEnergyCountAcrossBoard,
    DamagePerOpponentAllPokemonEnergyCount,
    DealDamageIgnoringResistance,
    DealDamageIgnoringDefenderShieldAndReduction,
    DealDamageToAllOpponentGxExPokemon,
    DiscardOwnEnergyTypeThenBonusDamage,
    SwitchSelfFromBenchToActive,
    LookTopNAttachBasicEnergyToChosenBench,
    MayDiscardHandCardThenDraw,
    SearchDiscardForEnergyAttachToSelfCountEqualOpponentPokemon,
    DamagePerOpponentBenchedPokemon,
    DamagePerOwnPrizesRemaining,
    DamageIfOpponentPrizesRemainingExactly,
    FlipMultipleCoinsForBonusDamage,
    AttachEnergyFromDiscardToSelf,
    DamagePerOwnBoardEnergyOfTypes,
    MoveOpponentHandCardToTheirPrizes,
    DamageIfSupporterPlayedThisTurn,
    HealAllOwnPokemonOfType,
    ChooseDiscardCardsToBottomOfDeck,
    ShuffleDiscardIntoDeck,
    ReturnDamagedOwnPokemonToHand,
    BlockAllAbilitiesUntilOpponentTurnEnds,
    EvolveOwnBasicDirectlyFromHand,
    InstantEvolveAnyOwnPokemonFromDeck,
    InstantEvolveAnyOwnPokemonFromDeckThenChainEvolve,
    DamagePerOpponentDiscardItemCount,
    DamagePerOpponentDiscardSpecialEnergyCount,
    DamagePerOwnDiscardPokemonWithAttackName,
    DealDamageToAllOpponentPokemon,
    DamageIfOwnBenchedPokemonDamaged,
    MoveEnergyFromChosenBenchToActive,
    DamageWithSupporterBonusToChosenOpponentBench,
    DamagePerOwnBenchedPokemonCount,
    DamagePerOwnBenchedSubtypeCount,
    ReturnSelfToHandUnconditional,
    ReturnOwnPokemonToHandDiscardingAttached,
    HealTargetAndClearStatus,
    DiscardAllOpponentTools,
    DamagePerOpponentActualPrizesTaken,
    DamageWithOptionalEnergyReturnBonus,
    BlockOpponentAbilitiesUntilTurnEnds,
    GrantFusionStrikeDamageBonusThisTurn,
    ClearAllStatusConditionsBothSides,
    RemoveAllAttackEffectsBothSides,
    SwapOwnPokemonIdentityWithDeckBasic,
    DamagePerOwnDiscardPokemonCount,
    DamagePerHeadsAmongEnergyCount,
    SearchDiscardForPokemonOfTypeToHand,
    ShuffleSpecialEnergyFromDiscardIntoDeck,
    SearchDiscardForPokemonOfTypeToBench,
    SearchDiscardForBasicPokemonToBench,
    SearchDiscardForItemToHand,
    SearchDeckForSubtypePokemonToHand,
    SearchDeckForSameNamePokemonToHand,
    DamageIfDefenderHasSubtypeIgnoringWeaknessResistance,
    ChooseOwnAncientPokemonThenAttachDiscardEnergy,
    ChooseOwnBenchThenHealFully,
    ChooseOwnBenchThenInstantEvolveFromDeck,
    ChooseOwnBenchThenSearchEnergyAttach,
    ChooseOwnPokemonThenSearchEnergyAttach,
    ChooseOneDiscardPokemonToHandOrThreeIntoDeck,
    RemoveOneActiveStatusCondition,
    ChooseOwnPokemonThenSearchSpecificEnergyAttach,
    ChooseOwnPokemonThenMoveOneBasicEnergyToAnother,
    ChooseOwnPokemonThenSearchDistinctBasicEnergyAttach,
    ChooseHandCardToLostZone,
    ChooseSourceThenMoveEnergyFreely,
    DamageIfOtherAncientPokemonAttackedLastOwnTurn,
    DiscardChosenFieldToolOrSpecialEnergy,
    DiscardChosenFieldToolsOrStadium,
    DiscardChosenOpponentSpecialEnergy,
    DiscardHandCostThenDiscardChosenOpponentEnergy,
    LookTopCardThenHandOrDiscardDraw,
    MoveChosenOwnEnergyToSelfThenSwitchActive,
    MoveChosenOwnFireEnergyToSelf,
    SearchDeckBasicEnergyToHandThenChooseDistinctAttach,
    MoveSelfAndAttachedToBottomOfDeck,
    SetDestinyBondShield,
    DamageBonusIfOwnEnergyIdAttached,
    DamageIfEvolvedFromNamedThisTurn,
    DamageIfEvolvedThisTurn,
    DamagePerDefenderEnergyCountIfSelfHasEnergyId,
    DiscardOpponentActiveEnergyIfSelfHasEnergyId,
    RandomOpponentHandCardToDeck,
    ChooseOwnAttachedEnergyThenShuffleForBonusBenchDamage,
    PreventPrizesIfKnockedOutNextTurn,
    InstantEvolveSelfFromDeck,
    SearchDeckAnyCardToDiscard,
    DiscardStadiumThenOpponentDiscardChosen,
    DiscardOwnEnergyOfTypeThenDistributeDamageFreely,
    ExDamageBonus40ThisTurn,
    ReturnOwnToolToHand,
    BonusDamageIfSelfDamaged,
    BonusDamageIfOpponentPrizesAtMost,
    BonusDamageIfSelfBurnedOrPoisoned,
    DamageIfSelfSameAttackUsedLastOwnTurn,
    DamagePerHeadsForEachAttachedEnergy,
    DamagePerEnergyOnAllOpponentPokemon,
    DamagePerEnergyOnOpponentActive,
    BonusDamageIfDefenderAlreadyDamaged,
    SearchDeckForNonRuleBoxPokemonToHand,
    SearchDeckForNamePrefixBasicPokemonToBench,
    SearchDeckForNamePrefixPokemonToHand,
    DamagePerOwnFieldNamePrefixCount,
    DamagePerHeadsUntilTails,
    BonusDamageIfDefenderHasSubtype,
    ShuffleSelfEnergyIntoDeck,
    SearchDiscardForFightingPokemonOrEnergyToHand,
    DamagePerOwnPrizesTaken,
    DealDamageIgnoringResistanceOnly,
    BonusDamageIfOwnBenchDamaged,
    DamageCounterFixedOnOpponentActive,
    ReturnOwnAttachedEnergyToHand,
    DamageToAllOwnBenchedPokemon,
    RandomOpponentHandDiscardDownTo,
    BonusDamageIfCardInOwnDiscard,
    DiscardOpponentActiveTool,
    DamagePerHandCardMatchingNames,
    DamagePerNamedBenchedDamageCounters,
    HealOwnActiveFixed,
    BonusDamageIfStadiumInPlay,
    SwitchActiveWithBenchThenHealBenchedIfEx,
    DealDamagePerOwnBenchedDamagedPokemon,
    DiscardToolsAndSpecialEnergyFromAllOpponentPokemon,
    HealAllPokemonBothSides,
    RevealOpponentHandThenDrawPerPokemonFound,
    BonusDamageIfSelfUndamaged,
    DealDamageLessPerSelfDamageCounters,
    DamagePerAllOpponentPokemonDamageCounters,
    BonusDamageIfDefenderHasNoRetreatCost,
    BonusDamageIfSelfHasAnySpecialEnergyAttached,
    DamageWithBonusBenchIfExtraEnergy,
    DamagePerOwnAttachedEnergyOfTypeAcrossBoard,
    DamagePerOwnEvolvedPokemonInPlay,
    DamagePerOwnPokemonWithNamedAttackInPlay,
    DealDamageThenDevolveOpponentActiveIfEvolved,
    DevolveOpponentActiveIfEvolved,
    DamagePerColorlessInOpponentActiveRetreatCost,
    BonusDamageIfAnyOwnBenchedDamaged,
    DrawPerOpponentPokemonWithSubtypes,
    ConfuseBothActiveNonDarknessPokemon,
    DamageOnlyIfDefenderConfused,
    ShuffleOwnHandIntoDeckThenDraw,
    DamageIgnoringWeaknessBonusIfSelfDamaged,
    BonusDamageIfDefenderType,
    DamagePerTotalBenchedPokemonBothSides,
    DamageReducedPerDefenderEnergyCount,
    DealFixedDamageToAllBenchedPokemonBothSides,
    BonusDamageIfOwnBoardEnergyTypeCountAtLeast,
    AllCoinsHeadsThen,
    BonusDamageIfDefenderBurned,
    DamageReducedIfDefenderAlreadyDamaged,
    BonusDamageIfOwnPrizesRemainingExactly,
    BonusDamageIfDefenderHasSpecialCondition,
    BonusDamageIfOpponentHandCountAtMost,
    BonusDamageIfOpponentPrizesExactly,
    BonusDamageIfOwnHandEmpty,
    BonusDamageIfDefenderIsEvolved,
    DamageReducedByDefenderRetreatCostColorless,
    OpponentDiscardExactlyFromHand,
    OpponentPoisonedCantRetreatNextTurn,
    DamageToChosenOpponentPokemonScaledByOwnPokemonNamedCoinFlips,
    WinGameIfExactlyOnePrizeRemaining,
)

ATTACK_EFFECTS: dict[str, dict[str, tuple[Effect, ...]]] = {
    # ---- WCS2016 6位/7位 ナイトマーチ系(Brad Curcio/Luca Schuster選手) ----
    "xy10-29": {  # ミュウ(Mew、Fates Collide版)
        # 特性「Memories of Dawn」(自分の場のたねポケモンのワザを使える)は
        # engine.legal_actions._memories_of_dawn_attack_actions経由で対応済み。
        "Encounter": (SearchDeckForPokemonToHand(count=1),),
    },
    # ---- WCS2016 8位 ドータクンボックス(Gustavo Wada選手) ----
    "xy4-60": {  # ドーミラー(Bronzor、Phantom Forces版)
        "Tackle": (DealDamage(10),),
    },
    "xy4-61": {  # ドータクン(Bronzong、Phantom Forces版)
        "Hammer In": (DealDamage(60),),
    },
    "xy10-62": {  # ドータクンBREAK(Bronzong BREAK)
        # BREAK進化ルールによりドータクン(xy4-61)のワザ・特性をそのまま引き継ぐ。
        "Hammer In": (DealDamage(60),),
        "Metal Rain": (DiscardOwnEnergyOfTypeThenDistributeDamageFreely(energy_type="Metal", damage_per=30),),
    },
    "xy10-64": {  # ゲノセクトEX(Genesect-EX、Fates Collide版)
        # 実カードテキスト: "Discard as many Metal Energy attached to this Pokémon as you like. This attack does 20
        # more damage for each Energy card discarded in this way."(鋼エネルギー限定・好きな枚数。以前は種類を
        # 問わず全てトラッシュしていた)
        "Rapid Blaster": (DiscardOwnBasicEnergyThenScalingDamage(damage_per=20, base=100, energy_type="Metal", source_only=True),),
    },
    "base1-44": {  # Bulbasaur
        "Leech Seed": (DealDamage(20), IfDamageDealt((HealSelf(10),))),
    },
    "base1-30": {  # Ivysaur
        "Vine Whip": (DealDamage(30),),
        "Poisonpowder": (DealDamage(20), InflictStatusOnDefender("poisoned")),
    },
    "base1-15": {  # Venusaur
        "Solarbeam": (DealDamage(60),),
    },
    "base1-46": {  # Charmander
        "Scratch": (DealDamage(10),),
        "Ember": (DiscardOwnEnergy(1, "Fire"), DealDamage(30)),
    },
    "base1-24": {  # Charmeleon
        "Slash": (DealDamage(30),),
        "Flamethrower": (DiscardOwnEnergy(1, "Fire"), DealDamage(50)),
    },
    "base1-4": {  # Charizard
        "Fire Spin": (DiscardOwnEnergy(2), DealDamage(100)),
    },
    "base1-35": {  # Magikarp
        "Tackle": (DealDamage(10),),
        "Flail": (DamagePerSelfDamageCounters(10),),
    },
    "base1-6": {  # Gyarados
        "Dragon Rage": (DealDamage(50),),
        "Bubblebeam": (FlipCoinThen(heads=(InflictStatusOnDefender("paralyzed"),)), DealDamage(40)),
    },
    "base1-16": {  # Zapdos
        "Thunder": (DealDamage(60), FlipCoinThen(tails=(SelfDamage(30),))),
        "Thunderbolt": (DiscardAllOwnEnergy(), DealDamage(100)),
    },
    "base1-20": {  # Electabuzz
        "Thundershock": (DealDamage(10), FlipCoinThen(heads=(InflictStatusOnDefender("paralyzed"),))),
        "Thunderpunch": (FlipCoinThen(heads=(DealDamage(40),), tails=(DealDamage(30), SelfDamage(10))),),
    },
    "base1-31": {  # Jynx
        "Doubleslap": (DealDamagePerHeads(2, 10),),
        "Meditate": (DamagePerDefenderDamageCounters(20, 10),),
    },
    "base1-50": {  # Gastly
        "Sleeping Gas": (FlipCoinThen(heads=(InflictStatusOnDefender("asleep"),)),),
        "Destiny Bond": (
            DiscardOwnEnergy(1, "Psychic"),
            SetDestinyBondShield(),
        ),
    },
    "bw4-5": {  # Shaymin-EX
        "Synthesis": (SearchDeckAndAttachEnergy("Grass", 1, self_only=False),),
        "Revenge Blast": (DamagePerOpponentPrizesTaken(30, 30),),
    },
    # ---- WCS2010(がブレンミラー) ----
    "pl2-9": {  # Luxray GL
        "Bite": (DealDamage(30),),
        "Trash Bolt": (DiscardEnergyFromHand(1), IfLastDiscardSucceeded((DealDamage(70),))),
    },
    "pl2-109": {  # Luxray GL LV.X
        "Flash Impact": (DealDamage(60), DamageToChosenOwnPokemonIgnoringWeaknessResistance(30)),
    },
    "pl3-60": {  # Garchomp C
        "Claw Swipe": (DealDamage(30),),
        "Earthquake": (DealDamage(50), BenchDamageAll(10, side="own")),
    },
    "pl3-145": {  # Garchomp C LV.X
        "Dragon Rush": (
            DiscardOwnEnergy(2),
            DealDamageToChosenOpponentPokemon(80),
            LockOwnAttackNextTurn("Dragon Rush"),
        ),
    },
    "dpp-DP41": {  # Toxicroak G(プロモ版、がブレンミラーで実際に使われた印刷)
        "Poison Revenge": (
            DamageIfOwnPokemonKnockedOutLastOpponentTurn(20, 40),
            IfOwnPokemonKnockedOutLastOpponentTurn((InflictStatusOnDefender("poisoned"),)),
        ),
    },
    "pl1-47": {  # Crobat G
        "Toxic Fang": (InflictHeavyPoison(),),
    },
    "pl3-56": {  # Dragonite FB
        "Mach Blow": (DamageIfDefenderIsSP(80, 20),),
        "Giant Tail": (FlipCoinThen(heads=(DealDamage(100),)),),
    },
    "pl1-41": {  # Bronzong G
        "Psychic Pulse": (DealDamage(40), BenchDamageAll(10, side="opponent", only_if_damaged=True)),
    },
    "pl2-56": {  # Ambipom G
        "Tail Code": (MoveEnergyOnOpponentSide(),),
        "Snap Attack": (DamageIfDefenderHasEnergy(20, 60),),
    },
    "dp6-43": {  # Uxie
        "Psychic Restore": (DealDamage(20),),  # 「してもよい」の山札の下に戻る効果はAFTER_ATTACK_TRIGGER_EFFECTS経由で対応済み
    },
    "dp6-146": {  # Uxie LV.X
        "Zen Blade": (DealDamage(60), LockOwnAttackNextTurn("Zen Blade")),
    },
    "dp6-19": {  # Azelf(がブレンミラーで実際に使われた印刷、ポケパワー「タイムウォーク」)
        "Lock Up": (DealDamage(20), DisableDefenderRetreatNextTurn()),
    },
    "dp5-49": {  # Unown Q
        "Hidden Power": (DealDamage(20),),
    },
    # ---- 現行スタンダード(Mega Evolutionブロック) ----
    "me5-9": {  # Sizzlipede
        "Controlled Burn": (DiscardTopOfOpponentDeck(1),),
        "Bug Out": (DamagePerBottomNCardsWithAttackName(7, "Bug Out", 50),),
    },
    "me5-10": {  # Centiskorch
        "Controlled Burn": (DiscardTopOfOpponentDeck(2),),
        "Heat Tackle": (DealDamage(160), SelfDamage(30)),
    },
    "me5-11": {  # Charcadet
        "Best Punch": (FlipCoinThen(heads=(DealDamage(40),)),),
    },
    "me5-12": {  # Armarouge
        "Flame Legion": (DamagePerBenchedPokemonWithEnergyType(40, 40, "Fire"),),
    },
    "me5-23": {  # Electrike
        "Collect": (Draw(1),),
        "Tackle": (DealDamage(30),),
    },
    "me5-24": {  # Manectric
        "Flashing Barrier": (DealDamage(50), ApplyScopedDamageImmunityToSelf("evolution")),
        "Sonic Edge": (DealDamage(110),),
    },
    # ---- ガーデヴォール/ジェリセント(2026年1月トロント地区大会) ----
    "sv6-95": {  # Munkidori
        "Mind Bend": (DealDamage(60), InflictStatusOnDefender("confused")),
    },
    "rsv10pt5-44": {  # Frillish
        "Oceanic Gloom": (DealDamage(20), LockOpponentItemsNextTurn()),
    },
    "rsv10pt5-45": {  # Jellicent ex
        "Power Press": (DamageIfExtraEnergyAttached(base=80, bonus=80, extra_needed=2, cost_count=2),),
    },
    "me1-58": {  # Ralts
        "Collect": (Draw(1),),
        "Headbutt": (DealDamage(10),),
    },
    "me1-59": {  # Kirlia
        "Call Sign": (SearchDeckForPokemonToHand(3),),
        "Psyshot": (DealDamage(30),),
    },
    "sv1-86": {  # Gardevoir ex
        "Miracle Force": (DealDamage(190), ClearOwnStatusConditions()),
    },
    "sv8-76": {  # Latias ex
        "Eon Blade": (DealDamage(200), LockOwnAttackNextTurn("Eon Blade", lock_all_attacks=True)),
    },
    # sv3pt5-151(Mew ex)の「Genome Hacking」は通常のATTACK_EFFECTSではなく、
    # legal_actions._attack_copy_actions(UseBorrowedAttackアクション)経由で対応済み。
    "sv9-56": {  # Lillie's Clefairy ex
        "Full Moon Rondo": (DamagePerTotalBenchedPokemon(20, 20),),
    },
    "sv6pt5-38": {  # Fezandipiti ex
        "Cruel Arrow": (DealDamageToChosenOpponentPokemon(100),),
    },
    "me2-41": {  # Mega Diancie ex
        "Garland Ray": (DiscardOwnEnergyForScalingDamage(max_count=2, damage_per=120),),
    },
    "sv4-86": {  # Scream Tail
        "Slap": (DealDamage(30),),
        "Roaring Scream": (DamagePerSelfDamageCountersToChosenOpponent(20),),
    },
    # ---- WCS2025 1位 ガーデヴォール(Riley McKay選手) ----
    "sv1-84": {  # Ralts(SVI版)
        "Psyshot": (DealDamage(30),),
    },
    "sv1-85": {  # Kirlia(SVI版)
        "Magical Shot": (DealDamage(30),),
        "Psychic": (DamagePerDefenderEnergyCount(60, 20),),
    },
    "sv5-78": {  # Flutter Mane
        "Hex Hurl": (DealDamage(90), DistributeDamageCountersFreely(2, bench_only=True)),
    },
    # ---- WCS2025 2位 ドラパルト/デスバーン(Justin Newdorf選手) ----
    "sv6-128": {  # Dreepy
        "Petty Grudge": (DealDamage(10),),
        "Bite": (DealDamage(40),),
    },
    "sv6-129": {  # Drakloak
        "Dragon Headbutt": (DealDamage(70),),
    },
    "sv6-130": {  # Dragapult ex
        "Jet Headbutt": (DealDamage(70),),
        "Phantom Dive": (DealDamage(200), DistributeDamageCountersFreely(6, bench_only=True)),
    },
    "sv8pt5-35": {  # Duskull
        "Come and Get You": (SearchDiscardForNamedPokemonToBench("Duskull", 3),),
        "Mumble": (DealDamage(30),),
    },
    "sv8pt5-36": {  # Dusclops
        "Will-O-Wisp": (DealDamage(50),),
    },
    "sv8pt5-37": {  # Dusknoir
        "Shadow Bind": (DealDamage(150), DisableDefenderRetreatNextTurn()),
    },
    "sv8pt5-4": {  # Budew
        "Itchy Pollen": (DealDamage(10), LockOpponentItemsNextTurn()),
    },
    "sv1-118": {  # Hawlucha
        "Wing Attack": (DealDamage(70),),
    },
    "sv6-141": {  # Bloodmoon Ursaluna ex
        "Blood Moon": (DealDamage(240), LockOwnAttackNextTurn("Blood Moon", lock_all_attacks=True)),
    },
    # ---- WCS2025 3位 らいげきしぶ/オーガポン(Shizuki Nakagawa選手) ----
    "sv7-114": {  # Hoothoot
        "Triple Stab": (DealDamagePerHeads(3, 10),),
    },
    "sv7-115": {  # Noctowl
        "Speed Wing": (DealDamage(60),),
    },
    "sv5-123": {  # Raging Bolt ex
        "Burst Roar": (DiscardHandThenDraw(6),),
        "Bellowing Thunder": (DiscardOwnBasicEnergyThenScalingDamage(damage_per=70),),
    },
    "sv6-25": {  # Teal Mask Ogerpon ex
        "Myriad Leaf Shower": (DamagePerBothActiveEnergyCount(30, 30),),
    },
    "sv7-118": {  # Fan Rotom
        "Assault Landing": (DamageIfStadiumInPlay(70),),
    },
    "sv7-111": {  # Raging Bolt(無印)
        "Thunderburst Storm": (DamagePerSelfEnergyToChosenOpponent(30),),
        "Dragon Headbutt": (DealDamage(130),),
    },
    "sv8-116": {  # Koraidon
        "Unrelenting Onslaught": (DamageIfOtherAncientPokemonAttackedLastOwnTurn(30, 150),),
        "Hammer In": (DealDamage(110),),
    },
    "sv3pt5-132": {  # Ditto
        "Splup": (DealDamage(10),),
    },
    "sv8-56": {  # Chien-Pao
        "Icicle Loop": (DealDamage(120), ReturnOwnEnergyToHand(1)),
    },
    "sv2-169": {  # Squawkabilly ex
        "Motivate": (DealDamage(20), AttachEnergyFromDiscardToOwnPokemon(energy_type=None, count=2, bench_only=True)),
    },
    # ---- WCS2025 4位 リザードンex/ポッポサンダー(Junya Tanaka選手) ----
    "sv4pt5-7": {  # Charmander
        "Blazing Destruction": (DiscardStadiumInPlay(),),
        "Steady Firebreathing": (DealDamage(30),),
    },
    "sv3pt5-5": {  # Charmeleon
        "Combustion": (DealDamage(20),),
        "Fire Blast": (DiscardOwnEnergy(1), DealDamage(90)),
    },
    "sv3-125": {  # Charizard ex
        "Burning Darkness": (DamagePerOpponentPrizesTaken(180, 30),),
    },
    "sv3-162": {  # Pidgey
        "Gust": (DealDamage(20),),
    },
    "sv3pt5-17": {  # Pidgeotto
        "Flap": (DealDamage(20),),
    },
    "sv3-164": {  # Pidgeot ex
        "Blustery Wind": (DealDamage(120), DiscardStadiumInPlayIfChosen()),  # "You may discard a Stadium in play."
    },
    "sv3-80": {  # Cleffa
        "Grasping Draw": (DrawUpTo(7),),
    },
    "sv4-29": {  # Chi-Yu
        "Flare Bringer": (AttachEnergyFromDiscardToOwnPokemon(energy_type="Fire", count=2),),
        "Megafire of Envy": (DamageIfOwnPokemonKnockedOutLastOpponentTurn(50, 90),),
    },
    # ---- WCS2025 5位 リザードンex/ポッポサンダー(Öjvind Svinhufvud選手) ----
    # (デッキ本体はTanaka選手(4位)とほぼ共通のため、新規カードのみここに追加)
    # ---- WCS2025 6位 Nのゾロアーク(Mateusz Łaszkiewicz選手) ----
    "sv9-97": {  # N's Zorua
        "Scratch": (DealDamage(20),),
    },
    "sv9-98": {  # N's Zoroark ex
        # 特性「Trade」(手札を1枚捨てて2枚引く)はATTACK_EFFECTSではなくABILITY_EFFECTSに登録
        # (以前は誤ってこちらに登録していたため特性メニューに出ず使用不能になっていたバグを修正)。
        # "Night Joker"(ベンチの「N's」ポケモンのワザを1つ選んで使う)はengine.legal_actions.py
        # ATTACK_COPY_SOURCES(UseBorrowedAttackアクション)経由で対応済み。
    },
    "sv9-116": {  # N's Reshiram
        "Powerful Rage": (DamagePerSelfDamageCounters(20),),
        "Virtuous Flame": (DealDamage(170),),
    },
    "sv6-64": {  # Wellspring Mask Ogerpon ex
        "Sob": (DealDamage(20), DisableDefenderRetreatNextTurn()),
        # 「してもよい」はengine.legal_actions._attack_actions側で「しない」選択肢を含めて対応済み。
        # ベンチにいる間ダメージを受けないのは、このカード固有の特性ではなくテラスタルポケモン共通の
        # ルール箱テキストのため、effects.primitives._apply_defender_side_damage_modifiers内の
        # "Tera" in defender_card.subtypes判定で全Teraカード共通に対応済み(2026-08-22訂正)。
        "Torrential Pump": (
            DealDamage(100),
            ChooseOwnAttachedEnergyThenShuffleForBonusBenchDamage(energy_count=3, bonus_amount=120),
        ),
    },
    "sv6-112": {  # Cornerstone Mask Ogerpon ex
        # 特性「Cornerstone Stance」(特性持ちの相手ポケモンからのワザダメージを受けない、場所を
        # 問わない)は effects.primitives._CORNERSTONE_OGERPON_ID経由で対応済み(発動アクションを
        # 持たない常時効果)。加えて、ベンチにいる間は特性の有無を問わず一切ダメージを受けない
        # (テラスタルポケモン共通のルール箱テキスト、カード固有の特性ではない)効果も、
        # "Tera" in defender_card.subtypes判定で全Teraカード共通に対応済み。
        "Demolish": (DealDamageIgnoringWeaknessResistance(140, ignore_defender_effects=True),),  # 実カードテキスト: 弱点・抵抗力・相手にかかっている効果すべてを計算しない
    },
    # ---- WCS2025 7位 サーフゴー(Piper Lepine選手) ----
    "sv8-97": {  # Gimmighoul(SSP版)
        "Minor Errand-Running": (SearchDeckForBasicEnergyToHand(2),),
        "Tackle": (DealDamage(50),),
    },
    "sv4-87": {  # Gimmighoul(PAR版)
        "Call for Family": (SearchDeckForBasicPokemonToBench(1),),
        "Corkscrew Punch": (DealDamage(20),),
    },
    "sv4-139": {  # Gholdengo ex
        # 特性「Coin Bonus」(1回の自分の番に1回、カードを1枚引く。バトル場にいればさらに1枚)は
        # ATTACK_EFFECTSではなくABILITY_EFFECTSに登録(以前は誤ってこちらに登録していたため
        # 特性メニューに出ず使用不能になっていたバグを修正)。
        "Make It Rain": (DiscardEnergyFromHandForScalingDamage(base=0, max_count=99, damage_per=50, basic_only=True),),
    },
    "sv8-131": {  # Gholdengo(無印)
        "Strike It Rich": (DamageIfEvolvedThisTurn(base=30, bonus=90),),
        # 「山札に戻してもよい」はAFTER_ATTACK_TRIGGER_EFFECTS経由で対応済み。
        "Surf Back": (DealDamage(100),),
    },
    "zsv10pt5-67": {  # Genesect ex
        # 特性「Metallic Signal」(山札から鋼の進化ポケモンを最大2匹まで手札に加える)は
        # ATTACK_EFFECTSではなくABILITY_EFFECTSに登録(以前は誤ってこちらに登録していたため
        # 特性メニューに出ず使用不能になっていたバグを修正)。
        "Protect Charge": (DealDamage(150), ApplyDamageReductionToSelf(30)),
    },
    "sv3-83": {  # Togepi
        "Whiny Voice": (RandomOpponentHandCardToDeck(),),
        "Rolling Tackle": (DealDamage(20),),
    },
    "sv8-72": {  # Togekiss
        # 特性「Wonder Kiss」(相手のバトルポケモンがきぜつした時、コイントスでオモテなら追加でサイドを1枚取れる)は
        # 発動条件(あらゆるきぜつ契機のフック)が未整備のため未実装(v1簡略版、場に出せるが効果はなし)。
        "Speed Wing": (DealDamage(140),),
    },
    # ---- WCS2025 8位 Nのゾロアーク(Marco Cifuentes Meta選手) ----
    "sv4-15": {  # Toedscool
        "Clinging Spore": (AttachEnergyFromHandToTarget(energy_type="Grass", max_count=1),),
        "Vine Slap": (DealDamage(30),),
    },
    "sv4-17": {  # Toedscruel
        # 特性「Slime Mold Colony」(相手が自分のトラッシュから手札に戻す効果を防ぐ)は
        # 発動条件のフックが未整備のため未実装(v1簡略版、場に出せるが効果はなし)。
        "Mushroom Drain": (DealDamage(80), HealSelf(30)),
    },
    # ---- WCS2025 6位/8位 共通: Nのゾロアーク ----
    "sv6-77": {  # Iron Thorns ex
        "Volt Cyclone": (
            DealDamage(140),
            MoveEnergyBetweenOwnPokemon(),
        ),
    },
    # ---- WCS2024 2位 あばれるつき(Seinosuke Shiokawa選手) ----
    "sv4-124": {  # Roaring Moon ex
        "Frenzied Gouging": (KnockOutOpponentActiveThenSelfDamage(200),),
        "Calamity Storm": (DamageBonusIfStadiumDiscarded(100, 120),),
    },
    "sv6pt5-39": {  # Pecharunt ex
        "Irritated Outburst": (DamagePerOpponentPrizesTaken(0, 60),),
    },
    "sv5-109": {  # Roaring Moon(無印)
        "Vengeance Fletching": (DamagePerAncientCardInDiscard(70, 10),),
        "Speed Wing": (DealDamage(120),),
    },
    "swsh10-46": {  # Radiant Greninja
        "Moonlight Shuriken": (DiscardOwnEnergy(2), DealDamageToChosenOpponentPokemonMulti(2, 90)),
    },
    # ---- WCS2024 3位 ミライドンex(Jesse Parker選手) ----
    "sv1-81": {  # Miraidon ex
        "Photon Blaster": (DealDamage(220), LockOwnAttackNextTurn("Photon Blaster", lock_all_attacks=True)),
    },
    "sv4-70": {  # Iron Hands ex
        "Arm Press": (DealDamage(160),),
        "Amp You Very Much": (DealDamage(120), BonusPrizeIfThisAttackKnockedOutOpponent(1)),
    },
    "swsh9-48": {  # Raikou V
        "Lightning Rondo": (DamagePerTotalBenchedPokemon(20, 20),),
    },
    "swsh9-40": {  # Lumineon V
        "Aqua Return": (DealDamage(120), ShuffleSelfIntoDeck()),
    },
    "pgo-29": {  # Zapdos
        "Electric Ball": (DealDamage(110),),
    },
    "sv4-56": {  # Iron Bundle
        "Refrigerated Stream": (
            DealDamage(80),
            IfDefenderIsEvolved(then=(DisableDefenderAttackNextTurn(),)),
        ),
    },
    # ---- WCS2024 4位 レジドラゴVSTAR(Raz Wolpe選手) ----
    "swsh12-135": {  # Regidrago V
        "Celestial Roar": (DiscardTopNAttachEnergyFound(3),),
        "Dragon Laser": (
            DealDamage(130),
            DealBonusDamageToChosenOpponentBench(30),
        ),
    },
    # swsh12-136(レジドラゴVSTAR)の「Apex Dragon」も同様にlegal_actions._attack_copy_actions経由で対応済み。
    "swsh11-131": {  # Giratina VSTAR
        "Lost Impact": (DealDamage(280), DiscardOwnBasicEnergyThenScalingDamage(damage_per=0, destination="lost_zone", exact_count=2)),
        # ロストゾーンが10枚以上あるときのみ使用可(legal_actionsでゲート)。相手のバトルポケモンを問答無用できぜつさせる。
        "Star Requiem": (KnockOutOpponentActive(),),
    },
    "swsh11-136": {  # Hisuian Goodra VSTAR
        "Rolling Iron": (DealDamage(200), ApplyDamageReductionToSelf(80)),
    },
    "sv6pt5-47": {  # Kyurem(特性「Plasma Bane」によるコスト書き換えはengine.energy.effective_attack_cost経由)
        "Trifrost": (DiscardAllOwnEnergy(), DealDamageToChosenOpponentPokemonMulti(3, 110)),
    },
    # ---- WCS2023 優勝 フュージョンミュウ(Vance Kelley選手) ----
    "swsh8-113": {  # Mew V
        "Energy Mix": (SearchDeckAnyEnergyAttachToSelf(self_only=False, target_subtype="Fusion Strike"),),
        "Psychic Leap": (DealDamage(70),),  # 「してもよい」の山札に戻る効果はAFTER_ATTACK_TRIGGER_EFFECTS経由で対応済み
    },
    "swsh8-114": {  # Mew VMAX
        # 「Cross Fusion Strike」もlegal_actions._attack_copy_actions経由で対応済み。
        "Max Miracle": (DealDamageIgnoringAllDefenderEffects(130),),
    },
    "swsh8-185": {  # Genesect V
        "Techno Blast": (DealDamage(210), LockOwnAttackNextTurn("Techno Blast", lock_all_attacks=True)),
    },
    "swsh8-124": {  # Meloetta
        "Melodious Echo": (DamagePerFusionStrikeEnergyAcrossBoard(70),),
    },
    "swsh8-42": {  # Oricorio
        "Glistening Droplets": (DistributeDamageCountersFreely(5),),
    },
    # ---- WCS2023 2位 ガーデヴォール(Tord Reklev選手) ----
    "swsh10-60": {  # Ralts
        "Teleportation Burst": (DealDamage(10), SwitchActiveWithBench()),
    },
    "swsh12-67": {  # Ralts(シルバーテンペスト版)
        "Memory Skip": (DealDamage(10), LockChosenOpponentAttackNextTurn()),
    },
    "swsh12-68": {  # Kirlia
        "Slap": (DealDamage(30),),
    },
    "swsh6-60": {  # Kirlia(CRE版)
        "Mirage Step": (SearchDeckForNamedPokemonToBench("Kirlia", 3),),
    },
    "swsh6-61": {  # Gardevoir
        "Brainwave": (DamagePerSelfEnergyOfType(60, 30, "Psychic"),),
    },
    "cel25-16": {  # Zacian V
        "Storm Slash": (DamagePerSelfEnergyOfType(60, 30, "Psychic"),),
    },
    "swsh11-74": {  # Cresselia
        "Moonglow Reverse": (MoveDamageCountersFromAllOwnPokemonToChosenOpponent(2),),
        "Lunar Blast": (DealDamage(110),),
    },
    "cel25-11": {  # Mew
        "Psyshot": (DealDamage(30),),
    },
    "swsh9-41": {  # Manaphy
        "Rain Splash": (DealDamage(20),),
    },
    # ---- WCS2023 4位 フュージョンミュウ(Azul Garcia Griego選手) ----
    "swsh9-44": {  # Eiscue
        "Block Slider": (DamagePerFusionStrikeEnergyAcrossBoard(40, choose_target=True),),
        "Icicle Missile": (DealDamage(100),),
    },
    # ---- WCS2023 3位 ギラティナLZボックス(Michael Pramawat選手) ----
    "swsh11-79": {  # Comfey(キュワワー)
        "Spinning Attack": (DealDamage(30),),
    },
    "swsh11-130": {  # Giratina V
        "Abyss Seeking": (LookTopNKeepMRestToLostZone(4, 2),),
        "Shred": (DealDamageIgnoringAllDefenderEffects(160),),
    },
    "swsh11-70": {  # Sableye(ヤミラミ)
        "Scratch": (DealDamage(20),),
        # ロストゾーンが10枚以上あるときのみ使用可(legal_actionsでゲート)。
        "Lost Mine": (DistributeDamageCountersFreely(12),),
    },
    "swsh11-50": {  # Cramorant(ウッウ)
        "Spit Innocently": (DealDamageIgnoringWeaknessOnly(110),),
    },
    "swsh11-143": {  # Snorlax(カビゴン)
        "Thumping Snore": (DealDamage(180), InflictHardToWakeSleepOnSelf(2)),
    },
    # ---- WCS2022 優勝 アルセウス/そらとぶピカチュウ(Ondřej Škubal選手) ----
    "swsh9-122": {  # Arceus V
        "Trinity Charge": (
            SearchDeckAnyEnergyAttachToSelf(basic_only=True, self_only=False, target_subtype="V"),
            SearchDeckAnyEnergyAttachToSelf(basic_only=True, self_only=False, target_subtype="V"),
            SearchDeckAnyEnergyAttachToSelf(basic_only=True, self_only=False, target_subtype="V"),
        ),
        "Power Edge": (DealDamage(130),),
    },
    "swsh9-123": {  # Arceus VSTAR
        "Trinity Nova": (
            DealDamage(200),
            SearchDeckAnyEnergyAttachToSelf(basic_only=True, self_only=False, target_subtype="V"),
            SearchDeckAnyEnergyAttachToSelf(basic_only=True, self_only=False, target_subtype="V"),
            SearchDeckAnyEnergyAttachToSelf(basic_only=True, self_only=False, target_subtype="V"),
        ),
    },
    "cel25-6": {  # Flying Pikachu V
        "Thunder Shock": (DealDamage(20), FlipCoinThen(heads=(InflictStatusOnDefender("paralyzed"),))),
        "Fly": (FlipCoinThen(heads=(DealDamage(120), ApplyShieldToSelf())),),
    },
    "cel25-7": {  # Flying Pikachu VMAX
        "Max Balloon": (DealDamage(160), ApplyScopedDamageImmunityToSelf("basic")),
    },
    "swsh10-83": {  # Hisuian Decidueye V
        "Mountain Hunt": (SearchDeckAnyCardToHand(2),),
        "Close-Quarters Shooting": (DealDamageIgnoringAllDefenderEffects(100),),
    },
    "swsh10-84": {  # Hisuian Decidueye VSTAR
        "Somersault Feathers": (DiscardEnergyFromHandForScalingDamage(160, 3, 30),),
    },
    "swsh9-120": {  # Bidoof
        "Rollout": (DealDamage(30),),
    },
    "swsh9-121": {  # Bibarel
        "Tail Smash": (FlipCoinThen(heads=(DealDamage(100),)),),
    },
    "swsh3-104": {  # Crobat V
        "Venomous Fang": (DealDamage(70), InflictStatusOnDefender("poisoned")),
    },
    "swsh7-76": {  # Pumpkaboo
        "Stampede": (DealDamage(20),),
    },
    # ---- WCS2022 2位 アルセウス/そらとぶピカチュウ(Daichi Shimada選手) ----
    "swsh7-125": {  # Eevee(Vee-Search版)
        "Vee-Search": (SearchDeckMultiCriteria(("pokemon_v", "pokemon_v", "pokemon_v")),),
        "Stampede": (DealDamage(20),),
    },
    "swsh10-119": {  # Eevee(ヒスイ版)
        "Tackle": (DealDamage(20),),
    },
    "swsh4-47": {  # Jolteon
        "Electric Ball": (DealDamage(90),),
    },
    "swsh6-97": {  # Galarian Moltres V
        "Aura Burn": (DealDamage(190), SelfDamage(30)),
    },
    # ---- WCS2022 4位 パルキアVSTAR/インテレオン(James Cox選手) ----
    "swsh10-39": {  # Origin Forme Palkia V
        "Rule the Region": (SearchDeckMultiCriteria(("stadium",)),),
        "Hydro Break": (DealDamage(200), LockOwnAttackNextTurn("Hydro Break", lock_all_attacks=True)),
    },
    "swsh10-40": {  # Origin Forme Palkia VSTAR
        "Subspace Swell": (DamagePerTotalBenchedPokemon(60, 20),),
    },
    "swsh6-41": {  # Sobble
        "Keep Calling": (SearchDeckForBasicPokemonToBench(3, required_subtype="Rapid Strike"),),
        "Double Spin": (DealDamagePerHeads(2, 20),),
    },
    "swsh1-56": {  # Drizzile
        "Water Drip": (DealDamage(30),),
    },
    "swsh1-58": {  # Inteleon(SSH版)
        "Aqua Bullet": (DealDamage(120), DealBonusDamageToChosenOpponentBench(20)),
    },
    "swsh6-43": {  # Inteleon(れんげきタグ版)
        "Waterfall": (DealDamage(70),),
    },
    "swsh8-76": {  # Crabominable V
        "Trigger Avalanche": (DiscardTopOfOpponentDeck(2),),
        "Destroyer Punch": (DamagePerDefenderDamageCounters(90, 60),),
    },
    "swsh1-117": {  # Galarian Zigzagoon
        "Surprise Attack": (FlipCoinThen(heads=(DealDamage(30),)),),
    },
    # ---- Players Cup 2020 優勝 ザシアン&メルメタル(Natalie Millar選手) ----
    "swsh1-138": {  # Zacian V
        "Brave Blade": (DealDamage(230), LockOwnAttackNextTurn("Brave Blade", lock_all_attacks=True)),
    },
    "sm10-120": {  # Lucario & Melmetal-GX
        "Steel Fist": (SearchDeckAndAttachEnergy("Metal", 1), DealDamage(50)),
        "Heavy Impact": (DealDamage(150),),
        "Full Metal Wall-GX": (
            ActivatePermanentMetalDamageReduction(),
            IfExtraEnergyAttached(1, 1, then=(DiscardAllOpponentActiveEnergy(),)),
        ),
    },
    "swsh1-139": {  # Zamazenta V
        "Assault Tackle": (DealDamage(130), DiscardOpponentActiveSpecialEnergy()),
    },
    "sm9-100": {  # Bronzor
        "Tackle": (DealDamage(20),),
    },
    "sm9-101": {  # Bronzong
        "Shady Stamp": (DealDamage(70), InflictStatusOnDefender("confused")),
    },
    # ---- Players Cup 2021 優勝 れんげきウーラオス(Azul Garcia Griego選手) ----
    "swsh5-87": {  # Rapid Strike Urshifu V
        "Strafe": (DealDamage(30),),  # 攻撃後の「自分のベンチと入れ替えてもよい」はAFTER_ATTACK_TRIGGER_EFFECTS経由で対応済み
        "Hundred Furious Blows": (DealDamage(150),),
    },
    "swsh5-88": {  # Rapid Strike Urshifu VMAX
        "Gale Thrust": (DamageIfBecameActiveThisTurn(30, 120),),
        "G-Max Rapid Flow": (DiscardAllOwnEnergy(), DealDamageToChosenOpponentPokemonMulti(2, 120)),
    },
    "sm9-99": {  # Jirachi
        "Slap": (DealDamage(30),),
    },
    "sm10-57": {  # Dedenne-GX
        "Static Shock": (DealDamage(50),),
        "Tingly Return-GX": (DealDamage(50), InflictStatusOnDefender("paralyzed"), ReturnSelfToHand()),
    },
    "sm11-86": {  # Giratina
        "Fade to Black": (DealDamage(70), InflictStatusOnDefender("confused")),
    },
    "sm10-76": {  # Mew
        "Psypower": (DistributeDamageCountersFreely(3),),
    },
    "sm12-97": {  # Mimikyu
        "Tail Trickery": (DealDamage(20), FlipCoinThen(heads=(InflictStatusOnDefender("confused"),))),
    },
    "sm11-79": {  # Jirachi-GX
        "Star Search": (SearchDeckAnyEnergyAttachToSelf(self_only=False, target_type="Psychic"),),
        "Star Shield-GX": (DealDamage(100), ApplyShieldToSelf()),
    },
    # ---- WCS2019 優勝 ミュウツー&ミュウGX(Henry Brand選手) ----
    "sm11-71": {  # Mewtwo & Mew-GX
        # 特性「パーフェクション」(ベンチ/トラッシュのGX/EXポケモンのワザを借りて使える)は、UseAbility方式
        # ではなく専用のUseBorrowedAttackアクション(legal_actions._perfection_attack_actions、
        # rules_engine._handle_use_borrowed_attack)で対応済み。v1簡略版: 借りられるのは通常ワザのみで、
        # GXワザ/VSTARパワー自体を借りることはできない(1ゲームに1回制限との整合性が複雑なため)。
        "Miraculous Duo-GX": (DealDamage(200), IfExtraEnergyAttached(3, 1, then=(HealAllOwnPokemon(),))),
    },
    "sm1-89": {  # Solgaleo-GX
        "Sunsteel Strike": (DealDamage(230), DiscardAllOwnEnergy()),
        "Sol Burst-GX": (SearchDeckAndAttachEnergy(None, 5, self_only=False),),
    },
    # ---- WCS2019 5位 ピカチュウ&ゼクロムGX(Kaiwen Cabbabe選手) ----
    "sm9-33": {  # ピカチュウ&ゼクロムGX(Pikachu & Zekrom-GX)
        "Full Blitz": (DealDamage(150), SearchDeckForBasicEnergyAttachToTarget(3, "Lightning")),
        "Tag Bolt-GX": (
            DealDamage(200),
            IfExtraEnergyAttached(3, 3, then=(DealBonusDamageToChosenOpponentBench(170),), energy_type="Lightning"),
        ),
    },
    "sm11-54": {  # カプ・ライチュウ&アローラライチュウGX(Raichu & Alolan Raichu-GX)
        "Tandem Shock": (DamageAndStatusIfBecameActiveThisTurn(0, 80, "paralyzed"),),
        "Lightning Ride-GX": (
            DealDamage(150),
            IfExtraEnergyAttached(2, 2, then=(DealDamage(100),), energy_type="Lightning"),
            SwitchActiveWithBench(),
        ),
    },
    "sm8-86": {  # ライボルトGX(Zeraora-GX)
        # 特性「Thunderclap Zone」(雷エネルギーがついている自分のポケモンはにげるコストが0)は
        # engine.energy.effective_retreat_cost_count経由で対応済み(発動アクションを持たないため
        # ABILITY_EFFECTSには登録しない)。
        # 実カードテキスト: "This Pokemon can't attack during your next turn."(プレイヤー全体
        # ではなくこのポケモン自身のロック。以前はLockSelfAttackNextTurn(プレイヤー単位ロック)
        # が誤用されており、このポケモンが引っ込んでも他のポケモンまで攻撃できなくなっていた
        # バグだったため修正、2026-08-22)。
        "Plasma Fists": (DealDamage(160), LockOwnAttackNextTurn("Plasma Fists", lock_all_attacks=True)),
        "Full Voltage-GX": (AttachDiscardEnergyFreelyToOwnPokemon(5),),
    },
    "sm8-98": {  # ネイティオ違い、いや実際はシギリスGX(Sigilyph-GX)
        # 特性「Mirror Counter」(GX/EXからのワザダメージを攻撃側にも同量のせる)は反撃ダメージという
        # 新種の仕組みが必要なため未実装(v1簡略版として一覧に登録せず、通常ワザのみ対応)。
        "Sonic Wing": (DealDamageIgnoringResistance(80),),
        "Intercept-GX": (DamagePerOpponentActiveEnergyCount(0, 60),),
    },
    "sm9-51": {  # カプ・コケコ◇(Tapu Koko ◇)
        # 特性「Dance of the Ancients」(ベンチにいる間、自分のベンチポケモン2匹を選びトラッシュから
        # 雷エネルギーをそれぞれにつけ、その後自分自身をロストゾーンに送る)は、対象選択+自己ロスト
        # ゾーン送りの複合処理が必要なため未実装(v1簡略版として一覧に登録せず、通常ワザのみ対応)。
        "Mach Bolt": (DealDamage(120),),
    },
    # ---- WCS2019 6位 ボルケニオン/レシラム&リザードンGX(Paco Vilchez Barea選手) ----
    "sm11-140": {  # フーパ(Hoopa)
        # 「Evil Admonition」(相手の特性持ちポケモン1匹につき+20)は相手の場全体を数える対象条件が
        # 追加で必要なため未実装(v1簡略版として一覧に登録せず、Mind Shockのみ対応)。
        "Mind Shock": (DealDamageIgnoringWeaknessResistance(80),),
    },
    # ---- WCS2019 7位 ミュウツー&ミュウGX(Ryota Ishiyama選手) ----
    "smp-SM171": {  # ブースターGX(Flareon-GX)
        "Heat Stage": (DealDamage(30), AttachEnergyFromHandToTarget("Fire", 3)),
        "Bright Flame": (DealDamage(190), DiscardOwnEnergy(2, "Fire")),
        "Power Burner-GX": (DamagePerOwnDiscardEnergyOfTypeCount(20, "Fire"),),
    },
    # ---- WCS2019 8位 ヤレユータン/ポッポ(Isaiah Williams選手) ----
    "sm9-121": {  # ポッポ(Pidgey)
        "Collect": (Draw(1),),
        "Gust": (DealDamage(20),),
    },
    "sm9-123": {  # ピジョン(Pidgeotto)
        "Gust": (DealDamage(30),),
    },
    "sm8-94": {  # キリンリキ(Girafarig)
        "Get Lost": (ChooseOpponentDiscardCardsToLostZone(2),),
        "Mind Shock": (DealDamageIgnoringWeaknessResistance(70),),
    },
    "sm7-31": {  # フリーザーGX(Articuno-GX)
        # 特性「Legendary Ascent」(手札からベンチに出したとき、してもよい)はENTER_BENCH_TRIGGER_EFFECTS経由で対応済み。
        "Ice Wing": (DealDamage(130),),
        "Cold Crush-GX": (DiscardAllEnergyFromBothActivePokemon(),),
    },
    "sm8-154": {  # メタモン◇(Ditto ◇)
        # 特性「Almighty Evolution」(手札の1進化ポケモンを進化元の一致条件を問わず重ねられる)は
        # 通常の進化ルールの例外という特殊な仕組みが必要なため未実装(v1簡略版として一覧に登録せず、
        # 場には出せるが特性は使えない)。
    },
    "sm10-20": {  # Reshiram & Charizard-GX
        "Outrage": (DamagePerSelfDamageCounters(10, base=30),),  # 30+(基本ダメージと追加を1回の計算にまとめた)
        "Flare Strike": (DealDamage(230), LockOwnAttackNextTurn("Flare Strike")),
        # v1簡略版: 相手のバトルポケモンの効果を無視する部分は未対応、追加ダメージのみ実装
        "Double Blaze-GX": (DamageBonusAndIgnoreEffectsIfExtraEnergy(base=200, bonus=100, own_cost_count=3, extra_needed=3, energy_type="Fire"),),
    },
    "sm8-44": {  # Magcargo-GX
        # 実カードテキスト: "Discard any amount of basic Energy from this Pokémon. This attack does 50 more damage
        # for each card you discarded in this way."(以前は全エネルギーを自動でトラッシュし、基本ダメージを別計算にしていた)
        "Lava Flow": (DiscardOwnBasicEnergyThenScalingDamage(damage_per=50, base=50, source_only=True),),
        "Burning Magma-GX": (DiscardTopOfOpponentDeck(5),),
    },
    "sm9-113": {  # Latias & Latios-GX
        "Buster Purge": (DealDamage(240), DiscardOwnEnergy(3)),
        # 追加エネルギー判定はエネルギーを付ける前の枚数で行う(実カード通り、シールド判定が先)。
        "Aero Unit-GX": (
            IfExtraEnergyAttached(1, 1, then=(ApplyShieldToSelf(),)),
            AttachDiscardEnergyFreelyToOwnPokemon(5),
        ),
    },
    "sm11-72": {  # Espeon & Deoxys-GX
        "Psychic Club": (DamagePerOwnBenchedPokemonOfType(10, 30, "Psychic"),),
        "Cross Division-GX": (DistributeDamageCountersFreelyConditional(10, 10, 3, 3),),
    },
    "sm9-106": {  # Cobalion-GX
        "Dueling Saber": (DealDamage(50), DamageIfStadiumInPlay(60)),
        "Iron Rule-GX": (LockOpponentAttackNextTurn(),),
    },
    "sm10-81": {  # Marshadow
        "Red Knuckles": (DamageIfDefenderHasSubtype(10, 60, "Ultra Beast"),),
    },
    # ---- WCS2019 2位 ズガドーンGX/アーゴヨン(Shintaro Ito選手) ----
    "sm8-52": {  # Blacephalon-GX
        "Bursting Burn": (InflictStatusOnDefender("burned"), InflictStatusOnDefender("confused")),
        "Mind Blown": (DiscardOwnBasicEnergyThenScalingDamage(damage_per=50, energy_type="Fire", destination="lost_zone"),),
        "Burst-GX": (RandomPrizeDiscardAttachIfEnergyToSelf(),),  # 対象は自分の場の任意の1匹を選べる(クラス名は初期実装時の名残)
    },
    "sm6-55": {  # Poipole(FLI版)
        "Spit Poison": (InflictStatusOnDefender("poisoned"),),
        "Knockout Reviver": (PreventPrizesIfKnockedOutNextTurn(),),
    },
    "sm8-107": {  # Poipole(LOT版)
        "Peck": (DealDamage(20),),
        "Eye Opener": (PeekOwnPrizes(),),  # 自分の裏向きのサイドを見る(本人だけが中身を知る)
    },
    "sm8-108": {  # Naganadel
        "Turning Point": (DamageIfOwnPrizesRemainingExactly(80, 80, 3),),
    },
    "sm11-25": {  # Heatran-GX
        "Steaming Stomp": (DealDamage(130),),
        "Hot Burn-GX": (DamagePerSelfEnergyOfType(0, 50, "Fire"),),
    },
    "sm6-56": {  # Naganadel-GX
        "Beast Raid": (DamagePerOwnPokemonWithSubtype(0, 20, "Ultra Beast"),),
        "Jet Needle": (DealDamageIgnoringWeaknessResistance(110),),
        "Stinger-GX": (ResetBothPlayersPrizes(3),),
    },
    # ---- WCS2019 3位 ボルケニオン/レシラム&リザードンGX(Blaine Hill選手) ----
    "sm10-25": {  # Volcanion
        "Flare Starter": (SearchDeckForBasicEnergyAttachFreelyWithSecondTurnBonus(1, 3, energy_type="Fire"),),
        "High-Heat Blast": (DamageIfOwnEnergyTypeCountInPlayAtLeast(50, 60, "Fire", 4),),
    },
    # ---- WCS2019 4位 レシラム&リザードンGX(Tord Reklev選手) ----
    "sm11-26": {  # Victini
        "Victory Sign": (SearchDeckForBasicEnergyAttachFreely(2, distinct_types=True),),
        "Flare": (DealDamage(20),),
    },
    "sm2-17": {  # Turtonator
        "Body Slam": (FlipCoinThen(heads=(InflictStatusOnDefender("paralyzed"),)), DealDamage(30)),
        "Heat Blast": (DealDamage(90),),
    },
    "drm-7": {  # ビクティニ(プリズムスター、Victini、DRM/7)
        "Infinity": (DamagePerOwnDiscardBasicEnergyCountThenShuffleIntoDeck(per_energy=20),),
    },
    "drm-50": {  # バクガメス(Turtonator、DRM/50)
        # 「Explosive Jet」(自分の場のポケモン全体から好きな枚数ほのおエネルギーを選んでトラッシュし、
        # 捨てた枚数×50ダメージ): DiscardOwnBasicEnergyThenScalingDamageが場の全ポケモン横断
        # (_field_attachment_candidates経由)で対応済み。
        "Explosive Jet": (DiscardOwnBasicEnergyThenScalingDamage(damage_per=50, energy_type="Fire"),),
    },
    "sm9-15": {  # Vulpix
        "Tail Whip": (FlipCoinThen(heads=(DisableDefenderAttackNextTurn(),)),),
    },
    "sm9-16": {  # Ninetales
        "Flame Tail": (DealDamage(90),),
    },
    # ---- WCS2018 優勝 ゾロアーク/ダストダス(Robin Schulz選手) ----
    "xy8-89": {  # ゾロア(Zorua)
        "Moonless Madness": (InflictStatusOnDefender("confused"),),
        "Dark Edge": (DealDamage(30), DiscardOwnEnergy(1)),
    },
    "sm35-53": {  # ゾロアークGX(Zoroark-GX)
        "Riotous Beating": (DamagePerOwnPokemonInPlay(20),),
        # 「トリックスターGX」(相手のワザをコピーして使う)はlegal_actions.ATTACK_COPY_SOURCES
        # (UseBorrowedAttackアクション)経由で対応済み。
    },
    "xy9-56": {  # ヤブクロン(Trubbish)
        "Acid Spray": (DealDamage(10), FlipCoinThen(heads=(DiscardOpponentActiveEnergy(),))),
    },
    "xy9-57": {  # ダストダス(Garbodor)
        "Offensive Bomb": (DealDamage(60), InflictStatusOnDefender("confused"), InflictStatusOnDefender("poisoned")),
    },
    "sm2-60": {  # タプ・レレGX(Tapu Lele-GX)
        "Energy Drive": (DamagePerBothActiveEnergyCount(0, 20, ignore_weakness_resistance=True),),
        "Tapu Cure-GX": (ChooseOwnBenchThenHealFully(2),),
    },
    "sm4-70": {  # カミツルギGX(Kartana-GX)
        "Gale Blade": (DealDamage(70),),  # 「してもよい」の山札に戻る効果はAFTER_ATTACK_TRIGGER_EFFECTS経由で対応済み
        "Blade-GX": (TakeOwnPrizeCard(),),
    },
    # ---- WCS2018 2位 カラマネロ(Jeff Kolenc選手) ----
    "sm3-89": {  # マーイーカ(Inkay)
        "Constrict": (FlipCoinThen(heads=(InflictStatusOnDefender("paralyzed"),)),),
        "Tackle": (DealDamage(20),),
    },
    "sm3-90": {  # カラマネロ(Malamar)
        "Psybeam": (DealDamage(20), InflictStatusOnDefender("confused")),
        "Energy Slosh": (MoveEnergyBetweenOwnPokemon(move_all=True), DealDamage(70)),
    },
    "sm3-80": {  # マーシャドーGX(Marshadow-GX)
        # 特性「シャドーハント」(トラッシュのたねポケモンのワザを自分のワザとして使える)は
        # legal_actions._shadow_hunt_attack_actions(UseBorrowedAttackアクション)経由で対応済み。
        "Beatdown": (DealDamage(120),),
        "Peerless Hundred Blows-GX": (DamagePerOwnAttachedEnergyCount(50, basic_only=True),),
    },
    "sm5-63": {  # ダウンウィングネクロズマGX(Dawn Wings Necrozma-GX)
        "Dark Flash": (DealDamageIgnoringResistance(120),),
        "Moon's Eclipse-GX": (ApplyShieldToSelf(), DealDamage(180)),
    },
    "sm3-63": {  # ネクロズマGX(Necrozma-GX)
        # 特性「Light's End」(無色ポケモンのワザによるダメージを受けない)はeffects/primitives.py の
        # _FULL_DAMAGE_IMMUNITY_VS_TYPE経由で対応済み(常時発動、有効化アクション不要)。
        "Prismatic Burst": (DiscardOwnEnergyTypeThenBonusDamage(10, "Psychic", 60),),
        "Black Ray-GX": (DealDamageToAllOpponentGxExPokemon(100),),
    },
    "sm35-39": {  # ミュウツーGX(Mewtwo-GX)
        "Full Burst": (DamagePerOwnAttachedEnergyCount(30),),
        "Super Absorption": (DealDamage(60), HealSelf(30)),
        "Psystrike-GX": (DealDamageIgnoringDefenderShieldAndReduction(200),),
    },
    "sm5-62": {  # ルナアーラ◇(Lunala Prism Star)
        "Full Moon Star": (SearchDiscardForEnergyAttachToSelfCountEqualOpponentPokemon("Psychic"),),
        "Psystorm": (DamagePerAllPokemonEnergyCountAcrossBoard(20),),
    },
    "sm2-58": {  # ミミッキュ(Mimikyu)
        "Filch": (Draw(2),),
        # 「コピーキャット」(相手が直前の番で使ったGXワザでないワザをこのワザとして使う)は
        # legal_actions._copycat_attack_actions(UseBorrowedAttackアクション)経由で対応済み。
    },
    "smp-SM151": {  # ギラティナ(Giratina、SMプロモ版)
        # 特性「Distortion Door」(トラッシュからベンチに出す)はDISCARD_ABILITY_EFFECTS
        # (UseDiscardAbilityアクション)経由で対応済み。
        "Shadow Impact": (DealDamage(130), DamageCounterOnChosenOwnPokemon(4)),
    },
    "sm1-113": {  # ヤレユータン(Oranguru)
        "Psychic": (DamagePerOpponentActiveEnergyCount(60, 20),),
    },
    # ---- WCS2018 3位 ジガルデGX/ルガルガンGX(Klive Aw Jun Jie選手) ----
    "sm6-73": {  # ジガルデGX(Zygarde-GX)
        "Cell Connector": (DealDamage(50), AttachEnergyFromDiscardToOwnPokemon(energy_type="Fighting", count=2, self_only=True)),
        "Land's Wrath": (DealDamage(130),),
        # 「Verdict-GX」(相手の次の番、GX/EXのワザによるダメージを受けない)はv1簡略版として
        # ダメージのみ対応(GX/EX限定シールドは未実装)。
        "Verdict-GX": (DealDamage(150), ApplyScopedDamageImmunityToSelf("gx_ex")),
    },
    "sm6-75": {  # イワンコ(Rockruff)
        "Surprise Attack": (FlipCoinThen(heads=(DealDamage(50),)),),
    },
    "sm2-74": {  # ルガルガンGX(Lycanroc-GX、たそがれのすがた)
        # 特性「Bloodthirsty Eyes」(手札から進化させて出したとき、してもよい)はEVOLVE_TRIGGER_EFFECTS経由で対応済み。
        "Claw Slash": (DealDamage(110),),
        "Dangerous Rogue-GX": (DamagePerOpponentBenchedPokemon(0, 50),),
    },
    "sm6-77": {  # マッシブーン(Buzzwole)
        "Sledgehammer": (DamageIfOpponentPrizesRemainingExactly(30, 90, 4),),
        "Swing Around": (FlipMultipleCoinsForBonusDamage(80, 2, 20),),
    },
    "sm4-57": {  # マッシブーンGX(Buzzwole-GX)
        "Jet Punch": (DealBonusDamageToChosenOpponentBench(30),),
        # 実カードテキスト: "This Pokemon can't attack during your next turn."(プレイヤー単位の
        # LockSelfAttackNextTurnは誤りだったため、Plasma Fists等と同様にポケモン単位に修正、2026-08-22)。
        "Knuckle Impact": (DealDamage(160), LockOwnAttackNextTurn("Knuckle Impact", lock_all_attacks=True)),
        "Absorption-GX": (DamagePerOwnPrizesRemaining(40),),
    },
    "sm6-74": {  # ディアンシー◇(Diancie ◇)
        # 特性「Princess's Cheers」(自分のベンチにいる間、自分の闘ポケモンのワザ+20)は常時効果のため
        # engine/continuous.py の fighting_pokemon_flat_bonus_damage 経由で対応済み(ABILITY_EFFECTSには登録しない)。
        "Diamond Rain": (DealDamage(90), HealAllOwnPokemon(bench_only=True, amount=30)),
    },
    "xy10-43": {  # レジロックEX(Regirock-EX)
        # 特性「Regi Power」(レジロックEX以外の自分の闘ポケモンのワザ+10)は常時効果のため
        # engine/continuous.py の fighting_pokemon_flat_bonus_damage 経由で対応済み(ABILITY_EFFECTSには登録しない)。
        "Bedrock Press": (DealDamage(100), ApplyDamageReductionToSelf(20)),
    },
    # ---- WCS2018 4位 レックウザGX(Pedro Eugenio Torres選手) ----
    "sm7-109": {  # レックウザGX(Rayquaza-GX)
        # 特性「Stormy Winds」(手札からベンチに出したとき、してもよい)はENTER_BENCH_TRIGGER_EFFECTS経由で対応済み。
        "Dragon Break": (DamagePerOwnBoardEnergyOfTypes(30, ("Grass", "Lightning")),),
        "Tempest-GX": (DiscardHandThenDraw(10),),
    },
    # ---- WCS2018 5位/7位 レックウザGX(Eric Smith/Shuto Itagaki選手) ----
    "sm7-107": {  # ラティアス◇(Latias ◇)
        "Dreamy Mist": (DealDamage(30), AttachEnergyFromDiscardToEachOwnBenchedOfType("Dragon")),
    },
    # ---- WCS2018 6位 マッシブーン/ルガルガンGX(Nicolas Galaz選手) ----
    "sm2-47": {  # カプ・コケコGX(Tapu Koko-GX)
        # 特性「Aero Trail」(手札からベンチに出したとき、してもよい)はENTER_BENCH_TRIGGER_EFFECTS経由で対応済み。
        "Sky-High Claws": (DealDamage(130),),
        "Tapu Thunder-GX": (DamagePerOpponentAllPokemonEnergyCount(50),),
    },
    # ---- WCS2018 8位 ゾロアーク/ゴロズブレイクGX(Brian Miller選手) ----
    "sm35-52": {  # ゾロア(Zorua、Shining Legends版)
        "Stampede": (DealDamage(10),),
        "Ram": (DealDamage(20),),
    },
    "sm35-45": {  # マーシャドー(Marshadow)
        # 特性「Let Loose」(手札からベンチに出したとき、してもよい)はENTER_BENCH_TRIGGER_EFFECTS経由で対応済み。
        "Shadow Punch": (DealDamageIgnoringResistance(30),),
    },
    "smp-SM68": {  # デンジュモクGX(Xurkitree-GX)
        # 特性「Flashing Head」(特殊エネルギーがついた相手のポケモンからのダメージを受けない)は常時効果のため
        # effects/primitives.py の _FULL_DAMAGE_IMMUNITY_VS_ATTACKER_SPECIAL_ENERGY 経由で対応済み。
        "Rumbling Wires": (DealDamage(100), DiscardTopOfOpponentDeck(1)),
        "Lighting-GX": (MoveOpponentHandCardToTheirPrizes(),),
    },
    # ---- WCS2017 優勝 サーナイトGX(Diego Cassiraga選手) ----
    "sm3-91": {  # ラルトス(Ralts)
        "Draining Kiss": (DealDamage(10), HealSelf(10)),
    },
    "sm3-92": {  # キルリア(Kirlia)
        "Smack": (DealDamage(20),),
        "Magical Shot": (DealDamage(30),),
    },
    "sm3-93": {  # サーナイトGX(Gardevoir-GX)
        # 特性「Secret Spring」(手札からフェアリーエネルギーを自分のポケモンにつけてもよい)はABILITY_EFFECTS経由で対応済み。
        "Infinite Force": (DamagePerBothActiveEnergyCount(0, 30),),
        "Twilight-GX": (ShuffleDiscardIntoDeck(10),),
    },
    "xy8-84": {  # エルレイド(Gallade)
        # 特性「Premonition」(山札の上5枚を見て並び替える)は順序操作のため非実装(NotImplementedEffect)。
        "Sensitive Blade": (DamageIfSupporterPlayedThisTurn(60, 70),),
    },
    "xy8-31": {  # テッポウオ(Remoraid)
        "Wild River": (SwitchActiveWithBench(),),
        "Water Gun": (DealDamage(20),),
    },
    "xy8-33": {  # オクタン(Octillery)
        # 特性「Abyssal Hand」(手札が5枚になるまで引く)はABILITY_EFFECTS経由で対応済み。
        "Hug": (DealDamage(40), DisableDefenderRetreatNextTurn()),
    },
    "sm3-94": {  # ディアンシー(Diancie、通常版)
        "Sparkling Wish": (InstantEvolveAnyOwnPokemonFromDeck(),),
        "Diamond Storm": (DealDamage(30), HealAllOwnPokemonOfType("Fairy", 30)),
    },
    "sm2-21": {  # アローラロコン(Alolan Vulpix)
        "Beacon": (SearchDeckForPokemonToHand(2),),
        "Icy Snow": (DealDamage(20),),
    },
    # ---- WCS2017 2位 グソクムシャGX(Naoto Suzuki選手) ----
    "sm3-16": {  # コソクムシ(Wimpod)
        # 特性「Wimp Out」(自分の最初の番、にげるコストが0)はengine.energy.WIMPOD_ID経由で対応済み。
        "Gnaw": (DealDamage(30),),
    },
    "sm3-17": {  # グソクムシャGX(Golisopod-GX)
        # 「First Impression」はv1簡略版: ベンチから出たばかりの条件による+90ダメージは未対応(常に基本30ダメージのみ)。
        "First Impression": (DamageIfBecameActiveThisTurn(30, 90),),
        "Armor Press": (DealDamage(100), ApplyDamageReductionToSelf(20)),
        "Crossing Cut-GX": (DealDamage(150), SwitchActiveWithBench()),
    },
    "sm2-51": {  # ダストダス(Garbodor、GRI版)
        "Trashalanche": (DamagePerOpponentDiscardItemCount(20),),
        "Acid Spray": (DealDamage(70), FlipCoinThen(heads=(DiscardOpponentActiveEnergy(),))),
    },
    "smp-SM30": {  # カプ・コケコ(Tapu Koko、通常版)
        "Flying Flip": (DealDamageToAllOpponentPokemon(20),),
        "Electric Ball": (DealDamage(100),),
    },
    # ---- WCS2017 3位 エーフィGX/ダストダス(Xander Pero選手) ----
    "sm1-101": {  # イーブイ(Eevee)
        # 特性「Energy Evolution」(手札からエネルギーをつけたとき、してもよい)はENERGY_ATTACH_TRIGGER_EFFECTS
        # 経由で対応済み(v1簡略版: エネルギータイプ一致条件は未対応)。
        "Quick Draw": (FlipCoinThen(heads=(Draw(1),)),),
    },
    "sm1-61": {  # エーフィGX(Espeon-GX)
        "Psybeam": (DealDamage(30), InflictStatusOnDefender("confused")),
        "Psychic": (DamagePerOpponentActiveEnergyCount(60, 30),),
        "Divide-GX": (DistributeDamageCountersFreely(10),),
    },
    "xy7-13": {  # ブースター(Flareon)
        # 特性「Flare Effect」(自分の1進化ポケモン全員がほのおタイプを追加で持つ)は、
        # タイプ計算全体に影響する広範な効果のため未実装(v1簡略版)。
        "Heat Breath": (FlipCoinThen(heads=(DealDamage(80),), tails=(DealDamage(60),)),),
    },
    # ---- WCS2017 4位 グソクムシャGX/ダストダス(Sho Sasaki選手) ----
    "sm2-115": {  # ジジーロンGX(Drampa-GX)
        "Righteous Edge": (DealDamage(20), DiscardOpponentActiveSpecialEnergy()),
        "Berserk": (DamageIfOwnBenchedPokemonDamaged(80, 70),),
        "Big Wheel-GX": (ShuffleHandIntoDeckThenDraw(10),),
    },
    "xy11-75": {  # マギアナEX(Magearna-EX)
        # 特性「Mystic Heart」(鋼エネルギーがついた自分のポケモンへの、ダメージ以外の効果を防ぐ)は
        # 対象条件つきの広範な防御効果のため未実装(v1簡略版)。
        # 「Soul Blaster」はv1簡略版: 次の自分の番の基本ダメージが下がる制約は未対応(常に120ダメージ)。
        "Soul Blaster": (DealDamageWithSelfDebuffNextTurn(base_amount=120, debuff_amount=60),),
    },
    # ---- WCS2017 5位 ダストダス/ネクロズマGX(Reiji Nishiguchi選手) ----
    "xy9-52": {  # エーフィEX(Espeon-EX)
        "Miraculous Shine": (DevolveAllOpponentEvolvedPokemon(),),
        "Psyshock": (DealDamageIgnoringAllDefenderEffects(70),),
    },
    "xy12-51": {  # ミュウツー(Mewtwo、Evolutions版)
        "Psychic": (DamagePerOpponentActiveEnergyCount(20, 20),),
        # 「Barrier」はv1簡略版: 自分の番に連続使用できない制約は未対応(ApplyShieldToSelfは
        # 毎回使用可能な扱い)。
        "Barrier": (ApplyShieldToSelf(),),
    },
    # ---- WCS2016 優勝 メガタブンネEX(Shintaro Ito選手) ----
    "xy10-85": {  # メガタブンネEX(M Audino-EX)
        # メガシンカのルール(進化した番はそこで終了する)はv1簡略版として未対応(通常の進化と同様に扱う)。
        "Magical Symphony": (DamageWithSupporterBonusToChosenOpponentBench(110, 50),),
    },
    "xy10-84": {  # タブンネEX(Audino-EX)
        "Drain Slap": (DealDamage(20), HealSelf(20)),
        "Do the Wave": (DamagePerOwnBenchedPokemonCount(60, 10),),
    },
    "xy6-77": {  # シェイミEX(Shaymin-EX)
        # 特性「Set Up」(ベンチに出したとき、手札が6枚になるまで引いてもよい)はENTER_BENCH_TRIGGER_EFFECTS経由で対応済み。
        "Sky Return": (DealDamage(30), ReturnSelfToHandUnconditional()),
    },
    "xy7-36": {  # フーパEX(Hoopa-EX)
        # 特性「Scoundrel Ring」(ベンチに出したとき、してもよい)はENTER_BENCH_TRIGGER_EFFECTS経由で対応済み。
        "Hyperspace Fury": (DiscardOwnEnergy(2), DealDamageToChosenOpponentPokemon(100)),
    },
    "xy11-74": {  # コバルオン(Cobalion)
        "Quick Guard": (ApplyScopedDamageImmunityToSelf("basic"), LockOwnAttackNextTurn("Quick Guard")),
        "Revenge Blast": (DamagePerOpponentActualPrizesTaken(30, 30),),
    },
    "xy6-40": {  # アブソル(Absol)
        # 特性「Cursed Eyes」(相手の場のポケモン間でダメカンを移動させる)は対象選択が2段階必要な
        # 複雑な効果のため未実装(v1簡略版)。
        "Mach Claw": (DealDamageIgnoringResistance(30),),
    },
    # ---- WCS2016 2位 ゲッコウガBREAK(Cody Walinski選手) ----
    "xy11-96": {  # ファイアロー(Talonflame)
        # 特性「Gale Wings」(対戦準備でたねポケモンでなくてもバトルポケモンにできる)は
        # legal_actions._can_be_initial_activeで対応済み(発動アクションを持たないため登録しない)。
        "Aero Blitz": (DealDamage(40), SearchDeckAnyCardToHand(2)),
    },
    "xy9-38": {  # ケロマツ(Froakie)
        "Bubble": (FlipCoinThen(heads=(InflictStatusOnDefender("paralyzed"),)),),
    },
    "xy9-39": {  # ゲコガシラ(Frogadier)
        "Water Duplicates": (SearchDeckForNamedPokemonToBench("Frogadier", 3),),
    },
    "xy9-40": {  # ゲッコウガ(Greninja)
        "Shadow Stitching": (DealDamage(40), BlockOpponentAbilitiesUntilTurnEnds()),
        "Moonlight Slash": (DamageWithOptionalEnergyReturnBonus(60, 20, "Water"),),
    },
    "xy9-41": {  # ゲッコウガBREAK(Greninja BREAK)
        # BREAK進化ルールによりゲッコウガのワザをそのまま引き継ぐ(legal_actions/rules_engineの
        # BREAKカード用フォールバック経由)。効果本体はここにも同じ内容を登録する。
        "Shadow Stitching": (DealDamage(40), BlockOpponentAbilitiesUntilTurnEnds()),
        "Moonlight Slash": (DamageWithOptionalEnergyReturnBonus(60, 20, "Water"),),
        # 特性「Giant Water Shuriken」(バトル場にいるとき、してもよい)はABILITY_EFFECTS経由で対応済み。
    },
    "xy1-41": {  # ゲッコウガ(Greninja、XY版)
        # v1簡略版: 「相手のバトルポケモンへの他の効果の影響を受けない」部分は未対応(弱点・抵抗力無視のみ対応)。
        "Mist Slash": (DealDamageIgnoringWeaknessResistance(50, ignore_defender_effects=True),),  # 実カードテキスト: 弱点・抵抗力・その他の効果すべてを計算しない
    },
    # ---- WCS2016 3位 ラフレシアトゥールボックス(Samuel Hough選手) ----
    "xy7-1": {  # ナゾノクサ(Oddish)
        "Trip Over": (FlipCoinThen(heads=(DealDamage(20),), tails=(DealDamage(10),)),),
    },
    "xy7-2": {  # クサイハナ(Gloom)
        "Drool": (DealDamage(20),),
    },
    "xy7-3": {  # ラフレシア(Vileplume)
        # 特性「Irritating Pollen」(場に出ている間、両者ともグッズが使えない)は常時効果のため
        # engine/continuous.py の items_blocked_by_vileplume 経由で対応済み(ABILITY_EFFECTSには登録しない)。
        "Solar Beam": (DealDamage(70),),
    },
    "g1-28": {  # サンダースEX(Jolteon-EX)
        "Swift": (DealDamageIgnoringWeaknessResistance(30, ignore_defender_effects=True),),  # 実カードテキスト: 弱点・抵抗力・その他の効果すべてを計算しない
        "Flash Ray": (DealDamage(70), ApplyScopedDamageImmunityToSelf("basic")),
    },
    "xy10-20": {  # グレイシアEX(Glaceon-EX)
        "Second Bite": (DamagePerDefenderDamageCounters(20, 10),),
        "Crystal Ray": (DealDamage(70), ApplyScopedDamageImmunityToSelf("evolution")),
    },
    "xy4-65": {  # ギルガルドEX(Aegislash-EX)
        # 特性「Mighty Shield」(特殊エネルギーがついた相手のポケモンからのダメージを受けない)は常時効果のため
        # effects/primitives.py の _FULL_DAMAGE_IMMUNITY_VS_ATTACKER_SPECIAL_ENERGY 経由で対応済み。
        "Slash Blast": (DamagePerSelfEnergyOfType(40, 20, "Metal"),),
    },
    "xy1-79": {  # イベルタルEX(Yveltal-EX)
        "Evil Ball": (DamagePerBothActiveEnergyCount(20, 20),),
        "Y Cyclone": (DealDamage(90), MoveEnergyBetweenOwnPokemon()),
    },
    "xy5-19": {  # オーロットEX(Trevenant-EX)
        "Dark Forest": (DealDamage(20), DisableDefenderRetreatNextTurn()),
        "Wood Blast": (DamagePerSelfEnergyOfType(50, 20, "Grass"),),
    },
    # ---- WCS2016 4位 ビークイン/イベルタル(Ross Cawthon選手) ----
    "xy7-9": {  # ミツハニー(Combee)
        "Bug Bite": (DealDamage(10),),
    },
    "xy7-10": {  # ビークイン(Vespiquen)
        "Intelligence Gathering": (DealDamage(10), DrawUpTo(6)),
        "Bee Revenge": (DamagePerOwnDiscardPokemonCount(20, 10),),
    },
    "xy7-30": {  # アンノーン(Unown)
        # 特性「Farewell Letter」(ベンチにいるとき、してもよい)はABILITY_EFFECTS経由で対応済み。
        "Hidden Power": (DealDamage(10),),
    },
    "xy11-65": {  # イベルタル(Yveltal、通常版)
        "Oblivion Wing": (DealDamage(30), AttachEnergyFromDiscardToOwnPokemon(energy_type="Darkness", count=1, bench_only=True)),
        # 実カードテキスト: "...if tails, this Pokemon can't attack during your next turn."
        # (プレイヤー単位のLockSelfAttackNextTurnは誤りだったため修正、2026-08-22)。
        "Darkness Blade": (
            DealDamage(100),
            FlipCoinThen(tails=(LockOwnAttackNextTurn("Darkness Blade", lock_all_attacks=True),)),
        ),
    },
    "xy4-58": {  # カラマネロEX(Malamar-EX)
        # 特性「Hyper Hypnosis」(手札からエネルギーをつけたとき、してもよい)はENERGY_ATTACH_TRIGGER_EFFECTS経由で対応済み。
        "MAXamar": (DamagePerHeadsAmongEnergyCount(60),),
    },
    "xy2-70": {  # クリムガン(Druddigon)
        "Revenge": (DamageIfOwnPokemonKnockedOutLastOpponentTurn(20, 70),),
        "Dragon Claw": (DealDamage(80),),
    },
    # ---- WCS2015 優勝 カメックス(Jacob Van Wagner選手) ----
    "bw10-16": {  # カメックス(Blastoise)
        # 特性「Deluge」(1回の自分の番に何度でも手札からみずエネルギーをつけられる)は
        # rules_engine._UNLIMITED_PER_TURN_ABILITY_CARD_IDS経由で対応済み。
        "Hydro Pump": (DamagePerSelfEnergyOfType(60, 10, "Water"),),
    },
    "bw7-49": {  # ケルディオEX(Keldeo-EX)
        # 特性「Rush In」(ベンチにいるとき、してもよい)はABILITY_EFFECTS経由で対応済み。
        "Secret Sword": (DamagePerSelfEnergyOfType(50, 20, "Water"),),
    },
    "bw10-60": {  # ジラーチEX(Jirachi-EX)
        # 特性「Stellar Guidance」(ベンチに出したとき、してもよい)はENTER_BENCH_TRIGGER_EFFECTS経由で対応済み。
        "Hypnostrike": (DealDamage(60), InflictStatusOnDefender("asleep"), InflictStatusOnSelf("asleep")),
    },
    "xy6-1": {  # タマタマ(Exeggcute)
        # 「Loathe」はv1簡略版: コイントスのみ対応、ベンチとの入れ替え先選択は未対応(実質常に不発)。
        "Loathe": (FlipCoinThen(heads=(SwitchActiveWithBench(),)),),
        "Ram": (DealDamage(10),),
    },
    "xy6-16": {  # フリーザー(Articuno)
        "Find Ice": (SearchDeckForBasicEnergyToHand(3, energy_type="Water"),),
        "Freezing Wind": (DealDamage(100),),
    },
    "bw11-54": {  # ミュウツーEX(Mewtwo-EX)
        "X Ball": (DamagePerBothActiveEnergyCount(0, 20),),
        "Psydrive": (DealDamage(120), DiscardOwnEnergy(1)),
    },
    "xy5-38": {  # ホエルオーEX(Wailord-EX)
        # 特性「Water Veil」(手札からエネルギーをつけたとき発動)はMANDATORY_ENERGY_ATTACH_TRIGGER_EFFECTS経由で対応済み。
        "High Breaching": (DealDamage(120), InflictStatusOnSelf("asleep")),
    },
    # ---- WCS2015 2位 ガマゲロゲEX/クロバット(Mees Brenninkmeijer選手) ----
    "bw8-53": {  # ズバット(Zubat)
        # 特性「Free Flight」(エネルギーがついていなければにげるコスト0)はengine.energy経由で対応済み。
        "Wing Attack": (DealDamage(20),),
    },
    "xy4-32": {  # ゴルバット(Golbat)
        # 特性「Sneaky Bite」(手札から進化させて出したとき、してもよい)はEVOLVE_TRIGGER_EFFECTS経由で対応済み。
        "Swoop Across": (DealDamageToAllOpponentPokemon(10),),
    },
    "xy4-33": {  # クロバット(Crobat)
        # 特性「Surprise Bite」(手札から進化させて出したとき、してもよい)はEVOLVE_TRIGGER_EFFECTS経由で対応済み。
        "Skill Dive": (DealDamageToChosenOpponentPokemon(30),),
    },
    "xy3-20": {  # ガマゲロゲEX(Seismitoad-EX)
        "Quaking Punch": (DealDamage(30), LockOpponentItemsNextTurn()),
        "Grenade Hammer": (
            DealDamage(130),
            DistributeDamageCountersFreely(
                0, bench_only=True, max_per_target=3, target_own_side=True, exactly=True, target_count=2
            ),
        ),
    },
    # ---- WCS2015 4位 ナイトマーチ(Merlin Quittek選手) ----
    "xy4-26": {  # バチュル(Joltik)
        "Gnaw": (DealDamage(10),),
        "Night March": (DamagePerOwnDiscardPokemonWithAttackName("Night March", 20),),
    },
    "xy4-44": {  # バケッチャ(Pumpkaboo)
        "Ram": (DealDamage(10),),
        "Night March": (DamagePerOwnDiscardPokemonWithAttackName("Night March", 20),),
    },
    "xy4-42": {  # ランプラー(Lampent)
        "Cursed Drop": (DistributeDamageCountersFreely(3),),
        "Night March": (DamagePerOwnDiscardPokemonWithAttackName("Night March", 20),),
    },
    "xyp-XY126": {  # ミュウEX(Mew-EX)
        # 特性「Versatile」(場のポケモンのワザを自分・相手問わず使える)はlegal_actions.
        # _versatile_attack_actions経由で対応済み。
        "Replace": (ChooseSourceThenMoveEnergyFreely(),),
    },
    # ---- WCS2015 5位 オーロット/ゲンガーEX(Sean Foisy選手) ----
    "xy1-54": {  # ボクレー(Phantump)
        "Astonish": (RandomOpponentHandCardToDeck(),),
        "Hook": (DealDamage(30),),
    },
    "xy1-55": {  # オーロット(Trevenant)
        # 特性「Forest's Curse」(バトル場にいる間、相手はグッズを使えない)は
        # engine.continuous.items_blocked_by_active_trevenant経由で対応済み(発動アクションを持たない常時効果)。
        "Tree Slam": (DealDamage(60), DealDamageToChosenOpponentPokemonMulti(2, 20)),
    },
    "xy4-34": {  # ゲンガーEX(Gengar-EX)
        "Night Attack": (DamageCounterOnChosenOpponentPokemon(3),),
        # v1簡略版: 「Dark Corridor」の本来は強制交代だが、bw8-72「Spinning Turn」と同様に
        # 「してもよい」トリガー機構を流用し任意交代として対応(強制フローは未整備)。
        "Dark Corridor": (DealDamage(60), InflictStatusOnDefender("poisoned")),
    },
    # ---- WCS2015 7位 ドンファン(Simon Narode選手) ----
    "bw8-71": {  # ゴマゾウ(Phanpy)
        "Tackle": (DealDamage(10),),
        "Rollout": (DealDamage(50),),
    },
    "bw8-72": {  # ドンファン(Donphan)
        # v1簡略版: 「Spinning Turn」の本来は強制交代だが、既存の「してもよい」トリガー機構
        # (AFTER_ATTACK_TRIGGER_EFFECTS)を流用し任意交代として対応(強制フローは未整備、常に交代したい
        # 場面が多いため実質的な影響は小さい)。
        "Spinning Turn": (DealDamage(40),),
        "Wreck": (DealDamage(80), DamageIfStadiumInPlay(60), DiscardStadiumInPlay()),
    },
    "xy3-63": {  # ルチャブル(Hawlucha)
        # 特性「Shining Spirit」(このポケモンのワザは弱点・抵抗力の影響を受けない)は、
        # ワザ側でDamageIfDefenderHasSubtypeIgnoringWeaknessResistanceを使うことで対応済み
        # (このポケモンの唯一のワザにのみ影響するため、ABILITY_EFFECTSへの登録は不要)。
        "Flying Press": (DamageIfDefenderHasSubtypeIgnoringWeaknessResistance(60, "EX"),),
    },
    "xy5-120": {  # ホルビー(Bunnelby)
        "Trip Over": (FlipCoinThen(heads=(DealDamage(40),), tails=(DealDamage(10),)),),
    },
    "xy5-121": {  # ホルビー(Bunnelby、PRC/121)
        # 特性「Omega Barrage」(このポケモンは1ターンに2回ワザを使ってよい。最初のワザで相手の
        # バトルポケモンをきぜつさせた場合、相手が新しいバトルポケモンを選んだ後、もう一度ワザを
        # 使ってよい)はengine.continuous.attack_twice_eligible + engine.rules_engine.
        # _finish_attack_or_offer_second経由で対応済み。
        "Burrow": (DiscardTopOfOpponentDeck(1),),
        "Rototiller": (ShuffleDiscardIntoDeck(1),),
    },
    # ---- WCS2015 8位 フレフワン/ガマゲロゲ(Tito Santoso選手) ----
    "xy2-67": {  # シュシュプ(Spritzee、Flashfire版)
        "Fairy Wind": (DealDamage(10),),
        "Fickle Attack": (FlipCoinThen(heads=(DealDamage(30),)),),
    },
    "bw8-93": {  # コバルオンEX(Cobalion-EX)
        "Righteous Edge": (DealDamage(30), DiscardChosenOpponentSpecialEnergy()),
        "Steel Bullet": (DealDamageIgnoringWeaknessResistance(100, ignore_defender_effects=True),),  # 実カードテキスト: 弱点・抵抗力・その他の効果すべてを計算しない
    },
    "xy2-11": {  # リザードンEX(Charizard-EX、Flashfire版)
        "Stoke": (FlipCoinThen(heads=(SearchDeckForBasicEnergyAttachToTarget(3),)),),
        "Fire Blast": (DealDamage(120), DiscardOwnEnergy(1)),
    },
    "xy2-12": {  # リザードンEX(Charizard-EX、Flashfire版 FLF/12)
        "Wing Attack": (DealDamage(60),),
        "Combustion Blast": (DealDamage(150), LockOwnAttackNextTurn("Combustion Blast")),
    },
    "xy4-23": {  # ライボルトEX(Manectric-EX)
        "Overrun": (DealDamage(20), DealDamageToChosenOpponentPokemonMulti(1, 20)),
        "Assault Laser": (DamageIfDefenderHasTool(60, 60),),
    },
    "xy4-24": {  # MライボルトEX(M Manectric-EX)
        "Turbo Bolt": (DealDamage(110), AttachEnergyFromDiscardToOwnPokemon(energy_type=None, count=2, bench_only=True)),
    },
    # ---- WCS2014 優勝 ビリジオンEX/ゲノセクトEX(Andrew Estrada選手) ----
    "bw10-9": {  # ビリジオンEX(Virizion-EX)
        # 特性「Verdant Wind」(くさエネルギーがついていれば特殊状態にならない)は
        # effects.primitives._defender_blocks_non_damage_effects経由で対応済み。
        "Emerald Slash": (SearchDeckAndAttachEnergy(energy_type="Grass", count=2, self_only=False, bench_only=True),),
    },
    "bw10-11": {  # ゲノセクトEX(Genesect-EX)
        # 特性「Red Signal」(手札からプラズマエネルギーをつけたとき、してもよい)はENERGY_ATTACH_TRIGGER_EFFECTS
        # 経由で対応済み(プラズマエネルギー限定の条件はrules_engine._handle_attach_energyでゲート)。
        "Megalo Cannon": (DealDamage(100), DealBonusDamageToChosenOpponentBench(20)),
    },
    "bw9-47": {  # バリヤード(Mr. Mime)
        # 特性「Bench Barrier」(自分のベンチはワザのダメージを受けない)は
        # effects.primitives._apply_continuous_damage_modifiers経由で対応済み(ワザ由来のダメージのみ)。
        "Psy Bolt": (DealDamage(20), FlipCoinThen(heads=(InflictStatusOnDefender("paralyzed"),))),
    },
    # ---- WCS2014 2位 ビリジオンEX/ゲノセクトEX(Igor Costa選手) ----
    "bw6-50": {  # フワンテ(Drifloon)
        "Beat": (DealDamage(10),),
        "Gust": (DealDamage(20),),
    },
    "bw6-51": {  # フワライド(Drifblim)
        "Shadow Steal": (DamagePerOpponentDiscardSpecialEnergyCount(50),),
        "Plentiful Placement": (DamageCounterOnChosenOpponentPokemon(4),),
    },
    # ---- WCS2014 3位 フレフワン/ガルーラEX(Michikazu Tsuda選手) ----
    "xy1-92": {  # シュシュプ(Spritzee)
        "Sweet Scent": (HealTarget(20),),
        "Flop": (DealDamage(20),),
    },
    # ---- WCS2014 4位 ビリジオンEX/ゲノセクトEX(Paulo Silva選手) ----
    # (ポケモンは優勝/2位デッキと共通のため新規登録なし)
    # ---- WCS2014 6位 イベルタル/ダストダス(Chase Moloney選手) ----
    # (イベルタルEXは既にxy1-79として登録済みのため新規登録なし)
    "bw11-88": {  # ダークライEX(Darkrai-EX)
        # 特性「Dark Cloak」(悪エネルギーがついている自分のポケモンはにげるコスト0)は
        # engine.energy.has_dark_cloak_in_play経由で対応済み(発動アクションを持たないため登録しない)。
        "Night Spear": (DealDamage(90), DealDamageToChosenOpponentPokemonMulti(1, 30)),
    },
    "bw5-62": {  # ヤミラミ(Sableye)
        "Confuse Ray": (DealDamage(10), FlipCoinThen(heads=(InflictStatusOnDefender("confused"),))),
        "Junk Hunt": (SearchDiscardForItemToHand(2),),
    },
    "bw8-65": {  # ヤブクロン(Trubbish)
        "Tool Drop": (DamagePerToolInPlayBothSides(20),),
    },
    "bw11-68": {  # ダストダス(Garbodor、Legendary Treasures版)
        # 特性「Garbotoxin」はengine.continuous.abilities_blocked_by_garbotoxin経由で対応済み
        # (xy9-57と同じ仕組みをGARBOTOXIN_CARD_IDSに追加しているだけ、発動アクションを持たないため登録しない)。
        "Sludge Toss": (DealDamage(60),),
    },
    "bw10-52": {  # ダゲキ(Sawk)
        "Kick of Righteousness": (DamageIfDefenderHasSubtype(10, 40, "Team Plasma"),),
        "Low Sweep": (DealDamage(60),),
    },
    # ---- WCS2014 7位 プラズマルギア/デオキシス(Vincent Azzolin選手) ----
    "bw9-53": {  # デオキシスEX(Deoxys-EX)
        # 特性「Power Connect」(自分のNプラズマ団ポケモンのワザ+10、デオキシスEX自身を除く)は
        # engine.continuous.team_plasma_power_connect_bonus_damage経由で対応済み(発動アクションを
        # 持たないため登録しない)。
        "Helix Force": (
            DamagePerDefenderEnergyCountIfSelfHasEnergyId(base=30, per_energy=30, required_energy_id=_PLASMA_ENERGY_ID),
        ),
    },
    "bw9-38": {  # ボルトロスEX(Thundurus-EX)
        "Raiden Knuckle": (
            DealDamage(30),
            AttachEnergyFromDiscardToOwnPokemon(energy_type=None, count=1, bench_only=True, target_subtype="Team Plasma"),
        ),
        "Thunderous Noise": (
            DealDamage(90),
            DiscardOpponentActiveEnergyIfSelfHasEnergyId(required_energy_id=_PLASMA_ENERGY_ID),
        ),
    },
    "bw11-102": {  # ルギアEX(Lugia-EX)
        # 特性「Overflow」(このポケモンのワザできぜつさせたらサイドを1枚多く取れる)は
        # 両方のワザにBonusPrizeIfThisAttackKnockedOutOpponent()を追加する形で対応。
        # 実カードテキスト: "Discard a Plasma Energy attached to this Pokémon. If you can't discard a Plasma
        # Energy, this attack does nothing."(以前は任意のエネルギーを1枚捨てるだけで、プラズマエネルギーが
        # ついていなくてもダメージが出ていた誤りを訂正、2026-10-06)
        "Plasma Gale": (
            DiscardOwnSpecificEnergyThenDealDamage(120, _PLASMA_ENERGY_ID),
            BonusPrizeIfThisAttackKnockedOutOpponent(),
        ),
    },
    "bw9-31": {  # キュレム(Kyurem)
        "Frost Spear": (DealDamage(30), DealDamageToChosenOpponentPokemonMulti(1, 30)),
        # 実カードテキスト: "This Pokemon can't attack during your next turn."(プレイヤー単位の
        # LockSelfAttackNextTurnは誤りだったため修正、2026-08-22)。
        "Blizzard Burn": (DealDamage(120), LockOwnAttackNextTurn("Blizzard Burn", lock_all_attacks=True)),
    },
    # ---- WCS2014 8位 ビリジオンEX/ゲノセクトEX(Goncalo Pereira選手) ----
    "bw10-66": {  # パルキアEX(Palkia-EX)
        # 「Strafe」のワザ後「自分のベンチと入れ替えてもよい」はAFTER_ATTACK_TRIGGER_EFFECTS経由で対応済み。
        "Strafe": (DealDamage(50),),
        "Dimension Heal": (DealDamage(80), HealSelfPerAttachedEnergyId(_PLASMA_ENERGY_ID, 20)),
    },
    "xy1-93": {  # フレフワン(Aromatisse)
        "Fairy Wind": (DealDamage(60),),
    },
    "xy2-78": {  # ガルーラEX(Kangaskhan-EX)
        "Triple Draw": (Draw(3),),
        "Kindred Kick": (DealDamageWithCoinFlipBonus(70, 30),),
    },
    "xy2-79": {  # MガルーラEX(M Kangaskhan-EX)
        "Wham Bam Punch": (DealDamageFlipUntilTailsBonus(100, 30),),
    },
    "xy1-97": {  # ゼルネアスEX(Xerneas-EX)
        "Break Through": (DealDamage(60), DealBonusDamageToChosenOpponentBench(30)),
        "X Blast": (DealDamage(140), LockOwnAttackNextTurn("X Blast")),
    },
    "xy1-96": {  # ゼルネアス(Xerneas)
        "Geomancy": (ChooseOwnBenchThenSearchEnergyAttach(2, "Fairy"),),
        "Rainbow Spear": (DealDamage(100), DiscardOwnEnergy(1)),
    },
    "bw10-20": {  # スイクン(Suicune)
        # 特性「Safeguard」(相手のEXポケモンからのワザの効果を一切受けない)は
        # effects.primitives._apply_continuous_damage_modifiers / _defender_blocks_non_damage_effects経由で対応済み。
        "Aurora Beam": (DealDamage(70),),
    },
    # ---- どうぐ自体にワザが印刷されているカード(legal_actions._tool_granted_attack_actions経由で使用可能) ----
    "sv4-178": {  # わざマシン エヴォリューション(Technical Machine: Evolution)
        # ベンチ最大2体を選び、それぞれ山札から進化先を探して直接進化させる。進化先候補が
        # 複数種類あるときはプレイヤーが選ぶ(InstantEvolveEachTargetFromDeck)。
        # ついた番の終わりにトラッシュされる処理はEND_OF_TURN_DISCARD_TOOL_IDS経由で対応済み。
        "Evolution": (ChooseOwnBenchThenInstantEvolveFromDeck(2),),
    },
    "sv4-177": {  # わざマシン ふるいもどし(Technical Machine: Devolution)
        "Devolution": (DevolveAllOpponentEvolvedPokemon(),),
    },
    "sv4-179": {  # わざマシン エナジーターボ(Technical Machine: Turbo Energize)
        "Turbo Energize": (SearchDeckForBasicEnergyAttachFreely(2, bench_only=True),),
    },
    "bw10-92": {  # Gブースター(G Booster)
        # 実カードテキスト: "This attack's damage isn't affected by any effects on the Defending Pokémon."
        # (弱点・抵抗力は効果ではないので通常通り適用される。以前は弱点・抵抗力を無視する誤りだった)
        "G Booster": (DealDamageIgnoringDefenderShieldAndReduction(200), DiscardOwnEnergy(2)),
    },
    # ---- 2026年 PJCS2026/CL2026各地 サンプルデッキ追加分 ----
    "sv9-120": {  # ノコッチ(Dunsparce)
        "Trading Places": (SwitchActiveWithBench(),),
        "Ram": (DealDamage(20),),
    },
    "sv8pt5-80": {  # ノココッチ(Dudunsparce、非ex版)
        "Land Crush": (DealDamage(90),),
    },
    "sv9-121": {  # ノココッチex(Dudunsparce ex)
        "Destructive Drill": (DealDamageIgnoringAllDefenderEffects(150),),
        "Tenacious Tail": (DealDamagePerOpponentPokemonWithSubtype(per_pokemon=60, subtype="ex"),),
    },
    "sv10-40": {  # アチャモ(Torchic)
        "Collect": (Draw(1),),
        "Combustion": (DealDamage(10),),
    },
    "sv9-23": {  # ワカシャモ(Combusken)
        "Slash": (DealDamage(50),),
    },
    "sv9-24": {  # バシャーモex(Blaziken ex)
        # 実カードテキスト: "During your next turn, this Pokémon can't attack."(以前はこの自己
        # ロックが未登録で、Nのゼクロムと同じパターンのバグだった、2026-08-21発覚)。
        "Smolder-sault": (DealDamage(200), LockOwnAttackNextTurn("Smolder-sault", lock_all_attacks=True)),
    },
    "me2pt5-9": {  # ベイリーフ(Bayleef)
        "Leaf Step": (DealDamage(60),),
    },
    "me1-10": {  # メガニウム(Meganium、メガ進化前の通常版)
        "Solar Beam": (DealDamage(140),),
    },
    "me1-104": {  # メガガルーラex(Mega Kangaskhan ex)
        "Rapid-Fire Combo": (DealDamageFlipUntilTailsBonus(base=200, bonus_per_heads=50),),
    },
    "me2-14": {  # ファイヤー(Moltres、通常版)
        "Fighting Wings": (DamageIfDefenderHasSubtype(base=20, bonus=90, subtype="ex"),),
    },
    "sv8pt5-54": {  # ガチグマアカツキ(Bloodmoon Ursaluna、ex表記なし通常版)
        "Mad Bite": (DamagePerDefenderDamageCounters(base=100, per_counter=30),),
    },
    "me1-54": {  # ケーシィ(Abra)
        "Teleportation Attack": (DealDamage(10), SwitchActiveWithBench()),
    },
    "me1-55": {  # ユンゲラー(Kadabra)
        "Super Psy Bolt": (DealDamage(30),),
    },
    "me2pt5-46": {  # ユキワラシ(Snorunt)
        "Chilly": (DealDamage(10),),
    },
    "sv6-53": {  # ユキメノコ(Froslass、メガex以外の通常版)
        "Frost Smash": (DealDamage(60),),
    },
    "me1-12": {  # セレビィ(Celebi)
        "Traverse Time": (
            SearchDeckMultiCriteria(("grass_pokemon_or_stadium", "grass_pokemon_or_stadium", "grass_pokemon_or_stadium")),
        ),
        "Solar Cutter": (DealDamage(30),),
    },
    "me3-62": {  # ニャースex(Meowth ex)
        "Tuck Tail": (DealDamage(60), ReturnSelfToHandUnconditional()),
    },
    "zsv10pt5-51": {  # イシズマイ(Dwebble)
        "Flail": (DamagePerSelfDamageCounters(10),),
        "Dig Claws": (DealDamage(20),),
    },
    "zsv10pt5-52": {  # イワパレス(Crustle)
        "Stone Edge": (DealDamageWithCoinFlipBonus(base=80, bonus=60),),
    },
    "me5-33": {  # カゲボウズ(Pitch Black)
        "Hang Down": (DealDamage(10),),
    },
    "me5-34": {  # ジュペッタ(Pitch Black)
        "Puppet Pull": (DealDamage(80), SearchDeckAnyCardToHand(count=1)),
    },
    "me5-29": {  # ヤドン(Pitch Black、通常版)
        "All-You-Can-Yeet": (DiscardAnyHandCardsOptional(),),
        "Headbutt": (DealDamage(20),),
    },
    "sv8-75": {  # ムチュール(Smoochum)。実カードテキスト(公式サイトの生HTMLで確認): "自分の山札から
        # 「基本<span class="icon-psychic icon"></span>エネルギー」を2枚まで選び、ベンチポケモン1匹に
        # つける。そして山札を切る。" — テキスト抽出(WebFetch等)だとこのicon-psychicスパンが
        # 消えて「基本エネルギー」(タイプ不問)に見えるが、実際は超タイプ限定(ワンダーパッチ(mbd-15)と
        # 同じ失敗パターン。cardrush.media等の非公式サイトでも「基本[超]エネルギー」と裏取り済み)。
        # 対象はベンチポケモン限定(バトル場の自分自身にはつけられない)。
        "Delightful Kiss": (SearchDeckForBasicEnergyAttachToTarget(count=2, energy_type="Psychic", self_only=False, bench_only=True),),
    },
    "sv8pt5-27": {  # オーガポン いどのめんex(Wellspring Mask Ogerpon ex、sv6-64と同一テキスト)
        "Sob": (DealDamage(20), DisableDefenderRetreatNextTurn()),
        "Torrential Pump": (
            DealDamage(100),
            ChooseOwnAttachedEnergyThenShuffleForBonusBenchDamage(energy_count=3, bonus_amount=120),
        ),
    },
    "me2pt5-10": {  # メガメガニウムex(Mega Meganium ex)
        "Giant Bouquet": (DamagePerSelfEnergyOfType(base=70, per_energy=50, energy_type="Grass"),),
    },
    "me3-3": {  # シェイミ(Shaymin)
        "Leaf Step": (DealDamage(30),),
        "Send Flowers": (
            SearchDeckAndAttachEnergy(energy_type=None, count=1, self_only=False, bench_only=True, target_type="Grass", any_energy=True),
        ),
    },
    "me5-41": {  # コノヨザル(Pitch Black)
        "Ghostly Blow": (DealDamage(100), DealBonusDamageToChosenOpponentBench(amount=50)),
    },
    "me5-5": {  # チャデス(Poltchageist)
        # 実カードテキスト: "Place 1 damage counter on your opponent's Active Pokemon."
        # (対象選択の余地は無い固定ターゲット。DamageCounterOnChosenOpponentPokemonだと誤って
        # ベンチも選べてしまうバグだったため、DamageCounterOnDefenderに変更、2026-08-22)。
        "Furtive Drop": (DamageCounterOnDefender(count=1),),
    },
    "sv8-momowarou": {  # モモワロウ(Pecharunt、SV8超電ブレイカー版)
        "ポイズンチェーン": (DealDamage(10), InflictStatusOnDefender("poisoned"), DisableDefenderRetreatNextTurn()),
    },
    "sv5a-18": {  # イーユイ(Chi-Yu、SV5a版)
        "ひきつける": (Draw(2),),
        "グラウンドメルト": (DealDamageBonusIfStadiumInPlayThenDiscardIt(base=60, bonus=60),),
    },
    "mc-481": {  # イベルタル(Yveltal、MC481/742・スタートデッキ100 バトルコレクション版)
        "わしづかみ": (DealDamage(20), DisableDefenderRetreatNextTurn()),
        "ダークフェザー": (DealDamage(110),),
    },
    "m2a-012": {  # シェイミ(Shaymin、M2a012/193)
        # 特性「はなのカーテン」(ルール箱を持つポケモンを除く自分のベンチはワザのダメージを受けない)は
        # effects.primitives._BENCH_BARRIER_EXCLUDING_RULE_BOX_ID経由で対応済み。
        "けとばす": (DealDamage(30),),
    },
    "sv10-19": {  # ワカシャモ(Combusken、SV10019/098)
        "かえん": (DealDamage(20),),
        "にどげり": (DealDamagePerHeads(coin_count=2, damage_per_heads=40),),
    },
    "m1l-1": {  # フシギダネ(Bulbasaur、M1L001/063)
        "しばりつける": (DealDamage(10), DisableDefenderRetreatNextTurn()),
    },
    "m1l-2": {  # フシギソウ(Ivysaur、M1L002/063)
        "はっぱカッター": (DealDamage(60),),
    },
    "m1s-4": {  # ベイリーフ(Bayleef、M1S004/063)
        "つきとばす": (DealDamage(50), ForceOpponentSwitchOpponentChooses()),
    },
    "sv7-38": {  # ヤドン(Slowpoke、SV7038/102)
        "しっぽをたらす": (SearchDiscardForPokemonToHand(count=1),),
        "たいあたり": (DealDamage(30),),
    },
    "sv7-39": {  # ヤドキング(Slowking、SV7039/102)
        "ひらめきチャレンジ": (DiscardTopOfOwnDeckThenUseItsAttack(),),
        "ちょうねんりき": (DealDamage(120),),
    },
    "sv8-62": {  # コノヨザル(Annihilape、SV8062/106)
        "あばれまわる": (DealDamage(130), InflictStatusOnSelf("confused")),
        "みちづれファイト": (KnockOutBothActivePokemon(),),
    },
    "sv8a-90": {  # イイネイヌ(Okidogi、SV8a090/187)
        # 特性「アドレナパワー」(悪エネルギーがついていれば最大HP+100・ワザダメージ+100)は
        # engine.continuous.adrena_power_bonus_damage/effective_max_hp経由で対応済み。
        "グッドパンチ": (DealDamage(70),),
    },
    "sv6a-40": {  # ゲノセクト(Genesect、SV6a040/064)
        # 特性「エースキャンセラー」(どうぐがついていれば相手のACE SPECを封じる)は
        # engine.legal_actions._ace_spec_locked_by_opponent経由(常時発動のためABILITY_EFFECTSには
        # 登録しない)で対応済み。ただし「ポケモンのどうぐ」のACE SPECは現状該当カードが存在しないため未対応。
        "マグネブラスト": (DealDamage(100),),
    },
    "m2a-13": {  # イシズマイ(Dwebble、M2a013/193)
        "かくせい": (InstantEvolveSelfFromDeck(),),
    },
    "sv9a-67": {  # イワパレス(Crustle、SV9a067/063)
        # 特性「しんぴのいしやど」(相手のポケモンexからのワザダメージを受けない)は
        # effects.primitives._FULL_DAMAGE_IMMUNITY_VS_SUBTYPE経由で対応済み。
        "グレートシザー": (DealDamageIgnoringAllDefenderEffects(120),),
    },
    "m4-20": {  # ケロマツ(Froakie、M4020/083)
        "もってくる": (Draw(1),),
        "みずでっぽう": (DealDamage(10),),
    },
    "m4-21": {  # ゲコガシラ(Frogadier、M4021/083)
        "よびよせのじゅつ": (SearchDeckForPokemonToHand(count=3),),
        "アクアエッジ": (DealDamage(50),),
    },
    "sv5a-24": {  # ゲコガシラ(Frogadier、SV5a024/066)
        "しびれみず": (DealDamage(20), FlipCoinThen(heads=(InflictStatusOnDefender("paralyzed"),))),
    },
    "sv5a-45": {  # ゲッコウガex(Greninja ex、SV5a045/066、テラスタル闘タイプ版)
        # 実カードはテラスタルポケモンで、「このポケモンは、ベンチにいるかぎり、ワザのダメージを
        # 受けない。」というルール箱テキストを持つ(data/cache/cards.jsonのrulesフィールドには
        # 元々このテキストがあったが、subtypesに"Tera"が含まれていないデータ欠落があり見逃す
        # ところだった。2026-08-22にcards.json側のsubtypesを["Stage 2","ex","Tera"]に修正し、
        # effects.primitives._apply_defender_side_damage_modifiers内の"Tera" in
        # defender_card.subtypes判定で他のTeraカードと同様に対応済み)。
        "しのびのやいば": (DealDamage(170), SearchDeckAnyCardToHand(count=1)),
        "ぶんしんれんだ": (DiscardOwnEnergy(count=2), DealDamageToChosenOpponentPokemonMulti(count=2, amount=120)),
    },
    "sv8a-8": {  # カジッチュ(Applin、SV8a008/187)
        "しるをとばす": (DealDamage(20),),
    },
    "sv6-103": {  # カミッチュ(Dipplin、SV6103/101)
        # 特性「おまつりおんど」(お祭り会場(sv6-149)が場にあればワザを2回連続で使える)は
        # engine.continuous.attack_twice_eligible + engine.rules_engine._finish_attack_or_offer_second
        # 経由で対応済み。
        "ともだちのわ": (DamagePerOwnBenchedPokemonCount(base=0, per_pokemon=20),),
    },
    "mc-77": {  # テツノイサハex(Iron Boulder ex、MC077/742)
        # 特性「ラピッドバーニア」(手札からベンチに出したときバトルポケモンと入れ替え、
        # エネルギーを自由につけ替え)はENTER_BENCH_TRIGGER_EFFECTS経由で対応済み。
        # 実カードテキスト: "During your next turn, this Pokemon can't attack."(プレイヤー単位の
        # LockSelfAttackNextTurnは誤りだったため修正、2026-08-22)。
        "プリズムエッジ": (DealDamage(180), LockOwnAttackNextTurn("プリズムエッジ", lock_all_attacks=True)),
    },
    "m1s-3": {  # チコリータ(Chikorita、M1S003/063)
        "はっぱカッター": (DealDamage(20),),
    },
    "sv4pt5-8": {  # リザード(Charmeleon、PAF/8)
        # 特性「Flare Veil」(相手のワザのダメージ以外の効果を受けない)は
        # effects.primitives.NON_DAMAGE_EFFECT_IMMUNE_CARD_IDS経由で対応済み。
        "Combustion": (DealDamage(50),),
    },
    "sv3pt5-16": {  # ポッポ(Pidgey、MEW/16)
        "Call for Family": (SearchDeckForBasicPokemonToBench(count=2),),
        "Tackle": (DealDamage(20),),
    },
    "sv4-16": {  # ノノクラゲ(Toedscool、PAR/16)
        "Kick": (DealDamage(20),),
        "Absorb": (DealDamage(40), HealSelf(20)),
    },
    "sm6-50": {  # マーイーカ(Inkay、FLI/50)
        "Hypnosis": (InflictStatusOnDefender("asleep"),),
    },
    "sm6-51": {  # カラマネロ(Malamar、FLI/51)
        # 特性「Psychic Recharge」はABILITY_EFFECTSで対応済み。
        "Psychic Sphere": (DealDamage(60),),
    },
    "xyp-184": {  # ギラティナ(Giratina、XYP/184)
        # 特性「Devour Light」(全てのBREAKポケモンの特性を無効化)は
        # engine.continuous.abilities_blocked_by_giratina_devour_light経由(常時発動のため
        # ABILITY_EFFECTSには登録しない)で対応済み。
        "Shadow Claw": (DealDamage(110), DiscardRandomFromOpponentHand()),
    },
    "xy8-32": {  # テッポウオ(Remoraid、BKT/32)
        "Ion Pool": (DiscardStadiumInPlay(),),
        "Water Gun": (DealDamage(20),),
    },
    "sm5-114": {  # ヤレユータン(Oranguru、UPR/114)
        "Resource Management": (ChooseDiscardCardsToBottomOfDeck(3),),
        "Profound Knowledge": (DealDamage(60), InflictStatusOnDefender("confused")),
    },
    "bw9-4": {  # タマタマ(Exeggcute、PLF/4)
        # 特性「Propagation」(トラッシュにあれば手札に戻せる)はDISCARD_ABILITY_EFFECTS
        # (UseDiscardAbilityアクション)経由で対応済み。
        "Seed Bomb": (DealDamage(20),),
    },
    "xy6-17": {  # フリーザー(Articuno、ROS/17)
        # 特性「Δ Plus」(このポケモンのワザできぜつさせたらサイド追加1枚)は、パッシブ特性
        # (effects/generated_abilities.py: bonus_prize_on_ko)として処理される。
        "Chilling Sigh": (InflictStatusOnDefender("asleep"),),
        "Tri Edge": (FlipMultipleCoinsForBonusDamage(base=20, count=3, per_heads=40),),
    },
    "sm11-78": {  # ラティオスGX(Latios-GX、UNM/78、単体版)
        # 特性「Power Bind」(場に4匹以下ならワザが使えない)はengine.legal_actions.
        # _MIN_OWN_POKEMON_IN_PLAY_TO_ATTACK経由で対応済み。
        "Tag Purge": (DealDamage(120), ApplyScopedDamageImmunityToSelf("tag_team")),
        "Clear Vision-GX": (LockOpponentGXAttacksForRestOfGame(),),
    },
    "sm11-160": {  # アーゴヨンGX(Naganadel-GX、UNM/160)
        # 特性「Ultra Conversion」はABILITY_EFFECTSで対応済み。
        "Venom Shot": (DiscardOwnEnergy(count=2), DealDamageToChosenOpponentPokemon(170)),
        "Injection-GX": (MoveOpponentDiscardCardToTheirPrizes(),),
    },
    "smp-104": {  # ソルガレオGX(Solgaleo-GX、SMP/104)
        # 特性「Shining Mane」(自分のポケモン全員が弱点を持たない)は
        # effects.primitives._defender_card_with_field_weakness_overrides経由(常時発動のため
        # ABILITY_EFFECTSには登録しない)で対応済み。
        "Turbo Strike": (AttachEnergyFromDiscardToOwnPokemon(energy_type=None, count=2, bench_only=True),),
        "Prominence-GX": (HealAllOwnPokemon(),),
    },
    "me5-6": {  # ヤバソチャ(Sinistcha)
        "Matcha Spin": (DamageCountersOnAllOpponentPokemonIfOwnHideNSneakDiscardThreshold(threshold=6, counters=4),),
    },
    "me5-39": {  # ダダリン(Dhelmise)
        "Vengeful Anchor": (DealDamageBonusIfOwnHideNSneakDiscardThreshold(base=30, bonus=140, threshold=4),),
    },
    "m4-yungoos": {  # ミネズミ(Yungoos)
        "かみつく": (DealDamage(10),),
    },
    "me2pt5-18": {  # ロケット団のタマンチュラ(Team Rocket's Tarountula)
        "Take Down": (DealDamage(30), SelfDamage(10)),
    },
    "sv10a-9": {  # ロケット団のワナイダー(手動登録カード。カード名は日本語のまま登録しているため、
        # 英語の名前接頭辞チェックだけではこのポケモン自身を数えられない(英語版未確認のため name を
        # 英語化していない)。also_count_card_idsでこのカード自身を明示的に追加カウントすることで
        # 修正した(2026-08-22、以前は自分自身が場にいてもロケットラッシュのダメージが30少なかった)。
        "ロケットラッシュ": (
            DamagePerOwnPokemonWithNamePrefix(
                base=0, per_pokemon=30, name_prefix="Team Rocket's", also_count_card_ids=frozenset({"sv10a-9"})
            ),
        ),
    },
    "sv10-16": {  # カジッチュ(Applin)
        "Mini Drain": (DealDamage(10), HealSelf(10)),
    },
    "sv10-17": {  # カミッチュ(Dipplin)
        "Energy Loop": (DealDamage(50), ReturnOwnEnergyToHand(count=1)),
    },
    "sv6pt5-6": {  # カプ・ブルル(Tapu Bulu)
        "Wood Hammer": (DealDamage(220), SelfDamage(30)),
    },
    "me2-8": {  # ゲノセクト(Genesect、ex表記なし通常版)
        "Speed Attack": (DealDamage(110),),
    },
    "me3-42": {  # カメテテ(Binacle)
        "Double Draw": (Draw(2),),
        "Scratch": (DealDamage(30),),
    },
    "sv7-41": {  # ゲッコウガex(Greninja ex)
        "Shifting Shuriken": (DealDamageWithCoinFlipBonus(base=100, bonus=100),),
    },
    "sv10-134": {  # マリィのベロバー(Marnie's Impidimp)
        "Filch": (Draw(1),),
        "Corkscrew Punch": (DealDamage(10),),
    },
    "sv10-135": {  # マリィのギモー(Marnie's Morgrem)
        "Corkscrew Punch": (DealDamage(60),),
    },
    "me2pt5-155": {  # Nのゼクロム(N's Zekrom)
        "Shred": (DealDamageIgnoringDefenderShieldAndReduction(70),),  # 実カードテキスト: "isn't affected by any effects on your opponent's Active Pokémon"(以前は通常のDealDamageだった)
        # 実カードテキスト: "During your next turn, this Pokémon can't use attacks."
        # 以前はこの自己ロックが未登録で、次の番も無制限に250ダメージを連発できてしまっていた
        # (2026-08-20発覚。他の同種カード(ザシアンVの「Brave Blade」等)には既に登録されており、
        # このカードだけ抜けていた)。
        "Rampaging Thunder": (DealDamage(250), LockOwnAttackNextTurn("Rampaging Thunder", lock_all_attacks=True)),
    },
    "sv8-111": {  # ナゲツケサル(Passimian)
        "Coordinated Throwing": (DamagePerOwnPokemonWithSubtype(base=0, per_pokemon=20, subtype="Basic"),),
    },
    "sv5-99": {  # テツノイサハex(Iron Boulder ex)
        "Power Stomp": (DealDamage(200), DiscardOwnEnergy(2)),
        "Repulsor Axe": (DealDamage(60), SetSelfRetaliateOnDamagedNextTurn(counters=8)),
    },
    "sv8pt5-45": {  # キチキギス(Fezandipiti、ex表記なし通常版)
        "Energy Feather": (DamagePerOwnAttachedEnergyCount(per_energy=30),),
    },
    "sv10-21": {  # ミニーブ(Smoliv)
        "Ram": (DealDamage(10),),
    },
    "me2pt5-126": {  # ロケット団のヤミカラス(Team Rocket's Murkrow)
        "Deceit": (SearchDeckMultiCriteria(("supporter",)),),
        "Torment": (DealDamage(30), LockChosenOpponentAttackNextTurn()),
    },
    "me2pt5-122": {  # イイネイヌ(Okidogi)
        "Light Punch": (DealDamage(20),),
    },
    "sv8pt5-58": {  # オーガポン いしずえのめんex(Cornerstone Mask Ogerpon ex、Prismatic Evolutions再録)
        "Demolish": (DealDamageIgnoringWeaknessResistance(140, ignore_defender_effects=True),),  # 実カードテキスト: 弱点・抵抗力・相手にかかっている効果すべてを計算しない
    },
    "me2pt5-47": {  # メガユキメノコex(Mega Froslass ex)
        "Resentful Refrain": (DamagePerOpponentHandCardCount(base=0, per_card=50),),
        "Absolute Snow": (DealDamage(150), InflictStatusOnDefender("asleep")),
    },
    "sv8pt5-19": {  # ヤドキング(Slowking)
        "Wash the Slate Clean": (DealDamage(70), ReturnChosenOpponentEnergyToHand(count=2)),
    },
    # ---- 2026年 レギュレーション優先実装(PJCS2026/CL2026) ----
    "me1-3": {  # メガフシギバナex(Mega Venusaur ex)
        "Jungle Dump": (DealDamage(240), HealSelf(30)),
    },
    "me1-56": {  # フーディン(Alakazam)
        "Powerful Hand": (DamageCountersOnDefenderPerOwnHandCount(per_card=2),),
    },
    "me1-86": {  # メガアブソルex(Mega Absol ex)
        "Terminal Period": (KnockOutDefenderIfExactDamageCounters(exact_counters=6),),
        "Claw of Darkness": (DealDamage(200), RevealOpponentHandThenDiscardChosen()),
    },
    "me2pt5-105": {  # ルナトーン(Lunatone)
        "Power Gem": (DealDamage(50),),
    },
    "me2pt5-106": {  # ソルロック(Solrock)
        "Cosmic Beam": (DamageIfOwnBenchedNamePrefixInPlayElseZero(amount=70, name_prefix="Lunatone", ignore_weakness_resistance=True),),
    },
    "me2pt5-127": {  # ロケット団のドンカラス(Team Rocket's Honchkrow)
        "Rocket Feathers": (DiscardChosenOwnHandSupportersThenScalingDamage(name_contains="Team Rocket", damage_per=60),),
        "Hammer In": (DealDamage(100),),
    },
    "me2pt5-179": {  # テラパゴスex(Terapagos ex)
        # ベンチにいる間ダメージを一切受けないルールは、このカード固有の特性ではなくテラスタル
        # ポケモン共通のルール箱テキストのため、effects.primitives._apply_defender_side_damage_modifiers
        # 内の"Tera" in defender_card.subtypes判定で全Teraカード共通に対応済み(2026-08-22)。
        "Unified Beatdown": (DamagePerOwnBenchedPokemonCount(base=0, per_pokemon=30),),
        "Crown Opal": (DealDamage(180), ApplyScopedDamageImmunityToSelf("basic_non_colorless")),
    },
    "me2pt5-287": {  # マリィのオーロンゲex(Marnie's Grimmsnarl ex)
        "Shadow Bullet": (DealDamage(180), DealBonusDamageToChosenOpponentBench(30)),
    },
    "me2pt5-39": {  # コダック(Psyduck)
        "Ram": (DealDamage(20),),
    },
    "me2pt5-79": {  # ロケット団のミュウツーex(Team Rocket's Mewtwo ex、特性「Power Saver」の攻撃ゲートはlegal_actions._MIN_NAMED_PREFIX_POKEMON_IN_PLAY_TO_ATTACK経由)
        "Erasure Ball": (
            DealDamage(160),
            DiscardOwnBasicEnergyThenScalingDamage(damage_per=60, max_selectable=2, bench_only=True, any_energy=True),
        ),
    },
    "me2pt5-8": {  # チコリータ(Chikorita)
        "Growl": (DebuffDefenderAttackDamageNextTurn(20),),
        "Seed Bomb": (DealDamage(30),),
    },
    "me2pt5-97": {  # ロケット団のミミッキュ(Team Rocket's Mimikyu)
        "Gemstone Mimicry": (CopyOpponentActiveAttack(required_subtype="Tera"),),
    },
    "me3-43": {  # ガメノデス(Barbaracle)
        "Hammer In": (DealDamage(80),),
    },
    "me4-61": {  # メタグロス(Metagross)
        "Bounce Back": (DealDamage(60), ForceOpponentSwitchOpponentChooses()),
        # 「Metal エネルギーを3枚捨てて150ダメージ追加してもよい」はワザ選択時の2択(捨てない/捨てる)で提示する。
        "Metallic Hammer": (DamageBonusWithOptionalEnergyDiscard(150, 150, energy_type="Metal", max_count=3),),
    },
    "sv10-128": {  # ロケット団のニューラ(Team Rocket's Sneasel)
        "Scratch": (DealDamage(20),),
        "Strike the Sleeper": (DamagePerChosenOpponentBenchedDamageCounters(per_counter=20),),
    },
    "sv10-153": {  # ロケット団のポリゴン(Team Rocket's Porygon)
        "Hacking": (MayDiscardOwnHandCardThenOpponentDiscardsOne(),),
    },
    "sv10-154": {  # ロケット団のポリゴン2(Team Rocket's Porygon2)
        "R Command": (DamagePerOwnDiscardSupporterNameContainsCount(per_card=20, name_contains="Team Rocket"),),
    },
    "sv10-22": {  # オリーニョ(Dolliv)
        "Nutrients": (HealTarget(40),),
        "Tackle": (DealDamage(40),),
    },
    "sv10-23": {  # オリーヴァex(Arboliva ex)
        # 実カードテキスト: "Choose 1 of your opponent's Pokémon 6 times. (You can choose the same
        # Pokémon more than once.) For each time you chose a Pokémon, do 20 damage to it."
        # 以前は対象選択を1回だけに簡略化しており、複数体に振り分けられなかった(2026-08-20発覚)。
        "Oil Salvo": (DistributeDamageCountersFreely(6, damage_per_counter=20),),
        "Aroma Shot": (DealDamage(160), ClearActiveStatusConditions()),
    },
    "sv10-51": {  # ロケット団のフリーザー(Team Rocket's Articuno、特性「Repelling Veil」はprimitives._defender_blocks_non_damage_effects経由で実装済み)
        # 実カードテキスト: "If this Pokemon has any Team Rocket's Energy attached, this attack
        # does 60 more damage."。ロケット団のエネルギー(engine.energy.TEAM_ROCKET_ENERGY_ID=
        # "sv10-182")は既に実装済みのため、以前の「該当エネルギー未実装のため未対応」は誤りだった
        # (2026-08-22訂正)。
        "Dark Frost": (DamageBonusIfOwnEnergyIdAttached(base=60, bonus=60, required_energy_id="sv10-182"),),
    },
}

ABILITY_EFFECTS: dict[str, dict[str, tuple[Effect, ...]]] = {
    "xy10-64": {  # ゲノセクトEX(Genesect-EX、Fates Collide版)
        "Drive Change": (ReturnOwnToolToHand(),),
    },
    "xy4-61": {  # ドータクン(Bronzong、Phantom Forces版)
        "Metal Links": (AttachEnergyFromDiscardToOwnPokemon(energy_type="Metal", bench_only=True),),
    },
    "xy10-62": {  # ドータクンBREAK(Bronzong BREAK): BREAK進化ルールによりドータクンの特性を引き継ぐ
        "Metal Links": (AttachEnergyFromDiscardToOwnPokemon(energy_type="Metal", bench_only=True),),
    },
    "base1-15": {  # Venusaur
        "Energy Trans": (ChooseOwnPokemonThenMoveOneBasicEnergyToAnother(energy_type="Grass"),),
    },
    "base1-4": {  # Charizard
        "Energy Burn": (NotImplementedEffect("エネルギーをFireとして扱う変換は未実装"),),
    },
    # ---- WCS2010(がブレンミラー) ----
    "pl1-41": {  # Bronzong G
        "Galactic Switch": (ChooseOwnPokemonThenMoveOneBasicEnergyToAnother(source_subtype="SP", self_damage_after=20),),
    },
    "dp6-146": {  # Uxie LV.X
        "Trade Off": (RevealTopNChooseOneToHandOtherToBottom(2),),
    },
    "sm9-123": {  # ピジョン(Pidgeotto)
        "Air Mail": (RevealTopNChooseOneToHandOtherToBottom(2),),
    },
    "dp5-49": {  # Unown Q
        "QUICK": (AttachSelfAsRetreatReducingTool(),),
    },
    "dpp-DP41": {  # Toxicroak G(プロモ版)
        "Leap Away": (FlipCoinThenReturnSelfToHand(),),
    },
    # ---- ガーデヴォール/ジェリセント(2026年1月トロント地区大会) ----
    # 注: このセットにあるラティアスex「スカイライナー」・ジェリセントex「オーシャンカース」・
    # メガディアンシーex「ダイヤモンドコート」・リリーの相棒クレッフィex「フェアリーゾーン」は
    # 常時発動型のパッシブ効果(発動アクションを持たない)のため、既存カード(Toxicroak Gの
    # 「予感」等)と同様に一覧に登録していない(=特性メニューには出ないが、カード自体は場に出せる)。
    "sv6-95": {  # Munkidori
        "Adrena-Brain": (MoveDamageCountersFromSelfToOpponentActive(3),),
    },
    "sv1-86": {  # Gardevoir ex
        "Psychic Embrace": (AttachEnergyFromDiscardToOwnPokemon(energy_type="Psychic", self_damage=20, target_type="Psychic"),),
    },
    "sv3pt5-151": {  # Mew ex
        "Restart": (DrawUpTo(3),),
    },
    "sv6pt5-38": {  # Fezandipiti ex
        "Flip the Script": (Draw(3),),  # 発動条件(相手の直前の番に自分のポケモンがきぜつしたか)はlegal_actions._ability_actionsでゲート済み
    },
    "sv9-98": {  # Nのゾロアークex(N's Zoroark ex)
        "Trade": (DiscardCardsFromHand(1), Draw(2)),
    },
    "me2pt5-137": {  # Nのゾロアークex(Mega系再録、sv9-98と同一テキスト)
        "Trade": (DiscardCardsFromHand(1), Draw(2)),
    },
    # ---- WCS2025 2位 ドラパルト/デスバーン(Justin Newdorf選手) ----
    # 注: ボルトラルナex「シーズンドスキル」(コスト軽減の常時効果)、ホルビーの「フライングエントリー」
    # (ベンチに出た瞬間、相手のベンチ2匹を選ぶ2対象選択が必要)は未対応のため一覧に登録していない。
    "sv6-129": {  # Drakloak
        "Recon Directive": (RevealTopNChooseOneToHandOtherToBottom(2),),
    },
    # ---- WCS2025 3位 らいげきしぶ/オーガポン(Shizuki Nakagawa選手) ----
    # ヨルノズク「ほうせきさがし」はEVOLVE_TRIGGER_EFFECTS経由で対応済み(テラスタルポケモンの
    # 発動条件はrules_engine._evolve_trigger_condition_metでゲート)。
    "sv6-25": {  # Teal Mask Ogerpon ex
        "Teal Dance": (AttachEnergyFromHandToSelf(energy_type="Grass", draw_if_attached=True),),
    },
    "sv3pt5-132": {  # メタモン(Ditto)
        # 特性「へんしんスタート」(自分の最初の番、バトル場にいれば山札のたねポケモンと入れ替わる)は
        # legal_actions経由でバトル場・自分の最初の番限定にゲート済み。
        "Transformative Start": (DiscardSelfSearchBasicToActiveInPlace(),),
    },
    "sv4-139": {  # サーフゴーex(Gholdengo ex)
        "Coin Bonus": (DrawBonusIfActive(base=1, bonus_if_active=1),),
    },
    "zsv10pt5-67": {  # ゲノセクトex(Genesect ex)
        "Metallic Signal": (SearchDeckMultiCriteria(("metal_evolution_pokemon", "metal_evolution_pokemon")),),
    },
    "sv7-118": {  # Fan Rotom
        "Fan Call": (SearchDeckForPokemonToHand(count=3, pokemon_type="Colorless", max_hp=100),),
    },
    "sv2-169": {  # Squawkabilly ex
        "Squawk and Seize": (DiscardHandThenDraw(6),),
    },
    # ---- WCS2025 4位 リザードンex/ポッポサンダー(Junya Tanaka選手) ----
    # リザードンex「インフェルノリボーン」はEVOLVE_TRIGGER_EFFECTS経由で対応済み。
    "sv3-164": {  # Pidgeot ex
        "Quick Search": (SearchDeckAnyCardToHand(1),),
    },
    # 注: アイアンバルジェットex「イニシャライズ」(バトル場にいる間、ルール変化を受けるポケモンの特性を
    # 双方とも封じる常時効果)は未対応のため一覧に登録していない。
    # ---- WCS2024 2位 あばれるつき(Seinosuke Shiokawa選手) ----
    "sv6pt5-39": {  # Pecharunt ex(モモワロウex、特性「しはいのくさり」)
        "Subjugating Chains": (SwitchActiveWithBenchThenPoisonSelf(required_type="Darkness", exclude_card_id="sv6pt5-39"),),
    },
    "swsh10-46": {  # Radiant Greninja
        "Concealed Cards": (DiscardEnergyFromHand(1), Draw(2)),
    },
    # ---- WCS2024 3位 ミライドンex(Jesse Parker選手) ----
    # 注: サンダー「エレキマーク」(自分の場の他の基本雷ポケモンの攻撃ダメージ+10という常時効果)は
    # 未対応のため一覧に登録していない。
    "sv1-81": {  # Miraidon ex
        "Tandem Unit": (SearchDeckForBasicPokemonToBench(2, pokemon_type="Lightning"),),
    },
    "swsh9-48": {  # Raikou V
        "Fleet-Footed": (Draw(1),),
    },
    "sv4-56": {  # Iron Bundle
        "Hyper Blower": (SwitchOutOpponentActiveOpponentChoosesThenDiscardSelf(),),  # 相手が新しいバトルポケモンを選ぶ
    },
    "swsh12-136": {  # Regidrago VSTAR
        # v1簡略版: 「上から7枚トラッシュ」は自分の山札を7枚トラッシュに簡略化し、続けてトラッシュから
        # 好きなカードを2枚まで手札に加える(実際は「トラッシュした中から」ではなくトラッシュ全体から選べる点が異なる)
        "Legacy Star": (DiscardTopOfOwnDeck(7), SearchDiscardAnyCardToHand(2)),
    },
    "swsh11-136": {  # Hisuian Goodra VSTAR(ヒスイヌメルゴンVSTAR)
        "Moisture Star": (HealSelf(9999),),
    },
    # キュレムの「プラズマの災い」(相手トラッシュのコレクレス関連カードでコスト軽減)も
    # 条件判定が複雑なため未対応(一覧に登録していない、Trifrostは常に本来のコストが必要)。
    # ---- WCS2023 優勝 フュージョンミュウ(Vance Kelley選手) ----
    "swsh8-185": {  # Genesect V
        "Fusion Strike System": (DrawUpToFusionStrikeCount(),),
    },
    # 注: ゲノセクトVの特性は上に登録済み。フォクスライの「決意のレッスン」(自分のフュージョン戦略
    # ポケモンが受けるダメージ-20の常時効果)は未対応のため一覧に登録していない。
    # ---- WCS2023 2位 ガーデヴォール(Tord Reklev選手) ----
    "swsh12-68": {  # Kirlia
        "Refinement": (DiscardCardsFromHand(1), Draw(2)),
    },
    "swsh6-61": {  # Gardevoir
        "Shining Arcana": (LookTopNChooseEnergyToAttachRestToHand(2),),
    },
    "cel25-16": {  # Zacian V
        "Roar of the Sword": (SearchDeckAndAttachEnergy("Psychic", 1, self_only=False), EndTurnAfterThisAbility()),
    },
    "cel25-11": {  # Mew
        "Mysterious Tail": (LookTopNChooseByCriteriaToHand(n=6, m=1, criteria="item"),),
    },
    # 注: マナフィの「ウェイブベール」(自分のベンチが受けるダメージを防ぐ常時効果)は未対応のため
    # 一覧に登録していない。
    # ---- WCS2023 3位 ギラティナLZボックス(Michael Pramawat選手) ----
    "swsh11-79": {  # Comfey(キュワワー)
        "Flower Selecting": (LookTopNKeepMRestToLostZone(2, 1),),
    },
    # 注: ウッウの「はぐれ補給」(ロストゾーン4枚以上でエネルギーコスト無視)、カビゴンの
    # 「ダメージ以外の効果を受けない」特性(NON_DAMAGE_EFFECT_IMMUNE_CARD_IDSで別途対応済み)は
    # 発動アクションを持たない常時効果のため一覧に登録していない。
    # ---- WCS2022 優勝 アルセウス/そらとぶピカチュウ(Ondřej Škubal選手) ----
    "swsh9-121": {  # Bibarel
        "Industrious Incisors": (DrawUpTo(5),),
    },
    "swsh9-123": {  # Arceus VSTAR
        "Starbirth": (SearchDeckAnyCardToHand(2),),
    },
    "swsh10-84": {  # Hisuian Decidueye VSTAR(ヒスイジュナイパーVSTAR)
        "Star of Fortune": (DrawUpTo(8),),
    },
    # ---- WCS2022 2位 アルセウス/そらとぶピカチュウ(Daichi Shimada選手) ----
    "swsh6-97": {  # Galarian Moltres V
        "Direflame Wings": (AttachEnergyFromDiscardToOwnPokemon(energy_type="Darkness", count=1, self_only=True),),
    },
    # 注: イーブイ(ヒスイ版)の「レゾナントエボリューション」(進化トリガー)、サンダースの
    # 「サンダーウェイクン」(メモリーカプセル装備が条件の常時効果)は未対応のため一覧に登録していない。
    # ---- WCS2022 4位 パルキアVSTAR/インテレオン(James Cox選手) ----
    "swsh6-43": {  # Inteleon(れんげきタグ版)
        "Quick Shooting": (DamageCounterOnChosenOpponentPokemon(2),),
    },
    "swsh10-40": {  # Origin Forme Palkia VSTAR(オリジンパルキアVSTAR)
        # 実カード: "you may attach up to 3 Water Energy cards from your discard pile to your
        # Water Pokémon in any way you like." → 好きなように分配(1匹にまとめても複数匹に分けても
        # よい)+ 3枚まで(打ち切り可)+ 対象は自分の水ポケモン限定。
        "Star Portal": (AttachDiscardEnergyFreelyToOwnPokemon(count=3, energy_type="Water", target_type="Water", optional=True),),
    },
    # ドリザイル/インテレオン(SSH版)のShady DealingsはEVOLVE_TRIGGER_EFFECTS経由で対応済み。
    # ---- Players Cup 2020 優勝 ザシアン&メルメタル(Natalie Millar選手) ----
    "swsh1-138": {  # Zacian V
        "Intrepid Sword": (LookTopNChooseEnergyToAttachRestToHand(3, energy_type="Metal", self_only=True, ends_turn=True),),
        # この特性を使ったら自分の番は終わる(選択の解決後にターンを終える。then_end_turn)
    },
    # 注: ザマゼンタVの「Dauntless Shield」(相手VMAXからのダメージを無効化)、ドータクンの
    # 「Heatproof」(相手ほのおポケモンからのダメージを無効化)は、UseAbility方式ではなく
    # engine/continuous.py + effects/primitives.py の常時ダメージ修正ロジックで対応済み(発動アクションを
    # 持たない常時効果のためABILITY_EFFECTSには登録しない)。ドーミラーの「Evolutionary Advantage」
    # (後攻1ターン目に進化できる特殊ルール)はルール変更型のため未対応(一覧に登録していない)。
    # ---- Players Cup 2021 優勝 れんげきウーラオス(Azul Garcia Griego選手) ----
    "sm9-99": {  # Jirachi
        "Stellar Wish": (LookTopNChooseByCriteriaToHand(5, 1, "trainer"), InflictStatusOnSelf("asleep")),
    },
    # 注: ミュウの「Bench Barrier」、ミミッキュの「Shadow Box」、ジラーチGXの「Psychic Zone」は
    # いずれも継続効果(常時ルール変更)のためこのエンジンでは未対応(一覧に登録していない)。
    # ---- WCS2019 優勝 ミュウツー&ミュウGX(Henry Brand選手) ----
    "sm1-89": {  # Solgaleo-GX
        "Ultra Road": (SwitchActiveWithBench(),),
    },
    # 注: コバルオンGXの「Metal Symbol」(鋼エネルギーがついた自分のポケモンを特殊状態から守る常時効果)、
    # マーシャドーの「Resetting Hole」(ベンチにいるとき限定でスタジアムと自分を道連れに破棄する効果)は
    # いずれも未対応(一覧に登録していない)。
    # ---- WCS2019 2位 ズガドーンGX/アーゴヨン(Shintaro Ito選手) ----
    "sm8-108": {  # Naganadel
        "Charging Up": (AttachEnergyFromDiscardToOwnPokemon(energy_type=None, count=1, self_only=True),),
        # v1簡略版: バトル場にいるときのみ使用可能とする(legal_actionsでゲート)。本来はベンチでも使える。
    },
    # ヒードランGXの「Burning Road」(ベンチからバトル場に出た瞬間の特性)はBECOME_ACTIVE_TRIGGER_EFFECTS
    # (自分の番にベンチからバトル場に出たとき。にげる/入れ替え効果を問わない)経由で対応済み。
    # ---- WCS2018 優勝 ゾロアーク/ダストダス(Robin Schulz選手) ----
    "sm35-53": {  # ゾロアークGX(Zoroark-GX)
        "Trade": (DiscardCardsFromHand(1), Draw(2)),
    },
    # ダストダスの「Garbotoxin」(どうぐがついていれば特性を封じる常時効果)はUseAbility方式ではなく
    # engine/continuous.py(abilities_blocked_by_garbotoxin)経由で対応済み(発動アクションを持たないため
    # ABILITY_EFFECTSには登録しない)。
    # ---- WCS2018 2位 カラマネロ(Jeff Kolenc選手) ----
    "sm1-113": {  # ヤレユータン(Oranguru)
        "Instruct": (DrawUpTo(3),),
    },
    # ダウンウィングネクロズマGXの「Invasion」(ベンチから直接バトル場に出る)。legal_actionsでベンチにいるときのみ
    # 使用可能とゲートする。以前はコメントだけで実際の登録が無く、使えなかった(2026-10-06のテストで発覚)。
    "sm5-63": {"Invasion": (SwitchSelfFromBenchToActive(),)},
    # ネクロズマGXの「Light's End」(無色ポケモンのワザによるダメージを無効化)は常時効果のため
    # effects/primitives.py の _FULL_DAMAGE_IMMUNITY_VS_TYPE 経由で対応済み(ABILITY_EFFECTSには登録しない)。
    # ---- WCS2017 優勝 サーナイトGX(Diego Cassiraga選手) ----
    "sm3-93": {  # サーナイトGX(Gardevoir-GX)
        "Secret Spring": (AttachEnergyFromHandToTarget(energy_type="Fairy", max_count=1),),
    },
    "xy8-84": {  # エルレイド(Gallade)
        "Premonition": (LookTopNReorderOnTop(5),),
    },
    "xy8-33": {  # オクタン(Octillery)
        "Abyssal Hand": (DrawUpTo(5),),
    },
    # ---- WCS2016 2位 ゲッコウガBREAK(Cody Walinski選手) ----
    "xy9-41": {  # ゲッコウガBREAK(Greninja BREAK)
        # 手札のみずエネルギーを1枚捨てて発動する。発動条件(手札にみずエネルギーがあること)は
        # legal_actionsでゲート済み。v1簡略版: 対象は常に相手のバトルポケモン固定(本来は場の任意の1匹を選べる)。
        "Giant Water Shuriken": (DiscardCardsFromHand(1, only_energy_type="Water"), DamageCounterOnChosenOpponentPokemon(6)),
    },
    # ---- WCS2016 4位 ビークイン/イベルタル(Ross Cawthon選手) ----
    "xy7-30": {  # アンノーン(Unown)
        "Farewell Letter": (DiscardSelfFromBench(), Draw(1)),
    },
    # ---- WCS2015 優勝 カメックス(Jacob Van Wagner選手) ----
    "bw10-16": {  # カメックス(Blastoise)
        "Deluge": (AttachEnergyFromHandToTarget(energy_type="Water", max_count=1),),
    },
    "bw7-49": {  # ケルディオEX(Keldeo-EX)
        "Rush In": (SwitchSelfFromBenchToActive(),),
    },
    "sm8-44": {  # Magcargo-GX
        "Crushing Charge": (DiscardTopNAttachEnergyFound(1, basic_only=True, self_only=False),),
    },
}

TRAINER_EFFECTS: dict[str, tuple[Effect, ...]] = {
    "swsh45-60": (DiscardHandThenDraw(7),),  # Professor's Research
    "sm35-68": (DiscardCardsFromHand(2), SearchDeckForPokemonToHand(1)),  # Ultra Ball(Shining Legends版)
    "sm1-135": (DiscardCardsFromHand(2), SearchDeckForPokemonToHand(1)),  # Ultra Ball(Sun & Moon版)
    # ---- WCS2017 8位 ジジーロンGX/ダストダス(Sam Chen選手) ----
    "sm3-120": (DiscardHandCostThenDiscardChosenOpponentEnergy(2),),  # プルメリ(Plumeria)
    "xy2-99": (DiscardCardsFromHand(2), SearchDeckForPokemonToHand(1)),  # Ultra Ball(Flashfire版)
    "xy10-113": (DiscardCardsFromHand(2), SearchDeckForPokemonToHand(1)),  # Ultra Ball(Fates Collide版)
    "xy0-38": (SwitchActiveWithBench(),),  # Switch
    "xy0-37": (HealTarget(30),),  # Potion
    "sm2-128": (HealTargetThenDiscardAllEnergy(),),  # マックスポーション(Max Potion)
    "sm9-135": (ShuffleFromDiscardIntoDeck(6),),  # ブロックのねばり(Brock's Grit)
    "sm5-128": (Draw(2), DiscardRandomFromOpponentHand()),  # マーズ(Mars)
    "sm5-135": (SearchDeckMultiCriteria(("item", "basic_lightning_energy")),),  # ボルケニオン ではなく デンジ(Volkner)
    "sm8-188": (SearchDeckForPokemonToHand(count=3, max_hp=60),),  # エルムはかせのこうぎ(Professor Elm's Lecture)
    "bw7-136": (TurnPrizesFaceUp(),),  # タウンマップ(Town Map): 自分のサイドをすべて表向きにする(以前は「情報開示のみで影響なし」として空実装だった。サイドの中身は本人も知らない非公開情報なので、表向きにすると山札の内容が確定する)
    "xy8-150": (TurnPrizesFaceUp(),),  # タウンマップ(Town Map、XY版、テキストはbw7-136と同一)
    # ---- WCS2010(がブレンミラー) ----
    "pl1-118": (ReturnOwnBenchedPokemonToHand(only_sp=True),),  # Poké Turn
    "pl2-96": (TopDeckThenSearchPokemon(only_sp=True),),  # SP Radar
    # パワースプレー(pl1-117)は通常のグッズとしては使えない(legal_actions._item_actionsでゲート済み)。
    # 実際の効果はUsePowerSprayアクション(rules_engine._handle_use_power_spray)経由で発動する。
    "hgss1-98": (SwapHandPokemonForDeckSearch(),),  # Pokémon Communication
    "dp7-86": (SearchDeckForPokemonToHand(1, exclude_level_up=True),),  # Luxury Ball
    "dp3-120": (ShuffleFromDiscardIntoDeck(3),),  # Night Maintenance
    "pl1-105": (SearchDeckMultiCriteria(("supporter", "basic_energy", "team_galactic_item")),),  # Cyrus's Conspiracy
    "hgss1-101": (ShuffleHandIntoDeckThenDraw(6),),  # Professor Oak's New Theory
    "dp3-125": (SearchDeckBasicPokemonAndEnergy(2),),  # Roseanne's Research
    "hgss1-97": (SearchDeckForPokemonToHand(3, only_basic=True),),  # Pokémon Collector
    "pl2-89": (TopDeckThenSearchPokemon(),),  # Bebe's Search
    "pl2-88": (SearchDiscardForSPAndEnergy(2),),  # Aaron's Collection
    # ---- 現行スタンダード(Mega Evolutionブロック) ----
    "me1-131": (DiscardCardsFromHand(2), SearchDeckForPokemonToHand(1)),  # Ultra Ball
    "me1-114": (ForceOpponentSwitchChosenBench(),),  # Boss's Orders
    "sv5-144": (SearchDeckForBasicPokemonToBench(2, max_hp=70),),  # Buddy-Buddy Poffin
    "me1-173": (SearchDiscardForPokemonOrEnergy(1, optional=False),),  # Night Stretcher(候補があれば必須、"may"表記なし)
    # ---- ガーデヴォール/ジェリセント(2026年1月トロント地区大会) ----
    "me1-119": (ShuffleHandThenDrawWithPrizeBonus(base_count=6, bonus_count=8, prizes_remaining_for_bonus=6),),  # Lillie's Determination
    "sv2-185": (BothPlayersShuffleHandAndDrawByPrizes(),),  # Iono
    "sv4-171": (ReturnOwnBenchedPokemonToHandDiscardAttached(),),  # Professor Turo's Scenario(バトル場/ベンチどちらも対象可)
    "sv3-186": (SearchDeckMultiCriteria(("item", "pokemon_tool")),),  # Arven
    "sv1-181": (SearchDeckForBasicPokemonToBench(1),),  # Nest Ball
    "sv4-163": (DiscardCardsFromHand(1), SearchDeckForBasicEnergyToHand(2)),  # Earthen Vessel
    "sv6pt5-61": (SearchDiscardForPokemonOrEnergy(1, optional=False),),  # Night Stretcher(SFA版、候補があれば必須)
    "sv6-163": (
        DiscardCardsFromHand(3),
        SearchDeckMultiCriteria(("item", "pokemon_tool", "supporter", "stadium")),
    ),  # Secret Box(ACE SPEC)
    "sv4-160": (ForceOpponentSwitchChosenBench(),),  # Counter Catcher(サイド枚数条件はlegal_actions._item_actionsでゲート済み)
    "sm4-91": (ForceOpponentSwitchChosenBench(),),  # Counter Catcher(SM期版、テキストはsv4-160と同一)
    "sv2-188": (ShuffleFromDiscardIntoDeck(3),),  # Super Rod
    # ---- WCS2025 1位 ガーデヴォール(Riley McKay選手) ----
    "sv9-155": (DiscardHandThenDraw(7),),  # Professor's Research
    "sv1-196": (DiscardCardsFromHand(2), SearchDeckForPokemonToHand(1)),  # Ultra Ball
    "sv1-191": (EvolveOwnBasicDirectlyFromHand(),),  # Rare Candy(sm1-129と同一効果、印刷違い)
    "me1-125": (EvolveOwnBasicDirectlyFromHand(),),  # Rare Candy(sm1-129と同一効果、印刷違い)
    # ---- WCS2025 2位 ドラパルト/デスバーン(Justin Newdorf選手) ----
    "sv2-172": (ForceOpponentSwitchChosenBench(),),  # Boss's Orders(Ghetsis版)
    "rsv10pt5-84": (SearchDeckMultiCriteria(("evolution_pokemon", "any_energy")),),  # Hilda
    # sv6-153(ジャミングタワー)の「どうぐ無効化」常時効果はengine/continuous.py(tools_disabled)経由で
    # 対応済み(発動アクションを持たないためTRAINER_EFFECTSには登録しない)。
    # ---- WCS2025 3位 らいげきしぶ/オーガポン(Shizuki Nakagawa選手) ----
    # 自分の場の「Ancient」ポケモンを最大2体選び(0〜2体)、選んだ各体にトラッシュから基本エネルギーを
    # 1枚ずつプレイヤーが選んでつける。1枚でもついたら3枚引く(オーリム博士の気迫)。
    "sv4-170": (ChooseOwnAncientPokemonThenAttachDiscardEnergy(2),),  # オーリム博士の気迫
    "sv7-133": (SearchDeckBasicEnergyToHandThenChooseDistinctAttach(),),  # Crispin
    "sv1-171": (SearchDiscardForBasicEnergyToHand(2),),  # Energy Retrieval
    "sv1-173": (ChooseOwnPokemonThenMoveOneBasicEnergyToAnother(),),  # Energy Switch
    "sv5-157": (ForceOpponentSwitchChosenBenchThenSwitchOwnActive(),),  # Prime Catcher(ACE SPEC)
    # sv7-131(エリアゼロの地下いにしえ大空洞、テラスタルポケモンがいれば両者ベンチ上限8)と
    # xy6-89(スカイフィールド、無条件で両者ベンチ上限8)はengine.continuous.effective_bench_limit
    # 経由で対応済み(発動アクションを持たないため登録しない)。
    # ---- WCS2025 4位 リザードンex/ポッポサンダー(Junya Tanaka選手) ----
    "sv1-175": (SearchDeckMultiCriteria(("evolution_pokemon", "evolution_pokemon")),),  # Jacq
    "sv7-132": (BonusPrizeIfTeraKnockedOutOpponentThisTurn(),),  # ブライアー(相手の残りサイド2枚条件はlegal_actionsでゲート)
    # zsv10pt5-79(ふうせん)はにげるコスト-2として engine/energy.py に直接組み込み済み。
    # sv5-154(プライムベルト、ACEスペック、相手のバトル場のexポケモンへのダメージ+50)は
    # engine.continuous.modern_ex_bonus_damage経由で対応済み(発動アクションを持たないため登録しない)。
    # sv5-161(ミストエネルギー)は無色トークンとしては通常通り機能する(コスト消費は自動対応)ほか、
    # 「ついているポケモンへのワザの追加効果を防ぐ」常時効果もeffects.primitives.
    # _defender_blocks_non_damage_effects経由で対応済み(ダメージ自体は防がない、2026-08-25の
    # 公式FAQ監査で発覚し実装)。
    # ---- WCS2025 6位 Nのゾロアーク(Mateusz Łaszkiewicz選手) ----
    # v1簡略版: 本来は対象を「N's」ポケモンのベンチ1匹に限定するが、自分のベンチ全体から選べる形にしている。
    # N's PP Up実カードテキスト: "Attach a Basic Energy card from your discard pile to 1 of your
    # Benched N's Pokémon."。対象は「N's」名を持つベンチのポケモン限定(engine.legal_actions側の
    # _attach_target_filters経由でtarget_name_prefixを絞り込み、_ITEM_TARGETS_OWN_BENCHで対象選択、
    # トラッシュに基本エネルギーが無い/N'sポケモンがベンチにいなければ使用不可)。
    "sv9-153": (AttachEnergyFromDiscardToOwnPokemonWithChoice(energy_type=None, bench_only=True, target_name_prefix="N's "),),
    # ---- WCS2025 8位 Nのゾロアーク(Marco Cifuentes Meta選手) ----
    # v1簡略版: 「バトル場につけた場合どく状態にする」追加効果は未対応。
    # ジェニーの秘技: 悪タイプのポケモンを2体まで選び、それぞれに山札から基本悪エネルギーをつける。バトルポケモンに
    # つけたらどくになる(以前はタイプ制限もどく付与も無かった、2026-10-06訂正)
    "sv8pt5-112": (ChooseOwnPokemonThenSearchEnergyAttach(2, "Darkness", target_type="Darkness", poison_active=True),),  # Janine's Secret Art
    # 発動条件(相手の直前の番に自分のポケモンがきぜつしたか)はlegal_actionsでゲート済み。
    "sv6-165": (BothPlayersShuffleHandAndDrawAsymmetric(own_count=5, opponent_count=2),),  # Unfair Stamp(ACEスペック)
    # ---- WCS2025 7位 サーフゴー(Piper Lepine選手) ----
    # v1簡略版: 「好きな順番で戻す」の並べ替えUIは未対応、選んだ順のまま一番上に戻す。
    "sv5-145": (SearchDeckToTopOfDeck(2),),  # 暗号マニアの解読(Ciphermaniac's Codebreaking)
    "sv8-176": (SearchDeckForDistinctBasicEnergyTypesToHand(),),  # エネルギー転送PRO(Energy Search Pro、ACEスペック)
    # ---- WCS2024 優勝 アイアンバルジェットex(Fernando Cifuentes選手) ----
    "sv1-189": (DiscardHandThenDraw(7),),  # Professor's Research(博士の研究)
    "sv1-176": (BothPlayersShuffleHandAndDrawFixed(4),),  # Judge(ジャッジ)
    "sv6pt5-57": (SearchDeckMultiCriteria(("stadium", "any_energy")),),  # Colress's Tenacity
    "sv1-183": (ReturnOwnBenchedPokemonAndAttachedToHand(),),  # Penny(バトル場/ベンチのたねポケモンが対象、legal_actionsでたね限定をゲート)
    "sv3pt5-161": (BounceOpponentActiveEnergyThenAttachFromHand(),),  # Giovanni's Charisma
    # sv1-186(ポケギア3.0)・swsh10-140(エナジーロト)実カードテキスト: "Look at the top 7 cards of
    # your deck. You may reveal a Supporter/Energy card you find there and put it into your hand."
    # 山札全体からの確定サーチではなく、上から7枚だけを見て「見つかれば」加えられる不確定な効果。
    "sv1-186": (LookTopNChooseByCriteriaToHand(7, 1, "supporter"),),  # Pokégear 3.0
    "sv1-168": (FlipCoinThenDiscardOpponentEnergy(),),  # Crushing Hammer(クラッシュハンマー、対象は
    # エネルギーがついている相手の場のポケモン限定でlegal_actions側がゲート済み)
    "sv1-187": (FlipCoinThen(heads=(ForceOpponentSwitchChosenBench(),)),),  # Pokémon Catcher
    "sv4-180": (DiscardCardsFromHand(1), SearchDeckMultiCriteria(("future_pokemon", "future_pokemon"))),  # Techno Radar
    # swsh10-136(キャンセルコロン、相手バトルポケモンの特性をターン終了時まで封じる)は
    # 特性の一時封印という仕組みが未整備のため未実装(場には出せるが効果なし)。
    "swsh10-140": (LookTopNChooseByCriteriaToHand(7, 1, "any_energy"),),  # Energy Loto(エナジーロト)
    "swsh11-162": (
        ChooseHandCardToLostZone(1),
        DiscardChosenFieldToolsOrStadium(include_stadium=True, max_count=1, destination="lost_zone"),
    ),  # Lost Vacuum(コストとして手札1枚→どうぐ or スタジアムを1つ選んでロストゾーンへ)
    # sv4-179(わざマシン ターボチャージ)はどうぐから新しいワザを付与する仕組みが未整備のため、
    # 場に出せるが効果はなし(v1簡略版、わざマシン しんか/ふるいもどしと同様)。
    # ---- WCS2024 2位 あばれるつき(Seinosuke Shiokawa選手) ----
    "swsh10-139": (AttachEnergyFromDiscardToOwnPokemon(energy_type="Darkness", count=1, bench_only=True, target_type="Darkness"),),  # Dark Patch(ダークパッチ)
    "swsh10-156": (LookTopCardThenHandOrDiscardDraw(),),  # Trekking Shoes(トレッキングシューズ)
    "sv1-182": (ShuffleSupportersFromDiscardIntoDeck(2),),  # Pal Pad(ポケモンれんらくちょう)
    # pgo-68(ポケストップ)の「各プレイヤーの番に1回」効果はSTADIUM_ABILITY_EFFECTS経由で対応済み。
    # ---- WCS2024 3位 ミライドンex(Jesse Parker選手) ----
    "sv1-170": (
        LookTopNAttachBasicEnergyToChosenBench(5, count=2, energy_type="Lightning", target_pokemon_type="Lightning", basic_stage_only=False),
    ),  # でんきはっせいき(Electric Generator)
    "swsh10-154": (SwitchActiveWithBenchThenHealBenched(30),),  # のりかえチケット(Switch Cart)
    # swsh12-156(フォレストシールストーン)はVSTARパワーの仕組みが未整備のため、
    # 場に出せるが効果はなし(v1簡略版)。
    # sv3-196(まちのポケモンショップ)の「各プレイヤーの番に1回」効果はSTADIUM_ABILITY_EFFECTS経由で対応済み。
    # ---- WCS2024 4位 レジドラゴVSTAR(Raz Wolpe選手) ----
    "sv2-189": (DiscardHandCostThenRetrieveEnergyExcludingDiscarded(discard_count=2, energy_count=4),),  # スーパーエネルギー回収(Superior Energy Retrieval)
    "sv1-194": (SwitchActiveWithBench(),),  # Switch(ポケモンいれかえ、xy0-38と同じ効果の別カードID)
    # swsh10-155(シンオウ神殿、特殊エネルギーをすべて無色扱いにする常時効果)はスタジアムの
    # 常時効果が未整備のため、場に出せるが効果はなし(v1簡略版)。
    # ---- WCS2023 優勝 フュージョンミュウ(Vance Kelley選手) ----
    "swsh8-233": (ChooseOwnPokemonThenSearchSpecificEnergyAttach(2, "Fusion Strike Energy", "Fusion Strike"),),  # Elesa's Sparkle(フュージョンストライクポケモンを2体まで選び、それぞれにフュージョンエネルギーをつける)
    # swsh8-236(パワータブレット、このターン中フュージョン戦略ポケモンの攻撃+30という条件付き常時効果)は
    # 未整備のため、場に出せるが効果はなし(v1簡略版)。
    "swsh8-225": (SearchDeckForBasicPokemonToBench(2),),  # Battle VIP Pass
    "swsh8-229": (
        DiscardCardsFromHand(1, only_item=True),
        FlipCoinThen(heads=(SearchDeckAnyCardToHand(1),)),
    ),  # Cram-o-matic(手札の他のグッズカードを1枚選んでトラッシュしてから使う)
    "swsh5-125": (BothPlayersSwitchActiveEachChoosesOwn(),),  # Escape Rope(両者入れ替え)
    # swsh8-244(フュージョンエネルギー)は無色コストとしては通常通り機能する(engine/energy.pyで
    # ワイルドカード扱いに対応済み)。特性を無効化する保護効果は未整備のため未実装。
    # sv2-176(こだわりベルト、相手のVポケモンへの追加30ダメージ)はengine.continuous.v_bonus_damage
    # 経由で対応済み(発動アクションを持たないため登録しない)。swsh11-154(災いの箱、満タンHPの
    # Vポケモンがきぜつしたときの反撃効果)はeffects.primitives._RETALIATE_ON_FULL_HP_KO_TOOLS
    # 経由で対応済み(同様に発動アクションを持たないため登録しない)。
    # swsh6-148(頂への雪道)の「ルール変化ポケモンの特性を封じる」常時効果はengine/continuous.py
    # (abilities_blocked_by_stadium)経由で対応済み。
    # swsh7-144(結晶の洞窟、金属/ドラゴンポケモンの回復スタジアム)はSTADIUM_ABILITY_EFFECTS
    # (UseStadiumAbilityアクション)経由で対応済み。
    # ---- WCS2023 2位 ガーデヴォール(Tord Reklev選手) ----
    "swsh5-129": (SearchDeckForPokemonToHand(1, max_hp=90),),  # Level Ball
    # swsh6-140(フォグクリスタル)は「基本超エネルギーか無色以外のたねポケモンのどちらかを選ぶ」を、
    # このデッキでは基本エネルギーが超エネルギーのみのため基本エネルギー検索に簡略化している。
    "swsh6-140": (SearchDeckMultiCriteria(("psychic_energy_or_basic_psychic_pokemon",)),),  # Fog Crystal
    # swsh9-137(崩れたスタジアム、両プレイヤーのベンチ上限4)はengine.continuous.effective_bench_limit
    # 経由で対応済み(発動アクションを持たないため登録しない。超過分の自動トラッシュは
    # rules_engine._enforce_bench_limits経由)。
    # sv2-192(リバーサルエネルギー)は無色トークンとしては通常通り機能するが、
    # サイド枚数条件による無色×3への強化は未整備のため未実装。
    # ---- WCS2023 4位 フュージョンミュウ(Azul Garcia Griego選手) ----
    "swsh10-141": (SearchDeckForPokemonToHand(1, max_retreat_cost=0),),  # Feather Ball
    # ---- WCS2023 3位 ギラティナLZボックス(Michael Pramawat選手) ----
    "swsh11-155": (LookTopNKeepMRestToLostZone(5, 3),),  # Colress's Experiment(アクロマの実験)
    "swsh11-163": (ChooseOwnPokemonThenSearchDistinctBasicEnergyAttach(2),),  # Mirage Gate(ロストゾーン7枚以上はlegal_actions側でゲート)
    # sv2-190(ジェットエネルギー)は無色トークンとしては通常通り機能するが、
    # 「ベンチに手札から付けた瞬間バトルポケモンと入れ替える」効果は未整備のため未実装。
    # ---- WCS2022 優勝 アルセウス/そらとぶピカチュウ(Ondřej Škubal選手) ----
    "swsh1-169": (BothPlayersHandToBottomThenDrawAsymmetric(5, 4),),  # Marnie(手札は山札の下に置く。山札全体には混ぜない)
    "swsh9-132": (ForceOpponentSwitchChosenBench(),),  # Boss's Orders(SWSH版)
    "swsh9-147": (DiscardHandThenDraw(7),),  # Professor's Research(ブリリアントスター版)
    # swsh7-152(ライハン)は前の相手の番にきぜつしたかどうかの条件チェックが未整備のため、
    # 条件を無視して常時使用可能として扱う(v1簡略版)。
    "swsh7-152": (AttachEnergyFromDiscardToOwnPokemon(energy_type=None, count=1), IfLastAttachSucceeded((SearchDeckAnyCardToHand(1),))),  # カイ(Raihan)
    "swsh8-237": (DiscardCardsFromHand(1), SearchDeckForPokemonToHand(1, only_basic=True)),  # Quick Ball
    "swsh9-150": (DiscardCardsFromHand(2), SearchDeckForPokemonToHand(1)),  # Ultra Ball(SWSH版)
    "swsh1-163": (SearchDeckMultiCriteria(("evolution_pokemon",)),),  # Evolution Incense
    # swsh1-183(ポケモンいれかえ)は xy0-38/sv1-194 と同じ効果の別カードIDのため、
    # legal_actions側で同じベンチ対象enumerationを共有している。
    "swsh1-183": (SwitchActiveWithBench(),),  # Switch
    # swsh2-171(キャプチャーエネルギー)は無色トークンとしては通常通り機能するが、
    # 「手札からベンチに付けた瞬間たねポケモンをベンチに出す」効果は未整備のため未実装。
    # ---- WCS2022 2位 アルセウス/そらとぶピカチュウ(Daichi Shimada選手) ----
    "swsh1-171": (ShuffleFromDiscardIntoDeck(2, only="pokemon"), ShuffleFromDiscardIntoDeck(2, only="energy")),  # Ordinary Rod
    # swsh4-155(メモリーカプセル)は「進化前のワザを使える」どうぐの常時効果が未整備のため、
    # 場に出せるが効果はなし(v1簡略版)。
    # ---- WCS2022 4位 パルキアVSTAR/インテレオン(James Cox選手) ----
    "swsh10-147": (SearchDeckMultiCriteria(("water_pokemon", "item")),),  # Irida
    "swsh6-146": (AttachEnergyFromDiscardToOwnPokemon(energy_type="Water", count=1), IfLastAttachSucceeded((Draw(3),))),  # メロン(Melony)
    # swsh10-150(ロクサーヌ)は相手の残りサイド枚数条件が未整備のため、条件を無視して常時使用可能として扱う(v1簡略版)。
    "swsh10-150": (BothPlayersShuffleHandAndDrawAsymmetric(6, 2),),  # Roxanne
    # swsh8-230(クロススイッチャー)は実カードでは「2枚同時使用」が必須(1枚だけでは使用不可)のため、
    # TRAINER_EFFECTSには登録せず、TRAINER_PAIRED_EFFECTS(2枚同時使用)のみに登録する。
    "swsh2-156": (SearchDeckForBasicEnergyToHand(2, energy_type="Water"),),  # Capacious Bucket
    "swsh2-165": (ReturnOwnBenchedPokemonToHandDiscardAttached(),),  # Scoop Up Net(V/GXは除外。対象選択はlegal_actions._SCOOP_UP_NET_ID)
    "swsh10-146": (SwapSelfFromPrizesForBasicPokemon(),),  # Hisuian Heavy Ball
    # v1簡略版: 「相手の次の番が終わるまで」と実カードの「自分の番が終わるまで」より長めに
    # 特性を封じる(既存のBlockOpponentAbilitiesUntilTurnEndsを再利用、安全側に長めの簡略化)。
    "swsh10-136": (BlockOpponentActiveAbilitiesThisTurn(),),  # Canceling Cologne(この番の終わりまで、相手のバトルポケモンの特性を封じる)
    "swsh8-236": (GrantFusionStrikeDamageBonusThisTurn(),),  # Power Tablet
    # sm8-182(ルザミーネ◇)は「相手の残りサイドが3枚のときのみ使える」条件+「次の相手の番、
    # 自分のウルトラビーストがワザのダメージを受けない」シールドの組み合わせが未整備のため未実装
    # (v1簡略版、場に出せるが使っても効果はなし)。
    # xy9-109(時のパズル/Puzzle of Time)は1枚使用時と2枚同時使用時で効果が変わる特殊カードで、
    # クロススイッチャーと同様の仕組みが必要だが未整備のため未実装(v1簡略版)。
    "swsh6-136": (MoveBasicPokemonFromOpponentDiscardToTheirBench(),),  # Echoing Horn
    "xy4-106": (MoveBasicPokemonFromOpponentDiscardToTheirBench(),),  # ターゲットホイッスル(Target Whistle)
    "xy4-92": (SearchDeckAnyCardToDiscard(3),),  # バトルコンプレッサー(Battle Compressor)
    "xy9-98": (DiscardStadiumThenOpponentDiscardChosen(3),),  # こわいおねえさん(Delinquent)
    # swsh9-135(こだわりベルト)はengine.continuous.v_bonus_damage経由で対応済み(発動アクション
    # を持たないため登録しない)。swsh5-136(ツールジャマー、相手のどうぐを無効化)は
    # effects.primitives._apply_continuous_damage_modifiers内のattacker_tool/defender_tool
    # 実効値計算経由で対応済み(同様に発動アクションを持たないため登録しない)。
    # swsh2-169(Training Court)の「各プレイヤーの番に1回」効果はSTADIUM_ABILITY_EFFECTS経由で対応済み。
    # ---- Players Cup 2020 優勝 ザシアン&メルメタル(Natalie Millar選手) ----
    "swsh2-154": (ForceOpponentSwitchChosenBench(),),  # Boss's Orders(RCL版)
    "sm12-198": (SwitchActiveWithBenchThenMayDiscardToHealOld(discard_count=2, heal_amount=120),),  # Mallow & Lana(2枚捨てて、ベンチに移したポケモンを120回復するオプション付き)
    "sm12-189": (SearchDiscardForSupporterToHand(1), MayDiscardHandCardThenDraw(3)),  # シンジ&カトレア(Cynthia & Caitlin)
    "swsh1-179": (DiscardCardsFromHand(1), SearchDeckForPokemonToHand(1, only_basic=True)),  # Quick Ball(SSH版)
    "swsh1-170": (AttachEnergyFromDiscardToOwnPokemon(energy_type="Metal", count=1, target_type="Metal", bench_only=True),),  # Metal Saucer
    "sm12-206": (SearchDeckMultiCriteria(("tag_team", "tag_team")),),  # Tag Call
    "sm11-206": (OpponentShuffleHandDrawByPrizes(),),  # Reset Stamp
    "sm12-192": (DiscardCardsFromHand(2), ForceOpponentSwitchChosenBench()),  # Great Catcher(対象のGX/EX限定はlegal_actions._item_actionsでゲート済み)
    # メタルゴーグル(sm9-148、鋼ポケモン限定の被ダメージ-30+ダメカン付与無効)は
    # effects/primitives.py の_FLAT_DAMAGE_REDUCTION_TOOLS/_blocks_damage_counters経由で対応済み。
    # くろおび(sm11-201、サイド優勢時に闘エネルギー1つぶんコスト軽減)はengine/energy.pyの
    # KARATE_BELT_TOOL_ID経由で対応済み。ふうせん(swsh1-156)は既存のAIR_BALLOON_TOOL_IDS
    # (engine/energy.py)経由でにげるコスト軽減のみ実装済み。
    # 格闘道場(sm10-179、闘エネルギーがついた攻撃側への+10/+40ダメージ)はeffects/primitives.pyの
    # _apply_continuous_damage_modifiers経由で対応済み。
    # ---- Players Cup 2021 優勝 れんげきウーラオス(Azul Garcia Griego選手) ----
    "sm9-152": (ReturnHandPokemonToDeck(), SearchDeckForPokemonToHand(1)),  # Pokémon Communication(SM版)
    # ---- WCS2019 優勝 ミュウツー&ミュウGX(Henry Brand選手) ----
    "sm10-189": (AttachEnergyFromHandToTarget(energy_type="Fire", max_count=2, draw_if_attached=True),),  # 溶接工
    "sm9-133": (LookTopNChooseByCriteriaToHand(7, 2, "trainer"),),  # マサキの解析
    "sm10-182": (LookTopNChooseByCriteriaToHand(7, 1, "supporter"),),  # ポケギア3.0
    "sm7-123": (LookTopNKeepMRestToDiscard(2, 1),),  # アクロバイク
    "xy5-122": (LookTopNKeepMRestToDiscard(2, 1),),  # アクロバイク(Primal Clash版)
    "sm11-191": (SearchDeckForPokemonToHand(1, only_gx=True),),  # プレシャスボール
    "sm8-171": (DrawUpTo(3),),  # カスタムキャッチャー(1枚使用時。2枚同時使用の効果はTRAINER_PAIRED_EFFECTSに登録済み)
    "sm6-113": (DiscardCardsFromHand(1), SearchDeckForPokemonToHand(1, pokemon_types_any=("Psychic", "Dragon"))),  # ミステリートレジャー
    "sm1-132": (SwitchActiveWithBench(),),  # ポケモンいれかえ(SM版)
    "sm10-169": (DiscardCardsFromHand(2), SearchDeckForPokemonToHand(2, pokemon_type="Lightning", only_gx_or_ex=True)),  # 電磁レーダー
    "sm10-173": (SearchDiscardForBasicEnergyToHand(3, energy_type="Fire"),),  # 炎の結晶
    # 巨大なカマド(sm11-197)・トキワの森(sm9-156)の「各プレイヤーの番に1回」効果は
    # STADIUM_ABILITY_EFFECTS(UseStadiumAbilityアクション)経由で対応済み。
    # ---- WCS2019 2位 ズガドーンGX/アーゴヨン(Shintaro Ito選手) ----
    "sm5-119": (ShuffleHandIntoDeckThenDraw(6),),  # シロナ
    "sm5-125": (DrawUpTo(6, bonus_count_if_own_first_turn=8),),  # リーリエ
    "sm11-200": (LookTopNKeepMRestToDiscard(6, 2),),  # ハプウ
    "sm6-102": (SearchDeckForBasicEnergyAttachToTarget(2),),  # ビーストリング(サイド3-4枚条件・UB限定はlegal_actions._item_actionsでゲート済み)
    # ウルトラスペース(sm6-115)・ヒートファクトリー◇(sm8-178)も同じくSTADIUM_ABILITY_EFFECTS経由で対応済み。
    # ---- WCS2019 3位 ボルケニオン/レシラム&リザードンGX(Blaine Hill選手) ----
    "sm10-175": (SearchDeckMultiCriteria(("trainer", "trainer")),),  # ブルーの探索(特性所持ポケモン不在の条件はlegal_actions._supporter_actionsでゲート済み)
    "sm5-153": (SearchDiscardForSupporterOrStadiumToHand(2),),  # ルザミーネ(通常版)
    "sm8-184": (RemoveOneActiveStatusCondition(),),  # ミックスハーブ(1枚使用時: 特殊状態を1つ選んで治す。2枚同時使用の効果はTRAINER_PAIRED_EFFECTSに登録済み)
    "sm11-198": (HealTarget(50),),  # グレートポーション
    "sm75-60": (DiscardCardsFromHand(2), SearchDeckForBasicEnergyToHand(4, energy_type="Fire")),  # 火打石
    "sm10-170": (SearchDeckForBasicEnergyToHand(1, bonus_count_if_second_first_turn=3),),  # エネルギースピナー
    # 無人発電所(sm10-183、GX/EXの特性を封じる)・フラダリラボ(sm6-111、どうぐ無効化)は
    # engine/continuous.py経由で対応済み。戒めの祠(sm7-143、番の合間にGX/EXへダメカン)は
    # rules_engine._apply_between_turns_stadium_effects経由で対応済み(TRAINER_EFFECTSへの登録は不要、
    # スタジアムは登録なしでもPlayStadiumできるため)。
    # ---- WCS2019 4位 レシラム&リザードンGX(Tord Reklev選手) ----
    "sm3-124": (FlipCoinThenChooseOwnPokemonReturnToHand(),),  # スーパーポケモン回収
    "sm5-132": (ShuffleSupportersFromDiscardIntoDeck(2),),  # ともだちてちょう(SM版)
    # ---- WCS2018 優勝 ゾロアーク/ダストダス(Robin Schulz選手) ----
    "xy10-105": (BothPlayersShuffleHandIntoDeckThenDrawByPrizes(),),  # N(手札を山札に混ぜてシャッフル。イオンとは別効果)
    "xy8-134": (SearchDeckForBasicExOrThreeBasicToBench(),),  # プラターヌ博士の贈り物(Brigette): たねポケモンEX1枚 または たねポケモン(EX以外)3枚
    "sm3-115": (ForceOpponentSwitchChosenBenchThenSwitchOwnActive(),),  # グズマ(SM版): 相手のベンチを選んで入れ替え、できたら自分のバトルポケモンも選んだベンチと入れ替える
    "xy9-107": (DiscardHandThenDraw(7),),  # プラターヌ博士(Professor Sycamore)
    "xy1-116": (InstantEvolveAnyOwnPokemonFromDeck(),),  # しんかのおこう(Evosoda)
    "sm2-125": (DiscardChosenFieldToolsOrStadium(),),  # かるいし(Field Blower)
    "sm2-130": (ChooseOneDiscardPokemonToHandOrThreeIntoDeck(),),  # レスキュータンカ(Rescue Stretcher): 手札に1枚 か 山札に3枚戻す、を選ぶ(target_bench_index None/0)
    "sm2-124": (DiscardChosenOpponentSpecialEnergy(),),  # つよいひっぱりハンマー(Enhanced Hammer)
    # タウンマップ(xy8-150)は自分のサイドを公開するだけの情報効果で、このシミュレーターには
    # プレイヤー間の情報非対称性が無いため実質的な効果を持たない(場に出せるが効果はなし)。
    # パラレルシティ(xy8-145)はeffects/primitives._apply_continuous_damage_modifiers経由で対応済み
    # (v1簡略版: 向きは常にスタジアムを出したプレイヤーを守る方向に固定、ベンチ制限の向きは未対応)。
    # ---- WCS2018 2位 カラマネロ(Jeff Kolenc選手) ----
    "sm1-122": (DrawUpTo(6, bonus_count_if_own_first_turn=8),),  # リーリエ(SM1版、sm5-125と同じ効果)
    "xy9-102": (LookTopNAttachBasicEnergyToChosenBench(6),),  # マックスげんき(Max Elixir)
    # ---- WCS2018 4位 レックウザGX(Pedro Eugenio Torres選手) ----
    "xy8-149": (ShuffleFromDiscardIntoDeck(3),),  # すごいつりざお(Super Rod)
    "sm3-114": (BothPlayersSwitchActiveEachChoosesOwn(),),  # あなぬけのヒモ(Escape Rope、両者入れ替え)
    # ---- WCS2017 優勝 サーナイトGX(Diego Cassiraga選手) ----
    "xy7-75": (BlockAllAbilitiesUntilOpponentTurnEnds(),),  # Hex Maniac
    "sm3-112": (ReturnDamagedOwnPokemonToHand(),),  # アセロラ(Acerola)
    "xy6-110": (SearchDiscardForSupporterToHand(1),),  # バトルサーチャー(VS Seeker)
    "sm1-129": (EvolveOwnBasicDirectlyFromHand(),),  # ふしぎなアメ(Rare Candy)
    # ---- WCS2017 2位 グソクムシャGX(Naoto Suzuki選手) ----
    "xy5-141": (SearchDeckAnyCardToHand(2),),  # Teammates(発動条件はlegal_actions._TEAMMATES_IDでゲート: 相手の直前の番に自分のポケモンがきぜつしていたとき)
    "xy8-140": (SearchDeckForPokemonToHand(1, min_retreat_cost=3),),  # ヘビーボール(Heavy Ball)
    # ---- WCS2017 4位 グソクムシャGX/ダストダス(Sho Sasaki選手) ----
    "sm2-129": (MoveChosenBenchEnergyToActive(max_count=1, exact=True),),  # マルチつけかえ(Multi Switch): ベンチのエネルギーを1枚(プレイヤーが選ぶ)バトルポケモンに移す
    # ---- WCS2016 優勝 メガタブンネEX(Shintaro Ito選手) ----
    "xy4-91": (ReturnOwnPokemonToHandDiscardingAttached(),),  # AZ
    "xy7-78": (ForceOpponentSwitchChosenBench(),),  # フラダリ(Lysandre)
    "xy4-110": (DiscardChosenFieldToolOrSpecialEnergy(),),  # クセロシキ(Xerosic)
    "xy2-93": (HealTargetAndClearStatus(60),),  # ポケモンセンターのお姉さん(Pokémon Center Lady)
    "xy6-92": (LookTopNChooseByCriteriaToHand(4, 1, "trainer"),),  # トレーナーズポスト(Trainers' Mail)
    "xy6-86": (AttachEnergyFromDiscardToOwnPokemon(energy_type=None, count=1, target_subtype="MEGA"),),  # メガターボ(Mega Turbo)
    "xy2-97": (DiscardAllOpponentTools(),),  # びっくりメガホン(Startling Megaphone)
    # ---- WCS2016 2位 ゲッコウガBREAK(Cody Walinski選手) ----
    "xy7-69": (BothPlayersShuffleHandAndDrawAsymmetric(6, 3),),  # エリートトレーナー(Ace Trainer、発動条件はlegal_actions._ACE_TRAINER_IDでゲート)
    "xy8-136": (SearchDiscardForBasicEnergyToHand(4),),  # 釣り人(Fisherman)
    "xy11-104": (RemoveAllAttackEffectsBothSides(),),  # ポケモンレンジャー(ワザの効果を取り除く。特殊状態は取り除かない=公式裁定)
    "xy5-125": (SearchDeckForPokemonToHand(1, pokemon_type="Water"),),  # ダイブボール(Dive Ball)
    "xy7-76": (SearchDeckForPokemonToHand(1, max_hp=90),),  # レベルボール(Level Ball)
    # ---- WCS2016 3位 ラフレシアトゥールボックス(Samuel Hough選手) ----
    "xy11-103": (SwapOwnPokemonIdentityWithDeckBasic(),),  # ニンジャごっこ(Ninja Boy)
    # 巨大植物の森(xy7-74、くさポケモンは出したターンでも進化できる)はlegal_actions._can_evolve_target
    # 経由で対応済み(発動アクションを持たないため登録しない)。
    # ---- WCS2016 4位 ビークイン/イベルタル(Ross Cawthon選手) ----
    "g1-70": (SearchDiscardForPokemonOfTypeToHand(2, "Grass"),),  # 活力剤(Revitalizer)
    "xy11-105": (ShuffleSpecialEnergyFromDiscardIntoDeck(2),),  # スペシャルチャージ(Special Charge)
    # ---- WCS2015 優勝 カメックス(Jacob Van Wagner選手) ----
    "xy5-124": (SearchDiscardForPokemonOfTypeToBench("Water"), Draw(5)),  # アオギリの切り札(Archie's Ace in the Hole、発動条件はlegal_actions._ARCHIE_ACE_IN_THE_HOLE_IDでゲート)
    "bw10-84": (DiscardHandThenDraw(7),),  # アララギ博士(Professor Juniper。プラターヌ博士(Professor Sycamore)とは別人)
    "bw9-103": (DiscardCardsFromHand(2), SearchDiscardForBasicEnergyToHand(4)),  # スーパーエネルギー回収(Superior Energy Retrieval)
    "bw7-137": (DiscardCardsFromHand(2), SearchDeckAnyCardToHand(1)),  # パソコン通信(Computer Search)
    # ---- WCS2015 2位 ガマゲロゲEX/クロバット(Mees Brenninkmeijer選手) ----
    "bw5-96": (BothPlayersShuffleHandIntoDeckThenDrawByPrizes(),),  # N(xy10-105と同名別収録)
    "bw8-118": (ShuffleHandDrawPerTotalBenchedPokemon(),),  # アクロマ(Colress)
    "bw8-123": (InflictStatusOnDefender("poisoned"), FlipCoinThen(heads=(InflictStatusOnDefender("asleep"),))),  # どくさいみん光線(Hypnotoxic Laser)
    "xy3-100": (FlipCoinThen(heads=(ReturnOwnBenchedPokemonAndAttachedToHand(),)),),  # スーパーポケモン回収(Super Scoop Up)
    # タチワキシティジム(bw8-126、どく状態のポケモンにダメカン2個追加)はengine.turn_manager.run_pokemon_checkup
    # 経由で対応済み(発動アクションを持たないため登録しない)。
    # ---- WCS2015 3位 ガマゲロゲEX/クロバット(Igor Costa選手) ----
    "xy4-97": (AttachToolToOpponentActiveEX(),),  # ヘッドノイザー(Head Ringer、発動条件はlegal_actions._HEAD_RINGER_IDでゲート)
    # ---- WCS2015 5位 オーロット/ゲンガーEX(Sean Foisy選手) ----
    # v1簡略版: 実際は「たねポケモン1枚を、1回進化させた状態で山札から出す」効果だが、
    # InstantEvolveAnyOwnPokemonFromDeckを再利用し、対象自動選択で1体を進化させる形に簡略化。
    # 実カードは自分の番の最初(手札0枚時)にも使えるが、この簡略実装は通常の進化タイミング
    # (山札を経由する疑似進化)扱いとなるため、1ターン目の使用制限が実カードと異なる点に注意。
    "xy6-94": (InstantEvolveAnyOwnPokemonFromDeck(),),  # ミツル(Wally)
    "xy6-93": (DiscardCardsFromHand(2), SearchDeckForPokemonToHand(1)),  # ハイパーボール(Ultra Ball)
    # ---- WCS2015 6位 ナイトマーチ(Martin Janous選手) ----
    "xy5-127": (BothPlayersSwitchActiveEachChoosesOwn(),),  # あなぬけのヒモ(Escape Rope、両者入れ替え)
    "xy6-88": (SearchDiscardForBasicPokemonToBench(),),  # げんきのかけら(Revive)
    # ---- WCS2015 7位 ドンファン(Simon Narode選手) ----
    "xy3-95": (SearchDeckMultiCriteria(("fighting_pokemon", "item")),),  # コルニ(Korrina)
    "xy5-136": (SearchDeckForSameNamePokemonToHand(),),  # リピートボール(Repeat Ball)
    # ---- WCS2015 8位 フレフワン/ガマゲロゲ(Tito Santoso選手) ----
    "xy2-94": (SearchDeckForPokemonToHand(count=2, only_basic=True),),  # ポケモンだいすきクラブ(Pokémon Fan Club)
    "xy2-96": (ShuffleFromDiscardIntoDeck(5),),  # せいなるはい(Sacred Ash)
    # ファイティングスタジアム(xy3-90、闘ポケモンのワザは相手のバトル場のEXに+20、両プレイヤー)は
    # engine.continuous.fighting_stadium_ex_bonus_damage経由で対応済み(発動アクションを持たないため
    # 登録しない)。きあいのタスキ(xy3-91、満タンHPからきぜつする一撃を残りHP10で耐える)は
    # effects.primitives._SURVIVE_LETHAL_HIT_TOOLS経由で対応済み(同様に発動アクションを持たないため
    # 登録しない)。みがわりロボ(xy4-102、グッズを「30HPの無色たねポケモン」として場に出す特殊カード)は
    # cards.card_db.ROBO_SUBSTITUTE_POKEMON_ID(合成カードID)+engine.legal_actions/rules_engineの
    # 専用ハンドリング経由で対応済み(TRAINER_EFFECTSには登録しない、PlayBasicPokemon経由で場に出す)。
    # ---- WCS2014 優勝 ビリジオンEX/ゲノセクトEX(Andrew Estrada選手) ----
    "xy1-122": (DiscardHandThenDraw(7),),  # プラターヌ博士(Professor Sycamore)
    "bw7-134": (SearchDeckMultiCriteria(("trainer",)),),  # フウロ(Skyla)
    "bw9-102": (SearchDiscardForSubtypeToHand("Team Plasma"),),  # ダークトリニティ(Shadow Triad)
    "xy3-89": (ChooseOwnPokemonThenMoveOneBasicEnergyToAnother(),),  # エネルギーつけかえ(Energy Switch)
    "bw5-94": (DiscardChosenOpponentSpecialEnergy(),),  # 改造ハンマー(Enhanced Hammer)
    "bw6-116": (DiscardChosenFieldToolsOrStadium(include_stadium=False),),  # どうぐハンター(Tool Scrapper)
    "xy1-123": (SearchDeckForBasicEnergyToHand(2),),  # はかせのてがみ(Professor's Letter)
    "bw3-95": (ShuffleFromDiscardIntoDeck(3),),  # すごいつりざお(Super Rod)
    "bw8-119": (
        SearchDeckForCardNameAttachToTarget("Plasma Energy", required_subtype="Team Plasma"),
    ),  # アクロママシーン(Colress Machine)
    # タウンマップ(bw7-136、サイドを表向きにする)はこのシミュレーターでは非公開情報を
    # 扱っていないため実質効果なし(未登録)。スカイアローブリッジ(bw4-91、たねポケモンの
    # にげるコスト-1、両プレイヤー)はengine.energy.effective_retreat_cost_count経由で対応済み。
    # Gブースター(bw10-92、ゲノセクトEXについていれば専用ワザ「G Booster」を追加で使えるどうぐ)は
    # どうぐ由来のワザ追加という新しい仕組みが必要なため未実装(v1簡略版。どうぐ自体は通常のどうぐ
    # として装備できるが、追加ワザは使えない)。
    # ---- WCS2014 2位 ビリジオンEX/ゲノセクトEX(Igor Costa選手) ----
    "bw8-117": (DrawUpTo(4),),  # じてんしゃ(Bicycle)
    # ---- WCS2014 3位 フレフワン/ガルーラEX(Michikazu Tsuda選手) ----
    "xy1-127": (ShuffleHandIntoDeckThenDraw(5),),  # サナ(Shauna)
    "bw11-109": (DrawUpTo(6),),  # ベル(Bianca)
    "bw2-94": (HealFullyAndDiscardAllEnergy(),),  # まんたんのくすり(Max Potion)
    "bw4-89": (SearchDeckForPokemonToHand(1, max_hp=90),),  # レベルボール(Level Ball)
    "bw4-88": (SearchDeckForPokemonToHand(1, min_retreat_cost=3),),  # ヘビーボール(Heavy Ball)
    "bw8-128": (DiscardCardsFromHand(2), SearchDiscardForTrainerToHand()),  # ダウジングマシン(Dowsing Machine)
    # フェアリーガーデン(xy1-117、フェアリーエネルギーがついていればにげるコスト0、両プレイヤー)は
    # engine.energy.effective_retreat_cost_count経由で対応済み(発動アクションを持たないため登録しない)。
    # ---- WCS2014 4位 ビリジオンEX/ゲノセクトEX(Paulo Silva選手) ----
    "bw8-120": (BothPlayersSwitchActiveEachChoosesOwn(),),  # あなぬけのヒモ(Escape Rope、両者入れ替え)
    # ---- WCS2014 6位 イベルタル/ダストダス(Chase Moloney選手) ----
    "bw5-93": (
        AttachEnergyFromDiscardToOwnPokemon(energy_type="Darkness", count=1, bench_only=True, target_type="Darkness"),
    ),  # ダークパッチ(Dark Patch、対象はベンチの悪ポケモン限定)
    # ポケモンいれかえ(xy0-38)は既にTRAINER_EFFECTSに登録済み(SwitchActiveWithBench)。
    "bw5-99": (RevealUntilSupporterToHand(),),  # ランダムレシーバー(Random Receiver): 山札の上から最初に出たサポートを手札に加える(好きなサポートを選べるわけではない)
    # ---- WCS2014 7位 プラズマルギア/デオキシス(Vincent Azzolin選手) ----
    "xy1-125": (FlipCoinThen(heads=(Draw(3),)),),  # ローラースケート(Roller Skates)
    "bw9-105": (SearchDeckForSubtypePokemonToHand("Team Plasma"),),  # プラズマ団のモンスターボール(Team Plasma Ball)
    "xy2-92": (ShuffleSupportersFromDiscardIntoDeck(2),),  # ともだちてちょう(Pal Pad)
    # ---- 2026年 PJCS2026/CL2026各地 サンプルデッキ追加分 ----
    "mp1-15": (SearchDeckForPokemonToHand(count=1, no_rule_box=True),),  # ポケパッド(ルールを持つポケモンを除く)
    "sv6-143": (LookTopNChooseByCriteriaToHand(n=7, m=2, criteria="grass_pokemon_or_basic_grass_energy"),),  # むしとりセット(Bug Catching Set)
    "sv6-155": (SearchDiscardForPokemonOrEnergy(count=3, no_rule_box=True),),  # スイレンのお世話(Lana's Aid): ルールを持たないポケモンと基本エネルギーを合計3枚まで
    "m2-77": (SearchDeckMultiCriteria(("basic_pokemon", "stage1_pokemon", "stage2_pokemon")),),  # ヒカリ(Dawn)
    "sv10-176": (SearchDeckMultiCriteria(("trainer",)),),  # ロケット団のラムダ(Team Rocket's Petrel)
    "sv8-189": (SearchDeckForSubtypePokemonToHand("Tera"),),  # テラスタルオーブ(Tera Orb)
    "m3-pyuru": (DiscardAnyHandCardsOptional(), DrawUpTo(5)),  # ピュール
    "me2pt5-200": (SwitchActiveWithBench(), DrawUpTo(5)),  # サーファー(Surfer)
    "mbd-15": (
        AttachEnergyFromDiscardToOwnPokemon(energy_type="Psychic", count=1, bench_only=True, target_type="Psychic"),
    ),  # ワンダーパッチ実カードテキスト(公式サイトHTML確認): "自分のトラッシュから「基本[超]エネルギー」を
    # 1枚選び、ベンチの[超]ポケモンにつける。"(エネルギーの種類・対象のポケモンタイプ、
    # どちらも超タイプ限定。公式サイトのテキストはエネルギーアイコンを画像(<span class="icon-psychic">)で
    # 表現しているため、単純なテキスト抽出では見落としやすい)
    "me4-82": (OpponentHandToBottomOfDeckThenDraw(3),),  # スペシャルレッドカード(使用条件はlegal_actionsでゲート済み)
    "sv8-170": (SearchDeckForPokemonToHand(count=3, required_subtypes=("ex",)),),  # シアノ(Cyrano): "Pokémon ex"(現行のex。旧GX/EXは含まない)
    "sv8-183": (SearchDiscardForSupporterToHand(count=2),),  # ミラクルインカム(Miracle Headset、ACE SPEC)
    "me3-72": (SearchDeckForBasicEnergyToHand(count=1),),  # エネルギー転送(Energy Search)
    "sv10-178": (SearchDeckMultiCriteria(("team_rocket_supporter",)),),  # ロケット団のレシーバー(Team Rocket's Transceiver)
    "rsv10pt5-83": (  # クラウン(Harlequin)
        FlipCoinThen(
            heads=(BothPlayersShuffleHandAndDrawAsymmetric(own_count=5, opponent_count=3),),
            tails=(BothPlayersShuffleHandAndDrawAsymmetric(own_count=3, opponent_count=5),),
        ),
    ),
    "m1l-59": (SearchDeckMultiCriteria(("fighting_pokemon_or_basic_fighting_energy",)),),  # ファイトゴング
    "m3-73": (SearchDiscardForPokemonOrEnergy(count=4, card_type="Fighting"),),  # タラゴン(公式: {闘}ポケモンと「基本{闘}エネルギー」を合計4枚まで)
    "sv8a-162": (  # アオキの手際: 手札を全てトラッシュしてから3種類を1枚ずつ探す
        DiscardHandThenDraw(0),
        SearchDeckMultiCriteria(("any_pokemon", "supporter", "basic_energy")),
    ),
    "sv10-171": (  # ロケット団のアテナ(Team Rocket's Ariana)
        DrawUpToBonusIfAllOwnPokemonNamePrefix(base=5, bonus=8, name_prefix="Team Rocket's"),
    ),
    "sv10-177": (  # ロケット団のランス(Team Rocket's Proton、先攻1ターン目に使える特例はlegal_actions._SUPPORTER_TURN1_EXCEPTION_IDSで対応済み)
        SearchDeckMultiCriteria(("team_rocket_basic_pokemon", "team_rocket_basic_pokemon", "team_rocket_basic_pokemon")),
    ),
    "sv8pt5-127": (LookTopNChooseByCriteriaToHand(n=4, m=4, criteria="supporter"),),  # ロトりぼう(Roto-Stick)実カード
    # テキスト: "you MAY reveal ANY NUMBER of Supporter cards you find there"(2026-09-03、ユーザー指摘
    # 「何を何枚手札に加えるのか選択できるはず」で発覚。以前は見つかった分を自動で全て回収するv1簡略版だった。
    # m=4はnと同値にすることで実質上限なし(top4のうち該当は最大4枚しかありえないため)にする狙い)。
    "m3-75": (  # メイのはげまし(自分の残りサイドが相手より多いときのみ使用可、legal_actionsでゲート)
        AttachEnergyFromDiscardToOwnPokemon(energy_type=None, count=2, self_only=False, target_subtype="Stage 2"),
    ),
    "sv6pt5-64": (OpponentDiscardHandDownTo(count=3),),  # クセロシキのたくらみ(Xerosic's Machinations)
    "sv5k-69": (  # マツバの確信(手札を1枚トラッシュしなければ使えない、legal_actionsでゲート)
        DiscardCardsFromHand(count=1),
        DrawPerOpponentBenchCount(),
    ),
    "me5-78": (DiscardChosenNonRuleBoxPokemonThenDrawPerCount(max_count=2, draw_per_count=3),),  # ムク(Gwynn)
    "zsv10pt5-83": (MoveChosenBenchEnergyToActive(max_count=2),),  # Nの筋書き(N's Plan)
    "sv10-174": (SwitchOwnActiveWithBenchThenForceOpponentSwitch(),),  # ロケット団のサカキ(Team Rocket's Giovanni)
    "sv10-170": (BothPlayersShuffleHandAndDrawAsymmetric(own_count=5, opponent_count=3),),  # ロケット団のアポロ(Team Rocket's Archer、使用条件はlegal_actionsでゲート)
    "sv8pt5-113": (SwitchActiveWithBenchOrExVDamageBonusThisTurn(),),  # スグリ(Kieran)
    # ---- 2026年 レギュレーション優先実装(PJCS2026/CL2026) 追加分 ----
    "m2-73": (HealOwnActiveIfEnergyCountAtLeast(amount=80, min_energy=3),),  # ジャンボアイス
    "me1-132": (HealTargetThenReturnAttachedEnergyToHandIfHealed(),),  # ミツルの思いやり(Wally's Compassion、対象はメガシンカexポケモン限定、legal_actionsでゲート)
    "me2pt5-255": (ExDamageBonus40ThisTurn(),),  # からておうの稽古(Black Belt's Training)
    "sv5k-68": (RevealOpponentHandThenDiscardChosen(count=2, only_item=True),),  # ビワ
    "sv7-135": (ChooseUpToNOwnBenchedThenAttachDiscardEnergyToEach(count=2, required_type="Colorless"),),  # ガラスのラッパ(Glass Trumpet、テラスタルポケモンが場にいる条件はlegal_actionsでゲート)
    "sv9-146": (SearchDeckUpToTwoBasicOrOneEvolutionToHand(),),  # タケシのスカウト(Brock's Scouting)
}

try:  # scripts/generate_effects.py が英語原文から自動生成した効果(手書きの登録が無いものだけ使う)
    from effects.generated_effects import GENERATED_ATTACK_EFFECTS
except ImportError:  # 未生成の環境
    GENERATED_ATTACK_EFFECTS = {}
try:
    from effects.generated_effects import GENERATED_TRAINER_EFFECTS
except ImportError:
    GENERATED_TRAINER_EFFECTS = {}
try:
    from effects.generated_effects import GENERATED_AFTER_ATTACK_TRIGGER_EFFECTS
except ImportError:
    GENERATED_AFTER_ATTACK_TRIGGER_EFFECTS = {}
try:
    from effects.generated_effects import GENERATED_TRAINER_GATES
except ImportError:
    GENERATED_TRAINER_GATES = {}


import os as _os

try:  # scripts/generate_abilities.py が英語原文から自動生成した特性の効果(手書きの登録が無いものだけ使う)
    if _os.environ.get("POKECA_IGNORE_GENERATED_ABILITIES"):
        raise ImportError
    from effects.generated_abilities import (
        GENERATED_ABILITY_EFFECTS,
        GENERATED_BECOME_ACTIVE_TRIGGER_EFFECTS,
        GENERATED_DISCARD_ABILITY_EFFECTS,
        GENERATED_ENERGY_ATTACH_TRIGGER_EFFECTS,
        GENERATED_ENTER_BENCH_TRIGGER_EFFECTS,
        GENERATED_EVOLVE_TRIGGER_EFFECTS,
        GENERATED_MANDATORY_ENERGY_ATTACH_TRIGGER_EFFECTS,
        GENERATED_UNLIMITED_ABILITY_IDS,
    )
except ImportError:  # 未生成の環境/生成中
    GENERATED_ABILITY_EFFECTS = {}
    GENERATED_BECOME_ACTIVE_TRIGGER_EFFECTS = {}
    GENERATED_DISCARD_ABILITY_EFFECTS = {}
    GENERATED_ENERGY_ATTACH_TRIGGER_EFFECTS = {}
    GENERATED_ENTER_BENCH_TRIGGER_EFFECTS = {}
    GENERATED_EVOLVE_TRIGGER_EFFECTS = {}
    GENERATED_MANDATORY_ENERGY_ATTACH_TRIGGER_EFFECTS = {}
    GENERATED_UNLIMITED_ABILITY_IDS = frozenset()


def _generated_trigger(table: dict, card_id: str) -> tuple:
    """生成されたトリガー効果({カードID: {特性名: スクリプト}})から、そのカードのスクリプトを取り出す(トリガーは1カード1つ)。"""
    by_name = table.get(card_id)
    if not by_name:
        return ()
    return next(iter(by_name.values()))


def get_attack_script(card_id: str, attack_name: str) -> tuple[Effect, ...]:
    script = ATTACK_EFFECTS.get(card_id, {}).get(attack_name)
    if script is not None:
        return script
    return GENERATED_ATTACK_EFFECTS.get(card_id, {}).get(attack_name, ())


def get_ability_script(card_id: str, ability_name: str) -> tuple[Effect, ...]:
    script = ABILITY_EFFECTS.get(card_id, {}).get(ability_name)
    if script is not None:
        return script
    return GENERATED_ABILITY_EFFECTS.get(card_id, {}).get(ability_name, ())


def get_trainer_script(card_id: str) -> tuple[Effect, ...]:
    script = TRAINER_EFFECTS.get(card_id)
    if script is not None:
        return script
    return GENERATED_TRAINER_EFFECTS.get(card_id, ())


# 「4枚同時使用」カード(ミッシングクローバー/カルテットストーン)の4枚同時使用時の効果(1枚だけ使う場合はTRAINER_EFFECTSの効果)。effects/era_tools_j.install_quadsが登録する。
TRAINER_QUAD_EFFECTS: dict[str, tuple] = {}


def get_trainer_quad_script(card_id: str) -> tuple:
    return TRAINER_QUAD_EFFECTS.get(card_id, ())


def get_trainer_paired_script(card_id: str) -> tuple[Effect, ...]:
    """「2枚同時使用」カード(カスタムキャッチャー等)の2枚同時使用時の効果。"""
    return TRAINER_PAIRED_EFFECTS.get(card_id, ())


def get_enter_bench_trigger_script(card_id: str) -> tuple[Effect, ...]:
    script = ENTER_BENCH_TRIGGER_EFFECTS.get(card_id)
    if script is not None:
        return script
    return _generated_trigger(GENERATED_ENTER_BENCH_TRIGGER_EFFECTS, card_id)


def get_level_up_trigger_script(card_id: str) -> tuple[Effect, ...]:
    return LEVEL_UP_TRIGGER_EFFECTS.get(card_id, ())


def get_become_active_trigger_script(card_id: str) -> tuple[Effect, ...]:
    """「ベンチからバトル場に出たとき、してもよい」系の特性(ヒードランGXの「Burning Road」等)。"""
    script = BECOME_ACTIVE_TRIGGER_EFFECTS.get(card_id)
    if script is not None:
        return script
    return _generated_trigger(GENERATED_BECOME_ACTIVE_TRIGGER_EFFECTS, card_id)


def get_evolve_trigger_script(card_id: str) -> tuple[Effect, ...]:
    """「手札から進化させて出したとき、してもよい」系の特性(リザードンexの「インフェルノリボーン」等)。"""
    script = EVOLVE_TRIGGER_EFFECTS.get(card_id)
    if script is not None:
        return script
    return _generated_trigger(GENERATED_EVOLVE_TRIGGER_EFFECTS, card_id)


def get_energy_attach_trigger_script(card_id: str) -> tuple[Effect, ...]:
    """「手札からエネルギーをつけたとき、してもよい」系の特性(カラマネロEXの「Hyper Hypnosis」等)。"""
    script = ENERGY_ATTACH_TRIGGER_EFFECTS.get(card_id)
    if script is not None:
        return script
    return _generated_trigger(GENERATED_ENERGY_ATTACH_TRIGGER_EFFECTS, card_id)


def get_mandatory_energy_attach_trigger_script(card_id: str) -> tuple[Effect, ...]:
    """「手札からエネルギーをつけたとき」の強制発動特性(ホエルオーEXの「Water Veil」等)。"""
    script = MANDATORY_ENERGY_ATTACH_TRIGGER_EFFECTS.get(card_id)
    if script is not None:
        return script
    return _generated_trigger(GENERATED_MANDATORY_ENERGY_ATTACH_TRIGGER_EFFECTS, card_id)


def get_stadium_ability_script(card_id: str) -> tuple[Effect, ...]:
    return STADIUM_ABILITY_EFFECTS.get(card_id, ())


def get_discard_ability_script(card_id: str) -> tuple[Effect, ...]:
    """トラッシュにいる状態で発動する特性(ギラティナ(smp-SM151)の「Distortion Door」等)。
    UseDiscardAbilityアクションで、ベンチに出した直後に実行する。"""
    script = DISCARD_ABILITY_EFFECTS.get(card_id)
    if script is not None:
        return script
    return _generated_trigger(GENERATED_DISCARD_ABILITY_EFFECTS, card_id)


def has_discard_ability(card_id: str) -> bool:
    """トラッシュ発動型の特性を持つか(タマタマ「Propagation」のように、スクリプトが空の手書きの特性もある)。"""
    return card_id in DISCARD_ABILITY_EFFECTS or bool(_generated_trigger(GENERATED_DISCARD_ABILITY_EFFECTS, card_id))


def discard_ability_dest(card_id: str) -> str:
    """トラッシュ発動型の特性で、そのポケモン自身が行く先: "bench"/"hand"/"deck_bottom"/"coin_bench"。"""
    if card_id in DISCARD_ABILITY_TO_HAND_CARD_IDS:
        return "hand"
    for effect in get_discard_ability_script(card_id):
        if getattr(effect, "discard_dest", False):
            return effect.kind
    return "bench"


ENTER_BENCH_TRIGGER_EFFECTS: dict[str, tuple[Effect, ...]] = {
    "xy6-40": (MoveDamageCountersBetweenOpponentPokemon(3),),  # アブソル: Cursed Eyes(手札からベンチに出したとき、相手のポケモン1匹から別の相手のポケモンにダメカンを3個移してよい)
    "pl1-47": (DamageCounterOnChosenOpponentPokemon(1),),  # Crobat G: Flash Bite
    "dp6-43": (DrawUpTo(7),),  # Uxie: Set Up
    "dp6-19": (TimeWalkSwapPrizeForPokemon(),),  # Azelf: Time Walk
    "sv8-56": (DiscardStadiumInPlay(),),  # Chien-Pao: Snow Sink
    "swsh9-40": (SearchDeckMultiCriteria(("supporter",)),),  # Lumineon V: Luminous Sign
    "swsh3-104": (DrawUpTo(6),),  # Crobat V: Dark Asset
    "swsh7-76": (DiscardStadiumInPlay(),),  # Pumpkaboo: Pumpkin Pit
    "swsh1-117": (DamageCounterOnChosenOpponentPokemon(1),),  # Galarian Zigzagoon: Headbutt Tantrum
    "sm10-57": (DiscardHandThenDraw(6),),  # Dedenne-GX: Dedechange
    "sm11-86": (DiscardOpponentActiveSpecialEnergy(),),  # Giratina: Dimension Breach
    "sm2-60": (SearchDeckMultiCriteria(("supporter",)),),  # タプ・レレGX: Wonder Tag
    "sm4-70": (DiscardChosenOpponentSpecialEnergy(),),  # カミツルギGX: Slice Off
    "sm7-109": (DiscardTopOfOwnDeck(3), AttachEnergyFromDiscardToSelf(count=1)),  # レックウザGX: Stormy Winds
    "sm2-47": (MoveChosenOwnEnergyToSelfThenSwitchActive("Lightning"),),  # カプ・コケコGX: Aero Trail
    "sm7-31": (SwitchSelfToActiveThenMoveChosenOwnEnergy("Water"),),  # フリーザーGX: Legendary Ascent
    "sm35-45": (BothPlayersShuffleHandAndDrawFixed(4),),  # マーシャドー: Let Loose
    "xy6-77": (DrawUpTo(6),),  # シェイミEX: Set Up
    "xy7-36": (SearchDeckForPokemonToHand(3, required_subtypes=("EX",), exclude_name="Hoopa-EX"),),  # フーパEX: Scoundrel Ring(Hoopa-EX以外のポケモンEXを3枚まで)
    "bw10-60": (SearchDeckMultiCriteria(("supporter",)),),  # ジラーチEX: Stellar Guidance
    "sv1-118": (DistributeDamageCountersFreely(2, bench_only=True, max_per_target=1),),  # ルチャブル: Flying Entry
    "me3-62": (SearchDeckMultiCriteria(("supporter",)),),  # ニャースex: Last-Ditch Catch
    "sv8pt5-54": (  # ガチグマアカツキ: Battle-Hardened(基本闘エネルギー2枚まで)
        AttachEnergyFromHandToSelf(energy_type="Fighting"),
        AttachEnergyFromHandToSelf(energy_type="Fighting"),
    ),
    "mc-77": (SwitchSelfToActiveThenMoveChosenOwnEnergy(),),  # テツノイサハex: ラピッドバーニア(タイプ問わず全エネルギー対象)
}

# ---- 手動で使用可能な特性(自分の番に1回、能動的に使う) ----
ABILITY_EFFECTS["sv8pt5-80"] = {  # ノココッチ(Dudunsparce)
    # 実カードテキスト: "...If you drew any cards in this way, shuffle this Pokemon and all
    # attached cards into your deck."(山札が0枚で1枚も引けなかった場合はシャッフルしない、
    # という条件が無条件Draw+ShuffleSelfIntoDeckでは欠落していたため修正、2026-08-22)。
    "Run Away Draw": (DrawThenShuffleSelfIntoDeckIfDrew(count=3),),
}
ABILITY_EFFECTS["sv10a-9"] = {  # ロケット団のワナイダー: チャージアップ
    "チャージアップ": (AttachEnergyFromDiscardToOwnPokemon(energy_type=None, count=1, self_only=True),),
}
ABILITY_EFFECTS["me1-104"] = {  # メガガルーラex: Run Errand(バトル場にいるときのみ発動可、legal_actions.py側でzone==ACTIVEを強制。2枚引く)
    "Run Errand": (Draw(2),),
}
ABILITY_EFFECTS["sv9-24"] = {  # バシャーモex: Seething Spirit(トラッシュから基本エネルギー1枚を自分のポケモンにつけてよい。
    # トラッシュに複数タイプの基本エネルギーがある場合、どれをつけるかプレイヤーが選べる必要がある
    # (以前はAttachEnergyFromDiscardToOwnPokemonを使っており、トラッシュの並び順で機械的に最初に
    # 見つかった1枚を自動選択していた。2026-08-25ユーザー報告「トラッシュにエネルギーの種類が
    # 複数あるときにどれを選ぶか選択できません」で発覚し、選択式のAttachEnergyFromDiscardToOwnPokemonWithChoice
    # に切り替えた)
    "Seething Spirit": (AttachEnergyFromDiscardToOwnPokemonWithChoice(energy_type=None, count=1),),
}
ABILITY_EFFECTS["xy1-41"] = {  # ゲッコウガ(Greninja): Water Shuriken(手札のみずエネルギーを1枚捨てて発動、条件はlegal_actionsでゲート)
    "Water Shuriken": (DiscardCardsFromHand(1, only_energy_type="Water"), DamageCounterOnChosenOpponentPokemon(3)),
}
ABILITY_EFFECTS["sm6-51"] = {  # カラマネロ(Malamar、FLI/51): Psychic Recharge(トラッシュから超エネルギー1枚をベンチのポケモンにつけてよい)
    "Psychic Recharge": (AttachEnergyFromDiscardToOwnPokemon(energy_type="Psychic", bench_only=True),),
}
ABILITY_EFFECTS["sm11-160"] = {  # アーゴヨンGX(Naganadel-GX): Ultra Conversion(手札のUltra Beastカードを1枚捨ててよく、そうしたら3枚引く)
    "Ultra Conversion": (MayDiscardHandCardThenDraw(3, card_criterion="ultra_beast"),),
}
ABILITY_EFFECTS["xy1-93"] = {  # フレフワン(Aromatisse): Fairy Transfer(1回の自分の番に何度でも使える制限解除はrules_engine._UNLIMITED_PER_TURN_ABILITY_CARD_IDS経由)
    "Fairy Transfer": (MoveEnergyBetweenOwnPokemon(energy_type="Fairy"),),
}
ABILITY_EFFECTS["sv8pt5-36"] = {  # サマヨール(Dusclops、実カードテキスト: "Once during your turn, you
    # may put 5 damage counters on 1 of your opponent's Pokémon. If you use this Ability, this
    # Pokémon is Knocked Out."。以前ATTACK_EFFECTS側に誤って重複登録されており、正しいWill-O-Wisp
    # ワザ登録を上書きしてしまっていたバグを修正、正しくABILITY_EFFECTS側に登録し直した)
    "Cursed Blast": (DamageCounterOnChosenOpponentThenSelfKnockout(5),),
}
ABILITY_EFFECTS["sv8pt5-37"] = {  # ヨノワール(Dusknoir、同上。実カードは13個)
    "Cursed Blast": (DamageCounterOnChosenOpponentThenSelfKnockout(13),),
}
# ---- 2026年 レギュレーション優先実装(PJCS2026/CL2026) 追加分 ----
ABILITY_EFFECTS["me1-3"] = {  # メガフシギバナex: Solar Transfer(1回の自分の番に何度でも使える制限解除はrules_engine._UNLIMITED_PER_TURN_ABILITY_CARD_IDS経由)
    "Solar Transfer": (ChooseOwnPokemonThenMoveOneBasicEnergyToAnother(energy_type="Grass"),),
}
ABILITY_EFFECTS["sv8pt5-11"] = {  # カミツオロチex(Hydrapple ex)
    "Ripening Charge": (AttachEnergyFromHandToChosenOwnPokemon(energy_type="Grass", heal_on_attach=30),),
}
ATTACK_EFFECTS["sv8pt5-11"] = {  # カミツオロチex(Hydrapple ex)
    "Syrup Storm": (DamagePerOwnFieldBasicEnergyTypeCountAcrossBoard(base=30, per_energy=30, energy_type="Grass"),),
}
ABILITY_EFFECTS["me3-43"] = {  # ガメノデス(Barbaracle)
    "Stone Arms": (AttachEnergyFromHandToChosenOwnPokemon(energy_type="Fighting", target_type="Fighting"),),
}
ABILITY_EFFECTS["me2pt5-105"] = {  # ルナトーン(Lunatone、「Solrockが場にいる」の発動条件はlegal_actions._ability_actions特別対応)
    "Lunar Cycle": (DiscardOwnHandBasicEnergyThenDraw(energy_type="Fighting", draw_count=3),),
}

LEVEL_UP_TRIGGER_EFFECTS: dict[str, tuple[Effect, ...]] = {
    "pl2-109": (ForceOpponentSwitchChosenBench(),),  # Luxray GL LV.X: Bright Look
    "pl3-145": (HealAllOwnSPPokemon(),),  # Garchomp C LV.X: Healing Breath
}

# 「ベンチからバトル場に出たとき、してもよい」系の特性(自分の番に、原因を問わず自分のベンチからバトル場に出たとき)。
# 発動判定はrules_engine._offer_become_active_trigger(apply_action後の差分検出)。
BECOME_ACTIVE_TRIGGER_EFFECTS: dict[str, tuple[Effect, ...]] = {
    "sm11-25": (MoveChosenOwnFireEnergyToSelf(),),  # Heatran-GX: Burning Road
}

# 「手札から進化させて出したとき、してもよい」系の特性。v1簡略版: エネルギー付与系は自分自身につける
# (「好きなように」の対象指定は未対応、SearchDeckForBasicEnergyAttachToTarget自体の既存の簡略化を踏襲)。
EVOLVE_TRIGGER_EFFECTS: dict[str, tuple[Effect, ...]] = {
    "sv3-125": (
        SearchDeckForBasicEnergyAttachFreely(3, energy_type="Fire", optional=True),
    ),  # リザードンex: インフェルノリボーン(実カードは"search your deck for up to 3 Basic Fire
    # Energy cards and attach them to your Pokémon in any way you like"。1〜3枚の任意枚数で、
    # 自分の場の好きなポケモンに分けてつけられる。以前は自分自身固定/常に3枚固定になっていた)
    "sv7-115": (SearchDeckByCriterionToHand("trainer", count=2),),  # ヨルノズク: ほうせきさがし(発動条件はrules_engineでゲート)
    "swsh1-56": (SearchDeckMultiCriteria(("trainer",)),),  # Drizzile: Shady Dealings
    "swsh1-58": (SearchDeckMultiCriteria(("trainer", "trainer")),),  # Inteleon(SSH版): Shady Dealings
    "sm2-74": (ForceOpponentSwitchChosenBench(),),  # ルガルガンGX: Bloodthirsty Eyes
    "xy4-32": (DamageCounterOnChosenOpponentPokemon(2),),  # ゴルバット(Golbat): Sneaky Bite(対象はrules_engine._TRIGGER_TARGET_KIND経由)
    "xy4-33": (DamageCounterOnChosenOpponentPokemon(3),),  # クロバット(Crobat): Surprise Bite(対象はrules_engine._TRIGGER_TARGET_KIND経由)
    "me1-55": (Draw(2),),  # ユンゲラー: Psychic Draw(このカードで進化させたとき2枚引く)
    "me1-56": (Draw(3),),  # フーディン: Psychic Draw(このカードで進化させたとき3枚引く)
    "me2pt5-287": (  # マリィのオーロンゲex: Punk Up(このカードを手札から出して進化させたとき、山札から
        # 基本あくエネルギーを最大5枚、マリィのポケモンに好きなように分けてつけてよい)
        SearchDeckForBasicEnergyAttachFreely(5, energy_type="Darkness", optional=True, target_name_prefix="Marnie's"),
    ),
}

# 「手札からエネルギーをつけたとき、してもよい」系の特性。キーはエネルギーがついたポケモンのcard_id。
# ゲノセクトEXの「Red Signal」はプラズマエネルギーを付けた場合のみ発動する条件をrules_engine側でゲートする。
ENERGY_ATTACH_TRIGGER_EFFECTS: dict[str, tuple[Effect, ...]] = {
    "xy4-58": (InflictStatusOnDefender("asleep"),),  # カラマネロEX: Hyper Hypnosis
    "bw10-11": (ForceOpponentSwitchChosenBench(),),  # ゲノセクトEX: Red Signal(プラズマエネルギー限定)
    "sm1-101": (InstantEvolveSelfFromDeck(allow_just_played=True),),  # イーブイ: Energy Evolution(つけたエネルギーと同じタイプの進化先のみ対象。Pokémon Rulings Compendium: 出したターン・先攻の最初の番でも進化できる)
}

# 「手札からエネルギーをつけたとき」の強制発動(してもよい、ではない)特性。キーは同上。
MANDATORY_ENERGY_ATTACH_TRIGGER_EFFECTS: dict[str, tuple[Effect, ...]] = {
    "xy5-38": (ClearOwnStatusConditions(),),  # ホエルオーEX: Water Veil
}

# 「各プレイヤーの番に1回、使ってもよい」スタジアム効果。UseStadiumAbilityアクションで発動する
# (通常のトレーナーズと違い手札のカードを消費せず、場に出ているスタジアム自体の効果として使う)。
STADIUM_ABILITY_EFFECTS: dict[str, tuple[Effect, ...]] = {
    "sm6-115": (SearchDeckMultiCriteria(("ultra_beast",)),),  # ウルトラスペース
    "sm9-156": (DiscardCardsFromHand(1), SearchDeckForBasicEnergyToHand(1)),  # トキワの森
    "sm11-197": (DiscardCardsFromHand(1), SearchDeckForBasicEnergyToHand(2, energy_type="Fire")),  # 巨大なカマド
    "sm8-178": (DiscardCardsFromHand(1, only_energy_type="Fire"), Draw(3)),  # ヒートファクトリー◇
    "sv3-196": (SearchDeckMultiCriteria(("pokemon_tool",)),),  # まちのポケモンショップ
    "swsh2-169": (SearchDiscardForBasicEnergyToHand(1),),  # トレーニングコート
    "pgo-68": (DiscardTopNRecoverItemsFound(3),),  # ポケストップ
    "sm2-120": (SearchDeckForBasicPokemonToBench(1, pokemon_types_any=("Water", "Fighting")),),  # せせらぎの丘(Brooklet Hill)
    "xy10-110": (DiscardCardsFromHand(1, only_energy_types_any=("Fire", "Fighting")), Draw(2)),  # 灼熱の大地(Scorched Earth)
    "xy5-137": (HealAllOwnPokemonOfType(amount=30, pokemon_types_any=("Water", "Lightning")),),  # うねりの大海(Rough Seas)
    "sv2-171": (SearchDeckForBasicPokemonToBench(1, no_rule_box=True),),  # アルタイル市/ボウルタウン(Artazon)
    "sv1-178": (FlipCoinThen(heads=(SearchDeckForPokemonToHand(1),)),),  # テーブルシティ(Mesagoza)
    "sv9-150": (SearchDiscardForBasicEnergyToHand(2, energy_type="Lightning"),),  # レビンシア(Levincia)
    "swsh7-144": (HealAllOwnPokemonOfType(amount=30, pokemon_types_any=("Metal", "Dragon")),),  # 結晶の洞窟(Crystal Cave)
    "sv10-173": (Draw(2),),  # ロケット団のファクトリー(Team Rocket's Factory、使用条件はlegal_actionsでゲート)
    "sv7-136": (InstantEvolveAnyOwnPokemonFromDeckThenChainEvolve(),),  # グランドツリー(Grand Tree、ACEスペック)
    "me4-80": (DiscardCardsFromHand(2), Draw(1)),  # プリズムタワー(Prism Tower)
    "sv10-169": (SearchDeckMultiCriteria(("marnies_pokemon",)),),  # スパイクタウンジム(Spikemuth Gym)
    "sv6pt5-54": (PutHandCardOnTopOfDeck(),),  # 夜のアカデミー(Academy at Night)
}

# トラッシュにいる状態で発動する「〜してもよい」系の特性。UseDiscardAbilityでベンチに出すと同時に発動する。
DISCARD_ABILITY_EFFECTS: dict[str, tuple[Effect, ...]] = {
    # ギラティナ(smp-SM151): Distortion Door「相手のベンチポケモン2匹に、ダメカンを1個ずつのせる」
    "smp-SM151": (DistributeDamageCountersFreely(2, bench_only=True, max_per_target=1),),
    # タマタマ(bw9-4): Propagation「トラッシュから手札に戻る」(ベンチには出ない)
    "bw9-4": (),
}

# DISCARD_ABILITY_EFFECTSのうち、ベンチに出す代わりに手札に戻るカード(タマタマの「Propagation」等)。
# ベンチ枠の空きは不要なので、engine.legal_actions._discard_ability_actionsのベンチ空きチェックを
# スキップし、engine.rules_engine._handle_use_discard_abilityで手札に戻す分岐に使う。
DISCARD_ABILITY_TO_HAND_CARD_IDS: set[str] = {"bw9-4"}

# 「2枚同時使用」カードの2枚同時使用時の効果(1枚だけ使う場合はTRAINER_EFFECTSの効果になる)。
TRAINER_PAIRED_EFFECTS: dict[str, tuple[Effect, ...]] = {
    "sm8-171": (ForceOpponentSwitchChosenBench(),),  # カスタムキャッチャー
    "sm8-184": (HealTarget(90), ClearActiveStatusConditions()),  # ミックスハーブ
    # クロススイッチャー: 相手のベンチ1匹とバトルポケモンを入れ替える。そうしたら、自分のバトルポケモンも自分の
    # ベンチ1匹(自分で選ぶ)と入れ替える(以前は入れ替え先がベンチの先頭に固定されていた)
    "swsh8-230": (ForceOpponentSwitchChosenBenchThenSwitchOwnActive(),),
    "xy9-109": (SearchDiscardAnyCardToHand(2),),  # パズル オブ タイム(Puzzle of Time)、2枚同時使用時
}

# ワザを使った直後に「してもよい」効果(ウーラオスVの「Strafe」の「自分のベンチと入れ替えてもよい」等)。
# キーは (card_id, attack_name)。
AFTER_ATTACK_TRIGGER_EFFECTS: dict[tuple[str, str], tuple[Effect, ...]] = {
    ("swsh5-87", "Strafe"): (SwitchActiveWithBench(),),
    ("dp6-43", "Psychic Restore"): (MoveSelfAndAttachedToBottomOfDeck(),),  # Uxie: 自分を山札の下に戻してもよい
    ("swsh8-113", "Psychic Leap"): (ShuffleSelfIntoDeck(),),  # ミュウV: 自分を山札に戻してもよい
    ("sm4-70", "Gale Blade"): (ShuffleSelfIntoDeck(),),  # カミツルギGX: 自分を山札に戻してもよい
    ("bw10-66", "Strafe"): (SwitchActiveWithBench(),),  # パルキアEX: 自分のベンチと入れ替えてもよい
    ("sv8-131", "Surf Back"): (ShuffleSelfIntoDeck(),),  # Gholdengo: 自分を山札に戻してもよい
    # v1簡略版: 「Spinning Turn」「Dark Corridor」は実カードでは強制交代だが、強制交代フローが
    # 未整備のため「してもよい」機構を流用(任意交代として対応)。
    ("bw8-72", "Spinning Turn"): (SwitchActiveWithBench(),),  # ドンファン
    ("xy4-34", "Dark Corridor"): (SwitchActiveWithBench(),),  # ゲンガーEX
}


def get_after_attack_trigger_script(card_id: str, attack_name: str) -> tuple[Effect, ...]:
    script = AFTER_ATTACK_TRIGGER_EFFECTS.get((card_id, attack_name))
    if script is not None:
        return script
    return GENERATED_AFTER_ATTACK_TRIGGER_EFFECTS.get((card_id, attack_name), ())


# ---- Jレギュレーション新規カード実装ぶん(2026-08-26〜、pokemontcg.io regulationMark:J全419枚を
# カードDBに追加した後の実装バッチ)。まとめてここに追加していく。 ----

ATTACK_EFFECTS["me2pt5-1"] = {  # Erika's Oddish
    "Reckless Charge": (DealDamage(30), SelfDamage(10)),
}
ATTACK_EFFECTS["me2pt5-102"] = {  # Hitmontop
    "Spin and Draw": (ShuffleHandIntoDeckThenDraw(6),),
    "Low Kick": (DealDamage(50),),
}
ATTACK_EFFECTS["me2pt5-108"] = {  # Groudon
    "Hammer In": (DealDamage(80),),
    "Megaton Fall": (DealDamage(150), SelfDamage(30)),
}
ATTACK_EFFECTS["me2pt5-114"] = {  # Stunfisk ex
    "Big Bite": (DealDamage(30), DisableDefenderRetreatNextTurn()),
    "Flopping Trap": (BonusDamageIfSelfDamaged(base=100, bonus=100),),
}
ATTACK_EFFECTS["me2pt5-117"] = {  # Carbink(特性Double Typeは未実装、v1簡略版: 弱点・抵抗力計算への
    # 二重タイプ反映はエンジン側の大改修が必要なため見送り)
    "Counter Jewel": (BonusDamageIfOpponentPrizesAtMost(base=70, bonus=100, threshold=2),),
}
ATTACK_EFFECTS["me2pt5-121"] = {  # Koraidon ex
    "Orichalcum Fang": (DamageIfOwnPokemonKnockedOutLastOpponentTurn(base=50, bonus=120),),
    "Impact Blow": (DealDamage(200), LockOwnAttackNextTurn(attack_name="Impact Blow")),
}
ATTACK_EFFECTS["me2pt5-138"] = {  # Vullaby
    "Flap": (DealDamage(20),),
}
ATTACK_EFFECTS["me2pt5-139"] = {  # Mandibuzz ex
    "Bone Shot": (DealDamageToChosenOpponentPokemon(50),),
    "Vulture Claw": (DealDamage(160), DiscardRandomFromOpponentHand()),
}
ATTACK_EFFECTS["me2pt5-141"] = {  # Hoopa
    "Filch": (Draw(2),),
    "Knuckle Impact": (DealDamage(130), LockOwnAttackNextTurn(attack_name="", lock_all_attacks=True)),
}
ATTACK_EFFECTS["me2pt5-144"] = {  # Mawile
    "Call for Family": (SearchDeckForBasicPokemonToBench(count=2),),
    "Bite": (DealDamage(90),),
}
ATTACK_EFFECTS["me2pt5-145"] = {  # Registeel ex
    "Regi Charge": (AttachEnergyFromDiscardToSelf(energy_type="Metal", count=2),),
    "Protecting Steel": (DealDamage(140), ApplyDamageReductionToSelf(amount=50)),
}
ATTACK_EFFECTS["me2pt5-149"] = {  # Togedemaru ex
    "Stun Needle": (DealDamage(20), FlipCoinThen(heads=(InflictStatusOnDefender(condition="paralyzed"),))),
    "Spiky Rolling": (DamageIfSelfSameAttackUsedLastOwnTurn(base=80, bonus=80, attack_name="Spiky Rolling"),),
}
ATTACK_EFFECTS["me2pt5-163"] = {  # Larry's Dunsparce
    "Rising Lunge": (DealDamage(10), FlipCoinThen(heads=(DealDamage(20),))),
}
ATTACK_EFFECTS["me2pt5-164"] = {  # Larry's Dudunsparce ex
    "Work Rush": (DamagePerHeadsForEachAttachedEnergy(damage_per_heads=80),),
}
ATTACK_EFFECTS["me2pt5-165"] = {  # Skitty
    "Cat Kick": (DealDamage(20),),
}
ATTACK_EFFECTS["me2pt5-166"] = {  # Delcatty
    "Cat Kick": (DealDamage(40),),
    "Energy Crush": (DamagePerEnergyOnAllOpponentPokemon(damage_per_energy=40),),
}
ATTACK_EFFECTS["me2pt5-167"] = {  # Zangoose ex
    "Spike Draw": (DealDamage(20), Draw(2)),
    "Wild Scissors": (DealDamage(180), SelfDamage(30)),
}
ATTACK_EFFECTS["me2pt5-168"] = {  # Larry's Starly
    "Minor Errand-Running": (SearchDeckForBasicEnergyToHand(count=2),),
    "Glide": (DealDamage(10),),
}
ATTACK_EFFECTS["me2pt5-169"] = {  # Larry's Staravia
    "Flap": (DealDamage(20),),
    "Razor Wing": (DealDamage(50),),
}
ATTACK_EFFECTS["me2pt5-170"] = {  # Larry's Staraptor
    "Facade": (BonusDamageIfSelfBurnedOrPoisoned(base=60, bonus=100),),
    "Feathery Strike": (DealDamage(150), DiscardOwnEnergy(count=2), DealBonusDamageToChosenOpponentBench(50)),
}

# ---- Jレギュレーション新規カード実装 第2バッチ ----

ATTACK_EFFECTS["me2pt5-172"] = {  # Mega Audino ex(Kaleidowaltzは未実装。コイン3回ぶんの可変枚数を
    # 好きなポケモンに自由配分する複雑な効果のため、v1簡略版は作らず一部実装のまま見送る)
    "Ear Force": (DamagePerEnergyOnOpponentActive(base=20, damage_per_energy=80),),
}
ATTACK_EFFECTS["me2pt5-173"] = {  # Larry's Rufflet
    "Peck the Wound": (BonusDamageIfDefenderAlreadyDamaged(base=20, bonus=80),),
}
ATTACK_EFFECTS["me2pt5-174"] = {  # Larry's Braviary
    "Clutch": (DealDamage(50), DisableDefenderRetreatNextTurn()),
    "Brave Bird": (DealDamage(120), SelfDamage(30)),
}
ATTACK_EFFECTS["me2pt5-175"] = {  # Larry's Komala(特性Lethargic Chargeは未実装: ベンチ限定発動+
    # 「自分のバトル場にいるLarry'sポケモン」への対象制限という複合条件のため一部実装のまま見送る)
    "Dozing Draw": (InflictStatusOnSelf(condition="asleep"), Draw(2)),
}
ATTACK_EFFECTS["me2pt5-176"] = {  # Drampa
    "Gentle Slap": (DealDamage(50),),
    "Dragon Strike": (DealDamage(120), LockOwnAttackNextTurn(attack_name="Dragon Strike")),
}
TRAINER_EFFECTS["me2pt5-198"] = (SearchDeckForNonRuleBoxPokemonToHand(count=1),)  # Poké Pad
ATTACK_EFFECTS["me2pt5-2"] = {  # Erika's Gloom
    "Poison Spray": (DealDamage(50), InflictStatusOnDefender(condition="poisoned")),
}
ATTACK_EFFECTS["me2pt5-20"] = {  # Charmander
    "Fire Claws": (DealDamage(30),),
}
ATTACK_EFFECTS["me2pt5-21"] = {  # Charmeleon
    "Heat Blast": (DealDamage(50),),
}
TRAINER_EFFECTS["me2pt5-214"] = (Draw(3),)  # Urbain
# Waitressは未実装(山札の上6枚を見て見つけた基本エネルギー1枚を自分のポケモン1匹につける。
# 専用のtop-N公開ゾーン処理が必要で一部実装のまま見送る)。
ATTACK_EFFECTS["me2pt5-218"] = {  # Erika's Tangela
    "Bind": (DealDamage(50), FlipCoinThen(heads=(InflictStatusOnDefender(condition="paralyzed"),))),
}
ABILITY_EFFECTS["me2pt5-218"] = {  # Erika's Tangela: Gathering of Blossoms
    "Gathering of Blossoms": (SearchDeckForNamePrefixPokemonToHand(name_prefix="Erika's", count=1),),
}
ATTACK_EFFECTS["me2pt5-22"] = {  # Mega Charizard Y ex
    "Explosion Y": (DiscardOwnEnergy(count=3), DealDamageToChosenOpponentPokemon(280)),
}
ATTACK_EFFECTS["me2pt5-232"] = {  # Marill
    "Hide": (FlipCoinThen(heads=(ApplyShieldToSelf(),)),),
    "Flop": (DealDamage(20),),
}
ATTACK_EFFECTS["me2pt5-236"] = {  # Slurpuff
    "Tackle": (DealDamage(40),),
    "Magical Shot": (DealDamage(70),),
}
# ---- 以下、既に実装済みの効果と全く同じテキストを持つ別イラスト/レアリティ版(同一セット内の
# 再録)。実カードテキストを個別に確認済みの上で、同じ効果定義を再利用する。 ----
ATTACK_EFFECTS["me2pt5-240"] = ATTACK_EFFECTS["me2pt5-102"]  # Hitmontop 別絵柄
ATTACK_EFFECTS["me2pt5-242"] = ATTACK_EFFECTS["me2pt5-117"]  # Carbink 別絵柄
ATTACK_EFFECTS["me2pt5-246"] = ATTACK_EFFECTS["me2pt5-144"]  # Mawile 別絵柄
ATTACK_EFFECTS["me2pt5-249"] = ATTACK_EFFECTS["me2pt5-170"]  # Larry's Staraptor 別絵柄
ATTACK_EFFECTS["me2pt5-252"] = ATTACK_EFFECTS["me2pt5-114"]  # Stunfisk ex 別絵柄

# ---- Jレギュレーション新規カード実装 第3バッチ ----

# Waitressは引き続き未実装(山札の上6枚を見て見つけた基本エネルギー1枚を自分のポケモン1匹に
# つける。専用のtop-N公開ゾーン処理が必要で一部実装のまま見送る)。
ATTACK_EFFECTS["me2pt5-253"] = ATTACK_EFFECTS["me2pt5-172"]  # Mega Audino ex 別絵柄(Kaleidowaltzは未実装のまま)
ATTACK_EFFECTS["me2pt5-272"] = {  # Mega Meganium ex
    "Giant Bouquet": (DamagePerSelfEnergyOfType(base=70, per_energy=50, energy_type="Grass"),),
}
ATTACK_EFFECTS["me2pt5-273"] = {  # Mega Emboar ex
    "Crimson Blast": (DealDamage(320), SelfDamage(60)),
}
ATTACK_EFFECTS["me2pt5-274"] = {  # Mega Feraligatr ex
    "Mortal Crunch": (BonusDamageIfDefenderAlreadyDamaged(base=200, bonus=200),),
}
ATTACK_EFFECTS["me2pt5-29"] = {  # Tepig
    "Steady Firebreathing": (DealDamage(20),),
}
ATTACK_EFFECTS["me2pt5-294"] = ATTACK_EFFECTS["me2pt5-22"]  # Mega Charizard Y ex 別絵柄
ATTACK_EFFECTS["me2pt5-3"] = {  # Erika's Vileplume ex
    "Bloom Powder": (DealDamage(160), InflictStatusOnDefender(condition="asleep"), InflictStatusOnDefender(condition="poisoned")),
}
ABILITY_EFFECTS["me2pt5-3"] = {  # Erika's Vileplume ex: Lovely Fragrance
    "Lovely Fragrance": (HealAllOwnPokemon(amount=30),),
}
ATTACK_EFFECTS["me2pt5-30"] = {  # Pignite
    "Super Singe": (DealDamage(70), InflictStatusOnDefender(condition="burned")),
}
ATTACK_EFFECTS["me2pt5-31"] = ATTACK_EFFECTS["me2pt5-273"]  # Mega Emboar ex 別絵柄
ATTACK_EFFECTS["me2pt5-4"] = {  # Erika's Bellsprout
    "Vine Slap": (DealDamage(20),),
}
ATTACK_EFFECTS["me2pt5-41"] = {  # Totodile
    "Slight Intrusion": (DealDamage(40), SelfDamage(10)),
}
ATTACK_EFFECTS["me2pt5-42"] = {  # Croconaw
    "Crunch": (DealDamage(50), FlipCoinThen(heads=(DiscardOpponentActiveEnergy(),))),
}
ATTACK_EFFECTS["me2pt5-43"] = ATTACK_EFFECTS["me2pt5-274"]  # Mega Feraligatr ex 別絵柄
ATTACK_EFFECTS["me2pt5-48"] = {  # Regice ex
    "Regi Charge": (AttachEnergyFromDiscardToSelf(energy_type="Water", count=2),),
    "Ice Prison": (DealDamage(140), DiscardOwnEnergy(count=2), InflictStatusOnDefender(condition="paralyzed")),
}
ATTACK_EFFECTS["me2pt5-5"] = {  # Erika's Weepinbell
    "Melt": (DealDamage(30),),
    "Leafy Cyclone": (DealDamage(70), LockOwnAttackNextTurn(attack_name="", lock_all_attacks=True)),
}
ATTACK_EFFECTS["me2pt5-55"] = {  # Pikachu
    "Tail Smack": (DealDamage(10),),
    "Tiny Bolt": (DealDamage(30),),
}
ATTACK_EFFECTS["me2pt5-56"] = {  # Raichu
    "Quick Blow": (DealDamage(20), FlipCoinThen(heads=(DealDamage(50),))),
    "Strong Volt": (DealDamage(150), DiscardOwnEnergy(count=1, energy_type="Lightning")),
}
ATTACK_EFFECTS["me2pt5-58"] = {  # Voltorb ex
    "Hundred-Hitting Ball": (DamagePerHeadsUntilTails(base=100, damage_per_heads=100),),
}
ATTACK_EFFECTS["me2pt5-6"] = {  # Erika's Victreebel
    "Flower Garden Rondo": (DamagePerOwnFieldNamePrefixCount(damage_per_pokemon=40, name_prefix="Erika's"),),
    "Solar Beam": (DealDamage(130),),
}

# ---- Jレギュレーション新規カード実装 第4バッチ ----

ATTACK_EFFECTS["me2pt5-7"] = ATTACK_EFFECTS["me2pt5-218"]  # Erika's Tangela 別絵柄
ABILITY_EFFECTS["me2pt5-7"] = ABILITY_EFFECTS["me2pt5-218"]
ATTACK_EFFECTS["me2pt5-73"] = {  # Miraidon ex
    "Slashing Claw": (DealDamage(40),),
    "Hadron Spark": (BonusDamageIfDefenderHasSubtype(base=120, bonus=120, subtype="ex"),),
}
ATTACK_EFFECTS["me2pt5-83"] = ATTACK_EFFECTS["me2pt5-232"]  # Marill 別絵柄
ATTACK_EFFECTS["me2pt5-84"] = {  # Azumarill ex(特性Bubble Gatheringは未実装: 「1回の自分の番に
    # 何度でも使える」エネルギー移動効果で、対象・回数選択のUIが複雑なため一部実装のまま見送る)
    "Energized Balloon": (DamagePerSelfEnergyOfType(base=60, per_energy=40, energy_type="Psychic"),),
}
ATTACK_EFFECTS["me2pt5-93"] = {  # Swirlix
    "Ram": (DealDamage(20),),
}
ATTACK_EFFECTS["me2pt5-94"] = ATTACK_EFFECTS["me2pt5-236"]  # Slurpuff 別絵柄
ATTACK_EFFECTS["me3-1"] = {  # Spinarak
    "Gooey Thread": (DealDamage(10), DisableDefenderRetreatNextTurn()),
}
ATTACK_EFFECTS["me3-10"] = {  # Rowlet
    "Find a Friend": (SearchDeckForPokemonToHand(count=1),),
    "Tackle": (DealDamage(30),),
}
ATTACK_EFFECTS["me3-11"] = {  # Dartrix
    "Leafage": (DealDamage(20),),
    "Feather Shot": (DiscardAllOwnEnergy(), DealDamageToChosenOpponentPokemon(90)),
}
ATTACK_EFFECTS["me3-101"] = {  # Salazzle ex(マレニエex)
    "Nasty Plot": (SearchDeckAnyCardToHand(count=2),),
    "Dire Nails": (
        DealDamage(100), InflictStatusOnDefender(condition="burned"), InflictStatusOnDefender(condition="poisoned"),
        SwitchActiveWithBench(),
    ),
}
ATTACK_EFFECTS["me3-102"] = {  # Mega Starmie ex(Nebula Beamは未実装: 「弱点・抵抗力に加え相手の
    # バトルポケモンの効果も一切無視する」という特殊なダメージ計算バイパスが必要で、既存の
    # DealDamageIgnoringWeaknessResistanceでは表現しきれない(シールド等は依然ブロックしてしまう)
    # ため一部実装のまま見送る)
    "Jetting Blow": (DealDamage(120), DealBonusDamageToChosenOpponentBench(50)),
}
ATTACK_EFFECTS["me3-105"] = {  # Yveltal ex(Soul Destroyerは未実装: 相手の場の「残りHPが50以下の
    # 全ポケモン」を一括できぜつさせる特殊な効果で専用の実装が必要なため一部実装のまま見送る)
    "Dark Strike": (DealDamage(210), LockOwnAttackNextTurn(attack_name="Dark Strike")),
}
ATTACK_EFFECTS["me3-118"] = ATTACK_EFFECTS["me3-102"]  # Mega Starmie ex 別絵柄
TRAINER_EFFECTS["me3-113"] = TRAINER_EFFECTS["me2pt5-198"]  # Poké Pad 別絵柄

# ---- Jレギュレーション新規カード実装 第5バッチ ----

# Rosa's Encouragement: 実カードは「メイのはげまし」(m3-75)と全く同じテキストの別収録版。
# 発動条件(自分の残りサイドが相手より多い)のゲートも_MAY_ENCOURAGEMENT_IDSに追加済み。
TRAINER_EFFECTS["me3-114"] = TRAINER_EFFECTS["m3-75"]
TRAINER_EFFECTS["me3-123"] = TRAINER_EFFECTS["m3-75"]
TRAINER_EFFECTS["me3-116"] = (SearchDiscardForFightingPokemonOrEnergyToHand(count=4),)  # タリオン(Tarragon)
ATTACK_EFFECTS["me3-104"] = {  # Mega Zygarde ex(Nullifying Zeroは未実装: 相手の場の全ポケモンに
    # 個別にコインを投げて命中したものだけダメージという多対象・可変処理が必要なため一部実装のまま見送る)
    "Gaia Wave": (DealDamage(200), ApplyDamageReductionToSelf(amount=30)),
}
ATTACK_EFFECTS["me3-106"] = {  # Mega Skarmory ex(メガエアームドex)
    "Sonic Ripper": (ShuffleSelfEnergyIntoDeck(), DealDamageToChosenOpponentPokemon(220)),
}
ATTACK_EFFECTS["me3-107"] = {  # Meowth ex(特性Last-Ditch Catchは未実装: ベンチに出した瞬間の
    # トリガー+「Last-Ditch」を含む特性の重複使用制限という複合条件のため一部実装のまま見送る)
    "Tuck Tail": (DealDamage(60), ReturnSelfToHand()),
}
ATTACK_EFFECTS["me3-100"] = {  # Decidueye ex(特性Sniper's Eyeは未実装: 相手の手札枚数に応じた
    # コスト軽減という特殊なコスト計算が必要なため一部実装のまま見送る)
    "Crushing Arrow": (DealDamage(240), DiscardOpponentActiveEnergy()),
}
ATTACK_EFFECTS["me3-12"] = ATTACK_EFFECTS["me3-100"]  # Decidueye ex 別絵柄
ATTACK_EFFECTS["me3-103"] = {  # Mega Clefable ex(メガピクシーex、特性Luminous Wingは未実装:
    # 相手の特性による自分への効果を無効化する広範な防御特性のため一部実装のまま見送る)
    "Shooting Moons": (DiscardEnergyFromHandForScalingDamage(base=120, max_count=4, damage_per=40),),
}
ATTACK_EFFECTS["me3-119"] = ATTACK_EFFECTS["me3-103"]  # Mega Clefable ex 別絵柄
ATTACK_EFFECTS["me3-120"] = ATTACK_EFFECTS["me3-104"]  # Mega Zygarde ex 別絵柄
ATTACK_EFFECTS["me3-121"] = ATTACK_EFFECTS["me3-107"]  # Meowth ex 別絵柄
ATTACK_EFFECTS["me3-124"] = ATTACK_EFFECTS["me3-104"]  # Mega Zygarde ex 別絵柄
ATTACK_EFFECTS["me3-13"] = {  # Fletchinder
    "Flare": (DealDamage(60),),
}
ATTACK_EFFECTS["me3-14"] = {  # Talonflame
    "Fire Wing": (DealDamage(110),),
}
ABILITY_EFFECTS["me3-14"] = {  # Talonflame: Sky Hunt
    "Sky Hunt": (FlipCoinThen(heads=(DiscardRandomFromOpponentHand(),)),),
}
ATTACK_EFFECTS["me3-15"] = {  # Salandit
    "Fire Claws": (DealDamage(20),),
}
ATTACK_EFFECTS["me3-16"] = ATTACK_EFFECTS["me3-101"]  # Salazzle ex 別絵柄

# ---- Jレギュレーション新規カード実装 第6バッチ ----

ATTACK_EFFECTS["me3-17"] = {  # Turtonator(特性Shell Spikesは未実装: 攻撃を受けた瞬間に反応する
    # トリガー型特性で専用の実装が必要なため一部実装のまま見送る)
    "Heat Breath": (DealDamage(80), FlipCoinThen(heads=(DealDamage(80),))),
}
ATTACK_EFFECTS["me3-18"] = {  # Seel
    "Rain Splash": (DealDamage(10),),
    "Wave Splash": (DealDamage(30),),
}
ATTACK_EFFECTS["me3-19"] = {  # Dewgong(特性Wash Outは未実装: 「1回の自分の番に何度でも」
    # 使えるベンチ→バトル場のエネルギー移動という複雑な繰り返しUIのため一部実装のまま見送る)
    "Wave Splash": (DealDamage(60),),
}
ATTACK_EFFECTS["me3-2"] = {  # Ariados
    "Poison Ring": (DealDamage(50), InflictStatusOnDefender(condition="poisoned"), DisableDefenderRetreatNextTurn()),
}
ATTACK_EFFECTS["me3-20"] = {  # Staryu
    "Water Gun": (DealDamage(20),),
}
ATTACK_EFFECTS["me3-21"] = ATTACK_EFFECTS["me3-102"]  # Mega Starmie ex 別絵柄
ATTACK_EFFECTS["me3-23"] = {  # Amaura
    "Icy Wind": (DealDamage(50), InflictStatusOnDefender(condition="asleep")),
}
ATTACK_EFFECTS["me3-24"] = {  # Aurorus(特性Tundra Wallは未実装: 「水エネルギーがついている自分の
    # 全ポケモン」への継続的なダメージ軽減という場全体への効果のため一部実装のまま見送る)
    "Freezing Chill": (DealDamage(150), DisableDefenderAttackNextTurn()),
}
ATTACK_EFFECTS["me3-25"] = {  # Volcanion
    "Strength": (DealDamage(50),),
    "Powerful Steam": (DamagePerHeadsForEachAttachedEnergy(damage_per_heads=90, energy_type="Water"),),
}
ATTACK_EFFECTS["me3-26"] = {  # Shinx
    "Double Scratch": (DealDamagePerHeads(coin_count=2, damage_per_heads=10),),
}
ATTACK_EFFECTS["me3-27"] = {  # Luxio(特性Fighting Roarは未実装: 進化タイミングのルール自体を
    # 書き換える特殊な特性のため一部実装のまま見送る)
    "Static Shock": (DealDamage(40),),
}
ATTACK_EFFECTS["me3-28"] = {  # Luxray
    "Incessant Onslaught": (DamagePerOwnPrizesTaken(base=0, per_prize=70),),
    "Strong Volt": (DealDamage(200), DiscardOwnEnergy(count=2)),
}
ATTACK_EFFECTS["me3-29"] = {  # Dedenne(Tail Generatorは未実装: 相手の場の総エネルギー数に応じた
    # 可変枚数を複数の自分のポケモンに自由配分するという複合効果のため一部実装のまま見送る)
    "Thunder Shock": (DealDamage(30), FlipCoinThen(heads=(InflictStatusOnDefender(condition="paralyzed"),))),
}
ATTACK_EFFECTS["me3-30"] = {  # Clefairy
    "Follow Me": (ForceOpponentSwitchChosenBench(),),
    "Flop": (DealDamage(30),),
}
ATTACK_EFFECTS["me3-31"] = ATTACK_EFFECTS["me3-103"]  # Mega Clefable ex 別絵柄
ATTACK_EFFECTS["me3-32"] = {  # Mawile
    "Double Eater": (DiscardEnergyFromHandForScalingDamage(base=0, max_count=2, damage_per=60),),
}
ATTACK_EFFECTS["me3-33"] = {  # Espurr
    "Nap": (HealSelf(20),),
    "Stampede": (DealDamage(10),),
}
ATTACK_EFFECTS["me3-34"] = {  # Meowstic
    "Perplex": (InflictStatusOnDefender(condition="confused"),),
    "Psychic": (DamagePerEnergyOnOpponentActive(base=30, damage_per_energy=30),),
}
ATTACK_EFFECTS["me3-35"] = {  # Spritzee
    "Sweet Scent": (HealTarget(30),),
    "Ram": (DealDamage(10),),
}

# ---- Jレギュレーション新規カード実装 第7バッチ ----

ATTACK_EFFECTS["me3-36"] = {  # Aromatisse
    "Draining Kiss": (DealDamage(50), HealSelf(30)),
}
ABILITY_EFFECTS["me3-36"] = {  # Aromatisse: Scent Collection
    "Scent Collection": (SearchDeckForBasicEnergyToHand(count=2, energy_type="Psychic"),),
}
ATTACK_EFFECTS["me3-37"] = {  # Nosepass
    "Rolling Rocks": (DealDamage(40),),
}
ATTACK_EFFECTS["me3-38"] = {  # Probopass
    "Rolling Rocks": (DealDamage(60),),
    "Obliterating Nose": (DealDamage(260), DiscardOwnEnergy(count=3)),
}
ATTACK_EFFECTS["me3-4"] = {  # Snivy
    "Reckless Charge": (DealDamage(30), SelfDamage(10)),
}
ATTACK_EFFECTS["me3-40"] = {  # Hippowdon(Twister Spewingは未実装: 「このターン中にタリオンを
    # 手札から出したか」という追加のターン内トラッキングが必要なため一部実装のまま見送る)
    "Heavy Impact": (DealDamage(130),),
}
ATTACK_EFFECTS["me3-41"] = {  # Landorus
    "Rock Tumble": (DealDamageIgnoringResistanceOnly(50),),
    "Screw Knuckle": (DealDamage(120), ReturnOwnAttachedEnergyToHand()),
}
ATTACK_EFFECTS["me3-44"] = {  # Tyrunt
    "Get Angry": (DamagePerSelfDamageCounters(per_counter=20),),
}
ATTACK_EFFECTS["me3-46"] = {  # Hawlucha(バルジーナexのHawluchaとは別カード、ハラバリー)
    "Vengeful Kick": (BonusDamageIfOwnBenchDamaged(base=30, bonus=60),),
}
ATTACK_EFFECTS["me3-47"] = ATTACK_EFFECTS["me3-104"]  # Mega Zygarde ex 別絵柄
ATTACK_EFFECTS["me3-48"] = {  # Gastly
    "Surprise Attack": (FlipCoinThen(heads=(DealDamage(30),)),),
}
ATTACK_EFFECTS["me3-49"] = {  # Haunter
    "Haunt": (DamageCounterFixedOnOpponentActive(count=3),),
}
ATTACK_EFFECTS["me3-5"] = {  # Servine
    "Solar Cutter": (DealDamage(40),),
}
ATTACK_EFFECTS["me3-50"] = {  # Gengar(特性Infinite Shadowは未実装: きぜつ処理そのものを
    # 分岐させる特殊な特性のため一部実装のまま見送る)
    "Mind Jack": (DamagePerOpponentBenchedPokemon(base=10, per_pokemon=30),),
}
ATTACK_EFFECTS["me3-51"] = {  # Skorupi
    "Poison Jab": (DealDamage(20), InflictStatusOnDefender(condition="poisoned")),
}
ATTACK_EFFECTS["me3-52"] = {  # Drapion
    "Wrack Down": (DealDamage(60),),
    "Hazardous Tail": (
        DealDamage(100), SelfDamage(70),
        InflictStatusOnDefender(condition="paralyzed"), InflictStatusOnDefender(condition="poisoned"),
    ),
}
ATTACK_EFFECTS["me3-53"] = ATTACK_EFFECTS["me3-105"]  # Yveltal ex 別絵柄
ATTACK_EFFECTS["me3-54"] = {  # Chien-Pao(実カードは「Strafe」実カードテキスト通り、攻撃後の
    # 「してもよい」入れ替え。既存のAFTER_ATTACK_TRIGGER_EFFECTS機構を再利用)
    "Strafe": (DealDamage(20),),
    "Rising Blade": (BonusDamageIfDefenderHasSubtype(base=80, bonus=80, subtype="ex"),),
}
AFTER_ATTACK_TRIGGER_EFFECTS[("me3-54", "Strafe")] = (SwitchActiveWithBench(),)

# ---- Jレギュレーション新規カード実装 第8バッチ ----

ATTACK_EFFECTS["me3-56"] = {  # Honedge
    "Cut": (DealDamage(10),),
}
ATTACK_EFFECTS["me3-57"] = {  # Doublade
    "Weaponized Swords": (DamagePerHandCardMatchingNames(damage_per_card=60, names=("Honedge", "Doublade", "Aegislash")),),
}
ATTACK_EFFECTS["me3-58"] = {  # Aegislash
    "Slash": (DealDamage(80),),
    "Metal Slash": (DealDamage(230), LockOwnAttackNextTurn(attack_name="", lock_all_attacks=True)),
}
ATTACK_EFFECTS["me3-59"] = {  # Klefki
    "Memory Lock": (LockChosenOpponentAttackNextTurn(),),
}
ATTACK_EFFECTS["me3-6"] = {  # Serperior(ジャローダ)
    "Regal Command": (DamagePerOwnPokemonInPlay(per_pokemon=20),),
    "Solar Coiling": (BonusDamageIfCardInOwnDiscard(base=100, bonus=150, card_ids=("me3-114", "me3-123")),),  # Rosa's Encouragement
}
ATTACK_EFFECTS["me3-60"] = {  # Rattata
    "Take Down": (DealDamage(30), SelfDamage(10)),
}
ATTACK_EFFECTS["me3-61"] = {  # Raticate
    "Scrape Off": (DiscardOpponentActiveTool(), DealDamage(20)),
    "Retaliatory Incisors": (DamagePerNamedBenchedDamageCounters(per_counter=40, name="Rattata"),),
}
ATTACK_EFFECTS["me3-63"] = {  # Snorlax(Gormandizerは未実装: 裏が出るまで投げ続けたコインの
    # 枚数ぶん可変枚数のエネルギーを検索して自由につけるという複合処理のため一部実装のまま見送る)
    "Collapse": (DealDamage(160), InflictStatusOnSelf(condition="asleep")),
}
ATTACK_EFFECTS["me3-64"] = {  # Bunnelby
    "Smash Kick": (DealDamage(10),),
}
ATTACK_EFFECTS["me3-65"] = {  # Diggersby
    "Earthquake": (DealDamage(140), DamageToAllOwnBenchedPokemon(30)),
    "Whap Down": (DealDamage(100),),
}
ATTACK_EFFECTS["me3-67"] = {  # Furfrou(ヨーテリー系統ではなくトリミアン自身)
    "Hand Trim": (RandomOpponentHandDiscardDownTo(count=5),),
    "Headbutt": (DealDamage(30),),
}
ATTACK_EFFECTS["me3-7"] = {  # Scatterbug
    "Gnaw": (DealDamage(20),),
}

# ---- Jレギュレーション新規カード実装 第9バッチ ----

TRAINER_EFFECTS["me3-71"] = (FlipCoinThenDiscardOpponentEnergy(),)  # Crushing Hammer(クラッシュハンマー別収録版)
TRAINER_EFFECTS["me3-75"] = (HealTarget(150),)  # ジャシンテ(Jacinthe、対象は超タイプ限定、legal_actionsでゲート)
TRAINER_EFFECTS["me3-110"] = TRAINER_EFFECTS["me3-75"]  # Jacinthe 別収録版
TRAINER_EFFECTS["me3-122"] = TRAINER_EFFECTS["me3-75"]  # Jacinthe 別収録版
TRAINER_EFFECTS["me3-76"] = (BothPlayersShuffleHandAndDrawFixed(count=4),)  # Judge(ジャッジ)
TRAINER_EFFECTS["me3-78"] = (HealOwnActiveFixed(20), ClearActiveStatusConditions())  # ルミオーズガレット(Lumiose Galette)
ATTACK_EFFECTS["me3-8"] = {  # Spewpa
    "Hide": (FlipCoinThen(heads=(ApplyShieldToSelf(),)),),
}
TRAINER_EFFECTS["me3-80"] = (FlipCoinThen(heads=(SearchDeckForPokemonToHand(count=1),)),)  # モンスターボール(Poké Ball)
TRAINER_EFFECTS["me3-81"] = TRAINER_EFFECTS["me2pt5-198"]  # Poké Pad 別収録版
TRAINER_EFFECTS["me3-82"] = (FlipCoinThen(heads=(ForceOpponentSwitchChosenBench(),)),)  # ポケモンキャッチャー(Pokémon Catcher別収録版)
TRAINER_EFFECTS["me3-83"] = (HealTarget(30),)  # キズぐすり(Potion)

# ---- Jレギュレーション新規カード実装 第10バッチ ----

TRAINER_EFFECTS["me3-84"] = TRAINER_EFFECTS["m3-75"]  # Rosa's Encouragement 別収録版
TRAINER_EFFECTS["me3-85"] = TRAINER_EFFECTS["me3-116"]  # Tarragon 別収録版
ATTACK_EFFECTS["me3-89"] = ATTACK_EFFECTS["me2pt5-232"]  # Spewpa(HideはMarillと同じ効果パターン)
ATTACK_EFFECTS["me3-90"] = ATTACK_EFFECTS["me3-10"]  # Rowlet 別絵柄
ATTACK_EFFECTS["me3-91"] = ATTACK_EFFECTS["me3-14"]  # Talonflame 別絵柄
ABILITY_EFFECTS["me3-91"] = ABILITY_EFFECTS["me3-14"]
ATTACK_EFFECTS["me3-92"] = ATTACK_EFFECTS["me3-24"]  # Aurorus 別絵柄
ATTACK_EFFECTS["me3-93"] = {  # Dedenne(Tail Generatorは未実装のため見送り、me3-29と同じ)
    "Thunder Shock": (DealDamage(30), FlipCoinThen(heads=(InflictStatusOnDefender(condition="paralyzed"),))),
}
ATTACK_EFFECTS["me3-9"] = {  # Vivillon(モルフォン、特性Grand Wingは未実装: 相手の手札を強制的に
    # シャッフルして山札の下に送り、実際に送ったカードがあれば4枚引かせるという相手側への
    # 複合操作のため一部実装のまま見送る)
    "Blow Through": (BonusDamageIfStadiumInPlay(base=60, bonus=60),),
}

# ---- Jレギュレーション新規カード実装 第11バッチ ----

ATTACK_EFFECTS["me3-94"] = ATTACK_EFFECTS["me3-30"]  # Clefairy 別絵柄
ATTACK_EFFECTS["me3-95"] = ATTACK_EFFECTS["me3-33"]  # Espurr 別絵柄
ATTACK_EFFECTS["me3-96"] = ATTACK_EFFECTS["me3-38"]  # Probopass 別絵柄
ATTACK_EFFECTS["me3-97"] = ATTACK_EFFECTS["me3-52"]  # Drapion 別絵柄
ATTACK_EFFECTS["me3-98"] = ATTACK_EFFECTS["me3-57"]  # Doublade 別絵柄
ATTACK_EFFECTS["me3-99"] = ATTACK_EFFECTS["me3-61"]  # Raticate 別絵柄
ATTACK_EFFECTS["me4-1"] = {  # Weedle
    "Surprise Attack": (FlipCoinThen(heads=(DealDamage(30),)),),
}
ATTACK_EFFECTS["me4-10"] = {  # Ho-Oh
    "Flames of Revival": (SearchDiscardForBasicPokemonToBench(count=3),),
    "Bright Wing": (DealDamage(130), DiscardOwnEnergy(count=1, energy_type="Fire")),
}

# ---- Jレギュレーション新規カード実装 第12バッチ ----

ATTACK_EFFECTS["me3-39"] = {  # Hippopotas(Sand Attackはこんらんと同じ機構で実装)
    "Sand Attack": (DealDamage(10), InflictStatusOnDefender(condition="confused")),
    "Bite": (DealDamage(60),),
}
ATTACK_EFFECTS["me3-45"] = {  # Tyrantrum(特性Tyrannically Gustyはengine.continuous.HP_BONUS_IF_ANY_SPECIAL_ENERGY
    # で対応。Wreak Havoc(「表が出るまでコインを振り、表の数ぶん相手の山札の上から捨てる」)は
    # 未実装のまま見送る)
}
ATTACK_EFFECTS["me3-55"] = ATTACK_EFFECTS["me3-106"]  # Mega Skarmory ex 別絵柄
ATTACK_EFFECTS["me3-66"] = {  # Fletchling(Chirpは「ひこう抵抗力を持つポケモン」というテキスト内容の
    # 検索条件が未実装のため見送り)
    "Peck": (DealDamage(20),),
}
ATTACK_EFFECTS["me4-11"] = {  # Fennekin
    "Call for Family": (SearchDeckForBasicPokemonToBench(count=2),),
    "Steady Firebreathing": (DealDamage(10),),
}
ATTACK_EFFECTS["me4-100"] = {  # Mega Greninja ex(特性Mortal Shurikenは手札からの基本水エネルギー
    # 破棄コストを伴う特性のため見送り。Ninja Spinnerは「エネルギーを手札に戻して+80」の
    # 任意選択ボーナスを省略し、確定80ダメージ部分のみ実装)
    "Ninja Spinner": (DealDamage(120),),
}
ATTACK_EFFECTS["me4-116"] = ATTACK_EFFECTS["me4-100"]  # Mega Greninja ex 別絵柄
ATTACK_EFFECTS["me4-101"] = {  # Mega Floette ex(Eternity Bloomは「山札から基本超エネルギーを最大4枚
    # 選び、複数のベンチポケモンに自由配分」という複数対象への分配選択が未実装のため見送り)
    "Gentle Light": (HealAllPokemonBothSides(30),),
}
ATTACK_EFFECTS["me4-102"] = {  # Gourgeist ex
    "Horrifying Rondo": (DealDamagePerOwnBenchedDamagedPokemon(base=30, per_damaged_bench=50),),
    "Ghostly Touch": (DealDamage(140), DiscardRandomFromOpponentHand()),
}
ATTACK_EFFECTS["me4-103"] = {  # Cobalion ex(特性Metal Roadは「ベンチからバトル場に出たとき」という
    # 入れ替わりトリガーが未実装のため見送り)
    "Power Tackle": (DealDamage(200), LockOwnAttackNextTurn(attack_name="Power Tackle", lock_all_attacks=True)),
}
ATTACK_EFFECTS["me4-104"] = {  # Mega Dragalge ex
    "Corrosive Liquid": (DiscardToolsAndSpecialEnergyFromAllOpponentPokemon(),),
    "Pernicious Poison": (InflictHeavyPoison(severity=16),),
}
ATTACK_EFFECTS["me4-105"] = {  # Cinccino ex(特性Smooth Coatは「被弾するたびにコイン判定」という
    # 反応型の特性が未実装のため見送り)
    "Energized Slap": (DamagePerOwnAttachedEnergyCount(per_energy=40),),
}
TRAINER_EFFECTS["me4-106"] = (SwitchActiveWithBenchThenHealBenchedIfEx(heal_amount=80),)  # AZ's Tranquility
TRAINER_EFFECTS["me4-107"] = (RevealOpponentHandThenDrawPerPokemonFound(),)  # Emma
TRAINER_EFFECTS["me4-110"] = (
    AttachEnergyFromDiscardToOwnPokemon(energy_type="Metal", count=2, target_type="Metal"),
)  # Philippe
TRAINER_EFFECTS["me4-113"] = TRAINER_EFFECTS["me4-82"]  # Special Red Card 別絵柄(使用条件はlegal_actionsでゲート済み)

# ---- Jレギュレーション新規カード実装 第13バッチ ----

ATTACK_EFFECTS["me4-117"] = ATTACK_EFFECTS["me4-101"]  # Mega Floette ex 別絵柄
ATTACK_EFFECTS["me4-35"] = ATTACK_EFFECTS["me4-101"]  # Mega Floette ex 別絵柄
ATTACK_EFFECTS["me4-118"] = ATTACK_EFFECTS["me4-104"]  # Mega Dragalge ex 別絵柄
ATTACK_EFFECTS["me4-119"] = ATTACK_EFFECTS["me4-105"]  # Cinccino ex 別絵柄
ATTACK_EFFECTS["me4-122"] = ATTACK_EFFECTS["me4-100"]  # Mega Greninja ex 別絵柄
ATTACK_EFFECTS["me4-22"] = ATTACK_EFFECTS["me4-100"]  # Mega Greninja ex 別絵柄
ATTACK_EFFECTS["me4-41"] = ATTACK_EFFECTS["me4-102"]  # Gourgeist ex 別絵柄
TRAINER_EFFECTS["me4-120"] = TRAINER_EFFECTS["me4-106"]  # AZ's Tranquility 別絵柄

ATTACK_EFFECTS["me4-12"] = {  # Braixen
    "Flamethrower": (DealDamage(80), DiscardOwnEnergy(count=1)),
}
ATTACK_EFFECTS["me4-14"] = {"Tackle": (DealDamage(10),)}  # Litleo
ATTACK_EFFECTS["me4-16"] = {"Sharp Fin": (DealDamage(20),)}  # Remoraid
ATTACK_EFFECTS["me4-2"] = {  # Kakuna(特性Exoskeletonは常時ダメージ軽減の新規機構が必要なため見送り)
    "Hang Down": (DealDamage(20),),
}
ATTACK_EFFECTS["me4-20"] = {  # Froakie
    "Collect": (Draw(1),),
    "Water Gun": (DealDamage(10),),
}
ATTACK_EFFECTS["me4-23"] = {  # Bergmite
    "Chilly": (DealDamage(10),),
    "Frost Breath": (DealDamage(50),),
}
ATTACK_EFFECTS["me4-25"] = {  # Wimpod
    "Gnaw": (DealDamage(10),),
    "Corkscrew Punch": (DealDamage(20),),
}
ATTACK_EFFECTS["me4-27"] = {  # Mareep
    "Thunder Wave": (DealDamage(20), FlipCoinThen(heads=(InflictStatusOnDefender(condition="paralyzed"),))),
}
ATTACK_EFFECTS["me4-30"] = {  # Emolga
    "Minor Errand-Running": (SearchDeckForBasicEnergyToHand(count=2),),
    "Sky Return": (DealDamage(30), ReturnSelfToHandUnconditional()),
}
ATTACK_EFFECTS["me4-49"] = {  # Zubat
    "Supersonic": (InflictStatusOnDefender(condition="confused"),),
}
ATTACK_EFFECTS["me4-5"] = {  # Chespin
    "Beat": (DealDamage(10),),
    "Spike Sting": (DealDamage(30),),
}
ATTACK_EFFECTS["me4-53"] = {"Scratch": (DealDamage(20),)}  # Stunky
ATTACK_EFFECTS["me4-58"] = {"Hook": (DealDamage(10),)}  # Skrelp
ATTACK_EFFECTS["me4-59"] = {  # Beldum
    "Headbutt": (DealDamage(10),),
    "Beam": (DealDamage(20),),
}
ATTACK_EFFECTS["me4-6"] = {  # Quilladin
    "Leafy Charge": (SearchDeckForBasicEnergyAttachToTarget(count=1, energy_type="Grass", self_only=True),),
    "Vine Whip": (DealDamage(80),),
}
ATTACK_EFFECTS["me4-44"] = {  # Phanpy
    "Mud-Slap": (DealDamage(10),),
    "Rollout": (DealDamage(40),),
}
ATTACK_EFFECTS["me4-60"] = {  # Metang
    "Metal Claw": (DealDamage(30),),
    "Guard Press": (DealDamage(70), ApplyDamageReductionToSelf(30)),
}
ATTACK_EFFECTS["me4-15"] = {  # Mega Pyroar ex
    "Ferocious Bellow": (DealDamage(80), DebuffDefenderAttackDamageNextTurn(50)),
    "Fiery Big Bang": (DealDamageLessPerSelfDamageCounters(base=290, per_self_damage_counter=10),),
}
ATTACK_EFFECTS["me4-17"] = {  # Octillery(Jet of Inkは「コイン2枚のどちらかが裏なら失敗」という
    # こんらんとは異なる確率の新規機構が必要なため見送り)
    "Jet of Ink": (DealDamage(30),),
    "Tantrum": (DealDamage(120), InflictStatusOnSelf(condition="confused")),
}
ATTACK_EFFECTS["me4-19"] = {  # Keldeo
    "Shoot Through": (DealDamage(20), DealBonusDamageToChosenOpponentBench(20)),
    "Reflect Energy": (DealDamage(70), MoveEnergyBetweenOwnPokemon()),
}
ATTACK_EFFECTS["me4-18"] = {  # Delibird(Pleasing Presentは両プレイヤーがエネルギーを自由につける
    # 複合選択のため見送り)
    "Flap": (DealDamage(40),),
}
ATTACK_EFFECTS["me4-24"] = {  # Avalugg(Iceberg Breakerは山札の上から6枚を見て水エネルギーを数える
    # 効果が未実装のため見送り)
    "Frost Stamp": (DealDamage(160),),
}
ATTACK_EFFECTS["me4-26"] = {  # Golisopod(Critical Slashはきぜつ後の条件付きシールドが未実装のため見送り)
    "Boundless Power": (DealDamage(150), LockOwnAttackNextTurn(attack_name="Boundless Power", lock_all_attacks=True)),
}
ATTACK_EFFECTS["me4-28"] = {"Disconnect": (DealDamage(40), LockOpponentItemsNextTurn())}  # Flaaffy
ATTACK_EFFECTS["me4-29"] = {  # Ampharos(特性Synchro Pulseは手札枚数比較の条件付き特性のため見送り)
    "Flashing Bolt": (DealDamage(140), LockOwnAttackNextTurn(attack_name="Flashing Bolt")),
}
ATTACK_EFFECTS["me4-3"] = {  # Beedrill ex
    "Rumbling Bees": (DamagePerOwnPokemonWithNamePrefix(base=0, per_pokemon=110, name_prefix="Beedrill"),),
}
ATTACK_EFFECTS["me4-31"] = {  # Deoxys(たね、超)
    "Genome Charge": (SearchDeckForBasicEnergyAttachToTarget(count=2, energy_type="Psychic", self_only=True),),
    "Psychic": (DamagePerOpponentActiveEnergyCount(base=80, per_energy=20),),
}
ATTACK_EFFECTS["me4-34"] = {  # Deoxys(たね、超、4種目)
    "Psyspeed": (DealDamage(30), DrawUpTo(5)),
}
ATTACK_EFFECTS["me4-36"] = {  # Espurr(「このターンにエマを使っていたら+60」は使用履歴追跡が
    # 未実装のため見送り)
    "Buddy Attack": (DealDamage(10),),
}
ATTACK_EFFECTS["me4-37"] = {  # Meowstic
    "Tricky Steps": (DealDamage(80), MoveEnergyOnOpponentSide()),
}
ATTACK_EFFECTS["me4-38"] = {  # Phantump(特性Spiteful Evolutionは手札からの直接進化という
    # 新規機構が必要なため見送り)
    "Mumble": (DealDamage(10),),
}
ATTACK_EFFECTS["me4-39"] = {  # Trevenant(Cursed Rootsの「相手は次の番エネルギーをつけられない」は
    # 未実装のため見送り)
    "Overwhelming Pain": (DamagePerAllOpponentPokemonDamageCounters(base=60, per_counter=10),),
}
ATTACK_EFFECTS["me4-40"] = {"Stampede": (DealDamage(20),)}  # Pumpkaboo
ATTACK_EFFECTS["me4-43"] = {  # Sudowoodo(Trials and Trip-ulationsはカード名の内容による検索条件が
    # 未実装のため見送り)
    "Rock Hurl": (DealDamageIgnoringResistanceOnly(30),),
}
ATTACK_EFFECTS["me4-45"] = {  # Donphan(No Reprieveの「次の自分の番+120ダメージ」ボーナスは
    # 未実装のため見送り、ベースの効果無し部分のみ)
    "Smashing Headbutt": (DealDamage(180), DiscardOwnEnergy(count=2)),
}
ATTACK_EFFECTS["me4-46"] = {  # Baltoy
    "Continuous Spin": (DealDamageFlipUntilTailsBonus(base=0, bonus_per_heads=30),),
}
ATTACK_EFFECTS["me4-48"] = {  # Mega Gallade ex
    "Gale Slash": (BonusDamageIfSelfUndamaged(base=50, bonus=150),),
    "Marvelous Edge": (DealDamage(240),),
}
ATTACK_EFFECTS["me4-50"] = {  # Golbat(Covert Flightの「たねポケモンからのダメージを次の番防ぐ」は
    # 攻撃元ポケモンのサブタイプ限定シールドという新規機構が必要なため見送り)
    "Covert Flight": (DealDamage(30),),
}
ATTACK_EFFECTS["me4-51"] = {  # Crobat(特性Nighttime Maneuversは見送り)
    "Poison Sound Wave": (
        DealDamage(80),
        InflictStatusOnDefender(condition="confused"),
        InflictStatusOnDefender(condition="poisoned"),
    ),
}
ATTACK_EFFECTS["me4-52"] = {  # Qwilfish(特性Poison Pointは被弾時トリガーの反応型特性のため見送り)
    "Venoshock": (DamageIfDefenderPoisoned(base=30, bonus=50),),
}
ATTACK_EFFECTS["me4-54"] = {  # Skuntank
    "Rear Kick": (DealDamage(40),),
    "Smash Turn": (DealDamage(100), SwitchActiveWithBench()),
}
ATTACK_EFFECTS["me4-56"] = {  # Trubbish
    "Acid Spray": (DealDamage(10), FlipCoinThen(heads=(DiscardOpponentActiveEnergy(),))),
}
ATTACK_EFFECTS["me4-57"] = {  # Garbodor(特性Gloomy Garbageは見送り)
    "Sludge Bomb": (DealDamage(100),),
}

# ---- Jレギュレーション新規カード実装 第14バッチ ----

ATTACK_EFFECTS["me4-64"] = ATTACK_EFFECTS["me4-103"]  # Cobalion ex 別絵柄
ATTACK_EFFECTS["me4-65"] = ATTACK_EFFECTS["me4-104"]  # Mega Dragalge ex 別絵柄
ATTACK_EFFECTS["me4-73"] = ATTACK_EFFECTS["me4-105"]  # Cinccino ex 別絵柄
TRAINER_EFFECTS["me4-76"] = TRAINER_EFFECTS["me4-106"]  # AZ's Tranquility 別絵柄
TRAINER_EFFECTS["me4-77"] = TRAINER_EFFECTS["me4-107"]  # Emma 別絵柄
TRAINER_EFFECTS["me4-79"] = TRAINER_EFFECTS["me4-110"]  # Philippe 別絵柄

ATTACK_EFFECTS["me4-4"] = {  # Carnivine
    "Chomp Whole": (BonusDamageIfDefenderHasNoRetreatCost(base=80, bonus=80),),
}
ATTACK_EFFECTS["me4-7"] = {  # Chesnaught(特性Needly Armorは見送り)
    "Impound": (DealDamage(160), DisableDefenderRetreatNextTurn()),
}
ATTACK_EFFECTS["me4-8"] = {  # Vulpix
    "Singe": (InflictStatusOnDefender(condition="burned"),),
}
ATTACK_EFFECTS["me4-9"] = {  # Ninetales(Nine-Tailed Transferの「ベンチからバトル場へダメカンを
    # まるごと移す」効果は未実装のため見送り)
    "Will-O-Wisp": (DealDamage(70),),
}
ATTACK_EFFECTS["me4-13"] = {  # Delphox(特性Flaring Magicは手札からの基本炎エネルギー破棄コストを
    # 伴う特性のため見送り)
    "Energized Storm": (DamagePerAllPokemonEnergyCountAcrossBoard(per_energy=30),),
}
ATTACK_EFFECTS["me4-21"] = {  # Frogadier
    "Summoning Jutsu": (SearchDeckForPokemonToHand(count=3),),
    "Aqua Edge": (DealDamage(50),),
}
ATTACK_EFFECTS["me4-32"] = {  # Deoxys(たね、超、2種目)
    "Psyspear": (DamageWithBonusBenchIfExtraEnergy(base=120, cost_count=3, extra_needed=2, bench_bonus=120),),
}
ATTACK_EFFECTS["me4-42"] = {  # Xerneas
    "Geo Storm": (DamagePerOwnAttachedEnergyOfTypeAcrossBoard(per_energy=30, energy_type="Psychic"),),
}
ATTACK_EFFECTS["me4-62"] = {"Rolling Tackle": (DealDamage(40),)}  # Ferroseed
ATTACK_EFFECTS["me4-63"] = {  # Ferrothorn(特性Startling Dropは見送り)
    "Special Whip": (BonusDamageIfSelfHasAnySpecialEnergyAttached(base=70, bonus=70),),
}
ATTACK_EFFECTS["me4-66"] = {  # Goomy
    "Absorb": (DealDamage(30), HealSelf(30)),
}
ATTACK_EFFECTS["me4-67"] = {"Gentle Slap": (DealDamage(70),)}  # Sliggoo
ATTACK_EFFECTS["me4-68"] = {  # Goodra(特性Slimy Slidingは見送り)
    "Dragon Pulse": (DealDamage(160), DiscardTopOfOwnDeck(1)),
}
ATTACK_EFFECTS["me4-70"] = {"Bite": (DealDamage(10),)}  # Patrat(特性Watchful Eyeは見送り)
ATTACK_EFFECTS["me4-71"] = {  # Watchog(Snap Inspectionは3枚コイン+手札公開+選択シャッフルという
    # 複合効果のため見送り)
    "Low Kick": (DealDamage(50),),
}
ATTACK_EFFECTS["me4-72"] = {"Take Down": (DealDamage(30), SelfDamage(10))}  # Minccino

# ---- Jレギュレーション新規カード実装 第15バッチ ----

ATTACK_EFFECTS["me4-87"] = ATTACK_EFFECTS["me4-5"]  # Chespin 別絵柄
ATTACK_EFFECTS["me4-88"] = ATTACK_EFFECTS["me4-20"]  # Froakie 別絵柄
ATTACK_EFFECTS["me4-89"] = ATTACK_EFFECTS["me4-21"]  # Frogadier 別絵柄
ATTACK_EFFECTS["me4-90"] = ATTACK_EFFECTS["me4-29"]  # Ampharos 別絵柄
ATTACK_EFFECTS["me4-91"] = ATTACK_EFFECTS["me4-42"]  # Xerneas 別絵柄
ATTACK_EFFECTS["me4-93"] = ATTACK_EFFECTS["me4-51"]  # Crobat 別絵柄
ATTACK_EFFECTS["me4-94"] = ATTACK_EFFECTS["me4-60"]  # Metang 別絵柄
ATTACK_EFFECTS["me4-95"] = ATTACK_EFFECTS["me4-67"]  # Sliggoo 別絵柄
ATTACK_EFFECTS["me4-97"] = ATTACK_EFFECTS["me4-71"]  # Watchog 別絵柄
ATTACK_EFFECTS["me4-98"] = ATTACK_EFFECTS["me4-3"]  # Beedrill ex 別絵柄
ATTACK_EFFECTS["me4-99"] = ATTACK_EFFECTS["me4-15"]  # Mega Pyroar ex 別絵柄

ATTACK_EFFECTS["me4-47"] = {  # Claydol
    "Devolution Ray": (DealDamageThenDevolveOpponentActiveIfEvolved(50),),
}
ATTACK_EFFECTS["me4-92"] = ATTACK_EFFECTS["me4-47"]  # Claydol 別絵柄

ATTACK_EFFECTS["me4-69"] = {  # Tauros
    "Target Together": (
        DamageToChosenOpponentPokemonScaledByOwnPokemonNamedCoinFlips(per_heads=50, name_contains="Tauros"),
    ),
}
ATTACK_EFFECTS["me4-96"] = ATTACK_EFFECTS["me4-69"]  # Tauros 別絵柄

TRAINER_EFFECTS["me4-112"] = (OpponentPoisonedCantRetreatNextTurn(),)  # Roxie's Performance
TRAINER_EFFECTS["me4-81"] = TRAINER_EFFECTS["me4-112"]  # Roxie's Performance 別絵柄
TRAINER_EFFECTS["me4-121"] = TRAINER_EFFECTS["me4-112"]  # Roxie's Performance 別絵柄

# ---- Jレギュレーション新規カード実装 第16バッチ ----

ATTACK_EFFECTS["me5-1"] = {  # Tropius(Fruity Aromaは山札上6枚を見て任意枚数手札に加える
    # 「Waitress」型の未実装機構のため見送り)
    "Solar Beam": (DealDamage(60),),
}
ATTACK_EFFECTS["me5-2"] = {  # Grubbin
    "String Shot": (DealDamage(10), FlipCoinThen(heads=(InflictStatusOnDefender(condition="paralyzed"),))),
}
ATTACK_EFFECTS["me5-3"] = {"Reckless Charge": (DealDamage(30), SelfDamage(10))}  # Fomantis
ATTACK_EFFECTS["me5-4"] = {  # Lurantis ex(Lively Cutterの「このターン回復していたら」判定は
    # 未実装のため見送り)
    "Leaf Guard": (DealDamage(140), ApplyDamageReductionToSelf(50)),
}
ATTACK_EFFECTS["me5-7"] = {  # Heatran(Lava Wallの「やけどポケモンからのダメージを防ぐ」シールドは
    # 攻撃元の特殊状態限定シールドという新規機構が必要なため見送り)
    "Singe": (InflictStatusOnDefender(condition="burned"),),
    "Lava Wall": (DealDamage(120),),
}
ATTACK_EFFECTS["me5-8"] = {  # Mega Delphox ex(Trick Portalは山札上9枚を見る機構が未実装のため見送り)
    "Eerie Glow": (
        DealDamage(200),
        InflictStatusOnDefender(condition="burned"),
        InflictStatusOnDefender(condition="confused"),
    ),
}
ATTACK_EFFECTS["me5-13"] = {"Pierce": (DealDamage(30),)}  # Goldeen
ATTACK_EFFECTS["me5-14"] = {  # Seaking
    "Hydro Jet": (DamagePerSelfEnergyToChosenOpponent(per_energy=30, energy_type="Water"),),
}
ATTACK_EFFECTS["me5-15"] = {  # Wailmer
    "Water Gun": (DealDamage(40),),
    "Wave Splash": (DealDamage(80),),
}
ATTACK_EFFECTS["me5-16"] = {  # Wailord ex
    "Surf": (DealDamage(120),),
    "Falling Down": (DealDamage(270), InflictStatusOnSelf(condition="asleep")),
}
ATTACK_EFFECTS["me5-18"] = {"Pound": (DealDamage(20),)}  # Popplio
ATTACK_EFFECTS["me5-19"] = {"Hyper Voice": (DealDamage(40),)}  # Brionne
ATTACK_EFFECTS["me5-20"] = {  # Primarina(特性Enriching Melodyは進化時トリガーの特性のため見送り)
    "Aqua Return": (DealDamage(120), ShuffleSelfIntoDeck()),
}
ATTACK_EFFECTS["me5-21"] = {  # Finizen
    "Draining Fin": (DealDamage(20), HealSelf(20)),
}
ATTACK_EFFECTS["me5-22"] = {  # Palafin
    "Knuckle Justice": (BonusDamageIfOpponentPrizesExactly(base=80, bonus=200, count=1),),
}
ATTACK_EFFECTS["me5-25"] = {  # Charjabug
    "Vise Grip": (DealDamage(30),),
    "Ram": (DealDamage(50),),
}
ATTACK_EFFECTS["me5-26"] = {  # Vikavolt(Giga Railgunは専用特殊エネルギー依存のため見送り)
    "Quick Dive": (DealDamageToChosenOpponentPokemon(50),),
}
ATTACK_EFFECTS["me5-27"] = {  # Mega Zeraora ex
    "Thunderous Fist": (DamagePerOwnAttachedEnergyCount(per_energy=60, energy_type="Lightning"),),
    "Zepto Turn": (DealDamage(150), SwitchActiveWithBench()),
}
ATTACK_EFFECTS["me5-28"] = {"Thunder": (DealDamage(90), SelfDamage(30))}  # Miraidon(特性Photon Cordは
# きぜつ時トリガーの反応型特性のため見送り)
ATTACK_EFFECTS["me5-30"] = {  # Slowbro
    "All Out": (BonusDamageIfOwnHandEmpty(base=50, bonus=160),),
    "Zen Headbutt": (DealDamage(110),),
}
ATTACK_EFFECTS["me5-31"] = {  # Mega Slowbro ex
    "Shellnado Spin": (DealDamage(180), SetSelfRetaliateOnDamagedNextTurn(counters=12)),
}
ATTACK_EFFECTS["me5-32"] = {  # Jynx(Intense Kissは相手の次の番終了時トリガーの遅延効果のため見送り)
    "Psy Bolt": (DealDamage(50), FlipCoinThen(heads=(InflictStatusOnDefender(condition="paralyzed"),))),
}
ATTACK_EFFECTS["me5-36"] = {"Will-O-Wisp": (DealDamage(20),)}  # Litwick
ATTACK_EFFECTS["me5-38"] = {  # Mega Chandelure ex(特性Binding Flameは相手のにげるコスト増加という
    # 新規機構が必要なため見送り)
    "Phantom Maze": (DamagePerColorlessInOpponentActiveRetreatCost(base=130, per_colorless=50),),
}
ATTACK_EFFECTS["me5-40"] = {  # Marshadow
    "Shadowy Knot": (DamagePerColorlessInOpponentActiveRetreatCost(base=0, per_colorless=30),),
}
ATTACK_EFFECTS["me5-42"] = {"Low Kick": (DealDamage(20),)}  # Mankey
ATTACK_EFFECTS["me5-43"] = {"Corkscrew Punch": (DealDamage(50),)}  # Primeape
ATTACK_EFFECTS["me5-44"] = {  # Cranidos
    "Push Down": (DealDamage(70), ForceOpponentSwitchOpponentChooses()),
}
ATTACK_EFFECTS["me5-45"] = {  # Rampardos ex(特性、次の番のダメージボーナスは見送り)
    "Rowdy Hammer": (DealDamage(150),),
}
ATTACK_EFFECTS["me5-100"] = ATTACK_EFFECTS["me5-45"]  # Rampardos ex 別絵柄
ATTACK_EFFECTS["me5-46"] = {  # Drilbur
    "Call for Family": (SearchDeckForBasicPokemonToBench(count=2),),
    "Dig Claws": (DealDamage(50),),
}
ATTACK_EFFECTS["me5-47"] = {  # Koraidon
    "Battle Claw": (BonusDamageIfDefenderIsEvolved(base=30, bonus=30),),
    "Gaia Impact": (DealDamage(190), DiscardOwnEnergy(count=99)),
}
ATTACK_EFFECTS["me5-48"] = {  # Mega Darkrai ex(Abyss Eyeの即きぜつ効果は見送り)
    "Dusk Raid": (BonusDamageIfAnyOwnBenchedDamaged(base=110, bonus=110),),
}
ATTACK_EFFECTS["me5-101"] = ATTACK_EFFECTS["me5-48"]  # Mega Darkrai ex 別絵柄
ATTACK_EFFECTS["me5-49"] = {  # Vullaby
    "Flap": (DealDamage(10),),
    "Gust": (DealDamage(20),),
}
ATTACK_EFFECTS["me5-50"] = {"Blasting Wind": (DealDamage(120),)}  # Mandibuzz(Bone Sniperは対象制限のある固定ダメージのため見送り)

# ---- Jレギュレーション新規カード実装 第17バッチ ----

ATTACK_EFFECTS["me5-51"] = {  # Inkay
    "Procurement": (SearchDeckByCriterionToHand(criterion="item", count=1),),
    "Spinning Attack": (DealDamage(30),),
}
ATTACK_EFFECTS["me5-52"] = {  # Malamar
    "Perplex": (InflictStatusOnDefender(condition="confused"),),
    "Brain Crush": (DamageOnlyIfDefenderConfused(130),),
}
ATTACK_EFFECTS["me5-53"] = {  # Nickit
    "Gnaw": (DealDamage(10),),
    "Rear Kick": (DealDamage(30),),
}
ATTACK_EFFECTS["me5-54"] = {"Sharp Fang": (DealDamage(80),)}  # Thievul(Skill Thiefは相手のワザをコピーする新規機構のため見送り)
ATTACK_EFFECTS["me5-55"] = {  # Morpeko ex
    "Wheely Draw": (ShuffleOwnHandIntoDeckThenDraw(6),),
    "Hangry Blaster": (DealDamage(40), DamagePerSelfDamageCounters(40)),
}
ATTACK_EFFECTS["me5-102"] = ATTACK_EFFECTS["me5-55"]  # Morpeko ex 別絵柄
ATTACK_EFFECTS["me5-56"] = {  # Zarude(Shadowy Whipは専用特殊エネルギー依存のため見送り)
    "Overhead Throw": (DealDamage(30), DamageCounterOnChosenOwnPokemon(count=3)),
}
ATTACK_EFFECTS["me5-57"] = {"Bite": (DealDamage(40),)}  # Maschiff
ATTACK_EFFECTS["me5-58"] = {  # Mabosstiff(Plunging Headbuttの被ダメージ増加は見送り)
    "Bite": (DealDamage(60),),
    "Plunging Headbutt": (DealDamage(210),),
}
ATTACK_EFFECTS["me5-59"] = {  # Chi-Yu
    "Whirling Envy": (DamageIgnoringWeaknessBonusIfSelfDamaged(base=20, bonus=90, min_counters=2),),
}
ATTACK_EFFECTS["me5-60"] = {  # Skarmory
    "Steel Cutter": (DiscardEnergyFromHandForScalingDamage(base=0, max_count=2, damage_per=40, energy_type="Metal"),),
}
ATTACK_EFFECTS["me5-61"] = {  # Shieldon
    "Smithereen Smash": (DealDamage(50), DiscardOpponentActiveEnergy()),
}
ATTACK_EFFECTS["me5-62"] = {"Hammer In": (DealDamage(160),)}  # Bastiodon(特性Ancient Bulwarkは見送り)
ATTACK_EFFECTS["me5-63"] = {  # Bronzor
    "Mirror Attack": (BonusDamageIfDefenderType(base=10, bonus=30, defender_type="Metal"),),
}
ATTACK_EFFECTS["me5-64"] = {"Gentle Slap": (DealDamage(40),)}  # Bronzong(Metal Blockは見送り)
ATTACK_EFFECTS["me5-65"] = {  # Mega Excadrill ex
    "Undermine": (DealDamage(90), DiscardTopOfOpponentDeck(2)),
    "Maximum Drilling": (DamageIfExtraEnergyAttached(base=200, bonus=130, extra_needed=2, cost_count=3),),
}
ATTACK_EFFECTS["me5-103"] = ATTACK_EFFECTS["me5-65"]  # Mega Excadrill ex 別絵柄
ATTACK_EFFECTS["me5-66"] = {  # Pikipek
    "Double Stab": (FlipMultipleCoinsForBonusDamage(base=0, count=2, per_heads=10),),
}
ATTACK_EFFECTS["me5-68"] = {  # Toucannon(特性Aerial Drawは見送り)
    "Feather Rondo": (DamagePerTotalBenchedPokemonBothSides(base=60, per_bench=20),),
}
ATTACK_EFFECTS["me5-69"] = {"Power Edge": (DealDamage(40),)}  # Type: Null
ATTACK_EFFECTS["me5-70"] = {  # Silvally(特性Call a Buddyは見送り)
    "Air Slash": (DealDamage(130), DiscardOwnEnergy(count=1)),
}

_CRUSHING_HAMMER_REPRINT_ID = "me5-105"
TRAINER_EFFECTS[_CRUSHING_HAMMER_REPRINT_ID] = TRAINER_EFFECTS["me3-71"]  # Crushing Hammer 別絵柄

# ---- Jレギュレーション新規カード実装 第18バッチ ----

ATTACK_EFFECTS["me5-85"] = ATTACK_EFFECTS["me5-3"]  # Fomantis 別絵柄
ATTACK_EFFECTS["me5-87"] = ATTACK_EFFECTS["me5-13"]  # Goldeen 別絵柄
ATTACK_EFFECTS["me5-88"] = ATTACK_EFFECTS["me5-20"]  # Primarina 別絵柄
ATTACK_EFFECTS["me5-90"] = ATTACK_EFFECTS["me5-30"]  # Slowbro 別絵柄
ATTACK_EFFECTS["me5-92"] = ATTACK_EFFECTS["me5-54"]  # Thievul 別絵柄
ATTACK_EFFECTS["me5-93"] = ATTACK_EFFECTS["me5-62"]  # Bastiodon 別絵柄
ATTACK_EFFECTS["me5-94"] = ATTACK_EFFECTS["me5-68"]  # Toucannon 別絵柄
ATTACK_EFFECTS["me5-95"] = ATTACK_EFFECTS["me5-70"]  # Silvally 別絵柄
ATTACK_EFFECTS["me5-96"] = ATTACK_EFFECTS["me5-4"]  # Lurantis ex 別絵柄
ATTACK_EFFECTS["me5-97"] = ATTACK_EFFECTS["me5-16"]  # Wailord ex 別絵柄
ATTACK_EFFECTS["me5-98"] = ATTACK_EFFECTS["me5-27"]  # Mega Zeraora ex 別絵柄
ATTACK_EFFECTS["me5-99"] = ATTACK_EFFECTS["me5-38"]  # Mega Chandelure ex 別絵柄

ATTACK_EFFECTS["me5-71"] = {  # Bombirdier(Challenging Deliveryは2枚コインどちらも表という
    # 複合条件検索のため見送り)
    "Speed Wing": (DealDamage(100),),
}
TRAINER_EFFECTS["me5-75"] = (ConfuseBothActiveNonDarknessPokemon(),)  # Dark Bell
TRAINER_EFFECTS["me5-106"] = TRAINER_EFFECTS["me5-75"]  # Dark Bell 別絵柄
TRAINER_EFFECTS["me5-79"] = (
    DrawPerOpponentPokemonWithSubtypes(subtypes=("MEGA", "ex")),
)  # Jett
TRAINER_EFFECTS["me5-81"] = (DiscardOpponentActiveEnergy(),)  # Rust Syndicate Grunt(使用条件はlegal_actionsでゲート済み)
ATTACK_EFFECTS["me5-86"] = {  # Armarouge
    "Flame Legion": (DamagePerBenchedPokemonWithEnergyType(base=40, per_pokemon=40, energy_type="Fire"),),
}
ATTACK_EFFECTS["me5-89"] = {  # Manectric(Flashing Barrierは攻撃元のサブタイプ限定シールドのため見送り)
    "Sonic Edge": (DealDamageIgnoringDefenderShieldAndReduction(110),),
}

# ---- Jレギュレーション新規カード実装 第19バッチ ----

ATTACK_EFFECTS["me5-114"] = ATTACK_EFFECTS["me5-27"]  # Mega Zeraora ex 別絵柄
ATTACK_EFFECTS["me5-115"] = ATTACK_EFFECTS["me5-38"]  # Mega Chandelure ex 別絵柄
ATTACK_EFFECTS["me5-116"] = ATTACK_EFFECTS["me5-48"]  # Mega Darkrai ex 別絵柄
ATTACK_EFFECTS["me5-120"] = ATTACK_EFFECTS["me5-48"]  # Mega Darkrai ex 別絵柄
ATTACK_EFFECTS["me5-117"] = ATTACK_EFFECTS["me5-55"]  # Morpeko ex 別絵柄
TRAINER_EFFECTS["me5-112"] = TRAINER_EFFECTS["me5-81"]  # Rust Syndicate Grunt 別絵柄
TRAINER_EFFECTS["me5-109"] = TRAINER_EFFECTS["me5-78"]  # Gwynn 別絵柄
TRAINER_EFFECTS["me5-119"] = TRAINER_EFFECTS["me5-78"]  # Gwynn 別絵柄

# ==== Iレギュレーション新規カード実装 ====
# ---- 攻撃内容が既存カードと完全一致のため再利用(種族名は異なるが実カードテキストが同一) ----

ATTACK_EFFECTS["me2pt5-136"] = ATTACK_EFFECTS["me4-53"]  # N's Zorua(me4-53と攻撃内容が完全一致のため再利用)
ATTACK_EFFECTS["me2pt5-23"] = ATTACK_EFFECTS["me2pt5-29"]  # Ethan's Slugma(me2pt5-29と攻撃内容が完全一致のため再利用)
TRAINER_EFFECTS["me2pt5-258"] = TRAINER_EFFECTS["me2pt5-214"]  # Cheren(me2pt5-214と効果が完全一致のため再利用)
TRAINER_EFFECTS["rsv10pt5-81"] = TRAINER_EFFECTS["me2pt5-214"]  # Cheren(me2pt5-214と効果が完全一致のため再利用)
ATTACK_EFFECTS["sv10-114"] = ATTACK_EFFECTS["me3-48"]  # Team Rocket's Nidoran♀(me3-48と攻撃内容が完全一致のため再利用)
ATTACK_EFFECTS["sv10-35"] = ATTACK_EFFECTS["me2pt5-29"]  # Ethan's Slugma(me2pt5-29と攻撃内容が完全一致のため再利用)
ATTACK_EFFECTS["sv10-37"] = ATTACK_EFFECTS["me2pt5-29"]  # Team Rocket's Houndour(me2pt5-29と攻撃内容が完全一致のため再利用)
ATTACK_EFFECTS["sv9-35"] = ATTACK_EFFECTS["me3-20"]  # Lotad(me3-20と攻撃内容が完全一致のため再利用)
ATTACK_EFFECTS["svp-189"] = ATTACK_EFFECTS["me4-53"]  # N's Zorua(me4-53と攻撃内容が完全一致のため再利用)

# ---- Iレギュレーション新規カード実装 第1バッチ ----

ATTACK_EFFECTS["me1-1"] = {  # Bulbasaur
    "Bind Down": (DealDamage(10), DisableDefenderRetreatNextTurn()),
}
ATTACK_EFFECTS["me1-133"] = ATTACK_EFFECTS["me1-1"]  # Bulbasaur 別絵柄
ATTACK_EFFECTS["me1-100"] = {  # Mega Latias ex(実カードは「Strafe」実カードテキスト通り、攻撃後の
    # 「してもよい」入れ替え。既存のAFTER_ATTACK_TRIGGER_EFFECTS機構を再利用)
    "Strafe": (DealDamage(40),),
    "Illusory Impulse": (DealDamage(300), DiscardOwnEnergy(count=99)),
}
ATTACK_EFFECTS["me1-163"] = ATTACK_EFFECTS["me1-100"]  # Mega Latias ex 別絵柄
ATTACK_EFFECTS["me1-181"] = ATTACK_EFFECTS["me1-100"]  # Mega Latias ex 別絵柄
for _alias_id in ("me1-100", "me1-163", "me1-181"):
    AFTER_ATTACK_TRIGGER_EFFECTS[(_alias_id, "Strafe")] = (SwitchActiveWithBench(),)
ATTACK_EFFECTS["me1-101"] = {"Dragon Claw": (DealDamage(130),)}  # Latios(特性Lustrous Assistは見送り)
ATTACK_EFFECTS["me1-102"] = {  # Spearow
    "Pluck": (DiscardOpponentActiveTool(), DealDamage(10)),
}
ATTACK_EFFECTS["me1-151"] = ATTACK_EFFECTS["me1-102"]  # Spearow 別絵柄
ATTACK_EFFECTS["me1-103"] = {  # Fearow
    "Repeating Drill": (FlipMultipleCoinsForBonusDamage(base=0, count=5, per_heads=30),),
}
ATTACK_EFFECTS["me1-105"] = {  # Delibird(Quick Giftは「先攻なら」条件付き山札検索のため見送り)
    "Gentle Slap": (DealDamage(30),),
}
ATTACK_EFFECTS["me1-152"] = ATTACK_EFFECTS["me1-105"]  # Delibird 別絵柄
ATTACK_EFFECTS["me1-106"] = {  # Miltank
    "Bellyful of Milk": (AllCoinsHeadsThen(count=2, then=(HealTarget(999),)),),
    "Tackle": (DealDamage(60),),
}
ATTACK_EFFECTS["me1-107"] = {  # Buneary
    "Charm": (DebuffDefenderAttackDamageNextTurn(20),),
    "Skip": (DealDamage(10),),
}
ATTACK_EFFECTS["me1-108"] = {  # Lopunny
    "Dashing Kick": (DealBonusDamageToChosenOpponentBench(50),),
    "Spiral Kick": (DealDamage(60),),
}
ATTACK_EFFECTS["me1-109"] = {  # Yungoos
    "Collect": (Draw(1),),
    "Gnaw": (DealDamage(20),),
}
ATTACK_EFFECTS["me1-11"] = {  # Shuckle(特性Fermented Juiceは見送り)
    "Rollout": (DealDamage(30),),
}
ATTACK_EFFECTS["me1-136"] = ATTACK_EFFECTS["me1-11"]  # Shuckle 別絵柄
ATTACK_EFFECTS["me1-110"] = {"Bite": (DealDamage(50),)}  # Gumshoos(特性Evidence Gatheringは見送り)
ATTACK_EFFECTS["me1-153"] = ATTACK_EFFECTS["me1-110"]  # Gumshoos 別絵柄
ATTACK_EFFECTS["me1-111"] = {  # Stufful
    "Light Punch": (DealDamage(10),),
    "Flop": (DealDamage(20),),
}
ATTACK_EFFECTS["me1-154"] = ATTACK_EFFECTS["me1-111"]  # Stufful 別絵柄
ATTACK_EFFECTS["me1-112"] = {  # Bewear
    "Knuckle Punch": (DealDamage(50),),
    "Hyper Lariat": (DealDamage(100), AllCoinsHeadsThen(count=2, then=(DealDamage(100),))),
}
TRAINER_EFFECTS["me1-126"] = (ForceOpponentSwitchOpponentChooses(),)  # Repel(グッズ。以前はATTACK_EFFECTSに
# 誤登録されており、get_trainer_scriptからは参照されず未実装扱いになっていた)
ATTACK_EFFECTS["me1-13"] = {  # Seedot
    "Nap": (HealSelf(20),),
    "Seed Bomb": (DealDamage(20),),
}
ATTACK_EFFECTS["me1-14"] = {  # Nuzleaf
    "Pound": (DealDamage(30),),
    "Low Kick": (DealDamage(50),),
}
TRAINER_EFFECTS["me1-121"] = (
    SearchDeckForPokemonToHand(count=1, required_subtypes=("MEGA", "ex")),
)  # Mega Signal
TRAINER_EFFECTS["me1-171"] = TRAINER_EFFECTS["me1-121"]  # Mega Signal 別絵柄
TRAINER_EFFECTS["me2pt5-193"] = TRAINER_EFFECTS["me1-121"]  # Mega Signal 別絵柄
TRAINER_EFFECTS["me1-123"] = (HealTargetAndClearStatus(amount=60),)  # Pokémon Center Lady
TRAINER_EFFECTS["me1-130"] = (SwitchActiveWithBench(),)  # Switch
TRAINER_EFFECTS["me2-123"] = TRAINER_EFFECTS["me1-130"]  # Switch 別絵柄
ATTACK_EFFECTS["me1-134"] = {"Razor Leaf": (DealDamage(60),)}  # Ivysaur
ATTACK_EFFECTS["me1-2"] = ATTACK_EFFECTS["me1-134"]  # Ivysaur 別絵柄
ATTACK_EFFECTS["me1-135"] = {  # Exeggutor
    "Guard Press": (DealDamage(30), ApplyDamageReductionToSelf(30)),
    "Stomping Wood": (DealDamage(60), DamagePerOwnAttachedEnergyCount(per_energy=30, energy_type="Grass")),
}
ATTACK_EFFECTS["me1-5"] = ATTACK_EFFECTS["me1-135"]  # Exeggutor 別絵柄
ATTACK_EFFECTS["me1-137"] = {  # Ninjask(特性Cast-Off Shellは見送り)
    "U-turn": (DealDamage(90), SwitchActiveWithBench()),
}
ATTACK_EFFECTS["me1-17"] = ATTACK_EFFECTS["me1-137"]  # Ninjask 別絵柄
ATTACK_EFFECTS["me1-138"] = {  # Vulpix
    "Stampede": (DealDamage(10),),
    "Combustion": (DealDamage(20),),
}
ATTACK_EFFECTS["me1-19"] = ATTACK_EFFECTS["me1-138"]  # Vulpix 別絵柄
ATTACK_EFFECTS["me1-139"] = {"Flare": (DealDamage(30),)}  # Litleo
ATTACK_EFFECTS["me1-23"] = ATTACK_EFFECTS["me1-139"]  # Litleo 別絵柄
ATTACK_EFFECTS["me1-16"] = {"Scratch": (DealDamage(20),)}  # Nincada
ATTACK_EFFECTS["me1-140"] = {  # Snover
    "Beat": (DealDamage(10),),
    "Icy Snow": (DealDamage(30),),
}
ATTACK_EFFECTS["me1-35"] = ATTACK_EFFECTS["me1-140"]  # Snover 別絵柄
ATTACK_EFFECTS["me1-141"] = {  # Clawitzer(特性Fall Back to Reloadは見送り)
    "Aqua Launcher": (DealDamage(210), DiscardOwnEnergy(count=99)),
}
ATTACK_EFFECTS["me1-38"] = ATTACK_EFFECTS["me1-141"]  # Clawitzer 別絵柄
ATTACK_EFFECTS["me1-142"] = {  # Inteleon(Bring Downは場のポケモンから最小HPを選んできぜつという新規機構が必要なため見送り)
    "Water Shot": (DealDamage(110), DiscardOwnEnergy(count=1)),
}
ATTACK_EFFECTS["me1-41"] = ATTACK_EFFECTS["me1-142"]  # Inteleon 別絵柄
ATTACK_EFFECTS["me1-143"] = {  # Helioptile
    "Double Scratch": (FlipMultipleCoinsForBonusDamage(base=0, count=2, per_heads=10),),
}
ATTACK_EFFECTS["me1-52"] = ATTACK_EFFECTS["me1-143"]  # Helioptile 別絵柄
ATTACK_EFFECTS["me1-144"] = {  # Shedinja(特性Fragile Huskは見送り)
    "Damage Beat": (DamagePerDefenderDamageCounters(base=0, per_counter=20),),
}
ATTACK_EFFECTS["me1-61"] = ATTACK_EFFECTS["me1-144"]  # Shedinja 別絵柄
ATTACK_EFFECTS["me1-145"] = {  # Houndstone(Horrifying Biteはコイン+ランダム手札公開シャッフルの複合効果のため見送り)
    "Hammer In": (DealDamage(130),),
}
ATTACK_EFFECTS["me1-66"] = ATTACK_EFFECTS["me1-145"]  # Houndstone 別絵柄
ATTACK_EFFECTS["me1-146"] = {  # Marshadow(きぜつ後シールドの条件付き効果は見送り)
    "Shadowy Side Kick": (DealDamage(60),),
}
ATTACK_EFFECTS["me1-80"] = ATTACK_EFFECTS["me1-146"]  # Marshadow 別絵柄
ATTACK_EFFECTS["me1-147"] = {"Hammer In": (DealDamage(130),)}  # Garganacl(特性Powerful a-Saltは見送り)
ATTACK_EFFECTS["me1-84"] = ATTACK_EFFECTS["me1-147"]  # Garganacl 別絵柄
ATTACK_EFFECTS["me1-148"] = {  # Spiritomb(特性Spiteful Swirlは見送り)
    "Mountain Breaker": (DealDamage(10), DiscardTopOfOpponentDeck(1)),
}
ATTACK_EFFECTS["me1-87"] = ATTACK_EFFECTS["me1-148"]  # Spiritomb 別絵柄
ATTACK_EFFECTS["me1-149"] = {  # Shroodle
    "Poison Jab": (DealDamage(20), InflictStatusOnDefender(condition="poisoned")),
}
ATTACK_EFFECTS["me1-91"] = ATTACK_EFFECTS["me1-149"]  # Shroodle 別絵柄
ATTACK_EFFECTS["me1-15"] = {  # Shiftry(Reversing Gustはコイン+選択シャッフル戻しの複合効果のため見送り)
    "Perplex": (DealDamage(100), InflictStatusOnDefender(condition="confused")),
}
ATTACK_EFFECTS["me1-150"] = {  # Steelix
    "Welcoming Tail": (BonusDamageIfOwnPrizesRemainingExactly(base=40, bonus=200, count=6),),
    "Skull Bash": (DealDamage(140),),
}
ATTACK_EFFECTS["me1-93"] = ATTACK_EFFECTS["me1-150"]  # Steelix 別絵柄
ABILITY_EFFECTS["me1-155"] = {"Solar Transfer": (MoveEnergyBetweenOwnPokemon(energy_type="Grass"),)}  # Mega Venusaur ex
ATTACK_EFFECTS["me1-155"] = {
    "Jungle Dump": (DealDamage(240), HealSelf(30)),
}
ATTACK_EFFECTS["me1-177"] = ATTACK_EFFECTS["me1-155"]  # Mega Venusaur ex 別絵柄
ABILITY_EFFECTS["me1-177"] = ABILITY_EFFECTS["me1-155"]
ATTACK_EFFECTS["me1-156"] = {  # Mega Camerupt ex
    "Roasting Heat": (BonusDamageIfDefenderBurned(base=80, bonus=160),),
    "Volcanic Meteor": (DealDamage(280), DiscardOwnEnergy(count=2)),
}
ATTACK_EFFECTS["me1-22"] = ATTACK_EFFECTS["me1-156"]  # Mega Camerupt ex 別絵柄
ATTACK_EFFECTS["me1-157"] = {  # Mega Abomasnow ex(Hammer-lancheは山札上6枚を見て水エネルギーを数える効果が未実装のため見送り)
    "Frost Barrier": (DealDamage(200), ApplyDamageReductionToSelf(30)),
}
ATTACK_EFFECTS["me1-36"] = ATTACK_EFFECTS["me1-157"]  # Mega Abomasnow ex 別絵柄
ATTACK_EFFECTS["me1-158"] = {  # Mega Manectric ex
    "Flash Ray": (ApplyScopedDamageImmunityToSelf(scope="basic"), DealDamage(120)),
    "Riotous Blasting": (DamageBonusWithOptionalEnergyDiscard(200, 130),),  # 捨てない/全て捨てる、をワザ選択時に選ぶ
}
ATTACK_EFFECTS["me1-50"] = ATTACK_EFFECTS["me1-158"]  # Mega Manectric ex 別絵柄
ATTACK_EFFECTS["me1-159"] = {  # Mega Gardevoir ex(Overflowing Wishesは複数ベンチへの自由分配のため見送り)
    "Mega Symphonia": (DamagePerOwnAttachedEnergyOfTypeAcrossBoard(per_energy=50, energy_type="Psychic"),),
}
for _alias_id in ("me1-178", "me1-187", "me1-60", "me2pt5-89"):
    ATTACK_EFFECTS[_alias_id] = ATTACK_EFFECTS["me1-159"]  # Mega Gardevoir ex 別絵柄
ATTACK_EFFECTS["me1-160"] = {  # Mega Lucario ex(Aura Jabは複数ベンチへの自由分配のため見送り)
    "Mega Brave": (DealDamage(270), LockOwnAttackNextTurn(attack_name="Mega Brave")),
}
for _alias_id in ("me1-179", "me1-188", "me1-77", "me2pt5-113"):
    ATTACK_EFFECTS[_alias_id] = ATTACK_EFFECTS["me1-160"]  # Mega Lucario ex 別絵柄
ATTACK_EFFECTS["me1-161"] = {  # Mega Absol ex(Terminal Periodはダメカンちょうど6個の判定という
    # 新規機構が必要なため見送り)
    "Claw of Darkness": (DealDamage(200), RevealOpponentHandThenDiscardChosen()),
}
ATTACK_EFFECTS["me1-180"] = ATTACK_EFFECTS["me1-161"]  # Mega Absol ex 別絵柄
ATTACK_EFFECTS["me1-162"] = {  # Mega Mawile ex
    "Gobble Down": (DamagePerOwnPrizesTaken(base=0, per_prize=80),),
    "Huge Bite": (DamageReducedIfDefenderAlreadyDamaged(normal=260, reduced=30),),
}
ATTACK_EFFECTS["me1-94"] = ATTACK_EFFECTS["me1-162"]  # Mega Mawile ex 別絵柄
ABILITY_EFFECTS["me1-164"] = {"Run Errand": (Draw(2),)}  # Mega Kangaskhan ex
ATTACK_EFFECTS["me1-164"] = {
    "Rapid-Fire Combo": (DealDamageFlipUntilTailsBonus(base=200, bonus_per_heads=50),),
}
ATTACK_EFFECTS["me1-182"] = ATTACK_EFFECTS["me1-164"]  # Mega Kangaskhan ex 別絵柄
ABILITY_EFFECTS["me1-182"] = ABILITY_EFFECTS["me1-164"]
TRAINER_EFFECTS["me1-169"] = (ShuffleOwnHandIntoDeckThenDraw(count=6, bonus_count_if_prizes_remaining=8),)  # Lillie's Determination
TRAINER_EFFECTS["me1-184"] = TRAINER_EFFECTS["me1-169"]  # Lillie's Determination 別絵柄
TRAINER_EFFECTS["me2pt5-192"] = TRAINER_EFFECTS["me1-169"]  # Lillie's Determination 別絵柄

# ---- Iレギュレーション新規カード実装 第2バッチ ----

TRAINER_EFFECTS["me1-175"] = TRAINER_EFFECTS["me1-125"]  # Rare Candy 別絵柄(既存実装と同一)
TRAINER_EFFECTS["me1-176"] = TRAINER_EFFECTS["me1-132"]  # Wally's Compassion 別絵柄(既存実装と同一、legal_actionsも対応済み)
TRAINER_EFFECTS["me1-186"] = TRAINER_EFFECTS["me1-132"]  # Wally's Compassion 別絵柄
ATTACK_EFFECTS["me1-18"] = {"Earthen Power": (BonusDamageIfStadiumInPlay(base=30, bonus=50),)}  # Dhelmise
ATTACK_EFFECTS["me1-20"] = {  # Ninetales(Supernatural Shapeshifterは山札トップのサポートを流用する
    # 新規機構が必要なため見送り)
    "Combustion": (DealDamage(60),),
}
ATTACK_EFFECTS["me1-21"] = {  # Numel
    "Call for Family": (SearchDeckForBasicPokemonToBench(count=2),),
    "Flare": (DealDamage(30),),
}
ATTACK_EFFECTS["me1-24"] = {  # Pyroar(特性Intimidating Fangは見送り)
    "Searing Flame": (DealDamage(70), InflictStatusOnDefender(condition="burned")),
}
ATTACK_EFFECTS["me1-25"] = {  # Volcanion
    "Singe": (InflictStatusOnDefender(condition="burned"),),
    "Backfire": (DealDamage(130), ReturnOwnEnergyToHand(count=2)),
}
ATTACK_EFFECTS["me1-26"] = {"Wild Kick": (FlipCoinThen(heads=(DealDamage(30),)),)}  # Scorbunny
ATTACK_EFFECTS["me1-27"] = {"Jumping Kick": (DealDamageToChosenOpponentPokemon(40),)}  # Raboot
ATTACK_EFFECTS["me1-29"] = {  # Sizzlipede
    "Ram": (DealDamage(10),),
    "Combustion": (DealDamage(50),),
}
ATTACK_EFFECTS["me1-30"] = {"Heat Crawler": (DealDamage(140),)}  # Centiskorch(Coiling Crushは2枚コイン×
    # エネルギー破棄という複合効果のため見送り)
ATTACK_EFFECTS["me1-32"] = {  # Mantine
    "Call for Family": (SearchDeckForBasicPokemonToBench(count=2),),
    "Waterfall": (DealDamage(50),),
}
ATTACK_EFFECTS["me1-33"] = {  # Corphish
    "Vise Grip": (DealDamage(10),),
    "Take Down": (DealDamage(30), SelfDamage(10)),
}
ATTACK_EFFECTS["me1-37"] = {"Wave Splash": (DealDamage(50),)}  # Clauncher
ATTACK_EFFECTS["me1-39"] = {"Surprise Attack": (FlipCoinThen(heads=(DealDamage(30),)),)}  # Sobble
ATTACK_EFFECTS["me1-4"] = {  # Exeggcute
    "Jam-Packed": (SearchDeckForBasicEnergyAttachToTarget(count=1, energy_type="Grass", self_only=True),),
}
ATTACK_EFFECTS["me1-40"] = {  # Drizzile
    "Double Stab": (FlipMultipleCoinsForBonusDamage(base=0, count=2, per_heads=30),),
}
ATTACK_EFFECTS["me1-42"] = {"Hide": (FlipCoinThen(heads=(ApplyShieldToSelf(),)),)}  # Snom
ATTACK_EFFECTS["me1-43"] = {  # Frosmoth
    "Chilling Wings": (DealDamageToAllOpponentPokemon(20), InflictStatusOnDefender(condition="asleep")),
}
ATTACK_EFFECTS["me1-44"] = {  # Eiscue
    "Freezing Headbutt": (DealDamage(20), FlipCoinThen(heads=(InflictStatusOnDefender(condition="paralyzed"),))),
    "Tackle": (DealDamage(90),),
}
ATTACK_EFFECTS["me1-45"] = {"Beam": (DealDamage(10),)}  # Magnemite
ATTACK_EFFECTS["me1-46"] = {  # Magneton
    "Thunder Shock": (DealDamage(30), FlipCoinThen(heads=(InflictStatusOnDefender(condition="paralyzed"),))),
}
ATTACK_EFFECTS["me1-47"] = {  # Magnezone
    "Upper Spark": (DamageIfEvolvedFromNamedThisTurn(base=50, bonus=120, from_name="Magneton"),),
    "Flashing Bolt": (DealDamage(160), LockOwnAttackNextTurn(attack_name="Flashing Bolt")),
}
ATTACK_EFFECTS["me1-48"] = {  # Raikou
    "Electro Fall": (
        BonusDamageIfOwnBoardEnergyTypeCountAtLeast(base=30, bonus=90, energy_type="Lightning", min_count=4),
    ),
}
ATTACK_EFFECTS["me1-49"] = {"Thunder Jolt": (DealDamage(30), SelfDamage(10))}  # Electrike
ATTACK_EFFECTS["me1-53"] = {  # Heliolisk
    "Dazzle Blast": (DealDamage(20), InflictStatusOnDefender(condition="confused")),
    "Head Bolt": (DealDamage(70),),
}
ATTACK_EFFECTS["me1-57"] = {  # Jynx
    "Psychic": (DamagePerOpponentActiveEnergyCount(base=30, per_energy=30),),
}
ATTACK_EFFECTS["me1-6"] = {  # Tangela
    "Poison Powder": (InflictStatusOnDefender(condition="poisoned"),),
    "Hook": (DealDamage(30),),
}
ATTACK_EFFECTS["me1-62"] = {  # Spoink
    "Triple Spin": (FlipMultipleCoinsForBonusDamage(base=0, count=3, per_heads=10),),
}
ATTACK_EFFECTS["me1-63"] = {"Psychic Sphere": (DealDamage(60),)}  # Grumpig(特性Energized Stepsは見送り)
ATTACK_EFFECTS["me1-64"] = {  # Xerneas
    "Geo Gate": (SearchDeckForBasicPokemonToBench(count=3, pokemon_type="Psychic"),),
    "Bright Horns": (DealDamage(120), LockOwnAttackNextTurn(attack_name="Bright Horns")),
}
ATTACK_EFFECTS["me1-65"] = {  # Greavard
    "Stampede": (DealDamage(10),),
    "Take Down": (DealDamage(40), SelfDamage(10)),
}
ATTACK_EFFECTS["me1-67"] = {"Slap": (DealDamage(10),)}  # Gimmighoul
ATTACK_EFFECTS["me1-68"] = {  # Sandshrew
    "Dig Claws": (DealDamage(10),),
    "Mud-Slap": (DealDamage(20),),
}
ATTACK_EFFECTS["me1-69"] = {  # Sandslash
    "Sand Attack": (DealDamage(50), InflictStatusOnDefender(condition="confused")),
    "Mud Shot": (DealDamage(100),),
}
ATTACK_EFFECTS["me1-7"] = {  # Tangrowth
    "Absorb": (DealDamage(30), HealSelf(30)),
    "Pumped-Up Whip": (DamageIfExtraEnergyAttached(base=120, bonus=140, extra_needed=2, cost_count=4),),
}
ATTACK_EFFECTS["me1-70"] = {  # Onix
    "Bind": (DealDamage(30), FlipCoinThen(heads=(InflictStatusOnDefender(condition="paralyzed"),))),
    "Strength": (DealDamage(100),),
}
ATTACK_EFFECTS["me1-71"] = {  # Tyrogue
    "Pow-Pow Punching": (DealDamageFlipUntilTailsBonus(base=10, bonus_per_heads=30),),
}
ATTACK_EFFECTS["me1-72"] = {  # Makuhita
    "Corkscrew Punch": (DealDamage(10),),
    "Confront": (DealDamage(30),),
}
ATTACK_EFFECTS["me1-73"] = {"Wild Press": (DealDamage(210), SelfDamage(70))}  # Hariyama(特性Heave-Ho Catcherは見送り)
ATTACK_EFFECTS["me1-74"] = {"Power Gem": (DealDamage(50),)}  # Lunatone(特性Lunar Cycleは見送り)
ATTACK_EFFECTS["me1-76"] = {  # Riolu
    "Accelerating Stab": (DealDamage(30), LockOwnAttackNextTurn(attack_name="Accelerating Stab")),
}
ATTACK_EFFECTS["me2pt5-112"] = ATTACK_EFFECTS["me1-76"]  # Riolu 別絵柄
ATTACK_EFFECTS["me1-78"] = {"Smack": (DealDamage(20),)}  # Croagunk
ATTACK_EFFECTS["me1-79"] = {"Reckless Charge": (DealDamage(70), SelfDamage(20))}  # Toxicroak
ATTACK_EFFECTS["me1-8"] = {"Razor Leaf": (DealDamage(20),)}  # Chikorita
ATTACK_EFFECTS["me1-81"] = {  # Stonjourner
    "Stony Kick": (DealDamage(20), DealBonusDamageToChosenOpponentBench(20)),
    "Boundless Power": (DealDamage(140), LockOwnAttackNextTurn(attack_name="Boundless Power", lock_all_attacks=True)),
}
ATTACK_EFFECTS["me1-82"] = {"Ram": (DealDamage(10),)}  # Nacli
ATTACK_EFFECTS["me1-83"] = {"Rock Hurl": (DealDamageIgnoringResistanceOnly(50),)}  # Naclstack
ATTACK_EFFECTS["me1-85"] = {  # Crawdaunt(Cutting Riposteの「ダメカンがあれば悪タイプとしても
    # 支払える」コスト特例は未実装のため見送り)
    "Vise Grip": (DealDamage(30),),
    "Cutting Riposte": (DealDamage(130),),
}
ATTACK_EFFECTS["me1-88"] = {  # Yveltal
    "Clutch": (DealDamage(20), DisableDefenderRetreatNextTurn()),
    "Dark Feather": (DealDamage(110),),
}
ATTACK_EFFECTS["me1-89"] = {"Darkness Fang": (DealDamage(20),)}  # Nickit
ATTACK_EFFECTS["me1-9"] = {"Push Down": (DealDamage(50), ForceOpponentSwitchOpponentChooses())}  # Bayleef
ATTACK_EFFECTS["me1-90"] = {  # Thievul
    "Greedy Hunt": (DrawUpTo(6),),
    "Pitch-Black Fangs": (DealDamage(60),),
}
ATTACK_EFFECTS["me1-95"] = {  # Dialga(Chrono Burstの「してもよいエネルギー山札戻し」ボーナスは見送り)
    "Beam": (DealDamage(30),),
    "Chrono Burst": (DealDamage(80),),
}

# ---- Iレギュレーション新規カード実装 第3バッチ ----

ATTACK_EFFECTS["me1-96"] = {"Beat": (DealDamage(20),)}  # Tinkatink
ATTACK_EFFECTS["me1-97"] = {"Light Punch": (DealDamage(30),)}  # Tinkatuff(特性Haphazard Hammerは見送り)
ATTACK_EFFECTS["me1-98"] = {  # Tinkaton
    "Windup Swing": (DamageReducedPerDefenderEnergyCount(base=240, per_energy=60),),
}
ATTACK_EFFECTS["me1-99"] = {"Speed Attack": (DealDamage(100),)}  # Gholdengo(All-You-Can-Grabは見送り)
ATTACK_EFFECTS["me2-1"] = {"Seed Bomb": (DealDamage(20),)}  # Oddish
ATTACK_EFFECTS["me2-10"] = {  # Lokix
    "Low Kick": (DealDamage(30),),
    "Jumping Shot": (DealDamage(150), ShuffleSelfIntoDeck()),
}
ATTACK_EFFECTS["me2-100"] = {  # Zacian
    "Limit Break": (BonusDamageIfOpponentPrizesAtMost(base=50, bonus=90, threshold=3),),
}
ATTACK_EFFECTS["me2-45"] = ATTACK_EFFECTS["me2-100"]  # Zacian 別絵柄
ATTACK_EFFECTS["me2-101"] = {"Cutting Wind": (DealDamage(130),)}  # Flygon(特性Sandy Flappingは見送り)
ATTACK_EFFECTS["me2-53"] = ATTACK_EFFECTS["me2-101"]  # Flygon 別絵柄
ATTACK_EFFECTS["me2-103"] = {"Gentle Slap": (DealDamage(100),)}  # Toxtricity(特性Sinister Surgeは見送り)
ATTACK_EFFECTS["me2-68"] = ATTACK_EFFECTS["me2-103"]  # Toxtricity 別絵柄
ATTACK_EFFECTS["me2-104"] = {  # Togedemaru
    "Find a Friend": (SearchDeckForPokemonToHand(count=1),),
    "Gnaw": (DealDamage(30),),
}
ATTACK_EFFECTS["me2-73"] = ATTACK_EFFECTS["me2-104"]  # Togedemaru 別絵柄
ATTACK_EFFECTS["me2-105"] = {  # Wigglytuff
    "Round": (DamagePerOwnPokemonWithNamedAttackInPlay(per_pokemon=40, attack_name="Round"),),
    "Seismic Toss": (DealDamage(100),),
}
ATTACK_EFFECTS["me2-77"] = ATTACK_EFFECTS["me2-105"]  # Wigglytuff 別絵柄
ATTACK_EFFECTS["me2-107"] = {"Slap": (DealDamage(50),)}  # Ambipom(Dual Tailは2体選択の複合効果のため見送り)
ATTACK_EFFECTS["me2-79"] = ATTACK_EFFECTS["me2-107"]  # Ambipom 別絵柄
ATTACK_EFFECTS["me2-108"] = {  # Mega Heracross ex(Juggernaut Hornの「相手の直前の番の被ダメージ」
    # 判定は見送り)
    "Mountain Ramming": (DealDamage(170), DiscardTopOfOpponentDeck(2)),
}
ATTACK_EFFECTS["me2-4"] = ATTACK_EFFECTS["me2-108"]  # Mega Heracross ex 別絵柄
ATTACK_EFFECTS["me2-11"] = {"Live Coal": (DealDamage(20),)}  # Charmander(特性Agileは見送り)
ATTACK_EFFECTS["me2-110"] = {"Fire Wing": (DealDamage(110),)}  # Oricorio ex(特性Excited Turboは見送り)
ATTACK_EFFECTS["me2-18"] = ATTACK_EFFECTS["me2-110"]  # Oricorio ex 別絵柄
ATTACK_EFFECTS["me2-111"] = {  # Rotom ex(特性Multi Adapterは見送り)
    "Thunderbolt": (DealDamage(130), DiscardOwnEnergy(count=99)),
}
ATTACK_EFFECTS["me2-126"] = ATTACK_EFFECTS["me2-111"]  # Rotom ex 別絵柄
ATTACK_EFFECTS["me2-29"] = ATTACK_EFFECTS["me2-111"]  # Rotom ex 別絵柄
ATTACK_EFFECTS["me2-112"] = {"Hexa-Magic": (DrawUpTo(6),)}  # Mismagius ex(特性Swirling Proseは見送り)
ATTACK_EFFECTS["me2-36"] = ATTACK_EFFECTS["me2-112"]  # Mismagius ex 別絵柄
ATTACK_EFFECTS["me2-113"] = {  # Mega Sharpedo ex
    "Greedy Fang": (DealDamage(70), Draw(2)),
    "Hungry Jaws": (BonusDamageIfSelfDamaged(base=120, bonus=150),),
}
ATTACK_EFFECTS["me2-127"] = ATTACK_EFFECTS["me2-113"]  # Mega Sharpedo ex 別絵柄
ATTACK_EFFECTS["me2-61"] = ATTACK_EFFECTS["me2-113"]  # Mega Sharpedo ex 別絵柄
ATTACK_EFFECTS["me2-114"] = {  # Empoleon ex(特性Emperor's StanceはNON_DAMAGE_EFFECT_IMMUNE_CARD_IDSで対応済み)
    "Iron Feathers": (DealDamage(210), ApplyDamageReductionToSelf(60)),
}
ATTACK_EFFECTS["me2-70"] = ATTACK_EFFECTS["me2-114"]  # Empoleon ex 別絵柄
ATTACK_EFFECTS["me2-115"] = {  # Mega Lopunny ex
    "Gale Thrust": (DamageIfBecameActiveThisTurn(base=60, bonus=170),),
    "Spiky Hopper": (DealDamageIgnoringDefenderShieldAndReduction(160),),
}
ATTACK_EFFECTS["me2-128"] = ATTACK_EFFECTS["me2-115"]  # Mega Lopunny ex 別絵柄
ATTACK_EFFECTS["me2-84"] = ATTACK_EFFECTS["me2-115"]  # Mega Lopunny ex 別絵柄
TRAINER_EFFECTS["me2-118"] = TRAINER_EFFECTS["m2-77"]  # Dawn(m2-77と同一カードの別絵柄)
TRAINER_EFFECTS["me2-129"] = TRAINER_EFFECTS["me2-118"]  # Dawn 別絵柄
TRAINER_EFFECTS["me2-87"] = TRAINER_EFFECTS["me2-118"]  # Dawn 別絵柄
TRAINER_EFFECTS["me2-119"] = (SearchDeckForBasicEnergyToHand(count=7, energy_type="Fire"),)  # Firebreather
TRAINER_EFFECTS["me2-89"] = TRAINER_EFFECTS["me2-119"]  # Firebreather 別絵柄
ATTACK_EFFECTS["me2-12"] = {"Steady Firebreathing": (DealDamage(40),)}  # Charmeleon
ATTACK_EFFECTS["me2-15"] = {  # Darumaka
    "Blaze Ball": (DealDamage(10), DamagePerOwnAttachedEnergyCount(per_energy=20, energy_type="Fire")),
}
ATTACK_EFFECTS["me2-16"] = {  # Darmanitan
    "Blaze Ball": (DealDamage(40), DamagePerOwnAttachedEnergyCount(per_energy=40, energy_type="Fire")),
}
ATTACK_EFFECTS["me2-17"] = {  # Reshiram
    "Combustion": (DealDamage(30),),
    "Burning Flare": (DealDamage(240), SelfDamage(60)),
}
ATTACK_EFFECTS["me2-19"] = {  # Charcadet
    "Gather Strength": (SearchDeckForBasicEnergyToHand(count=2),),
    "Chop": (DealDamage(10),),
}
ATTACK_EFFECTS["me2-2"] = {  # Gloom
    "Disperse Drool": (DealDamage(20), DealFixedDamageToAllBenchedPokemonBothSides(20)),
}
ATTACK_EFFECTS["me2-21"] = {"Bubble Drain": (DealDamage(20), HealSelf(20))}  # Seel
ATTACK_EFFECTS["me2-22"] = {  # Dewgong(特性Thick Fatは見送り)
    "Slam": (FlipMultipleCoinsForBonusDamage(base=0, count=2, per_heads=70),),
}
ATTACK_EFFECTS["me2-97"] = ATTACK_EFFECTS["me2-22"]  # Dewgong 別絵柄
ATTACK_EFFECTS["me2-23"] = {  # Swinub
    "Stampede": (DealDamage(10),),
    "Icy Snow": (DealDamage(20),),
}
ATTACK_EFFECTS["me2-24"] = {  # Piloswine
    "Rising Lunge": (DealDamage(30), FlipCoinThen(heads=(DealDamage(30),))),
    "Frost Smash": (DealDamage(70),),
}
ATTACK_EFFECTS["me2-25"] = {  # Mamoswine
    "Wreck": (DealDamageBonusIfStadiumInPlayThenDiscardIt(base=120, bonus=120),),
    "Blizzard Edge": (DealDamage(200), DiscardOwnEnergy(count=2)),
}
ATTACK_EFFECTS["me2-26"] = {  # Suicune
    "Crystal Fall": (
        BonusDamageIfOwnBoardEnergyTypeCountAtLeast(base=30, bonus=90, energy_type="Water", min_count=4),
    ),
}
ATTACK_EFFECTS["me2-27"] = {  # Piplup
    "Call for Support": (SearchDeckMultiCriteria(criteria=("supporter",)),),
    "Tackle": (DealDamage(20),),
}
ATTACK_EFFECTS["me2-98"] = ATTACK_EFFECTS["me2-27"]  # Piplup 別絵柄
ATTACK_EFFECTS["me2-28"] = {  # Prinplup
    "Peck": (DealDamage(20),),
    "Targeted Dive": (DealBonusDamageToChosenOpponentBench(70),),
}
ATTACK_EFFECTS["me2-3"] = {  # Vileplume(Lively Flowerの「このターン回復していたら」判定は見送り)
    "Pollen Bomb": (
        DealDamage(30),
        InflictStatusOnDefender(condition="asleep"),
        InflictStatusOnDefender(condition="poisoned"),
    ),
}
ATTACK_EFFECTS["me2-30"] = {"Play Rough": (DealDamage(20), FlipCoinThen(heads=(DealDamage(20),)))}  # Yamper
ATTACK_EFFECTS["me2-99"] = ATTACK_EFFECTS["me2-30"]  # Yamper 別絵柄
ATTACK_EFFECTS["me2-31"] = {"Electric Run": (DealDamage(70), FlipCoinThen(heads=(DealDamage(70),)))}  # Boltund
ATTACK_EFFECTS["me2-32"] = {  # Pawmi
    "Growl": (DebuffDefenderAttackDamageNextTurn(30),),
    "Tiny Charge": (DealDamage(10),),
}
ATTACK_EFFECTS["me2-33"] = {"Electric Punch": (DealDamage(60),)}  # Pawmo
ATTACK_EFFECTS["me2-34"] = {"Voltaic Fist": (DealDamage(130),)}  # Pawmot(自傷+マヒの「してもよい」ボーナスは見送り)
ATTACK_EFFECTS["me2-35"] = {"Petty Grudge": (DealDamage(20),)}  # Misdreavus
ATTACK_EFFECTS["me2-37"] = {"Tackle": (DealDamage(20),)}  # Snubbull
ATTACK_EFFECTS["me2-38"] = {  # Granbull
    "Bite": (DealDamage(50),),
    "Finishing Blow": (BonusDamageIfDefenderAlreadyDamaged(base=90, bonus=90),),
}
ATTACK_EFFECTS["me2-39"] = {  # Cresselia
    "Swelling Light": (SearchDeckForBasicEnergyAttachToTarget(count=2, energy_type="Psychic", self_only=True),),
    "Aurora Beam": (DealDamage(90),),
}
ATTACK_EFFECTS["me2-40"] = {  # Meloetta
    "Soothing Melody": (HealTarget(120, bench_only=True, target_type="Psychic"),),
    "Magical Shot": (DealDamage(50),),
}
ATTACK_EFFECTS["me2-42"] = {  # Mimikyu
    "Call for Family": (SearchDeckForBasicPokemonToBench(count=1),),
    "Scratch": (DealDamage(20),),
}
ATTACK_EFFECTS["me2-43"] = {"Draining Kiss": (DealDamage(10), HealSelf(10))}  # Milcery
ATTACK_EFFECTS["me2-44"] = {"Sweet Circle": (DamagePerOwnPokemonInPlay(per_pokemon=20),)}  # Alcremie
ATTACK_EFFECTS["me2-46"] = {"Sneaky Placement": (DamageCounterOnChosenOpponentPokemon(count=1),)}  # Bramblin
ATTACK_EFFECTS["me2-47"] = {"Psychic Sphere": (DealDamage(80),)}  # Brambleghast(特性Prison Panicは見送り)

# ---- Iレギュレーション新規カード実装 第4バッチ ----

ATTACK_EFFECTS["me2-48"] = {  # Paldean Tauros
    "Raging Charge": (DamagePerOwnNamedPokemonWithDamageCounters(per_pokemon=40, name_contains="Tauros"),),
    "Double-Edge": (DealDamage(70), SelfDamage(20)),
}
ATTACK_EFFECTS["me2-49"] = {"Poison Jab": (DealDamage(10), InflictStatusOnDefender(condition="poisoned"))}  # Gligar
ATTACK_EFFECTS["me2-5"] = {"Headbutt": (DealDamage(30),)}  # Lotad
ATTACK_EFFECTS["me2-50"] = {  # Gliscor
    "Poison Ring": (
        DealDamage(50),
        InflictStatusOnDefender(condition="poisoned"),
        DisableDefenderRetreatNextTurn(),
    ),
}
ATTACK_EFFECTS["me2-51"] = {  # Trapinch
    "Double Headbutt": (FlipMultipleCoinsForBonusDamage(base=0, count=2, per_heads=10),),
}
ATTACK_EFFECTS["me2-52"] = {"Super Vibration": (DealDamage(60),)}  # Vibrava
ATTACK_EFFECTS["me2-54"] = {"Petty Grudge": (DealDamage(10),)}  # Gastly
ATTACK_EFFECTS["me2-55"] = {"Spooky Shot": (DealDamage(40),)}  # Haunter
ATTACK_EFFECTS["me2-56"] = {  # Mega Gengar ex(特性Shadowy Concealmentはきぜつ時サイド減少という
    # 新規機構が必要なため見送り)
    "Void Gale": (DealDamage(230), MoveEnergyBetweenOwnPokemon()),
}
ATTACK_EFFECTS["me2-57"] = {  # Murkrow
    "Ambush": (DealDamage(10), FlipCoinThen(heads=(DealDamage(20),))),
}
ATTACK_EFFECTS["me2-58"] = {  # Honchkrow
    "Wind of Darkness": (DealDamage(30),),
    "Sniping Feathers": (DiscardOwnEnergy(count=2), DealDamageToChosenOpponentPokemon(120)),
}
ATTACK_EFFECTS["me2-59"] = {  # Sableye
    "Cocky Claw": (
        BonusDamageIfOwnBenchHasSubtypeOfType(base=20, bonus=70, subtype="Stage 2", pokemon_type="Darkness"),
    ),
}
ATTACK_EFFECTS["me2-6"] = {"Mega Drain": (DealDamage(30), HealSelf(30))}  # Lombre
ATTACK_EFFECTS["me2-60"] = {"Reckless Charge": (DealDamage(30), SelfDamage(10))}  # Carvanha
ATTACK_EFFECTS["me2-62"] = {"Pitch-Black Fangs": (DealDamage(120),)}  # Seviper(特性Excited Powerは見送り)
ATTACK_EFFECTS["me2-63"] = {  # Absol
    "Allure": (Draw(2),),
    "Dark Cutter": (DealDamage(60),),
}
ATTACK_EFFECTS["me2-64"] = {  # Sandile
    "Ram": (DealDamage(10),),
    "Rear Kick": (DealDamage(20),),
}
ATTACK_EFFECTS["me2-65"] = {  # Krokorok
    "Bite": (DealDamage(30),),
    "Confront": (DealDamage(60),),
}
ATTACK_EFFECTS["me2-66"] = {  # Krookodile(Vengeful Fangは「相手の直前の番にきぜつした自分のポケモンが
    # いれば」判定という新規状態追跡が必要なため見送り)
    "Hammer In": (DealDamage(160),),
}
ATTACK_EFFECTS["me2-67"] = {  # Toxel
    "Call for Family": (SearchDeckForBasicPokemonToBench(count=2),),
    "Playful Kick": (DealDamage(20),),
}
ATTACK_EFFECTS["me2-69"] = {  # Eternatus
    "Shatter": (DealDamage(50), DiscardStadiumInPlay()),
    "Power Rush": (
        DealDamage(130),
        FlipCoinThen(tails=(LockOwnAttackNextTurn(attack_name="", lock_all_attacks=True),)),
    ),
}
ATTACK_EFFECTS["me2-7"] = {"Lunge Out": (DealDamage(120),)}  # Ludicolo(特性Excited Healは見送り)
ATTACK_EFFECTS["me2-71"] = {  # Bronzor
    "Iron Defense": (FlipCoinThen(heads=(ApplyShieldToSelf(),)),),
    "Rollout": (DealDamage(30),),
}
ATTACK_EFFECTS["me2-72"] = {  # Bronzong
    "Triple Draw": (Draw(3),),
    "Tool Drop": (DamagePerToolAttachedBothSides(per_tool=40),),
}
ATTACK_EFFECTS["me2-74"] = {"Hyper Beam": (DealDamage(70), DiscardOpponentActiveEnergy())}  # Duraludon
ATTACK_EFFECTS["me2-75"] = {  # Archaludon
    "Coated Attack": (DealDamage(120), ApplyScopedDamageImmunityToSelf(scope="basic")),
}
ATTACK_EFFECTS["me2-76"] = {"Ball Roll": (DamagePerHeadsUntilTails(base=0, damage_per_heads=20),)}  # Jigglypuff
ATTACK_EFFECTS["me2-78"] = {"Astonish": (DealDamage(20), RandomOpponentHandCardToDeck())}  # Aipom
ATTACK_EFFECTS["me2-80"] = {"Hook": (DealDamage(40),)}  # Smeargle(Energizing Sketchは複数ベンチへの
    # 自由分配のため見送り)
ATTACK_EFFECTS["me2-81"] = {  # Zigzagoon
    "Surprise Attack": (FlipCoinThen(heads=(DealDamage(30),)),),
}
ATTACK_EFFECTS["me2-82"] = {"Slash": (DealDamage(70),)}  # Linoone(特性Excited Dashは見送り)
ATTACK_EFFECTS["me2-83"] = {  # Buneary
    "Run Around": (SwitchActiveWithBench(),),
    "Kick": (DealDamage(20),),
}
ATTACK_EFFECTS["me2-9"] = {"Flail Around": (FlipMultipleCoinsForBonusDamage(base=0, count=3, per_heads=10),)}  # Nymble
TRAINER_EFFECTS["me2-91"] = (HealOwnActiveIfEnergyCountAtLeast(amount=80, min_energy=3),)  # Jumbo Ice Cream
TRAINER_EFFECTS["me2-94"] = TRAINER_EFFECTS["mbd-15"]  # Wondrous Patch(mbd-15と同一カードの別絵柄)
ATTACK_EFFECTS["me2pt5-100"] = {  # Team Rocket's Diglett
    "Relentless Burrowing": (DiscardOpponentDeckPerHeadsUntilTails(),),
}
ATTACK_EFFECTS["me2pt5-101"] = {"Mud Shot": (DealDamage(50),)}  # Team Rocket's Dugtrio(特性Holesは見送り)
ATTACK_EFFECTS["me2pt5-103"] = {  # Meditite
    "Collect": (Draw(1),),
    "Gentle Slap": (DealDamage(10),),
}
ATTACK_EFFECTS["me2pt5-104"] = {  # Medicham
    "Seventh Kick": (DealDamageIfHandCountExactly(amount=150, count=7),),
}
ATTACK_EFFECTS["me2pt5-107"] = {  # Regirock ex
    "Regi Charge": (AttachEnergyFromDiscardToOwnPokemon(energy_type="Fighting", count=2, self_only=True),),
    "Giant Rock": (BonusDamageIfDefenderHasSubtype(base=140, bonus=140, subtype="Stage 2"),),
}
ATTACK_EFFECTS["me2pt5-109"] = {"Rock Hurl": (DealDamageIgnoringResistanceOnly(20),)}  # Cynthia's Gible
ATTACK_EFFECTS["me2pt5-11"] = {"Bug Bite": (DealDamage(20),)}  # Wurmple
ATTACK_EFFECTS["me2pt5-110"] = {"Dragonslice": (DealDamage(40),)}  # Cynthia's Gabite
ABILITY_EFFECTS["me2pt5-110"] = {  # Cynthia's Gabite
    "Champion's Call": (SearchDeckForPokemonToHand(count=1, name_prefix="Cynthia's"),),
}
ATTACK_EFFECTS["me2pt5-111"] = {  # Cynthia's Garchomp ex
    "Corkscrew Dive": (DealDamage(100), DrawUpTo(6)),
    "Draconic Buster": (DealDamage(260), DiscardOwnEnergy(count=99)),
}
ATTACK_EFFECTS["me2pt5-115"] = {"Reckless Charge": (DealDamage(20), SelfDamage(10))}  # Pancham
ATTACK_EFFECTS["me2pt5-116"] = {  # Mega Hawlucha ex(特性Tenacious Bodyは
    # effects.primitives._COINFLIP_SURVIVE_LETHAL_HIT_ABILITY_IDS経由、常時効果のため登録不要)
    "Somersault Dive": (DealDamageBonusIfStadiumInPlayThenDiscardIt(base=120, bonus=140),),
}
ATTACK_EFFECTS["me2pt5-118"] = {"Mud-Slap": (DealDamage(20),)}  # Rolycoly
ATTACK_EFFECTS["me2pt5-119"] = {  # Carkol
    "Guard Press": (DealDamage(20), ApplyDamageReductionToSelf(20)),
    "Power Gem": (DealDamage(60),),
}
ATTACK_EFFECTS["me2pt5-12"] = {"Tackle": (DealDamage(30),)}  # Silcoon(特性Multiplying Cocoonは見送り)
ATTACK_EFFECTS["me2pt5-120"] = {  # Coalossal(Tar Cannonはトラッシュ枚数条件+自由対象の複合効果のため見送り)
    "Bulky Bump": (DealDamage(220), DiscardOwnEnergy(count=3)),
}
ATTACK_EFFECTS["me2pt5-13"] = {  # Beautifly
    "Stun Spore": (DealDamage(40), FlipCoinThen(heads=(InflictStatusOnDefender(condition="paralyzed"),))),
    "Energy Straw": (DamagePerEnergyCardInOpponentHand(per_energy=80),),
}
ATTACK_EFFECTS["me2pt5-130"] = {"Gnaw": (DealDamage(10),)}  # Galarian Zigzagoon
ATTACK_EFFECTS["me2pt5-131"] = {  # Galarian Linoone
    "Gnaw": (DealDamage(20),),
    "Claw Slash": (DealDamage(50),),
}
ATTACK_EFFECTS["me2pt5-132"] = {  # Galarian Obstagoon
    "Scarring Shout": (DamagePerDefenderDamageCounters(base=0, per_counter=70),),
    "Punk Smash": (DealDamage(160), DiscardOwnEnergy(count=1)),
}
ATTACK_EFFECTS["me2pt5-134"] = {"Knock Off": (DealDamage(20), DiscardRandomFromOpponentHand())}  # Scraggy
ATTACK_EFFECTS["me2pt5-135"] = {  # Mega Scrafty ex(特性Counterattacking Crestはきぜつしても発動する
    # 永続反撃効果のため見送り)
    "Outlaw Leg": (DealDamage(160), DiscardRandomFromOpponentHand(), DiscardTopOfOpponentDeck(1)),
}
ATTACK_EFFECTS["me2pt5-14"] = {"Trading Places": (SwitchActiveWithBench(),)}  # Cascoon
ATTACK_EFFECTS["me2pt5-140"] = {  # Pangoro(Master's Punchはベンチの特定名前ポケモンの被ダメージ判定
    # という複合条件のため見送り)
    "Corkscrew Punch": (DealDamage(40),),
}

ATTACK_EFFECTS["me2pt5-123"] = ATTACK_EFFECTS["me2-54"]  # Gastly 別絵柄
ATTACK_EFFECTS["me2pt5-124"] = ATTACK_EFFECTS["me2-55"]  # Haunter 別絵柄
for _alias_id in ("me2pt5-125", "me2pt5-269", "me2pt5-284"):
    ATTACK_EFFECTS[_alias_id] = ATTACK_EFFECTS["me2-56"]  # Mega Gengar ex 別絵柄
ATTACK_EFFECTS["me2-95"] = ATTACK_EFFECTS["me2-7"]  # Ludicolo 別絵柄
ATTACK_EFFECTS["me2-96"] = ATTACK_EFFECTS["me2-9"]  # Nymble 別絵柄
TRAINER_EFFECTS["me3-117"] = TRAINER_EFFECTS["me2-94"]  # Wondrous Patch 別絵柄
ATTACK_EFFECTS["me2pt5-239"] = ATTACK_EFFECTS["me2pt5-101"]  # Team Rocket's Dugtrio 別絵柄
ATTACK_EFFECTS["me2pt5-241"] = ATTACK_EFFECTS["me2pt5-104"]  # Medicham 別絵柄
for _alias_id in ("sv10-101", "sv10-214"):
    ATTACK_EFFECTS[_alias_id] = ATTACK_EFFECTS["me2pt5-107"]  # Regirock ex 別絵柄
ATTACK_EFFECTS["sv10-102"] = ATTACK_EFFECTS["me2pt5-109"]  # Cynthia's Gible 別絵柄
for _alias_id in ("rsv10pt5-1", "rsv10pt5-87", "sv9-1"):
    ATTACK_EFFECTS[_alias_id] = ATTACK_EFFECTS["me2pt5-11"]  # Wurmple 別絵柄
ATTACK_EFFECTS["sv10-103"] = ATTACK_EFFECTS["me2pt5-110"]  # Cynthia's Gabite 別絵柄
ABILITY_EFFECTS["sv10-103"] = ABILITY_EFFECTS["me2pt5-110"]
for _alias_id in ("sv10-104", "sv10-215", "sv10-232", "sv10-241"):
    ATTACK_EFFECTS[_alias_id] = ATTACK_EFFECTS["me2pt5-111"]  # Cynthia's Garchomp ex 別絵柄
for _alias_id in ("me2pt5-268", "me2pt5-283"):
    ATTACK_EFFECTS[_alias_id] = ATTACK_EFFECTS["me2pt5-116"]  # Mega Hawlucha ex 別絵柄
ATTACK_EFFECTS["me2pt5-219"] = ATTACK_EFFECTS["me2pt5-13"]  # Beautifly 別絵柄
ATTACK_EFFECTS["me2pt5-245"] = ATTACK_EFFECTS["me2pt5-132"]  # Galarian Obstagoon 別絵柄
for _alias_id in ("me2pt5-270", "me2pt5-285"):
    ATTACK_EFFECTS[_alias_id] = ATTACK_EFFECTS["me2pt5-135"]  # Mega Scrafty ex 別絵柄

# ---- Iレギュレーション新規カード実装 第5バッチ ----

ATTACK_EFFECTS["me2pt5-146"] = {"Push Down": (DealDamage(10), ForceOpponentSwitchOpponentChooses())}  # Pawniard
ATTACK_EFFECTS["me2pt5-147"] = {"Rapid Draw": (DealDamage(50), Draw(2))}  # Bisharp
ATTACK_EFFECTS["me2pt5-148"] = {  # Kingambit(特性Supreme Overlordは、パッシブ特性(effects/generated_abilities.py:
    # self_attack_bonus_per_opp_prize_taken)としてワザのダメージに加算される)
    "Double-Edged Slash": (DealDamage(180), SelfDamage(50)),
}
ATTACK_EFFECTS["me2pt5-15"] = {  # Dustox
    "Twilight Poison": (
        DealDamage(100),
        InflictStatusOnDefender(condition="asleep"),
        InflictStatusOnDefender(condition="poisoned"),
    ),
}
ABILITY_EFFECTS["me2pt5-15"] = {  # Dustox
    "Boisterous Wind": (FlipCoinThen(heads=(ReturnChosenOpponentEnergyToHand(count=1),)),),
}
ATTACK_EFFECTS["me2pt5-150"] = {"Headbutt": (DealDamage(30),)}  # Dratini
ATTACK_EFFECTS["me2pt5-151"] = {"Tail Snap": (DealDamage(60),)}  # Dragonair
ABILITY_EFFECTS["me2pt5-151"] = {  # Dragonair
    "Evolutionary Guidance": (SearchDeckMultiCriteria(("evolution_pokemon",)),),
}
ATTACK_EFFECTS["me2pt5-152"] = {  # Mega Dragonite ex
    "Ryuno Glide": (DealDamage(330), DiscardOwnEnergy(count=2)),
}
ABILITY_EFFECTS["me2pt5-152"] = {"Sky Transport": (SwitchActiveWithBench(),)}  # Mega Dragonite ex
ATTACK_EFFECTS["me2pt5-153"] = {  # Rayquaza
    "Breakthrough Assault": (DamageIfBecameActiveThisTurn(base=20, bonus=90),),
    "Dragon Claw": (DealDamage(130),),
}
ATTACK_EFFECTS["me2pt5-154"] = {  # N's Reshiram
    "Powerful Rage": (DamagePerSelfDamageCounters(per_counter=20),),
    "Virtuous Flame": (DealDamage(170),),
}
ATTACK_EFFECTS["me2pt5-156"] = {  # Noibat
    "Knickknack Carrying": (SearchDeckMultiCriteria(("pokemon_tool",)),),
    "Bite": (DealDamage(30),),
}
ATTACK_EFFECTS["me2pt5-157"] = {  # Noivern
    "Agility": (FlipCoinThen(heads=(ApplyShieldToSelf(),)),),
    "Enhanced Blade": (BonusDamageIfSelfHasToolAttached(base=70, bonus=70),),
}
ATTACK_EFFECTS["me2pt5-161"] = {  # Team Rocket's Meowth
    "Paw-cket Pilfer": (RandomOpponentHandCardToDeck(),),
    "Fury Swipes": (FlipMultipleCoinsForBonusDamage(base=0, count=3, per_heads=20),),
}
ATTACK_EFFECTS["me2pt5-162"] = {  # Team Rocket's Kangaskhan ex
    "Comet Punch": (FlipMultipleCoinsForBonusDamage(base=0, count=4, per_heads=30),),
    "Wicked Impact": (BonusDamageIfTeamRocketSupporterPlayedThisTurn(base=120, bonus=100),),
}
ATTACK_EFFECTS["me2pt5-177"] = {  # Hop's Cramorant
    "Fickle Spitting": (DealDamageIfOpponentPrizesInRange(amount=120, low=3, high=4),),
}
TRAINER_EFFECTS["me2pt5-183"] = TRAINER_EFFECTS["me1-114"]  # Boss's Orders(me1-114と同一カードの別絵柄)
TRAINER_EFFECTS["me2pt5-185"] = (  # Canari
    DiscardCardsFromHand(1),
    SearchDeckForPokemonToHand(count=4, pokemon_type="Lightning"),
)
ATTACK_EFFECTS["me2pt5-19"] = {  # Team Rocket's Spidops
    "Rocket Rush": (DamagePerOwnTeamRocketsPokemonInPlay(per_pokemon=30),),
}
ABILITY_EFFECTS["me2pt5-19"] = {  # Team Rocket's Spidops
    "Charging Up": (AttachEnergyFromDiscardToOwnPokemon(energy_type=None, count=1, self_only=True),),
}
TRAINER_EFFECTS["me2pt5-190"] = (DiscardCardsFromHand(1), DrawUpTo(6))  # Iris's Fighting Spirit
TRAINER_EFFECTS["me2pt5-195"] = (  # N's PP Up
    AttachEnergyFromDiscardToOwnPokemon(energy_type=None, count=1, bench_only=True, target_name_prefix="N's"),
)
TRAINER_EFFECTS["me2pt5-201"] = TRAINER_EFFECTS["sv10-170"]  # Team Rocket's Archer(sv10-170と同一カードの別絵柄)
TRAINER_EFFECTS["me2pt5-202"] = TRAINER_EFFECTS["sv10-171"]  # Team Rocket's Ariana(sv10-171と同一カードの別絵柄)
STADIUM_ABILITY_EFFECTS["me2pt5-203"] = STADIUM_ABILITY_EFFECTS["sv10-173"]  # Team Rocket's Factory 別絵柄
TRAINER_EFFECTS["me2pt5-204"] = TRAINER_EFFECTS["sv10-174"]  # Team Rocket's Giovanni(sv10-174と同一カードの別絵柄)
TRAINER_EFFECTS["me2pt5-205"] = (  # Team Rocket's Great Ball
    FlipCoinThen(
        heads=(SearchDeckForPokemonToHand(count=1, name_prefix="Team Rocket's", exclude_basic=True),),
        tails=(SearchDeckForPokemonToHand(count=1, name_prefix="Team Rocket's", only_basic=True),),
    ),
)
TRAINER_EFFECTS["me2pt5-207"] = TRAINER_EFFECTS["sv10-176"]  # Team Rocket's Petrel(sv10-176と同一カードの別絵柄)
TRAINER_EFFECTS["me2pt5-208"] = TRAINER_EFFECTS["sv10-177"]  # Team Rocket's Proton(sv10-177と同一カードの別絵柄、先攻1ターン目特例はlegal_actionsで対応済み)
TRAINER_EFFECTS["me2pt5-209"] = TRAINER_EFFECTS["sv10-178"]  # Team Rocket's Transceiver(sv10-178と同一カードの別絵柄)
TRAINER_EFFECTS["me2pt5-212"] = TRAINER_EFFECTS["bw6-116"]  # Tool Scrapper(bw6-116と同一カードの別絵柄)
TRAINER_EFFECTS["me2pt5-213"] = TRAINER_EFFECTS["me1-131"]  # Ultra Ball(me1-131と同一カードの別絵柄)
ATTACK_EFFECTS["me2pt5-222"] = {  # Ethan's Magcargo(特性Melt Awayはにげるコスト動的変更という
    # 新規機構が必要なため見送り)
    "Lava Burst": (DiscardOwnEnergyForScalingDamage(max_count=5, damage_per=70, energy_type="Fire"),),
}
ATTACK_EFFECTS["me2pt5-223"] = {"Combustion": (DealDamage(20),)}  # Numel(特性Incandescent Bodyは見送り)
ATTACK_EFFECTS["me2pt5-226"] = {"Ram": (DealDamage(20),)}  # Psyduck(特性Dampは見送り)
ATTACK_EFFECTS["me2pt5-227"] = {"Chilly": (DealDamage(10),)}  # Snorunt
ATTACK_EFFECTS["me2pt5-229"] = {  # Heliolisk(特性Frilled Generatorは特定カード名依存トリガーのため見送り)
    "Powerful Bolt": (DamagePerHeadsForEachAttachedEnergy(damage_per_heads=70),),
}
ATTACK_EFFECTS["me2pt5-231"] = {  # Iono's Wattrel
    "Quick Attack": (DealDamage(10), FlipCoinThen(heads=(DealDamage(20),))),
}
ATTACK_EFFECTS["me2pt5-233"] = {"Ascension": (InstantEvolveSelfFromDeck(),)}  # Misdreavus
ATTACK_EFFECTS["me2pt5-234"] = {  # Banette(Cursed Wordsは相手自身による手札選択という新規UIが
    # 必要なため見送り)
    "Spooky Shot": (DealDamage(70),),
}
ATTACK_EFFECTS["me2pt5-237"] = {  # Hop's Trevenant(Horrifying Revengeは「Hop's」ポケモンのきぜつ
    # 追跡という新規状態が必要なため見送り)
    "Corner": (DealDamage(90), DisableDefenderRetreatNextTurn()),
}
ATTACK_EFFECTS["me2pt5-238"] = ATTACK_EFFECTS["me2pt5-97"]  # Team Rocket's Mimikyu(me2pt5-97と同一カードの別絵柄)
ATTACK_EFFECTS["me2pt5-25"] = {  # Entei
    "Flare Fall": (
        BonusDamageIfOwnBoardEnergyTypeCountAtLeast(base=30, bonus=90, energy_type="Fire", min_count=4),
    ),
}
ATTACK_EFFECTS["me2pt5-26"] = {"Shining Feathers": (DealDamage(160), HealAllOwnPokemon(amount=50))}  # Ethan's Ho-Oh ex(特性Golden Flameは手札から複数エネルギーを自由分配という新規機構が必要なため見送り)
ATTACK_EFFECTS["me2pt5-265"] = {  # Mega Froslass ex
    "Resentful Refrain": (DamagePerOpponentHandCardCount(base=0, per_card=50),),
    "Absolute Snow": (DealDamage(150), InflictStatusOnDefender(condition="asleep")),
}
ATTACK_EFFECTS["me2pt5-266"] = {  # Mega Eelektross ex(Split Bombは相手の場から2匹選ぶ新規UIが必要なため見送り)
    "Disaster Shock": (DealDamage(190),),
}
AFTER_ATTACK_TRIGGER_EFFECTS[("me2pt5-266", "Disaster Shock")] = (
    DiscardOwnEnergy(count=2, energy_type="Lightning"),
    InflictStatusOnDefender(condition="paralyzed"),
)
ATTACK_EFFECTS["me2pt5-267"] = {  # Mega Diancie ex(特性Diamond Coatはprimitives._INNATE_DAMAGE_REDUCTION_ABILITY_IDS経由)
    "Garland Ray": (DiscardOwnEnergyForScalingDamage(max_count=2, damage_per=120),),
}
ATTACK_EFFECTS["me2pt5-279"] = {  # Iono's Bellibolt ex(特性Electric Streamerは手札から複数エネルギーを
    # 自由分配という新規機構が必要なため見送り)
    "Thunderous Bolt": (DealDamage(230), LockOwnAttackNextTurn(attack_name="Thunderous Bolt")),
}
ATTACK_EFFECTS["me2pt5-28"] = {  # Camerupt
    "Roasting Burn": (DealDamageIfDefenderBurned(110),),
    "Power Stomp": (DealDamage(170), DiscardOwnEnergy(count=2)),
}
ATTACK_EFFECTS["me2pt5-280"] = {  # Lillie's Clefairy ex(特性Fairy Zoneはprimitives.LILLIE_CLEFAIRY_EX_REPRINT_ID経由)
    "Full Moon Rondo": (BonusDamagePerBenchCountBothSides(base=20, per_pokemon=20),),
}
ATTACK_EFFECTS["me2pt5-281"] = ATTACK_EFFECTS["me2pt5-79"]  # Team Rocket's Mewtwo ex(me2pt5-79と同一カードの
    # 別絵柄。特性Power Saverの攻撃ゲートはlegal_actions._MIN_NAMED_PREFIX_POKEMON_IN_PLAY_TO_ATTACKで対応済み)
ABILITY_EFFECTS["me2pt5-286"] = {"Trade": (DiscardCardsFromHand(1), Draw(2))}  # N's Zoroark ex(Night Jokerは
    # 自分のベンチのNのポケモンからワザをコピーという新規機構が必要なため見送り)
ATTACK_EFFECTS["me2pt5-289"] = {"Metal Stomp": (DealDamage(200),)}  # Steven's Metagross ex(特性X-Bootは
    # 2種類の基本エネルギーを自由分配という新規機構が必要なため見送り)

ATTACK_EFFECTS["me2pt5-220"] = ATTACK_EFFECTS["me2pt5-15"]  # Dustox 別絵柄
ABILITY_EFFECTS["me2pt5-220"] = ABILITY_EFFECTS["me2pt5-15"]
for _alias_id in ("me2pt5-271", "me2pt5-290", "me2pt5-295"):
    ATTACK_EFFECTS[_alias_id] = ATTACK_EFFECTS["me2pt5-152"]  # Mega Dragonite ex 別絵柄
    ABILITY_EFFECTS[_alias_id] = ABILITY_EFFECTS["me2pt5-152"]
ATTACK_EFFECTS["sv9-167"] = ATTACK_EFFECTS["me2pt5-154"]  # N's Reshiram 別絵柄
for _alias_id in ("sv10-149", "sv10-203"):
    ATTACK_EFFECTS[_alias_id] = ATTACK_EFFECTS["me2pt5-161"]  # Team Rocket's Meowth 別絵柄
ATTACK_EFFECTS["sv9-138"] = ATTACK_EFFECTS["me2pt5-177"]  # Hop's Cramorant 別絵柄
TRAINER_EFFECTS["me2pt5-256"] = TRAINER_EFFECTS["me2pt5-183"]  # Boss's Orders 別絵柄
for _alias_id in ("me2pt5-257", "me2pt5-291"):
    TRAINER_EFFECTS[_alias_id] = TRAINER_EFFECTS["me2pt5-185"]  # Canari 別絵柄
for _alias_id in ("sv10-187", "sv10-20"):
    ATTACK_EFFECTS[_alias_id] = ATTACK_EFFECTS["me2pt5-19"]  # Team Rocket's Spidops 別絵柄
    ABILITY_EFFECTS[_alias_id] = ABILITY_EFFECTS["me2pt5-19"]
for _alias_id in ("me2pt5-292", "sv9-149", "sv9-180"):
    TRAINER_EFFECTS[_alias_id] = TRAINER_EFFECTS["me2pt5-190"]  # Iris's Fighting Spirit 別絵柄
TRAINER_EFFECTS["me2pt5-262"] = TRAINER_EFFECTS["me2pt5-195"]  # N's PP Up 別絵柄
TRAINER_EFFECTS["sv10-223"] = TRAINER_EFFECTS["me2pt5-201"]  # Team Rocket's Archer 別絵柄(legal_actionsのきぜつゲートも対応済み)
for _alias_id in ("sv10-224", "sv10-237"):
    TRAINER_EFFECTS[_alias_id] = TRAINER_EFFECTS["me2pt5-202"]  # Team Rocket's Ariana 別絵柄
for _alias_id in ("sv10-225", "sv10-238"):
    TRAINER_EFFECTS[_alias_id] = TRAINER_EFFECTS["me2pt5-204"]  # Team Rocket's Giovanni 別絵柄
TRAINER_EFFECTS["sv10-175"] = TRAINER_EFFECTS["me2pt5-205"]  # Team Rocket's Great Ball 別絵柄
TRAINER_EFFECTS["sv10-226"] = TRAINER_EFFECTS["me2pt5-207"]  # Team Rocket's Petrel 別絵柄
TRAINER_EFFECTS["sv10-227"] = TRAINER_EFFECTS["me2pt5-208"]  # Team Rocket's Proton 別絵柄(先攻1ターン目特例も対応済み)
TRAINER_EFFECTS["me2pt5-263"] = TRAINER_EFFECTS["me2pt5-209"]  # Team Rocket's Transceiver 別絵柄
TRAINER_EFFECTS["rsv10pt5-85"] = TRAINER_EFFECTS["me2pt5-212"]  # Tool Scrapper 別絵柄
TRAINER_EFFECTS["me2pt5-264"] = TRAINER_EFFECTS["me2pt5-213"]  # Ultra Ball 別絵柄
ATTACK_EFFECTS["me2pt5-24"] = ATTACK_EFFECTS["me2pt5-222"]  # Ethan's Magcargo 別絵柄
ATTACK_EFFECTS["sv10-36"] = ATTACK_EFFECTS["me2pt5-222"]  # Ethan's Magcargo 別絵柄
ATTACK_EFFECTS["me2pt5-27"] = ATTACK_EFFECTS["me2pt5-223"]  # Numel 別絵柄
ATTACK_EFFECTS["me2pt5-64"] = ATTACK_EFFECTS["me2pt5-229"]  # Heliolisk 別絵柄
ATTACK_EFFECTS["me2pt5-71"] = ATTACK_EFFECTS["me2pt5-231"]  # Iono's Wattrel 別絵柄
ATTACK_EFFECTS["sv9-54"] = ATTACK_EFFECTS["me2pt5-231"]  # Iono's Wattrel 別絵柄
ATTACK_EFFECTS["me2pt5-85"] = ATTACK_EFFECTS["me2pt5-233"]  # Misdreavus 別絵柄
ATTACK_EFFECTS["me2pt5-91"] = ATTACK_EFFECTS["me2pt5-234"]  # Banette 別絵柄
ATTACK_EFFECTS["sv9-60"] = ATTACK_EFFECTS["me2pt5-234"]  # Banette 別絵柄
ATTACK_EFFECTS["me2pt5-96"] = ATTACK_EFFECTS["me2pt5-237"]  # Hop's Trevenant 別絵柄
ATTACK_EFFECTS["sv10-87"] = ATTACK_EFFECTS["me2pt5-238"]  # Team Rocket's Mimikyu 別絵柄
for _alias_id in ("sv10-209", "sv10-230", "sv10-239", "sv10-39"):
    ATTACK_EFFECTS[_alias_id] = ATTACK_EFFECTS["me2pt5-26"]  # Ethan's Ho-Oh ex 別絵柄
ATTACK_EFFECTS["me2pt5-275"] = ATTACK_EFFECTS["me2pt5-265"]  # Mega Froslass ex 別絵柄
for _alias_id in ("me2pt5-278", "me2pt5-61"):
    ATTACK_EFFECTS[_alias_id] = ATTACK_EFFECTS["me2pt5-266"]  # Mega Eelektross ex 別絵柄
    AFTER_ATTACK_TRIGGER_EFFECTS[(_alias_id, "Disaster Shock")] = AFTER_ATTACK_TRIGGER_EFFECTS[("me2pt5-266", "Disaster Shock")]
ATTACK_EFFECTS["me2pt5-282"] = ATTACK_EFFECTS["me2pt5-267"]  # Mega Diancie ex 別絵柄(常時ダメージ軽減はprimitives._INNATE_DAMAGE_REDUCTION_ABILITY_IDS経由)
for _alias_id in ("me2pt5-70", "sv9-172", "sv9-183", "sv9-188", "sv9-53", "svp-194"):
    ATTACK_EFFECTS[_alias_id] = ATTACK_EFFECTS["me2pt5-279"]  # Iono's Bellibolt ex 別絵柄
for _alias_id in ("me2pt5-76", "sv9-173", "sv9-184", "svp-195"):
    ATTACK_EFFECTS[_alias_id] = ATTACK_EFFECTS["me2pt5-280"]  # Lillie's Clefairy ex 別絵柄(特性Fairy Zoneはprimitives.LILLIE_CLEFAIRY_EX_REPRINT_IDS経由で対応済み)
for _alias_id in ("sv10-213", "sv10-231", "sv10-240", "sv10-81"):
    ATTACK_EFFECTS[_alias_id] = ATTACK_EFFECTS["me2pt5-281"]  # Team Rocket's Mewtwo ex 別絵柄(Power Saverゲートも対応済み)
for _alias_id in ("sv9-175", "sv9-185", "sv9-189"):
    ABILITY_EFFECTS[_alias_id] = ABILITY_EFFECTS["me2pt5-286"]  # N's Zoroark ex 別絵柄
ATTACK_EFFECTS["sv10-145"] = ATTACK_EFFECTS["me2pt5-289"]  # Steven's Metagross ex 別絵柄

# ---- Iレギュレーション新規カード実装 第6バッチ ----

ATTACK_EFFECTS["me2pt5-32"] = {  # N's Darumaka
    "Rolling Tackle": (DealDamage(20),),
    "Flare": (DealDamage(50),),
}
ATTACK_EFFECTS["me2pt5-33"] = {  # N's Darmanitan
    "Back Draft": (DamagePerOpponentDiscardBasicEnergyCount(per_card=30),),
    "Flamebody Cannon": (
        DealDamage(90),
        DiscardOwnEnergy(count=99),
        DealBonusDamageToChosenOpponentBench(90),
    ),
}
ATTACK_EFFECTS["me2pt5-40"] = {  # Golduck(特性Dampは見送り)
    "Hydro Pump": (DealDamage(60), DamagePerOwnAttachedEnergyCount(per_energy=20, energy_type="Water")),
}
ATTACK_EFFECTS["me2pt5-49"] = {  # N's Vanillite
    "Call for Family": (SearchDeckForBasicPokemonToBench(count=2),),
    "Icy Snow": (DealDamage(20),),
}
ATTACK_EFFECTS["me2pt5-50"] = {  # N's Vanillish
    "Flop": (DealDamage(20),),
    "Sheer Cold": (DealDamage(60), DisableDefenderAttackNextTurn()),
}
ATTACK_EFFECTS["me2pt5-51"] = {  # N's Vanilluxe
    "Snow Coating": (DoubleAllOpponentDamageCounters(),),
    "Blizzard": (DealDamage(120), DealFixedDamageToAllOpponentBenchedPokemon(10)),
}
ATTACK_EFFECTS["me2pt5-52"] = {"Icicle": (DealDamage(20),)}  # Snom
ATTACK_EFFECTS["me2pt5-53"] = {  # Frosmoth
    "Cold Cyclone": (DealDamage(90), MoveEnergyBetweenOwnPokemon(energy_type="Water")),
}
ABILITY_EFFECTS["me2pt5-53"] = {"Alluring Wings": (EachPlayerDraws(count=1),)}  # Frosmoth
ATTACK_EFFECTS["me2pt5-54"] = {  # Glastrier
    "Ice Shot": (DealDamage(20), DealBonusDamageToChosenOpponentBench(20)),
    "Frosty Typhoon": (DealDamage(130), LockOwnAttackNextTurn(attack_name="Frosty Typhoon")),
}
ATTACK_EFFECTS["me2pt5-59"] = {"Hold Still": (HealSelf(10),)}  # Tynamo
ATTACK_EFFECTS["me2pt5-60"] = {"Electric Ball": (DealDamage(50),)}  # Eelektrik
ABILITY_EFFECTS["me2pt5-60"] = {  # Eelektrik
    "Dynamotor": (AttachEnergyFromDiscardToOwnPokemon(energy_type="Lightning", count=1, bench_only=True),),
}
ATTACK_EFFECTS["me2pt5-62"] = {  # Stunfisk(「次の自分の番、被ダメージ+100」の遅延バフは見送り、
    # ダメージ+にげ封じ部分のみ実装)
    "Pouncing Trap": (DealDamage(30), DisableDefenderRetreatNextTurn()),
}
ATTACK_EFFECTS["me2pt5-63"] = {"Zap Kick": (DealDamage(30),)}  # Helioptile
ATTACK_EFFECTS["me2pt5-67"] = {  # Tapu Koko(Fast Flightは先攻1ターン目ワザ使用という新規機構が
    # 必要なため見送り)
    "Thunder Blast": (DealDamage(130), DiscardOwnEnergy(count=2)),
}
ATTACK_EFFECTS["me2pt5-68"] = {"Spiky Thunder": (DealDamage(120), Draw(2))}  # Hop's Pincurchin ex(特性
    # Counterattack Quillsはきぜつしても発動する永続反撃効果のため見送り)
ATTACK_EFFECTS["me2pt5-69"] = {"Tiny Charge": (DealDamage(30),)}  # Iono's Tadbulb
ATTACK_EFFECTS["me2pt5-72"] = {"Mach Bolt": (DealDamage(70),)}  # Iono's Kilowattrel
ABILITY_EFFECTS["me2pt5-72"] = {  # Iono's Kilowattrel
    "Flashing Draw": (DiscardOwnEnergy(count=1, energy_type="Lightning"), DrawUpTo(6)),
}
ATTACK_EFFECTS["me2pt5-77"] = {  # Team Rocket's Exeggcute
    "Focused Wish": (DealDamage(10), FlipCoinThen(heads=(DealDamage(20),))),
}
ATTACK_EFFECTS["me2pt5-78"] = {  # Team Rocket's Exeggutor(Tri Kinesisはコイン3枚オモテで即きぜつという
    # 新規機構が必要なため見送り)
    "Double-Edge": (DealDamage(150), SelfDamage(30)),
}
ATTACK_EFFECTS["me2pt5-86"] = {  # Mismagius
    "Assassin's Magic": (
        DealDamage(60),
        DamageCounterOnChosenOpponentBenchIfActiveHasSpecialCondition(count=6),
    ),
}
ATTACK_EFFECTS["me2pt5-87"] = {  # Ralts
    "Collect": (Draw(1),),
    "Headbutt": (DealDamage(10),),
}
ATTACK_EFFECTS["me2pt5-88"] = {  # Kirlia
    "Call Sign": (SearchDeckForPokemonToHand(count=3),),
    "Psyshot": (DealDamage(30),),
}
ATTACK_EFFECTS["me2pt5-90"] = {"Spooky Shot": (DealDamage(20),)}  # Shuppet
ATTACK_EFFECTS["me2pt5-92"] = {  # Rotom
    "Roto Call": (SearchDeckForNamedPokemonToBench(name="Rotom", count=99),),
    "Gadget Show": (DamagePerOwnToolAttachedCount(per_tool=30),),
}
ATTACK_EFFECTS["me2pt5-95"] = {  # Hop's Phantump
    "Splashing Dodge": (DealDamage(10), FlipCoinThen(heads=(ApplyShieldToSelf(),))),
}
ATTACK_EFFECTS["me2pt5-98"] = {  # Spectrier
    "Spooky Shot": (DealDamage(30),),
    "Phantasmal Barrage": (DiscardOwnEnergy(count=99), DamageCounterOnChosenOpponentPokemon(count=12)),
}
TRAINER_EFFECTS["me3-108"] = (ShuffleFromDiscardIntoDeck(count=5, only="energy"),)  # Energy Recycler
TRAINER_EFFECTS["me3-115"] = (ShuffleFromDiscardIntoDeck(count=5, only="pokemon"),)  # Sacred Ash
ATTACK_EFFECTS["me3-22"] = {  # Lapras ex
    "Hydro Turn": (
        DamagePerOwnAttachedEnergyCount(per_energy=30, energy_type="Water"),
        SwitchActiveWithBench(),
    ),
    "Surf": (DealDamage(140),),
}
TRAINER_EFFECTS["me3-74"] = (DiscardTopOfOwnDeck(count=2),)  # Hole-Digging Shovel
TRAINER_EFFECTS["me4-108"] = (SearchDiscardForBasicEnergyToHand(2),)  # Energy Retrieval
TRAINER_EFFECTS["me4-109"] = TRAINER_EFFECTS["me2-91"]  # Jumbo Ice Cream(me2-91と同一カードの別絵柄)
TRAINER_EFFECTS["me4-115"] = TRAINER_EFFECTS["me2pt5-212"]  # Tool Scrapper(me2pt5-212と同一カードの別絵柄)
ATTACK_EFFECTS["me4-55"] = {  # Krookodile ex
    "Corner": (DealDamage(80), DisableDefenderRetreatNextTurn()),
    "Strong Bite": (BonusDamageIfSelfHasToolAttached(base=140, bonus=140),),
}
TRAINER_EFFECTS["me5-107"] = TRAINER_EFFECTS["sv1-173"]  # Energy Switch(sv1-173と同一カードの別絵柄)
ATTACK_EFFECTS["rsv10pt5-10"] = {  # Virizion
    "Giga Drain": (DealDamage(30), HealSelfEqualToDamageDealt()),
    "Emerald Blade": (DealDamage(130), LockOwnAttackNextTurn(attack_name="Emerald Blade")),
}
ATTACK_EFFECTS["rsv10pt5-100"] = {"Gentle Slap": (DealDamage(70),)}  # Simisear
ATTACK_EFFECTS["rsv10pt5-102"] = {  # Lampent
    "Fire Blast": (DealDamage(50), DiscardOwnEnergy(count=1)),
}
ATTACK_EFFECTS["rsv10pt5-103"] = {  # Chandelure
    "Incendiary Pillar": (
        BonusDamageIfOwnDiscardEnergyCountAtLeast(base=50, bonus=100, energy_type="Fire", min_count=10),
    ),
    "Burn It All Up": (DealDamage(180), DiscardOwnEnergy(count=99)),
}
ATTACK_EFFECTS["rsv10pt5-104"] = {  # Heatmor(Licking Catchはポケモン/エネルギー混合3枚までの
    # 複合検索のため見送り)
    "Fire Claws": (DealDamage(60),),
}
ATTACK_EFFECTS["rsv10pt5-105"] = {  # Oshawott
    "Tackle": (DealDamage(10),),
    "Water Gun": (DealDamage(30),),
}
ATTACK_EFFECTS["rsv10pt5-106"] = {  # Dewott
    "Energized Shell": (DamagePerOwnAttachedEnergyCount(per_energy=30),),
}
ATTACK_EFFECTS["rsv10pt5-107"] = {  # Samurott
    "Energized Slash": (DealDamage(30), DamagePerOwnAttachedEnergyCount(per_energy=50)),
}
ABILITY_EFFECTS["rsv10pt5-107"] = {  # Samurott
    "Torrential Whirlpool": (SwitchActiveWithBench(), ForceOpponentSwitchOpponentChooses()),
}
ATTACK_EFFECTS["rsv10pt5-108"] = {  # Basculin
    "Bite": (DealDamage(10),),
    "Bared Fangs": (DealDamageIfDefenderAlreadyDamaged(50),),
}
ATTACK_EFFECTS["rsv10pt5-109"] = {  # Ducklett
    "Firefighting": (DiscardOpponentActiveEnergyOfType(energy_type="Fire"),),
    "Wing Attack": (DealDamage(20),),
}
ATTACK_EFFECTS["rsv10pt5-11"] = {  # Tepig
    "Tackle": (DealDamage(10),),
    "Rollout": (DealDamage(30),),
}
ATTACK_EFFECTS["rsv10pt5-110"] = {  # Swanna
    "Flap": (DealDamage(30),),
    "Air Slash": (DealDamage(120), DiscardOwnEnergy(count=1)),
}
ATTACK_EFFECTS["rsv10pt5-111"] = {  # Vanillite
    "Beat": (DealDamage(10),),
    "Ice Edge": (DealDamage(20), FlipCoinThen(heads=(DealDamage(20),))),
}
ATTACK_EFFECTS["rsv10pt5-112"] = {  # Vanillish
    "Ram": (DealDamage(30),),
    "Ice Beam": (DealDamage(50), FlipCoinThen(heads=(InflictStatusOnDefender(condition="paralyzed"),))),
}
ATTACK_EFFECTS["rsv10pt5-113"] = {  # Vanilluxe
    "Ram": (DealDamage(60),),
    "Double Freeze": (
        FlipMultipleCoinsForBonusDamageThenStatusIfAnyHeads(count=2, per_heads=90, condition="paralyzed"),
    ),
}
ATTACK_EFFECTS["rsv10pt5-114"] = {  # Blitzle
    "Smash Kick": (DealDamage(10),),
    "Zap Kick": (DealDamage(30),),
}
ATTACK_EFFECTS["rsv10pt5-115"] = {  # Zebstrika
    "Smash Kick": (DealDamage(30),),
    "Electrobullet": (DealDamage(100), DealBonusDamageToChosenOpponentBench(30)),
}
ATTACK_EFFECTS["rsv10pt5-116"] = {  # Joltik
    "Surprise Attack": (FlipCoinThen(heads=(DealDamage(30),)),),
}
ATTACK_EFFECTS["rsv10pt5-117"] = {  # Galvantula
    "Discharge": (DiscardOwnEnergyForScalingDamage(max_count=99, damage_per=50, energy_type="Lightning"),),
}
ATTACK_EFFECTS["rsv10pt5-118"] = {  # Stunfisk
    "Muddy Bolt": (BonusDamageIfSelfHasEnergyType(base=20, bonus=20, energy_type="Fighting"),),
    "Flop": (DealDamage(50),),
}

ATTACK_EFFECTS["sv9-26"] = ATTACK_EFFECTS["me2pt5-32"]  # N's Darumaka 別絵柄
for _alias_id in ("sv9-27", "svp-181"):
    ATTACK_EFFECTS[_alias_id] = ATTACK_EFFECTS["me2pt5-33"]  # N's Darmanitan 別絵柄
for _alias_id in ("zsv10pt5-113", "zsv10pt5-30"):
    ATTACK_EFFECTS[_alias_id] = ATTACK_EFFECTS["me2pt5-59"]  # Tynamo 別絵柄
for _alias_id in ("zsv10pt5-114", "zsv10pt5-31"):
    ATTACK_EFFECTS[_alias_id] = ATTACK_EFFECTS["me2pt5-60"]  # Eelektrik 別絵柄
    ABILITY_EFFECTS[_alias_id] = ABILITY_EFFECTS["me2pt5-60"]
ATTACK_EFFECTS["sv9-52"] = ATTACK_EFFECTS["me2pt5-69"]  # Iono's Tadbulb 別絵柄
for _alias_id in ("sv9-163", "sv9-55", "svp-182"):
    ATTACK_EFFECTS[_alias_id] = ATTACK_EFFECTS["me2pt5-72"]  # Iono's Kilowattrel 別絵柄
    ABILITY_EFFECTS[_alias_id] = ABILITY_EFFECTS["me2pt5-72"]
ATTACK_EFFECTS["sv9-59"] = ATTACK_EFFECTS["me2pt5-90"]  # Shuppet 別絵柄
TRAINER_EFFECTS["sv10-164"] = TRAINER_EFFECTS["me3-108"]  # Energy Recycler 別絵柄
TRAINER_EFFECTS["sv10-168"] = TRAINER_EFFECTS["me3-115"]  # Sacred Ash 別絵柄
ATTACK_EFFECTS["rsv10pt5-95"] = ATTACK_EFFECTS["rsv10pt5-10"]  # Virizion 別絵柄
for _alias_id in ("rsv10pt5-15", "zsv10pt5-102", "zsv10pt5-18", "zsv10pt5-5", "zsv10pt5-90"):
    ATTACK_EFFECTS[_alias_id] = ATTACK_EFFECTS["rsv10pt5-100"]  # Simisear 別絵柄
ATTACK_EFFECTS["rsv10pt5-17"] = ATTACK_EFFECTS["rsv10pt5-102"]  # Lampent 別絵柄
ATTACK_EFFECTS["rsv10pt5-18"] = ATTACK_EFFECTS["rsv10pt5-103"]  # Chandelure 別絵柄
ATTACK_EFFECTS["rsv10pt5-19"] = ATTACK_EFFECTS["rsv10pt5-104"]  # Heatmor 別絵柄
ATTACK_EFFECTS["rsv10pt5-21"] = ATTACK_EFFECTS["rsv10pt5-105"]  # Oshawott 別絵柄
ATTACK_EFFECTS["rsv10pt5-22"] = ATTACK_EFFECTS["rsv10pt5-106"]  # Dewott 別絵柄
ATTACK_EFFECTS["rsv10pt5-23"] = ATTACK_EFFECTS["rsv10pt5-107"]  # Samurott 別絵柄
ABILITY_EFFECTS["rsv10pt5-23"] = ABILITY_EFFECTS["rsv10pt5-107"]
ATTACK_EFFECTS["rsv10pt5-24"] = ATTACK_EFFECTS["rsv10pt5-108"]  # Basculin 別絵柄
ATTACK_EFFECTS["rsv10pt5-25"] = ATTACK_EFFECTS["rsv10pt5-109"]  # Ducklett 別絵柄
ATTACK_EFFECTS["rsv10pt5-96"] = ATTACK_EFFECTS["rsv10pt5-11"]  # Tepig 別絵柄
ATTACK_EFFECTS["rsv10pt5-26"] = ATTACK_EFFECTS["rsv10pt5-110"]  # Swanna 別絵柄
ATTACK_EFFECTS["rsv10pt5-27"] = ATTACK_EFFECTS["rsv10pt5-111"]  # Vanillite 別絵柄
ATTACK_EFFECTS["rsv10pt5-28"] = ATTACK_EFFECTS["rsv10pt5-112"]  # Vanillish 別絵柄
ATTACK_EFFECTS["rsv10pt5-29"] = ATTACK_EFFECTS["rsv10pt5-113"]  # Vanilluxe 別絵柄
ATTACK_EFFECTS["rsv10pt5-31"] = ATTACK_EFFECTS["rsv10pt5-114"]  # Blitzle 別絵柄
ATTACK_EFFECTS["rsv10pt5-32"] = ATTACK_EFFECTS["rsv10pt5-115"]  # Zebstrika 別絵柄
ATTACK_EFFECTS["rsv10pt5-33"] = ATTACK_EFFECTS["rsv10pt5-116"]  # Joltik 別絵柄
ATTACK_EFFECTS["rsv10pt5-34"] = ATTACK_EFFECTS["rsv10pt5-117"]  # Galvantula 別絵柄
ATTACK_EFFECTS["rsv10pt5-35"] = ATTACK_EFFECTS["rsv10pt5-118"]  # Stunfisk 別絵柄

# ---- Iレギュレーション新規カード実装 第7バッチ ----

ATTACK_EFFECTS["rsv10pt5-119"] = {"Heart Stamp": (DealDamage(10),)}  # Woobat
ATTACK_EFFECTS["rsv10pt5-12"] = {  # Pignite
    "Combustion": (DealDamage(30),),
    "Heat Crash": (DealDamage(80),),
}
ATTACK_EFFECTS["rsv10pt5-120"] = {  # Swoobat
    "Happy Return": (ReturnOwnBenchedPokemonAndAttachedToHand(),),
    "Gust": (DealDamage(50),),
}
ATTACK_EFFECTS["rsv10pt5-121"] = {  # Sigilyph
    "Reflect": (ApplyDamageReductionToSelf(40),),
    "Telekinesis": (DealDamageIgnoringWeaknessResistance(70),),
}
ATTACK_EFFECTS["rsv10pt5-122"] = {  # Yamask
    "Focused Wish": (DealDamage(20), FlipCoinThen(heads=(DealDamage(20),))),
}
ATTACK_EFFECTS["rsv10pt5-123"] = {  # Cofagrigus(Extended Damagriiigusは自分のベンチ1匹選択+相手の場
    # 1匹選択という2段階の対象選択が必要なため見送り)
    "Perplex": (DealDamage(60), InflictStatusOnDefender(condition="confused")),
}
ATTACK_EFFECTS["rsv10pt5-124"] = {"Super Psy Bolt": (DealDamage(20),)}  # Gothita
ATTACK_EFFECTS["rsv10pt5-125"] = {  # Gothorita(Fortunate Eyeは相手の山札の並び替えという新規UIが
    # 必要なため見送り)
    "Psyshot": (DealDamage(40),),
}
ATTACK_EFFECTS["rsv10pt5-126"] = {  # Frillish
    "Oceanic Gloom": (DealDamage(20), LockOpponentItemsNextTurn()),
}
ATTACK_EFFECTS["rsv10pt5-127"] = {  # Roggenrola(Hardenは「40以下のダメージのみ防ぐ」閾値シールドという
    # 新規機構が必要なため見送り)
    "Rolling Rocks": (DealDamage(30),),
}
ATTACK_EFFECTS["rsv10pt5-128"] = {  # Boldore
    "Smack Down": (BonusDamageIfDefenderHasResistanceType(base=30, bonus=50, resistance_type="Fighting"),),
    "Power Gem": (DealDamage(90),),
}
ATTACK_EFFECTS["rsv10pt5-129"] = {  # Gigalith
    "Vengeful Cannon": (DamagePerTypeBenchedDamageCounters(per_counter=20, pokemon_type="Fighting"),),
    "Heavy Impact": (DealDamage(160),),
}
ATTACK_EFFECTS["rsv10pt5-13"] = {"Heat Crash": (DealDamage(120),)}  # Emboar
ABILITY_EFFECTS["rsv10pt5-13"] = {  # Emboar(unlimited per turnはrules_engine._UNLIMITED_PER_TURN_ABILITY_CARD_IDS経由)
    "Inferno Fandango": (AttachEnergyFromHandToChosenOwnPokemon(energy_type="Fire"),),
}
ATTACK_EFFECTS["rsv10pt5-130"] = {  # Sawk
    "Elbow Strike": (DealDamage(30),),
    "Rising Chop": (DealDamageIfDefenderHasSubtypeIgnoringWeaknessResistance(amount=90, subtype="ex"),),
}
ATTACK_EFFECTS["rsv10pt5-131"] = {  # Archen
    "Acrobatics": (FlipMultipleCoinsForBonusDamage(base=0, count=2, per_heads=30),),
}
ATTACK_EFFECTS["rsv10pt5-132"] = {"Rock Throw": (DealDamage(100),)}  # Archeops
ABILITY_EFFECTS["rsv10pt5-132"] = {"Ancient Wing": (DevolveOpponentActiveIfEvolved(),)}
ATTACK_EFFECTS["rsv10pt5-133"] = {"Kick": (DealDamage(20),)}  # Mienfoo
ATTACK_EFFECTS["rsv10pt5-134"] = {  # Mienshao
    "Low Sweep": (DealDamage(40),),
    "Smash Uppercut": (DealDamageIgnoringResistanceOnly(80),),
}
ATTACK_EFFECTS["rsv10pt5-135"] = {  # Terrakion(Retaliateは「相手の直前の番にきぜつした自分のポケモンが
    # いれば」判定という新規状態追跡が必要なため見送り)
    "Land Crush": (DealDamage(100),),
}
ATTACK_EFFECTS["rsv10pt5-136"] = {  # Purrloin
    "Invite Evil": (SearchDeckForPokemonToHand(count=3, pokemon_type="Darkness"),),
}
ATTACK_EFFECTS["rsv10pt5-137"] = {  # Liepard
    "Knock Off": (DealDamage(50), DiscardRandomFromOpponentHand()),
}
ATTACK_EFFECTS["rsv10pt5-138"] = {  # Scraggy
    "Headbutt": (DealDamage(10),),
    "Invade": (DealDamage(30),),
}
ATTACK_EFFECTS["rsv10pt5-139"] = {  # Scrafty
    "Ruffians Attack": (FlipCoinPerOwnPokemonOfTypeForDamage(per_heads=60, pokemon_type="Darkness"),),
}
ATTACK_EFFECTS["rsv10pt5-14"] = {  # Pansear
    "Collect": (Draw(1),),
    "Scratch": (DealDamage(30),),
}
ATTACK_EFFECTS["rsv10pt5-140"] = {  # Trubbish
    "Drool": (DealDamage(10),),
    "Sludge Bomb": (DealDamage(20),),
}
ATTACK_EFFECTS["rsv10pt5-141"] = {  # Garbodor
    "Suffocating Gas": (DealDamage(40),),
    "Gunk Shot": (DealDamage(120), InflictStatusOnDefender(condition="poisoned")),
}
ATTACK_EFFECTS["rsv10pt5-142"] = {"Take Down": (DealDamage(30), SelfDamage(10))}  # Zorua
ATTACK_EFFECTS["rsv10pt5-143"] = {  # Zoroark
    "Mind Jack": (DamagePerOpponentBenchedPokemonCount(per_pokemon=30),),
    "Foul Play": (CopyOpponentActiveAttack(),),
}
ATTACK_EFFECTS["rsv10pt5-144"] = {"Playful Kick": (DealDamage(10),)}  # Vullaby
ATTACK_EFFECTS["rsv10pt5-145"] = {"Cutting Wind": (DealDamage(90),)}  # Mandibuzz(特性Look for Preyは
    # 相手の手札から選んで相手の場に出すという新規機構が必要なため見送り)
ATTACK_EFFECTS["rsv10pt5-146"] = {  # Deino
    "Body Slam": (DealDamage(20), FlipCoinThen(heads=(InflictStatusOnDefender(condition="paralyzed"),))),
    "Darkness Fang": (DealDamage(50),),
}
ATTACK_EFFECTS["rsv10pt5-147"] = {  # Zweilous
    "Double Hit": (FlipMultipleCoinsForBonusDamage(base=0, count=2, per_heads=40),),
    "Pitch-Black Fangs": (DealDamage(100),),
}
ATTACK_EFFECTS["rsv10pt5-148"] = {  # Ferroseed
    "Zzzt": (DealDamage(10),),
    "Metal Claw": (DealDamage(40),),
}
ATTACK_EFFECTS["rsv10pt5-149"] = {  # Ferrothorn
    "Power Whip": (DamagePerSelfEnergyToChosenOpponent(per_energy=20),),
    "Metal Claw": (DealDamage(130),),
}
ATTACK_EFFECTS["rsv10pt5-150"] = {  # Durant
    "Bite Together": (BonusDamageIfNamedPokemonOnBench(base=20, bonus=20, name="Durant"),),
    "Vise Grip": (DealDamage(50),),
}
ATTACK_EFFECTS["rsv10pt5-151"] = {  # Druddigon
    "Shred": (DealDamageIgnoringDefenderShieldAndReduction(40),),
    "Ambush": (DealDamage(90), FlipCoinThen(heads=(DealDamage(60),))),
}
ATTACK_EFFECTS["rsv10pt5-152"] = {  # Patrat
    "Procurement": (SearchDeckMultiCriteria(("item",)),),
    "Gnaw": (DealDamage(10),),
}
ATTACK_EFFECTS["rsv10pt5-154"] = {  # Lillipup
    "Play Rough": (DealDamage(10), FlipCoinThen(heads=(DealDamage(20),))),
}
ATTACK_EFFECTS["rsv10pt5-155"] = {  # Herdier
    "Roar": (ForceOpponentSwitchOpponentChooses(),),
    "Lunge Out": (DealDamage(70),),
}
ATTACK_EFFECTS["rsv10pt5-156"] = {  # Stoutland
    "Odor Sleuth": (FlipCoinsThenRetrieveFromDiscardToHand(count=3),),
    "Special Fang": (BonusDamageIfSelfHasAnySpecialEnergyAttached(base=100, bonus=100),),
}
ATTACK_EFFECTS["rsv10pt5-157"] = {  # Whimsicott ex
    "Energy Gift": (SearchDeckForBasicEnergyAttachFreely(count=3),),
    "Wondrous Cotton": (DamagePerOpponentHandTrainerCount(per_card=50),),
}
ATTACK_EFFECTS["rsv10pt5-158"] = {  # Reshiram ex
    "Slash": (DealDamage(50),),
    "Blazing Burst": (DamagePerOpponentPrizesTaken(base=130, per_prize=50), DiscardOwnEnergy(count=1)),
}
ATTACK_EFFECTS["rsv10pt5-159"] = {  # Keldeo ex
    "Gale Thrust": (DamageIfBecameActiveThisTurn(base=30, bonus=90),),
    "Sonic Edge": (DealDamageIgnoringDefenderShieldAndReduction(120),),
}
ATTACK_EFFECTS["rsv10pt5-160"] = {  # Jellicent ex(特性Oceanic Curseはバトル場にいる間ずっと発動する
    # 相手のグッズ/どうぐ使用禁止という新規機構が必要なため見送り)
    "Power Press": (DealDamage(80), IfExtraEnergyAttached(own_cost_count=2, extra_needed=2, then=(DealDamage(80),))),
}
ATTACK_EFFECTS["rsv10pt5-161"] = {  # Hydreigon ex(特性Greedy Eaterはたねポケモンをきぜつさせたら
    # サイド+1という新規プライズ機構が必要なため見送り)
    "Dark Bite": (DealDamage(200), DisableDefenderRetreatNextTurn()),
}
ATTACK_EFFECTS["rsv10pt5-162"] = {  # Bouffalant ex(特性Bouffalantはprimitives._INNATE_DAMAGE_REDUCTION_ABILITY_IDS経由)
    "Gold Breaker": (BonusDamageIfDefenderHasSubtype(base=100, bonus=100, subtype="ex"),),
}
TRAINER_EFFECTS["rsv10pt5-163"] = (  # Harlequin
    FlipCoinThen(
        heads=(BothPlayersShuffleHandAndDrawAsymmetric(own_count=5, opponent_count=3),),
        tails=(BothPlayersShuffleHandAndDrawAsymmetric(own_count=3, opponent_count=5),),
    ),
)
TRAINER_EFFECTS["rsv10pt5-164"] = (  # Hilda
    SearchDeckMultiCriteria(("evolution_pokemon", "any_energy")),
)
ATTACK_EFFECTS["rsv10pt5-172"] = {  # Victini
    "V-Force": (DealDamageIfOwnBenchCountAtMost(amount=120, min_more_than=4),),
}
ATTACK_EFFECTS["rsv10pt5-2"] = {"Bug Buzz": (DealDamage(40),)}  # Swadloon
ABILITY_EFFECTS["rsv10pt5-2"] = {"Healing Leaves": (HealOwnActiveFixed(amount=20),)}  # Swadloon
ATTACK_EFFECTS["rsv10pt5-3"] = {  # Leavanny
    "Healing Wrapping": (HealAllOwnPokemon(amount=100, basic_only=True),),
    "X-Scissor": (DealDamage(90), FlipCoinThen(heads=(DealDamage(40),))),
}
ATTACK_EFFECTS["rsv10pt5-4"] = {"Absorb": (DealDamage(10), HealSelf(10))}  # Cottonee
ATTACK_EFFECTS["rsv10pt5-43"] = {  # Gothitelle
    "Synchro Shot": (BonusDamageIfHandCountEqualsOpponent(base=0, bonus=90),),
}
ABILITY_EFFECTS["rsv10pt5-43"] = {"Distorted Future": (ForceOpponentShuffleHandThenDraw(count=3),)}  # Gothitelle
ATTACK_EFFECTS["rsv10pt5-6"] = {"Rear Kick": (DealDamage(30),)}  # Deerling
ATTACK_EFFECTS["rsv10pt5-7"] = {  # Sawsbuck
    "Push Down": (ForceOpponentSwitchOpponentChooses(),),
    "Solar Beam": (DealDamage(100),),
}
ATTACK_EFFECTS["rsv10pt5-78"] = {  # Tornadus
    "Wrapped in Wind": (AttachEnergyFromHandToSelf(),),
    "Hurricane": (DealDamage(100), MoveEnergyBetweenOwnPokemon()),
}
ATTACK_EFFECTS["rsv10pt5-8"] = {"Headbutt Bounce": (DealDamage(10),)}  # Shelmet(特性Stimulated Evolutionは
    # カラブラスト依存の進化タイミング例外という新規機構が必要なため見送り)
TRAINER_EFFECTS["rsv10pt5-82"] = TRAINER_EFFECTS["me4-108"]  # Energy Retrieval(me4-108と同一カードの別絵柄)

ATTACK_EFFECTS["rsv10pt5-36"] = ATTACK_EFFECTS["rsv10pt5-119"]  # Woobat 別絵柄
ATTACK_EFFECTS["rsv10pt5-97"] = ATTACK_EFFECTS["rsv10pt5-12"]  # Pignite 別絵柄
ATTACK_EFFECTS["rsv10pt5-37"] = ATTACK_EFFECTS["rsv10pt5-120"]  # Swoobat 別絵柄
ATTACK_EFFECTS["rsv10pt5-38"] = ATTACK_EFFECTS["rsv10pt5-121"]  # Sigilyph 別絵柄
ATTACK_EFFECTS["rsv10pt5-39"] = ATTACK_EFFECTS["rsv10pt5-122"]  # Yamask 別絵柄
ATTACK_EFFECTS["rsv10pt5-40"] = ATTACK_EFFECTS["rsv10pt5-123"]  # Cofagrigus 別絵柄
ATTACK_EFFECTS["rsv10pt5-41"] = ATTACK_EFFECTS["rsv10pt5-124"]  # Gothita 別絵柄
ATTACK_EFFECTS["rsv10pt5-42"] = ATTACK_EFFECTS["rsv10pt5-125"]  # Gothorita 別絵柄
ATTACK_EFFECTS["rsv10pt5-46"] = ATTACK_EFFECTS["rsv10pt5-127"]  # Roggenrola 別絵柄
ATTACK_EFFECTS["rsv10pt5-47"] = ATTACK_EFFECTS["rsv10pt5-128"]  # Boldore 別絵柄
ATTACK_EFFECTS["rsv10pt5-48"] = ATTACK_EFFECTS["rsv10pt5-129"]  # Gigalith 別絵柄
ATTACK_EFFECTS["rsv10pt5-98"] = ATTACK_EFFECTS["rsv10pt5-13"]  # Emboar 別絵柄
ABILITY_EFFECTS["rsv10pt5-98"] = ABILITY_EFFECTS["rsv10pt5-13"]
ATTACK_EFFECTS["rsv10pt5-49"] = ATTACK_EFFECTS["rsv10pt5-130"]  # Sawk 別絵柄
ATTACK_EFFECTS["rsv10pt5-50"] = ATTACK_EFFECTS["rsv10pt5-131"]  # Archen 別絵柄
ATTACK_EFFECTS["rsv10pt5-51"] = ATTACK_EFFECTS["rsv10pt5-132"]  # Archeops 別絵柄
ABILITY_EFFECTS["rsv10pt5-51"] = ABILITY_EFFECTS["rsv10pt5-132"]  # Archeops 別絵柄
ATTACK_EFFECTS["rsv10pt5-52"] = ATTACK_EFFECTS["rsv10pt5-133"]  # Mienfoo 別絵柄
ATTACK_EFFECTS["rsv10pt5-53"] = ATTACK_EFFECTS["rsv10pt5-134"]  # Mienshao 別絵柄
ATTACK_EFFECTS["rsv10pt5-54"] = ATTACK_EFFECTS["rsv10pt5-135"]  # Terrakion 別絵柄
ATTACK_EFFECTS["rsv10pt5-55"] = ATTACK_EFFECTS["rsv10pt5-136"]  # Purrloin 別絵柄
ATTACK_EFFECTS["rsv10pt5-56"] = ATTACK_EFFECTS["rsv10pt5-137"]  # Liepard 別絵柄
ATTACK_EFFECTS["rsv10pt5-57"] = ATTACK_EFFECTS["rsv10pt5-138"]  # Scraggy 別絵柄
ATTACK_EFFECTS["rsv10pt5-58"] = ATTACK_EFFECTS["rsv10pt5-139"]  # Scrafty 別絵柄
for _alias_id in ("rsv10pt5-99", "zsv10pt5-101", "zsv10pt5-17", "zsv10pt5-4", "zsv10pt5-89"):
    ATTACK_EFFECTS[_alias_id] = ATTACK_EFFECTS["rsv10pt5-14"]  # Pansear 別絵柄
ATTACK_EFFECTS["rsv10pt5-59"] = ATTACK_EFFECTS["rsv10pt5-140"]  # Trubbish 別絵柄
ATTACK_EFFECTS["rsv10pt5-60"] = ATTACK_EFFECTS["rsv10pt5-141"]  # Garbodor 別絵柄
ATTACK_EFFECTS["rsv10pt5-61"] = ATTACK_EFFECTS["rsv10pt5-142"]  # Zorua 別絵柄
ATTACK_EFFECTS["rsv10pt5-62"] = ATTACK_EFFECTS["rsv10pt5-143"]  # Zoroark 別絵柄
ATTACK_EFFECTS["rsv10pt5-63"] = ATTACK_EFFECTS["rsv10pt5-144"]  # Vullaby 別絵柄
ATTACK_EFFECTS["rsv10pt5-64"] = ATTACK_EFFECTS["rsv10pt5-145"]  # Mandibuzz 別絵柄
ATTACK_EFFECTS["rsv10pt5-65"] = ATTACK_EFFECTS["rsv10pt5-146"]  # Deino 別絵柄
ATTACK_EFFECTS["rsv10pt5-66"] = ATTACK_EFFECTS["rsv10pt5-147"]  # Zweilous 別絵柄
ATTACK_EFFECTS["rsv10pt5-68"] = ATTACK_EFFECTS["rsv10pt5-148"]  # Ferroseed 別絵柄
ATTACK_EFFECTS["rsv10pt5-69"] = ATTACK_EFFECTS["rsv10pt5-149"]  # Ferrothorn 別絵柄
ATTACK_EFFECTS["rsv10pt5-70"] = ATTACK_EFFECTS["rsv10pt5-150"]  # Durant 別絵柄
ATTACK_EFFECTS["rsv10pt5-71"] = ATTACK_EFFECTS["rsv10pt5-151"]  # Druddigon 別絵柄
ATTACK_EFFECTS["rsv10pt5-72"] = ATTACK_EFFECTS["rsv10pt5-152"]  # Patrat 別絵柄
ATTACK_EFFECTS["rsv10pt5-74"] = ATTACK_EFFECTS["rsv10pt5-154"]  # Lillipup 別絵柄
ATTACK_EFFECTS["rsv10pt5-75"] = ATTACK_EFFECTS["rsv10pt5-155"]  # Herdier 別絵柄
ATTACK_EFFECTS["rsv10pt5-76"] = ATTACK_EFFECTS["rsv10pt5-156"]  # Stoutland 別絵柄
for _alias_id in ("rsv10pt5-165", "rsv10pt5-5"):
    ATTACK_EFFECTS[_alias_id] = ATTACK_EFFECTS["rsv10pt5-157"]  # Whimsicott ex 別絵柄
for _alias_id in ("rsv10pt5-166", "rsv10pt5-173", "rsv10pt5-20"):
    ATTACK_EFFECTS[_alias_id] = ATTACK_EFFECTS["rsv10pt5-158"]  # Reshiram ex 別絵柄
for _alias_id in ("rsv10pt5-167", "rsv10pt5-30"):
    ATTACK_EFFECTS[_alias_id] = ATTACK_EFFECTS["rsv10pt5-159"]  # Keldeo ex 別絵柄
ATTACK_EFFECTS["rsv10pt5-168"] = ATTACK_EFFECTS["rsv10pt5-160"]  # Jellicent ex 別絵柄
for _alias_id in ("rsv10pt5-169", "rsv10pt5-67"):
    ATTACK_EFFECTS[_alias_id] = ATTACK_EFFECTS["rsv10pt5-161"]  # Hydreigon ex 別絵柄
for _alias_id in ("rsv10pt5-170", "rsv10pt5-77"):
    ATTACK_EFFECTS[_alias_id] = ATTACK_EFFECTS["rsv10pt5-162"]  # Bouffalant ex 別絵柄
TRAINER_EFFECTS["rsv10pt5-171"] = TRAINER_EFFECTS["rsv10pt5-164"]  # Hilda 別絵柄
for _alias_id in ("zsv10pt5-12", "zsv10pt5-171"):
    ATTACK_EFFECTS[_alias_id] = ATTACK_EFFECTS["rsv10pt5-172"]  # Victini 別絵柄
ATTACK_EFFECTS["rsv10pt5-88"] = ATTACK_EFFECTS["rsv10pt5-2"]  # Swadloon 別絵柄
ABILITY_EFFECTS["rsv10pt5-88"] = ABILITY_EFFECTS["rsv10pt5-2"]
ATTACK_EFFECTS["rsv10pt5-89"] = ATTACK_EFFECTS["rsv10pt5-3"]  # Leavanny 別絵柄
ATTACK_EFFECTS["rsv10pt5-90"] = ATTACK_EFFECTS["rsv10pt5-4"]  # Cottonee 別絵柄
ATTACK_EFFECTS["rsv10pt5-91"] = ATTACK_EFFECTS["rsv10pt5-6"]  # Deerling 別絵柄
ATTACK_EFFECTS["rsv10pt5-92"] = ATTACK_EFFECTS["rsv10pt5-7"]  # Sawsbuck 別絵柄
ATTACK_EFFECTS["rsv10pt5-93"] = ATTACK_EFFECTS["rsv10pt5-8"]  # Shelmet 別絵柄

# ---- Iレギュレーション新規カード実装 第8バッチ ----

ATTACK_EFFECTS["rsv10pt5-9"] = {  # Accelgor
    "Acid Spray": (DealDamage(50), FlipCoinThen(heads=(DiscardOpponentActiveEnergy(),))),
}
ATTACK_EFFECTS["sv10-1"] = {  # Ethan's Pinsir(Rallying Hornは「相手の直前の番にきぜつした自分の
    # Ethan'sポケモンがいれば」判定という新規状態追跡が必要なため見送り)
    "Vise Grip": (DealDamage(20),),
    "Rallying Horn": (DealDamage(70),),
}
ATTACK_EFFECTS["sv10-10"] = {"Smash Kick": (DealDamage(30),)}  # Shaymin(特性Flower Curtainは
    # primitives._BENCH_BARRIER_EXCLUDING_RULE_BOX_IDS経由)
ATTACK_EFFECTS["sv10-100"] = {  # Medicham
    "Harmonious Spirit Palm": (BonusDamageIfSameEnergyCountAsDefender(base=50, bonus=120),),
}
ATTACK_EFFECTS["sv10-107"] = {  # Mudbray
    "Running Charge": (DamagePerHeadsUntilTails(base=0, damage_per_heads=40),),
}
ATTACK_EFFECTS["sv10-108"] = {"Heavy Impact": (DealDamage(130),)}  # Mudsdale(特性Mud Coatは
    # primitives._INNATE_DAMAGE_REDUCTION_ABILITY_IDS経由)
ATTACK_EFFECTS["sv10-109"] = {"Slight Intrusion": (DealDamage(30), SelfDamage(10))}  # Arven's Toedscool
ATTACK_EFFECTS["sv10-11"] = {"Ascension": (InstantEvolveSelfFromDeck(),)}  # Dwebble
ATTACK_EFFECTS["sv10-110"] = {  # Arven's Toedscruel
    "Pull": (ForceOpponentSwitchOpponentChooses(),),
    "Reckless Charge": (DealDamage(120), SelfDamage(30)),
}
ATTACK_EFFECTS["sv10-111"] = {  # Cornerstone Mask Ogerpon
    "Rock Kagura": (SearchDeckForBasicEnergyAttachToTarget(count=1, energy_type="Fighting", self_only=False),),
    "Mountain Ramming": (DealDamage(100), DiscardTopOfOpponentDeck(1)),
}
ATTACK_EFFECTS["sv10-112"] = {  # Team Rocket's Ekans
    "Drag Down": (FlipCoinThen(heads=(InflictStatusOnDefender(condition="paralyzed"),)),),
    "Gnaw": (DealDamage(10),),
}
ATTACK_EFFECTS["sv10-113"] = {  # Team Rocket's Arbok(特性Potent Glareは相手の手札からの特定条件付き
    # プレイ禁止という新規機構が必要なため見送り)
    "Spinning Tail": (DealDamage(30), DealFixedDamageToAllOpponentBenchedPokemon(30)),
}
ATTACK_EFFECTS["sv10-115"] = {  # Team Rocket's Nidorina(Dark Awakeningはベンチ最大2匹への同時進化と
    # いう新規機構が必要なため見送り)
    "Scratch": (DealDamage(50),),
}
ATTACK_EFFECTS["sv10-116"] = {  # Team Rocket's Nidoqueen
    "Love Impact": (BonusDamageIfNamedPokemonOnBench(base=60, bonus=120, name="Nidoking", contains=True),),
    "Mega Kick": (DealDamage(130),),
}
ATTACK_EFFECTS["sv10-117"] = {  # Team Rocket's Nidoran♂
    "Pierce": (DealDamage(10),),
    "Hammer In": (DealDamage(30),),
}
ATTACK_EFFECTS["sv10-118"] = {  # Team Rocket's Nidorino
    "Hammer In": (DealDamage(30),),
    "Horn Rend": (BonusDamageIfDefenderAlreadyDamaged(base=60, bonus=60),),
}
ATTACK_EFFECTS["sv10-119"] = {  # Team Rocket's Nidoking ex
    "Tainted Horn": (DealDamage(100), InflictHeavyPoison(severity=8)),
    "Kingly Impact": (DealDamage(240),),
}
ATTACK_EFFECTS["sv10-12"] = {  # Crustle(特性Mysterious Rock Innはprimitives._FULL_DAMAGE_IMMUNITY_VS_SUBTYPE経由)
    "Superb Scissors": (DealDamageIgnoringDefenderShieldAndReduction(120),),
}
ATTACK_EFFECTS["sv10-120"] = {"Poison Spray": (InflictStatusOnDefender(condition="poisoned"),)}  # Team Rocket's Zubat
ATTACK_EFFECTS["sv10-121"] = {  # Team Rocket's Golbat
    "Confuse Ray": (DealDamage(30), InflictStatusOnDefender(condition="confused")),
}
EVOLVE_TRIGGER_EFFECTS["sv10-121"] = EVOLVE_TRIGGER_EFFECTS["xy4-32"]  # Team Rocket's Golbat: Sneaky Bite(xy4-32ゴルバットと同一テキストの別カード)
ATTACK_EFFECTS["sv10-122"] = {  # Team Rocket's Crobat ex(特性Biting Spreeは相手の場から2匹選ぶ新規UIが
    # 必要なため見送り)
    "Assassin's Return": (DealDamage(120), ReturnSelfToHandUnconditional()),
}
ATTACK_EFFECTS["sv10-124"] = {  # Team Rocket's Muk
    "Gooped Up": (
        DealDamage(40),
        InflictStatusOnDefender(condition="confused"),
        DisableDefenderRetreatNextTurn(),
    ),
    "Hazardous Venom": (DamagePerDefenderSpecialConditionCount(per_condition=100),),
}
ATTACK_EFFECTS["sv10-125"] = {"Leaking Gas": (DealDamage(30),)}  # Team Rocket's Koffing(特性Smog Signalsは
    # 見送り)
ATTACK_EFFECTS["sv10-126"] = {  # Team Rocket's Weezing
    "Explode Together Now": (
        DamagePerPokemonBothSidesNamedContains(per_pokemon=40, names=("Koffing", "Weezing")),
    ),
}
ATTACK_EFFECTS["sv10-127"] = {  # Team Rocket's Murkrow
    "Deceit": (SearchDeckMultiCriteria(("supporter",)),),
    "Torment": (DealDamage(30), LockChosenOpponentAttackNextTurn()),
}
ATTACK_EFFECTS["sv10-13"] = {"Cut Up": (DealDamage(20),)}  # Fomantis
ATTACK_EFFECTS["sv10-130"] = {  # Marnie's Purrloin
    "Pointy Nails": (BonusDamageIfDefenderHasSubtype(base=20, bonus=40, subtype="ex"),),
}
ATTACK_EFFECTS["sv10-131"] = {  # Marnie's Liepard
    "Pointy Claws": (BonusDamageIfDefenderHasSubtype(base=70, bonus=70, subtype="ex"),),
}
ATTACK_EFFECTS["sv10-132"] = {"Crunch": (DealDamage(50), DiscardOpponentActiveEnergy())}  # Marnie's Scraggy
ATTACK_EFFECTS["sv10-133"] = {  # Marnie's Scrafty
    "Rear Kick": (DealDamage(40),),
    "Wild Tackle": (DealDamage(160), SelfDamage(30)),
}
ATTACK_EFFECTS["sv10-136"] = ATTACK_EFFECTS["me2pt5-287"]  # Marnie's Grimmsnarl ex(me2pt5-287と同一カードの別絵柄)
EVOLVE_TRIGGER_EFFECTS["sv10-136"] = EVOLVE_TRIGGER_EFFECTS["me2pt5-287"]
ATTACK_EFFECTS["sv10-137"] = {  # Marnie's Morpeko
    "Spiky Wheel": (DealDamage(20), DamagePerOwnAttachedEnergyCount(per_energy=40, energy_type="Darkness")),
}
ATTACK_EFFECTS["sv10-138"] = {  # Arven's Maschiff
    "Stampede": (DealDamage(10),),
    "Confront": (DealDamage(50),),
}
ATTACK_EFFECTS["sv10-139"] = {  # Arven's Mabosstiff ex
    "Vigorous Tackle": (BonusDamageIfSelfNotDamaged(base=30, bonus=120),),
    "Boss Headbutt": (DealDamage(210), LockOwnAttackNextTurn(attack_name="Boss Headbutt")),
}
ATTACK_EFFECTS["sv10-14"] = {  # Lurantis
    "Razor Leaf": (DealDamage(30),),
    "Petal Blade Dance": (DealDamageIfCanDiscardEnergyFromHand(amount=130, count=2, energy_type="Grass"),),
}
ATTACK_EFFECTS["sv10-140"] = {  # Forretress
    "Iron Shake-Up": (DealDamage(20), ChooseSourceThenMoveEnergyFreely()),
    "Hurricane of Needles": (FlipMultipleCoinsForBonusDamage(base=0, count=4, per_heads=80),),
}
ATTACK_EFFECTS["sv10-141"] = {  # Skarmory
    "Roost": (HealSelf(50), LockSelfRetreatNextTurn()),
    "Metal Claw": (DealDamage(60),),
}
ATTACK_EFFECTS["sv10-142"] = {  # Steven's Skarmory(Sonic Doubleは相手の場から2匹選ぶ新規UIが必要なため見送り)
    "Razor Wing": (DealDamage(30),),
}
ATTACK_EFFECTS["sv10-143"] = {"Ram": (DealDamage(30),)}  # Steven's Beldum
ATTACK_EFFECTS["sv10-144"] = {  # Steven's Metang
    "Metal Slash": (DealDamage(70), LockOwnAttackNextTurn(attack_name="", lock_all_attacks=True)),
}
ATTACK_EFFECTS["sv10-146"] = {  # Zamazenta(Strong Bashの被ダメージ量に比例した反撃は新規機構が
    # 必要なため見送り)
    "Strong Bash": (DealDamage(70),),
}
ATTACK_EFFECTS["sv10-147"] = {"Dangerous Incisors": (DealDamage(10), InflictStatusOnDefender(condition="poisoned"))}  # Team Rocket's Rattata
ATTACK_EFFECTS["sv10-148"] = {  # Team Rocket's Raticate
    "Reckless Abandon": (DealDamage(90), SelfDamageUnlessAllCoinsTails(count=2, amount=90)),
}
ATTACK_EFFECTS["sv10-150"] = {  # Team Rocket's Persian ex(Haughty Orderは山札上10枚から借りたワザを
    # 使うという新規機構が必要なため見送り)
    "Cruel Slash": (DealDamage(140), InflictStatusOnDefender(condition="confused")),
}
ATTACK_EFFECTS["sv10-151"] = {  # Kangaskhan
    "Gentle Slap": (DealDamage(50),),
    "Dizzy Punch": (FlipMultipleCoinsForBonusDamage(base=0, count=2, per_heads=90),),
}
ATTACK_EFFECTS["sv10-152"] = {  # Tauros
    "Horn Attack": (DealDamage(30),),
    "Clean Hit": (BonusDamageIfDefenderIsEvolutionPokemon(base=50, bonus=50),),
}
ATTACK_EFFECTS["sv10-155"] = {  # Team Rocket's Porygon-Z
    "R Command": (DamagePerOwnDiscardSupporterNameContainsCount(per_card=20, name_contains="Team Rocket"),),
}
ABILITY_EFFECTS["sv10-155"] = {"Reconstitute": (DiscardCardsFromHand(2), Draw(1))}  # Team Rocket's Porygon-Z
ATTACK_EFFECTS["sv10-156"] = {"Wing Attack": (DealDamage(20),)}  # Taillow
ATTACK_EFFECTS["sv10-157"] = {  # Swellow
    "Add On": (Draw(3),),
    "Speed Wing": (DealDamage(70),),
}
ATTACK_EFFECTS["sv10-158"] = {  # Arven's Skwovet
    "Gnaw Through": (DiscardDefenderTool(), DealDamage(10)),
}
ATTACK_EFFECTS["sv10-159"] = {"Rolling Tackle": (DealDamage(50),)}  # Arven's Greedent(特性Greedy Orderは
    # 特定カード名のトラッシュ回収という限定的機構のため見送り)
ATTACK_EFFECTS["sv10-160"] = {  # Squawkabilly
    "Push Down": (DealDamage(20), FlipCoinThen(heads=(ForceOpponentSwitchOpponentChooses(),))),
}
TRAINER_EFFECTS["sv10-161"] = (  # Arven's Sandwich
    HealOwnActiveBonusIfNamedPrefix(amount=30, bonus_amount=100, name_prefix="Arven's"),
)
TRAINER_EFFECTS["sv10-163"] = (  # Emcee's Hype
    DrawBonusIfOpponentPrizesAtMost(base=2, bonus=4, threshold=3),
)

ATTACK_EFFECTS["rsv10pt5-94"] = ATTACK_EFFECTS["rsv10pt5-9"]  # Accelgor 別絵柄
ATTACK_EFFECTS["sv10-185"] = ATTACK_EFFECTS["sv10-10"]  # Shaymin 別絵柄
for _alias_id in ("sv10-216", "sv10-233"):
    ATTACK_EFFECTS[_alias_id] = ATTACK_EFFECTS["sv10-119"]  # Team Rocket's Nidoking ex 別絵柄
ATTACK_EFFECTS["sv10-186"] = ATTACK_EFFECTS["sv10-12"]  # Crustle 別絵柄
for _alias_id in ("sv10-217", "sv10-234", "sv10-242"):
    ATTACK_EFFECTS[_alias_id] = ATTACK_EFFECTS["sv10-122"]  # Team Rocket's Crobat ex 別絵柄
ATTACK_EFFECTS["sv10-199"] = ATTACK_EFFECTS["sv10-126"]  # Team Rocket's Weezing 別絵柄
ATTACK_EFFECTS["sv10-200"] = ATTACK_EFFECTS["sv10-127"]  # Team Rocket's Murkrow 別絵柄
ATTACK_EFFECTS["svp-206"] = ATTACK_EFFECTS["sv10-137"]  # Marnie's Morpeko 別絵柄
for _alias_id in ("sv10-218", "sv10-235"):
    ATTACK_EFFECTS[_alias_id] = ATTACK_EFFECTS["sv10-139"]  # Arven's Mabosstiff ex 別絵柄
ATTACK_EFFECTS["svp-207"] = ATTACK_EFFECTS["sv10-143"]  # Steven's Beldum 別絵柄
ATTACK_EFFECTS["sv10-201"] = ATTACK_EFFECTS["sv10-146"]  # Zamazenta 別絵柄
ATTACK_EFFECTS["sv10-202"] = ATTACK_EFFECTS["sv10-148"]  # Team Rocket's Raticate 別絵柄
ATTACK_EFFECTS["sv10-219"] = ATTACK_EFFECTS["sv10-150"]  # Team Rocket's Persian ex 別絵柄
ATTACK_EFFECTS["sv10-204"] = ATTACK_EFFECTS["sv10-151"]  # Kangaskhan 別絵柄
ATTACK_EFFECTS["sv10-205"] = ATTACK_EFFECTS["sv10-159"]  # Arven's Greedent 別絵柄
TRAINER_EFFECTS["sv10-220"] = TRAINER_EFFECTS["sv10-163"]  # Emcee's Hype 別絵柄

# ---- Iレギュレーション新規カード実装 第9バッチ ----
TRAINER_EFFECTS["sv10-179"] = (  # Team Rocket's Venture Bomb
    FlipCoinThen(heads=(DamageCounterOnChosenOpponentPokemon(count=2),), tails=(DamageCounterOnOwnActive(count=2),)),
)
ATTACK_EFFECTS["sv10-18"] = {  # Hydrapple
    "Hydra Breath": (KnockOutDefenderIfCanDiscardEnergyFromHand(count=6, energy_type="Grass"),),
    "Whip Smash": (DealDamage(140),),
}
ATTACK_EFFECTS["sv10-188"] = ATTACK_EFFECTS["sv10-18"]  # Hydrapple 別絵柄
ATTACK_EFFECTS["sv10-183"] = {  # Yanma
    "Whirlwind": (ForceOpponentSwitchOpponentChooses(),),
    "Razor Wing": (DealDamage(30),),
}
ATTACK_EFFECTS["sv10-2"] = ATTACK_EFFECTS["sv10-183"]  # Yanma 別絵柄
ATTACK_EFFECTS["sv10-184"] = {"Leaf Step": (DealDamage(80),)}  # Cynthia's Roserade(特性「Cheer On to
# Glory」はeffects.primitives._NAMED_PREFIX_TEAM_ATTACK_BONUS_ABILITY_IDS経由で実装済み、常時発動の
# ダメージ加算なのでABILITY_EFFECTSへの登録は不要)
ATTACK_EFFECTS["sv10-8"] = ATTACK_EFFECTS["sv10-184"]  # Cynthia's Roserade 別絵柄
ATTACK_EFFECTS["sv10-189"] = {"Fire Mane": (DealDamage(60),)}  # Rapidash
ABILITY_EFFECTS["sv10-189"] = {"Hurried Gait": (Draw(1),)}
ATTACK_EFFECTS["sv10-30"] = ATTACK_EFFECTS["sv10-189"]  # Rapidash 別絵柄
ABILITY_EFFECTS["sv10-30"] = ABILITY_EFFECTS["sv10-189"]
ATTACK_EFFECTS["sv10-190"] = {  # Ethan's Typhlosion
    "Buddy Blast": (DamagePerOwnDiscardSupporterNameContainsCount(base=40, per_card=60, name_contains="Ethan's Adventure"),),
    "Steam Artillery": (DealDamage(160),),
}
ATTACK_EFFECTS["sv10-34"] = ATTACK_EFFECTS["sv10-190"]  # Ethan's Typhlosion 別絵柄
ATTACK_EFFECTS["sv10-191"] = {  # Team Rocket's Houndoom
    "Cruel Coal": (InflictStatusOnDefender(condition="burned"), InflictStatusOnDefender(condition="confused")),
    "Scorching Fire": (DealDamage(120), DiscardOwnEnergy(count=1)),
}
ATTACK_EFFECTS["sv10-38"] = ATTACK_EFFECTS["sv10-191"]  # Team Rocket's Houndoom 別絵柄
ATTACK_EFFECTS["sv10-192"] = {  # Blaziken
    "Heat Blast": (DealDamage(70),),
    "Inferno Kick Flurry": (DealDamage(120), DiscardOwnEnergy(count=2), DealBonusDamageToChosenOpponentBench(120)),
}
ATTACK_EFFECTS["sv10-42"] = ATTACK_EFFECTS["sv10-192"]  # Blaziken 別絵柄
ATTACK_EFFECTS["sv10-193"] = {"Sprinkle Water": (DealDamage(30),)}  # Misty's Psyduck(特性「Flustered
# Leap」は「山札の下から捨てる→自分自身を山札の1番上に戻す」という新規機構が必要なため見送り)
ATTACK_EFFECTS["sv10-45"] = ATTACK_EFFECTS["sv10-193"]  # Misty's Psyduck 別絵柄
ATTACK_EFFECTS["sv10-194"] = {  # Misty's Lapras
    "Swim Together": (SearchDeckForNamePrefixPokemonToHand(name_prefix="Misty's", count=3),),
    "Surf": (DealDamage(60),),
}
ATTACK_EFFECTS["sv10-50"] = ATTACK_EFFECTS["sv10-194"]  # Misty's Lapras 別絵柄
ATTACK_EFFECTS["sv10-195"] = {"Shell Press": (DealDamage(10), ApplyDamageReductionToSelf(10))}  # Clamperl
ATTACK_EFFECTS["sv10-54"] = ATTACK_EFFECTS["sv10-195"]  # Clamperl 別絵柄
ATTACK_EFFECTS["sv10-196"] = {"Rear Kick": (DealDamage(10),), "Tiny Bolt": (DealDamage(30),)}  # Electrike
ATTACK_EFFECTS["sv10-75"] = ATTACK_EFFECTS["sv10-196"]  # Electrike 別絵柄
ATTACK_EFFECTS["sv10-197"] = {  # Rotom
    "Astonish": (DealDamage(20), ShuffleRandomFromOpponentHandIntoDeck()),
    "Gadget Show": (DamagePerOwnToolAttachedCount(per_tool=30),),
}
ATTACK_EFFECTS["sv10-77"] = ATTACK_EFFECTS["sv10-197"]  # Rotom 別絵柄
ATTACK_EFFECTS["sv10-198"] = {"Psychic": (DamagePerDefenderEnergyCount(base=40, per_energy=40),)}  # Team
# Rocket's Orbeetle(特性「Rocket Brain」は「何度でも使える、ダメカンを別ポケモンへ移す」という
# 回数無制限の追加行動機構が必要なため見送り)
ATTACK_EFFECTS["sv10-89"] = ATTACK_EFFECTS["sv10-198"]  # Team Rocket's Orbeetle 別絵柄
ATTACK_EFFECTS["sv10-206"] = {"Jet Cyclone": (DealDamage(210), MoveEnergyBetweenOwnPokemon(count=3))}  # Yanmega ex
BECOME_ACTIVE_TRIGGER_EFFECTS["sv10-206"] = (
    SearchDeckForBasicEnergyAttachToTarget(count=3, energy_type="Grass", self_only=True),
)
for _alias_id in ("sv10-228", "sv10-3"):
    ATTACK_EFFECTS[_alias_id] = ATTACK_EFFECTS["sv10-206"]  # Yanmega ex 別絵柄
    BECOME_ACTIVE_TRIGGER_EFFECTS[_alias_id] = BECOME_ACTIVE_TRIGGER_EFFECTS["sv10-206"]
ATTACK_EFFECTS["sv10-207"] = ATTACK_EFFECTS["sv10-23"]  # Arboliva ex(sv10-23と完全同一テキストの
# 別収録、novel_groupsの自動判定漏れを個別に発見)
ATTACK_EFFECTS["sv10-208"] = {  # Team Rocket's Moltres ex
    "Flame Screen": (DealDamage(110), ApplyDamageReductionToSelf(50)),
    "Evil Incineration": (DiscardOwnTeamRocketEnergyThenKnockOutDefender(),),
}
for _alias_id in ("sv10-229", "sv10-31"):
    ATTACK_EFFECTS[_alias_id] = ATTACK_EFFECTS["sv10-208"]  # Team Rocket's Moltres ex 別絵柄
ATTACK_EFFECTS["sv10-210"] = {  # Cetitan ex(特性「Snow Camouflage」は相手のグッズ/サポートカードの
    # 効果を個別に無効化する汎用防御機構が必要なため見送り)
    "Crushing Press": (DealDamageBonusIfStadiumInPlayThenDiscardIt(base=140, bonus=140), DiscardStadiumInPlay()),
}
ATTACK_EFFECTS["sv10-65"] = ATTACK_EFFECTS["sv10-210"]  # Cetitan ex 別絵柄
ATTACK_EFFECTS["sv10-211"] = {  # Dondozo ex
    "Avenging Billow": (DamagePerSelfDamageCounters(per_counter=10, base=30),),
    "Dynamic Dive": (DealDamage(240), SelfDamage(50)),
}
ATTACK_EFFECTS["sv10-66"] = ATTACK_EFFECTS["sv10-211"]  # Dondozo ex 別絵柄
ATTACK_EFFECTS["sv10-212"] = {  # Electivire ex(ワザ「Dual Bolt」は相手の場のポケモン2体を選ぶ
    # 複数対象選択という新規機構が必要なため見送り)
    "High-Voltage Press": (DamageIfExtraEnergyAttached(base=180, bonus=100, extra_needed=2, cost_count=3),),
}
ATTACK_EFFECTS["sv10-69"] = ATTACK_EFFECTS["sv10-212"]  # Electivire ex 別絵柄
STADIUM_ABILITY_EFFECTS["sv10-244"] = STADIUM_ABILITY_EFFECTS["sv9-150"]  # Levincia(sv9-150と完全同一テキストの別収録)
ATTACK_EFFECTS["sv10-26"] = {  # Teal Mask Ogerpon
    "Grass Kagura": (SearchDeckForBasicEnergyAttachToTarget(count=1, energy_type="Grass", self_only=False),),
    "Ogre's Hammer": (DealDamage(120), LockOwnAttackNextTurn("Ogre's Hammer")),
}
ATTACK_EFFECTS["sv10-27"] = {"Live Coal": (DealDamage(10),), "Dig Claws": (DealDamage(20),)}  # Growlithe
ATTACK_EFFECTS["sv10-28"] = {  # Arcanine
    "Flare": (DealDamage(50),),
    "Punishing Fang": (BonusDamageIfDefenderType(base=100, bonus=100, defender_type="Darkness"),),
}
ATTACK_EFFECTS["sv10-29"] = {"Double Headbutt": (DealDamagePerHeads(coin_count=2, damage_per_heads=10),)}  # Ponyta
ATTACK_EFFECTS["sv10-32"] = {"Ember": (DealDamage(30), DiscardOwnEnergy(count=1))}  # Ethan's Cyndaquil
ATTACK_EFFECTS["sv10-33"] = {"Combustion": (DealDamage(40),)}  # Ethan's Quilava
ABILITY_EFFECTS["sv10-33"] = {"Bonded by the Journey": (SearchDeckByCriterionToHand(criterion="ethans_adventure", count=1),)}
ATTACK_EFFECTS["sv10-4"] = {"Hang Down": (DealDamage(10),)}  # Pineco
ATTACK_EFFECTS["sv10-41"] = {  # Combusken
    "Combustion": (DealDamage(20),),
    "Double Kick": (DealDamagePerHeads(coin_count=2, damage_per_heads=40),),
}
ATTACK_EFFECTS["sv10-43"] = {  # Heat Rotom
    "Singe": (InflictStatusOnDefender(condition="burned"),),
    "Gadget Show": (DamagePerOwnToolAttachedCount(per_tool=30),),
}
ATTACK_EFFECTS["sv10-44"] = {  # Hearthflame Mask Ogerpon
    "Fire Kagura": (SearchDeckForBasicEnergyAttachToTarget(count=1, energy_type="Fire", self_only=False),),
    "Searing Flame": (DealDamage(80), InflictStatusOnDefender(condition="burned")),
}
ATTACK_EFFECTS["sv10-46"] = {  # Misty's Staryu
    "Bubble Beam": (DealDamage(20), FlipCoinThen(heads=(InflictStatusOnDefender(condition="paralyzed"),))),
}
ATTACK_EFFECTS["sv10-47"] = {"Abrupt Flash": (DamageIfEvolvedThisTurn(base=60, bonus=80),)}  # Misty's Starmie
ATTACK_EFFECTS["sv10-48"] = {"Splash": (DealDamage(10),)}  # Misty's Magikarp(特性「So Submerged」は
# effects.primitives._SELF_BENCH_FULL_IMMUNITY_IDS経由で実装済み、常時効果なのでABILITY_EFFECTS登録は不要)
ATTACK_EFFECTS["sv10-49"] = {  # Misty's Gyarados
    "Splashing Panic": (DamagePerNamePrefixMilledFromTopOfOwnDeck(count=7, per_pokemon=70, name_prefix="Misty's"),),
    "Waterfall": (DealDamage(120),),
}
ATTACK_EFFECTS["sv10-5"] = {"Rolling Tackle": (DealDamage(30),)}  # Shroomish
ATTACK_EFFECTS["sv10-52"] = {"Undulate": (DealDamage(10), FlipCoinThen(heads=(ApplyShieldToSelf(),)))}  # Cynthia's Feebas
# Cynthia's Milotic(sv10-53)「Aqua Split」は相手のベンチポケモン2体を選ぶ複数対象選択という
# 新規機構が必要なため見送り(唯一のワザのため、このカードにはATTACK_EFFECTSを登録しない)
ATTACK_EFFECTS["sv10-55"] = {"Wave Splash": (DealDamage(80),)}  # Huntail(特性「Diver's Catch」は自分の
# 場のどのみずポケモンがきぜつしてもよい、きぜつ時トリガーの新規機構が必要なため見送り)
# Gorebyss(sv10-56)「Crescendo Wave」はダメージ計算前に手札から好きな枚数エネルギーを付け、その
# 結果を反映してダメージを決めるという新規機構が必要なため見送り(唯一のワザのため、このカードには
# ATTACK_EFFECTSを登録しない)
ATTACK_EFFECTS["sv10-57"] = {"Tail Whap": (DealDamage(10),), "Wave Splash": (DealDamage(30),)}  # Buizel
ATTACK_EFFECTS["sv10-58"] = {  # Floatzel
    "Whirlpool": (DealDamage(30), DiscardOpponentActiveEnergy()),
    "Aqua Slash": (DealDamage(140), LockOwnAttackNextTurn("Aqua Slash", lock_all_attacks=True)),
}
ATTACK_EFFECTS["sv10-59"] = {"Light Punch": (DealDamage(20),), "Icicle": (DealDamage(50),)}  # Snover
ATTACK_EFFECTS["sv10-6"] = {  # Breloom
    "Damage Rush": (DealDamageFlipUntilTailsBonus(base=30, bonus_per_heads=50),),
    "Mega Drain": (DealDamage(90), HealSelf(30)),
}
ATTACK_EFFECTS["sv10-60"] = {  # Abomasnow
    "Lunge Out": (DealDamage(90),),
    "Frozen Wood": (BonusDamageIfSelfHasEnergyType(base=120, bonus=120, energy_type="Grass", min_count=2),),
}
ATTACK_EFFECTS["sv10-61"] = {  # Wash Rotom
    "Manual Wash": (DealDamage(20), HealAllOwnPokemon(amount=10)),
    "Gadget Show": (DamagePerOwnToolAttachedCount(per_tool=30),),
}
ATTACK_EFFECTS["sv10-62"] = {"Reckless Charge": (DealDamage(30), SelfDamage(10))}  # Arrokuda
ATTACK_EFFECTS["sv10-63"] = {  # Barraskewda
    "Sharp Fin": (DealDamage(40),),
    "Dive": (DealDamage(60), FlipCoinThen(heads=(ApplyShieldToSelf(),))),
}
ATTACK_EFFECTS["sv10-64"] = {"Gentle Slap": (DealDamage(30),), "Frost Smash": (DealDamage(80),)}  # Cetoddle
ATTACK_EFFECTS["sv10-67"] = {  # Wellspring Mask Ogerpon
    "Water Kagura": (SearchDeckForBasicEnergyAttachToTarget(count=1, energy_type="Water", self_only=False),),
    "Bubble Drain": (DealDamage(100), HealSelf(30)),
}
ATTACK_EFFECTS["sv10-68"] = {"Electroslug": (DealDamage(50),)}  # Electabuzz
ATTACK_EFFECTS["sv10-7"] = {"Spike Sting": (DealDamage(20),)}  # Cynthia's Roselia
ATTACK_EFFECTS["sv10-70"] = {  # Team Rocket's Zapdos
    "Jamming Wing": (DealDamage(30), MoveEnergyOnOpponentSide()),
    "Wicked Thunder": (DamageBonusIfOwnEnergyIdAttached(base=60, bonus=60, required_energy_id="sv10-182"),),
}
ATTACK_EFFECTS["sv10-71"] = {"Zapping Draw": (DealDamage(30), Draw(1))}  # Ethan's Pichu
ATTACK_EFFECTS["sv10-72"] = {  # Team Rocket's Mareep
    "Procurement": (SearchDeckByCriterionToHand(criterion="item", count=1),),
    "Tiny Bolt": (DealDamage(10),),
}
ATTACK_EFFECTS["sv10-73"] = {  # Team Rocket's Flaaffy
    "Thunder Shock": (DealDamage(50), FlipCoinThen(heads=(InflictStatusOnDefender(condition="paralyzed"),))),
}
ATTACK_EFFECTS["sv10-74"] = {"Head Bolt": (DealDamage(140),)}  # Team Rocket's Ampharos(特性
# 「Darkest Impulse」は相手が進化させたときに反応する新規トリガー機構が必要なため見送り)
ATTACK_EFFECTS["sv10-76"] = {  # Manectric
    "Zap Kick": (DealDamage(30),),
    "Flash Impact": (DealDamage(120), DamageToChosenOwnPokemonIgnoringWeaknessResistance(40)),
}
ATTACK_EFFECTS["sv10-78"] = {  # Zeraora
    "Scratch": (DealDamage(20),),
    "Thunder Raid": (DiscardAllOwnEnergy(), DealBonusDamageToChosenOpponentBench(210, ex_only=True)),
}
ATTACK_EFFECTS["sv10-79"] = {"Hypnotic Ray": (DealDamage(10), InflictStatusOnDefender(condition="asleep"))}  # Team Rocket's Drowzee

# ---- Iレギュレーション新規カード実装 第10バッチ ----
ATTACK_EFFECTS["sv10-80"] = {  # Team Rocket's Hypno
    "Psyshot": (DealDamage(40),),
    "Bench Manipulation": (FlipCoinPerOpponentBenchCountForDamageToActive(per_tails=80),),
}
ATTACK_EFFECTS["sv10-82"] = {"Headbutt Bounce": (DealDamage(70),)}  # Team Rocket's Wobbuffet(特性を
# 持たないワザ「Rocket Mirror」は自分のベンチの「Team Rocket's」ポケモンを名前で絞り込んで選び、
# ダメカンを全て移すという新規機構が必要なため見送り)
ATTACK_EFFECTS["svp-203"] = ATTACK_EFFECTS["sv10-82"]  # Team Rocket's Wobbuffet 別絵柄
ATTACK_EFFECTS["sv10-83"] = {  # Steven's Baltoy
    "Summoning Sign": (SearchDeckForNamePrefixBasicPokemonToBench(name_prefix="Steven's", count=2),),
    "Psychic Sphere": (DealDamage(20),),
}
ATTACK_EFFECTS["sv10-84"] = {  # Steven's Claydol
    "Eerie Light": (DealDamage(20), InflictStatusOnDefender(condition="confused")),
    "Clay Blast": (DealDamage(220), DiscardAllOwnEnergy()),
}
ATTACK_EFFECTS["sv10-85"] = {"Chiming Commotion": (DiscardRandomFromOpponentHand(),)}  # Team Rocket's Chingling
ATTACK_EFFECTS["sv10-86"] = {"Magical Shot": (DealDamage(80),)}  # Steven's Carbink(特性「Stone Palace」は
# effects.primitives._NAMED_PREFIX_TEAM_DEFENSE_REDUCTION_ABILITY_IDS経由で実装済み)
ATTACK_EFFECTS["sv10-88"] = {"Super Psy Bolt": (DealDamage(30),)}  # Team Rocket's Dottler(ワザ
# 「Disruptive Radar」は相手の山札の上から5枚を見て自由な順番で戻すという新規機構が必要なため見送り)
ATTACK_EFFECTS["sv10-9"] = {  # Mow Rotom
    "Trimming Mower": (DealDamage(20), DiscardStadiumInPlay()),
    "Gadget Show": (DamagePerOwnToolAttachedCount(per_tool=30),),
}
ATTACK_EFFECTS["sv10-90"] = {"Wild Kick": (FlipCoinThen(heads=(DealDamage(30),)),)}  # Mankey
ATTACK_EFFECTS["sv10-91"] = {"Drag Off": (ForceOpponentSwitchChosenBench(), DealDamage(30))}  # Primeape
ATTACK_EFFECTS["sv10-92"] = {  # Annihilape
    "Impact Blow": (DealDamage(160), LockOwnAttackNextTurn("Impact Blow")),
}  # 特性「Lose Cool」はeffects.primitives._SELF_DAMAGED_BONUS_DAMAGE_ABILITY_IDS経由で実装済み
ATTACK_EFFECTS["sv10-93"] = {  # Ethan's Sudowoodo
    "Impound": (DealDamage(20), DisableDefenderRetreatNextTurn()),
    "Try to Imitate": (FlipCoinThen(heads=(CopyOpponentActiveAttack(),)),),
}
ATTACK_EFFECTS["sv10-94"] = {"Mountain Munch": (DealDamage(10), DiscardTopOfOpponentDeck(1))}  # Team Rocket's Larvitar
ATTACK_EFFECTS["sv10-95"] = {"Explosive Ascension": (DealDamage(30), InstantEvolveSelfFromDeck())}  # Team Rocket's Pupitar
ATTACK_EFFECTS["sv10-96"] = {  # Team Rocket's Tyranitar(特性「Sand Stream」はチェックアップ時に発動する
    # 新規トリガー機構が必要なため見送り)
    "Demolition Tackle": (DealDamage(180), DiscardOpponentActiveEnergy()),
}
ATTACK_EFFECTS["sv10-97"] = {"Headbutt": (DealDamage(20),), "Rock Throw": (DealDamage(40),)}  # Nosepass
ATTACK_EFFECTS["sv10-98"] = {  # Probopass
    "Power Gem": (DealDamage(40),),
    "Mountain Drop": (BonusDamageIfStadiumInPlay(base=70, bonus=70),),
}
ATTACK_EFFECTS["sv10-99"] = {"Steady Punch": (FlipCoinThen(heads=(DealDamage(30),), tails=(DealDamage(10),)),)}  # Meditite
ATTACK_EFFECTS["sv9-102"] = {  # Escavalier
    "Pierce": (DealDamage(20),),
    "Iron Buster": (DealDamage(120), LockOwnAttackNextTurn("Iron Buster", lock_all_attacks=True)),
}
ATTACK_EFFECTS["sv9-103"] = {"Double Spin": (DealDamagePerHeads(coin_count=2, damage_per_heads=10),)}  # N's Klink
ATTACK_EFFECTS["sv9-104"] = {  # N's Klang
    "Spinning Gears": (DealDamage(20), InflictStatusOnDefender(condition="confused")),
    "Confront": (DealDamage(40),),
}
ATTACK_EFFECTS["sv9-105"] = {  # N's Klinklang
    "Magnetic Blast": (DealDamage(50),),
    "Triple Smash": (DealDamagePerHeads(coin_count=3, damage_per_heads=120),),
}
ATTACK_EFFECTS["sv9-107"] = {"Spike Draw": (DealDamage(20), Draw(2))}  # Magearna(特性「Auto Heal」は
# 自分がバトル場にいる間、場のどのポケモンにエネルギーをつけても発動する監視型トリガーという
# 新規機構が必要なため見送り)
ATTACK_EFFECTS["sv9-108"] = {  # Hop's Corviknight
    "Shoot Through": (DealDamage(50), DealBonusDamageToChosenOpponentBench(50)),
    "Steel Wing": (DealDamage(150), ApplyDamageReductionToSelf(60)),
}
ATTACK_EFFECTS["sv9-111"] = {  # Hop's Zacian ex
    "Insta-Strike": (DealDamage(30), DealBonusDamageToChosenOpponentBench(30)),
    "Brave Slash": (DealDamage(240), LockOwnAttackNextTurn("Brave Slash")),
}
for _alias_id in ("sv9-176", "sv9-186", "svp-193"):
    ATTACK_EFFECTS[_alias_id] = ATTACK_EFFECTS["sv9-111"]  # Hop's Zacian ex 別絵柄
ATTACK_EFFECTS["sv9-112"] = {"Bite": (DealDamage(10),), "Reckless Charge": (DealDamage(50), SelfDamage(10))}  # Bagon
ATTACK_EFFECTS["sv9-113"] = {  # Shelgon
    "Guard Press": (DealDamage(30), ApplyDamageReductionToSelf(30)),
    "Heavy Impact": (DealDamage(80),),
}
ATTACK_EFFECTS["sv9-114"] = {  # Salamence ex
    "Wide Blast": (DealFixedDamageToAllOpponentBenchedPokemon(50),),
    "Dragon Impact": (DealDamage(300), DiscardOwnEnergy(count=2)),
}
for _alias_id in ("sv9-177", "sv9-187"):
    ATTACK_EFFECTS[_alias_id] = ATTACK_EFFECTS["sv9-114"]  # Salamence ex 別絵柄
ATTACK_EFFECTS["sv9-115"] = {  # Druddigon
    "Dragon's Fury": (AttachEnergyFromDiscardToOwnPokemon(energy_type="Fire", count=1, self_only=False, target_type="Dragon"),),
    "Slashing Claw": (DealDamage(120),),
}
ATTACK_EFFECTS["sv9-117"] = {"Dynamic Press": (DealDamage(140), SelfDamage(80))}  # Hop's Snorlax(特性
# 「Extra Helpings」はeffects.primitives._NAMED_PREFIX_TEAM_ATTACK_BONUS_ABILITY_IDS経由で実装済み)
ATTACK_EFFECTS["svp-184"] = ATTACK_EFFECTS["sv9-117"]  # Hop's Snorlax 別絵柄
ATTACK_EFFECTS["sv9-118"] = {"Smack": (DealDamage(20),)}  # Sentret
ATTACK_EFFECTS["sv9-119"] = {"Scratch": (DealDamage(40),), "Jet Headbutt": (DealDamage(70),)}  # Furret
ATTACK_EFFECTS["sv9-168"] = ATTACK_EFFECTS["sv9-119"]  # Furret 別絵柄
ATTACK_EFFECTS["sv9-12"] = {  # Shelmet
    "Shell Smack": (DealDamage(20), FlipCoinThen(heads=(ApplyScopedDamageImmunityToSelf(scope="all"),))),
}
ATTACK_EFFECTS["sv9-127"] = {"Rapid Draw": (DealDamage(10), Draw(1))}  # Noibat
ATTACK_EFFECTS["sv9-169"] = ATTACK_EFFECTS["sv9-127"]  # Noibat 別絵柄
ATTACK_EFFECTS["sv9-128"] = {"Frightening Howl": (DealDamage(110), InflictStatusOnDefender(condition="confused"))}  # Noivern(特性
# 「Tuning Echo」は手札枚数が同数ならコスト無視という新規のコスト計算機構が必要なため見送り)
# Komala(sv9-129)「Slumbering Smack」はおたがいのバトルポケモンをねむり状態にし、次の自分の番に
# 遅延ボーナスダメージが発生するという新規機構が必要なため見送り(唯一のワザのため、このカードには
# ATTACK_EFFECTSを登録しない)
ATTACK_EFFECTS["sv9-13"] = {  # Accelgor
    "Poisonous Ploy": (
        DealDamage(70),
        InflictStatusOnDefender(condition="confused"),
        InflictStatusOnDefender(condition="poisoned"),
        SwitchActiveWithBench(),
    ),
}
ATTACK_EFFECTS["sv9-133"] = {  # Hop's Rookidee
    "Intimidating Stare": (DebuffDefenderAttackDamageNextTurn(amount=20),),
    "Peck": (DealDamage(20),),
}
ATTACK_EFFECTS["sv9-134"] = {"Speed Dive": (DealDamage(30),), "Razor Wing": (DealDamage(80),)}  # Hop's Corvisquire
ATTACK_EFFECTS["sv9-135"] = {"Smash Kick": (DealDamage(50),)}  # Hop's Wooloo
ATTACK_EFFECTS["sv9-170"] = ATTACK_EFFECTS["sv9-135"]  # Hop's Wooloo 別絵柄
ATTACK_EFFECTS["sv9-136"] = {"Headbutt": (DealDamage(80),)}  # Hop's Dubwool
EVOLVE_TRIGGER_EFFECTS["sv9-136"] = (ForceOpponentSwitchChosenBench(),)  # 特性「Defiant Horn」
TRAINER_EFFECTS["sv9-147"] = (SearchDeckForNamePrefixBasicPokemonToBench(name_prefix="Hop's", count=2),)  # Hop's Bag
TRAINER_EFFECTS["sv9-156"] = (ReshuffleTakenPrizesAndRedraw(),)  # Redeemable Ticket
TRAINER_EFFECTS["sv9-157"] = (DiscardChosenOpponentToolAndSpecialEnergy(),)  # Ruffian
TRAINER_EFFECTS["sv9-181"] = TRAINER_EFFECTS["sv9-157"]  # Ruffian 別絵柄
TRAINER_EFFECTS["sv9-158"] = (HealTargetThenDiscardEnergyIfHealed(amount=60),)  # Super Potion
ATTACK_EFFECTS["sv9-16"] = {"Tons of Treading": (DealDamagePerHeads(coin_count=3, damage_per_heads=10),)}  # Sprigatito
ATTACK_EFFECTS["sv9-160"] = {"Corner": (DealDamage(20), DisableDefenderRetreatNextTurn())}  # Maractus(特性
# 「Exploding Needles」はバトル場のこのポケモンがきぜつしたときのみ発動する新規トリガー機構が
# 必要なため見送り)
ATTACK_EFFECTS["sv9-8"] = ATTACK_EFFECTS["sv9-160"]  # Maractus 別絵柄
ATTACK_EFFECTS["sv9-161"] = {  # Articuno
    "Frigid Fluttering": (SearchDeckForBasicEnergyAttachToTarget(count=2, energy_type="Water", self_only=True),),
    "Ice Blast": (DealDamage(110),),
}
ATTACK_EFFECTS["sv9-32"] = ATTACK_EFFECTS["sv9-161"]  # Articuno 別絵柄
ATTACK_EFFECTS["sv9-162"] = {"Hydro Pump": (DamagePerSelfEnergyOfType(base=10, per_energy=50, energy_type="Water"),)}  # Wailord
ATTACK_EFFECTS["sv9-41"] = ATTACK_EFFECTS["sv9-162"]  # Wailord 別絵柄
ATTACK_EFFECTS["sv9-164"] = {"Magical Shot": (DealDamage(50),)}  # Lillie's Ribombee(特性「Inviting Wink」は
# 相手の手札を公開させ、見つけた基本ポケモンを任意の数だけ相手のベンチに出させるという新規機構が
# 必要なため見送り)
for _alias_id in ("sv9-67", "svp-183"):
    ATTACK_EFFECTS[_alias_id] = ATTACK_EFFECTS["sv9-164"]  # Lillie's Ribombee 別絵柄
ATTACK_EFFECTS["sv9-165"] = {  # Swinub
    "Call for Family": (SearchDeckForBasicPokemonToBench(count=2),),
    "Lunge Out": (DealDamage(10),),
}
ATTACK_EFFECTS["sv9-77"] = ATTACK_EFFECTS["sv9-165"]  # Swinub 別絵柄
ATTACK_EFFECTS["sv9-166"] = {"Clamping Fangs": (DamagePerDefenderDamageCounters(base=40, per_counter=40),)}  # Lycanroc(特性
# 「Spike-Clad」はトラッシュから「とげとげエネルギー」を名指しで選んでつけるという新規機構が
# 必要なため見送り)
ATTACK_EFFECTS["sv9-85"] = ATTACK_EFFECTS["sv9-166"]  # Lycanroc 別絵柄
ATTACK_EFFECTS["sv9-17"] = {"Magical Leaf": (FlipCoinThen(heads=(DealDamage(60), HealSelf(30)), tails=(DealDamage(30),)),)}  # Floragato
ATTACK_EFFECTS["sv9-171"] = {  # Volcanion ex
    "Scorching Cyclone": (DealDamage(160), MoveEnergyBetweenOwnPokemon(count=1)),
}
ABILITY_EFFECTS["sv9-171"] = {"Scalding Steam": (InflictStatusOnDefender(condition="burned"),)}
for _alias_id in ("sv9-182", "sv9-31"):
    ATTACK_EFFECTS[_alias_id] = ATTACK_EFFECTS["sv9-171"]  # Volcanion ex 別絵柄
    ABILITY_EFFECTS[_alias_id] = ABILITY_EFFECTS["sv9-171"]
ATTACK_EFFECTS["sv9-174"] = {  # Mamoswine ex
    "Rumbling March": (DamagePerOwnBenchedSubtypeCount(base=180, per_pokemon=40, subtype="Stage 2"),),
}
ABILITY_EFFECTS["sv9-174"] = {"Mammoth Hauler": (SearchDeckByCriterionToHand(criterion="any_pokemon", count=1),)}
ATTACK_EFFECTS["sv9-79"] = ATTACK_EFFECTS["sv9-174"]  # Mamoswine ex 別絵柄
ABILITY_EFFECTS["sv9-79"] = ABILITY_EFFECTS["sv9-174"]
ATTACK_EFFECTS["sv9-178"] = ATTACK_EFFECTS["sv9-121"]  # Dudunsparce ex(sv9-121と完全同一テキストの
# 別収録、novel_groupsの自動判定漏れを個別に発見)

# ---- Iレギュレーション新規カード実装 第11バッチ ----
TRAINER_EFFECTS["sv9-179"] = (SearchDeckUpToTwoBasicOrOneEvolutionToHand(),)  # Brock's Scouting
ATTACK_EFFECTS["sv9-18"] = {"Rising Bloom": (BonusDamageIfDefenderHasSubtype(base=90, bonus=90, subtype="ex"),)}  # Meowscarada
ABILITY_EFFECTS["sv9-18"] = {"Showtime": (SwitchSelfFromBenchToActive(),)}
ATTACK_EFFECTS["sv9-2"] = {}  # Metapod(ワザ「Harden」は「60以下のダメージのみ防ぐ」という閾値付き
# シールドの新規機構が必要なため見送り。唯一のワザのため空辞書のまま)
ATTACK_EFFECTS["sv9-20"] = {  # Magmar
    "Searing Flame": (DealDamage(30), FlipCoinThen(heads=(InflictStatusOnDefender(condition="burned"),))),
}
ATTACK_EFFECTS["sv9-21"] = {  # Magmortar(特性「Magma Surge」はチェックアップ時に発動する新規
    # トリガー機構が必要なため見送り)
    "Searing Flame": (DealDamage(90), FlipCoinThen(heads=(InflictStatusOnDefender(condition="burned"),))),
}
ATTACK_EFFECTS["sv9-3"] = {  # Butterfree
    "Scale Hurricane": (
        FlipMultipleCoinsForBonusDamageThenStatusIfAnyHeads(count=4, per_heads=60, condition="paralyzed", min_heads=2),
    ),
}
ATTACK_EFFECTS["sv9-33"] = {"Flail": (DamagePerSelfDamageCounters(per_counter=10),), "Rain Splash": (DealDamage(20),)}  # Remoraid
ATTACK_EFFECTS["sv9-34"] = {  # Octillery
    "Aqua Wash": (DealDamage(20), MoveDefenderEnergyToOpponentHand()),
    "Octo Beatdown": (DealDamageFlipUntilTailsBonus(base=0, bonus_per_heads=90),),
}
ATTACK_EFFECTS["sv9-36"] = {"Aqua Slash": (DealDamage(70), LockOwnAttackNextTurn("Aqua Slash", lock_all_attacks=True))}  # Lombre
ATTACK_EFFECTS["sv9-37"] = {"Hydro Splash": (DealDamage(130),)}  # Ludicolo(特性「Vibrant Dance」は
# 自分の場の全ポケモンのHP上限を+40する常時効果という新規のHP計算機構が必要なため見送り)
ATTACK_EFFECTS["sv9-4"] = {"Leech Life": (DealDamage(10), HealSelfEqualToDamageDealt())}  # Paras
ATTACK_EFFECTS["sv9-40"] = {"Surf": (DealDamage(60),)}  # Wailmer
ATTACK_EFFECTS["sv9-47"] = {  # Iono's Voltorb
    "Voltaic Chain": (DamagePerNamePrefixBoardEnergyCount(base=20, per_energy=20, energy_type="Lightning", name_prefix="Iono's"),),
}
ATTACK_EFFECTS["sv9-48"] = {  # Iono's Electrode
    "Thump-Thump Boom": (SelfDamage(100), FlipCoinThen(heads=(KnockOutOpponentActive(),))),
    "Electric Ball": (DealDamage(100),),
}
ATTACK_EFFECTS["sv9-49"] = {"Zapping Short": (DealDamage(30), DiscardDefenderToolThenParalyzeIfDiscarded())}  # N's Joltik
ATTACK_EFFECTS["sv9-5"] = {  # Parasect
    "Spore": (InflictStatusOnDefender(condition="asleep"),),
    "Scissor Swing": (DealDamagePerHeads(coin_count=2, damage_per_heads=30, base=60),),
}
ATTACK_EFFECTS["sv9-58"] = {  # Mr. Mime
    "Mimic": (ShuffleHandThenDrawEqualToOpponentHandSize(),),
    "Psy Bolt": (DealDamage(40), FlipCoinThen(heads=(InflictStatusOnDefender(condition="paralyzed"),))),
}
ATTACK_EFFECTS["sv9-61"] = {"Spinning Attack": (DealDamage(10),), "Beam": (DealDamage(30),)}  # Beldum
ATTACK_EFFECTS["sv9-62"] = {"Psypunch": (DealDamage(30),), "Zen Headbutt": (DealDamage(50),)}  # Metang
ATTACK_EFFECTS["sv9-63"] = {  # Metagross
    "Wrack Down": (DealDamage(60),),
    "Conjoined Beams": (BonusDamageIfTwoNamedPokemonOnBench(base=130, bonus=150, name_a="Beldum", name_b="Metang"),),
}
ATTACK_EFFECTS["sv9-64"] = {  # N's Sigilyph
    "Psychic Sphere": (DealDamage(20),),
    "Victory Symbol": (WinGameIfExactlyOnePrizeRemaining(),),
}
ATTACK_EFFECTS["sv9-66"] = {"Hold Still": (HealSelf(10),)}  # Lillie's Cutiefly
ATTACK_EFFECTS["sv9-68"] = {  # Lillie's Comfey
    "Inviting Flowers": (SearchDeckForNamePrefixBasicPokemonToBench(name_prefix="Lillie's", count=99),),
    "Fade Out": (DealDamage(30), ReturnSelfToHandUnconditional()),
}
ATTACK_EFFECTS["sv9-78"] = {"Strength": (DealDamage(20),), "Impaling Tusk": (DealDamage(50),)}  # Piloswine
ATTACK_EFFECTS["sv9-80"] = {"Crunch": (DealDamage(20), FlipCoinThen(heads=(DiscardOpponentActiveEnergy(),)))}  # Larvitar
ATTACK_EFFECTS["sv9-81"] = {"Take Down": (DealDamage(60), SelfDamage(20))}  # Pupitar
ATTACK_EFFECTS["sv9-82"] = {"Breaching Lariat": (DealDamageIgnoringResistanceOnly(120),)}  # Regirock(特性
# 「Rock Armor」はeffects.primitives._SELF_ENERGY_CONDITIONAL_DAMAGE_REDUCTION_IDS経由で実装済み)
ATTACK_EFFECTS["sv9-83"] = {"Corkscrew Punch": (DealDamage(10),), "Focus Fist": (FlipCoinThen(heads=(DealDamage(50),)),)}  # Pancham
ATTACK_EFFECTS["sv9-84"] = {"Dig It Up": (LookTopCardMayDiscard(),), "Stampede": (DealDamage(20),)}  # Rockruff
ATTACK_EFFECTS["sv9-86"] = {  # Hop's Silicobra
    "Turf Maker": (SearchDeckByCriterionToHand(criterion="stadium", count=1),),
    "Gnaw": (DealDamage(20),),
}
ATTACK_EFFECTS["sv9-87"] = {  # Hop's Sandaconda
    "Rumble": (DealDamage(30), DisableDefenderRetreatNextTurn()),
    "Break Ground": (DealDamage(140), DealFixedDamageToAllOwnBenchedPokemon(20)),
}
ATTACK_EFFECTS["sv9-9"] = {"Push Down": (ForceOpponentSwitchOpponentChooses(),)}  # Karrablast
ATTACK_EFFECTS["sv9-90"] = {  # Klawf
    "Snipping Pincers": (DiscardDefenderEnergyPerHeads(coin_count=2),),
    "Hammer In": (DealDamage(100),),
}
ATTACK_EFFECTS["sv9-91"] = {"Tackle": (DealDamage(10),), "Suffocating Gas": (DealDamage(20),)}  # Koffing
ATTACK_EFFECTS["sv9-92"] = {  # Weezing
    "Pervasive Gas": (DealDamage(30), InflictStatusOnDefender(condition="confused")),
    "Crazy Blast": (DamageIfSelfSameAttackUsedLastOwnTurn(base=50, bonus=120, attack_name="Pervasive Gas"),),
}
ATTACK_EFFECTS["sv9-95"] = {"Cracking Stomp": (DealDamage(150), DiscardTopOfOpponentDeck(2))}  # Tyranitar(特性
# 「Daunting Gaze」はengine.continuous.items_blocked_by_active_trevenant経由で実装済み)
ATTACK_EFFECTS["sv9-96"] = {"Thieving Swipe": (DealDamage(30), RevealOpponentHandThenChosenToBottomOfDeck())}  # N's Purrloin
ATTACK_EFFECTS["sv9-99"] = {  # Pangoro
    "Torment": (DealDamage(30), LockChosenOpponentAttackNextTurn()),
    "Power Tackle": (DealDamage(160), LockOwnAttackNextTurn("Power Tackle", lock_all_attacks=True)),
}

# ---- Iレギュレーション新規カード実装 第12バッチ(zsv10pt5セット) ----
ATTACK_EFFECTS["zsv10pt5-1"] = {"Tackle": (DealDamage(10),), "Vine Whip": (DealDamage(30),)}  # Snivy
ATTACK_EFFECTS["zsv10pt5-10"] = {"Toxic Spore": (InflictStatusOnDefender(condition="poisoned"),)}  # Foongus
ATTACK_EFFECTS["zsv10pt5-100"] = {"Fire Wing": (DealDamage(70),)}  # Volcarona(特性「Torrid Scales」は
# 手札からエネルギーを捨てることを発動コストとする新規のコスト支払い機構が必要なため見送り)
ATTACK_EFFECTS["zsv10pt5-103"] = {"Round": (DamagePerOwnPokemonWithNamedAttackInPlay(per_pokemon=20, attack_name="Round"),)}  # Tympole
ATTACK_EFFECTS["zsv10pt5-104"] = {  # Palpitoad
    "Round": (DamagePerOwnPokemonWithNamedAttackInPlay(per_pokemon=40, attack_name="Round"),),
    "Wave Splash": (DealDamage(60),),
}
ATTACK_EFFECTS["zsv10pt5-105"] = {  # Seismitoad
    "Round": (DamagePerOwnPokemonWithNamedAttackInPlay(per_pokemon=70, attack_name="Round"),),
    "Hyper Voice": (DealDamage(160),),
}
ATTACK_EFFECTS["zsv10pt5-106"] = {  # Tirtouga
    "Ancient Seaweed": (DamagePerOpponentDiscardItemCount(per_item=30),),
    "Surf": (DealDamage(80),),
}
ATTACK_EFFECTS["zsv10pt5-107"] = {"Big Bite": (DealDamage(150), DisableDefenderRetreatNextTurn())}  # Carracosta(特性
# 「Mighty Shell」は相手ポケモンが特殊エネルギーを持つかどうかで判定する新規免疫スコープが必要なため見送り)
ATTACK_EFFECTS["zsv10pt5-108"] = {"Waterfall": (DealDamage(70),)}  # Alomomola(特性「Gentle Fin」は自分の
# トラッシュからHP条件付きでポケモンをベンチに戻すという新規機構が必要なため見送り)
ATTACK_EFFECTS["zsv10pt5-109"] = {"Snotted Up": (DealDamage(10), DisableDefenderAttackNextTurn())}  # Cubchoo
ATTACK_EFFECTS["zsv10pt5-11"] = {  # Amoonguss
    "Dangerous Reaction": (BonusDamageIfDefenderHasSpecialCondition(base=30, bonus=120),),
    "Seed Bomb": (DealDamage(60),),
}
ATTACK_EFFECTS["zsv10pt5-110"] = {  # Beartic
    "Continuous Headbutt": (DealDamageFlipUntilTailsBonus(base=0, bonus_per_heads=50),),
    "Sheer Cold": (DealDamage(150), DisableDefenderAttackNextTurn()),
}
ATTACK_EFFECTS["zsv10pt5-111"] = {  # Cryogonal
    "Drag Off": (ForceOpponentSwitchChosenBench(), DealDamage(20)),
    "Icicle": (DealDamage(30),),
}
ATTACK_EFFECTS["zsv10pt5-112"] = {  # Emolga
    "Call for Family": (SearchDeckForBasicPokemonToBench(count=2),),
    "Static Shock": (DealDamage(20),),
}
ATTACK_EFFECTS["zsv10pt5-115"] = {  # Eelektross
    "Thunder Fang": (DealDamage(60), FlipCoinThen(heads=(InflictStatusOnDefender(condition="paralyzed"),))),
    "Buzz Flip": (DealDamagePerHeads(coin_count=4, damage_per_heads=100),),
}
ATTACK_EFFECTS["zsv10pt5-116"] = {  # Munna
    "Rest": (InflictStatusOnSelf(condition="asleep"), HealSelf(30)),
    "Mumble": (DealDamage(10),),
}
ATTACK_EFFECTS["zsv10pt5-117"] = {  # Musharna
    "Dream Calling": (SearchDeckByCriterionToHand(criterion="stadium", count=99),),  # v1近似: 本来はFennel名指し検索だが、
    # 名前指定の検索は既存のSearchDeckForNamePrefixPokemonToHand等ポケモン専用のためトレーナーには使えず、
    # 唯一の近いスタジアム検索で代替せず、実際にはFennel(サポート)の複数枚検索が必要なため見送りに変更
    "Sleep Pulse": (DealDamage(50), InflictStatusOnDefender(condition="asleep")),
}
ATTACK_EFFECTS["zsv10pt5-118"] = {"Rollout": (DealDamage(10),)}  # Solosis
ATTACK_EFFECTS["zsv10pt5-119"] = {"Spray Fluid": (DealDamage(30),)}  # Duosion(ワザ「Cellular Evolution」は
# 手札を経由せず山札から直接進化させる既存のInstantEvolveSelfFromDeckと同じ発想だが、対象が自分自身固定の
# 前者と異なりこちらは対象選択が必要なため、既存クラスの単純流用では不正確。今回は見送り)
ATTACK_EFFECTS["zsv10pt5-120"] = {"Slight Shift": (MoveEnergyOnOpponentSide(),), "Beam": (DealDamage(40),)}  # Elgyem
ATTACK_EFFECTS["zsv10pt5-121"] = {  # Beheeyem
    "Calm Mind": (HealSelf(40),),
    "Psychic": (DamagePerDefenderEnergyCount(base=80, per_energy=30),),
}
ATTACK_EFFECTS["zsv10pt5-122"] = {"Best Punch": (FlipCoinThen(heads=(DealDamage(60),)),)}  # Golett
ATTACK_EFFECTS["zsv10pt5-123"] = {  # Golurk
    "Double Smash": (DealDamagePerHeads(coin_count=2, damage_per_heads=80),),
    "Golurk Hammer": (DealDamage(200),),
}
ATTACK_EFFECTS["zsv10pt5-124"] = {"Mud-Slap": (DealDamage(10),), "Corkscrew Punch": (DealDamage(30),)}  # Drilbur
ATTACK_EFFECTS["zsv10pt5-125"] = {"Low Kick": (DealDamage(10),), "Strength": (DealDamage(50),)}  # Timburr
ATTACK_EFFECTS["zsv10pt5-126"] = {  # Gurdurr
    "Low Kick": (DealDamage(30),),
    "Hammer Arm": (DealDamage(60), DiscardTopOfOpponentDeck(1)),
}
ATTACK_EFFECTS["zsv10pt5-127"] = {"Swing Around": (DealDamagePerHeads(coin_count=2, damage_per_heads=50, base=100),)}  # Conkeldurr(特性
# 「Craftsmanship」は闘エネルギーの数に応じたHP上限増加という新規のHP計算機構が必要なため見送り)
ATTACK_EFFECTS["zsv10pt5-128"] = {"Shoulder Throw": (DamageReducedByDefenderRetreatCostColorless(base=120, per_colorless=30),)}  # Throh
ATTACK_EFFECTS["zsv10pt5-129"] = ATTACK_EFFECTS["zsv10pt5-51"]  # Dwebble(zsv10pt5-51と完全同一テキストの
# 別収録、novel_groupsの自動判定漏れを個別に発見)
ATTACK_EFFECTS["zsv10pt5-13"] = {"Will-O-Wisp": (DealDamage(30),)}  # Darumaka
ATTACK_EFFECTS["zsv10pt5-130"] = ATTACK_EFFECTS["zsv10pt5-52"]  # Crustle(zsv10pt5-52と完全同一テキストの
# 別収録、novel_groupsの自動判定漏れを個別に発見。特性「Sturdy」も同一のため下で
# _SURVIVE_LETHAL_HIT_AT_FULL_HP_ABILITY_IDSに追加する)
ATTACK_EFFECTS["zsv10pt5-131"] = {  # Landorus
    "Abundant Harvest": (AttachEnergyFromDiscardToOwnPokemon(energy_type="Fighting", count=1, self_only=True),),
    "Earthquake": (DealDamage(110), DealFixedDamageToAllOwnBenchedPokemon(10)),
}
ATTACK_EFFECTS["zsv10pt5-132"] = {"Poison Spray": (InflictStatusOnDefender(condition="poisoned"),)}  # Venipede
ATTACK_EFFECTS["zsv10pt5-133"] = {"Venoshock": (DamageIfDefenderPoisoned(base=30, bonus=60),)}  # Whirlipede
ATTACK_EFFECTS["zsv10pt5-134"] = {"Venoshock": (DamageIfDefenderPoisoned(base=90, bonus=90),)}  # Scolipede(特性
# 「Poison Point」はeffects.primitives._ON_DAMAGED_WHILE_ACTIVE_RETALIATE_STATUS_ABILITY_IDS経由で実装済み)
ATTACK_EFFECTS["zsv10pt5-135"] = {"Tighten Up": (DealDamage(10), OpponentDiscardExactlyFromHand(count=1))}  # Sandile
ATTACK_EFFECTS["zsv10pt5-136"] = {"Tighten Up": (DealDamage(40), OpponentDiscardExactlyFromHand(count=2))}  # Krokorok
ATTACK_EFFECTS["zsv10pt5-137"] = {  # Krookodile
    "Tighten Up": (DealDamage(60), OpponentDiscardExactlyFromHand(count=2)),
    "Cursed Slug": (BonusDamageIfOpponentHandCountAtMost(base=120, bonus=120, threshold=3),),
}
ATTACK_EFFECTS["zsv10pt5-138"] = {"Wild Lances": (DealDamage(90), SelfDamage(30))}  # Escavalier
ATTACK_EFFECTS["zsv10pt5-139"] = {"Hard Gears": (DealDamage(10), ApplyDamageReductionToSelf(10))}  # Klink
ATTACK_EFFECTS["zsv10pt5-14"] = {  # Darmanitan
    "Searing Flame": (DealDamage(50), InflictStatusOnDefender(condition="burned")),
    "Smashing Headbutt": (DealDamage(180), DiscardOwnEnergy(count=2)),
}
ATTACK_EFFECTS["zsv10pt5-140"] = {"Hard Gears": (DealDamage(50), ApplyDamageReductionToSelf(20))}  # Klang
ATTACK_EFFECTS["zsv10pt5-141"] = {"Hammer In": (DealDamage(120),)}  # Klinklang(特性「Gear Coating」は
# effects.primitives._ENERGY_TYPE_CONDITIONAL_TEAM_DEFENSE_REDUCTION_ABILITY_IDS経由で実装済み)
ATTACK_EFFECTS["zsv10pt5-142"] = {"Corner": (DealDamage(10), DisableDefenderRetreatNextTurn())}  # Pawniard
ATTACK_EFFECTS["zsv10pt5-143"] = {  # Bisharp
    "Cut Up": (DealDamage(40),),
    "Finishing Blow": (BonusDamageIfDefenderAlreadyDamaged(base=60, bonus=60),),
}
ATTACK_EFFECTS["zsv10pt5-144"] = {  # Cobalion
    "Righteous Edge": (DealDamage(20), DiscardOpponentActiveSpecialEnergy()),
    "Metal Arms": (BonusDamageIfSelfHasToolAttached(base=80, bonus=40),),
}
ATTACK_EFFECTS["zsv10pt5-145"] = {"Gather Strength": (SearchDeckForBasicEnergyToHand(count=2),)}  # Axew
ATTACK_EFFECTS["zsv10pt5-146"] = {  # Fraxure
    "Bite": (DealDamage(30),),
    "Boundless Power": (DealDamage(90), LockOwnAttackNextTurn("Boundless Power", lock_all_attacks=True)),
}
ATTACK_EFFECTS["zsv10pt5-147"] = {  # Haxorus
    "Cross-Cut": (BonusDamageIfDefenderIsEvolved(base=80, bonus=80),),
    "Axe Blast": (KnockOutDefenderIfBasic(),),
}
ATTACK_EFFECTS["zsv10pt5-148"] = {"Scout": (RevealOpponentHandOnly(),), "Stampede": (DealDamage(10),)}  # Pidove
ATTACK_EFFECTS["zsv10pt5-149"] = {"Fly": (FlipCoinThen(heads=(DealDamage(40), ApplyShieldToSelf()),),)}  # Tranquill
ATTACK_EFFECTS["zsv10pt5-15"] = {"Peck Off": (DiscardDefenderTool(), DealDamage(10))}  # Larvesta
ATTACK_EFFECTS["zsv10pt5-150"] = {  # Unfezant
    "Add On": (Draw(4),),
    "Swift Flight": (DealDamage(120), FlipCoinThen(heads=(ApplyShieldToSelf(),))),
}
ATTACK_EFFECTS["zsv10pt5-151"] = {"Return": (DealDamage(30), DrawUpTo(6))}  # Audino
ATTACK_EFFECTS["zsv10pt5-152"] = {"Tail Slap": (DealDamagePerHeads(coin_count=2, damage_per_heads=20),)}  # Minccino
ATTACK_EFFECTS["zsv10pt5-153"] = {"Do the Wave": (DamagePerOwnBenchedPokemonCount(base=20, per_pokemon=20),)}  # Cinccino
ATTACK_EFFECTS["zsv10pt5-154"] = {"Peck": (DealDamage(10),), "Glide": (DealDamage(20),)}  # Rufflet
ATTACK_EFFECTS["zsv10pt5-155"] = {  # Braviary
    "Aerial Ace": (DealDamagePerHeads(coin_count=1, damage_per_heads=40, base=40),),
    "Speed Wing": (DealDamage(130),),
}
ATTACK_EFFECTS["zsv10pt5-156"] = {"Command the Grass": (DealDamage(150), SearchDeckAnyCardToHand(count=3))}  # Serperior ex
ABILITY_EFFECTS["zsv10pt5-156"] = {}  # 特性「Regal Cheer」はeffects.primitives._TEAM_WIDE_ATTACK_BONUS_ABILITY_IDS経由で実装済み
ATTACK_EFFECTS["zsv10pt5-157"] = {  # Kyurem ex
    "Slash": (DealDamage(50),),
    "Blizzard Burst": (DealDamage(130), DealFixedDamageToAllOpponentBenchedPokemonScaledByPrizesTaken(per_prize=10)),
}
ATTACK_EFFECTS["zsv10pt5-158"] = {  # Zekrom ex
    "Slash": (DealDamage(50),),
    "Voltage Burst": (DamagePerOpponentPrizesTaken(base=130, per_prize=50), SelfDamage(30)),
}
ATTACK_EFFECTS["zsv10pt5-159"] = {"Echoed Voice": (DealDamage(30),)}  # Meloetta ex(次の自分の番の
# Echoed Voice強化は新規の自己バフ持続機構、特性「Debut Performance」は先攻1ターン目の攻撃制限解除
# という新規機構がそれぞれ必要なため見送り)
ATTACK_EFFECTS["zsv10pt5-16"] = ATTACK_EFFECTS["zsv10pt5-100"]  # Volcarona 別絵柄(実は先に見つけた
# 方を代表として揃える必要は無いため、zsv10pt5-100側の内容をそのまま踏襲)
ATTACK_EFFECTS["zsv10pt5-160"] = {  # Excadrill ex
    "Piercing Drill": (DealDamage(60), DealBonusDamageToChosenOpponentBench(60, damaged_only=True)),
    "Rock Tumble": (DealDamageIgnoringResistanceOnly(200),),
}
ATTACK_EFFECTS["zsv10pt5-161"] = ATTACK_EFFECTS["zsv10pt5-67"]  # Genesect ex(zsv10pt5-67と完全同一
# テキストの別収録、novel_groupsの自動判定漏れを個別に発見)
ABILITY_EFFECTS["zsv10pt5-161"] = ABILITY_EFFECTS.get("zsv10pt5-67", {})
TRAINER_EFFECTS["zsv10pt5-162"] = (HealAllOwnPokemon(amount=40),)  # Fennel
TRAINER_EFFECTS["zsv10pt5-163"] = TRAINER_EFFECTS["zsv10pt5-83"]  # N's Plan(zsv10pt5-83と完全同一
# テキストの別収録、novel_groupsの自動判定漏れを個別に発見)
ATTACK_EFFECTS["zsv10pt5-2"] = {  # Servine
    "Wrap": (DealDamage(20), FlipCoinThen(heads=(InflictStatusOnDefender(condition="paralyzed"),))),
    "Vine Whip": (DealDamage(60),),
}
ATTACK_EFFECTS["zsv10pt5-33"] = {"Charge": (SearchDeckForBasicEnergyAttachToTarget(count=1, energy_type="Lightning", self_only=True),), "Disaster Volt": (DealDamage(110), DiscardOwnEnergy(count=1))}  # Thundurus
ATTACK_EFFECTS["zsv10pt5-39"] = {"Evo-Lariat": (DamagePerOwnEvolvedPokemonInPlay(base=40, per_pokemon=40),)}  # Reuniclus(ワザ
# 「Cellular Ascension」は自分のベンチポケモン全員をそれぞれ山札から進化させるという新規の複数対象
# 進化機構が必要なため見送り)
ATTACK_EFFECTS["zsv10pt5-6"] = {"Hide": (FlipCoinThen(heads=(ApplyShieldToSelf(),)),), "Leafage": (DealDamage(10),)}  # Petilil
ATTACK_EFFECTS["zsv10pt5-7"] = {  # Lilligant
    "Bemusing Aroma": (
        FlipCoinThen(
            heads=(InflictStatusOnDefender(condition="paralyzed"), InflictStatusOnDefender(condition="poisoned")),
            tails=(InflictStatusOnDefender(condition="confused"),),
        ),
    ),
    "Cut": (DealDamage(70),),
}
ATTACK_EFFECTS["zsv10pt5-8"] = {"Pierce": (DealDamage(50),)}  # Maractus(ワザ「Lively Needles」は「この番に
# 回復したことがある」という新規の当該ターン限定フラグ機構が必要なため見送り)
TRAINER_EFFECTS["zsv10pt5-81"] = (
    AllCoinsHeadsThen(count=2, then=(SearchDeckForBasicEnergyAttachToTarget(count=1, self_only=False),)),
)  # Energy Coin
TRAINER_EFFECTS["zsv10pt5-84"] = (LookTopNChooseByCriteriaToHand(n=7, m=1, criteria="supporter"),)  # Pokégear 3.0
ATTACK_EFFECTS["zsv10pt5-9"] = {"Horn Attack": (DealDamage(10),)}  # Karrablast(特性「Stimulated Evolution」は
# シェルミー(rsv10pt5-8)側でも見送った「自分の場にシェルミーがいれば早期進化可能」という新規の進化タイミング
# 例外機構が必要なため見送り)


# ==== HIJレギュレーション完全化(2026-09-01): 既存実装(同一テキストの別カードID)への一括エイリアス ====
# 名前・テキスト(・ワザはダメージ/コストも)が完全一致する、既に実装済みの別カードIDへの
# エイリアス登録。再録/別絵柄違い、または「Round」のように複数のポケモンで使い回される
# 同名ワザなど、内容が完全一致することを確認した上で登録している。

# ---- 特性 ----
ABILITY_EFFECTS.setdefault("zsv10pt5-169", {})["Metallic Signal"] = ABILITY_EFFECTS["zsv10pt5-67"]["Metallic Signal"]  # ゲノセクトEX(=ゲノセクトexと同一テキスト)

# ---- ワザ ----
ATTACK_EFFECTS.setdefault("zsv10pt5-53", {})["Abundant Harvest"] = ATTACK_EFFECTS["zsv10pt5-131"]["Abundant Harvest"]  # ランドロス(=ランドロスと同一テキスト)
ATTACK_EFFECTS.setdefault("zsv10pt5-73", {})["Add On"] = ATTACK_EFFECTS["zsv10pt5-150"]["Add On"]  # ケンホロウ(=ケンホロウと同一テキスト)
ATTACK_EFFECTS.setdefault("zsv10pt5-78", {})["Aerial Ace"] = ATTACK_EFFECTS["zsv10pt5-155"]["Aerial Ace"]  # ウォーグル(=ウォーグルと同一テキスト)
ATTACK_EFFECTS.setdefault("zsv10pt5-22", {})["Ancient Seaweed"] = ATTACK_EFFECTS["zsv10pt5-106"]["Ancient Seaweed"]  # プロトーガ(=プロトーガと同一テキスト)
ATTACK_EFFECTS.setdefault("zsv10pt5-70", {})["Axe Blast"] = ATTACK_EFFECTS["zsv10pt5-147"]["Axe Blast"]  # オノノクス(=オノノクスと同一テキスト)
ATTACK_EFFECTS.setdefault("zsv10pt5-40", {})["Beam"] = ATTACK_EFFECTS["zsv10pt5-120"]["Beam"]  # リグレー(=リグレーと同一テキスト)
ATTACK_EFFECTS.setdefault("zsv10pt5-92", {})["Bemusing Aroma"] = ATTACK_EFFECTS["zsv10pt5-7"]["Bemusing Aroma"]  # ドレディア(=ドレディアと同一テキスト)
ATTACK_EFFECTS.setdefault("zsv10pt5-42", {})["Best Punch"] = ATTACK_EFFECTS["zsv10pt5-122"]["Best Punch"]  # ゴビット(=ゴビットと同一テキスト)
ATTACK_EFFECTS.setdefault("zsv10pt5-23", {})["Big Bite"] = ATTACK_EFFECTS["zsv10pt5-107"]["Big Bite"]  # アバゴーラ(=アバゴーラと同一テキスト)
ATTACK_EFFECTS.setdefault("zsv10pt5-69", {})["Bite"] = ATTACK_EFFECTS["zsv10pt5-146"]["Bite"]  # オノンド(=オノンドと同一テキスト)
ATTACK_EFFECTS.setdefault("zsv10pt5-165", {})["Blizzard Burst"] = ATTACK_EFFECTS["zsv10pt5-157"]["Blizzard Burst"]  # キュレムex(=キュレムexと同一テキスト)
ATTACK_EFFECTS.setdefault("zsv10pt5-28", {})["Blizzard Burst"] = ATTACK_EFFECTS["zsv10pt5-157"]["Blizzard Burst"]  # キュレムex(=キュレムexと同一テキスト)
ATTACK_EFFECTS.setdefault("zsv10pt5-69", {})["Boundless Power"] = ATTACK_EFFECTS["zsv10pt5-146"]["Boundless Power"]  # オノンド(=オノンドと同一テキスト)
ATTACK_EFFECTS.setdefault("zsv10pt5-32", {})["Buzz Flip"] = ATTACK_EFFECTS["zsv10pt5-115"]["Buzz Flip"]  # シビルドン(=シビルドンと同一テキスト)
ATTACK_EFFECTS.setdefault("zsv10pt5-29", {})["Call for Family"] = ATTACK_EFFECTS["me2pt5-144"]["Call for Family"]  # エモンガ(=クチートと同一テキスト)
ATTACK_EFFECTS.setdefault("zsv10pt5-41", {})["Calm Mind"] = ATTACK_EFFECTS["zsv10pt5-121"]["Calm Mind"]  # オーベム(=オーベムと同一テキスト)
ATTACK_EFFECTS.setdefault("zsv10pt5-164", {})["Command the Grass"] = ATTACK_EFFECTS["zsv10pt5-156"]["Command the Grass"]  # ジャローダex(=ジャローダexと同一テキスト)
ATTACK_EFFECTS.setdefault("zsv10pt5-3", {})["Command the Grass"] = ATTACK_EFFECTS["zsv10pt5-156"]["Command the Grass"]  # ジャローダex(=ジャローダexと同一テキスト)
ATTACK_EFFECTS.setdefault("zsv10pt5-26", {})["Continuous Headbutt"] = ATTACK_EFFECTS["zsv10pt5-110"]["Continuous Headbutt"]  # ツンベアー(=ツンベアーと同一テキスト)
ATTACK_EFFECTS.setdefault("zsv10pt5-45", {})["Corkscrew Punch"] = ATTACK_EFFECTS["zsv10pt5-124"]["Corkscrew Punch"]  # モグリュー(=モグリューと同一テキスト)
ATTACK_EFFECTS.setdefault("zsv10pt5-64", {})["Corner"] = ATTACK_EFFECTS["zsv10pt5-142"]["Corner"]  # コマタナ(=コマタナと同一テキスト)
ATTACK_EFFECTS.setdefault("me1-75", {})["Cosmic Beam"] = ATTACK_EFFECTS["me2pt5-106"]["Cosmic Beam"]  # ソルロック(=ソルロックと同一テキスト)
ATTACK_EFFECTS.setdefault("zsv10pt5-70", {})["Cross-Cut"] = ATTACK_EFFECTS["zsv10pt5-147"]["Cross-Cut"]  # オノノクス(=オノノクスと同一テキスト)
ATTACK_EFFECTS.setdefault("zsv10pt5-59", {})["Cursed Slug"] = ATTACK_EFFECTS["zsv10pt5-137"]["Cursed Slug"]  # ワルビアル(=ワルビアルと同一テキスト)
ATTACK_EFFECTS.setdefault("zsv10pt5-92", {})["Cut"] = ATTACK_EFFECTS["zsv10pt5-7"]["Cut"]  # ドレディア(=ドレディアと同一テキスト)
ATTACK_EFFECTS.setdefault("zsv10pt5-65", {})["Cut Up"] = ATTACK_EFFECTS["zsv10pt5-143"]["Cut Up"]  # キリキザン(=キリキザンと同一テキスト)
ATTACK_EFFECTS.setdefault("zsv10pt5-96", {})["Dangerous Reaction"] = ATTACK_EFFECTS["zsv10pt5-11"]["Dangerous Reaction"]  # モロバレル(=モロバレルと同一テキスト)
ATTACK_EFFECTS.setdefault("zsv10pt5-76", {})["Do the Wave"] = ATTACK_EFFECTS["zsv10pt5-153"]["Do the Wave"]  # チラチーノ(=チラチーノと同一テキスト)
ATTACK_EFFECTS.setdefault("zsv10pt5-43", {})["Double Smash"] = ATTACK_EFFECTS["zsv10pt5-123"]["Double Smash"]  # ゴルーグ(=ゴルーグと同一テキスト)
ATTACK_EFFECTS.setdefault("zsv10pt5-27", {})["Drag Off"] = ATTACK_EFFECTS["zsv10pt5-111"]["Drag Off"]  # フリージオ(=フリージオと同一テキスト)
ATTACK_EFFECTS.setdefault("zsv10pt5-36", {})["Dream Calling"] = ATTACK_EFFECTS["zsv10pt5-117"]["Dream Calling"]  # ムシャーナ(=ムシャーナと同一テキスト)
ATTACK_EFFECTS.setdefault("zsv10pt5-53", {})["Earthquake"] = ATTACK_EFFECTS["zsv10pt5-131"]["Earthquake"]  # ランドロス(=ランドロスと同一テキスト)
ATTACK_EFFECTS.setdefault("zsv10pt5-167", {})["Echoed Voice"] = ATTACK_EFFECTS["zsv10pt5-159"]["Echoed Voice"]  # メロエッタex(=メロエッタexと同一テキスト)
ATTACK_EFFECTS.setdefault("zsv10pt5-44", {})["Echoed Voice"] = ATTACK_EFFECTS["zsv10pt5-159"]["Echoed Voice"]  # メロエッタex(=メロエッタexと同一テキスト)
ATTACK_EFFECTS.setdefault("zsv10pt5-65", {})["Finishing Blow"] = ATTACK_EFFECTS["zsv10pt5-143"]["Finishing Blow"]  # キリキザン(=キリキザンと同一テキスト)
ATTACK_EFFECTS.setdefault("zsv10pt5-72", {})["Fly"] = ATTACK_EFFECTS["zsv10pt5-149"]["Fly"]  # ハトーボー(=ハトーボーと同一テキスト)
ATTACK_EFFECTS.setdefault("zsv10pt5-68", {})["Gather Strength"] = ATTACK_EFFECTS["zsv10pt5-145"]["Gather Strength"]  # キバゴ(=キバゴと同一テキスト)
ATTACK_EFFECTS.setdefault("zsv10pt5-77", {})["Glide"] = ATTACK_EFFECTS["zsv10pt5-154"]["Glide"]  # ワシボン(=ワシボンと同一テキスト)
ATTACK_EFFECTS.setdefault("zsv10pt5-43", {})["Golurk Hammer"] = ATTACK_EFFECTS["zsv10pt5-123"]["Golurk Hammer"]  # ゴルーグ(=ゴルーグと同一テキスト)
ATTACK_EFFECTS.setdefault("zsv10pt5-48", {})["Hammer Arm"] = ATTACK_EFFECTS["zsv10pt5-126"]["Hammer Arm"]  # ドテッコツ(=ドテッコツと同一テキスト)
ATTACK_EFFECTS.setdefault("zsv10pt5-63", {})["Hammer In"] = ATTACK_EFFECTS["zsv10pt5-141"]["Hammer In"]  # ギギギアル(=ギギギアルと同一テキスト)
ATTACK_EFFECTS.setdefault("zsv10pt5-61", {})["Hard Gears"] = ATTACK_EFFECTS["zsv10pt5-139"]["Hard Gears"]  # ギアル(=ギアルと同一テキスト)
ATTACK_EFFECTS.setdefault("zsv10pt5-62", {})["Hard Gears"] = ATTACK_EFFECTS["zsv10pt5-140"]["Hard Gears"]  # ギギアル(=ギギアルと同一テキスト)
ATTACK_EFFECTS.setdefault("zsv10pt5-91", {})["Hide"] = ATTACK_EFFECTS["me2pt5-83"]["Hide"]  # チュリネ(=ルリリと同一テキスト)
ATTACK_EFFECTS.setdefault("zsv10pt5-94", {})["Horn Attack"] = ATTACK_EFFECTS["zsv10pt5-9"]["Horn Attack"]  # カブルモ(=カブルモと同一テキスト)
ATTACK_EFFECTS.setdefault("zsv10pt5-21", {})["Hyper Voice"] = ATTACK_EFFECTS["zsv10pt5-105"]["Hyper Voice"]  # ガマゲロゲ(=ガマゲロゲと同一テキスト)
ATTACK_EFFECTS.setdefault("zsv10pt5-27", {})["Icicle"] = ATTACK_EFFECTS["zsv10pt5-111"]["Icicle"]  # フリージオ(=フリージオと同一テキスト)
ATTACK_EFFECTS.setdefault("zsv10pt5-91", {})["Leafage"] = ATTACK_EFFECTS["zsv10pt5-6"]["Leafage"]  # チュリネ(=チュリネと同一テキスト)
ATTACK_EFFECTS.setdefault("zsv10pt5-47", {})["Low Kick"] = ATTACK_EFFECTS["zsv10pt5-125"]["Low Kick"]  # ドッコラー(=ドッコラーと同一テキスト)
ATTACK_EFFECTS.setdefault("zsv10pt5-48", {})["Low Kick"] = ATTACK_EFFECTS["zsv10pt5-126"]["Low Kick"]  # ドテッコツ(=ドテッコツと同一テキスト)
ATTACK_EFFECTS.setdefault("zsv10pt5-66", {})["Metal Arms"] = ATTACK_EFFECTS["zsv10pt5-144"]["Metal Arms"]  # コバルオン(=コバルオンと同一テキスト)
ATTACK_EFFECTS.setdefault("zsv10pt5-45", {})["Mud-Slap"] = ATTACK_EFFECTS["me4-44"]["Mud-Slap"]  # モグリュー(=ゴマゾウと同一テキスト)
ATTACK_EFFECTS.setdefault("zsv10pt5-35", {})["Mumble"] = ATTACK_EFFECTS["me4-38"]["Mumble"]  # ムンナ(=ボクレーと同一テキスト)
ATTACK_EFFECTS.setdefault("zsv10pt5-77", {})["Peck"] = ATTACK_EFFECTS["zsv10pt5-154"]["Peck"]  # ワシボン(=ワシボンと同一テキスト)
ATTACK_EFFECTS.setdefault("zsv10pt5-99", {})["Peck Off"] = ATTACK_EFFECTS["zsv10pt5-15"]["Peck Off"]  # メラルバ(=メラルバと同一テキスト)
ATTACK_EFFECTS.setdefault("zsv10pt5-93", {})["Pierce"] = ATTACK_EFFECTS["zsv10pt5-8"]["Pierce"]  # マラカッチ(=マラカッチと同一テキスト)
ATTACK_EFFECTS.setdefault("zsv10pt5-168", {})["Piercing Drill"] = ATTACK_EFFECTS["zsv10pt5-160"]["Piercing Drill"]  # ドリュウズex(=ドリュウズexと同一テキスト)
ATTACK_EFFECTS.setdefault("zsv10pt5-46", {})["Piercing Drill"] = ATTACK_EFFECTS["zsv10pt5-160"]["Piercing Drill"]  # ドリュウズex(=ドリュウズexと同一テキスト)
ATTACK_EFFECTS.setdefault("zsv10pt5-54", {})["Poison Spray"] = ATTACK_EFFECTS["zsv10pt5-132"]["Poison Spray"]  # フシデ(=フシデと同一テキスト)
ATTACK_EFFECTS.setdefault("zsv10pt5-169", {})["Protect Charge"] = ATTACK_EFFECTS["zsv10pt5-67"]["Protect Charge"]  # ゲノセクトEX(=ゲノセクトexと同一テキスト)
ATTACK_EFFECTS.setdefault("zsv10pt5-41", {})["Psychic"] = ATTACK_EFFECTS["zsv10pt5-121"]["Psychic"]  # オーベム(=オーベムと同一テキスト)
ATTACK_EFFECTS.setdefault("zsv10pt5-35", {})["Rest"] = ATTACK_EFFECTS["zsv10pt5-116"]["Rest"]  # ムンナ(=ムンナと同一テキスト)
ATTACK_EFFECTS.setdefault("zsv10pt5-74", {})["Return"] = ATTACK_EFFECTS["zsv10pt5-151"]["Return"]  # タブンネ(=タブンネと同一テキスト)
ATTACK_EFFECTS.setdefault("zsv10pt5-66", {})["Righteous Edge"] = ATTACK_EFFECTS["zsv10pt5-144"]["Righteous Edge"]  # コバルオン(=コバルオンと同一テキスト)
ATTACK_EFFECTS.setdefault("zsv10pt5-168", {})["Rock Tumble"] = ATTACK_EFFECTS["zsv10pt5-160"]["Rock Tumble"]  # ドリュウズex(=ドリュウズexと同一テキスト)
ATTACK_EFFECTS.setdefault("zsv10pt5-46", {})["Rock Tumble"] = ATTACK_EFFECTS["zsv10pt5-160"]["Rock Tumble"]  # ドリュウズex(=ドリュウズexと同一テキスト)
ATTACK_EFFECTS.setdefault("zsv10pt5-37", {})["Rollout"] = ATTACK_EFFECTS["zsv10pt5-118"]["Rollout"]  # ユニラン(=ユニランと同一テキスト)
ATTACK_EFFECTS.setdefault("zsv10pt5-19", {})["Round"] = ATTACK_EFFECTS["zsv10pt5-103"]["Round"]  # オタマロ(=オタマロと同一テキスト)
ATTACK_EFFECTS.setdefault("zsv10pt5-20", {})["Round"] = ATTACK_EFFECTS["zsv10pt5-104"]["Round"]  # ガマガル(=ガマガルと同一テキスト)
ATTACK_EFFECTS.setdefault("zsv10pt5-21", {})["Round"] = ATTACK_EFFECTS["zsv10pt5-105"]["Round"]  # ガマゲロゲ(=ガマゲロゲと同一テキスト)
ATTACK_EFFECTS.setdefault("zsv10pt5-71", {})["Scout"] = ATTACK_EFFECTS["zsv10pt5-148"]["Scout"]  # マメパト(=マメパトと同一テキスト)
ATTACK_EFFECTS.setdefault("zsv10pt5-98", {})["Searing Flame"] = ATTACK_EFFECTS["zsv10pt5-14"]["Searing Flame"]  # ヒヒダルマ(=ヒヒダルマと同一テキスト)
ATTACK_EFFECTS.setdefault("zsv10pt5-96", {})["Seed Bomb"] = ATTACK_EFFECTS["zsv10pt5-11"]["Seed Bomb"]  # モロバレル(=モロバレルと同一テキスト)
ATTACK_EFFECTS.setdefault("zsv10pt5-26", {})["Sheer Cold"] = ATTACK_EFFECTS["zsv10pt5-110"]["Sheer Cold"]  # ツンベアー(=ツンベアーと同一テキスト)
ATTACK_EFFECTS.setdefault("zsv10pt5-50", {})["Shoulder Throw"] = ATTACK_EFFECTS["zsv10pt5-128"]["Shoulder Throw"]  # ナゲキ(=ナゲキと同一テキスト)
ATTACK_EFFECTS.setdefault("zsv10pt5-165", {})["Slash"] = ATTACK_EFFECTS["rsv10pt5-20"]["Slash"]  # キュレムex(=レシラムexと同一テキスト)
ATTACK_EFFECTS.setdefault("zsv10pt5-166", {})["Slash"] = ATTACK_EFFECTS["rsv10pt5-20"]["Slash"]  # ゼクロムex(=レシラムexと同一テキスト)
ATTACK_EFFECTS.setdefault("zsv10pt5-172", {})["Slash"] = ATTACK_EFFECTS["rsv10pt5-20"]["Slash"]  # ゼクロムex(=レシラムexと同一テキスト)
ATTACK_EFFECTS.setdefault("zsv10pt5-28", {})["Slash"] = ATTACK_EFFECTS["rsv10pt5-20"]["Slash"]  # キュレムex(=レシラムexと同一テキスト)
ATTACK_EFFECTS.setdefault("zsv10pt5-34", {})["Slash"] = ATTACK_EFFECTS["rsv10pt5-20"]["Slash"]  # ゼクロムex(=レシラムexと同一テキスト)
ATTACK_EFFECTS.setdefault("zsv10pt5-36", {})["Sleep Pulse"] = ATTACK_EFFECTS["zsv10pt5-117"]["Sleep Pulse"]  # ムシャーナ(=ムシャーナと同一テキスト)
ATTACK_EFFECTS.setdefault("zsv10pt5-40", {})["Slight Shift"] = ATTACK_EFFECTS["zsv10pt5-120"]["Slight Shift"]  # リグレー(=リグレーと同一テキスト)
ATTACK_EFFECTS.setdefault("zsv10pt5-98", {})["Smashing Headbutt"] = ATTACK_EFFECTS["zsv10pt5-14"]["Smashing Headbutt"]  # ヒヒダルマ(=ヒヒダルマと同一テキスト)
ATTACK_EFFECTS.setdefault("zsv10pt5-25", {})["Snotted Up"] = ATTACK_EFFECTS["zsv10pt5-109"]["Snotted Up"]  # クマシュン(=クマシュンと同一テキスト)
ATTACK_EFFECTS.setdefault("zsv10pt5-78", {})["Speed Wing"] = ATTACK_EFFECTS["zsv10pt5-155"]["Speed Wing"]  # ウォーグル(=ウォーグルと同一テキスト)
ATTACK_EFFECTS.setdefault("zsv10pt5-38", {})["Spray Fluid"] = ATTACK_EFFECTS["zsv10pt5-119"]["Spray Fluid"]  # ダブラン(=ダブランと同一テキスト)
ATTACK_EFFECTS.setdefault("zsv10pt5-71", {})["Stampede"] = ATTACK_EFFECTS["sv10-138"]["Stampede"]  # マメパト(=ペパーのオラチフと同一テキスト)
ATTACK_EFFECTS.setdefault("zsv10pt5-29", {})["Static Shock"] = ATTACK_EFFECTS["zsv10pt5-112"]["Static Shock"]  # エモンガ(=エモンガと同一テキスト)
ATTACK_EFFECTS.setdefault("zsv10pt5-47", {})["Strength"] = ATTACK_EFFECTS["zsv10pt5-125"]["Strength"]  # ドッコラー(=ドッコラーと同一テキスト)
ATTACK_EFFECTS.setdefault("zsv10pt5-22", {})["Surf"] = ATTACK_EFFECTS["zsv10pt5-106"]["Surf"]  # プロトーガ(=プロトーガと同一テキスト)
ATTACK_EFFECTS.setdefault("zsv10pt5-73", {})["Swift Flight"] = ATTACK_EFFECTS["zsv10pt5-150"]["Swift Flight"]  # ケンホロウ(=ケンホロウと同一テキスト)
ATTACK_EFFECTS.setdefault("zsv10pt5-49", {})["Swing Around"] = ATTACK_EFFECTS["zsv10pt5-127"]["Swing Around"]  # ローブシン(=ローブシンと同一テキスト)
ATTACK_EFFECTS.setdefault("zsv10pt5-87", {})["Tackle"] = ATTACK_EFFECTS["zsv10pt5-1"]["Tackle"]  # ツタージャ(=ツタージャと同一テキスト)
ATTACK_EFFECTS.setdefault("zsv10pt5-75", {})["Tail Slap"] = ATTACK_EFFECTS["zsv10pt5-152"]["Tail Slap"]  # チラーミィ(=チラーミィと同一テキスト)
ATTACK_EFFECTS.setdefault("sv10-19", {})["Take Down"] = ATTACK_EFFECTS["me2pt5-18"]["Take Down"]  # ロケット団のタマンチュラ(=ロケット団のタマンチュラと同一テキスト)
ATTACK_EFFECTS.setdefault("me1-180", {})["Terminal Period"] = ATTACK_EFFECTS["me1-86"]["Terminal Period"]  # メガアブソルex(=メガアブソルexと同一テキスト)
ATTACK_EFFECTS.setdefault("zsv10pt5-32", {})["Thunder Fang"] = ATTACK_EFFECTS["zsv10pt5-115"]["Thunder Fang"]  # シビルドン(=シビルドンと同一テキスト)
ATTACK_EFFECTS.setdefault("zsv10pt5-57", {})["Tighten Up"] = ATTACK_EFFECTS["zsv10pt5-135"]["Tighten Up"]  # メグロコ(=メグロコと同一テキスト)
ATTACK_EFFECTS.setdefault("zsv10pt5-58", {})["Tighten Up"] = ATTACK_EFFECTS["zsv10pt5-136"]["Tighten Up"]  # ワルビル(=ワルビルと同一テキスト)
ATTACK_EFFECTS.setdefault("zsv10pt5-59", {})["Tighten Up"] = ATTACK_EFFECTS["zsv10pt5-137"]["Tighten Up"]  # ワルビアル(=ワルビアルと同一テキスト)
ATTACK_EFFECTS.setdefault("zsv10pt5-95", {})["Toxic Spore"] = ATTACK_EFFECTS["zsv10pt5-10"]["Toxic Spore"]  # タマゲタケ(=タマゲタケと同一テキスト)
ATTACK_EFFECTS.setdefault("me5-91", {})["Vengeful Anchor"] = ATTACK_EFFECTS["me5-39"]["Vengeful Anchor"]  # ダダリン(=ダダリンと同一テキスト)
ATTACK_EFFECTS.setdefault("zsv10pt5-55", {})["Venoshock"] = ATTACK_EFFECTS["zsv10pt5-133"]["Venoshock"]  # ホイーガ(=ホイーガと同一テキスト)
ATTACK_EFFECTS.setdefault("zsv10pt5-56", {})["Venoshock"] = ATTACK_EFFECTS["zsv10pt5-134"]["Venoshock"]  # ペンドラー(=ペンドラーと同一テキスト)
ATTACK_EFFECTS.setdefault("zsv10pt5-87", {})["Vine Whip"] = ATTACK_EFFECTS["zsv10pt5-1"]["Vine Whip"]  # ツタージャ(=ツタージャと同一テキスト)
ATTACK_EFFECTS.setdefault("zsv10pt5-88", {})["Vine Whip"] = ATTACK_EFFECTS["zsv10pt5-2"]["Vine Whip"]  # ジャノビー(=ジャノビーと同一テキスト)
ATTACK_EFFECTS.setdefault("zsv10pt5-166", {})["Voltage Burst"] = ATTACK_EFFECTS["zsv10pt5-158"]["Voltage Burst"]  # ゼクロムex(=ゼクロムexと同一テキスト)
ATTACK_EFFECTS.setdefault("zsv10pt5-172", {})["Voltage Burst"] = ATTACK_EFFECTS["zsv10pt5-158"]["Voltage Burst"]  # ゼクロムex(=ゼクロムexと同一テキスト)
ATTACK_EFFECTS.setdefault("zsv10pt5-34", {})["Voltage Burst"] = ATTACK_EFFECTS["zsv10pt5-158"]["Voltage Burst"]  # ゼクロムex(=ゼクロムexと同一テキスト)
ATTACK_EFFECTS.setdefault("zsv10pt5-24", {})["Waterfall"] = ATTACK_EFFECTS["zsv10pt5-108"]["Waterfall"]  # ママンボウ(=ママンボウと同一テキスト)
ATTACK_EFFECTS.setdefault("zsv10pt5-20", {})["Wave Splash"] = ATTACK_EFFECTS["zsv10pt5-104"]["Wave Splash"]  # ガマガル(=ガマガルと同一テキスト)
ATTACK_EFFECTS.setdefault("zsv10pt5-60", {})["Wild Lances"] = ATTACK_EFFECTS["zsv10pt5-138"]["Wild Lances"]  # シュバルゴ(=シュバルゴと同一テキスト)
ATTACK_EFFECTS.setdefault("zsv10pt5-97", {})["Will-O-Wisp"] = ATTACK_EFFECTS["zsv10pt5-13"]["Will-O-Wisp"]  # ダルマッカ(=ダルマッカと同一テキスト)
ATTACK_EFFECTS.setdefault("zsv10pt5-88", {})["Wrap"] = ATTACK_EFFECTS["zsv10pt5-2"]["Wrap"]  # ジャノビー(=ジャノビーと同一テキスト)

# ---- トレーナーズ ----
TRAINER_EFFECTS["me1-115"] = TRAINER_EFFECTS["sv1-173"]  # エネルギーつけかえ(=エネルギーつけかえと同一テキスト)
TRAINER_EFFECTS["me1-116"] = TRAINER_EFFECTS["m1l-59"]  # ファイトゴング(=ファイトゴングと同一テキスト、m1l-59はJPテキストのみでaliasable判定漏れ)
TRAINER_EFFECTS["me1-168"] = TRAINER_EFFECTS["m1l-59"]  # ファイトゴング 別絵柄
TRAINER_EFFECTS["me2pt5-187"] = TRAINER_EFFECTS["m1l-59"]  # ファイトゴング 別絵柄
TRAINER_EFFECTS["zsv10pt5-82"] = TRAINER_EFFECTS["zsv10pt5-162"]  # マコモ(=マコモと同一テキスト)
TRAINER_EFFECTS["zsv10pt5-170"] = TRAINER_EFFECTS["zsv10pt5-83"]  # Nの筋書き(=Nの筋書きと同一テキスト)

# ---- デッキ採用カード監査(2026-10-06)で追加した起動型の特性 ----
ABILITY_EFFECTS["sm10-81"] = {  # マーシャドー(Marshadow): Resetting Hole ― ベンチにいるとき、場のスタジアムをトラッシュしてよい。そうしたら、このポケモンとついているカードをすべてトラッシュする(スタジアムが無ければ使えない=legal_actions側でゲート)
    "Resetting Hole": (DiscardStadiumInPlay(), DiscardSelfFromBench()),
}
ABILITY_EFFECTS["sm9-16"] = {  # キュウコン(Ninetales): Nine Temptations ― 手札のほのおエネルギーを2枚トラッシュしてよい。そうしたら、相手のベンチポケモン1匹をバトルポケモンと入れ替える
    "Nine Temptations": (DiscardHandEnergyThenSwitchOpponentBench(count=2, energy_type="Fire"),),
}

ABILITY_EFFECTS["swsh12-156"] = {  # 森の封印石(Forest Seal Stone): ついているポケモンVが使えるVSTARパワー「Star Alchemy」(山札から好きなカード1枚を手札に加え、山札を切る)
    "Star Alchemy": (SearchDeckAnyCardToHand(1),),
}

# 「自分の場の別のポケモンを手札から進化させたとき、してもよい」系の特性(イーブイ(swsh10-119)の「Resonant Evolution」)。
# キー: 特性を持つポケモンのcard_id。値: (対象となる「別のポケモン」の名前, 効果)。
SIBLING_EVOLVE_TRIGGER_EFFECTS: dict[str, tuple[str, tuple[Effect, ...]]] = {
    "swsh10-119": ("Eevee", (InstantEvolveSelfFromDeck(allow_just_played=True),)),
}


def get_sibling_evolve_trigger(card_id: str) -> tuple[str, tuple[Effect, ...]] | None:
    return SIBLING_EVOLVE_TRIGGER_EFFECTS.get(card_id)

TRAINER_EFFECTS["xy9-109"] = (LookTopNReorderOnTop(3),)  # パズル オブ タイム(Puzzle of Time): 1枚使用時は山札の上3枚を見て好きな順番で戻す(2枚同時使用時の効果はTRAINER_PAIRED_EFFECTS)


# ワザの後の「してもよい」ではなく、必ず行う効果(実カードテキストに"you may"が無い): ドンファンの「Spinning Turn」、
# ゲンガーEXの「Dark Corridor」の「このポケモンをベンチポケモンと入れ替える」。AFTER_ATTACK_TRIGGER_EFFECTSの
# 仕組みを流用しているが、使わない(DeclineTrigger)を選べないようにする。ベンチが無いときは発動自体しない。
MANDATORY_AFTER_ATTACK_TRIGGERS: set[tuple[str, str]] = {
    ("bw8-72", "Spinning Turn"),
    ("xy4-34", "Dark Corridor"),
}


def is_mandatory_after_attack_trigger(card_id: str, attack_name: str) -> bool:
    return (card_id, attack_name) in MANDATORY_AFTER_ATTACK_TRIGGERS
