"""同名・同文面のトレーナーズ/特殊エネルギー(再録)を、既に実装済みの代表カードのIDに結びつける(2026-10-06〜)。

エンジンの多くの効果は「カードIDごとのテーブル」(集合・辞書・タプル)に登録されているため、同じ文面の再録(別のカードID)は
そのままでは未実装に見える。effects/generated_card_aliases.py(scripts/build_card_aliases.pyが生成)の対応表
(再録のID → 代表のID)を使い、apply_aliases()が各モジュールのIDテーブルに再録のIDを追加する(代表のIDがあるテーブルに、
同じ値で再録のIDも入れる)。何度呼んでも結果は同じ(冪等)。
"""

from __future__ import annotations

import sys

import os

try:
    if os.environ.get("POKECA_IGNORE_CARD_ALIASES"):  # scripts/build_card_aliases.pyが「エイリアス適用前」の状態を数えるため
        raise ImportError
    from effects.generated_card_aliases import CARD_ALIASES
except ImportError:  # pragma: no cover
    CARD_ALIASES: dict[str, str] = {}

_TARGET_MODULES = (
    "effects.registry", "effects.primitives", "effects.era_primitives", "engine.continuous", "engine.energy",
    "engine.legal_actions", "engine.rules_engine", "engine.win_conditions", "engine.turn_manager", "engine.display",
)

_ALIASES_BY_CANON: dict[str, list[str]] = {}
for _alias, _canon in CARD_ALIASES.items():
    _ALIASES_BY_CANON.setdefault(_canon, []).append(_alias)


class AliasStr(str):
    """代表のカードIDの定数。同名・同文面の再録のID(CARD_ALIASES)とも==で等しくなる(定数を==で比べているコード用。
    集合・辞書のキーには使わない: ハッシュは代表のIDのまま)。"""

    __slots__ = ()

    def __eq__(self, other):
        if isinstance(other, str):
            return str.__eq__(self, other) or CARD_ALIASES.get(other) == str(self)
        return NotImplemented

    def __ne__(self, other):
        result = self.__eq__(other)
        return result if result is NotImplemented else not result

    __hash__ = str.__hash__


def canonical_id(card_id: str) -> str:
    return CARD_ALIASES.get(card_id, card_id)


def _extend_container(value):
    """IDテーブル(集合/辞書/タプル/リスト)に、代表のIDがあれば再録のIDを追加したものを返す(変更があったときだけ新しい値/Noneなら変更なし)。"""
    if isinstance(value, dict):
        added = False
        for key in list(value):
            if isinstance(key, str) and key in _ALIASES_BY_CANON:
                for alias in _ALIASES_BY_CANON[key]:
                    if alias not in value:
                        value[alias] = value[key]
                        added = True
        return value if added else None
    if isinstance(value, set):
        added = False
        for item in list(value):
            if isinstance(item, str) and item in _ALIASES_BY_CANON:
                for alias in _ALIASES_BY_CANON[item]:
                    if alias not in value:
                        value.add(alias)
                        added = True
        return value if added else None
    if isinstance(value, (tuple, frozenset)):
        items = list(value)
        extra = [a for item in items if isinstance(item, str) and item in _ALIASES_BY_CANON for a in _ALIASES_BY_CANON[item] if a not in value]
        if not extra:
            return None
        return type(value)(items + extra)
    return None


_ALIAS_MODULE_PREFIXES = ("engine.", "effects.", "agents.", "rl_env.")


def _alias_constants() -> None:
    """読み込み済みのエンジン/効果モジュールの、代表のカードIDを値に持つ文字列定数(DOUBLE_COLORLESS_ENERGY_ID等)を、
    再録のIDとも==で等しいAliasStrに置き換える(他のモジュールにfrom-importされたコピーも含む)。"""
    for name, module in list(sys.modules.items()):
        if module is None or not name.startswith(_ALIAS_MODULE_PREFIXES) or name.endswith("generated_card_aliases"):
            continue
        for attr, value in list(vars(module).items()):
            if type(value) is str and value in _ALIASES_BY_CANON and not attr.startswith("__"):
                setattr(module, attr, AliasStr(value))


def apply_aliases() -> None:
    """読み込み済みの各モジュールのIDテーブルに、再録のIDを追加する(未読み込みのモジュールは、次回の呼び出しで処理される)。"""
    if not CARD_ALIASES:
        return
    _alias_constants()
    for name in _TARGET_MODULES:
        module = sys.modules.get(name)
        if module is None:
            continue
        for attr, value in list(vars(module).items()):
            if attr.startswith("__") or not isinstance(value, (dict, set, tuple, frozenset)):
                continue
            if isinstance(value, tuple) and value and not all(isinstance(x, str) for x in value):
                continue  # 文字列だけのタプルだけが対象(ワザのコスト等を壊さない)
            replaced = _extend_container(value)
            if replaced is not None and replaced is not value:
                setattr(module, attr, replaced)  # タプル/frozensetは作り直したものに差し替える
