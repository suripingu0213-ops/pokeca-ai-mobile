"""SWSH/SV期のグッズ/サポート用の汎用プリミティブ(2026-10-07)。effects/era_trainers_i.py の仕組み(PendingSearchChoice + GENERIC_OP_HANDLERS)の続き。

選択を伴う効果は PendingSearchChoice(zone="gen_*") と GENERIC_OP_HANDLERS["op名"] で解決する。ops はこのファイルの末尾で登録する。
"""

from __future__ import annotations

from dataclasses import dataclass

from effects.context import EffectContext
from effects.primitives import Draw, Effect, SearchDeckMultiCriteria, _attacker_player, _blocks_damage_counters
from engine.state import PendingSearchChoice


def _matches(ctx_or_db, card_id: str, criterion: str) -> bool:
    card_db = getattr(ctx_or_db, "card_db", ctx_or_db)
    c = card_db.get(card_id)
    return c is not None and (criterion == "any" or SearchDeckMultiCriteria._matches(c, criterion))


def _choice(ctx: EffectContext, *, player: int | None = None, zone: str, source_indices, card_ids, min_count: int, max_count: int, prompt: str, op: str, then_end_turn: bool = False, **custom) -> PendingSearchChoice:
    """汎用の選択待ちを立てる(選ぶのは player(既定は効果を使った側)。解決後の続きは効果を使った側として実行する)。"""
    choice = PendingSearchChoice(
        player_index=ctx.acting_player if player is None else player,
        zone=zone,
        source_indices=list(source_indices),
        card_ids=list(card_ids),
        min_count=min_count,
        max_count=max_count,
        prompt=prompt,
        shuffle_after=False,
        all_card_ids=list(card_ids),
        custom_data={"op": op, "user": ctx.acting_player, **custom},
        effect_source=ctx.effect_source,
        cont_acting_player=ctx.acting_player,
        cont_source_pokemon=ctx.source_pokemon,
        cont_source_card_id=ctx.source_card_id,
    )
    ctx.state.pending_search_choice = choice
    return choice


def _draw(player, n: int) -> int:
    drawn = 0
    for _ in range(max(0, n)):
        if not player.deck:
            break
        player.hand.append(player.deck.pop(0))
        drawn += 1
    return drawn


def _label(card_db, card_id: str) -> str:
    c = card_db.get(card_id)
    return c.name if c is not None else card_id


# ---------------------------------------------------------------------------------------------
# 手札を捨てる・山札の下に置く
# ---------------------------------------------------------------------------------------------
@dataclass(frozen=True)
class DiscardUpToFromHand(Effect):
    """手札を、min_count〜max_count枚、好きなカードを選んでトラッシュする(アリスター: 最低1枚)。"""

    max_count: int
    min_count: int = 0

    def execute(self, ctx: EffectContext) -> None:
        from effects.primitives import _trigger_search_choice

        player = _attacker_player(ctx)
        if not player.hand:
            return
        _trigger_search_choice(
            ctx, player, "hand", lambda c: True, self.max_count, f"手札を{self.min_count}〜{self.max_count}枚トラッシュする",
            shuffle_after=False, destination="discard", min_count=min(self.min_count, len(player.hand)),
        )


@dataclass(frozen=True)
class DiscardHandDownTo(Effect):
    """自分の手札がn枚になるまで、好きなカードを選んでトラッシュする(ハンドトリマー)。"""

    n: int

    def execute(self, ctx: EffectContext) -> None:
        from effects.primitives import _trigger_search_choice

        player = _attacker_player(ctx)
        extra = len(player.hand) - self.n
        if extra <= 0:
            return
        _trigger_search_choice(
            ctx, player, "hand", lambda c: True, extra, f"手札が{self.n}枚になるまでトラッシュする", shuffle_after=False,
            destination="discard", min_count=extra,
        )


@dataclass(frozen=True)
class PutHandCardsOnBottom(Effect):
    """手札を、山札の下に好きな順で置く。count>0ならちょうどその枚数(足りなければ使えない)、count=0なら好きな枚数(0枚でもよい)。
    置いたあとの引き方 after: "none" / "same"(置いた枚数と同じ枚数) / "until:N"(手札がN枚になるまで) / "fixed:N"(N枚)。"""

    count: int
    after: str = "none"

    def execute(self, ctx: EffectContext) -> None:
        player = _attacker_player(ctx)
        if not player.hand or (self.count and len(player.hand) < self.count):
            return
        n = self.count or len(player.hand)
        _choice(
            ctx, zone="gen_hand_pick", source_indices=range(len(player.hand)), card_ids=list(player.hand),
            min_count=self.count, max_count=n, prompt="山札の下に置く手札を、置く順に選ぶ", op="hand_to_bottom", after=self.after,
        )


def _op_hand_to_bottom(state, card_db, choice, selected, action, ctx, custom) -> bool:
    player = state.player(custom["user"])
    picked = [player.hand[choice.source_indices[i]] for i in selected]
    for i in sorted((choice.source_indices[i] for i in selected), reverse=True):
        del player.hand[i]
    player.deck.extend(picked)  # 選んだ順に、山札の下へ
    after = custom["after"]
    if after == "same":
        _draw(player, len(picked))
    elif after.startswith("until:"):
        _draw(player, int(after[6:]) - len(player.hand))
    elif after.startswith("fixed:"):
        _draw(player, int(after[6:]))
    state.add_log(f"手札{len(picked)}枚を山札の下に置いた")
    return False


@dataclass(frozen=True)
class KeepOneDiscardRestThenDraw(Effect):
    """手札から1枚を選んで残し、他の手札を全てトラッシュして、draw枚引く(カマド。他に手札が無いと使えない)。"""

    draw: int

    def execute(self, ctx: EffectContext) -> None:
        player = _attacker_player(ctx)
        if not player.hand:
            return
        _choice(
            ctx, zone="gen_hand_pick", source_indices=range(len(player.hand)), card_ids=list(player.hand), min_count=1, max_count=1,
            prompt="手札に残す1枚を選ぶ(他の手札はトラッシュする)", op="keep_one_discard_rest", draw=self.draw,
        )


def _op_keep_one(state, card_db, choice, selected, action, ctx, custom) -> bool:
    player = state.player(custom["user"])
    keep = choice.source_indices[selected[0]] if selected else 0
    kept = player.hand[keep]
    player.discard.extend(c for i, c in enumerate(player.hand) if i != keep)
    player.hand = [kept]
    _draw(player, custom["draw"])
    return False


@dataclass(frozen=True)
class ShuffleHandThenDrawSame(Effect):
    """手札の枚数を数えて山札に戻してシャッフルし、その枚数+plus枚引く(ブラシアス)。"""

    plus: int = 0

    def execute(self, ctx: EffectContext) -> None:
        player = _attacker_player(ctx)
        n = len(player.hand)
        player.deck.extend(player.hand)
        player.hand = []
        ctx.rng.shuffle(player.deck)
        _draw(player, n + self.plus)


@dataclass(frozen=True)
class DrawThenBonusIfHandAtLeast(Effect):
    """base枚引く。そのあと手札がthreshold枚以上なら、さらにbonus枚引く(ビリー&オナ)。"""

    base: int
    threshold: int
    bonus: int

    def execute(self, ctx: EffectContext) -> None:
        player = _attacker_player(ctx)
        _draw(player, self.base)
        if len(player.hand) >= self.threshold:
            _draw(player, self.bonus)


@dataclass(frozen=True)
class DrawUntilMoreThanOpponent(Effect):
    """手札が相手の手札よりextra枚多くなるまで引く(ジス)。"""

    extra: int = 1

    def execute(self, ctx: EffectContext) -> None:
        player = _attacker_player(ctx)
        _draw(player, len(ctx.state.player(ctx.opponent).hand) + self.extra - len(player.hand))


@dataclass(frozen=True)
class OpponentDraw(Effect):
    """相手がcount枚引く(「相手は1枚引いてもよい」を、引くものとして扱う: 引かない理由が無いため)。"""

    count: int = 1

    def execute(self, ctx: EffectContext) -> None:
        _draw(ctx.state.player(ctx.opponent), self.count)


@dataclass(frozen=True)
class OpponentHandToBottomThenDrawSame(Effect):
    """相手が手札を数えてシャッフルし、山札の下に置いて、同じ枚数を引く(やっかいなメモ)。"""

    def execute(self, ctx: EffectContext) -> None:
        opp = ctx.state.player(ctx.opponent)
        n = len(opp.hand)
        if n == 0:
            return
        cards = list(opp.hand)
        ctx.rng.shuffle(cards)
        opp.hand = []
        opp.deck.extend(cards)
        _draw(opp, n)


@dataclass(frozen=True)
class EachPlayerHandToBottomThenCoinDraw(Effect):
    """おたがいに手札をシャッフルして山札の下に置く。どちらかが1枚でも置いたら、おたがいにコインを投げ、オモテなら heads 枚、ウラなら tails 枚引く(ルチアン)。"""

    heads: int
    tails: int

    def execute(self, ctx: EffectContext) -> None:
        any_put = False
        for idx in (ctx.acting_player, ctx.opponent):
            player = ctx.state.player(idx)
            if player.hand:
                any_put = True
                cards = list(player.hand)
                ctx.rng.shuffle(cards)
                player.hand = []
                player.deck.extend(cards)
        if not any_put:
            return
        for idx in (ctx.acting_player, ctx.opponent):
            _draw(ctx.state.player(idx), self.heads if ctx.rng.random() < 0.5 else self.tails)


@dataclass(frozen=True)
class OpponentBenchDownTo(Effect):
    """相手が、ベンチのポケモンがn匹になるまで自分で選んでトラッシュする(ついているカードもトラッシュ)(エイヴリー)。"""

    n: int

    def execute(self, ctx: EffectContext) -> None:
        opp = ctx.state.player(ctx.opponent)
        extra = len(opp.bench) - self.n
        if extra <= 0:
            return
        _choice(
            ctx, player=ctx.opponent, zone="gen_pokemon_pick", source_indices=range(len(opp.bench)),
            card_ids=[_label(ctx.card_db, m.card_id) for m in opp.bench], min_count=extra, max_count=extra,
            prompt=f"ベンチが{self.n}匹になるまで、トラッシュするポケモンを選ぶ", op="bench_discard_picked", owner=ctx.opponent,
        )


def _op_bench_discard_picked(state, card_db, choice, selected, action, ctx, custom) -> bool:
    from engine.state import discard_attached_tool

    owner = state.player(custom["owner"])
    picked = sorted((choice.source_indices[i] for i in selected), reverse=True)
    for bi in picked:
        mon = owner.bench.pop(bi)
        if mon.attached_tool is not None:
            discard_attached_tool(state, owner, mon)
        owner.discard.extend(mon.evolution_history)
        owner.discard.append(mon.card_id)
        owner.discard.extend(mon.attached_energy)
    state.add_log(f"ベンチのポケモンを{len(picked)}匹トラッシュした")
    return False


# ---------------------------------------------------------------------------------------------
# 山札・トラッシュを見る
# ---------------------------------------------------------------------------------------------
@dataclass(frozen=True)
class FlipCoinsThenPutDiscardOnTop(Effect):
    """コインをcoins枚投げ、オモテの数まで、トラッシュからカードを選んで山札の上に好きな順で置く(シレーヌ)。"""

    coins: int

    def execute(self, ctx: EffectContext) -> None:
        player = _attacker_player(ctx)
        heads = sum(1 for _ in range(self.coins) if ctx.rng.random() < 0.5)
        ctx.log(f"コイン{self.coins}枚: オモテ{heads}枚")
        if heads == 0 or not player.discard:
            return
        _choice(
            ctx, zone="discard", source_indices=range(len(player.discard)), card_ids=list(player.discard), min_count=0,
            max_count=min(heads, len(player.discard)), prompt="山札の上に置くトラッシュのカードを、置く順に選ぶ(最初に選んだカードが一番上)",
            op="discard_to_top",
        )


def _op_discard_to_top(state, card_db, choice, selected, action, ctx, custom) -> bool:
    player = state.player(custom["user"])
    idxs = [choice.source_indices[i] for i in selected]
    cards = [player.discard[i] for i in idxs]
    for i in sorted(idxs, reverse=True):
        del player.discard[i]
    player.deck[0:0] = cards  # 最初に選んだカードが一番上
    return False


@dataclass(frozen=True)
class MoveBottomCardsToTop(Effect):
    """山札の下からn枚を見て、好きな順で山札の上に置く(エクスペディションユニフォーム)。"""

    n: int

    def execute(self, ctx: EffectContext) -> None:
        player = _attacker_player(ctx)
        n = min(self.n, len(player.deck))
        if n == 0:
            return
        seen = player.deck[-n:]
        _choice(
            ctx, zone="gen_deck_pick", source_indices=range(n), card_ids=list(seen), min_count=n, max_count=n,
            prompt="山札の下から見たカードを、山札の上に置く順に選ぶ(最初に選んだカードが一番上)", op="bottom_to_top", n=n,
        )


def _op_bottom_to_top(state, card_db, choice, selected, action, ctx, custom) -> bool:
    player = state.player(custom["user"])
    n = custom["n"]
    seen = player.deck[-n:]
    del player.deck[-n:]
    player.deck[0:0] = [seen[choice.source_indices[i]] for i in selected]
    return False


@dataclass(frozen=True)
class ShuffleTopNToBottom(Effect):
    """山札の上からn枚をシャッフルして、山札の下に置く(推理キット)。"""

    n: int

    def execute(self, ctx: EffectContext) -> None:
        player = _attacker_player(ctx)
        n = min(self.n, len(player.deck))
        seen = player.deck[:n]
        del player.deck[:n]
        ctx.rng.shuffle(seen)
        player.deck.extend(seen)


@dataclass(frozen=True)
class LookTopNTakeEachKind(Effect):
    """山札の上からn枚を見て、criteriaの各条件ごとに1枚まで(「ポケモンとトレーナーズ」等)選んで手札に加え、残りは山札に戻してシャッフルする(ドレイトン)。"""

    n: int
    criteria: tuple

    def execute(self, ctx: EffectContext) -> None:
        player = _attacker_player(ctx)
        seen = player.deck[: self.n]
        if not seen:
            return
        self._step(ctx, 0, list(range(len(seen))), len(seen), [])

    def _step(self, ctx: EffectContext, k: int, remaining: list, n: int, taken: list) -> None:
        player = _attacker_player(ctx)
        seen = player.deck[:n]
        while k < len(self.criteria):
            eligible = [i for i in remaining if _matches(ctx, seen[i], self.criteria[k])]
            if eligible:
                _choice(
                    ctx, zone="gen_deck_pick", source_indices=eligible, card_ids=[seen[i] for i in eligible], min_count=0, max_count=1,
                    prompt=f"山札の上{n}枚から、手札に加える「{self.criteria[k]}」を1枚まで選ぶ", op="look_each_kind", n=n,
                    criteria=self.criteria, k=k, remaining=remaining, taken=taken, all_taken=taken,
                )
                return
            k += 1
        _finish_look_each_kind(ctx.state, ctx.rng, player, n, taken)


def _finish_look_each_kind(state, rng, player, n: int, taken: list) -> None:
    seen = player.deck[:n]
    del player.deck[:n]
    rest = []
    for i, cid in enumerate(seen):
        if i in taken:
            player.hand.append(cid)
        else:
            rest.append(cid)
    player.deck.extend(rest)
    rng.shuffle(player.deck)


def _op_look_each_kind(state, card_db, choice, selected, action, ctx, custom) -> bool:
    player = state.player(custom["user"])
    taken = list(custom["taken"])
    remaining = list(custom["remaining"])
    if selected:
        pos = choice.source_indices[selected[0]]
        taken.append(pos)
        remaining.remove(pos)
    effect = LookTopNTakeEachKind(n=custom["n"], criteria=tuple(custom["criteria"]))
    ectx = EffectContext(
        state=state, card_db=card_db, acting_player=custom["user"], source_pokemon=choice.cont_source_pokemon,
        source_card_id=choice.cont_source_card_id, rng=state.rng, effect_source=choice.effect_source,
    )
    _ = player
    effect._step(ectx, custom["k"] + 1, remaining, custom["n"], taken)
    return state.pending_search_choice is not None and state.pending_search_choice is not choice


@dataclass(frozen=True)
class DrawPerOpponentHandKind(Effect):
    """相手の手札を公開させ、条件(criterion)に合うカード1枚につき per枚引く(アセロラの予感/クライブ)。"""

    per: int
    criterion: str

    def execute(self, ctx: EffectContext) -> None:
        opp = ctx.state.player(ctx.opponent)
        ctx.state.player(ctx.acting_player).known_opponent_hand = list(opp.hand)
        n = sum(1 for cid in opp.hand if _matches(ctx, cid, self.criterion))
        ctx.log(f"相手の手札を公開させた({n}枚が該当)")
        _draw(_attacker_player(ctx), self.per * n)


@dataclass(frozen=True)
class RevealOpponentHandDiscardUpTo(Effect):
    """相手の手札を公開させ、条件(criterion)に合うカードを最大count枚選んでトラッシュする(イリ/シドニー)。"""

    criterion: str
    count: int

    def execute(self, ctx: EffectContext) -> None:
        opp = ctx.state.player(ctx.opponent)
        ctx.state.player(ctx.acting_player).known_opponent_hand = list(opp.hand)
        eligible = [i for i, cid in enumerate(opp.hand) if _matches(ctx, cid, self.criterion)]
        if not eligible:
            return
        _choice(
            ctx, zone="gen_hand_pick", source_indices=eligible, card_ids=[opp.hand[i] for i in eligible], min_count=0,
            max_count=min(self.count, len(eligible)), prompt="相手の手札から、トラッシュさせるカードを選ぶ", op="opp_hand_discard", target=ctx.opponent,
        )


def _op_opp_hand_discard(state, card_db, choice, selected, action, ctx, custom) -> bool:
    opp = state.player(custom["target"])
    idxs = sorted((choice.source_indices[i] for i in selected), reverse=True)
    for i in idxs:
        opp.discard.append(opp.hand.pop(i))
    return False


@dataclass(frozen=True)
class LookOpponentTopDiscardKind(Effect):
    """相手の山札の上からn枚を見て、条件(criterion)に合うカードを好きなだけトラッシュし、残りは山札に戻してシャッフルさせる(ミス・フォーチュンシスターズ)。"""

    n: int
    criterion: str

    def execute(self, ctx: EffectContext) -> None:
        opp = ctx.state.player(ctx.opponent)
        seen = opp.deck[: self.n]
        if not seen:
            return
        eligible = [i for i, cid in enumerate(seen) if _matches(ctx, cid, self.criterion)]
        if not eligible:
            ctx.rng.shuffle(opp.deck)
            return
        _choice(
            ctx, zone="gen_deck_pick", source_indices=eligible, card_ids=[seen[i] for i in eligible], min_count=0, max_count=len(eligible),
            prompt="相手の山札の上から見たカードのうち、トラッシュするカードを選ぶ", op="opp_top_discard", n=len(seen), target=ctx.opponent,
        )


def _op_opp_top_discard(state, card_db, choice, selected, action, ctx, custom) -> bool:
    opp = state.player(custom["target"])
    n = custom["n"]
    picked = {choice.source_indices[i] for i in selected}
    seen = opp.deck[:n]
    del opp.deck[:n]
    for i, cid in enumerate(seen):
        if i in picked:
            opp.discard.append(cid)
        else:
            opp.deck.append(cid)
    state.rng.shuffle(opp.deck)
    return False


@dataclass(frozen=True)
class RevealOpponentTopPutBasicsOnTheirBench(Effect):
    """相手の山札の上からn枚を見て、たねポケモンを好きなだけ相手のベンチに出し、残りは相手の山札に戻してシャッフルさせる(おともするふえ)。"""

    n: int

    def execute(self, ctx: EffectContext) -> None:
        from engine.continuous import effective_bench_limit

        opp = ctx.state.player(ctx.opponent)
        seen = opp.deck[: self.n]
        if not seen:
            return
        eligible = [i for i, cid in enumerate(seen) if (c := ctx.card_db.get(cid)) is not None and c.is_pokemon and c.is_basic]
        room = effective_bench_limit(ctx.state, opp, ctx.card_db) - len(opp.bench)
        if not eligible or room <= 0:
            ctx.rng.shuffle(opp.deck)
            return
        _choice(
            ctx, zone="gen_deck_pick", source_indices=eligible, card_ids=[seen[i] for i in eligible], min_count=0, max_count=min(room, len(eligible)),
            prompt="相手の山札の上から見たたねポケモンのうち、相手のベンチに出すものを選ぶ", op="opp_top_to_bench", n=len(seen), target=ctx.opponent,
        )


def _op_opp_top_to_bench(state, card_db, choice, selected, action, ctx, custom) -> bool:
    from engine.state import PokemonInPlay

    opp = state.player(custom["target"])
    n = custom["n"]
    picked = {choice.source_indices[i] for i in selected}
    seen = opp.deck[:n]
    del opp.deck[:n]
    for i, cid in enumerate(seen):
        if i in picked:
            opp.bench.append(PokemonInPlay(card_id=cid, turn_played=opp.turns_taken))
        else:
            opp.deck.append(cid)
    state.rng.shuffle(opp.deck)
    return False


# ---------------------------------------------------------------------------------------------
# 回復・特殊状態
# ---------------------------------------------------------------------------------------------
def _own_slots(player):
    from effects.era_primitives_b import _slots

    return _slots(player)


def _mon_card(ctx, mon):
    return ctx.card_db.get(mon.card_id)


@dataclass(frozen=True)
class HealUpToNPokemon(Effect):
    """自分のポケモンを最大count匹まで(1匹ずつ選んで)、それぞれamountだけ回復する(サグアロ/シーボルト/モーモーチーズ)。
    subtype: そのサブタイプのポケモンだけ / require_energy: エネルギーがついているポケモンだけ。"""

    count: int
    amount: int
    subtype: str | None = None
    require_energy: bool = False

    def _candidates(self, ctx, player, done: list):
        out = []
        for slot, mon in _own_slots(player):
            if slot in done or mon.damage <= 0:
                continue
            card = _mon_card(ctx, mon)
            if self.subtype and (card is None or self.subtype not in card.subtypes):
                continue
            if self.require_energy and not mon.attached_energy:
                continue
            out.append((slot, mon))
        return out

    def execute(self, ctx: EffectContext) -> None:
        self.step(ctx, [])

    def step(self, ctx: EffectContext, done: list) -> None:
        player = _attacker_player(ctx)
        if len(done) >= self.count:
            return
        cands = self._candidates(ctx, player, done)
        if not cands:
            return
        _choice(
            ctx, zone="gen_pokemon_pick", source_indices=[s for s, _ in cands], card_ids=[m.card_id for _, m in cands], min_count=0, max_count=1,
            prompt=f"回復させるポケモンを選ぶ(あと{self.count - len(done)}匹まで。選ばなければ終わる)", op="heal_up_to_step",
            spec=(self.count, self.amount, self.subtype, self.require_energy), done=done,
        )


def _op_heal_up_to_step(state, card_db, choice, selected, action, ctx, custom) -> bool:
    from effects.era_primitives_b import _mon_at

    if not selected:
        return False
    count, amount, subtype, require_energy = custom["spec"]
    player = state.player(custom["user"])
    slot = choice.source_indices[selected[0]]
    mon = _mon_at(player, slot)
    if mon is not None:
        mon.heal(amount)
    effect = HealUpToNPokemon(count=count, amount=amount, subtype=subtype, require_energy=require_energy)
    ectx = EffectContext(
        state=state, card_db=card_db, acting_player=custom["user"], source_pokemon=choice.cont_source_pokemon,
        source_card_id=choice.cont_source_card_id, rng=state.rng, effect_source=choice.effect_source,
    )
    effect.step(ectx, list(custom["done"]) + [slot])
    return state.pending_search_choice is not None and state.pending_search_choice is not choice


@dataclass(frozen=True)
class HealBothActive(Effect):
    """おたがいのバトルポケモンのダメージをamountずつ回復する(チームヤールのタオル)。"""

    amount: int

    def execute(self, ctx: EffectContext) -> None:
        for idx in (ctx.acting_player, ctx.opponent):
            active = ctx.state.player(idx).active
            if active is not None:
                active.heal(self.amount)


@dataclass(frozen=True)
class HealActiveOfType(Effect):
    """自分のバトルポケモンが ptype なら、amountだけ回復する(ドラゴンエリクサー)。"""

    amount: int
    ptype: str

    def execute(self, ctx: EffectContext) -> None:
        active = _attacker_player(ctx).active
        card = _mon_card(ctx, active) if active is not None else None
        if card is not None and self.ptype in card.types:
            active.heal(self.amount)


@dataclass(frozen=True)
class HealActiveThenCoinKeepCard(Effect):
    """自分のバトルポケモンをamount回復する。実際に回復したらコインを投げ、オモテならこのカードを手札に戻す(ラッキーアイスバー)。"""

    amount: int

    def execute(self, ctx: EffectContext) -> None:
        active = _attacker_player(ctx).active
        if active is None or active.damage <= 0:
            return
        active.heal(self.amount)
        if ctx.rng.random() < 0.5:
            ctx.state.played_card_destination = "hand"
            ctx.log("コインがオモテ: このカードを手札に戻す")


@dataclass(frozen=True)
class HealUntilTailsOnChosen(Effect):
    """自分のポケモン1匹を選び、ウラが出るまでコインを投げ、オモテ1枚につきperだけ回復する(あまいハチミツ)。"""

    per: int

    def execute(self, ctx: EffectContext) -> None:
        player = _attacker_player(ctx)
        slots = _own_slots(player)
        if not slots:
            return
        _choice(
            ctx, zone="gen_pokemon_pick", source_indices=[s for s, _ in slots], card_ids=[m.card_id for _, m in slots], min_count=1, max_count=1,
            prompt="回復させるポケモンを1匹選ぶ", op="heal_until_tails", per=self.per,
        )


def _op_heal_until_tails(state, card_db, choice, selected, action, ctx, custom) -> bool:
    from effects.era_primitives_b import _mon_at

    player = state.player(custom["user"])
    mon = _mon_at(player, choice.source_indices[selected[0]]) if selected else None
    if mon is None:
        return False
    heads = 0
    while state.rng.random() < 0.5:
        heads += 1
    state.add_log(f"コイン: オモテ{heads}回")
    mon.heal(custom["per"] * heads)
    return False


@dataclass(frozen=True)
class HealThenDiscardEnergy(Effect):
    """自分のポケモン1匹(エネルギーがmin_energy個以上ついている。energy_type指定時はそのタイプがmin_energy個以上)を選び、amount回復する。
    実際に回復したら、そのポケモンからエネルギーをdiscard枚(energy_type指定時はそのタイプ)トラッシュする(ハイパーポーション/あやしいフードボックス)。"""

    amount: int
    min_energy: int
    discard: int
    energy_type: str | None = None

    def _energy_ids(self, card_db, mon) -> list:
        out = []
        for e in mon.attached_energy:
            c = card_db.get(e)
            if c is not None and (self.energy_type is None or c.basic_energy_type == self.energy_type):
                out.append(e)
        return out

    def execute(self, ctx: EffectContext) -> None:
        player = _attacker_player(ctx)
        cands = [(s, m) for s, m in _own_slots(player) if len(self._energy_ids(ctx.card_db, m)) >= self.min_energy]
        if not cands:
            return
        _choice(
            ctx, zone="gen_pokemon_pick", source_indices=[s for s, _ in cands], card_ids=[m.card_id for _, m in cands], min_count=1, max_count=1,
            prompt="回復させるポケモンを1匹選ぶ", op="heal_discard_energy_pick", spec=(self.amount, self.min_energy, self.discard, self.energy_type),
        )


def _op_heal_discard_energy_pick(state, card_db, choice, selected, action, ctx, custom) -> bool:
    from effects.era_primitives_b import _mon_at

    amount, min_energy, discard, energy_type = custom["spec"]
    player = state.player(custom["user"])
    slot = choice.source_indices[selected[0]] if selected else None
    mon = _mon_at(player, slot) if slot is not None else None
    if mon is None:
        return False
    healed = mon.damage > 0
    mon.heal(amount)
    if not healed:
        return False
    effect = HealThenDiscardEnergy(amount, min_energy, discard, energy_type)
    ids = effect._energy_ids(card_db, mon)
    if len(ids) <= discard or len(set(ids)) == 1:
        for _ in range(min(discard, len(ids))):
            e = ids[0]
            ids.remove(e)
            mon.attached_energy.remove(e)
            player.discard.append(e)
        return False
    state.pending_search_choice = PendingSearchChoice(
        player_index=custom["user"], zone="gen_pokemon_pick", source_indices=list(range(len(ids))), card_ids=[_label(card_db, e) for e in ids],
        min_count=discard, max_count=discard, prompt=f"トラッシュするエネルギーを{discard}枚選ぶ", shuffle_after=False,
        all_card_ids=[_label(card_db, e) for e in ids], custom_data={"op": "discard_energy_picked", "user": custom["user"], "slot": slot, "energy_ids": ids},
        effect_source=choice.effect_source, cont_acting_player=custom["user"],
    )
    return True


def _op_discard_energy_picked(state, card_db, choice, selected, action, ctx, custom) -> bool:
    from effects.era_primitives_b import _mon_at

    player = state.player(custom["user"])
    mon = _mon_at(player, custom["slot"])
    if mon is None:
        return False
    for i in selected:
        e = custom["energy_ids"][i]
        if e in mon.attached_energy:
            mon.attached_energy.remove(e)
            player.discard.append(e)
    return False


@dataclass(frozen=True)
class HealEvolutionsThenDiscardEnergy(Effect):
    """自分の進化ポケモン全員のダメージを全て回復し、実際に回復したポケモンについているエネルギーを全てトラッシュする(チェリ)。"""

    def execute(self, ctx: EffectContext) -> None:
        player = _attacker_player(ctx)
        for _, mon in _own_slots(player):
            card = _mon_card(ctx, mon)
            if card is None or card.is_basic or mon.damage <= 0:
                continue
            mon.heal(9999)
            player.discard.extend(mon.attached_energy)
            mon.attached_energy = []


@dataclass(frozen=True)
class InflictStatusOnOwnActive(Effect):
    """自分のバトルポケモンを特殊状態にする(ピリ辛カレー: やけど)。"""

    condition: str

    def execute(self, ctx: EffectContext) -> None:
        from effects.primitives import _apply_condition

        active = _attacker_player(ctx).active
        if active is not None:
            _apply_condition(active, self.condition)


@dataclass(frozen=True)
class BothActiveStatus(Effect):
    """おたがいのバトルポケモンを特殊状態にする(エールホーン: こんらん)。"""

    condition: str

    def execute(self, ctx: EffectContext) -> None:
        from effects.primitives import _apply_condition

        for idx in (ctx.acting_player, ctx.opponent):
            active = ctx.state.player(idx).active
            if active is not None:
                _apply_condition(active, self.condition)


@dataclass(frozen=True)
class SetAttackLockThisTurn(Effect):
    """この番、自分のポケモンはワザを使えない(ギーマ等。この番に場に出たポケモンも含む)。"""

    def execute(self, ctx: EffectContext) -> None:
        player = _attacker_player(ctx)
        player.attack_locked_until_turn = player.turns_taken


# ---------------------------------------------------------------------------------------------
# 入れ替え
# ---------------------------------------------------------------------------------------------
@dataclass(frozen=True)
class SwitchInOpponentBenched(Effect):
    """相手のベンチのポケモン(spec: era_attacks_i.pokemon_matches の絞り込み。hp_at_most: 残りHPがこの値以下)を1匹選んで、バトル場に出す。
    then_status: 出したポケモンをその特殊状態にする(リシアの魅力)。候補が無ければ何もしない。"""

    spec: str = ""
    hp_at_most: int | None = None
    then_status: str | None = None

    def candidates(self, ctx):
        from effects.era_attacks_i import pokemon_matches

        opp = ctx.state.player(ctx.opponent)
        out = []
        for bi, mon in enumerate(opp.bench):
            if self.spec and not pokemon_matches(ctx, mon, self.spec):
                continue
            if self.hp_at_most is not None:
                from engine.continuous import effective_max_hp

                remaining = effective_max_hp(ctx.card_db, mon.card_id, mon.attached_tool, ctx.state.stadium_in_play, mon.attached_energy) - mon.damage
                if remaining > self.hp_at_most:
                    continue
            out.append(bi)
        return out

    def execute(self, ctx: EffectContext) -> None:
        opp = ctx.state.player(ctx.opponent)
        cands = self.candidates(ctx)
        if not cands:
            return
        if len(cands) == 1:
            _switch_in_opponent(ctx.state, ctx.opponent, cands[0], self.then_status)
            return
        _choice(
            ctx, zone="gen_pokemon_pick", source_indices=cands, card_ids=[opp.bench[i].card_id for i in cands], min_count=1, max_count=1,
            prompt="バトル場に出す相手のベンチのポケモンを選ぶ", op="switch_in_opp_picked", status=self.then_status,
        )


def _switch_in_opponent(state, owner_index: int, bench_index: int, status) -> None:
    from effects.primitives import _apply_condition

    owner = state.player(owner_index)
    new_active = owner.bench.pop(bench_index)
    if owner.active is not None:
        owner.active.status.clear_all()
        owner.bench.append(owner.active)
    new_active.status.clear_all()
    owner.active = new_active
    if status:
        _apply_condition(new_active, status)
    state.add_log(f"相手のベンチの {new_active.card_id} をバトル場に出した")


def _op_switch_in_opp_picked(state, card_db, choice, selected, action, ctx, custom) -> bool:
    if selected:
        _switch_in_opponent(state, 1 - custom["user"], choice.source_indices[selected[0]], custom["status"])
    return False


@dataclass(frozen=True)
class PrimeCatcherEffect(Effect):
    """相手のベンチのポケモンを1匹選んでバトル場に出し、そうしたら、自分のバトルポケモンをベンチのポケモンと入れ替える(プライムキャッチャー)。"""

    def execute(self, ctx: EffectContext) -> None:
        opp = ctx.state.player(ctx.opponent)
        if not opp.bench:
            return
        _choice(
            ctx, zone="gen_pokemon_pick", source_indices=range(len(opp.bench)), card_ids=[m.card_id for m in opp.bench], min_count=1, max_count=1,
            prompt="バトル場に出す相手のベンチのポケモンを選ぶ", op="prime_catcher_opp",
        )


def _op_prime_catcher_opp(state, card_db, choice, selected, action, ctx, custom) -> bool:
    if not selected:
        return False
    _switch_in_opponent(state, 1 - custom["user"], choice.source_indices[selected[0]], None)
    me = state.player(custom["user"])
    if not me.bench:
        return False
    state.pending_search_choice = PendingSearchChoice(
        player_index=custom["user"], zone="gen_pokemon_pick", source_indices=list(range(len(me.bench))), card_ids=[m.card_id for m in me.bench],
        min_count=1, max_count=1, prompt="バトル場に出す自分のベンチのポケモンを選ぶ", shuffle_after=False, all_card_ids=[m.card_id for m in me.bench],
        custom_data={"op": "own_switch_picked", "user": custom["user"]}, effect_source=choice.effect_source, cont_acting_player=custom["user"],
    )
    return True


def _op_own_switch_picked(state, card_db, choice, selected, action, ctx, custom) -> bool:
    if not selected:
        return False
    owner = state.player(custom["user"])
    new_active = owner.bench.pop(choice.source_indices[selected[0]])
    if owner.active is not None:
        owner.active.status.clear_all()
        owner.bench.append(owner.active)
    new_active.status.clear_all()
    new_active.became_active_turn = owner.turns_taken
    owner.active = new_active
    return False


@dataclass(frozen=True)
class SwitchWithDiscardPokemon(Effect):
    """トラッシュのポケモン(discard_spec)を1匹選び、場の自分のポケモン(own_spec)1匹と入れ替える。場にいたカードがトラッシュに行き、
    ついているカード・ダメカン・特殊状態・場に出た番などは、新しいポケモンに引き継がれる(サントン/オーガポンのお面)。"""

    own_spec: str
    discard_spec: str

    def execute(self, ctx: EffectContext) -> None:
        from effects.era_attacks_i import card_matches, pokemon_matches

        player = _attacker_player(ctx)
        discard_idx = [i for i, cid in enumerate(player.discard) if card_matches(ctx.card_db.get(cid), self.discard_spec)]
        own = [(s, m) for s, m in _own_slots(player) if pokemon_matches(ctx, m, self.own_spec)]
        if not discard_idx or not own:
            return
        _choice(
            ctx, zone="discard", source_indices=discard_idx, card_ids=[player.discard[i] for i in discard_idx], min_count=1, max_count=1,
            prompt="場のポケモンと入れ替える、トラッシュのポケモンを選ぶ", op="swap_discard_pick1", own_spec=self.own_spec,
        )


def _op_swap_discard_pick1(state, card_db, choice, selected, action, ctx, custom) -> bool:
    from effects.era_attacks_i import pokemon_matches

    if not selected:
        return False
    player = state.player(custom["user"])
    discard_pos = choice.source_indices[selected[0]]
    ectx = EffectContext(state=state, card_db=card_db, acting_player=custom["user"], source_pokemon=None, source_card_id="", rng=state.rng)
    own = [(s, m) for s, m in _own_slots(player) if pokemon_matches(ectx, m, custom["own_spec"])]
    if len(own) == 1:
        _swap_with_discard(state, player, own[0][0], discard_pos)
        return False
    state.pending_search_choice = PendingSearchChoice(
        player_index=custom["user"], zone="gen_pokemon_pick", source_indices=[s for s, _ in own], card_ids=[m.card_id for _, m in own],
        min_count=1, max_count=1, prompt="トラッシュのポケモンと入れ替える、場のポケモンを選ぶ", shuffle_after=False, all_card_ids=[m.card_id for _, m in own],
        custom_data={"op": "swap_discard_pick2", "user": custom["user"], "discard_pos": discard_pos}, effect_source=choice.effect_source,
        cont_acting_player=custom["user"],
    )
    return True


def _op_swap_discard_pick2(state, card_db, choice, selected, action, ctx, custom) -> bool:
    if selected:
        _swap_with_discard(state, state.player(custom["user"]), choice.source_indices[selected[0]], custom["discard_pos"])
    return False


def _swap_with_discard(state, player, slot: int, discard_pos: int) -> None:
    from effects.era_primitives_b import _mon_at

    mon = _mon_at(player, slot)
    if mon is None or not (0 <= discard_pos < len(player.discard)):
        return
    new_id = player.discard.pop(discard_pos)
    old_id = mon.card_id
    mon.card_id = new_id
    player.discard.append(old_id)
    state.add_log(f"場の {old_id} をトラッシュの {new_id} と入れ替えた")


# ---------------------------------------------------------------------------------------------
# エネルギー・サイド・その他
# ---------------------------------------------------------------------------------------------
@dataclass(frozen=True)
class AttachDiscardEnergyToEachMatching(Effect):
    """自分の場のポケモンのうち spec(era_attacks_i.pokemon_matches)に合う全員に、トラッシュの基本エネルギーを1枚ずつつける(リブートポッド)。
    つけるエネルギーは1匹ずつプレイヤーが選ぶ。"""

    spec: str

    def execute(self, ctx: EffectContext) -> None:
        from effects.era_attacks_i import pokemon_matches

        player = _attacker_player(ctx)
        slots = [s for s, m in _own_slots(player) if pokemon_matches(ctx, m, self.spec)]
        self.step(ctx, slots)

    def step(self, ctx: EffectContext, slots: list) -> None:
        player = _attacker_player(ctx)
        while slots:
            eligible = [i for i, cid in enumerate(player.discard) if (c := ctx.card_db.get(cid)) is not None and c.is_energy and not c.is_special_energy]
            if not eligible:
                return
            slot = slots[0]
            if len({player.discard[i] for i in eligible}) == 1:
                from effects.era_primitives_b import _mon_at

                mon = _mon_at(player, slot)
                if mon is not None:
                    mon.attached_energy.append(player.discard.pop(eligible[0]))
                slots = slots[1:]
                continue
            _choice(
                ctx, zone="discard", source_indices=eligible, card_ids=[player.discard[i] for i in eligible], min_count=1, max_count=1,
                prompt="次のポケモンにつける基本エネルギーを選ぶ", op="attach_each_step", spec=self.spec, slots=slots,
            )
            return


def _op_attach_each_step(state, card_db, choice, selected, action, ctx, custom) -> bool:
    from effects.era_primitives_b import _mon_at

    player = state.player(custom["user"])
    slots = list(custom["slots"])
    if selected:
        mon = _mon_at(player, slots[0])
        if mon is not None:
            mon.attached_energy.append(player.discard.pop(choice.source_indices[selected[0]]))
    effect = AttachDiscardEnergyToEachMatching(custom["spec"])
    ectx = EffectContext(
        state=state, card_db=card_db, acting_player=custom["user"], source_pokemon=choice.cont_source_pokemon,
        source_card_id=choice.cont_source_card_id, rng=state.rng, effect_source=choice.effect_source,
    )
    effect.step(ectx, slots[1:])
    return state.pending_search_choice is not None and state.pending_search_choice is not choice


@dataclass(frozen=True)
class DiscardTopThenAttachDiscardedEnergy(Effect):
    """山札の上からn枚をトラッシュし、そのうちのエネルギーを(1枚ずつ対象を選んで)、自分のベンチの spec に合うポケモンにつける(ビーア)。"""

    n: int
    spec: str

    def execute(self, ctx: EffectContext) -> None:
        player = _attacker_player(ctx)
        top = [player.deck.pop(0) for _ in range(min(self.n, len(player.deck)))]
        player.discard.extend(top)
        ctx.log(f"山札の上から{len(top)}枚をトラッシュした")
        energies = [cid for cid in top if (c := ctx.card_db.get(cid)) is not None and c.is_energy]
        self.step(ctx, energies)

    def step(self, ctx: EffectContext, energies: list) -> None:
        from effects.era_attacks_i import pokemon_matches

        player = _attacker_player(ctx)
        targets = [i for i, m in enumerate(player.bench) if pokemon_matches(ctx, m, self.spec)]
        while energies and targets:
            if len(targets) == 1:
                eid = energies.pop(0)
                player.discard.remove(eid)
                player.bench[targets[0]].attached_energy.append(eid)
                continue
            _choice(
                ctx, zone="gen_pokemon_pick", source_indices=targets, card_ids=[player.bench[i].card_id for i in targets], min_count=1, max_count=1,
                prompt=f"エネルギー({_label(ctx.card_db, energies[0])})をつけるベンチのポケモンを選ぶ(残り{len(energies)}枚)", op="attach_discarded_step",
                n=self.n, spec=self.spec, energies=energies,
            )
            return


def _op_attach_discarded_step(state, card_db, choice, selected, action, ctx, custom) -> bool:
    player = state.player(custom["user"])
    energies = list(custom["energies"])
    if selected and energies:
        eid = energies.pop(0)
        if eid in player.discard:
            player.discard.remove(eid)
            player.bench[choice.source_indices[selected[0]]].attached_energy.append(eid)
    effect = DiscardTopThenAttachDiscardedEnergy(custom["n"], custom["spec"])
    ectx = EffectContext(
        state=state, card_db=card_db, acting_player=custom["user"], source_pokemon=choice.cont_source_pokemon,
        source_card_id=choice.cont_source_card_id, rng=state.rng, effect_source=choice.effect_source,
    )
    effect.step(ectx, energies)
    return state.pending_search_choice is not None and state.pending_search_choice is not choice


@dataclass(frozen=True)
class RevealTopCardAttachOrHand(Effect):
    """山札の一番上のカードを公開する。そのカードが条件(criterion)に合うエネルギーなら、自分のベンチのポケモン1匹につける。そうでなければ手札に加える(ガッツのつるはし)。"""

    criterion: str

    def execute(self, ctx: EffectContext) -> None:
        player = _attacker_player(ctx)
        if not player.deck:
            return
        top = player.deck[0]
        ctx.log(f"山札の一番上を公開: {_label(ctx.card_db, top)}")
        if _matches(ctx, top, self.criterion) and player.bench:
            player.deck.pop(0)
            if len(player.bench) == 1:
                player.bench[0].attached_energy.append(top)
                return
            _choice(
                ctx, zone="gen_pokemon_pick", source_indices=range(len(player.bench)), card_ids=[m.card_id for m in player.bench], min_count=1, max_count=1,
                prompt="公開したエネルギーをつけるベンチのポケモンを選ぶ", op="attach_revealed_top", energy=top,
            )
            return
        player.hand.append(player.deck.pop(0))


def _op_attach_revealed_top(state, card_db, choice, selected, action, ctx, custom) -> bool:
    player = state.player(custom["user"])
    if selected:
        player.bench[choice.source_indices[selected[0]]].attached_energy.append(custom["energy"])
    else:
        player.hand.append(custom["energy"])
    return False


@dataclass(frozen=True)
class PrizeSwapWithHand(Effect):
    """サイドを最大n枚(選んだ枚数)手札に加え、加えた枚数ぶん、手札のカードを選んでサイドに裏向きで置く(ペオニア)。"""

    n: int

    def execute(self, ctx: EffectContext) -> None:
        player = _attacker_player(ctx)
        k = min(self.n, len(player.prizes))
        if k <= 0:
            return
        labels = tuple(f"{i}枚" for i in range(k + 1))
        _choice(
            ctx, zone="gen_pokemon_pick", source_indices=range(len(labels)), card_ids=labels, min_count=1, max_count=1,
            prompt=f"サイドを手札に加える枚数を選ぶ(最大{k}枚)", op="prize_swap_count",
        )


def _op_prize_swap_count(state, card_db, choice, selected, action, ctx, custom) -> bool:
    player = state.player(custom["user"])
    k = choice.source_indices[selected[0]] if selected else 0
    if k <= 0:
        return False
    taken = [player.prizes.pop(0) for _ in range(min(k, len(player.prizes)))]
    player.hand.extend(taken)
    player.reset_prize_marks()
    ectx = EffectContext(state=state, card_db=card_db, acting_player=custom["user"], source_pokemon=None, source_card_id="", rng=state.rng)
    _choice(
        ectx, zone="gen_hand_pick", source_indices=range(len(player.hand)), card_ids=list(player.hand), min_count=min(len(taken), len(player.hand)),
        max_count=min(len(taken), len(player.hand)), prompt=f"サイドに裏向きで置く手札を{len(taken)}枚選ぶ", op="prize_swap_put",
    )
    return True


def _op_prize_swap_put(state, card_db, choice, selected, action, ctx, custom) -> bool:
    player = state.player(custom["user"])
    idxs = sorted((choice.source_indices[i] for i in selected), reverse=True)
    cards = [player.hand[i] for i in idxs]
    for i in idxs:
        del player.hand[i]
    player.add_prizes(cards)
    state.rng.shuffle(player.prizes)
    player.reset_prize_marks()
    return False


@dataclass(frozen=True)
class SearchBasicToBenchMayPromote(Effect):
    """山札からたねポケモンを1匹ベンチに出し、シャッフルする。そのあと、そのポケモンをバトルポケモンと入れ替えてもよい(ふりそでガール)。"""

    def execute(self, ctx: EffectContext) -> None:
        from effects.primitives import _trigger_search_choice

        player = _attacker_player(ctx)
        before = len(player.bench)
        _trigger_search_choice(
            ctx, player, "deck", lambda c: c is not None and c.is_pokemon and c.is_basic, 1, "山札からたねポケモンを1匹ベンチに出す",
            shuffle_after=True, destination="bench",
        )
        pending = ctx.state.pending_search_choice
        if pending is not None:
            pending.remaining_script = pending.remaining_script + (MayPromoteLastBenched(before),)
        elif len(player.bench) > before:
            MayPromoteLastBenched(before).execute(ctx)


@dataclass(frozen=True)
class MayPromoteLastBenched(Effect):
    """直前にベンチに出したポケモン(それまでのベンチの数before番目)を、バトルポケモンと入れ替えるか選ぶ。"""

    before: int

    def execute(self, ctx: EffectContext) -> None:
        player = _attacker_player(ctx)
        if len(player.bench) <= self.before or player.active is None:
            return
        _choice(
            ctx, zone="gen_pokemon_pick", source_indices=range(2), card_ids=["入れ替える", "入れ替えない"], min_count=1, max_count=1,
            prompt="ベンチに出したポケモンを、バトルポケモンと入れ替えるか選ぶ", op="promote_last_benched", index=self.before,
        )


def _op_promote_last_benched(state, card_db, choice, selected, action, ctx, custom) -> bool:
    if not selected or choice.source_indices[selected[0]] != 0:
        return False
    player = state.player(custom["user"])
    idx = custom["index"]
    if idx >= len(player.bench):
        return False
    new_active = player.bench.pop(idx)
    if player.active is not None:
        player.active.status.clear_all()
        player.bench.append(player.active)
    new_active.status.clear_all()
    new_active.became_active_turn = player.turns_taken
    player.active = new_active
    return False


@dataclass(frozen=True)
class ArcPhoneEffect(Effect):
    """自分の山札の一番上を見て、そのカードを、自分のサイド(裏向き)の1枚と入れ替えてもよい(アークフォン)。"""

    def execute(self, ctx: EffectContext) -> None:
        player = _attacker_player(ctx)
        if not player.deck or not player.prizes:
            return
        top = player.deck[0]
        labels = ["入れ替えない"] + [f"サイド{i + 1}枚目と入れ替える" for i in range(len(player.prizes))]
        _choice(
            ctx, zone="gen_pokemon_pick", source_indices=range(len(labels)), card_ids=labels, min_count=1, max_count=1,
            prompt=f"山札の一番上のカード({_label(ctx.card_db, top)})を、サイドの1枚と入れ替えるか選ぶ", op="arc_phone_swap",
        )


def _op_arc_phone_swap(state, card_db, choice, selected, action, ctx, custom) -> bool:
    player = state.player(custom["user"])
    k = choice.source_indices[selected[0]] if selected else 0
    if k <= 0 or not player.deck or k - 1 >= len(player.prizes):
        return False
    player.deck[0], player.prizes[k - 1] = player.prizes[k - 1], player.deck[0]
    player.reset_prize_marks()
    return False


@dataclass(frozen=True)
class ReturnChosenOwnToolToHand(Effect):
    """自分のポケモンについているどうぐを1枚選んで、手札に戻す(ショッピングセンター)。"""

    def execute(self, ctx: EffectContext) -> None:
        player = _attacker_player(ctx)
        cands = [(s, m) for s, m in _own_slots(player) if m.attached_tool is not None]
        if not cands:
            return
        _choice(
            ctx, zone="gen_pokemon_pick", source_indices=[s for s, _ in cands], card_ids=[m.attached_tool for _, m in cands], min_count=1, max_count=1,
            prompt="手札に戻すどうぐを選ぶ", op="return_tool_to_hand",
        )


def _op_return_tool_to_hand(state, card_db, choice, selected, action, ctx, custom) -> bool:
    from effects.era_primitives_b import _mon_at

    player = state.player(custom["user"])
    mon = _mon_at(player, choice.source_indices[selected[0]]) if selected else None
    if mon is not None and mon.attached_tool is not None:
        player.hand.append(mon.attached_tool)
        mon.attached_tool = None
        mon.attached_tool_owner = None
    return False


@dataclass(frozen=True)
class OpponentTopDeckLookAndRevealHand(Effect):
    """相手の手札を公開させ、そうしたら、相手の山札の上を見る(ドローンロトム)。"""

    def execute(self, ctx: EffectContext) -> None:
        opp = ctx.state.player(ctx.opponent)
        me = ctx.state.player(ctx.acting_player)
        me.known_opponent_hand = list(opp.hand)
        if opp.deck:
            ctx.log(f"相手の山札の一番上を見た: {_label(ctx.card_db, opp.deck[0])}")


@dataclass(frozen=True)
class DrawThenLookAtPrizes(Effect):
    """count枚引く。そのあと、自分のサイドを見る(デイジーのおてつだい)。"""

    count: int

    def execute(self, ctx: EffectContext) -> None:
        player = _attacker_player(ctx)
        _draw(player, self.count)
        ctx.log(f"自分のサイドを見た: {[_label(ctx.card_db, c) for c in player.prizes]}")


@dataclass(frozen=True)
class RevealBothHands(Effect):
    """おたがいの手札を公開する(ユゲ・ヒヨ・ドロー系の前置き)。"""

    def execute(self, ctx: EffectContext) -> None:
        opp = ctx.state.player(ctx.opponent)
        ctx.state.player(ctx.acting_player).known_opponent_hand = list(opp.hand)
        ctx.log("おたがいの手札を公開した")


@dataclass(frozen=True)
class ShuffleDiscardedKindIntoDeckThenDraw(Effect):
    """トラッシュの条件(criterion)に合うカードを最大count枚選んで山札に戻してシャッフルする(except_name以外)。戻したら draw 枚引く(ミリ/チームヤールのエール)。"""

    criterion: str
    count: int
    draw: int = 0
    except_name: str | None = None

    def execute(self, ctx: EffectContext) -> None:
        from effects.primitives import _trigger_search_choice

        player = _attacker_player(ctx)
        _trigger_search_choice(
            ctx, player, "discard",
            lambda c: c is not None and _card_ok(c, self.criterion) and c.name != self.except_name, self.count,
            f"トラッシュから最大{self.count}枚を山札に戻す", shuffle_after=True, destination="deck",
        )
        pending = ctx.state.pending_search_choice
        if pending is not None and self.draw:
            pending.remaining_script = pending.remaining_script + (Draw(self.draw),)


def _card_ok(card, criterion: str) -> bool:
    return criterion == "any" or SearchDeckMultiCriteria._matches(card, criterion)


@dataclass(frozen=True)
class SearchDeckEachKindToHand(Effect):
    """山札から、criteriaの各条件に1枚ずつ(あるだけ)探して手札に加え、シャッフルする(ラリーのスキル)。"""

    criteria: tuple

    def execute(self, ctx: EffectContext) -> None:
        from effects.primitives import SearchDeckMultiCriteria as S

        S(self.criteria).execute(ctx)


@dataclass(frozen=True)
class DiscardWholeHand(Effect):
    """手札を全てトラッシュする。"""

    def execute(self, ctx: EffectContext) -> None:
        player = _attacker_player(ctx)
        player.discard.extend(player.hand)
        player.hand = []


# ---------------------------------------------------------------------------------------------
# 相手のエネルギー・検索の追加クラス・この番のダメージ強化
# ---------------------------------------------------------------------------------------------
@dataclass(frozen=True)
class MoveOpponentFieldEnergy(Effect):
    """相手の場のポケモン(only_active=Trueならバトルポケモンだけ)についているエネルギー(special_only=Trueなら特殊エネルギーだけ)を count 枚選び、
    destination("hand"=相手の手札/"deck"=相手の山札の下/"deck_top"=相手の山札の上/"discard"=トラッシュ)へ送る。"""

    count: int = 1
    destination: str = "hand"
    special_only: bool = False
    only_active: bool = False

    def execute(self, ctx: EffectContext) -> None:
        from effects.era_attacks_h import _opp_energy_entries

        source_indices, card_ids = _opp_energy_entries(ctx, 0 if self.only_active else None)
        if self.special_only:
            keep = [i for i, cid in enumerate(card_ids) if (c := ctx.card_db.get(cid)) is not None and c.is_special_energy]
            source_indices = [source_indices[i] for i in keep]
            card_ids = [card_ids[i] for i in keep]
        n = min(self.count, len(card_ids))
        if n <= 0:
            ctx.log("相手の場に対象のエネルギーが無い")
            return
        ctx.state.pending_search_choice = PendingSearchChoice(
            player_index=ctx.acting_player, zone="field_attachment", source_indices=source_indices, card_ids=card_ids, min_count=n, max_count=n,
            prompt=f"相手のエネルギーを{n}枚選ぶ", shuffle_after=False, all_card_ids=list(card_ids), destination=self.destination,
            effect_source=ctx.effect_source,
        )


@dataclass(frozen=True)
class SearchAnyToDiscard(Effect):
    """山札から好きなカードを最大count枚選んでトラッシュし、シャッフルする(ブリリアントブレンダー/バーネット教授)。"""

    count: int

    def execute(self, ctx: EffectContext) -> None:
        from effects.primitives import _trigger_search_choice

        _trigger_search_choice(
            ctx, _attacker_player(ctx), "deck", lambda c: c is not None, self.count, f"山札から最大{self.count}枚を選んでトラッシュする",
            shuffle_after=True, destination="discard",
        )


@dataclass(frozen=True)
class SearchPokemonSameNameAs(Effect):
    """山札から、「自分のトラッシュ(source="discard")/相手の場(source="opp_play")のポケモン」と同じ名前のポケモンを1匹選んで手札に加え、シャッフルする(なかよしベル/ラブラブボール)。"""

    source: str

    def execute(self, ctx: EffectContext) -> None:
        from effects.primitives import _trigger_search_choice

        if self.source == "discard":
            names = {c.name for cid in _attacker_player(ctx).discard if (c := ctx.card_db.get(cid)) is not None and c.is_pokemon}
        else:
            names = {c.name for m in ctx.state.player(ctx.opponent).all_pokemon_in_play() if (c := ctx.card_db.get(m.card_id)) is not None}
        _trigger_search_choice(
            ctx, _attacker_player(ctx), "deck", lambda c: c is not None and c.is_pokemon and c.name in names, 1,
            "山札から、同じ名前のポケモンを1匹探す", shuffle_after=True,
        )


@dataclass(frozen=True)
class EachPlayerRevealTopTakePokemon(Effect):
    """おたがいに、山札の上からn枚を公開し、その中のポケモンを全て手札に加え、残りを山札に戻してシャッフルする(ルアーモジュール)。"""

    n: int

    def execute(self, ctx: EffectContext) -> None:
        for idx in (ctx.acting_player, ctx.opponent):
            player = ctx.state.player(idx)
            seen = player.deck[: self.n]
            del player.deck[: self.n]
            rest = []
            for cid in seen:
                c = ctx.card_db.get(cid)
                if c is not None and c.is_pokemon:
                    player.hand.append(cid)
                else:
                    rest.append(cid)
            player.deck.extend(rest)
            ctx.rng.shuffle(player.deck)


@dataclass(frozen=True)
class CardsFromDiscardToHandIfCoins(Effect):
    """コインをcoins枚投げ、全てオモテなら、トラッシュから好きなカードを1枚手札に加える(ふるいパソコン)。"""

    coins: int

    def execute(self, ctx: EffectContext) -> None:
        from effects.primitives import _trigger_search_choice

        if all(ctx.rng.random() < 0.5 for _ in range(self.coins)):
            _trigger_search_choice(ctx, _attacker_player(ctx), "discard", lambda c: c is not None, 1, "トラッシュから手札に加えるカードを選ぶ", shuffle_after=False)


@dataclass(frozen=True)
class AttackBonusRuleThisTurn(Effect):
    """この番の間、spec(era_attacks_i.card_matches)に合う自分のポケモンのワザが、相手のバトルポケモンに+amount(+相手がとったサイド1枚につきper_prize)ダメージ
    (弱点・抵抗力の前)。ignore_defender_effects=Trueなら、そのワザのダメージは相手のバトルポケモンにかかっている効果を受けない(フィービ)。"""

    amount: int = 0
    spec: str = ""
    per_prize: int = 0
    ignore_defender_effects: bool = False

    def execute(self, ctx: EffectContext) -> None:
        _attacker_player(ctx).attack_bonus_rules_this_turn.append(
            {"amount": self.amount, "spec": self.spec, "per_prize": self.per_prize, "ignore_defender_effects": self.ignore_defender_effects}
        )


@dataclass(frozen=True)
class DamageReductionNextTurn(Effect):
    """相手の次の番の間、自分のポケモン(defender_spec)が、相手のポケモン(attacker_spec)から受けるワザのダメージをamount軽減する(ジャスミンの視線/ファイナ)。
    この間に場に出たポケモンも対象。"""

    amount: int
    attacker_subtype: str | None = None

    def execute(self, ctx: EffectContext) -> None:
        opponent = ctx.state.player(ctx.opponent)
        _attacker_player(ctx).damage_reductions.append(
            {"type": None, "subtype": None, "amount": self.amount, "until": opponent.turns_taken + 1, "attacker_subtype": self.attacker_subtype}
        )


@dataclass(frozen=True)
class NamedSupporterFromDiscardToHand(Effect):
    """トラッシュから、名前に name_part を含むポケモンを最大count枚手札に加える(ラベンテン教授)。"""

    name_part: str
    count: int

    def execute(self, ctx: EffectContext) -> None:
        from effects.primitives import _trigger_search_choice

        _trigger_search_choice(
            ctx, _attacker_player(ctx), "discard", lambda c: c is not None and c.is_pokemon and self.name_part in c.name, self.count,
            f"トラッシュから、名前に「{self.name_part}」を含むポケモンを最大{self.count}匹手札に加える", shuffle_after=False,
        )


# ---------------------------------------------------------------------------------------------
# 個別のサポート用
# ---------------------------------------------------------------------------------------------
@dataclass(frozen=True)
class ReturnChosenOwnPokemonToHand(Effect):
    """自分の場のポケモン(spec: pokemon_matches の絞り込み)を1匹選び、ついているカードごと手札に戻す(チェレンのいたわり)。"""

    spec: str = ""

    def execute(self, ctx: EffectContext) -> None:
        from effects.era_attacks_i import pokemon_matches

        player = _attacker_player(ctx)
        cands = [(s, m) for s, m in _own_slots(player) if pokemon_matches(ctx, m, self.spec)]
        if not cands:
            return
        _choice(
            ctx, zone="gen_pokemon_pick", source_indices=[s for s, _ in cands], card_ids=[m.card_id for _, m in cands], min_count=1, max_count=1,
            prompt="手札に戻すポケモンを選ぶ", op="return_pokemon_to_hand",
        )


def _op_return_pokemon_to_hand(state, card_db, choice, selected, action, ctx, custom) -> bool:
    from effects.era_primitives_b import _mon_at
    from engine.state import discard_attached_tool

    player = state.player(custom["user"])
    slot = choice.source_indices[selected[0]] if selected else None
    mon = _mon_at(player, slot) if slot is not None else None
    if mon is None:
        return False
    if mon.attached_tool is not None:
        player.hand.append(mon.attached_tool)
        mon.attached_tool = None
        mon.attached_tool_owner = None
    player.hand.extend(mon.evolution_history)
    player.hand.append(mon.card_id)
    player.hand.extend(mon.attached_energy)
    if slot == 0:
        if not player.bench:
            player.active = None
        else:
            state.pending_active_choice = [custom["user"]]
            player.active = None
    else:
        player.bench.pop(slot - 1)
    _ = discard_attached_tool
    return False


@dataclass(frozen=True)
class PutOpponentHandBasicOnBenchThenSwitch(Effect):
    """相手の手札を公開させ、たねポケモンを1匹選んで相手のベンチに出す。出したら、そのポケモンをバトル場に出す(switch=True。エリカの招待)。"""

    switch: bool = True

    def execute(self, ctx: EffectContext) -> None:
        from engine.continuous import effective_bench_limit

        opp = ctx.state.player(ctx.opponent)
        ctx.state.player(ctx.acting_player).known_opponent_hand = list(opp.hand)
        if len(opp.bench) >= effective_bench_limit(ctx.state, opp, ctx.card_db):
            return
        eligible = [i for i, cid in enumerate(opp.hand) if (c := ctx.card_db.get(cid)) is not None and c.is_pokemon and c.is_basic]
        if not eligible:
            return
        _choice(
            ctx, zone="gen_hand_pick", source_indices=eligible, card_ids=[opp.hand[i] for i in eligible], min_count=1, max_count=1,
            prompt="相手の手札から、相手のベンチに出すたねポケモンを選ぶ", op="opp_hand_basic_to_bench", switch=self.switch,
        )


def _op_opp_hand_basic_to_bench(state, card_db, choice, selected, action, ctx, custom) -> bool:
    from engine.state import PokemonInPlay

    opp = state.player(1 - custom["user"])
    if not selected:
        return False
    card_id = opp.hand.pop(choice.source_indices[selected[0]])
    opp.bench.append(PokemonInPlay(card_id=card_id, turn_played=opp.turns_taken))
    if custom["switch"]:
        _switch_in_opponent(state, 1 - custom["user"], len(opp.bench) - 1, None)
    return False


@dataclass(frozen=True)
class SetPlayedCardDestinationIfStadiumNamed(Effect):
    """このカード自身の行き先を、指定の名前のスタジアムが場に出ているときだけ変える(用務員: コミュニティセンターがあれば山札に混ぜる)。"""

    destination: str
    stadium_name: str

    def execute(self, ctx: EffectContext) -> None:
        stadium = ctx.card_db.get(ctx.state.stadium_in_play) if ctx.state.stadium_in_play else None
        if stadium is not None and stadium.name == self.stadium_name:
            ctx.state.played_card_destination = self.destination


@dataclass(frozen=True)
class MoveUpToNEnergyFromOneToAnother(Effect):
    """自分のポケモン1匹を選び、そのポケモンから別の自分のポケモンへ、エネルギーを最大n枚(選んで)移す(ポピー)。"""

    n: int

    def execute(self, ctx: EffectContext) -> None:
        player = _attacker_player(ctx)
        slots = _own_slots(player)
        srcs = [(s, m) for s, m in slots if m.attached_energy and len(slots) > 1]
        if not srcs:
            return
        _choice(
            ctx, zone="gen_pokemon_pick", source_indices=[s for s, _ in srcs], card_ids=[m.card_id for _, m in srcs], min_count=1, max_count=1,
            prompt="エネルギーを移す元のポケモンを選ぶ", op="move_energy_src", n=self.n,
        )


def _op_move_energy_src(state, card_db, choice, selected, action, ctx, custom) -> bool:
    player = state.player(custom["user"])
    if not selected:
        return False
    src = choice.source_indices[selected[0]]
    dests = [(s, m) for s, m in _own_slots(player) if s != src]
    state.pending_search_choice = PendingSearchChoice(
        player_index=custom["user"], zone="gen_pokemon_pick", source_indices=[s for s, _ in dests], card_ids=[m.card_id for _, m in dests],
        min_count=1, max_count=1, prompt="エネルギーを移す先のポケモンを選ぶ", shuffle_after=False, all_card_ids=[m.card_id for _, m in dests],
        custom_data={"op": "move_energy_dst", "user": custom["user"], "src": src, "n": custom["n"]}, effect_source=choice.effect_source,
        cont_acting_player=custom["user"],
    )
    return True


def _op_move_energy_dst(state, card_db, choice, selected, action, ctx, custom) -> bool:
    from effects.era_primitives_b import _mon_at

    if not selected:
        return False
    player = state.player(custom["user"])
    src_mon = _mon_at(player, custom["src"])
    if src_mon is None or not src_mon.attached_energy:
        return False
    dst = choice.source_indices[selected[0]]
    ids = list(src_mon.attached_energy)
    n = min(custom["n"], len(ids))
    state.pending_search_choice = PendingSearchChoice(
        player_index=custom["user"], zone="gen_pokemon_pick", source_indices=list(range(len(ids))), card_ids=[_label(card_db, e) for e in ids],
        min_count=0, max_count=n, prompt=f"移すエネルギーを最大{n}枚選ぶ", shuffle_after=False, all_card_ids=[_label(card_db, e) for e in ids],
        custom_data={"op": "move_energy_pick", "user": custom["user"], "src": custom["src"], "dst": dst, "ids": ids}, effect_source=choice.effect_source,
        cont_acting_player=custom["user"],
    )
    return True


def _op_move_energy_pick(state, card_db, choice, selected, action, ctx, custom) -> bool:
    from effects.era_primitives_b import _mon_at

    player = state.player(custom["user"])
    src = _mon_at(player, custom["src"])
    dst = _mon_at(player, custom["dst"])
    if src is None or dst is None:
        return False
    for i in selected:
        e = custom["ids"][i]
        if e in src.attached_energy:
            src.attached_energy.remove(e)
            dst.attached_energy.append(e)
    return False


@dataclass(frozen=True)
class PaldeanStudentEffect(Effect):
    """山札から、ルールを持たないポケモンを1匹探して手札に加える。トラッシュにある(このカード以外の)パルデアの子の枚数だけ、追加で探してもよい(パルデアの子)。"""

    def execute(self, ctx: EffectContext) -> None:
        from effects.primitives import _trigger_search_choice

        player = _attacker_player(ctx)
        extra = sum(1 for cid in player.discard if (c := ctx.card_db.get(cid)) is not None and c.name == "Paldean Student")
        from effects.era_attacks_i import card_matches

        _trigger_search_choice(
            ctx, player, "deck", lambda c: c is not None and c.is_pokemon and card_matches(c, "no_rule_box"), 1 + extra,
            "山札から、ルールを持たないポケモンを探す(トラッシュのパルデアの子の枚数ぶん追加)", shuffle_after=True,
        )


@dataclass(frozen=True)
class PerrinEffect(Effect):
    """手札のポケモンを最大2匹公開して山札に戻し、そうしたら、山札からその枚数までポケモンを探して手札に加える(ペパー)。"""

    def execute(self, ctx: EffectContext) -> None:
        player = _attacker_player(ctx)
        eligible = [i for i, cid in enumerate(player.hand) if (c := ctx.card_db.get(cid)) is not None and c.is_pokemon]
        if not eligible:
            return
        _choice(
            ctx, zone="gen_hand_pick", source_indices=eligible, card_ids=[player.hand[i] for i in eligible], min_count=0, max_count=min(2, len(eligible)),
            prompt="公開して山札に戻す手札のポケモンを最大2匹選ぶ", op="perrin_return",
        )


def _op_perrin_return(state, card_db, choice, selected, action, ctx, custom) -> bool:
    player = state.player(custom["user"])
    idxs = sorted((choice.source_indices[i] for i in selected), reverse=True)
    if not idxs:
        return False
    cards = [player.hand.pop(i) for i in idxs]
    player.deck.extend(cards)
    state.rng.shuffle(player.deck)
    ectx = EffectContext(state=state, card_db=card_db, acting_player=custom["user"], source_pokemon=None, source_card_id="", rng=state.rng)
    from effects.primitives import _trigger_search_choice

    _trigger_search_choice(
        ectx, player, "deck", lambda c: c is not None and c.is_pokemon, len(cards), f"山札からポケモンを最大{len(cards)}匹探す", shuffle_after=True,
    )
    return state.pending_search_choice is not None and state.pending_search_choice is not choice


@dataclass(frozen=True)
class RaifortEffect(Effect):
    """山札の上からn枚を見て、好きな枚数をトラッシュし、残りを好きな順で山札の上に戻す(ネリネ・ライフォート)。"""

    n: int

    def execute(self, ctx: EffectContext) -> None:
        player = _attacker_player(ctx)
        seen = player.deck[: self.n]
        if not seen:
            return
        _choice(
            ctx, zone="gen_deck_pick", source_indices=range(len(seen)), card_ids=list(seen), min_count=0, max_count=len(seen),
            prompt="山札の上から見たカードのうち、トラッシュするものを選ぶ(残りは好きな順で山札の上に戻す)", op="raifort_discard", n=len(seen),
        )


def _op_raifort_discard(state, card_db, choice, selected, action, ctx, custom) -> bool:
    player = state.player(custom["user"])
    n = custom["n"]
    seen = player.deck[:n]
    del player.deck[:n]
    discard = {choice.source_indices[i] for i in selected}
    keep = [cid for i, cid in enumerate(seen) if i not in discard]
    player.discard.extend(cid for i, cid in enumerate(seen) if i in discard)
    player.deck[0:0] = keep
    if len(keep) > 1:
        from effects.primitives import LookTopNReorderOnTop

        ectx = EffectContext(state=state, card_db=card_db, acting_player=custom["user"], source_pokemon=None, source_card_id="", rng=state.rng)
        LookTopNReorderOnTop(len(keep)).execute(ectx)
        return state.pending_search_choice is not None and state.pending_search_choice is not choice
    return False


@dataclass(frozen=True)
class DiscardOwnBenchedChosen(Effect):
    """自分のベンチのポケモン(spec)を1匹選び、ついているカードごとトラッシュする(ボロ)。"""

    spec: str = ""

    def execute(self, ctx: EffectContext) -> None:
        from effects.era_attacks_i import pokemon_matches

        player = _attacker_player(ctx)
        cands = [i for i, m in enumerate(player.bench) if pokemon_matches(ctx, m, self.spec)]
        if not cands:
            return
        _choice(
            ctx, zone="gen_pokemon_pick", source_indices=cands, card_ids=[player.bench[i].card_id for i in cands], min_count=1, max_count=1,
            prompt="トラッシュするベンチのポケモンを選ぶ", op="bench_discard_picked", owner=ctx.acting_player,
        )


@dataclass(frozen=True)
class RileyEffect(Effect):
    """山札の上からn枚を公開し、相手がそのうち2枚を選ぶ。選ばれたカードをトラッシュし、残りを手札に加える(ライリ)。"""

    n: int = 5

    def execute(self, ctx: EffectContext) -> None:
        player = _attacker_player(ctx)
        seen = player.deck[: self.n]
        if not seen:
            return
        k = min(2, len(seen))
        _choice(
            ctx, player=ctx.opponent, zone="gen_deck_pick", source_indices=range(len(seen)), card_ids=list(seen), min_count=k, max_count=k,
            prompt="相手の山札の上から公開されたカードのうち、トラッシュするカードを2枚選ぶ(残りは相手の手札に入る)", op="riley_pick", n=len(seen), owner=ctx.acting_player,
        )


def _op_riley_pick(state, card_db, choice, selected, action, ctx, custom) -> bool:
    owner = state.player(custom["owner"])
    n = custom["n"]
    seen = owner.deck[:n]
    del owner.deck[:n]
    chosen = {choice.source_indices[i] for i in selected}
    for i, cid in enumerate(seen):
        (owner.discard if i in chosen else owner.hand).append(cid)
    return False


@dataclass(frozen=True)
class DrawIfBenchGrew(Effect):
    """直前の効果で自分のベンチのポケモンが増えていたら(before匹より多ければ)、count枚引く(ミスタード: 「そうしたら」)。"""

    before: int
    count: int

    def execute(self, ctx: EffectContext) -> None:
        player = _attacker_player(ctx)
        if len(player.bench) > self.before:
            _draw(player, self.count)


@dataclass(frozen=True)
class SearchToBenchThenDraw(Effect):
    """条件(criterion)に合うポケモンを(zone="deck"/"discard"から)count匹までベンチに出し、出せたらdraw枚引く(ラピッド/シングルストライクスタイルのカラシナ)。"""

    criterion: str
    count: int
    zone: str
    draw: int

    def execute(self, ctx: EffectContext) -> None:
        from effects.era_trainers_j import SearchByCriterionToBench

        player = _attacker_player(ctx)
        before = len(player.bench)
        SearchByCriterionToBench(self.criterion, self.count, self.zone).execute(ctx)
        pending = ctx.state.pending_search_choice
        if pending is not None:
            pending.remaining_script = pending.remaining_script + (DrawIfBenchGrew(before, self.draw),)
        else:
            DrawIfBenchGrew(before, self.draw).execute(ctx)


# ---------------------------------------------------------------------------------------------
# 登録
# ---------------------------------------------------------------------------------------------
def register_ops() -> None:
    from effects.era_primitives_b import GENERIC_OP_HANDLERS

    GENERIC_OP_HANDLERS.update({
        "hand_to_bottom": _op_hand_to_bottom,
        "keep_one_discard_rest": _op_keep_one,
        "bench_discard_picked": _op_bench_discard_picked,
        "discard_to_top": _op_discard_to_top,
        "bottom_to_top": _op_bottom_to_top,
        "look_each_kind": _op_look_each_kind,
        "opp_hand_discard": _op_opp_hand_discard,
        "opp_top_discard": _op_opp_top_discard,
        "opp_top_to_bench": _op_opp_top_to_bench,
        "heal_up_to_step": _op_heal_up_to_step,
        "heal_until_tails": _op_heal_until_tails,
        "heal_discard_energy_pick": _op_heal_discard_energy_pick,
        "discard_energy_picked": _op_discard_energy_picked,
        "switch_in_opp_picked": _op_switch_in_opp_picked,
        "prime_catcher_opp": _op_prime_catcher_opp,
        "own_switch_picked": _op_own_switch_picked,
        "swap_discard_pick1": _op_swap_discard_pick1,
        "swap_discard_pick2": _op_swap_discard_pick2,
        "attach_each_step": _op_attach_each_step,
        "attach_discarded_step": _op_attach_discarded_step,
        "attach_revealed_top": _op_attach_revealed_top,
        "prize_swap_count": _op_prize_swap_count,
        "prize_swap_put": _op_prize_swap_put,
        "promote_last_benched": _op_promote_last_benched,
        "arc_phone_swap": _op_arc_phone_swap,
        "return_tool_to_hand": _op_return_tool_to_hand,
        "return_pokemon_to_hand": _op_return_pokemon_to_hand,
        "opp_hand_basic_to_bench": _op_opp_hand_basic_to_bench,
        "move_energy_src": _op_move_energy_src,
        "move_energy_dst": _op_move_energy_dst,
        "move_energy_pick": _op_move_energy_pick,
        "perrin_return": _op_perrin_return,
        "raifort_discard": _op_raifort_discard,
        "riley_pick": _op_riley_pick,
    })


register_ops()


# ---------------------------------------------------------------------------------------------
# 表への登録(effects/era_trainers_i.install から呼ぶ)。キーは effects/era_trainer_specs.py の SWSH_SV_TRAINER_SPECS
# ---------------------------------------------------------------------------------------------
def install(reg) -> None:
    import itertools

    from effects.era_abilities import PickPokemonThen
    from effects.era_attacks_h import SearchDiscardByCriterionToHand, ShuffleFromDiscardByCriterionIntoDeck
    from effects.era_attacks_i import DrawForEach, SearchByCriterionToBench
    from effects.era_abilities import SwapHandCardWithDeckTop
    from effects.era_primitives import IfCondition
    from effects.era_primitives_f import DiscardAllSpecialEnergyFromAllOpponentPokemon
    from effects.era_primitives_b import AttachEnergyGeneric, RevealOpponentHandPick
    from effects.era_primitives_f import ChooseOneEffectBranch
    from effects.era_trainers import _has_bench
    from effects.era_trainers_i import (
        DiscardHandCardsThenDrawPerCard, DiscardMatchingFromHand, FlipCoinsThenRepeat, LookTopNTake, LookOwnTopNChooseOneOnTop, MoveDamageCounters,
        SetEndTurnHandLimit, SetPlayedCardDestination, _all_gates, _gate,
    )
    from effects.primitives import (
        AllCoinsHeadsThen, ClearActiveStatusConditions, DiscardCardsFromHand, DiscardHandThenDraw,
        DiscardStadiumInPlay, DiscardToolsAndSpecialEnergyFromAllOpponentPokemon, Draw, DrawUpTo, EndTurnAfterThisAbility, FlipCoinThen,
        HealAllPokemonBothSides, HealOwnActiveFixed, LookTopNReorderOnTop, OpponentDiscardHandDownTo, SearchDeckAnyCardToHand,
        SearchDeckByCriterionToHand, SearchDeckForPokemonToHand, SearchDeckMultiCriteria, ShuffleHandIntoDeckThenDraw,
        SwitchActiveWithBench,
    )
    from effects.era_trainers_i import EvolveChosenOwnFromDeck
    from effects.primitives import IfLastAttachSucceeded

    EOT = EndTurnAfterThisAbility
    others = lambda n: _gate("hand_others_at_least", str(n))  # noqa: E731

    # ---- グッズ
    reg("j_accompanying_flute", (RevealOpponentTopPutBasicsOnTheirBench(5),))
    reg("j_arc_phone", (ArcPhoneEffect(),))
    reg("j_boost_shake", (EvolveChosenOwnFromDeck(ignore_timing=True), EOT()))
    reg("j_capturing_aroma", (FlipCoinThen(heads=(SearchDeckByCriterionToHand("evolution_pokemon", count=1),), tails=(SearchDeckByCriterionToHand("basic_pokemon", count=1),)),))
    reg("j_chill_teaser", (MoveOpponentFieldEnergy(1, "hand"),), _gate("second_player_first_turn"))
    reg("j_damage_pump", (MoveDamageCounters(count=2, scope="own_multi"),))
    reg("j_deduction_kit", (ChooseOneEffectBranch(
        labels=("好きな順番で山札の上に戻す", "シャッフルして山札の下に置く"), branches=((LookTopNReorderOnTop(3),), (ShuffleTopNToBottom(3),)),
    ),))
    reg("j_delivery_drone", (AllCoinsHeadsThen(2, then=(SearchDeckAnyCardToHand(1),)),))
    reg("j_dragon_elixir", (HealActiveOfType(60, "Dragon"),))
    from effects.era_tools_j import LookOwnTopCardEffect
    from effects.primitives import HealOwnActiveFixed

    reg("j_quad_stone", (HealOwnActiveFixed(10),))  # 4枚同時使用は registry.TRAINER_QUAD_EFFECTS(effects/era_tools_j.install_quads)
    reg("j_missing_clover", (LookOwnTopCardEffect(),))
    reg("j_drone_rotom", (OpponentTopDeckLookAndRevealHand(),))
    reg("j_egg_incubator", (FlipCoinThen(heads=(SearchByCriterionToBench("basic_pokemon", 1),), tails=(SetPlayedCardDestination("bottom"),)),))
    reg("j_energy_recycler", (ShuffleDiscardedKindIntoDeckThenDraw("basic_energy", 5),))
    reg("j_expedition_uniform", (MoveBottomCardsToTop(3),))
    reg("j_familiar_bell", (SearchPokemonSameNameAs("discard"),))
    reg("j_fan_of_waves", (MoveOpponentFieldEnergy(1, "deck", special_only=True),))
    reg("j_full_heal", (ClearActiveStatusConditions(),))
    reg("j_grabber", (RevealOpponentHandPick(criteria="pokemon", dest="bottom"),))
    reg("j_gutsy_pickaxe", (RevealTopCardAttachOrHand("energy_type:Fighting"),))
    reg("j_hand_trimmer", (OpponentDiscardHandDownTo(5), DiscardHandDownTo(5)))
    reg("j_hyper_potion", (HealThenDiscardEnergy(120, 2, 2),))
    reg("j_love_ball", (SearchPokemonSameNameAs("opp_play"),))
    reg("j_lucky_ice_pop", (HealActiveThenCoinKeepCard(20),))
    reg("j_lure_module", (EachPlayerRevealTopTakePokemon(3),))
    reg("j_meddling_memo", (OpponentHandToBottomThenDrawSame(),))
    reg("j_megaton_blower", (DiscardToolsAndSpecialEnergyFromAllOpponentPokemon(), DiscardStadiumInPlay()))
    reg("j_moomoo_cheese", (HealUpToNPokemon(2, 30, require_energy=True),))
    reg("j_ogres_mask", (SwitchWithDiscardPokemon(own_spec="subtype:ex|name_part:Ogerpon", discard_spec="subtype:ex|name_part:Ogerpon"),))
    reg("j_old_pc", (CardsFromDiscardToHandIfCoins(2),))
    reg("j_picnic_basket", (HealAllPokemonBothSides(30),))
    reg("j_poke_ball_coin", (FlipCoinThen(heads=(SearchDeckForPokemonToHand(count=1),), tails=()),))
    reg("j_poke_vital_a", (PickPokemonThen(side="own", action="heal", amount=150),))
    reg("j_prime_catcher", (PrimeCatcherEffect(),))
    reg("j_reboot_pod", (AttachDiscardEnergyToEachMatching("subtype:Future"),))
    reg("j_rescue_carrier", (SearchDiscardByCriterionToHand("cardspec:hp_at_most:90", count=2),))
    reg("j_rotom_phone", (LookOwnTopNChooseOneOnTop(5),))
    reg("j_spicy_curry", (InflictStatusOnOwnActive("burned"), HealOwnActiveFixed(40)))
    reg("j_suspicious_food_tin", (HealThenDiscardEnergy(80, 1, 1, "Psychic"),))
    reg("j_sweet_honey", (HealUntilTailsOnChosen(40),))
    reg("j_switching_cups", (SwapHandCardWithDeckTop(),))
    reg("j_team_yell_towel", (HealBothActive(50),))
    reg("j_toy_catcher", (SwitchInOpponentBenched(hp_at_most=50),))
    reg("j_turbo_patch", (FlipCoinThen(heads=(AttachEnergyGeneric(
        source="discard", count=1, basic_only=True, single_target=True, target_subtype="Basic", exclude_subtype="GX"),), tails=()),))
    reg("j_urn_of_vitality", (ShuffleDiscardedKindIntoDeckThenDraw("and:any_energy&&name_part:Single Strike", 2),))
    reg("j_yell_horn", (BothActiveStatus("confused"),))

    # ---- サポート
    reg("j_acerola", (DrawPerOpponentHandKind(1, "trainer"),))
    reg("j_agatha", (MoveDamageCounters(count=3, scope="active_to_opp_active", up_to=True),))
    reg("j_allister", (Draw(3), DiscardUpToFromHand(3, 1)))
    reg("j_amarys", (Draw(4), SetEndTurnHandLimit(threshold=5, keep=0)))
    reg("j_aroma_lady", (Draw(2), ClearActiveStatusConditions()))
    reg("j_avery", (Draw(3), OpponentBenchDownTo(3)))
    reg("j_ball_guy", (SearchDeckByCriterionToHand("item_name_contains:Ball", count=3),))
    reg("j_bea", (DiscardTopThenAttachDiscardedEnergy(5, "type:Fighting"),))
    reg("j_bianca", (PickPokemonThen(side="own", action="heal", full=True, remaining_hp_at_most=30),))
    reg("j_billy_onare", (DrawThenBonusIfHandAtLeast(2, 10, 2),))
    reg("j_bird_keeper", (SwitchActiveWithBench(), Draw(3)), _has_bench)
    for key, etype in (("j_blanche", "Water"), ("j_candela", "Fire"), ("j_spark", "Lightning")):
        reg(key, (Draw(2), FlipCoinThen(heads=(AttachEnergyGeneric(
            source="discard", count=1, basic_only=True, energy_type=etype, bench_only=True, single_target=True),), tails=())))
    reg("j_brassius", (ShuffleHandThenDrawSame(1),))
    reg("j_cafe_master", (AttachEnergyGeneric(
        source="deck", count=3, basic_only=True, bench_only=True, distinct_targets=True, distinct_energy_types=True, optional=True), EOT()))
    reg("j_caretaker", (Draw(2), SetPlayedCardDestinationIfStadiumNamed("deck", "Community Center")))
    reg("j_cheren", (ReturnChosenOwnPokemonToHand("type:Colorless|damaged"),))
    reg("j_cheryl", (HealEvolutionsThenDiscardEnergy(),))
    reg("j_choy", (RevealBothHands(), Draw(3)))
    reg("j_clive", (DrawPerOpponentHandKind(2, "supporter"),))
    reg("j_cyllene", (FlipCoinsThenPutDiscardOnTop(2),))
    reg("j_daisy", (DrawThenLookAtPrizes(2),))
    reg("j_dendra", (PutHandCardsOnBottom(1, "until:5"),), others(1))
    reg("j_digging_duo", (FlipCoinThen(
        heads=(LookTopNTake(n=8, m=1, criterion="any", exact=True, rest="shuffle", from_top=False),),
        tails=(LookTopNTake(n=3, m=1, criterion="any", exact=True, rest="shuffle", from_top=False),)),))
    reg("j_drasna", (ShuffleHandIntoDeckThenDraw(0), FlipCoinThen(heads=(Draw(8),), tails=(Draw(3),))))
    reg("j_drayton", (LookTopNTakeEachKind(7, ("pokemon", "trainer")),))
    reg("j_eri", (RevealOpponentHandDiscardUpTo("item", 2),))
    reg("j_erikas_invitation", (PutOpponentHandBasicOnBenchThenSwitch(),))
    reg("j_fantina", (DamageReductionNextTurn(120, "V"),), _gate("lost_zone_at_least", "10"))
    reg("j_flannery", (MoveOpponentFieldEnergy(1, "discard", special_only=True), DiscardStadiumInPlay()))
    reg("j_furisode_girl", (SearchBasicToBenchMayPromote(),))
    reg("j_gardenias_vigor", (Draw(2), AttachEnergyGeneric(
        source="hand", count=2, basic_only=True, energy_type="Grass", bench_only=True, single_target=True, optional=True)))
    reg("j_geeta", (AttachEnergyGeneric(source="deck", count=2, basic_only=True, single_target=True), SetAttackLockThisTurn()))
    reg("j_giacomo", (DiscardAllSpecialEnergyFromAllOpponentPokemon(),))
    reg("j_honey", (DrawForEach(per=1, counter="opp_bench", arg="subtype:V"),))
    reg("j_jasmines_gaze", (DamageReductionNextTurn(30),))
    reg("j_kamado", (KeepOneDiscardRestThenDraw(4),), others(1))
    reg("j_karens_conviction", (AttackBonusRuleThisTurn(spec="subtype:Single Strike", per_prize=20),))
    reg("j_klara", (ChooseOneEffectBranch(
        labels=("トラッシュのポケモンを最大2枚手札に加える", "トラッシュの基本エネルギーを最大2枚手札に加える", "両方"),
        branches=(
            (SearchDiscardByCriterionToHand("pokemon", count=2),), (SearchDiscardByCriterionToHand("basic_energy", count=2),),
            (SearchDiscardByCriterionToHand("pokemon", count=2), SearchDiscardByCriterionToHand("basic_energy", count=2)),
        )),))
    reg("j_kofu", (PutHandCardsOnBottom(2, "fixed:4"),), others(2))
    reg("j_larry", (FlipCoinThen(heads=(SearchDeckByCriterionToHand("pokemon", count=2),), tails=(SearchDeckByCriterionToHand("basic_pokemon", count=1),)),))
    reg("j_larrys_skill", (DiscardWholeHand(), SearchDeckMultiCriteria(("pokemon", "supporter", "basic_energy"))))
    reg("j_leon", (AttackBonusRuleThisTurn(amount=30),))
    reg("j_lisias_appeal", (SwitchInOpponentBenched(spec="basic", then_status="confused"),))
    reg("j_lucian", (EachPlayerHandToBottomThenCoinDraw(6, 3),))
    reg("j_mela", (AttachEnergyGeneric(source="discard", count=1, basic_only=True, energy_type="Fire", single_target=True), IfLastAttachSucceeded((DrawUpTo(6),))), _gate("ko_last_turn"))
    reg("j_milo", (DiscardHandCardsThenDrawPerCard(criterion="any", max_count=2, per=2),))
    reg("j_miriam", (ShuffleDiscardedKindIntoDeckThenDraw("pokemon", 5, draw=3),))
    reg("j_miss_fortune_sisters", (LookOpponentTopDiscardKind(5, "item"),))
    reg("j_mortys_conviction", (DrawForEach(per=1, counter="opp_bench"),), others(1))
    reg("j_oleana", (DiscardCardsFromHand(2), RevealOpponentHandPick(criteria="trainer", dest="bottom")), others(2))
    reg("j_opal", (FlipCoinsThenRepeat(coins=2, effect=SearchDeckAnyCardToHand(1)),))
    reg("j_ortega", (RevealOpponentHandPick(criteria="any", dest="bottom", then=(OpponentDraw(1),)),))
    reg("j_paldean_student", (PaldeanStudentEffect(),))
    reg("j_peonia", (PrizeSwapWithHand(3),))
    reg("j_peony", (DiscardWholeHand(), SearchDeckByCriterionToHand("trainer", count=2)))
    reg("j_perrin", (PerrinEffect(),))
    reg("j_phoebe", (AttackBonusRuleThisTurn(spec="subtype:VMAX", ignore_defender_effects=True),))
    reg("j_breeders_nurturing", (EvolveChosenOwnFromDeck(), EvolveChosenOwnFromDeck()))
    reg("j_poppy", (MoveUpToNEnergyFromOneToAnother(2),))
    reg("j_burnet", (SearchAnyToDiscard(2),))
    reg("j_laventon", (NamedSupporterFromDiscardToHand("Hisuian", 3),))
    reg("j_raifort", (RaifortEffect(5),))
    reg("j_rapid_strike_mustard", (SearchToBenchThenDraw("cardspec:subtype:Rapid Strike", 1, "discard", 5),), _gate("hand_only_this"))
    reg("j_single_strike_mustard", (SearchToBenchThenDraw("cardspec:subtype:Single Strike", 1, "deck", 5),), _gate("hand_only_this"))
    reg("j_rika", (LookTopNTake(n=4, m=2, criterion="any", exact=True, rest="bottom_shuffle"),))
    reg("j_riley", (RileyEffect(5),))
    reg("j_rose", (AttachEnergyGeneric(source="discard", count=2, basic_only=True, single_target=True, target_subtype="VMAX"), IfLastAttachSucceeded((DiscardWholeHand(),))))
    reg("j_roseannes_backup", (_subset_branch(),))
    reg("j_saguaro", (HealUpToNPokemon(2, 50),))
    reg("j_salvatore", (EvolveChosenOwnFromDeck(ignore_timing=True, no_ability=True),))
    reg("j_serena", (ChooseOneEffectBranch(
        labels=("手札を最大3枚トラッシュして、手札が5枚になるまで引く", "相手のベンチのポケモンVを入れ替える"),
        branches=((DiscardUpToFromHand(3, 1), DrawUpTo(5)), (SwitchInOpponentBenched(spec="subtype:V"),))),))
    reg("j_sidney", (RevealOpponentHandDiscardUpTo("or:pokemon_tool|special_energy|stadium", 2),))
    reg("j_siebold", (HealUpToNPokemon(2, 60, subtype="Rapid Strike"),))
    reg("j_sonia", (ChooseOneEffectBranch(
        labels=("たねポケモンを最大2枚手札に加える", "基本エネルギーを最大2枚手札に加える"),
        branches=((SearchDeckByCriterionToHand("basic_pokemon", count=2),), (SearchDeckByCriterionToHand("basic_energy", count=2),))),))
    reg("j_team_star_grunt", (MoveOpponentFieldEnergy(1, "deck_top", only_active=True),))
    reg("j_team_yell_grunt", (MoveOpponentFieldEnergy(1, "hand"),))
    reg("j_team_yells_cheer", (ShuffleDiscardedKindIntoDeckThenDraw("or:pokemon|supporter", 3, except_name="Team Yell's Cheer"),))
    reg("j_thorton", (SwitchWithDiscardPokemon(own_spec="basic", discard_spec="basic"),))
    reg("j_volo", (DiscardOwnBenchedChosen("subtype:V"),))
    reg("j_wallace", (Draw(3), OpponentDraw(1), Draw(1)))
    reg("j_zisu", (DrawUntilMoreThanOpponent(1),))
    reg("j_marnies_pride", (AttachEnergyGeneric(source="discard", count=1, basic_only=True, bench_only=True, single_target=True),))
    _ = (IfCondition, _all_gates, DrawForEach)


def _subset_branch():
    """ローズマリーの手助け: 4つの効果から1つ以上を選ぶ(全ての組み合わせを選択肢にする)。"""
    import itertools

    from effects.era_attacks_h import ShuffleFromDiscardByCriterionIntoDeck as S

    parts = (
        ("ポケモン", S("pokemon", 1)),
        ("ポケモンのどうぐ", S("pokemon_tool", 1)),
        ("スタジアム", S("stadium", 1)),
        ("エネルギー", S("any_energy", 1)),
    )
    labels, branches = [], []
    for r in range(1, 5):
        for combo in itertools.combinations(parts, r):
            labels.append("+".join(name for name, _ in combo))
            branches.append(tuple(e for _, e in combo))
    from effects.era_primitives_f import ChooseOneEffectBranch

    return ChooseOneEffectBranch(labels=tuple(labels), branches=tuple(branches))
