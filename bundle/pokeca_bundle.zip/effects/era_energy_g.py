"""メガ時代(ME)・XY・ダブルクライシスの特殊エネルギーと、それに関わるスタジアム/どうぐのフック(2026-10-07)。

effects/era_trainers_g.py のIDテーブル(カード名→ID)を使う。engine/effects側の各フックから呼ばれる。
"""

from __future__ import annotations

from effects.generated_era_trainer_ids import IDS


def _ids(key: str) -> frozenset:
    return frozenset(card_id for card_id, _tag in IDS.get(key, ()))


DOUBLE_AQUA_IDS = _ids("double_aqua")
DOUBLE_MAGMA_IDS = _ids("double_magma")
DOUBLE_DRAGON_IDS = _ids("double_dragon")
SHIELD_ENERGY_IDS = _ids("shield_energy")
DANGEROUS_ENERGY_IDS = _ids("dangerous_energy")
FLASH_ENERGY_IDS = _ids("flash_energy")
BURNING_ENERGY_IDS = _ids("burning_energy")
BUBBLY_WATER_IDS = _ids("bubbly_water_energy")
NITRO_FIRE_IDS = _ids("nitro_fire_energy")
SHADOWY_DARKNESS_IDS = _ids("shadowy_darkness_energy")
RECYCLE_ENERGY_IDS = _ids("recycle_energy")
SPIKY_ENERGY_IDS = _ids("spiky_energy")

# 「〜ポケモンにしかつけられない」特殊エネルギー: ID集合 → ついてよいポケモンの条件
def _is_team(prefix: str):
    return lambda card: card.name.startswith(prefix + "'s ")


def _sm_ids(name: str) -> frozenset:
    from effects import era_sm_hooks

    return getattr(era_sm_hooks, name)


_RESTRICTED: tuple = (
    (_sm_ids("TRIPLE_ACCELERATION_IDS"), lambda card: not card.is_basic),  # トリプルアクセレーション: 進化ポケモンにしかつけられない
    (DOUBLE_AQUA_IDS, _is_team("Team Aqua")),
    (DOUBLE_MAGMA_IDS, _is_team("Team Magma")),
    (DOUBLE_DRAGON_IDS, lambda card: "Dragon" in card.types),
    (SHIELD_ENERGY_IDS, lambda card: "Metal" in card.types),
    (DANGEROUS_ENERGY_IDS, lambda card: "Darkness" in card.types),
    (FLASH_ENERGY_IDS, lambda card: "Lightning" in card.types),
    (BURNING_ENERGY_IDS, lambda card: "Fire" in card.types),
)


def energy_tokens_g(card_db, energy_card_id: str, host_card_id):
    """この特殊エネルギーが提供するタイプトークン(該当しなければNone)。条件を満たさないポケモンについていれば無色1個ぶん(実際はトラッシュされる)。"""
    host = card_db.get(host_card_id) if host_card_id else None
    for ids, ok in _RESTRICTED:
        if energy_card_id in ids:
            if host is None or not ok(host):
                return ["Colorless"]
            if ids is DOUBLE_AQUA_IDS:
                return ["Water", "Water"]
            if ids is DOUBLE_MAGMA_IDS:
                return ["Fighting", "Fighting"]
            if ids is DOUBLE_DRAGON_IDS:
                from engine.energy import WILDCARD_TOKEN

                return [WILDCARD_TOKEN, WILDCARD_TOKEN]  # あらゆるタイプのエネルギーを(2個ぶん)提供する
            if ids is SHIELD_ENERGY_IDS:
                return ["Metal"]
            if ids is DANGEROUS_ENERGY_IDS:
                return ["Darkness"]
            if ids is FLASH_ENERGY_IDS:
                return ["Lightning"]
            return ["Fire"]
    if energy_card_id in BUBBLY_WATER_IDS:
        return ["Water"]
    if energy_card_id in NITRO_FIRE_IDS:
        return ["Fire"]
    if energy_card_id in SHADOWY_DARKNESS_IDS:
        return ["Darkness"]
    if energy_card_id in RECYCLE_ENERGY_IDS:
        return ["Colorless"]
    return None


def attach_allowed_g(energy_card_id: str, target_card) -> bool:
    for ids, ok in _RESTRICTED:
        if energy_card_id in ids:
            return ok(target_card)
    return True


def discard_invalid_restricted_energy(state, card_db) -> None:
    """条件を満たさないポケモンについている限定エネルギー(ダブルアクア/ダブルマグマ/ダブルドラゴン等)をトラッシュする。"""
    for side in (0, 1):
        player = state.players[side]
        for mon in player.all_pokemon_in_play():
            card = card_db.get(mon.card_id)
            if card is None:
                continue
            for ids, ok in _RESTRICTED:
                if ok(card) or not any(e in ids for e in mon.attached_energy):
                    continue
                kept = []
                for e in mon.attached_energy:
                    (player.discard if e in ids else kept).append(e)
                mon.attached_energy = kept
                state.add_log("限定エネルギーは、条件に合わないポケモンについていたのでトラッシュされた")


def on_energy_attached(state, card_db, actor: int, target, energy_card_id: str) -> None:
    """手札からつけたとき: ダブルアクア/ダブルマグマは、つけた番の終わりにトラッシュする印をつける。"""
    if energy_card_id in DOUBLE_AQUA_IDS or energy_card_id in DOUBLE_MAGMA_IDS or energy_card_id in _sm_ids("TRIPLE_ACCELERATION_IDS"):
        state.player(actor).end_of_turn_discard_energy.append((target, energy_card_id))
    if energy_card_id in _sm_ids("DRAW_ENERGY_IDS"):
        player = state.player(actor)
        if player.deck:
            player.hand.append(player.deck.pop(0))  # ドローエネルギー: 手札からつけたとき、山札を1枚引く
            state.add_log("ドローエネルギーの効果で、山札を1枚引いた")


def end_of_turn_energy(state, card_db) -> None:
    """ターン終了時: つけた番の終わりにトラッシュするエネルギー(ダブルアクア/ダブルマグマ)をトラッシュする(現在のプレイヤー=終わる番の側)。"""
    player = state.player(state.current_player)
    for mon, energy_id in player.end_of_turn_discard_energy:
        if energy_id in mon.attached_energy:
            mon.attached_energy.remove(energy_id)
            player.discard.append(energy_id)
            state.add_log("このエネルギーはつけた番の終わりにトラッシュされた")
    player.end_of_turn_discard_energy = []


def shield_energy_reduction(defender, defender_card) -> int:
    """シールドエネルギー: ついているメタルポケモンへの相手のワザのダメージを10減らす(弱点・抵抗力の前)。"""
    if any(e in SHIELD_ENERGY_IDS for e in defender.attached_energy) and "Metal" in defender_card.types:
        return 10
    return 0


def on_active_damaged(ctx, defender, defender_owner, dmg: int) -> None:
    """バトル場でワザのダメージを受けたとき: ダンジャラスエネルギー(ポケモンEXの攻撃者にダメカン2個)/Tremendous Bomb(メガシンカポケモンexから240以上でダメカン12個)。"""
    attacker = ctx.source_pokemon
    if attacker is None:
        return
    attacker_card = ctx.card_db.get(attacker.card_id)
    defender_card = ctx.card_db.get(defender.card_id)
    if attacker_card is None or defender_card is None:
        return
    from effects.primitives import _blocks_damage_counters

    if (
        any(e in DANGEROUS_ENERGY_IDS for e in defender.attached_energy)
        and "Darkness" in defender_card.types
        and "EX" in attacker_card.subtypes
        and not _blocks_damage_counters(attacker)
    ):
        attacker.damage += 20
        ctx.log("ダンジャラスエネルギーの効果で、攻撃したポケモンEXにダメカンを2個のせた")
    tool = defender.attached_tool
    if tool in TREMENDOUS_BOMB_IDS:
        from effects.era_trainers import _tools_active

        is_mega_ex = "MEGA" in defender_card.subtypes and "ex" in defender_card.subtypes
        attacker_is_mega_ex = "MEGA" in attacker_card.subtypes and "ex" in attacker_card.subtypes
        if _tools_active(ctx.state) and not is_mega_ex and attacker_is_mega_ex and dmg >= 240 and not _blocks_damage_counters(attacker):
            attacker.damage += 120
            ctx.log("トレメンダスボムの効果で、攻撃したポケモンにダメカンを12個のせた")
            from effects.primitives import discard_attached_tool

            discard_attached_tool(ctx.state, defender_owner, defender)


TREMENDOUS_BOMB_IDS = _ids("tremendous_bomb")
LIGHT_BALL_IDS = _ids("light_ball")


def no_weakness_by_energy(defender, defender_card) -> bool:
    """フラッシュエネルギー: ついている雷ポケモンは弱点を持たない。"""
    if any(e in _sm_ids("WEAKNESS_GUARD_IDS") for e in defender.attached_energy):
        return True  # ウィークネスガードエネルギー: ついているポケモンは弱点を持たない
    return any(e in FLASH_ENERGY_IDS for e in defender.attached_energy) and "Lightning" in defender_card.types


def status_immune_by_energy(mon, card) -> bool:
    """バブリーウォーターエネルギー: ついている水ポケモンは特殊状態にならない。"""
    return card is not None and "Water" in card.types and any(e in BUBBLY_WATER_IDS for e in mon.attached_energy)


def bench_immune_by_energy(defender, defender_card, owner) -> bool:
    """シャドウィダークネスエネルギー: ベンチにいる、ついている悪ポケモンは相手のワザのダメージを受けない。"""
    return (
        defender is not owner.active
        and defender_card is not None
        and "Darkness" in defender_card.types
        and any(e in SHADOWY_DARKNESS_IDS for e in defender.attached_energy)
    )


# ---------------------------------------------------------------------------------------------
# 「トラッシュされたら手札に戻る/つけ直す」系: apply_actionの前後で、エネルギーの増減を数えて処理する
# ---------------------------------------------------------------------------------------------
def energy_snapshot(state, card_db):
    """apply_action前の、各プレイヤーの「場についている対象エネルギー」と「トラッシュにある対象エネルギー」の枚数、およびワザを使う側のバトルポケモン。"""
    watched = RECYCLE_ENERGY_IDS | NITRO_FIRE_IDS | BURNING_ENERGY_IDS
    if not watched or not state.setup_complete:
        return None
    snap = []
    for side in (0, 1):
        player = state.players[side]
        attached = {}
        for mon in player.all_pokemon_in_play():
            for e in mon.attached_energy:
                if e in watched:
                    attached[e] = attached.get(e, 0) + 1
        discard = {e: player.discard.count(e) for e in watched if e in player.discard}
        snap.append((attached, discard))
    if not any(a for a, _d in snap):
        return None
    attacker = state.player(state.current_player).active
    return snap, attacker, list(attacker.attached_energy) if attacker is not None else []


def after_action_energy(state, card_db, before, was_attack: bool) -> None:
    if before is None:
        return
    snap, attacker, attacker_energy_before = before
    for side in (0, 1):
        player = state.players[side]
        attached_before, discard_before = snap[side]
        attached_now = {}
        for mon in player.all_pokemon_in_play():
            for e in mon.attached_energy:
                if e in attached_before:
                    attached_now[e] = attached_now.get(e, 0) + 1
        for e, count_before in attached_before.items():
            lost = count_before - attached_now.get(e, 0)
            if lost <= 0:
                continue
            gained = player.discard.count(e) - discard_before.get(e, 0)
            moved = min(lost, gained)
            for _ in range(moved):
                if e in RECYCLE_ENERGY_IDS:
                    player.discard.remove(e)
                    player.hand.append(e)  # リサイクルエネルギー: トラッシュされるかわりに手札に戻る
                    state.add_log("リサイクルエネルギーは、トラッシュされるかわりに手札に戻った")
                elif side == state.current_player and was_attack and attacker is not None:
                    card = card_db.get(attacker.card_id)
                    if e in NITRO_FIRE_IDS and e in attacker_energy_before and card is not None and "Fire" in card.types:
                        player.discard.remove(e)
                        player.hand.append(e)  # ニトロファイアエネルギー: 自分の炎ポケモンのワザで捨てたら手札に戻る
                        state.add_log("ニトロファイアエネルギーは、ワザの効果で捨てたので手札に戻った")
                    elif e in BURNING_ENERGY_IDS and e in attacker_energy_before and card is not None and "Fire" in card.types and attacker in player.all_pokemon_in_play():
                        player.discard.remove(e)
                        attacker.attached_energy.append(e)  # バーニングエネルギー: ワザで捨てたら、そのポケモンにつけ直す
                        state.add_log("バーニングエネルギーは、ワザの効果で捨てたのでそのポケモンにつけ直された")
