"""自動生成したグッズ/サポート(effects/generated_effects.py の GENERATED_TRAINER_GATES)の「使える条件」(2026-10-07)。

「You can play this card only if ...」「If you have no cards in your deck, you can't play this card.」のような文を、
scripts/generate_effects_batch17.py が条件名(+引数)に直して書き出し、effects/era_trainers.trainer_playable がここで評価する。
各関数は(state, player, player_index, card_db, arg) -> bool。使う時点で、このカード自身はまだ手札にある。
"""

from __future__ import annotations

import functools


def _opponent(state, player_index: int):
    return state.player(1 - player_index)


def deck_nonempty(state, player, player_index, card_db, arg) -> bool:
    return bool(player.deck)


def hand_only_this(state, player, player_index, card_db, arg) -> bool:
    return len(player.hand) <= 1


def hand_others_at_most(state, player, player_index, card_db, arg) -> bool:
    return len(player.hand) - 1 <= int(arg)


def hand_others_at_least(state, player, player_index, card_db, arg) -> bool:
    return len(player.hand) - 1 >= int(arg)


def ko_last_turn(state, player, player_index, card_db, arg) -> bool:
    """直前の相手の番に、自分のポケモン(arg指定ならそのタイプのポケモン)がきぜつしていた。"""
    if arg:
        return arg in player.ko_types_last_turn
    return bool(player.pokemon_ko_last_turn)


def opponent_active_subtype(state, player, player_index, card_db, arg) -> bool:
    active = _opponent(state, player_index).active
    card = card_db.get(active.card_id) if active is not None else None
    return card is not None and arg in card.subtypes


def stadium_in_play(state, player, player_index, card_db, arg) -> bool:
    return state.stadium_in_play is not None


def hand_has_pokemon_of_type(state, player, player_index, card_db, arg) -> bool:
    return any((c := card_db.get(cid)) is not None and c.is_pokemon and arg in c.types for cid in player.hand)


def second_player_first_turn(state, player, player_index, card_db, arg) -> bool:
    return player.turns_taken == 1 and player_index != state.first_player


def opponent_active_has_energy(state, player, player_index, card_db, arg) -> bool:
    active = _opponent(state, player_index).active
    return active is not None and bool(active.attached_energy)


def own_discard_nonempty(state, player, player_index, card_db, arg) -> bool:
    return bool(player.discard)


def opp_active_status(state, player, player_index, card_db, arg) -> bool:
    active = _opponent(state, player_index).active
    if active is None:
        return False
    if arg == "poisoned":
        return active.status.poisoned
    if arg == "burned":
        return active.status.burned
    return active.status.exclusive.name == arg.upper()


def lost_zone_at_least(state, player, player_index, card_db, arg) -> bool:
    return len(player.lost_zone) >= int(arg)


def more_prizes_than_opponent(state, player, player_index, card_db, arg) -> bool:
    return len(player.prizes) > len(_opponent(state, player_index).prizes)


def turn1_ok(state, player, player_index, card_db, arg) -> bool:
    return True  # 「先攻なら、最初の番に使ってもよい」(使える条件ではなく、1番目の番の制限の例外。effects/era_trainer_gates.turn1_exception_ids)


@functools.lru_cache(maxsize=1)
def turn1_exception_ids() -> frozenset:
    """「If you go first, you may use this card during your first turn.」のカードID(自動生成した使える条件のうち、turn1_okを持つもの)。"""
    from effects import registry as R

    return frozenset(cid for cid, gates in R.GENERATED_TRAINER_GATES.items() if any(name == "turn1_ok" for name, _ in gates))


def opp_prizes_in(state, player, player_index, card_db, arg) -> bool:
    return len(_opponent(state, player_index).prizes) in {int(x) for x in arg.split(",")}


def own_only_active(state, player, player_index, card_db, arg) -> bool:
    return player.active is not None and not player.bench


def own_no_energy(state, player, player_index, card_db, arg) -> bool:
    return not any(m.attached_energy for m in player.all_pokemon_in_play())


def first_turn(state, player, player_index, card_db, arg) -> bool:
    return player.turns_taken == 1


def own_active_name_part(state, player, player_index, card_db, arg) -> bool:
    card = card_db.get(player.active.card_id) if player.active is not None else None
    return card is not None and arg in card.name


def stadium_named(state, player, player_index, card_db, arg) -> bool:
    card = card_db.get(state.stadium_in_play) if state.stadium_in_play else None
    return card is not None and card.name == arg


def hand_matches(state, player, player_index, card_db, arg) -> bool:
    """手札に条件(SearchDeckMultiCriteriaの条件名)に合うカードがN枚以上(カード自身を除く)。arg="条件:枚数"。"""
    from effects.primitives import SearchDeckMultiCriteria

    criterion, _, count = arg.rpartition(":")
    return sum(
        1 for cid in player.hand
        if (c := card_db.get(cid)) is not None and (criterion == "any" or SearchDeckMultiCriteria._matches(c, criterion))
    ) >= int(count)


def opp_prizes_at_most(state, player, player_index, card_db, arg) -> bool:
    return len(_opponent(state, player_index).prizes) <= int(arg)


GATE_FUNCS = {
    "opp_active_status": opp_active_status,
    "lost_zone_at_least": lost_zone_at_least,
    "more_prizes_than_opponent": more_prizes_than_opponent,
    "turn1_ok": turn1_ok,
    "opp_prizes_at_most": opp_prizes_at_most,
    "opp_prizes_in": opp_prizes_in,
    "own_only_active": own_only_active,
    "own_no_energy": own_no_energy,
    "first_turn": first_turn,
    "own_active_name_part": own_active_name_part,
    "stadium_named": stadium_named,
    "hand_matches": hand_matches,
    "deck_nonempty": deck_nonempty,
    "hand_only_this": hand_only_this,
    "hand_others_at_most": hand_others_at_most,
    "hand_others_at_least": hand_others_at_least,
    "ko_last_turn": ko_last_turn,
    "opponent_active_subtype": opponent_active_subtype,
    "stadium_in_play": stadium_in_play,
    "hand_has_pokemon_of_type": hand_has_pokemon_of_type,
    "second_player_first_turn": second_player_first_turn,
    "opponent_active_has_energy": opponent_active_has_energy,
    "own_discard_nonempty": own_discard_nonempty,
}


def generated_gate_ok(gates, state, player, player_index: int, card_db) -> bool:
    """GENERATED_TRAINER_GATES[card_id] = ((条件名, 引数), ...)の全てを満たしているか。"""
    return all(GATE_FUNCS[name](state, player, player_index, card_db, arg) for name, arg in gates)
