"""時代ごとのカード取り込み(2026-10-06〜)で追加した効果プリミティブその4(サイド・トラッシュ・ダメージの個別効果)。

effects/era_primitives*.py と同じ規約。ダメージを与えるものは必ずDealDamageを1回だけ経由する。
"""

from __future__ import annotations

from dataclasses import dataclass

from effects.context import EffectContext
from effects.primitives import DealDamage, Effect, _attacker_player, _defender


def _basic_energy_type_of(card_db, card_id: str) -> str | None:
    card = card_db.get(card_id)
    return card.basic_energy_type if card is not None else None


@dataclass(frozen=True)
class PeekOneOwnPrize(Effect):
    """自分の裏向きのサイドを1枚見る(Safety Check)。どれを見るかはサイドが伏せてあるため区別がつかず、ランダムでよい。"""

    def execute(self, ctx: EffectContext) -> None:
        player = _attacker_player(ctx)
        if len(player.prize_marks) != len(player.prizes):
            player.prize_marks = [0] * len(player.prizes)
        hidden = [i for i, m in enumerate(player.prize_marks) if m == 0]
        if not hidden:
            return
        i = ctx.rng.choice(hidden)
        player.prize_marks[i] = max(player.prize_marks[i], 1)
        ctx.log("自分のサイドを1枚見た")


@dataclass(frozen=True)
class TurnOnePrizeFaceUpBonusIfPokemon(Effect):
    """自分の裏向きのサイドを1枚表向きにする。それがポケモンならbase+bonus、そうでなければbaseのダメージ(Lunatic Sense)。
    表向きにしたカードはゲーム中ずっと表向きのまま。"""

    base: int
    bonus: int

    def execute(self, ctx: EffectContext) -> None:
        player = _attacker_player(ctx)
        if len(player.prize_marks) != len(player.prizes):
            player.prize_marks = [0] * len(player.prizes)
        hidden = [i for i, m in enumerate(player.prize_marks) if m < 2]
        extra = 0
        if hidden:
            i = ctx.rng.choice(hidden)
            player.prize_marks[i] = 2
            card = ctx.card_db.get(player.prizes[i])
            ctx.log(f"サイドの{player.prizes[i]}を表向きにした")
            if card is not None and card.is_pokemon:
                extra = self.bonus
        DealDamage(self.base + extra).execute(ctx)


@dataclass(frozen=True)
class DamagePerOwnDiscardEnergyOfTypesThenShuffleBack(Effect):
    """自分のトラッシュにある指定タイプ(types)のエネルギー1枚につきperダメージ。そのあと、それらのカードを全て山札に戻してシャッフルする
    (Dragon Vortex)。"""

    types: tuple
    per: int

    def execute(self, ctx: EffectContext) -> None:
        player = _attacker_player(ctx)
        mine = [cid for cid in player.discard if _basic_energy_type_of(ctx.card_db, cid) in self.types]
        DealDamage(self.per * len(mine)).execute(ctx)
        if mine:
            player.discard = [cid for cid in player.discard if _basic_energy_type_of(ctx.card_db, cid) not in self.types]
            player.deck.extend(mine)
            ctx.rng.shuffle(player.deck)


@dataclass(frozen=True)
class MoveAllDefenderEnergyToOpponentHand(Effect):
    """相手のバトルポケモンについているエネルギーを全て、相手の手札に戻す(Retribution)。"""

    def execute(self, ctx: EffectContext) -> None:
        from effects.primitives import _defender_blocks_effect

        opponent = ctx.state.player(ctx.opponent)
        active = opponent.active
        if active is None or not active.attached_energy or _defender_blocks_effect(ctx, active):
            return
        opponent.hand.extend(active.attached_energy)
        active.attached_energy = []
        ctx.log("相手のバトルポケモンのエネルギーを全て相手の手札に戻した")


@dataclass(frozen=True)
class DamagePerEnergyOnOwnNamed(Effect):
    """自分の場の指定名のポケモンについているエネルギー1枚につきper(+base)ダメージ(Tag Team Spark)。"""

    base: int
    per: int
    name: str

    def execute(self, ctx: EffectContext) -> None:
        player = _attacker_player(ctx)
        n = sum(
            len(m.attached_energy)
            for m in player.all_pokemon_in_play()
            if (c := ctx.card_db.get(m.card_id)) is not None and c.name == self.name
        )
        DealDamage(self.base + self.per * n).execute(ctx)


@dataclass(frozen=True)
class DamagePerDistinctTypesOnOpponentBench(Effect):
    """相手のベンチのポケモンのタイプの種類数×perダメージ(Prismatic Wave)。"""

    per: int

    def execute(self, ctx: EffectContext) -> None:
        types = set()
        for m in ctx.state.player(ctx.opponent).bench:
            c = ctx.card_db.get(m.card_id)
            if c is not None:
                types.update(c.types)
        DealDamage(self.per * len(types)).execute(ctx)


@dataclass(frozen=True)
class DamagePerOpponentPokemonInPlay(Effect):
    """相手の場のポケモン(バトル場+ベンチ)の数×perダメージ(Emperor's Command)。"""

    per: int

    def execute(self, ctx: EffectContext) -> None:
        DealDamage(self.per * len(ctx.state.player(ctx.opponent).all_pokemon_in_play())).execute(ctx)


@dataclass(frozen=True)
class DamagePerOpponentActiveEnergyOfType(Effect):
    """相手のバトルポケモンについている指定タイプの基本エネルギー1枚につきper追加ダメージ(Powder)。"""

    base: int
    per: int
    energy_type: str

    def execute(self, ctx: EffectContext) -> None:
        _, defender = _defender(ctx)
        n = 0
        if defender is not None:
            n = sum(1 for e in defender.attached_energy if _basic_energy_type_of(ctx.card_db, e) == self.energy_type)
        DealDamage(self.base + self.per * n).execute(ctx)


@dataclass(frozen=True)
class OpponentFlipCoinsDiscardPerTails(Effect):
    """相手がコインをcount枚投げ、ウラ1枚につき手札を1枚(相手が選んで)トラッシュする(Mental Trash)。"""

    count: int

    def execute(self, ctx: EffectContext) -> None:
        from effects.era_primitives import OpponentDiscardsFromHand

        tails = sum(1 for _ in range(self.count) if ctx.rng.random() >= 0.5)
        ctx.log(f"相手のコイン: ウラ{tails}回")
        if tails > 0:
            OpponentDiscardsFromHand(tails).execute(ctx)


@dataclass(frozen=True)
class DiscardOpponentDeckPerSelfCounters(Effect):
    """このポケモンについているダメカン1個につき、相手の山札の上を1枚トラッシュする(Mad Mountain)。"""

    def execute(self, ctx: EffectContext) -> None:
        if ctx.source_pokemon is None:
            return
        opponent = ctx.state.player(ctx.opponent)
        for _ in range(ctx.source_pokemon.damage // 10):
            if not opponent.deck:
                break
            opponent.discard.append(opponent.deck.pop(0))


@dataclass(frozen=True)
class RockPaperScissorsDrawDiscard(Effect):
    """おたがいにじゃんけんをして、勝った方がdraw枚引き、負けた方が山札の上をdiscard枚トラッシュする(Fortunate Draw)。
    あいこは勝負がつくまでやり直すので、勝敗は五分五分。"""

    draw: int
    discard: int

    def execute(self, ctx: EffectContext) -> None:
        winner_is_me = ctx.rng.random() < 0.5
        ctx.log("じゃんけん: 勝ち" if winner_is_me else "じゃんけん: 負け")
        winner = ctx.state.player(ctx.acting_player if winner_is_me else ctx.opponent)
        loser = ctx.state.player(ctx.opponent if winner_is_me else ctx.acting_player)
        for _ in range(self.draw):
            if not winner.deck:
                break
            winner.hand.append(winner.deck.pop(0))
        for _ in range(self.discard):
            if not loser.deck:
                break
            loser.discard.append(loser.deck.pop(0))


@dataclass(frozen=True)
class DamageCoinShieldNextTurn(Effect):
    """相手の次の番、このポケモンがワザのダメージを受けるたびにコインを投げ、オモテならそのダメージを防ぐ(Afterimage Strike)。"""

    def execute(self, ctx: EffectContext) -> None:
        if ctx.source_pokemon is None:
            return
        ctx.source_pokemon.damage_coin_shield_until_turn = ctx.state.player(ctx.opponent).turns_taken + 1


@dataclass(frozen=True)
class DealDamageToChosenDamagedOpponentPokemon(Effect):
    """ダメカンがのっている相手のポケモン1匹を選び、amountダメージ(ベンチは弱点・抵抗力を計算しない)(Blindside)。"""

    amount: int
    attack_target = "opp_any"
    damaged_only = True

    def execute(self, ctx: EffectContext) -> None:
        from effects.primitives import DealDamageToChosenOpponentPokemon, _resolve_opponent_target

        opponent = ctx.state.player(ctx.opponent)
        target = _resolve_opponent_target(ctx, opponent)
        if target is None or target.damage <= 0:
            return
        DealDamageToChosenOpponentPokemon(self.amount).execute(ctx)


@dataclass(frozen=True)
class DamageBonusIfSelfAsleepUsableWhileAsleep(Effect):
    """ねむり状態でも使えるワザ。ねむりのときだけbonus追加ダメージ(Dream Waltz)。"""

    base: int
    bonus: int
    attack_while_asleep = True

    def execute(self, ctx: EffectContext) -> None:
        asleep = ctx.source_pokemon is not None and ctx.source_pokemon.status.exclusive.name == "ASLEEP"
        DealDamage(self.base + (self.bonus if asleep else 0)).execute(ctx)


@dataclass(frozen=True)
class DealDamageUsableOnFirstTurnIfFirstPlayer(Effect):
    """先攻なら、最初の番からでも使えるワザ(Fast Raid)。"""

    amount: int
    usable_on_first_turn_if_first_player = True

    def execute(self, ctx: EffectContext) -> None:
        DealDamage(self.amount).execute(ctx)


@dataclass(frozen=True)
class DiscardChosenOpponentToolsUpTo(Effect):
    """相手のポケモンについているポケモンのどうぐを、最大max_count枚まで選んでトラッシュする(Double Scrapper)。"""

    max_count: int

    def execute(self, ctx: EffectContext) -> None:
        from effects.primitives import _field_attachment_candidates
        from engine.state import PendingSearchChoice

        source_indices, card_ids = _field_attachment_candidates(
            ctx.state, ctx.card_db, (ctx.opponent,), include_tool=True, energy_predicate=None
        )
        if not card_ids:
            ctx.log("相手のポケモンについているどうぐが無い")
            return
        ctx.state.pending_search_choice = PendingSearchChoice(
            player_index=ctx.acting_player,
            zone="field_attachment",
            source_indices=source_indices,
            card_ids=card_ids,
            min_count=0,
            max_count=min(self.max_count, len(card_ids)),
            prompt=f"トラッシュする相手のポケモンのどうぐを選ぶ(最大{self.max_count}枚)",
            shuffle_after=False,
            all_card_ids=list(card_ids),
            destination="discard",
        )
